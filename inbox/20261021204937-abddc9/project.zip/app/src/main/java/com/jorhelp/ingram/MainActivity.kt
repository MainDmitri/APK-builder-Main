package com.jorhelp.ingram

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import java.net.HttpURLConnection
import java.net.URL
import android.util.Base64
import java.util.concurrent.ConcurrentLinkedQueue

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ScannerScreen()
                }
            }
        }
    }
}

@Composable
fun ScannerScreen() {
    var targets by remember { mutableStateOf("192.168.1.1\n192.168.1.0/24") }
    var ports by remember { mutableStateOf("80,81,8000,8080,37777") }
    var users by remember { mutableStateOf("admin") }
    var passwords by remember { mutableStateOf("admin\nadmin12345\n12345") }
    var isScanning by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf(listOf<String>()) }
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Ingram Camera Scanner", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = targets,
            onValueChange = { targets = it },
            label = { Text("Targets (IP, IP:port, CIDR, range)") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )
        OutlinedTextField(
            value = ports,
            onValueChange = { ports = it },
            label = { Text("Ports (comma separated)") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = users,
            onValueChange = { users = it },
            label = { Text("Users") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = passwords,
            onValueChange = { passwords = it },
            label = { Text("Passwords (one per line)") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                if (!isScanning) {
                    isScanning = true
                    results = emptyList()
                    scope.launch {
                        val res = withContext(Dispatchers.IO) {
                            runScan(targets, ports, users, passwords)
                        }
                        results = res
                        isScanning = false
                    }
                }
            },
            enabled = !isScanning,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isScanning) "Scanning..." else "Start Scan")
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(results) { line ->
                Text(line, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 2.dp))
            }
        }
    }
}

private suspend fun runScan(targetsStr: String, portsStr: String, usersStr: String, passwordsStr: String): List<String> {
    val out = ConcurrentLinkedQueue<String>()
    val portList = portsStr.split(",").mapNotNull { it.trim().toIntOrNull() }.ifEmpty { listOf(80, 8000, 8080) }
    val userList = usersStr.lines().map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf("admin") }
    val passList = passwordsStr.lines().map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf("admin") }

    val targets = parseTargets(targetsStr)
    out.add("Parsed ${targets.size} targets, scanning ${portList.size} ports...")

    coroutineScope {
        val jobs = targets.map { target ->
            async(Dispatchers.IO) {
                scanTarget(target, portList, userList, passList, out)
            }
        }
        jobs.awaitAll()
    }
    out.add("Scan complete.")
    return out.toList()
}

private fun parseTargets(input: String): List<String> {
    val list = mutableListOf<String>()
    input.lines().forEach { line ->
        val t = line.trim()
        if (t.isEmpty() || t.startsWith("#")) return@forEach
        if (t.contains("/")) {
            // simple CIDR expand limited
            list.add(t) // placeholder, expand later if needed
        } else if (t.contains("-")) {
            list.add(t)
        } else {
            list.add(t)
        }
    }
    // For demo, just take first few unique IPs if CIDR too big
    return list.distinct().take(50)
}

private fun scanTarget(target: String, ports: List<Int>, users: List<String>, passes: List<String>, out: ConcurrentLinkedQueue<String>) {
    val (ip, forcedPort) = if (target.contains(":")) {
        val p = target.split(":")
        p[0] to p[1].toIntOrNull()
    } else target to null

    val portsToScan = forcedPort?.let { listOf(it) } ?: ports

    for (port in portsToScan) {
        try {
            val url = URL("http://$ip:$port/")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 3000
            conn.readTimeout = 3000
            conn.requestMethod = "GET"
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            val code = conn.responseCode
            val body = try { conn.inputStream.bufferedReader().readText().take(2000) } catch (e: Exception) { "" }
            val headers = conn.headerFields.entries.joinToString { "${it.key}:${it.value}" }

            var product = "unknown"
            if (body.contains("hikvision", ignoreCase = true) || body.contains("iVMS") || headers.contains("APP-webs")) product = "hikvision"
            else if (body.contains("dahua", ignoreCase = true) || body.contains("DVR")) product = "dahua"
            else if (headers.contains("DCS") || body.contains("dlink")) product = "dlink"
            else if (body.contains("GeoVision")) product = "geovision"

            if (product != "unknown") {
                out.add("[$ip:$port] Fingerprint: $product (HTTP $code)")
                // Weak password check for hikvision
                if (product == "hikvision") {
                    for (u in users) {
                        for (p in passes) {
                            try {
                                val auth = Base64.encodeToString("$u:$p".toByteArray(), Base64.NO_WRAP)
                                val authConn = URL("http://$ip:$port/ISAPI/Security/userCheck").openConnection() as HttpURLConnection
                                authConn.setRequestProperty("Authorization", "Basic $auth")
                                authConn.connectTimeout = 2000
                                authConn.readTimeout = 2000
                                if (authConn.responseCode == 200) {
                                    val resp = authConn.inputStream.bufferedReader().readText()
                                    if (resp.contains("statusValue") && resp.contains("200")) {
                                        out.add("[$ip:$port] VULN: $product weak-password $u:$p")
                                        return
                                    }
                                }
                            } catch (_: Exception) {}
                        }
                    }
                }
            } else if (code in 200..399) {
                out.add("[$ip:$port] Open (HTTP $code), no known fingerprint")
            }
            conn.disconnect()
        } catch (e: Exception) {
            // port closed or timeout
        }
    }
}
