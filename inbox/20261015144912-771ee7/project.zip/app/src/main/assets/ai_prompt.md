Напиши Telegram-бота для платформы Telegram Serverless (tgcloud). Ответ — ОДИН файл bot.js целиком, без сокращений и заглушек.

Правила платформы:
1. Код работает в облаке Telegram в изолированном V8, это не Node.js. Нет npm-пакетов, require, fs, process, файлов .env. Токен бота не нужен и не должен быть в коде.
2. Импорт только из 'sdk': import { api, fetch, InputFile, BotApiError } from 'sdk';
3. Обработчики — экспортируемые функции: export async function <тип_апдейта>(payload, ctx). Имя функции = тип апдейта Bot API: message, edited_message, callback_query, inline_query, chosen_inline_result, pre_checkout_query, shipping_query, my_chat_member, chat_member, chat_join_request, poll, poll_answer, message_reaction, channel_post, business_message и т.д. payload — содержимое апдейта (для message — объект Message, для callback_query — CallbackQuery), полный Update — в ctx.update.
4. Экспортируй ТОЛЬКО обработчики. Вспомогательные функции и константы — без export.
5. Нет polling, Dispatcher, bot.launch(), main(), setWebhook. Платформа сама вызывает обработчик на каждый апдейт, вебхук настраивается автоматически по списку экспортов.
6. Вызов Bot API: const result = await api.<метод>({ параметры в snake_case }), например api.sendMessage({ chat_id, text, reply_markup }). Возвращается сразу result. При ошибке бросается BotApiError с полями .code и .description.
7. Команды разбирай вручную из msg.text, например /^\/start(@\w+)?(\s|$)/. Не забывай, что в группах команда может быть вида /start@имя_бота.
8. Не храни состояние в переменных модуля между апдейтами: каждый вызов может идти в новом экземпляре. Базы данных в однофайловом режиме нет; если нужно хранить данные, используй внешний HTTPS API через fetch из 'sdk' (await fetch(url, { method, headers, body }) → res.ok, await res.json()).
9. Логи — console.log / console.warn / console.error.
10. Оплата Telegram Stars: api.sendInvoice с currency: 'XTR', provider_token: '', prices: [{ label, amount }]; обязательно экспортируй pre_checkout_query с await api.answerPreCheckoutQuery({ pre_checkout_query_id: query.id, ok: true }); успешная оплата приходит в обработчик message как msg.successful_payment.
11. Кнопки callback: export async function callback_query(q, ctx) и обязательно await api.answerCallbackQuery({ callback_query_id: q.id }).
12. Все запросы асинхронные — всегда await.

Шаблон:
import { api } from 'sdk';

export async function message(msg, ctx) {
  if (typeof msg.text !== 'string') return;
  if (/^\/start(@\w+)?(\s|$)/.test(msg.text)) {
    await api.sendMessage({ chat_id: msg.chat.id, text: 'Привет!' });
  }
}

Задача бота:
