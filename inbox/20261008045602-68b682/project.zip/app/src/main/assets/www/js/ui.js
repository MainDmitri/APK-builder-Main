// Интерфейс: меню, список миров и серверов, настройки, HUD, чат, инвентарь
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const A = window.MC_ASSETS;

  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined && text !== null) e.textContent = text;
    return e;
  }

  function loadImg(src) {
    return new Promise((res, rej) => {
      const im = new Image();
      im.onload = () => res(im);
      im.onerror = () => rej(new Error('Не удалось загрузить изображение интерфейса'));
      im.src = src;
    });
  }

  function crop(img, x, y, w, h) {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    c.getContext('2d').drawImage(img, x, y, w, h, 0, 0, w, h);
    return c.toDataURL();
  }

  class UI {
    constructor(app) {
      this.app = app;
      this.root = document.getElementById('screens');
      this.hud = document.getElementById('hud');
      this.sprites = {};
      this.chatLines = [];
      this.chatOpen = false;
      this.current = null;
    }

    async init() {
      const [gui, icons] = await Promise.all([loadImg(A.gui.gui), loadImg(A.gui.icons)]);
      const s = this.sprites;
      s.hotbar = crop(gui, 0, 0, 182, 22);
      s.selector = crop(gui, 0, 22, 24, 24);
      s.btn = crop(gui, 0, 66, 200, 20);
      s.btnHover = crop(gui, 0, 86, 200, 20);
      s.btnOff = crop(gui, 0, 46, 200, 20);
      s.up = crop(gui, 0, 107, 26, 26);
      s.left = crop(gui, 26, 107, 26, 26);
      s.down = crop(gui, 52, 107, 26, 26);
      s.right = crop(gui, 78, 107, 26, 26);
      s.jump = crop(gui, 104, 107, 26, 26);
      s.flyUp = crop(gui, 52, 133, 26, 26);
      s.flyDown = crop(gui, 78, 133, 26, 26);
      s.sneak = crop(gui, 218, 64, 18, 18);
      s.pause = crop(gui, 200, 64, 18, 18);
      s.chat = crop(gui, 200, 82, 18, 18);
      s.cross = crop(icons, 0, 0, 15, 15);
      s.heartEmpty = crop(icons, 16, 0, 9, 9);
      s.heartFull = crop(icons, 52, 0, 9, 9);
      s.heartHalf = crop(icons, 61, 0, 9, 9);
      s.foodEmpty = crop(icons, 16, 27, 9, 9);
      s.foodFull = crop(icons, 52, 27, 9, 9);
      s.foodHalf = crop(icons, 61, 27, 9, 9);
      s.bubble = crop(icons, 16, 18, 9, 9);
      s.armorEmpty = crop(icons, 16, 9, 9, 9);
      s.armorHalf = crop(icons, 25, 9, 9, 9);
      s.armorFull = crop(icons, 34, 9, 9, 9);
      const css = document.documentElement.style;
      css.setProperty('--btn', 'url(' + s.btn + ')');
      css.setProperty('--btn-hover', 'url(' + s.btnHover + ')');
      css.setProperty('--btn-off', 'url(' + s.btnOff + ')');
      css.setProperty('--dirt', 'url(' + A.gui.background + ')');
      css.setProperty('--hotbar', 'url(' + s.hotbar + ')');
      css.setProperty('--selector', 'url(' + s.selector + ')');
      css.setProperty('--cross', 'url(' + s.cross + ')');
      css.setProperty('--t-up', 'url(' + s.up + ')');
      css.setProperty('--t-down', 'url(' + s.down + ')');
      css.setProperty('--t-jump', 'url(' + s.jump + ')');
      css.setProperty('--t-left', 'url(' + s.left + ')');
      css.setProperty('--t-right', 'url(' + s.right + ')');
      css.setProperty('--t-flyup', 'url(' + s.flyUp + ')');
      css.setProperty('--t-flydown', 'url(' + s.flyDown + ')');
      css.setProperty('--t-sneak', 'url(' + s.sneak + ')');
      css.setProperty('--t-pause', 'url(' + s.pause + ')');
      css.setProperty('--t-chat', 'url(' + s.chat + ')');
      this.buildPanorama();
      this.buildHud();
    }

    buildPanorama() {
      const pano = document.getElementById('panorama');
      const cube = el('div', 'pano-cube');
      // panorama_0..5: перед, право, зад, лево, верх, низ
      const tf = ['translateZ(-50vmax)', 'rotateY(-90deg) translateZ(-50vmax)', 'rotateY(180deg) translateZ(-50vmax)',
        'rotateY(90deg) translateZ(-50vmax)', 'rotateX(-90deg) translateZ(-50vmax)', 'rotateX(90deg) translateZ(-50vmax)'];
      A.gui.panorama.forEach((src, i) => {
        const f = el('div', 'pano-face');
        f.style.backgroundImage = 'url(' + src + ')';
        f.style.transform = tf[i];
        cube.appendChild(f);
      });
      pano.appendChild(cube);
    }

    showPanorama(v) { document.getElementById('panorama').style.display = v ? 'block' : 'none'; }

    // ---------- Общие элементы меню ----------
    clear() {
      this.root.innerHTML = '';
      this.root.style.display = 'none';
      this.root.className = '';
      this.current = null;
    }

    screen(name, opts) {
      this.root.innerHTML = '';
      this.root.style.display = 'flex';
      this.root.className = (opts && opts.dirt ? 'dirt ' : '') + (opts && opts.overlay ? 'overlay ' : '');
      this.current = name;
      const box = el('div', 'screen screen-' + name);
      this.root.appendChild(box);
      return box;
    }

    button(parent, label, onClick, opts) {
      const b = el('button', 'mc-btn' + (opts && opts.small ? ' small' : ''), label);
      if (opts && opts.disabled) b.disabled = true;
      b.addEventListener('click', (e) => { e.preventDefault(); if (!b.disabled) { MC.Sound.click(); onClick(); } });
      parent.appendChild(b);
      return b;
    }

    field(parent, label, value, opts) {
      const wrap = el('label', 'mc-field');
      wrap.appendChild(el('span', 'mc-label', label));
      const i = el('input', 'mc-input');
      i.type = (opts && opts.type) || 'text';
      i.value = value === undefined || value === null ? '' : value;
      if (opts && opts.placeholder) i.placeholder = opts.placeholder;
      if (opts && opts.maxLength) i.maxLength = opts.maxLength;
      i.autocomplete = 'off';
      i.spellcheck = false;
      wrap.appendChild(i);
      parent.appendChild(wrap);
      return i;
    }

    slider(parent, label, min, max, step, value, fmt, onChange) {
      const wrap = el('label', 'mc-field');
      const lab = el('span', 'mc-label', label + ': ' + fmt(value));
      wrap.appendChild(lab);
      const i = el('input', 'mc-range');
      i.type = 'range';
      i.min = min; i.max = max; i.step = step; i.value = value;
      i.addEventListener('input', () => { lab.textContent = label + ': ' + fmt(parseFloat(i.value)); onChange(parseFloat(i.value)); });
      wrap.appendChild(i);
      parent.appendChild(wrap);
      return i;
    }

    // ---------- Экраны ----------
    showMain() {
      this.showPanorama(true);
      const box = this.screen('main');
      const logo = el('div', 'logo');
      const img = el('img');
      img.src = A.gui.title;
      img.alt = 'Minecraft';
      logo.appendChild(img);
      if (A.splashes && A.splashes.length) logo.appendChild(el('div', 'splash', A.splashes[Math.floor(Math.random() * A.splashes.length)]));
      box.appendChild(logo);
      const col = el('div', 'menu-col');
      box.appendChild(col);
      this.button(col, 'Одиночная игра', () => this.showWorlds());
      this.button(col, 'Сетевая игра', () => this.showServers());
      this.button(col, 'Настройки', () => this.showSettings(() => this.showMain()));
      if (this.app.startupNotes && this.app.startupNotes.length) {
        box.appendChild(el('div', 'hint startup-note', this.app.startupNotes.join(' · ')));
        this.app.startupNotes = [];
      }
      box.appendChild(el('div', 'footer-left', 'HTML5-клиент · протокол ' + MC.McpeClient.PROTOCOL + ' (MCPE 1.1.x)'));
      box.appendChild(el('div', 'footer-right', 'Неофициальная игра. Текстуры: Minecraft PE 1.1.5 © Mojang'));
    }

    async showWorlds() {
      this.showPanorama(false);
      const box = this.screen('worlds', { dirt: true });
      box.appendChild(el('h2', 'title', 'Одиночная игра'));
      const list = el('div', 'list');
      box.appendChild(list);
      const row = el('div', 'btn-row');
      box.appendChild(row);
      let selected = null;
      const playBtn = this.button(row, 'Играть', () => selected && this.app.playWorld(selected), { disabled: true });
      const delBtn = this.button(row, 'Удалить', async () => {
        if (!selected) return;
        if (!confirm('Удалить мир «' + selected.name + '»? Это нельзя отменить.')) return;
        await MC.Storage.Worlds.remove(selected.id);
        this.showWorlds();
      }, { disabled: true });
      const row2 = el('div', 'btn-row');
      box.appendChild(row2);
      this.button(row2, 'Создать новый мир', () => this.showCreateWorld());
      this.button(row2, 'Назад', () => this.showMain());
      let worlds = [];
      try {
        worlds = await MC.Storage.Worlds.list();
      } catch (e) {
        list.appendChild(el('div', 'empty', 'Хранилище недоступно: ' + e.message));
        return;
      }
      if (!worlds.length) list.appendChild(el('div', 'empty', 'Миров пока нет. Создайте первый.'));
      for (const w of worlds) {
        const item = el('div', 'list-item');
        item.appendChild(el('div', 'li-title', w.name));
        item.appendChild(el('div', 'li-sub', (w.gamemode === 0 ? 'Выживание' : 'Творческий') + ' · зерно ' + w.seed + ' · ' + new Date(w.lastPlayed).toLocaleString('ru-RU')));
        item.addEventListener('click', () => {
          for (const c of list.children) c.classList.remove('sel');
          item.classList.add('sel');
          selected = w;
          playBtn.disabled = false;
          delBtn.disabled = false;
        });
        item.addEventListener('dblclick', () => this.app.playWorld(w));
        list.appendChild(item);
      }
    }

    showCreateWorld() {
      const box = this.screen('create', { dirt: true });
      box.appendChild(el('h2', 'title', 'Новый мир'));
      const name = this.field(box, 'Название мира', 'Новый мир', { maxLength: 32 });
      const seed = this.field(box, 'Зерно (необязательно)', '', { placeholder: 'случайное' });
      const modeWrap = el('label', 'mc-field');
      modeWrap.appendChild(el('span', 'mc-label', 'Режим игры'));
      const mode = el('select', 'mc-input');
      for (const [v, t] of [['0', 'Выживание'], ['1', 'Творческий']]) {
        const o = el('option', null, t);
        o.value = v;
        mode.appendChild(o);
      }
      modeWrap.appendChild(mode);
      box.appendChild(modeWrap);
      const row = el('div', 'btn-row');
      box.appendChild(row);
      this.button(row, 'Создать', async () => {
        let s = seed.value.trim();
        let num;
        if (!s) num = Math.floor(Math.random() * 2147483647);
        else if (/^-?\d+$/.test(s)) num = parseInt(s, 10) | 0;
        else { num = 0; for (const ch of s) num = (Math.imul(num, 31) + ch.charCodeAt(0)) | 0; }
        const w = { id: MC.Storage.uuidv4(), name: name.value.trim() || 'Новый мир', seed: num, gamemode: parseInt(mode.value, 10), created: Date.now(), lastPlayed: Date.now(), player: null };
        await MC.Storage.Worlds.put(w);
        this.app.playWorld(w);
      });
      this.button(row, 'Отмена', () => this.showWorlds());
    }

    showServers() {
      this.showPanorama(false);
      const st = this.app.settings;
      const box = this.screen('servers', { dirt: true });
      box.appendChild(el('h2', 'title', 'Сетевая игра'));
      const relay = this.field(box, 'Адрес ретранслятора (relay.js)', st.relay, { placeholder: 'ws://192.168.1.10:8080' });
      relay.addEventListener('change', () => { st.relay = relay.value.trim(); MC.Storage.saveSettings(st); this.showServers(); });
      box.appendChild(el('div', 'hint', window.AndroidRelay
        ? 'Ретранслятор встроен в приложение и запускается сам (адрес выше). Вход через Xbox Live не поддерживается: нужны серверы без него (xbox-auth=false).'
        : 'Серверы MCPE работают по UDP, а браузер умеет только WebSocket, поэтому подключение идёт через ретранслятор. Вход через Xbox Live не поддерживается: нужны серверы без него (xbox-auth=false).'));
      const list = el('div', 'list');
      box.appendChild(list);
      const servers = MC.Storage.loadServers();
      let selected = -1;
      const row = el('div', 'btn-row');
      box.appendChild(row);
      const join = this.button(row, 'Подключиться', () => selected >= 0 && this.app.connect(servers[selected]), { disabled: true });
      const edit = this.button(row, 'Изменить', () => selected >= 0 && this.showEditServer(selected), { disabled: true });
      const del = this.button(row, 'Удалить', () => {
        if (selected < 0) return;
        servers.splice(selected, 1);
        MC.Storage.saveServers(servers);
        this.showServers();
      }, { disabled: true });
      const row2 = el('div', 'btn-row');
      box.appendChild(row2);
      this.button(row2, 'Добавить сервер', () => this.showEditServer(-1));
      this.button(row2, 'Обновить', () => this.showServers());
      this.button(row2, 'Назад', () => this.showMain());
      if (!servers.length) list.appendChild(el('div', 'empty', 'Добавьте сервер Minecraft PE 1.1.x (адрес и порт, обычно 19132).'));
      servers.forEach((srv, i) => {
        const item = el('div', 'list-item');
        const top = el('div', 'li-title', srv.name || srv.host);
        const status = el('span', 'li-status', 'опрос...');
        top.appendChild(status);
        item.appendChild(top);
        const sub = el('div', 'li-sub', srv.host + ':' + srv.port);
        item.appendChild(sub);
        item.addEventListener('click', () => {
          for (const c of list.children) c.classList.remove('sel');
          item.classList.add('sel');
          selected = i;
          join.disabled = edit.disabled = del.disabled = false;
        });
        item.addEventListener('dblclick', () => this.app.connect(srv));
        list.appendChild(item);
        MC.pingServer(st.relay, srv.host, srv.port).then((info) => {
          status.textContent = info.online + '/' + info.max + ' · ' + info.ping + ' мс';
          sub.textContent = '';
          sub.appendChild(MC.formatted(info.name));
          sub.appendChild(document.createTextNode(' · v' + info.version));
          if (info.protocol !== MC.McpeClient.PROTOCOL) {
            status.textContent += ' · несовместим (протокол ' + info.protocol + ')';
            status.classList.add('bad');
          }
        }).catch((e) => {
          status.textContent = e.message;
          status.classList.add('bad');
        });
      });
    }

    showEditServer(index) {
      const servers = MC.Storage.loadServers();
      const srv = index >= 0 ? servers[index] : { name: 'Сервер Minecraft', host: '', port: 19132 };
      const box = this.screen('edit', { dirt: true });
      box.appendChild(el('h2', 'title', index >= 0 ? 'Изменить сервер' : 'Добавить сервер'));
      const name = this.field(box, 'Название', srv.name, { maxLength: 40 });
      const host = this.field(box, 'Адрес сервера', srv.host, { placeholder: 'play.example.com или 192.168.1.5' });
      const port = this.field(box, 'Порт', srv.port, { type: 'number' });
      const err = el('div', 'hint bad');
      box.appendChild(err);
      const row = el('div', 'btn-row');
      box.appendChild(row);
      this.button(row, 'Сохранить', () => {
        let h = host.value.trim();
        let p = parseInt(port.value, 10) || 19132;
        const m = h.match(/^(.*):(\d+)$/);
        if (m && h.indexOf(']') < 0 && h.split(':').length === 2) { h = m[1]; p = parseInt(m[2], 10); }
        if (!h) { err.textContent = 'Укажите адрес сервера'; return; }
        if (p < 1 || p > 65535) { err.textContent = 'Порт должен быть от 1 до 65535'; return; }
        const entry = { name: name.value.trim() || h, host: h, port: p };
        if (index >= 0) servers[index] = entry; else servers.push(entry);
        MC.Storage.saveServers(servers);
        this.showServers();
      });
      this.button(row, 'Отмена', () => this.showServers());
    }

    // Настройки по вкладкам, как в Minecraft PE: список прокручивается, «Готово» всегда на экране
    showSettings(back, tab) {
      const st = this.app.settings;
      const box = this.screen('settings', { dirt: true, overlay: !!this.app.game });
      box.appendChild(el('h2', 'title', 'Настройки'));
      const save = () => MC.Storage.saveSettings(st);
      const tabs = el('div', 'btn-row tabs');
      box.appendChild(tabs);
      const body = el('div', 'settings-body');
      box.appendChild(body);
      const current = tab || 'game';
      for (const [id, label] of [['game', 'Игра'], ['controls', 'Управление'], ['video', 'Графика'], ['skin', 'Скин'], ['scripts', 'Скрипты'], ['pvp', 'PvP']]) {
        const b = this.button(tabs, label, () => this.showSettings(back, id), { small: true });
        if (id === current) b.classList.add('sel');
      }
      const check = (label, value, onChange) => {
        const w = el('label', 'mc-check');
        const i = el('input');
        i.type = 'checkbox';
        i.checked = !!value;
        i.addEventListener('change', () => onChange(i.checked));
        w.appendChild(i);
        w.appendChild(document.createTextNode(' ' + label));
        body.appendChild(w);
        return i;
      };
      const select = (label, options, value, onChange) => {
        const w = el('label', 'mc-field');
        w.appendChild(el('span', 'mc-label', label));
        const sel = el('select', 'mc-input');
        for (const [v, t] of options) {
          const o = el('option', null, t);
          o.value = v;
          if (value === v) o.selected = true;
          sel.appendChild(o);
        }
        sel.addEventListener('change', () => onChange(sel.value));
        w.appendChild(sel);
        body.appendChild(w);
        return sel;
      };

      if (current === 'game') {
        const nick = this.field(body, 'Ник (3-16 символов: латиница, цифры, _)', st.nickname, { maxLength: 16 });
        const nickErr = el('div', 'hint bad');
        body.appendChild(nickErr);
        nick.addEventListener('input', () => {
          const v = nick.value;
          if (/^[A-Za-z0-9_ ]{3,16}$/.test(v)) { st.nickname = v; save(); nickErr.textContent = ''; }
          else nickErr.textContent = 'Серверы MCPE принимают только латиницу, цифры, пробел и _ (3-16 символов)';
        });
        if (this.app.game && this.app.game.mode === 'mp') body.appendChild(el('div', 'hint', 'Новый ник и скин сервер увидит после переподключения.'));
        this.slider(body, 'Громкость звука', 0, 1, 0.05, st.volume, (v) => Math.round(v * 100) + '%', (v) => { st.volume = v; save(); this.app.applySettings(); });
        this.folderBlock(body);
      } else if (current === 'controls') {
        select('Сенсорное управление', [['auto', 'Автоматически'], ['on', 'Включено'], ['off', 'Выключено (мышь и клавиатура)']], st.touch,
          (v) => { st.touch = v; save(); this.app.applySettings(); });
        select('Схема кнопок', [['dpad', 'Крестовина (как в Minecraft PE)'], ['joystick', 'Джойстик']], st.controls,
          (v) => { st.controls = v; save(); this.app.applySettings(); });
        this.slider(body, 'Размер кнопок', 0.6, 1.6, 0.05, st.buttonScale, (v) => Math.round(v * 100) + '%', (v) => { st.buttonScale = v; save(); this.app.applySettings(); });
        this.slider(body, 'Непрозрачность кнопок', 0.2, 1, 0.05, st.buttonOpacity, (v) => Math.round(v * 100) + '%', (v) => { st.buttonOpacity = v; save(); this.app.applySettings(); });
        this.slider(body, 'Чувствительность', 0.2, 3, 0.1, st.sensitivity, (v) => Math.round(v * 100) + '%', (v) => { st.sensitivity = v; save(); });
        check('Инвертировать обзор по вертикали', st.invertY, (v) => { st.invertY = v; save(); });
        check('Автопрыжок (сенсорное управление)', st.autoJump, (v) => { st.autoJump = v; save(); });
        check('Поменять прыжок и присед местами (для PvP)', st.swapJumpSneak, (v) => { st.swapJumpSneak = v; save(); this.app.applySettings(); });
        select('Бег', [['keep', 'Не сбрасывать: начатый бег продолжается, пока идёте вперёд'], ['auto', 'Авто-спринт: движение вперёд — всегда бег'], ['hold', 'Только пока зажат (Ctrl или двойное «вперёд»)']],
          st.sprintMode || (st.autoSprint ? 'auto' : 'keep'), (v) => { st.sprintMode = v; st.autoSprint = v === 'auto'; save(); });
        select('Помощь в прицеливании', [['off', 'Выключена'], ['weak', 'Слабая'], ['normal', 'Обычная'], ['strong', 'Сильная']],
          st.aimAssist === false ? 'off' : st.aimLevel || 'normal', (v) => { st.aimAssist = v !== 'off'; if (v !== 'off') st.aimLevel = v; save(); });
        body.appendChild(el('div', 'hint', 'Крестовина: двойное касание «вверх» — бег, центр — присесть (или прыжок, если поменять местами: тогда палец можно вести с «вперёд» на центр, движение продолжится и будет прыжок). Прыжок справа, двойной прыжок в творческом режиме — полёт. Касание экрана — поставить блок или ударить, удержание — ломать.'));
      } else if (current === 'video') {
        this.slider(body, 'Дальность прорисовки', 2, 16, 1, st.renderDistance, (v) => v + ' чанков', (v) => { st.renderDistance = v; save(); this.app.applySettings(); });
        this.slider(body, 'Поле зрения', 50, 110, 1, st.fov, (v) => v + '°', (v) => { st.fov = v; save(); this.app.applySettings(); });
        select('Вид камеры', [['first', 'От первого лица'], ['back', 'От третьего лица (сзади)'], ['front', 'От третьего лица (спереди)']], st.camera || 'first',
          (v) => { st.camera = v; save(); });
        select('Шейдеры', [['fast', 'Быстро (для слабых устройств)'], ['fancy', 'Красиво: небо, туман, качание листвы и воды'], ['pack', 'Из шейдер-пака (.mcpack)']], st.shaders,
          (v) => { st.shaders = v; save(); this.app.applySettings(); });
        const r = this.app.renderer;
        body.appendChild(el('div', 'hint', r && r.packStatus ? r.packStatus : 'Шейдер-пак не загружен: добавьте .mcpack с папками materials и shaders в «Текстур-паки» и перезапустите игру.'));
        this.slider(body, 'Разрешение рендера', 0.4, 1, 0.05, st.renderScale, (v) => Math.round(v * 100) + '%', (v) => { st.renderScale = v; save(); this.app.applySettings(); });
        this.slider(body, 'Яркость', 0.6, 1.6, 0.05, typeof st.brightness === 'number' ? st.brightness : 1, (v) => Math.round(v * 100) + '%', (v) => { st.brightness = v; save(); this.app.applySettings(); });
        check('Облака', st.clouds, (v) => { st.clouds = v; save(); this.app.applySettings(); });
        body.appendChild(el('div', 'hint', 'На слабом телефоне: шейдеры «Быстро», разрешение 50-70%, дальность 4 чанка.'));
        const packRow = el('div', 'btn-row');
        body.appendChild(packRow);
        this.button(packRow, 'Текстур-паки (.mcpack)', () => this.showPacks(() => this.showSettings(back, 'video')));
      } else if (current === 'scripts') {
        this.scriptsTab(body);
      } else if (current === 'pvp') {
        this.pvpTab(body, check, select, () => this.showSettings(back, 'pvp'));
      } else {
        const skinRow = el('div', 'skin-row');
        const prev = el('img', 'skin-prev');
        const skinBytes = st.skin ? MC.Skin.fromBase64(st.skin) : MC.Skin.defaultSkin();
        prev.src = MC.Skin.facePreview(skinBytes);
        skinRow.appendChild(prev);
        const skinInfo = el('div', 'hint', st.skin ? 'Свой скин' : 'Стандартный скин (Стив)');
        skinRow.appendChild(skinInfo);
        const file = el('input');
        file.type = 'file';
        file.accept = 'image/png';
        file.style.display = 'none';
        const applySkin = () => {
          const g = this.app.game;
          if (g) { g.ownSkin = null; this.app.renderer.dropSkin('self'); }
        };
        file.addEventListener('change', async () => {
          if (!file.files[0]) return;
          try {
            const bytes = await MC.Skin.loadSkinFile(file.files[0]);
            st.skin = MC.Skin.toBase64(bytes);
            save();
            applySkin();
            prev.src = MC.Skin.facePreview(bytes);
            skinInfo.textContent = 'Свой скин загружен';
          } catch (e) {
            skinInfo.textContent = e.message;
          }
        });
        skinRow.appendChild(file);
        body.appendChild(skinRow);
        const row = el('div', 'btn-row');
        body.appendChild(row);
        this.button(row, 'Загрузить скин (PNG)', () => file.click());
        this.button(row, 'Стандартный скин', () => { st.skin = null; save(); applySkin(); prev.src = MC.Skin.facePreview(MC.Skin.defaultSkin()); skinInfo.textContent = 'Стандартный скин (Стив)'; });
        body.appendChild(el('div', 'hint', 'Скин 64x32 или 64x64 пикселя в формате PNG.'));
        // Скины из папки игры (подпапка skins или корень)
        const folderSkins = el('div', 'btn-row');
        body.appendChild(folderSkins);
        const showFolderSkins = () => {
          folderSkins.innerHTML = '';
          for (const f of MC.GameFolder.skins) {
            this.button(folderSkins, f.name.replace(/\.png$/i, ''), async () => {
              try {
                const bytes = await MC.Skin.loadSkinFile(await MC.GameFolder.readFile(f));
                st.skin = MC.Skin.toBase64(bytes);
                save();
                applySkin();
                prev.src = MC.Skin.facePreview(bytes);
                skinInfo.textContent = 'Скин из папки: ' + f.name;
              } catch (e) { skinInfo.textContent = e.message; }
            }, { small: true });
          }
        };
        if (MC.GameFolder.available()) {
          MC.GameFolder.name().then(async (n) => {
            if (!n) return;
            if (!MC.GameFolder.skins.length) { try { await MC.GameFolder.sync(false); } catch (e) { /* папка недоступна */ } }
            showFolderSkins();
          });
        }
      }
      this.button(box, 'Готово', back);
    }

    // Папка игры в хранилище: выбор и импорт новых паков, скриптов и скинов
    folderBlock(body) {
      body.appendChild(el('div', 'mc-label', 'Папка игры'));
      const info = el('div', 'hint');
      body.appendChild(info);
      if (!MC.GameFolder.available()) {
        info.textContent = 'В этом браузере папку выбрать нельзя: она работает в APK и в Chrome/Edge на компьютере.';
        return;
      }
      const showName = async () => {
        const n = await MC.GameFolder.name();
        info.textContent = n ? 'Выбрана папка «' + n + '». Кладите туда .mcpack/.zip (в packs), .js (в scripts), скины .png (в skins) и схемы .schematic (в schematics) — новые файлы добавятся при запуске игры или по кнопке «Обновить».'
          : 'Папка не выбрана. Создайте в хранилище папку, например MinecraftHTML, и выберите её: игра создаст в ней packs, scripts и skins.';
      };
      showName();
      const row = el('div', 'btn-row');
      body.appendChild(row);
      const status = el('div', 'hint');
      this.button(row, 'Выбрать папку', async () => {
        try {
          const ok = await MC.GameFolder.pick();
          if (!ok) { status.textContent = 'Папка не выбрана'; return; }
          await showName();
          const r = await MC.GameFolder.sync(true);
          status.textContent = MC.GameFolder.summary(r) + (r.packs ? ' Перезапустите игру, чтобы применить паки.' : '');
          if (r.scripts && this.app.game) await MC.Scripts.reload(this.app.game);
        } catch (e) { if (e.name !== 'AbortError') status.textContent = 'Ошибка: ' + e.message; }
      });
      this.button(row, 'Обновить', async () => {
        status.textContent = 'Проверяю папку...';
        try {
          const r = await MC.GameFolder.sync(true);
          status.textContent = MC.GameFolder.summary(r) + (r.packs ? ' Перезапустите игру, чтобы применить паки.' : '');
          if (r.scripts && this.app.game) await MC.Scripts.reload(this.app.game);
        } catch (e) { status.textContent = 'Ошибка: ' + e.message; }
      });
      body.appendChild(status);
    }

    // Вкладка «Скрипты»: загрузка .js из файлов, включение и удаление; в запущенной игре перезапускаются сразу
    // Better PvP: интерфейс боя, миникарта и точки маршрута
    pvpTab(body, check, select, reopen) {
      const st = this.app.settings;
      const c = MC.PvP.settings(st);
      const save = () => MC.Storage.saveSettings(st);
      const sub = (t) => body.appendChild(el('div', 'mc-label eb-name', t));
      sub('Бой');
      check('Панель цели: имя, расстояние, здоровье (здоровье — в одиночной игре)', c.targetHud, (v) => { c.targetHud = v; save(); });
      check('Счётчик комбо', c.combo, (v) => { c.combo = v; save(); });
      check('Жёлтый прицел, когда удар будет критическим (в падении)', c.crit, (v) => { c.crit = v; save(); });
      check('Замедление обзора над целью (сенсорное управление)', c.aimSlow, (v) => { c.aimSlow = v; save(); });
      check('Красная рамка при здоровье ≤ 3 сердец', c.lowHp, (v) => { c.lowHp = v; save(); });
      check('Броня и прочность предметов', c.armorHud, (v) => { c.armorHud = v; save(); });
      check('Эффекты с таймерами', c.effects, (v) => { c.effects = v; save(); });
      sub('Миникарта');
      check('Миникарта', c.minimap, (v) => { c.minimap = v; save(); });
      check('Поворачивать по взгляду (иначе север сверху)', c.mapRotate, (v) => { c.mapRotate = v; save(); });
      check('Существа и игроки на карте', c.mapEntities, (v) => { c.mapEntities = v; save(); });
      this.slider(body, 'Размер миникарты', 80, 220, 4, c.mapSize, (v) => v + ' px', (v) => { c.mapSize = v; save(); });
      select('Масштаб (касание карты тоже меняет)', [['1', '1 блок = 1 px'], ['2', '1 блок = 2 px'], ['4', '1 блок = 4 px']], String(c.mapZoom), (v) => { c.mapZoom = Number(v); save(); });
      sub('Точки маршрута');
      check('Показывать точки на карте и в мире', c.waypoints, (v) => { c.waypoints = v; save(); });
      check('Ставить точку на месте смерти', c.deathPoint, (v) => { c.deathPoint = v; save(); });
      const g = this.app.game;
      if (!g || !g.pvp) { body.appendChild(el('div', 'hint', 'Точки маршрута хранятся отдельно для каждого мира и сервера: добавить их можно из игры (пауза → Настройки → PvP или клавиша N).')); return; }
      const pv = g.pvp;
      const nameF = this.field(body, 'Название новой точки', '', { maxLength: 24 });
      this.button(body, 'Добавить точку здесь (' + Math.floor(g.player.x) + ' ' + Math.floor(g.player.y) + ' ' + Math.floor(g.player.z) + ')', () => { pv.addWaypoint(nameF.value.trim()); reopen(); }, { small: true });
      if (!pv.waypoints.length) body.appendChild(el('div', 'hint', 'Точек пока нет.'));
      pv.waypoints.forEach((w, i) => {
        const r = el('div', 'eb-row');
        const n = el('span', 'eb-name', w.name + ' — ' + w.x + ' ' + w.y + ' ' + w.z);
        n.style.color = w.color;
        r.appendChild(n);
        const t = this.button(r, w.on ? 'Видна' : 'Скрыта', () => { w.on = !w.on; pv.saveWaypoints(); reopen(); }, { small: true });
        if (w.on) t.classList.add('on');
        this.button(r, 'Удалить', () => { pv.removeWaypoint(i); reopen(); }, { small: true });
        body.appendChild(r);
      });
    }

    scriptsTab(body) {
      const list = el('div', 'list');
      body.appendChild(list);
      const status = el('div', 'hint');
      const file = el('input');
      file.type = 'file';
      // Без фильтра типов: в Android WebView фильтр «.js» превращается в неверный MIME и файлы не видны
      file.accept = '';
      file.style.display = 'none';
      body.appendChild(file);
      const applyNow = async () => {
        const g = this.app.game;
        if (g && g.ready && !g.stopped) { await MC.Scripts.reload(g); status.textContent = 'Скрипты перезапущены в текущей игре'; }
      };
      const render = async () => {
        list.innerHTML = '';
        let scripts = [];
        try { scripts = await MC.Scripts.list(); } catch (e) { status.textContent = 'Хранилище недоступно: ' + e.message; return; }
        if (!scripts.length) list.appendChild(el('div', 'empty', 'Скриптов нет. Загрузите файл .js — он получит объект mc с API игры.'));
        for (const s of scripts) {
          const row = el('div', 'list-item pack-row');
          const info = el('div', 'craft-info');
          info.appendChild(el('div', 'li-title', s.name));
          info.appendChild(el('div', 'li-sub', (s.size / 1024).toFixed(1) + ' КБ · ' + new Date(s.updated).toLocaleString()));
          const on = el('label', 'mc-check');
          const cb = el('input');
          cb.type = 'checkbox';
          cb.checked = !!s.enabled;
          cb.addEventListener('change', async () => { await MC.Scripts.setEnabled(s.id, cb.checked); await applyNow(); });
          on.appendChild(cb);
          on.appendChild(document.createTextNode(' Включён'));
          info.appendChild(on);
          row.appendChild(info);
          const btns = el('div', 'btn-row');
          this.button(btns, 'Удалить', async () => { await MC.Scripts.remove(s.id); await applyNow(); render(); }, { small: true });
          row.appendChild(btns);
          list.appendChild(row);
        }
      };
      file.addEventListener('change', async () => {
        const files = [...file.files];
        file.value = '';
        const msgs = [];
        for (const f of files) {
          try { msgs.push(await MC.Scripts.addFile(f)); } catch (e) { msgs.push(f.name + ': ' + e.message); }
        }
        status.textContent = msgs.join('; ');
        await applyNow();
        render();
      });
      const row = el('div', 'btn-row');
      body.appendChild(row);
      this.button(row, 'Загрузить скрипт (.js)', () => file.click());
      body.appendChild(status);
      body.appendChild(el('div', 'hint', 'Скрипт работает с полным доступом к игре: загружайте только свои или проверенные файлы. ' +
        'API: mc.on(\'tick\'|\'chat\'|\'message\'|\'blockBreak\'|\'blockPlace\'|\'attack\'|\'stop\', fn), mc.command(имя, fn), mc.print, mc.say, mc.popup, ' +
        'mc.player, mc.world, mc.inventory, mc.entities, mc.setTimeout/setInterval, mc.storage. Подробно — в README.'));
      render();
    }

    // Текстур-паки: список, включение, порядок, добавление .mcpack; применяются после перезапуска
    showPacks(back) {
      const box = this.screen('packs', { dirt: true, overlay: !!this.app.game });
      box.appendChild(el('h2', 'title', 'Текстур-паки'));
      const list = el('div', 'list');
      box.appendChild(list);
      const status = el('div', 'hint');
      box.appendChild(status);
      const file = el('input');
      file.type = 'file';
      // Без фильтра: в Android WebView фильтр «.mcpack» превращается в неверный MIME и файлы не видны
      file.accept = '';
      file.style.display = 'none';
      box.appendChild(file);
      let changed = false;
      const render = async () => {
        list.innerHTML = '';
        let packs = [];
        try { packs = await MC.Packs.list(); } catch (e) { status.textContent = 'Хранилище недоступно: ' + e.message; return; }
        if (!packs.length) list.appendChild(el('div', 'empty', 'Паков нет. Добавьте файл .mcpack (архив с manifest.json и папкой textures).'));
        packs.forEach((p, i) => {
          const row = el('div', 'list-item pack-row');
          const info = el('div', 'craft-info');
          info.appendChild(el('div', 'li-title', p.name + (p.version ? ' ' + p.version : '')));
          info.appendChild(el('div', 'li-sub', (p.description ? p.description + ' · ' : '') + p.textures + ' текстур' + (p.shaders ? ' · шейдеры' : '') + ' · ' + (p.size / 1024 / 1024).toFixed(1) + ' МБ'));
          const on = el('label', 'mc-check');
          const cb = el('input');
          cb.type = 'checkbox';
          cb.checked = !!p.enabled;
          cb.addEventListener('change', async () => { p.enabled = cb.checked; await MC.Packs.update(p); changed = true; status.textContent = 'Изменения применятся после перезапуска'; });
          on.appendChild(cb);
          on.appendChild(document.createTextNode(' Включён'));
          info.appendChild(on);
          row.appendChild(info);
          const btns = el('div', 'btn-row');
          const swap = async (j) => {
            const o = packs[j];
            const t = o.order; o.order = p.order; p.order = t;
            await MC.Packs.update(o); await MC.Packs.update(p);
            changed = true;
            render();
          };
          this.button(btns, '▲', () => swap(i - 1), { small: true, disabled: i === 0 });
          this.button(btns, '▼', () => swap(i + 1), { small: true, disabled: i === packs.length - 1 });
          this.button(btns, 'Удалить', async () => { await MC.Packs.remove(p.id); changed = true; status.textContent = 'Изменения применятся после перезапуска'; render(); }, { small: true });
          row.appendChild(btns);
          list.appendChild(row);
        });
      };
      file.addEventListener('change', async () => {
        if (!file.files[0]) return;
        status.textContent = 'Читаю ' + file.files[0].name + '...';
        try {
          const p = await MC.Packs.addFile(file.files[0]);
          changed = true;
          if (p.shaders) { this.app.settings.shaders = 'pack'; MC.Storage.saveSettings(this.app.settings); }
          status.textContent = 'Добавлен: ' + p.name + ' (' + p.textures + ' текстур' + (p.shaders ? ', шейдеры: ' + p.shaders + ' файлов' : '') + '). Нажмите «Перезапустить»';
        } catch (e) {
          status.textContent = 'Ошибка: ' + e.message;
        }
        file.value = '';
        render();
      });
      box.appendChild(el('div', 'hint', 'Верхний пак в списке накладывается первым, нижние перекрывают его. Поддерживаются блоки, предметы, существа, интерфейс, небо и скин Стива из папки textures, а также GLSL-шейдеры MCPE 1.x (materials + shaders/glsl).'));
      const row = el('div', 'btn-row');
      box.appendChild(row);
      this.button(row, 'Добавить .mcpack', () => file.click());
      this.button(row, 'Перезапустить', () => { if (this.app.game && this.app.game.mode === 'sp') this.app.game.save().finally(() => location.reload()); else location.reload(); });
      this.button(box, 'Готово', () => { if (changed) status.textContent = 'Не забудьте перезапустить игру'; back(); });
      render();
    }

    showConnecting(text, onCancel) {
      this.showPanorama(false);
      let box = this.root.querySelector('.screen-connecting');
      if (!box || this.current !== 'connecting') {
        box = this.screen('connecting', { dirt: true });
        box.appendChild(el('h2', 'title', 'Подключение'));
        box.appendChild(el('div', 'status'));
        this.button(box, 'Отмена', onCancel);
      }
      box.querySelector('.status').textContent = text;
    }

    showMessage(title, text, onOk) {
      this.showPanorama(false);
      const box = this.screen('message', { dirt: true });
      box.appendChild(el('h2', 'title', title));
      const t = el('div', 'status');
      t.appendChild(MC.formatted(text));
      box.appendChild(t);
      this.button(box, 'OK', onOk);
    }

    showPause(game) {
      const box = this.screen('pause', { overlay: true });
      box.appendChild(el('h2', 'title', 'Пауза'));
      this.button(box, 'Продолжить', () => this.app.resume());
      this.button(box, 'Настройки', () => this.showSettings(() => this.showPause(game)));
      this.button(box, game.mode === 'mp' ? 'Отключиться' : 'Сохранить и выйти', () => this.app.quitToTitle());
    }

    showDeath(cause) {
      const box = this.screen('death', { overlay: true });
      box.classList.add('red');
      box.appendChild(el('h2', 'title', 'Вы погибли!'));
      if (cause) box.appendChild(el('div', 'status', cause));
      this.button(box, 'Возродиться', () => this.app.respawn());
      this.button(box, 'Выйти в меню', () => this.app.quitToTitle());
    }

    // Полоска прочности инструмента или брони (data — износ)
    durability(cell, it) {
      const max = MC.Survival.durabilityOf(it.id);
      if (!max || !it.data) return;
      const left = Math.max(0, 1 - it.data / max);
      const bar = el('div', 'dur');
      const fill = el('div', 'dur-fill');
      fill.style.width = Math.round(left * 100) + '%';
      fill.style.background = 'hsl(' + Math.round(left * 120) + ', 90%, 45%)';
      bar.appendChild(fill);
      cell.appendChild(bar);
    }

    // Анимация тотема бессмертия: иконка вылетает в центр экрана, вращается и исчезает
    totemPop() {
      const img = el('img', 'totem-pop');
      img.src = MC.Items.icon(450, 0);
      img.addEventListener('animationend', () => img.remove());
      this.hHurt.parentNode.appendChild(img);
    }

    flashHurt() {
      this.hHurt.classList.remove('on');
      void this.hHurt.offsetWidth;
      this.hHurt.classList.add('on');
    }

    setAir(value) {
      const key = value === null ? 'n' : String(value);
      if (this.airKey === key) return;
      this.airKey = key;
      this.hAir.innerHTML = '';
      if (value === null) return;
      for (let i = 0; i < 10; i++) {
        if (i >= value) break;
        const img = el('img');
        img.src = this.sprites.bubble;
        img.alt = '';
        this.hAir.insertBefore(img, this.hAir.firstChild);
      }
    }

    // ---------- HUD ----------
    buildHud() {
      const h = this.hud;
      h.innerHTML = '';
      this.hCross = el('div', 'crosshair');
      h.appendChild(this.hCross);
      this.hDebug = el('div', 'debug');
      h.appendChild(this.hDebug);
      this.hChat = el('div', 'chat');
      h.appendChild(this.hChat);
      this.hTitle = el('div', 'htitle');
      h.appendChild(this.hTitle);
      this.hSub = el('div', 'hsub');
      h.appendChild(this.hSub);
      this.hPopup = el('div', 'popup');
      h.appendChild(this.hPopup);
      this.hBuild = el('div', 'buildhint');
      h.appendChild(this.hBuild);
      this.buildHintText = '';
      const bottom = el('div', 'bottom');
      h.appendChild(bottom);
      const stats = el('div', 'stats');
      this.hArmor = el('div', 'armor');
      bottom.appendChild(this.hArmor);
      this.hHearts = el('div', 'hearts');
      this.hFood = el('div', 'food');
      stats.appendChild(this.hHearts);
      stats.appendChild(this.hFood);
      this.hAir = el('div', 'air');
      bottom.appendChild(this.hAir);
      bottom.appendChild(stats);
      this.hHurt = el('div', 'hurt');
      h.insertBefore(this.hHurt, h.firstChild);
      this.hBar = el('div', 'hotbar');
      this.hSel = el('div', 'hb-sel');
      this.hBar.appendChild(this.hSel);
      this.hSlots = [];
      for (let i = 0; i < 9; i++) {
        const s = el('div', 'hb-slot');
        s.addEventListener('click', () => this.app.selectHotbar(i));
        s.addEventListener('touchstart', (e) => { e.preventDefault(); this.app.selectHotbar(i); }, { passive: false });
        this.hBar.appendChild(s);
        this.hSlots.push(s);
      }
      bottom.appendChild(this.hBar);
      this.hItemName = el('div', 'itemname');
      h.appendChild(this.hItemName);
      this.hTags = el('div', 'tags');
      h.appendChild(this.hTags);
      this.chatInputWrap = el('form', 'chat-input');
      this.chatInput = el('input');
      this.chatInput.maxLength = 255;
      this.chatInput.autocomplete = 'off';
      this.chatInputWrap.appendChild(this.chatInput);
      const send = el('button', 'mc-btn small', 'Отправить');
      send.type = 'submit';
      this.chatInputWrap.appendChild(send);
      this.chatInputWrap.addEventListener('submit', (e) => {
        e.preventDefault();
        const v = this.chatInput.value.trim();
        this.closeChat();
        if (v) this.app.sendChat(v);
      });
      this.chatInput.addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.preventDefault(); this.closeChat(); } });
      h.appendChild(this.chatInputWrap);
    }

    showHud(v) { this.hud.style.display = v ? 'block' : 'none'; }

    setHotbar(items, selected) {
      for (let i = 0; i < 9; i++) {
        const s = this.hSlots[i];
        const it = items[i];
        const key = it && it.id ? it.id + ':' + it.data + ':' + it.count : '';
        const tool = it && it.id && MC.Survival.isTool(it.id);
        if (s.dataset.key === key) continue;
        s.dataset.key = key;
        s.innerHTML = '';
        if (it && it.id) {
          const img = el('img');
          img.src = MC.Items.icon(it.id, tool || it.data < 0 ? 0 : it.data);
          img.alt = '';
          s.appendChild(img);
          if (it.count > 1) s.appendChild(el('span', 'cnt', String(it.count)));
          this.durability(s, it);
        }
      }
      this.hSel.style.left = 'calc(var(--u) * (' + (selected * 20 - 1) + '))';
    }

    showItemName(text) {
      this.hItemName.textContent = text;
      this.hItemName.classList.remove('fade');
      void this.hItemName.offsetWidth;
      this.hItemName.classList.add('fade');
    }

    setStats(show, health, food, armor) {
      this.hHearts.style.display = show ? 'flex' : 'none';
      this.hFood.style.display = show && food !== null ? 'flex' : 'none';
      this.hArmor.style.display = show && armor > 0 ? 'flex' : 'none';
      if (!show) return;
      const key = health + ':' + food + ':' + armor;
      if (this.statsKey === key) return;
      this.statsKey = key;
      const fill = (root, value, full, half, empty, rtl) => {
        root.innerHTML = '';
        for (let i = 0; i < 10; i++) {
          const v = value - i * 2;
          const img = el('img');
          img.src = v >= 2 ? full : v === 1 ? half : empty;
          img.alt = '';
          if (rtl) root.insertBefore(img, root.firstChild); else root.appendChild(img);
        }
      };
      fill(this.hHearts, Math.max(0, Math.ceil(health)), this.sprites.heartFull, this.sprites.heartHalf, this.sprites.heartEmpty, false);
      if (food !== null) fill(this.hFood, Math.max(0, Math.ceil(food)), this.sprites.foodFull, this.sprites.foodHalf, this.sprites.foodEmpty, true);
      if (armor > 0) fill(this.hArmor, armor, this.sprites.armorFull, this.sprites.armorHalf, this.sprites.armorEmpty, false);
    }

    addChat(text) {
      const line = el('div', 'chat-line');
      line.appendChild(MC.formatted(text));
      line.dataset.t = String(performance.now());
      this.hChat.appendChild(line);
      while (this.hChat.children.length > 60) this.hChat.removeChild(this.hChat.firstChild);
      this.hChat.scrollTop = this.hChat.scrollHeight;
    }

    updateChatFade() {
      const now = performance.now();
      for (const l of this.hChat.children) {
        const age = now - parseFloat(l.dataset.t);
        l.style.opacity = this.chatOpen ? '1' : age > 10000 ? '0' : age > 9000 ? String((10000 - age) / 1000) : '1';
      }
      this.hChat.classList.toggle('open', this.chatOpen);
    }

    openChat(prefix) {
      this.chatOpen = true;
      this.chatInputWrap.style.display = 'flex';
      this.chatInput.value = prefix || '';
      setTimeout(() => this.chatInput.focus(), 0);
    }

    closeChat() {
      this.chatOpen = false;
      this.chatInputWrap.style.display = 'none';
      this.chatInput.blur();
      this.app.resume();
    }

    setTitle(title, sub, ms) {
      if (title !== null) { this.hTitle.textContent = ''; this.hTitle.appendChild(MC.formatted(title)); }
      if (sub !== null) { this.hSub.textContent = ''; this.hSub.appendChild(MC.formatted(sub)); }
      this.titleUntil = performance.now() + (ms || 3500);
    }

    setBuildHint(text) {
      if (text === this.buildHintText) return;
      this.buildHintText = text;
      this.hBuild.textContent = text;
    }

    // ---------- Строительство (Effortless Building) и схемы (Schematica) ----------
    showBuild(game, tab) {
      const eb = game.building, sv = game.schematic;
      const box = this.screen('build', { overlay: true });
      box.classList.add('screen-settings');
      box.appendChild(el('h2', 'title', 'Строительство'));
      const tabs = el('div', 'btn-row tabs');
      box.appendChild(tabs);
      const body = el('div', 'settings-body');
      box.appendChild(body);
      const current = tab || this.buildTab || 'shapes';
      this.buildTab = current;
      for (const [id, label] of [['shapes', 'Фигуры'], ['mods', 'Модификаторы'], ['schem', 'Схемы']]) {
        const b = this.button(tabs, label, () => this.showBuild(game, id), { small: true });
        if (id === current) b.classList.add('sel');
      }
      const redraw = () => { const top = body.scrollTop; this.showBuild(game, current); const nb = this.root.querySelector('.settings-body'); if (nb) nb.scrollTop = top; };
      const row = () => { const r = el('div', 'btn-row eb-row'); body.appendChild(r); return r; };
      const label = (t) => body.appendChild(el('div', 'mc-label', t));
      const toggle = (parent, text, on, fn) => { const b = this.button(parent, text + (on ? ': вкл' : ': выкл'), () => { fn(!on); redraw(); }, { small: true }); if (on) b.classList.add('on'); return b; };
      const num = (parent, text, value, min, max, fn) => {
        const w = el('div', 'eb-num');
        w.appendChild(el('span', null, text));
        this.button(w, '−', () => { fn(Math.max(min, value - 1)); redraw(); }, { small: true });
        w.appendChild(el('span', 'eb-val', String(value)));
        this.button(w, '+', () => { fn(Math.min(max, value + 1)); redraw(); }, { small: true });
        parent.appendChild(w);
      };

      if (current === 'shapes') {
        label('Режим (ставить — «использовать», ломать фигурой — «ломать», другая кнопка отменяет)');
        const grid = el('div', 'eb-grid');
        body.appendChild(grid);
        for (const m of MC.Building.MODES) {
          const b = this.button(grid, m.name, () => { eb.setMode(m.id); redraw(); }, { small: true });
          if (eb.cfg.mode === m.id) b.classList.add('on');
        }
        const mode = eb.mode;
        if (mode.opts) {
          const r = row();
          for (const o of mode.opts) this.button(r, eb.optLabel(o), () => { eb.cycleOpt(o); redraw(); }, { small: true });
        }
        if (eb.cfg.mode === 'copy') {
          const r = row();
          this.button(r, 'Повернуть вставку 90°', () => { eb.rotateClip(); redraw(); }, { small: true, disabled: !eb.clip });
          this.button(r, 'Выделить заново', () => { eb.clip = null; eb.cancel(); redraw(); }, { small: true, disabled: !eb.clip });
          this.button(r, 'Сохранить как схему', async () => {
            const name = 'copy-' + new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');
            try {
              const s = MC.Schematics.fromClip(eb.clip, name);
              await MC.Schematics.store(s);
              const msg = await MC.Schematics.exportFile(s);
              this.setPopup(msg);
            } catch (e) { this.setPopup('§cНе сохранено: ' + e.message); }
            this.buildTab = 'schem';
            redraw();
          }, { small: true, disabled: !eb.clip });
          body.appendChild(el('div', 'hint', eb.clip ? 'В буфере ' + eb.clip.blocks.length + ' блоков' : 'Нажмите «использовать» на двух углах области'));
        }
        const r2 = row();
        toggle(r2, 'Заменять блоки', eb.cfg.replace, (v) => { eb.cfg.replace = v; eb.changed(); });
        this.button(r2, '↶ Отменить', () => eb.undo(), { small: true });
        this.button(r2, '↷ Повторить', () => eb.redo(), { small: true });
        if (game.gamemode === 1) this.slider(body, 'Предел блоков за раз', 100, 50000, 100, eb.cfg.max, (v) => String(v), (v) => { eb.cfg.max = v; eb.changed(); });
        else if (game.mode === 'sp') body.appendChild(el('div', 'hint', 'Выживание: блоки берутся из инвентаря, при ломании выпадают как обычно'));
        if (game.mode === 'mp') {
          this.slider(body, 'Скорость установки на сервере', 2, 20, 1, eb.cfg.netRate, (v) => v + ' бл/с', (v) => { eb.cfg.netRate = v; eb.changed(); });
          body.appendChild(el('div', 'hint', 'Сервер: блоки ставятся обычными пакетами по одному, только в радиусе досягаемости (подходите ближе к фигуре) и только к соседнему блоку. ' +
            (game.gamemode === 1 ? 'Нужный блок кладётся в выбранную ячейку панели.' : 'Выживание: нужные блоки берутся из инвентаря; ломать фигурами и отменять можно только в творческом.') +
            ' Ориентацию ступеней и брёвен задаёт сервер по взгляду. Высокая скорость может не понравиться античиту сервера.'));
          if (eb.net.length) this.button(body, 'Очистить очередь (' + eb.net.length + ' бл.)', () => { eb.clearNet(); this.showBuild(game, current); }, { small: true });
        }
      } else if (current === 'mods') {
        const m = eb.cfg.mirror, a = eb.cfg.array, rd = eb.cfg.radial;
        label('Отражение (центр — ' + m.cx + ' ' + m.cy + ' ' + m.cz + ')');
        let r = row();
        toggle(r, 'Отражение', m.on, (v) => { m.on = v; eb.changed(); });
        for (const ax of ['x', 'y', 'z']) toggle(r, ax.toUpperCase(), m[ax], (v) => { m[ax] = v; eb.changed(); });
        r = row();
        this.button(r, 'Центр — под игроком', () => { this.setPopup('Центр отражения: ' + eb.centerHere('mirror')); redraw(); }, { small: true });
        toggle(r, 'Между блоками', m.half, (v) => { m.half = v; eb.changed(); });
        label('Массив (повторить фигуру со сдвигом)');
        r = row();
        toggle(r, 'Массив', a.on, (v) => { a.on = v; eb.changed(); });
        num(r, 'Копий', a.count, 1, 64, (v) => { a.count = v; eb.changed(); });
        r = row();
        num(r, 'X', a.ox, -64, 64, (v) => { a.ox = v; eb.changed(); });
        num(r, 'Y', a.oy, -64, 64, (v) => { a.oy = v; eb.changed(); });
        num(r, 'Z', a.oz, -64, 64, (v) => { a.oz = v; eb.changed(); });
        label('Радиальное отражение (центр — ' + rd.cx + ' ' + rd.cz + ')');
        r = row();
        toggle(r, 'Радиальное', rd.on, (v) => { rd.on = v; eb.changed(); });
        num(r, 'Частей', rd.slices, 2, 32, (v) => { rd.slices = v; eb.changed(); });
        r = row();
        this.button(r, 'Центр — под игроком', () => { this.setPopup('Центр радиального отражения: ' + eb.centerHere('radial')); redraw(); }, { small: true });
        toggle(r, 'Чередовать', rd.alt, (v) => { rd.alt = v; eb.changed(); });
      } else {
        label('Схемы .schematic (Java Edition до 1.12, MCEdit, Schematica, WorldEdit)');
        const r = row();
        const file = el('input');
        file.type = 'file';
        file.multiple = true;
        file.style.display = 'none';
        file.addEventListener('change', async () => {
          const msgs = [];
          for (const f of file.files) {
            try { const s = await MC.Schematics.addFile(f); msgs.push('«' + s.name + '» ' + s.w + '×' + s.h + '×' + s.l + ', ' + s.count + ' бл.' + (s.skipped ? ' (без аналога в MCPE: ' + s.skipped + ')' : '')); }
            catch (e) { msgs.push(f.name + ': ' + e.message); }
          }
          this.setPopup(msgs.join('; '));
          redraw();
        });
        body.appendChild(file);
        this.button(r, 'Загрузить .schematic', () => file.click(), { small: true });
        if (sv.s) {
          label('Загружена «' + sv.s.name + '» ' + sv.s.w + '×' + sv.s.h + '×' + sv.s.l + ' в ' + sv.pos.x + ' ' + sv.pos.y + ' ' + sv.pos.z);
          let rr = row();
          this.button(rr, 'Сюда (под прицел)', () => {
            const hit = game.player.raycast(64);
            const p = game.player;
            sv.moveTo(hit ? eb.placePos(hit) : { x: Math.floor(p.x), y: Math.floor(p.y), z: Math.floor(p.z) });
            redraw();
          }, { small: true });
          this.button(rr, 'Повернуть 90°', () => { sv.rotate(); redraw(); }, { small: true });
          this.button(rr, 'Убрать', () => { sv.unload(); redraw(); }, { small: true });
          rr = row();
          for (const [t, d] of [['X−', [-1, 0, 0]], ['X+', [1, 0, 0]], ['Y−', [0, -1, 0]], ['Y+', [0, 1, 0]], ['Z−', [0, 0, -1]], ['Z+', [0, 0, 1]]]) this.button(rr, t, () => { sv.move(d[0], d[1], d[2]); redraw(); }, { small: true });
          rr = row();
          this.button(rr, sv.layer < 0 ? 'Слои: все' : 'Слой ' + (sv.layer + 1) + '/' + sv.s.h, () => { sv.setLayer(sv.layer < 0 ? 0 : -1); redraw(); }, { small: true });
          this.button(rr, 'Слой −', () => { sv.setLayer(Math.max(0, sv.layer - 1)); redraw(); }, { small: true, disabled: sv.layer < 0 });
          this.button(rr, 'Слой +', () => { sv.setLayer(sv.layer + 1); redraw(); }, { small: true, disabled: sv.layer < 0 });
          rr = row();
          toggle(rr, 'Принтер', sv.printer, (v) => { sv.printer = v; });
          this.button(rr, 'Построить всё сразу', () => { sv.buildAll(); this.app.resume(); }, { small: true });
          body.appendChild(el('div', 'hint', sv.hint() + '. Принтер сам ставит недостающие блоки рядом с вами' + (game.gamemode === 0 ? ' из инвентаря' : '') + '.'));
        }
        label('Готовые постройки (ставьте на ровное место; «Показать» — голограмма, потом принтер или «Построить всё сразу»)');
        for (const st of MC.Structures.LIST) {
          const line = el('div', 'btn-row eb-row');
          line.appendChild(el('span', 'eb-name', (st.kind === 'trap' ? '⚠ ' : '⌂ ') + MC.Structures.get(st.id).name + ' — ' + st.desc));
          this.button(line, 'Показать', () => { sv.load(MC.Structures.get(st.id)); this.setPopup('«' + MC.Structures.get(st.id).name + '» показана перед вами'); redraw(); }, { small: true });
          this.button(line, 'Построить', () => { sv.load(MC.Structures.get(st.id)); sv.buildAll(); this.app.resume(); }, { small: true });
          body.appendChild(line);
        }
        label('Загруженные схемы');
        MC.Schematics.list().then((list) => {
          if (this.current !== 'build' || this.buildTab !== 'schem') return;
          if (!list.length) { body.appendChild(el('div', 'hint', 'Схем нет. Загрузите файл или положите .schematic в папку игры (schematics) и нажмите «Обновить» в настройках.')); return; }
          for (const s of list) {
            const line = el('div', 'btn-row eb-row');
            line.appendChild(el('span', 'eb-name', s.name + ' · ' + s.w + '×' + s.h + '×' + s.l));
            this.button(line, 'Показать', () => { sv.load(s); this.setPopup('Схема «' + s.name + '» показана перед вами'); redraw(); }, { small: true });
            this.button(line, 'Файл', async () => { try { this.setPopup(await MC.Schematics.exportFile(s)); } catch (e) { this.setPopup('§c' + e.message); } }, { small: true });
            this.button(line, '✕', async () => { await MC.Schematics.remove(s.name); redraw(); }, { small: true });
            body.appendChild(line);
          }
        });
      }
      this.button(box, 'Готово', () => this.app.resume());
    }

    setPopup(text) {
      this.hPopup.textContent = '';
      this.hPopup.appendChild(MC.formatted(text));
      this.popupUntil = performance.now() + 3000;
    }

    tick() {
      const now = performance.now();
      if (this.titleUntil && now > this.titleUntil) { this.hTitle.textContent = ''; this.hSub.textContent = ''; this.titleUntil = 0; }
      if (this.popupUntil && now > this.popupUntil) { this.hPopup.textContent = ''; this.popupUntil = 0; }
      this.updateChatFade();
    }

    setDebug(text) { if (this.hDebug.textContent !== text) this.hDebug.textContent = text; }

    // list: [{key, name, x, y}] в пикселях экрана
    setNametags(list) {
      const seen = new Set();
      for (const t of list) {
        seen.add(t.key);
        let e = this.hTags.querySelector('[data-k="' + t.key + '"]');
        if (!e) {
          e = el('div', 'tag');
          e.dataset.k = t.key;
          e.appendChild(MC.formatted(t.name));
          this.hTags.appendChild(e);
        }
        e.style.transform = 'translate(' + Math.round(t.x) + 'px,' + Math.round(t.y) + 'px) translate(-50%, -100%)';
      }
      for (const e of Array.from(this.hTags.children)) if (!seen.has(e.dataset.k)) e.remove();
    }
  }

  MC.UI = UI;
})();
