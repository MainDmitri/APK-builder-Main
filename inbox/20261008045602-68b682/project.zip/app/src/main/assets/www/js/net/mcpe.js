// Клиент игрового протокола Minecraft PE 1.1.x (протокол 113)
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const { BinaryWriter, BinaryReader } = MC;

  const PROTOCOL = 113;
  const GAME_VERSION = '1.1.5';

  const P = {
    LOGIN: 0x01, PLAY_STATUS: 0x02, SERVER_TO_CLIENT_HANDSHAKE: 0x03, DISCONNECT: 0x05,
    RESOURCE_PACKS_INFO: 0x06, RESOURCE_PACK_STACK: 0x07, RESOURCE_PACK_CLIENT_RESPONSE: 0x08,
    TEXT: 0x09, SET_TIME: 0x0a, START_GAME: 0x0b, ADD_PLAYER: 0x0c, ADD_ENTITY: 0x0d,
    REMOVE_ENTITY: 0x0e, ADD_ITEM_ENTITY: 0x0f, TAKE_ITEM_ENTITY: 0x11, MOVE_ENTITY: 0x12,
    MOVE_PLAYER: 0x13, REMOVE_BLOCK: 0x15, UPDATE_BLOCK: 0x16, LEVEL_SOUND_EVENT: 0x19, LEVEL_EVENT: 0x1a, ENTITY_EVENT: 0x1c,
    MOB_EFFECT: 0x1d, UPDATE_ATTRIBUTES: 0x1e, MOB_EQUIPMENT: 0x1f, MOB_ARMOR_EQUIPMENT: 0x20, INTERACT: 0x21, USE_ITEM: 0x23,
    PLAYER_ACTION: 0x24, SET_ENTITY_MOTION: 0x28, SET_HEALTH: 0x2a, SET_SPAWN_POSITION: 0x2b,
    ANIMATE: 0x2c, RESPAWN: 0x2d, DROP_ITEM: 0x2e, CONTAINER_OPEN: 0x30, CONTAINER_CLOSE: 0x31, CONTAINER_SET_SLOT: 0x32, CONTAINER_SET_DATA: 0x33, CONTAINER_SET_CONTENT: 0x34,
    CRAFTING_DATA: 0x35, CRAFTING_EVENT: 0x36,
    ADVENTURE_SETTINGS: 0x37, FULL_CHUNK_DATA: 0x3a, SET_PLAYER_GAME_TYPE: 0x3e,
    PLAYER_LIST: 0x3f, REQUEST_CHUNK_RADIUS: 0x45, CHUNK_RADIUS_UPDATED: 0x46,
    AVAILABLE_COMMANDS: 0x4e, COMMAND_STEP: 0x4f, TRANSFER: 0x56, SET_TITLE: 0x59
  };

  const PLAYER_ACTION = { START_BREAK: 0, ABORT_BREAK: 1, STOP_BREAK: 2, RESPAWN: 7, JUMP: 8, START_SPRINT: 9, STOP_SPRINT: 10, START_SNEAK: 11, STOP_SNEAK: 12, START_GLIDE: 15, STOP_GLIDE: 16 };

  // ---------- zlib через встроенные CompressionStream / DecompressionStream ----------
  async function streamBytes(stream, data) {
    const writer = stream.writable.getWriter();
    writer.write(data);
    writer.close();
    const chunks = [];
    const reader = stream.readable.getReader();
    let total = 0;
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      chunks.push(value);
      total += value.length;
    }
    const out = new Uint8Array(total);
    let o = 0;
    for (const c of chunks) { out.set(c, o); o += c.length; }
    return out;
  }
  const inflate = (d) => streamBytes(new DecompressionStream('deflate'), d);
  const deflate = (d) => streamBytes(new CompressionStream('deflate'), d);

  // ---------- JWT ES384 для пакета входа ----------
  function b64(bytes) {
    let s = '';
    for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(s);
  }
  const b64url = (bytes) => b64(bytes).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const jsonUrl = (obj) => b64url(MC.utf8.encode(JSON.stringify(obj)));

  async function signJwt(keys, pubB64, payload) {
    const head = jsonUrl({ alg: 'ES384', x5u: pubB64 });
    const body = jsonUrl(payload);
    const sig = new Uint8Array(await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-384' }, keys.privateKey, MC.utf8.encode(head + '.' + body)));
    return head + '.' + body + '.' + b64url(sig);
  }

  // ---------- Предметы (slot) ----------
  function readItem(r) {
    const id = r.varint();
    if (id <= 0) return { id: 0, data: 0, count: 0, nbt: new Uint8Array(0) };
    const aux = r.varint();
    let data = aux >> 8;
    if (data === 0x7fff) data = -1;
    const count = aux & 0xff;
    const nbtLen = r.lshort();
    const nbt = nbtLen > 0 ? r.raw(nbtLen).slice() : new Uint8Array(0);
    const canPlace = r.varint();
    for (let i = 0; i < canPlace; i++) r.string();
    const canDestroy = r.varint();
    for (let i = 0; i < canDestroy; i++) r.string();
    return { id, data, count, nbt };
  }

  function writeItem(w, item) {
    if (!item || item.id === 0) { w.varint(0); return; }
    w.varint(item.id);
    w.varint(((item.data < 0 ? 0x7fff : item.data) & 0x7fff) << 8 | (item.count & 0xff));
    const nbt = item.nbt || new Uint8Array(0);
    w.lshort(nbt.length);
    w.raw(nbt);
    w.varint(0);
    w.varint(0);
  }

  // ---------- Разбор чанка формата 1.1 ----------
  function readChunk(cx, cz, data) {
    const r = new BinaryReader(data);
    const count = r.byte();
    const sections = new Array(16).fill(null);
    for (let i = 0; i < count && i < 16; i++) {
      r.byte();
      const ids = r.raw(4096).slice();
      const packed = r.raw(2048);
      r.raw(2048);
      r.raw(2048);
      const meta = new Uint8Array(4096);
      for (let j = 0; j < 2048; j++) {
        const b = packed[j];
        meta[j << 1] = b & 15;
        meta[(j << 1) | 1] = b >> 4;
      }
      sections[i] = { ids, meta };
    }
    return { cx, cz, sections };
  }

  // ---------- Клиент ----------
  class McpeClient {
    constructor(opts, handler) {
      this.opts = opts;
      this.h = handler;
      this.rak = null;
      this.eid = 0;
      this.closed = false;
      this.recvChain = Promise.resolve();
      this.sendChain = Promise.resolve();
      this.pending = [];
      this.flushScheduled = false;
      this.commands = {};
      this.clientRandomId = Math.floor(Math.random() * 9007199254740991);
    }

    async connect() {
      if (!window.crypto || !crypto.subtle) throw new Error('WebCrypto недоступен: откройте игру через https://, http://localhost или file://');
      if (typeof CompressionStream === 'undefined') throw new Error('Браузер не поддерживает CompressionStream (нужен Chrome/WebView 80+)');
      this.h.onStatus('Подключение к ретранслятору...');
      const t = await MC.RelayTransport.open(this.opts.relayUrl, this.opts.host, this.opts.port);
      this.h.onStatus('Соединение с сервером ' + this.opts.host + ':' + this.opts.port + '...');
      this.rak = new MC.RakNetClient(t);
      this.rak.onconnect = () => this.login().catch((e) => this.fail('Ошибка входа: ' + e.message));
      this.rak.onpacket = (batch) => {
        this.recvChain = this.recvChain.then(() => this.handleBatch(batch)).catch((e) => console.warn('Ошибка пакета', e));
      };
      this.rak.ondisconnect = (reason) => this.fail(reason);
      this.rak.connect();
    }

    fail(reason) {
      if (this.closed) return;
      this.closed = true;
      if (this.rak) this.rak.disconnect();
      this.h.onDisconnect(reason);
    }

    disconnect() {
      if (this.closed) return;
      this.closed = true;
      if (this.rak) this.rak.disconnect();
    }

    // Отправка пакета: все пакеты одного кадра собираются в один сжатый batch
    send(w) {
      if (this.closed || !this.rak) return;
      this.pending.push(w.bytes());
      if (!this.flushScheduled) {
        this.flushScheduled = true;
        Promise.resolve().then(() => this.flushPending());
      }
    }

    flushPending() {
      this.flushScheduled = false;
      const list = this.pending;
      this.pending = [];
      if (list.length === 0) return;
      const w = new BinaryWriter(1024);
      for (const p of list) w.bytearray(p);
      const raw = w.bytes();
      this.sendChain = this.sendChain.then(async () => {
        const z = await deflate(raw);
        if (!this.closed && this.rak) this.rak.sendGamePacket(z);
      }).catch((e) => console.warn('Ошибка сжатия', e));
    }

    pk(id) { return new BinaryWriter(64).byte(id); }

    async login() {
      this.h.onStatus('Вход на сервер...');
      const o = this.opts;
      const keys = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-384' }, true, ['sign', 'verify']);
      const pub = b64(new Uint8Array(await crypto.subtle.exportKey('spki', keys.publicKey)));
      const now = Math.floor(Date.now() / 1000);
      const chainJwt = await signJwt(keys, pub, {
        exp: now + 86400,
        nbf: now - 60,
        iat: now,
        extraData: { displayName: o.username, identity: o.uuid, XUID: '' },
        identityPublicKey: pub,
        certificateAuthority: true
      });
      const clientJwt = await signJwt(keys, pub, {
        ADRole: 0,
        CapeData: '',
        ClientRandomId: this.clientRandomId,
        CurrentInputMode: o.touch ? 2 : 1,
        DefaultInputMode: o.touch ? 2 : 1,
        DeviceModel: 'HTML5 WebGL',
        DeviceOS: 1,
        GameVersion: GAME_VERSION,
        GuiScale: 0,
        LanguageCode: 'ru_RU',
        ServerAddress: o.host + ':' + o.port,
        SkinData: b64(o.skin),
        SkinId: 'Standard_Custom',
        TenantId: '',
        UIProfile: 1
      });
      const chain = MC.utf8.encode(JSON.stringify({ chain: [chainJwt] }));
      const client = MC.utf8.encode(clientJwt);
      const inner = new BinaryWriter(chain.length + client.length + 16);
      inner.lint(chain.length).raw(chain).lint(client.length).raw(client);
      const w = this.pk(P.LOGIN);
      w.int(PROTOCOL).byte(0).bytearray(inner.bytes());
      this.send(w);
    }

    async handleBatch(batch) {
      const data = await inflate(batch);
      const r = new BinaryReader(data);
      while (!r.eof()) {
        const buf = r.bytearray();
        if (buf.length === 0) continue;
        try {
          this.handlePacket(buf[0], new BinaryReader(buf, 1));
        } catch (e) {
          console.warn('Ошибка разбора пакета 0x' + buf[0].toString(16), e);
        }
        if (this.closed) return;
      }
    }

    handlePacket(id, r) {
      const h = this.h;
      switch (id) {
        case P.PLAY_STATUS: {
          const s = r.int();
          if (s === 0) h.onStatus('Загрузка мира...');
          else if (s === 3) h.onSpawn();
          else if (s === 1) this.fail('Ваш клиент устарел для этого сервера (нужен протокол сервера, у нас ' + PROTOCOL + ')');
          else if (s === 2) this.fail('Сервер устарел (у нас протокол ' + PROTOCOL + ')');
          else this.fail('Сервер отказал во входе (код ' + s + ')');
          break;
        }
        case P.SERVER_TO_CLIENT_HANDSHAKE:
          this.fail('Сервер требует шифрование и вход через Xbox Live. Такие серверы не поддерживаются.');
          break;
        case P.DISCONNECT: {
          const hide = r.bool();
          const msg = hide ? 'Отключено сервером' : r.string();
          this.fail(MC.translate(msg));
          break;
        }
        case P.RESOURCE_PACKS_INFO: {
          const w = this.pk(P.RESOURCE_PACK_CLIENT_RESPONSE);
          w.byte(3).lshort(0);
          this.send(w);
          break;
        }
        case P.RESOURCE_PACK_STACK: {
          const w = this.pk(P.RESOURCE_PACK_CLIENT_RESPONSE);
          w.byte(4).lshort(0);
          this.send(w);
          break;
        }
        case P.START_GAME: {
          const uniqueId = r.varlong();
          const runtimeId = r.varlong();
          const playerGamemode = r.varint();
          const pos = r.vec3();
          const yaw = r.lfloat();
          const pitch = r.lfloat();
          const seed = r.varint();
          const dimension = r.varint();
          r.varint();
          const worldGamemode = r.varint();
          const difficulty = r.varint();
          const spawn = r.blockcoords();
          this.eid = runtimeId;
          this.uniqueId = uniqueId;
          h.onStartGame({ eid: runtimeId, gamemode: playerGamemode, worldGamemode, pos, yaw, pitch, seed, dimension, difficulty, spawn });
          const w = this.pk(P.REQUEST_CHUNK_RADIUS);
          w.varint(this.opts.chunkRadius || 8);
          this.send(w);
          break;
        }
        case P.TEXT: {
          const type = r.byte();
          let source = '', message = '', params = [];
          if (type === 1 || type === 3 || type === 6 || type === 7) source = r.string();
          if (type === 2) {
            message = r.string();
            const c = r.uvarint();
            for (let i = 0; i < c; i++) params.push(r.string());
          } else {
            message = r.string();
          }
          h.onText({ type, source, message: type === 2 ? MC.translate(message, params) : message });
          break;
        }
        case P.SET_TIME:
          h.onTime(r.varint());
          break;
        case P.ADD_PLAYER: {
          const uuid = r.raw(16);
          const name = r.string();
          r.varlong();
          const eid = r.varlong();
          const pos = r.vec3();
          r.vec3();
          const pitch = r.lfloat();
          const yaw = r.lfloat();
          r.lfloat();
          const item = readItem(r);
          h.onAddPlayer({ eid, uuid: Array.from(uuid).join(','), name, pos, pitch, yaw, item });
          break;
        }
        case P.ADD_ENTITY: {
          r.varlong();
          const eid = r.varlong();
          const type = r.uvarint();
          const pos = r.vec3();
          r.vec3();
          const pitch = r.lfloat();
          const yaw = r.lfloat();
          h.onAddEntity({ eid, type, pos, pitch, yaw });
          break;
        }
        case P.MOB_ARMOR_EQUIPMENT: {
          const eid = r.varlong();
          const items = [readItem(r), readItem(r), readItem(r), readItem(r)];
          h.onMobArmor(eid, items);
          break;
        }
        case P.ADD_ITEM_ENTITY: {
          r.varlong();
          const eid = r.varlong();
          const item = readItem(r);
          const pos = r.vec3();
          h.onAddItemEntity({ eid, item, pos });
          break;
        }
        case P.REMOVE_ENTITY:
          h.onRemoveEntity(r.varlong());
          break;
        case P.TAKE_ITEM_ENTITY: {
          // Сначала подобранный предмет, затем подобравшее его существо
          const item = r.varlong();
          const picker = r.varlong();
          h.onTakeItem(item, picker);
          break;
        }
        case P.LEVEL_SOUND_EVENT: {
          const sound = r.byte();
          const pos = r.vec3();
          const extra = r.varint();
          h.onLevelSound({ sound, x: pos.x, y: pos.y, z: pos.z, extra });
          break;
        }
        case P.LEVEL_EVENT: {
          const id = r.varint();
          const pos = r.vec3();
          const data = r.varint();
          h.onLevelEvent({ id, x: pos.x, y: pos.y, z: pos.z, data });
          break;
        }
        case P.MOVE_ENTITY: {
          const eid = r.varlong();
          const pos = r.vec3();
          const pitch = r.byte() * 360 / 256;
          const headYaw = r.byte() * 360 / 256;
          const yaw = r.byte() * 360 / 256;
          h.onMoveEntity({ eid, pos, pitch, yaw, headYaw, eye: false });
          break;
        }
        case P.MOVE_PLAYER: {
          const eid = r.varlong();
          const pos = r.vec3();
          const pitch = r.lfloat();
          const yaw = r.lfloat();
          const headYaw = r.lfloat();
          const mode = r.byte();
          if (eid === this.eid) h.onTeleport({ pos, pitch, yaw, mode });
          else h.onMoveEntity({ eid, pos, pitch, yaw, headYaw, eye: true });
          break;
        }
        case P.UPDATE_BLOCK: {
          const c = r.blockcoords();
          const bid = r.uvarint();
          const aux = r.uvarint();
          h.onBlock(c.x, c.y, c.z, bid, aux & 15);
          break;
        }
        case P.ENTITY_EVENT: {
          const eid = r.varlong();
          const ev = r.byte();
          h.onEntityEvent(eid, ev);
          break;
        }
        case P.MOB_EFFECT: {
          const eid = r.varlong();
          const ev = r.byte();
          const id = r.varint();
          const amp = r.varint();
          r.bool();
          const dur = r.varint();
          if (h.onMobEffect) h.onMobEffect({ eid, ev, id, amp, dur });
          break;
        }
        case P.UPDATE_ATTRIBUTES: {
          const eid = r.varlong();
          const count = r.uvarint();
          const attrs = {};
          for (let i = 0; i < count; i++) {
            const min = r.lfloat(), max = r.lfloat(), value = r.lfloat();
            r.lfloat();
            attrs[r.string()] = { min, max, value };
          }
          if (eid === this.eid) h.onAttributes(attrs);
          break;
        }
        case P.SET_ENTITY_MOTION: {
          const eid = r.varlong();
          const m = r.vec3();
          if (eid === this.eid) h.onMotion(m);
          break;
        }
        case P.SET_HEALTH:
          h.onHealth(r.uvarint());
          break;
        case P.SET_SPAWN_POSITION: {
          r.varint();
          h.onSpawnPosition(r.blockcoords());
          break;
        }
        case P.ANIMATE: {
          const action = r.uvarint();
          const eid = r.varlong();
          if (action === 1) h.onSwing(eid);
          break;
        }
        case P.RESPAWN:
          h.onRespawn(r.vec3());
          break;
        case P.CONTAINER_OPEN: {
          const windowId = r.byte();
          const type = r.byte();
          const pos = r.blockcoords();
          h.onContainerOpen(windowId, type, pos);
          break;
        }
        case P.CONTAINER_CLOSE:
          h.onContainerClose(r.byte());
          break;
        case P.CONTAINER_SET_DATA: {
          const windowId = r.byte();
          const property = r.varint();
          const value = r.varint();
          h.onContainerData(windowId, property, value);
          break;
        }
        // Рецепты сервера: нужны для крафта (сервер проверяет рецепт по UUID)
        case P.CRAFTING_DATA: {
          const count = r.uvarint();
          const recipes = [];
          for (let i = 0; i < count && !r.eof(); i++) {
            const type = r.varint();
            if (type === 0) {
              const n = r.uvarint();
              const input = [];
              for (let k = 0; k < n; k++) input.push(readItem(r));
              const m = r.uvarint();
              const output = [];
              for (let k = 0; k < m; k++) output.push(readItem(r));
              recipes.push({ type: 'shapeless', input, out: output[0], uuid: r.raw(16).slice() });
            } else if (type === 1) {
              const w = r.varint(), hh = r.varint();
              const input = [];
              for (let k = 0; k < w * hh; k++) input.push(readItem(r));
              const m = r.uvarint();
              const output = [];
              for (let k = 0; k < m; k++) output.push(readItem(r));
              recipes.push({ type: 'shaped', w, h: hh, input, out: output[0], uuid: r.raw(16).slice() });
            } else if (type === 2) {
              r.varint();
              readItem(r);
            } else if (type === 3) {
              r.varint();
              r.varint();
              readItem(r);
            } else if (type === 4) {
              const n = r.byte();
              for (let k = 0; k < n; k++) {
                r.uvarint();
                const c = r.uvarint();
                for (let j = 0; j < c; j++) { r.uvarint(); r.uvarint(); }
                r.string();
              }
            } else {
              break;
            }
          }
          h.onCraftingData(recipes);
          break;
        }
        case P.CONTAINER_SET_SLOT: {
          const windowId = r.byte();
          const slot = r.varint();
          const hotbarSlot = r.varint();
          const item = readItem(r);
          h.onSlot(windowId, slot, hotbarSlot, item);
          break;
        }
        case P.CONTAINER_SET_CONTENT: {
          const windowId = r.uvarint();
          r.varlong();
          const count = r.uvarint();
          const slots = [];
          for (let i = 0; i < count && !r.eof(); i++) slots.push(readItem(r));
          const hotbar = [];
          if (!r.eof()) {
            const hc = r.uvarint();
            for (let i = 0; i < hc && !r.eof(); i++) hotbar.push(r.varint());
          }
          h.onContent(windowId, slots, hotbar);
          break;
        }
        case P.ADVENTURE_SETTINGS: {
          const flags = r.uvarint();
          h.onAdventure({ worldImmutable: (flags & 1) !== 0, allowFlight: (flags & 64) !== 0, noClip: (flags & 128) !== 0, flying: (flags & 512) !== 0 });
          break;
        }
        case P.FULL_CHUNK_DATA: {
          const cx = r.varint();
          const cz = r.varint();
          h.onChunk(readChunk(cx, cz, r.bytearray()));
          break;
        }
        case P.SET_PLAYER_GAME_TYPE:
          h.onGamemode(r.varint());
          break;
        case P.PLAYER_LIST: {
          const type = r.byte();
          const count = r.uvarint();
          for (let i = 0; i < count; i++) {
            const uuid = Array.from(r.raw(16)).join(',');
            if (type === 0) {
              const eid = r.varlong();
              const name = r.string();
              const skinId = r.string();
              const skin = r.bytearray().slice();
              h.onPlayerList({ add: true, uuid, eid, name, skinId, skin });
            } else {
              h.onPlayerList({ add: false, uuid });
            }
          }
          break;
        }
        case P.CHUNK_RADIUS_UPDATED:
          h.onChunkRadius(r.varint());
          break;
        case P.AVAILABLE_COMMANDS: {
          try {
            this.commands = JSON.parse(r.string()) || {};
          } catch (e) {
            this.commands = {};
          }
          break;
        }
        case P.TRANSFER: {
          const address = r.string();
          const port = r.lshort();
          h.onTransfer(address, port);
          break;
        }
        case P.SET_TITLE: {
          const type = r.varint();
          const text = r.string();
          h.onTitle(type, text);
          break;
        }
        default:
          break;
      }
    }

    // ---------- Исходящие пакеты ----------
    sendMove(x, eyeY, z, yaw, pitch, onGround) {
      const w = this.pk(P.MOVE_PLAYER);
      w.varlong(this.eid).vec3(x, eyeY, z).lfloat(pitch).lfloat(yaw).lfloat(yaw).byte(0).bool(onGround).varlong(0);
      this.send(w);
    }

    sendAction(action, x, y, z, face) {
      const w = this.pk(P.PLAYER_ACTION);
      w.varlong(this.eid).varint(action).blockcoords(x, Math.max(0, y), z).varint(face);
      this.send(w);
    }

    sendRemoveBlock(x, y, z) {
      const w = this.pk(P.REMOVE_BLOCK);
      w.blockcoords(x, y, z);
      this.send(w);
    }

    sendUseItem(x, y, z, face, fx, fy, fz, px, py, pz, slot, item, blockId) {
      const w = this.pk(P.USE_ITEM);
      w.blockcoords(x, Math.max(0, y), z).uvarint(blockId || 0).varint(face).vec3(fx, fy, fz).vec3(px, py, pz).varint(slot);
      writeItem(w, item);
      this.send(w);
    }

    sendEquipment(item, inventorySlot, hotbarSlot) {
      const w = this.pk(P.MOB_EQUIPMENT);
      w.varlong(this.eid);
      writeItem(w, item);
      w.byte(inventorySlot).byte(hotbarSlot).byte(0);
      this.send(w);
    }

    // Событие сущности игрока (9 — съесть предмет в руке)
    sendEntityEvent(event, data) {
      const w = this.pk(P.ENTITY_EVENT);
      w.varlong(this.eid).byte(event).varint(data || 0);
      this.send(w);
    }

    // Звук своего действия для других игроков (так делает официальный клиент)
    sendSoundEvent(sound, x, y, z, extra) {
      const w = this.pk(P.LEVEL_SOUND_EVENT);
      w.byte(sound).vec3(x, y, z).varint(extra || 0).varint(-1).bool(false).bool(false);
      this.send(w);
    }

    // Перенос предметов как в MCPE 1.1: сервер собирает пары ContainerSetSlot в сбалансированную транзакцию
    sendSetSlot(windowId, slot, item, selected) {
      const w = this.pk(P.CONTAINER_SET_SLOT);
      w.byte(windowId).varint(slot).varint(-1);
      writeItem(w, item);
      w.byte(selected || 0);
      this.send(w);
    }

    sendCraftingEvent(windowId, big, uuid, input, output) {
      const w = this.pk(P.CRAFTING_EVENT);
      w.byte(windowId).uvarint(big ? 1 : 0).raw(uuid).uvarint(input.length);
      for (const it of input) writeItem(w, it);
      w.uvarint(output.length);
      for (const it of output) writeItem(w, it);
      this.send(w);
    }

    sendContainerClose(windowId) {
      const w = this.pk(P.CONTAINER_CLOSE);
      w.byte(windowId);
      this.send(w);
    }

    sendDropItem(item) {
      const w = this.pk(P.DROP_ITEM);
      w.byte(0);
      writeItem(w, item);
      this.send(w);
    }

    sendSwing() {
      const w = this.pk(P.ANIMATE);
      w.uvarint(1).varlong(this.eid);
      this.send(w);
    }

    sendInteract(action, target) {
      const w = this.pk(P.INTERACT);
      w.byte(action).varlong(target);
      this.send(w);
    }

    sendChat(message) {
      if (message.startsWith('/')) {
        this.sendCommand(message.slice(1));
        return;
      }
      const w = this.pk(P.TEXT);
      w.byte(1).string(this.opts.username).string(message);
      this.send(w);
    }

    // Команды в 1.1 отправляются пакетом CommandStep с аргументами, разложенными по параметрам перегрузки
    sendCommand(text) {
      const parts = text.trim().split(/\s+/);
      const name = (parts.shift() || '').toLowerCase();
      if (!name) return;
      let def = this.commands[name];
      if (!def) {
        for (const k of Object.keys(this.commands)) {
          const v = this.commands[k].versions && this.commands[k].versions[0];
          if (v && Array.isArray(v.aliases) && v.aliases.indexOf(name) >= 0) { def = this.commands[k]; break; }
        }
      }
      let overload = 'default';
      let args = {};
      const version = def && def.versions && def.versions[0];
      if (version && version.overloads) {
        const names = Object.keys(version.overloads);
        let best = null;
        for (const n of names) {
          const params = ((version.overloads[n].input || {}).parameters) || [];
          const required = params.filter((p) => !p.optional).length;
          const fits = parts.length >= required && (parts.length <= params.length || params.some((p) => p.type === 'rawtext' || p.type === 'message'));
          if (fits && (!best || params.length > best.params.length)) best = { n, params };
        }
        if (!best && names.length) best = { n: names[0], params: ((version.overloads[names[0]].input || {}).parameters) || [] };
        if (best) {
          overload = best.n;
          let i = 0;
          for (let pi = 0; pi < best.params.length && i < parts.length; pi++) {
            const p = best.params[pi];
            if (p.type === 'rawtext' || p.type === 'message' || pi === best.params.length - 1 && p.type === 'string') {
              args[p.name] = parts.slice(i).join(' ');
              i = parts.length;
            } else if (p.type === 'int') {
              args[p.name] = parseInt(parts[i++], 10) || 0;
            } else if (p.type === 'float' || p.type === 'value') {
              args[p.name] = parseFloat(parts[i++]) || 0;
            } else if (p.type === 'blockpos' || p.type === 'position') {
              args[p.name] = { x: parts[i] || '0', y: parts[i + 1] || '0', z: parts[i + 2] || '0' };
              i += 3;
            } else if (p.type === 'target') {
              args[p.name] = { rules: [{ inverted: false, name: 'name', value: parts[i++] }], selector: 'nearestPlayer' };
            } else {
              args[p.name] = parts[i++];
            }
          }
        }
      } else {
        args = parts.length ? { args: parts.join(' ') } : {};
      }
      const w = this.pk(P.COMMAND_STEP);
      w.string(name).string(overload).uvarint(1).uvarint(0).bool(true).uvarlong(BigInt(this.clientRandomId)).string(JSON.stringify(args)).string('null').byte(0).byte(0).byte(0);
      this.send(w);
    }
  }

  MC.McpeClient = McpeClient;
  MC.McpeClient.PROTOCOL = PROTOCOL;
  MC.PLAYER_ACTION = PLAYER_ACTION;
})();
