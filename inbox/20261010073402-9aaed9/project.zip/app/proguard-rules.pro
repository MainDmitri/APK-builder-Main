# Rhino (движок плагинов сервера): классы java.beans/javax нет на Android, они нужны только в неиспользуемых частях
-dontwarn java.beans.**
-dontwarn javax.**
-dontwarn jdk.dynalink.**
-keep class org.mozilla.javascript.** { *; }
-keep class com.mcpehtml.app.server.** { *; }
