package com.mcpehtml.app.server

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.sqrt

class ServerConfig(
    var name: String = "Мой сервер",
    var port: Int = 19132,
    var maxPlayers: Int = 10,
    var seed: Int = 0,
    var guestsBuild: Boolean = true,
    var whitelist: Boolean = false,
    var viewDistance: Int = 6,
    var owner: String = "",
    var gamemode: Int = 0,
    var difficulty: Int = 1,
    var pvp: Boolean = true,
    var plugins: Boolean = true
) {
    companion object {
        fun fromJson(o: JSONObject): ServerConfig {
            val c = ServerConfig()
            c.name = o.optString("name", c.name).take(40).ifBlank { "Мой сервер" }
            c.port = o.optInt("port", 19132).coerceIn(1024, 65535)
            c.maxPlayers = o.optInt("maxPlayers", 10).coerceIn(1, 40)
            val s = o.optString("seed", "")
            c.seed = if (s.isBlank()) 0 else s.toIntOrNull() ?: s.hashCode()
            c.guestsBuild = o.optBoolean("guestsBuild", true)
            c.whitelist = o.optBoolean("whitelist", false)
            c.viewDistance = o.optInt("viewDistance", 6).coerceIn(3, 10)
            c.owner = o.optString("owner", "").trim()
            c.gamemode = o.optInt("gamemode", 0).coerceIn(0, 2)
            c.difficulty = o.optInt("difficulty", 1).coerceIn(0, 3)
            c.pvp = o.optBoolean("pvp", true)
            c.plugins = o.optBoolean("plugins", true)
            return c
        }
    }
}

// Сервер Minecraft PE 1.1 (протокол 113) прямо в приложении: свой мир, выживание и творческий режим, команды, плагины
class MineServer(val cfg: ServerConfig, val dir: File, private val logger: (String) -> Unit) : RakListener, Transport {
    @Volatile var running = false
        private set
    @Volatile var error: String? = null
        private set

    private val inbox = LinkedBlockingQueue<Pair<Peer, ByteArray>>(20000)
    private var socket: DatagramSocket? = null
    private var loop: Thread? = null
    private var reader: Thread? = null
    private val guid = java.util.Random().nextLong()
    val rak = RakServer(guid, this) { motd() }
    lateinit var world: World
        private set

    val players = LinkedHashMap<RakSession, Player>()
    private var nextEid = 1L
    var time = 0
    var ticks = 0
        private set
    private var spawn = doubleArrayOf(0.5, 70.0, 0.5)
    private val ops = HashSet<String>()
    private val builders = HashSet<String>()
    private val bans = HashSet<String>()
    private val allowed = HashSet<String>()
    private val logLines = ArrayDeque<String>()
    private val commands = Commands(this)
    val items = Items(this)
    val containers = Containers(this)
    val plugins = Plugins(this, File(dir, "plugins"))
    val rules = LinkedHashMap<String, Boolean>()
    var difficulty = 1
    private val rnd = java.util.Random()
    @Volatile var tunnelStatus = ""
    // Ники игроков в сети для других потоков (уведомление, экран сервера)
    @Volatile private var online: List<String> = emptyList()
    @Volatile var pluginInfo = "[]"
        private set
    @Volatile private var reloadRequested = false
    private val console = java.util.concurrent.ConcurrentLinkedQueue<String>()
    private var commandsDirty = false

    init {
        for (r in RULES) rules[r] = r != "keepInventory"
        difficulty = cfg.difficulty
        rules["pvp"] = cfg.pvp
    }

    fun log(s: String) {
        synchronized(logLines) {
            logLines.addLast(s)
            while (logLines.size > 300) logLines.removeFirst()
        }
        logger(s)
    }

    fun logs(): List<String> = synchronized(logLines) { logLines.toList() }

    private fun motd(): String {
        val n = cfg.name.replace(";", "\\;")
        return "MCPE;$n;${Pk.PROTOCOL};${Pk.VERSION};${online.size};${cfg.maxPlayers}"
    }

    fun newEid() = nextEid++

    // ---------- Запуск и остановка ----------
    fun start() {
        if (running) return
        dir.mkdirs()
        loadState()
        world = World(File(dir, "world"), Generator(cfg.seed))
        if (!File(dir, "world.json").exists()) {
            spawn = world.gen.findSpawn()
            saveState()
        }
        containers.bind(File(dir, "containers.json"))
        val s = DatagramSocket(null)
        s.reuseAddress = true
        s.broadcast = true
        s.bind(InetSocketAddress(cfg.port))
        s.receiveBufferSize = 1 shl 20
        socket = s
        running = true
        error = null
        reader = Thread({ readLoop(s) }, "mcpe-udp").also { it.isDaemon = true; it.start() }
        loop = Thread({ mainLoop() }, "mcpe-server").also { it.isDaemon = true; it.start() }
        log("Сервер «${cfg.name}» запущен на порту ${cfg.port}, зерно мира ${cfg.seed}")
    }

    fun stop() {
        if (!running) return
        running = false
        loop?.join(4000)
        socket?.close()
        reader?.join(1000)
        log("Сервер остановлен")
    }

    // Перезагрузка плагинов (с экрана сервера): выполняется в потоке сервера
    fun requestReload() { reloadRequested = true }

    // Команда из консоли приложения (другой поток): выполнится на потоке сервера
    fun queueConsole(line: String) { if (line.isNotBlank()) console.offer(line.trim().removePrefix("/")) }

    private fun readLoop(s: DatagramSocket) {
        val buf = ByteArray(2048)
        val peers = HashMap<String, Peer>()
        while (running) {
            try {
                val p = DatagramPacket(buf, buf.size)
                s.receive(p)
                val ip = p.address.hostAddress ?: continue
                val key = "u:$ip:${p.port}"
                val peer = peers.getOrPut(key) { Peer(key, ip, p.port, this) }
                if (peers.size > 5000) peers.clear()
                inbox.offer(peer to p.data.copyOfRange(p.offset, p.offset + p.length))
            } catch (e: Exception) {
                if (running) Thread.sleep(5)
            }
        }
    }

    // Отправка через UDP-сокет сервера
    override fun send(peer: Peer, data: ByteArray) {
        try {
            socket?.send(DatagramPacket(data, data.size, InetSocketAddress(peer.ip, peer.port)))
        } catch (e: Exception) {
        }
    }

    // Датаграмма из туннеля (игроки, пришедшие через VPS)
    fun inject(peer: Peer, data: ByteArray) { inbox.offer(peer to data) }

    private fun loadPlugins() {
        try {
            if (cfg.plugins) plugins.loadAll() else plugins.unloadAll()
        } catch (e: Throwable) {
            // Движок JavaScript недоступен: сервер работает без плагинов
            log("Плагины не загружены: $e")
        }
        pluginInfo = plugins.info().toString()
        commandsChanged()
    }

    private fun mainLoop() {
        var nextTick = System.currentTimeMillis()
        var lastSave = nextTick
        var lastUnload = nextTick
        try {
            loadPlugins()
            while (running) {
                if (reloadRequested) { reloadRequested = false; loadPlugins(); broadcastMessage("§eПлагины перезагружены") }
                while (true) { val line = console.poll() ?: break; try { runConsole(line) } catch (e: Exception) { log("Ошибка команды: $e") } }
                val first = inbox.poll(5, TimeUnit.MILLISECONDS)
                if (first != null) {
                    rak.handle(first.first, first.second)
                    var n = 0
                    while (n++ < 4000) { val e = inbox.poll() ?: break; rak.handle(e.first, e.second) }
                }
                val now = System.currentTimeMillis()
                if (now >= nextTick) {
                    tick()
                    nextTick += 50
                    if (now - nextTick > 1000) nextTick = now + 50
                }
                for (p in players.values) p.flush()
                rak.tick()
                if (now - lastSave > 60000) { lastSave = now; saveAll() }
                if (now - lastUnload > 10000) {
                    lastUnload = now
                    world.unloadUnused { cx, cz -> players.values.any { abs((floor(it.x).toInt() shr 4) - cx) <= it.chunkRadius + 2 && abs((floor(it.z).toInt() shr 4) - cz) <= it.chunkRadius + 2 } }
                }
            }
        } catch (e: Throwable) {
            error = e.toString()
            log("Ошибка сервера: $e")
        } finally {
            try { plugins.unloadAll() } catch (e: Throwable) { }
            for (p in players.values.toList()) p.disconnect("Сервер остановлен")
            for (p in players.values) p.flush()
            rak.tick()
            saveAll()
            running = false
        }
    }

    // ---------- Такт (20 в секунду) ----------
    private fun tick() {
        ticks++
        if (rules["doDaylightCycle"] == true) time++
        online = onlineNames()
        if (ticks % 200 == 0) broadcast { Pk.new(Pk.SET_TIME).varint(time) }
        if (commandsDirty) {
            commandsDirty = false
            for (p in players.values) if (p.loggedIn) p.send(Pk.new(Pk.AVAILABLE_COMMANDS, 4096).string(commands.json(p)).string(""))
        }
        for (p in players.values.toList()) {
            if (!p.loggedIn || !p.radiusSet || p.closed) continue
            if (sendChunks(p, 6) > 0) items.sync(p)
            if (!p.spawned && spawnReady(p)) firstSpawn(p)
        }
        for (p in players.values.toList()) {
            if (!p.spawned) continue
            if (p.moved) {
                p.moved = false
                for (o in players.values) if (o !== p && o.spawned) o.send(movePacket(p, 0))
            }
            survivalTick(p)
            if (p.statsDirty) { p.statsDirty = false; sendStats(p) }
        }
        items.tick()
        containers.tick()
        randomTicks()
        plugins.tick(ticks)
    }

    // ---------- RakNet ----------
    override fun onOpen(s: RakSession) {
        if (bans.contains("ip:" + s.peer.ip)) { s.close("Бан", true); return }
        players[s] = Player(this, s, newEid())
    }

    override fun onGamePacket(s: RakSession, batch: ByteArray) {
        val p = players[s] ?: return
        val data = try { Zlib.inflate(batch) } catch (e: Exception) { return }
        val r = R(data)
        var count = 0
        while (!r.eof() && count++ < 512) {
            val pk = try { r.bytes() } catch (e: Exception) { return }
            if (pk.isEmpty()) continue
            try {
                handle(p, pk)
            } catch (e: Exception) {
                // Неизвестная версия пакета не должна отключать игрока
            }
            if (p.closed) return
        }
    }

    override fun onClose(s: RakSession, reason: String) {
        val p = players[s] ?: return
        removePlayer(p, reason)
    }

    fun removePlayer(p: Player, reason: String) {
        if (p.closed) return
        p.closed = true
        players.remove(p.session)
        if (p.loggedIn) {
            containers.closeFor(p)
            savePlayer(p)
            for (o in players.values) {
                if (p.spawned) o.send(Pk.new(Pk.REMOVE_ENTITY).varlong(p.eid))
                o.send(Pk.new(Pk.PLAYER_LIST).byte(1).uvarint(1).uuid(p.uuidMsb, p.uuidLsb))
            }
            if (p.spawned) {
                val e = plugins.fire("quit", mapOf("player" to p, "reason" to reason, "message" to "§e${p.name} вышел из игры"))
                val msg = e?.optString("message", "") ?: "§e${p.name} вышел из игры"
                if (msg.isNotEmpty()) broadcastMessage(msg)
            }
            log("${p.name} вышел: $reason")
        }
    }

    // ---------- Пакеты ----------
    private fun handle(p: Player, b: ByteArray) {
        val id = b[0].toInt() and 0xff
        val r = R(b, 1)
        if (!p.loggedIn && id != Pk.LOGIN && id != Pk.RESOURCE_PACK_CLIENT_RESPONSE) return
        when (id) {
            Pk.LOGIN -> login(p, r)
            Pk.RESOURCE_PACK_CLIENT_RESPONSE -> {
                when (r.byte()) {
                    3 -> p.send(Pk.new(Pk.RESOURCE_PACK_STACK).bool(false).uvarint(0).uvarint(0))
                    4 -> if (!p.loggedIn) completeLogin(p)
                    1 -> p.disconnect("Нужно принять наборы ресурсов")
                }
            }
            Pk.REQUEST_CHUNK_RADIUS -> {
                p.chunkRadius = r.varint().coerceIn(2, cfg.viewDistance)
                p.send(Pk.new(Pk.CHUNK_RADIUS_UPDATED).varint(p.chunkRadius))
                p.radiusSet = true
            }
            Pk.MOVE_PLAYER -> {
                r.varlong()
                val x = r.lfloat().toDouble(); val y = r.lfloat().toDouble(); val z = r.lfloat().toDouble()
                val pitch = r.lfloat(); r.lfloat(); val yaw = r.lfloat()
                r.byte()
                val ground = if (r.eof()) true else r.bool()
                if (!p.spawned || p.dead || x.isNaN() || y.isNaN() || z.isNaN() || abs(x) > 3.0e7 || abs(z) > 3.0e7) return
                onMove(p, x, y - 1.62, z, yaw, pitch, ground)
            }
            Pk.TEXT -> {
                val type = r.byte()
                if (type != Pk.TEXT_CHAT) return
                r.string()
                val msg = r.string().trim().take(256)
                if (msg.isEmpty()) return
                if (msg.startsWith("/")) { commands.run(p, msg.substring(1)); return }
                chat(p, if (p.op) msg else msg.replace(Regex("§."), ""))
            }
            Pk.COMMAND_STEP -> {
                val name = r.string()
                r.string()
                r.uvarint(); r.uvarint(); r.bool(); r.varlong()
                val argsJson = r.string()
                val args = StringBuilder()
                try {
                    val o = JSONObject(argsJson)
                    if (o.has("args")) args.append(o.get("args").toString())
                    else for (k in o.keys()) { if (args.isNotEmpty()) args.append(' '); args.append(o.get(k).toString()) }
                } catch (e: Exception) {
                }
                commands.run(p, (name + " " + args).trim())
            }
            Pk.USE_ITEM -> {
                val c = r.blockCoords()
                r.uvarint()
                val face = r.varint()
                r.lfloat(); val fy = r.lfloat(); r.lfloat()
                r.lfloat(); r.lfloat(); r.lfloat()
                r.varint()
                val item = Item.read(r)
                if (face < 0 || face > 5) return
                useItem(p, c[0], c[1], c[2], face, fy, item)
            }
            Pk.REMOVE_BLOCK -> {
                val c = r.blockCoords()
                breakBlock(p, c[0], c[1], c[2])
            }
            Pk.PLAYER_ACTION -> {
                r.varlong()
                when (r.varint()) {
                    7 -> if (p.dead) respawn(p) else { val sp = spawnPos(); teleport(p, sp[0], sp[1], sp[2]) }
                    8 -> p.exhaustion += if (p.sprinting) 0.2f else 0.05f
                    9 -> { p.sprinting = true; sendData(p) }
                    10 -> { p.sprinting = false; sendData(p) }
                    11 -> { p.sneaking = true; sendData(p) }
                    12 -> { p.sneaking = false; sendData(p) }
                }
            }
            Pk.ANIMATE -> {
                val action = r.uvarint()
                if (action == 1) for (o in players.values) if (o !== p && o.spawned) o.send(Pk.new(Pk.ANIMATE).uvarint(1).varlong(p.eid))
            }
            Pk.INTERACT -> {
                val action = r.byte()
                val target = r.varlong()
                if (action == 2) attack(p, target)
            }
            Pk.ENTITY_EVENT -> {
                r.varlong()
                if (r.byte() == 9) eat(p)
            }
            Pk.DROP_ITEM -> {
                r.byte()
                dropItem(p, Item.read(r))
            }
            Pk.CRAFTING_EVENT -> {
                r.byte(); r.uvarint()
                craft(p, r.raw(16))
            }
            Pk.MOB_EQUIPMENT -> {
                r.varlong()
                val item = Item.read(r)
                val inv = r.byte()
                val sel = r.byte()
                p.selected = sel
                p.heldSlot = if (inv in 9..44) inv - 9 else sel.coerceIn(0, 8)
                p.held = item
                for (o in players.values) if (o !== p && o.spawned) o.send(equipmentPacket(p))
            }
            Pk.CONTAINER_SET_SLOT -> {
                val window = r.byte()
                val slot = r.varint()
                r.varint()
                val item = Item.read(r)
                if (p.dead) return
                if (window == Pk.WINDOW_INVENTORY && slot in 0..35) {
                    p.inventory[slot] = if (item.id == 0) null else item
                    if (slot == p.heldSlot) p.held = p.inventory[slot] ?: Item.AIR
                } else if (window == Pk.WINDOW_ARMOR && slot in 0..3) {
                    p.armor[slot] = if (item.id == 0) null else item
                    for (o in players.values) if (o !== p && o.spawned) o.send(armorPacket(p))
                } else containers.onSlot(p, window, slot, item)
            }
            Pk.LEVEL_SOUND_EVENT -> {
                // Звуки действий игрока (шаги, установка блока) слышат остальные
                for (o in players.values) if (o !== p && o.spawned) o.send(W(b.size).raw(b))
            }
            Pk.CONTAINER_CLOSE -> {
                val w = r.byte()
                containers.onClose(p, w)
                p.send(Pk.new(Pk.CONTAINER_CLOSE).byte(w))
            }
        }
    }

    private fun chat(p: Player, msg: String) {
        val e = plugins.fire("chat", mapOf("player" to p, "message" to msg))
        if (e != null && e.optBoolean("cancelled")) return
        val text = e?.optString("text", "") ?: ""
        val m = e?.optString("message", msg) ?: msg
        if (text.isNotEmpty()) {
            log(text.replace(Regex("§."), ""))
            broadcast { Pk.new(Pk.TEXT).byte(Pk.TEXT_RAW).string(text) }
        } else {
            log("<${p.name}> $m")
            broadcast { Pk.new(Pk.TEXT).byte(Pk.TEXT_CHAT).string(p.name).string(m) }
        }
    }

    // ---------- Вход ----------
    private fun login(p: Player, r: R) {
        val protocol = r.int()
        if (protocol != Pk.PROTOCOL) {
            p.send(Pk.new(Pk.PLAY_STATUS).int(if (protocol < Pk.PROTOCOL) 1 else 2))
            p.disconnect(if (protocol < Pk.PROTOCOL) "Нужен Minecraft PE 1.1" else "Сервер для Minecraft PE 1.1")
            return
        }
        r.byte()
        val inner = R(r.bytes())
        val chainStr = String(inner.raw(inner.lint()), Charsets.UTF_8)
        val clientJwt = String(inner.raw(inner.lint()), Charsets.UTF_8)
        var name = ""
        var identity = ""
        val chain = JSONObject(chainStr).getJSONArray("chain")
        for (i in 0 until chain.length()) {
            val body = jwtBody(chain.getString(i)) ?: continue
            val extra = body.optJSONObject("extraData") ?: continue
            name = extra.optString("displayName", name)
            identity = extra.optString("identity", identity)
        }
        val client = jwtBody(clientJwt)
        if (client != null) {
            p.skinId = client.optString("SkinId", "Standard_Custom")
            p.skin = B64.decode(client.optString("SkinData", ""))
            if (p.skin.size != 8192 && p.skin.size != 16384) p.skin = ByteArray(8192)
        }
        name = name.trim()
        if (!Regex("^[\\p{L}\\p{N}_ ]{1,16}$").matches(name)) { p.disconnect("Недопустимый ник"); return }
        p.name = name
        val lower = name.lowercase()
        try {
            val u = java.util.UUID.fromString(identity)
            p.uuidMsb = u.mostSignificantBits; p.uuidLsb = u.leastSignificantBits
        } catch (e: Exception) {
            val u = java.util.UUID.nameUUIDFromBytes(("OfflinePlayer:$name").toByteArray())
            p.uuidMsb = u.mostSignificantBits; p.uuidLsb = u.leastSignificantBits
        }
        if (bans.contains(lower)) { p.disconnect("Вы забанены на этом сервере"); return }
        p.op = p.isLocal || ops.contains(lower)
        if (cfg.whitelist && !p.op && !allowed.contains(lower)) { p.disconnect("Вас нет в белом списке сервера"); return }
        if (players.values.count { it.loggedIn } >= cfg.maxPlayers && !p.op) { p.disconnect("Сервер заполнен"); return }
        for (o in players.values.toList()) if (o !== p && o.loggedIn && o.name.equals(name, true)) o.disconnect("Вход с другого устройства")
        p.send(Pk.new(Pk.PLAY_STATUS).int(0))
        p.send(Pk.new(Pk.RESOURCE_PACKS_INFO).bool(false).lshort(0).lshort(0))
    }

    private fun jwtBody(jwt: String): JSONObject? {
        val parts = jwt.split('.')
        if (parts.size < 2) return null
        return try { JSONObject(String(B64.decode(parts[1]), Charsets.UTF_8)) } catch (e: Exception) { null }
    }

    private fun completeLogin(p: Player) {
        val lower = p.name.lowercase()
        p.canBuild = cfg.guestsBuild || p.op || builders.contains(lower)
        p.x = spawn[0]; p.y = spawn[1]; p.z = spawn[2]
        val f = File(dir, "players/$lower.json")
        if (f.exists()) try { p.fromJson(JSONObject(f.readText())) } catch (e: Exception) { }
        p.gamemode = if (p.savedGamemode >= 0) p.savedGamemode else cfg.gamemode
        if (!p.canBuild && p.gamemode != 3) p.gamemode = 2
        if (p.gamemode == 1) p.health = 20f
        p.lastX = p.x; p.lastZ = p.z
        world.chunk(floor(p.x).toInt() shr 4, floor(p.z).toInt() shr 4)
        p.loggedIn = true

        val sg = Pk.new(Pk.START_GAME, 256)
        sg.varlong(p.eid).varlong(p.eid).varint(netGamemode(p))
        sg.vec3(p.x.toFloat(), p.y.toFloat(), p.z.toFloat()).lfloat(p.yaw).lfloat(p.pitch)
        sg.varint(cfg.seed).varint(0).varint(1).varint(cfg.gamemode).varint(difficulty)
        sg.blockCoords(floor(spawn[0]).toInt(), floor(spawn[1]).toInt(), floor(spawn[2]).toInt())
        sg.bool(true).varint(-1).bool(false).lfloat(0f).lfloat(0f).bool(true).bool(false)
        sg.uvarint(0).string("").string(cfg.name).string("").bool(false).llong(time.toLong())
        p.send(sg)
        p.send(Pk.new(Pk.SET_TIME).varint(time))
        sendStats(p)
        p.send(dataPacket(p))
        val sp = p.bedSpawn ?: spawn
        p.send(Pk.new(Pk.SET_SPAWN_POSITION).varint(1).blockCoords(floor(sp[0]).toInt(), floor(sp[1]).toInt(), floor(sp[2]).toInt()).bool(false))
        p.send(Pk.new(Pk.SET_DIFFICULTY).uvarint(difficulty))
        sendAdventure(p)
        sendCreative(p)
        sendInventory(p)
        p.send(W(Survival.craftingPacket.size).raw(Survival.craftingPacket))
        p.send(Pk.new(Pk.AVAILABLE_COMMANDS, 4096).string(commands.json(p)).string(""))
        val pl = Pk.new(Pk.PLAYER_LIST, 20000).byte(0)
        val listed = players.values.filter { it.loggedIn }
        pl.uvarint(listed.size)
        for (o in listed) pl.uuid(o.uuidMsb, o.uuidLsb).varlong(o.eid).string(o.name).string(o.skinId).bytes(o.skin)
        p.send(pl)
        for (o in players.values) if (o !== p && o.loggedIn) {
            o.send(Pk.new(Pk.PLAYER_LIST, 20000).byte(0).uvarint(1).uuid(p.uuidMsb, p.uuidLsb).varlong(p.eid).string(p.name).string(p.skinId).bytes(p.skin))
        }
        log("${p.name} подключился (${p.session.peer.ip})" + if (p.op) " — оператор" else "")
    }

    // В сеть уходит режим клиента: наблюдатель показывается как приключение с полётом сквозь блоки
    private fun netGamemode(p: Player) = if (p.gamemode == 3) 2 else p.gamemode

    private fun sendCreative(p: Player) {
        val cr = Pk.new(Pk.CONTAINER_SET_CONTENT, 8192).uvarint(Pk.WINDOW_CREATIVE).varlong(p.eid)
        if (p.gamemode == 1) {
            cr.uvarint(Blocks.creative.size)
            for (it in Blocks.creative) Item(it[0], it[1], 1).write(cr)
        } else cr.uvarint(0)
        cr.uvarint(0)
        p.send(cr)
    }

    fun sendStats(p: Player) {
        val w = Pk.new(Pk.UPDATE_ATTRIBUTES, 256).varlong(p.eid).uvarint(6)
        fun a(min: Float, max: Float, v: Float, def: Float, n: String) { w.lfloat(min).lfloat(max).lfloat(v).lfloat(def).string(n) }
        a(0f, 20f, maxOf(0f, p.health), 20f, "minecraft:health")
        a(0f, 20f, p.food.toFloat(), 20f, "minecraft:player.hunger")
        a(0f, 20f, p.saturation, 20f, "minecraft:player.saturation")
        a(0f, Float.MAX_VALUE, 0.1f, 0.1f, "minecraft:movement")
        a(0f, 24791f, 0f, 0f, "minecraft:player.level")
        a(0f, 1f, 0f, 0f, "minecraft:player.experience")
        p.send(w)
        p.send(Pk.new(Pk.SET_HEALTH).uvarint(maxOf(0, kotlin.math.ceil(p.health.toDouble()).toInt())))
    }

    fun sendAdventure(p: Player) {
        var flags = 1 shl 5
        if (p.gamemode == 2 || p.gamemode == 3) flags = flags or 1
        if (p.gamemode == 1 || p.gamemode == 3 || p.flyAllowed) flags = flags or (1 shl 6)
        if (p.gamemode == 3) flags = flags or (1 shl 7) or (1 shl 9)
        p.send(Pk.new(Pk.ADVENTURE_SETTINGS).uvarint(flags).uvarint(if (p.op) 1 else 0))
    }

    fun sendInventory(p: Player) {
        val w = Pk.new(Pk.CONTAINER_SET_CONTENT, 1024).uvarint(Pk.WINDOW_INVENTORY).varlong(p.eid).uvarint(36)
        for (it in p.inventory) (it ?: Item.AIR).write(w)
        w.uvarint(9)
        for (i in 0 until 9) w.varint(i + 9)
        p.send(w)
        val a = Pk.new(Pk.CONTAINER_SET_CONTENT, 128).uvarint(Pk.WINDOW_ARMOR).varlong(p.eid).uvarint(4)
        for (it in p.armor) (it ?: Item.AIR).write(a)
        a.uvarint(0)
        p.send(a)
        p.held = p.inventory[p.heldSlot] ?: Item.AIR
    }

    fun sendArmorAll(p: Player) {
        val a = Pk.new(Pk.CONTAINER_SET_CONTENT, 128).uvarint(Pk.WINDOW_ARMOR).varlong(p.eid).uvarint(4)
        for (it in p.armor) (it ?: Item.AIR).write(a)
        a.uvarint(0)
        p.send(a)
        for (o in players.values) if (o !== p && o.spawned) o.send(armorPacket(p))
    }

    private fun dataPacket(p: Player): W {
        val w = Pk.new(Pk.SET_ENTITY_DATA, 96).varlong(p.eid)
        Meta.write(w, p.flags(), p.name)
        return w
    }

    private fun sendData(p: Player) {
        val pk = dataPacket(p).toBytes()
        for (o in players.values) if (o.spawned) o.send(W(pk.size).raw(pk))
    }

    // ---------- Режим игры ----------
    fun setGamemode(p: Player, gm: Int) {
        val was = p.gamemode
        p.gamemode = gm
        if (gm == 1 || gm == 3) { p.health = 20f; p.fallTop = Double.NaN }
        p.send(Pk.new(Pk.SET_PLAYER_GAME_TYPE).varint(netGamemode(p)))
        sendAdventure(p)
        sendCreative(p)
        sendInventory(p)
        p.statsDirty = true
        if (was == 3 || gm == 3) sendData(p)
        p.send(Pk.new(Pk.AVAILABLE_COMMANDS, 4096).string(commands.json(p)).string(""))
    }

    fun setFly(p: Player, v: Boolean) { p.flyAllowed = v; sendAdventure(p) }

    // ---------- Чанки ----------
    private fun ck(cx: Int, cz: Int) = (cx.toLong() shl 32) or (cz.toLong() and 0xffffffffL)

    private fun sendChunks(p: Player, budget: Int): Int {
        val pcx = floor(p.x).toInt() shr 4
        val pcz = floor(p.z).toInt() shr 4
        val r = p.chunkRadius
        // Забываем далёкие чанки, чтобы при возвращении прислать их заново
        p.sentChunks.removeIf { k ->
            val cx = (k shr 32).toInt(); val cz = k.toInt()
            abs(cx - pcx) > r + 1 || abs(cz - pcz) > r + 1
        }
        var sent = 0
        for (d in 0..r) {
            for (dx in -d..d) for (dz in -d..d) {
                if (maxOf(abs(dx), abs(dz)) != d || dx * dx + dz * dz > r * r + r) continue
                val cx = pcx + dx; val cz = pcz + dz
                val k = ck(cx, cz)
                if (p.sentChunks.contains(k)) continue
                val c = world.chunk(cx, cz)
                val data = c.network { x, z -> world.gen.mcpeBiome(x, z) }
                p.send(Pk.new(Pk.FULL_CHUNK_DATA, data.size + 16).varint(cx).varint(cz).bytes(data))
                p.sentChunks.add(k)
                if (++sent >= budget) return sent
            }
        }
        return sent
    }

    private fun spawnReady(p: Player): Boolean {
        val pcx = floor(p.x).toInt() shr 4
        val pcz = floor(p.z).toInt() shr 4
        for (dx in -2..2) for (dz in -2..2) if (!p.sentChunks.contains(ck(pcx + dx, pcz + dz))) return false
        return true
    }

    private fun firstSpawn(p: Player) {
        p.spawned = true
        p.send(Pk.new(Pk.RESPAWN).vec3(p.x.toFloat(), p.y.toFloat(), p.z.toFloat()))
        p.send(Pk.new(Pk.PLAY_STATUS).int(3))
        p.send(movePacket(p, 1))
        p.statsDirty = true
        for (o in players.values) {
            if (o === p || !o.spawned) continue
            p.send(addPlayerPacket(o)); p.send(armorPacket(o))
            o.send(addPlayerPacket(p)); o.send(armorPacket(p))
        }
        items.sync(p)
        val e = plugins.fire("join", mapOf("player" to p, "message" to "§e${p.name} зашёл в игру"))
        val msg = e?.optString("message", "") ?: "§e${p.name} зашёл в игру"
        if (msg.isNotEmpty()) broadcastMessage(msg)
        if (!p.canBuild) p.message("§7Строить могут только игроки, которым разрешил владелец сервера")
        p.message("§aДобро пожаловать на «${cfg.name}»! Команды: /help")
    }

    private fun addPlayerPacket(o: Player): W {
        val w = Pk.new(Pk.ADD_PLAYER, 256)
        w.uuid(o.uuidMsb, o.uuidLsb).string(o.name).varlong(o.eid).varlong(o.eid)
        w.vec3(o.x.toFloat(), o.y.toFloat(), o.z.toFloat()).vec3(0f, 0f, 0f).lfloat(o.pitch).lfloat(o.yaw).lfloat(o.yaw)
        o.held.write(w)
        Meta.write(w, o.flags(), o.name)
        return w
    }

    private fun equipmentPacket(o: Player): W {
        val w = Pk.new(Pk.MOB_EQUIPMENT).varlong(o.eid)
        o.held.write(w)
        return w.byte(o.selected + 9).byte(o.selected).byte(0)
    }

    private fun armorPacket(o: Player): W {
        val w = Pk.new(Pk.MOB_ARMOR_EQUIPMENT).varlong(o.eid)
        for (it in o.armor) (it ?: Item.AIR).write(w)
        return w
    }

    fun movePacket(p: Player, mode: Int): W =
        Pk.new(Pk.MOVE_PLAYER).varlong(p.eid).vec3(p.x.toFloat(), (p.y + 1.62).toFloat(), p.z.toFloat())
            .lfloat(p.pitch).lfloat(p.yaw).lfloat(p.yaw).byte(mode).bool(true).varlong(0)

    fun teleport(p: Player, x: Double, y: Double, z: Double) {
        p.x = x; p.y = y; p.z = z
        p.lastX = x; p.lastZ = z
        p.fallTop = Double.NaN
        p.send(movePacket(p, 1))
        for (o in players.values) if (o !== p && o.spawned) o.send(movePacket(p, 0))
    }

    // ---------- Движение, падение, голод ----------
    private fun onMove(p: Player, x: Double, y: Double, z: Double, yaw: Float, pitch: Float, ground: Boolean) {
        val dx = x - p.lastX; val dz = z - p.lastZ
        val dist = sqrt(dx * dx + dz * dz)
        if (dist < 10) p.exhaustion += (dist * if (p.sprinting) 0.1 else 0.01).toFloat()
        p.lastX = x; p.lastZ = z
        p.x = x; p.y = y; p.z = z; p.yaw = yaw; p.pitch = pitch
        p.onGround = ground
        p.moved = true
        if (!p.survivalLike || p.flyAllowed) { p.fallTop = Double.NaN; return }
        val feet = world.getId(floor(x).toInt(), floor(y + 0.1).toInt(), floor(z).toInt())
        if (feet in 8..11 || feet == 65 || feet == 106 || feet == 30) { p.fallTop = Double.NaN; return }
        if (!ground) {
            if (p.fallTop.isNaN() || y > p.fallTop) p.fallTop = y
        } else {
            val top = p.fallTop
            p.fallTop = Double.NaN
            if (!top.isNaN() && rules["fallDamage"] == true) {
                val fall = top - y
                if (fall > 3.5) damage(p, floor(fall - 3).toFloat(), "fall", null)
            }
        }
    }

    private fun survivalTick(p: Player) {
        if (p.hurtCooldown > 0) p.hurtCooldown--
        if (!p.alive || !p.survivalLike) return
        if (difficulty == 0) {
            if (p.food < 20) { p.food = 20; p.statsDirty = true }
            if (p.health < 20 && ticks % 20 == 0) heal(p, 1f)
        } else {
            if (p.exhaustion >= 4f) {
                p.exhaustion -= 4f
                if (p.saturation > 0) p.saturation = maxOf(0f, p.saturation - 1f) else p.food = maxOf(0, p.food - 1)
                p.statsDirty = true
            }
            p.regenTimer++
            if (p.regenTimer >= 80) {
                p.regenTimer = 0
                if (p.food >= 18 && p.health < 20 && rules["naturalRegeneration"] == true) { heal(p, 1f); p.exhaustion += 3f }
                else if (p.food == 0) {
                    val min = when (difficulty) { 1 -> 10f; 2 -> 1f; else -> 0f }
                    if (p.health > min) damage(p, 1f, "starve", null)
                }
            }
        }
        p.envTimer++
        if (p.envTimer >= 10) {
            p.envTimer = 0
            if (p.y < -40) { damage(p, 4f, "void", null); return }
            val bx = floor(p.x).toInt(); val bz = floor(p.z).toInt()
            val fy = floor(p.y + 0.1).toInt()
            val feet = world.getId(bx, fy, bz); val head = world.getId(bx, fy + 1, bz)
            if (feet == 10 || feet == 11 || head == 10 || head == 11) damage(p, 4f, "lava", null)
            else if (feet == 51 || head == 51) damage(p, 1f, "fire", null)
            else if (cactusNear(p)) damage(p, 1f, "cactus", null)
        }
    }

    private fun cactusNear(p: Player): Boolean {
        val y = floor(p.y + 0.1).toInt()
        for (dx in -1..1) for (dz in -1..1) {
            val bx = floor(p.x + dx * 0.35).toInt(); val bz = floor(p.z + dz * 0.35).toInt()
            if (world.getId(bx, y, bz) == 81 || (world.getId(bx, y - 1, bz) == 81 && p.y - y < 0.05)) return true
        }
        return false
    }

    fun heal(p: Player, amount: Float) {
        if (p.dead) return
        p.health = minOf(20f, p.health + amount)
        p.statsDirty = true
    }

    fun setHealth(p: Player, h: Float) {
        if (p.dead) return
        if (h <= 0f) { die(p, "kill", null); return }
        p.health = minOf(20f, h)
        p.statsDirty = true
    }

    // ---------- Урон, смерть, возрождение ----------
    fun damage(p: Player, amount0: Float, cause: String, attacker: Player?): Boolean {
        if (!p.alive || amount0 <= 0) return false
        if ((p.gamemode == 1 || p.gamemode == 3) && cause != "void") return false
        if (cause == "attack" && p.hurtCooldown > 0) return false
        var amount = amount0
        val e = plugins.fire("damage", mapOf("player" to p, "amount" to amount.toDouble(), "cause" to cause, "attacker" to attacker))
        if (e != null) {
            if (e.optBoolean("cancelled")) return false
            amount = e.optDouble("amount", amount.toDouble()).toFloat()
            if (amount <= 0) return false
        }
        if (cause == "attack" || cause == "lava" || cause == "fire" || cause == "cactus") {
            val pts = Survival.armorPoints(p.armor)
            if (pts > 0) {
                amount *= (1f - pts * 0.04f)
                wearArmor(p)
            }
        }
        p.health -= amount
        p.hurtCooldown = 10
        p.exhaustion += 0.1f
        p.statsDirty = true
        p.lastAttacker = attacker?.name
        val ev = Pk.new(Pk.ENTITY_EVENT).varlong(p.eid).byte(2).varint(0).toBytes()
        for (o in players.values) if (o.spawned) o.send(W(ev.size).raw(ev))
        if (p.health <= 0f) die(p, cause, attacker)
        return true
    }

    private fun wearArmor(p: Player) {
        var changed = false
        for (i in 0 until 4) {
            val a = p.armor[i] ?: continue
            val max = Survival.durability(a.id)
            if (max <= 0) continue
            p.armor[i] = if (a.data + 1 >= max) null else Item(a.id, a.data + 1, a.count, a.nbt)
            changed = true
        }
        if (changed) sendArmorAll(p)
    }

    fun die(p: Player, cause: String, killer: Player?) {
        if (p.dead || !p.spawned) return
        p.dead = true
        p.health = 0f
        p.fallTop = Double.NaN
        containers.closeFor(p)
        sendStats(p)
        val ev = Pk.new(Pk.ENTITY_EVENT).varlong(p.eid).byte(3).varint(0).toBytes()
        for (o in players.values) if (o.spawned) o.send(W(ev.size).raw(ev))
        val text = when (cause) {
            "attack" -> "${p.name} убит игроком ${killer?.name ?: "?"}"
            "fall" -> "${p.name} разбился"
            "lava" -> "${p.name} решил поплавать в лаве"
            "fire" -> "${p.name} сгорел"
            "cactus" -> "${p.name} исколот кактусом"
            "void" -> "${p.name} выпал из мира"
            "starve" -> "${p.name} умер от голода"
            else -> "${p.name} умер"
        }
        p.lastDeath = doubleArrayOf(p.x, p.y, p.z)
        val e = plugins.fire("death", mapOf("player" to p, "cause" to cause, "killer" to killer, "message" to text, "keepInventory" to (rules["keepInventory"] == true)))
        val msg = e?.optString("message", text) ?: text
        if (msg.isNotEmpty() && rules["showDeathMessages"] == true) broadcastMessage("§c$msg")
        val keep = e?.optBoolean("keepInventory", rules["keepInventory"] == true) ?: (rules["keepInventory"] == true)
        if (!keep && p.gamemode != 1) {
            for (i in 0 until 36) p.inventory[i]?.let { items.spawn(it, p.x, p.y + 1, p.z, (rnd.nextDouble() - 0.5) * 0.4, 0.2, (rnd.nextDouble() - 0.5) * 0.4, 40) }
            for (i in 0 until 4) p.armor[i]?.let { items.spawn(it, p.x, p.y + 1, p.z, (rnd.nextDouble() - 0.5) * 0.4, 0.2, (rnd.nextDouble() - 0.5) * 0.4, 40) }
            java.util.Arrays.fill(p.inventory, null)
            java.util.Arrays.fill(p.armor, null)
            sendInventory(p)
            for (o in players.values) if (o !== p && o.spawned) o.send(armorPacket(p))
        }
        if (msg.isEmpty() || rules["showDeathMessages"] != true) log(text)
    }

    fun respawn(p: Player) {
        if (!p.dead) return
        p.dead = false
        p.health = 20f; p.food = 20; p.saturation = 5f; p.exhaustion = 0f
        val sp = p.bedSpawn?.takeIf { val id = world.getId(floor(it[0]).toInt(), floor(it[1]).toInt() - 1, floor(it[2]).toInt()); id == 26 } ?: spawn
        p.x = sp[0]; p.y = sp[1]; p.z = sp[2]
        p.lastX = p.x; p.lastZ = p.z
        p.send(Pk.new(Pk.RESPAWN).vec3(p.x.toFloat(), p.y.toFloat(), p.z.toFloat()))
        p.send(movePacket(p, 1))
        sendStats(p)
        sendInventory(p)
        for (o in players.values) if (o !== p && o.spawned) {
            o.send(Pk.new(Pk.REMOVE_ENTITY).varlong(p.eid))
            o.send(addPlayerPacket(p)); o.send(armorPacket(p))
        }
        plugins.fire("respawn", mapOf("player" to p))
    }

    private fun attack(p: Player, target: Long) {
        if (!p.alive || p.gamemode == 3) return
        val t = players.values.firstOrNull { it.eid == target && it.spawned } ?: return
        if (t === p || !t.alive) return
        val dx = t.x - p.x; val dz = t.z - p.z; val dy = t.y - p.y
        if (dx * dx + dy * dy + dz * dz > 49) return
        if (rules["pvp"] != true) { p.popup("§cPvP выключено на этом сервере"); return }
        if (plugins.emit("attack", mapOf("player" to p, "target" to t))) return
        val crit = !p.onGround && !p.fallTop.isNaN() && p.y < p.fallTop
        val dmg = Survival.attackDamage(p.held.id).toFloat() + if (crit) 1f else 0f
        if (!damage(t, dmg, "attack", p)) return
        val len = sqrt(dx * dx + dz * dz).coerceAtLeast(0.01)
        t.send(Pk.new(Pk.SET_ENTITY_MOTION).varlong(t.eid).vec3((dx / len * 0.4).toFloat(), 0.36f, (dz / len * 0.4).toFloat()))
        p.exhaustion += 0.1f
        if (p.survivalLike) wearHeld(p, if (Survival.tools[p.held.id]?.type == Survival.T_SWORD) 1 else 2)
    }

    // Износ предмета в руке; сломанный исчезает
    private fun wearHeld(p: Player, n: Int) {
        val it = p.inventory[p.heldSlot] ?: return
        val max = Survival.tools[it.id]?.durability ?: return
        if (it.data + n >= max) {
            p.setSlot(p.heldSlot, null)
            p.send(Pk.new(Pk.LEVEL_SOUND_EVENT).byte(5).vec3(p.x.toFloat(), p.y.toFloat() + 1, p.z.toFloat()).varint(0).varint(-1).bool(false).bool(false))
        } else p.setSlot(p.heldSlot, Item(it.id, it.data + n, it.count, it.nbt))
    }

    // ---------- Еда, выбрасывание, крафт ----------
    private fun eat(p: Player) {
        if (!p.alive) return
        val it = p.inventory[p.heldSlot] ?: return
        val f = Survival.food[it.id] ?: return
        if (p.survivalLike) {
            p.food = minOf(20, p.food + f.hunger)
            p.saturation = minOf(p.food.toFloat(), p.saturation + f.saturation)
            if (it.id == 322 || it.id == 466) heal(p, if (it.id == 466) 8f else 4f)
            p.setSlot(p.heldSlot, if (it.count > 1) Item(it.id, it.data, it.count - 1, it.nbt) else null)
            if (f.remainder > 0 && p.give(Item(f.remainder, 0, 1)) > 0) items.spawn(Item(f.remainder, 0, 1), p.x, p.y + 1, p.z, 0.0, 0.1, 0.0, 20)
            p.statsDirty = true
        }
        val ev = Pk.new(Pk.ENTITY_EVENT).varlong(p.eid).byte(9).varint(0).toBytes()
        for (o in players.values) if (o !== p && o.spawned) o.send(W(ev.size).raw(ev))
    }

    private fun dropItem(p: Player, item: Item) {
        if (!p.alive || item.id == 0 || item.count <= 0) return
        if (p.gamemode != 1) {
            // Сначала из руки, иначе из любой ячейки с таким предметом
            val h = p.inventory[p.heldSlot]
            if (h != null && h.id == item.id && h.data == item.data && h.count >= item.count) {
                p.setSlot(p.heldSlot, if (h.count > item.count) Item(h.id, h.data, h.count - item.count, h.nbt) else null)
            } else if (!p.take(item.id, item.data, item.count)) { sendInventory(p); return }
        }
        if (plugins.emit("drop", mapOf("player" to p, "id" to item.id, "data" to item.data, "count" to item.count))) { p.give(item); return }
        val yaw = Math.toRadians(p.yaw.toDouble()); val pitch = Math.toRadians(p.pitch.toDouble())
        val lx = -sin(yaw) * cos(pitch); val ly = -sin(pitch); val lz = cos(yaw) * cos(pitch)
        items.spawn(Item(item.id, item.data, item.count, item.nbt), p.x + lx * 0.3, p.y + 1.3, p.z + lz * 0.3, lx * 0.3, ly * 0.3 + 0.1, lz * 0.3, 40)
    }

    private fun craft(p: Player, uuid: ByteArray) {
        if (!p.alive) return
        val r = Survival.recipe(uuid)
        if (r == null) { sendInventory(p); return }
        if (plugins.emit("craft", mapOf("player" to p, "id" to r.out.id, "data" to r.out.data, "count" to r.out.count))) { sendInventory(p); return }
        val left = p.give(r.out)
        if (left > 0) items.spawn(Item(r.out.id, r.out.data, left), p.x, p.y + 1, p.z, 0.0, 0.1, 0.0, 20)
    }

    // ---------- Блоки ----------
    private fun inReach(p: Player, x: Int, y: Int, z: Int): Boolean {
        val dx = x + 0.5 - p.x; val dy = y + 0.5 - (p.y + 1.62); val dz = z + 0.5 - p.z
        return sqrt(dx * dx + dy * dy + dz * dz) <= 14.0
    }

    private fun sendBlock(p: Player, x: Int, y: Int, z: Int) {
        if (y < 0 || y > 255) return
        p.send(Pk.new(Pk.UPDATE_BLOCK).blockCoords(x, y, z).uvarint(world.getId(x, y, z)).uvarint((0xb shl 4) or world.getData(x, y, z)))
    }

    fun setBlock(x: Int, y: Int, z: Int, id: Int, data: Int) {
        if (y < 0 || y > 255) return
        world.setBlock(x, y, z, id, data)
        val k = ck(x shr 4, z shr 4)
        val pk = Pk.new(Pk.UPDATE_BLOCK).blockCoords(x, y, z).uvarint(id).uvarint((0xb shl 4) or (data and 15)).toBytes()
        for (o in players.values) if (o.loggedIn && o.sentChunks.contains(k)) o.send(W(pk.size).raw(pk))
    }

    private fun canEdit(p: Player): Boolean = p.canBuild && (p.gamemode == 0 || p.gamemode == 1)

    private fun useItem(p: Player, x: Int, y: Int, z: Int, face: Int, fy: Float, item: Item) {
        if (!p.alive || y < 0 || y > 255 || p.gamemode == 3) return
        val clicked = world.getId(x, y, z)
        val cdata = world.getData(x, y, z)
        if (!p.sneaking) {
            if (plugins.emit("interact", mapOf("player" to p, "x" to x, "y" to y, "z" to z, "id" to clicked, "data" to cdata))) { revert(p, x, y, z, face); return }
            if (containers.open(p, x, y, z, clicked)) return
            if (clicked == 26) { useBed(p, x, y, z); return }
            if (Place.toggle(this, x, y, z, clicked, cdata)) return
        }
        if (!canEdit(p)) { revert(p, x, y, z, face); if (!p.canBuild) p.popup("§cВам нельзя строить на этом сервере"); return }
        if (!inReach(p, x, y, z)) { revert(p, x, y, z, face); return }
        val survival = p.gamemode == 0
        val slot = p.inventory[p.heldSlot]
        if (survival && (slot == null || slot.id != item.id)) { revert(p, x, y, z, face); sendInventory(p); return }
        when {
            item.id in 290..294 -> {
                if (face != 0 && (clicked == 2 || clicked == 3) && world.getId(x, y + 1, z) == 0) {
                    setBlock(x, y, z, 60, 0)
                    if (survival) wearHeld(p, 1)
                } else revert(p, x, y, z, face)
                return
            }
            item.id == 351 && item.data == 15 -> {
                if (boneMeal(x, y, z, clicked, cdata) && survival) consume(p)
                return
            }
            item.id == 259 -> {
                val d = Place.FACE[face]
                val tx = x + d[0]; val ty = y + d[1]; val tz = z + d[2]
                if (world.getId(tx, ty, tz) == 0) { setBlock(tx, ty, tz, 51, 0); if (survival) wearHeld(p, 1) } else revert(p, x, y, z, face)
                return
            }
        }
        val d0 = Place.FACE[face]
        val repl = Blocks.replaceable[clicked]
        val tx = if (repl) x else x + d0[0]
        val ty = if (repl) y else y + d0[1]
        val tz = if (repl) z else z + d0[2]
        if (plugins.emit("blockPlace", mapOf("player" to p, "x" to tx, "y" to ty, "z" to tz, "id" to item.id, "data" to item.data))) { revert(p, x, y, z, face); return }
        if (!Place.place(this, p, x, y, z, face, fy, clicked, cdata, item)) { revert(p, x, y, z, face); return }
        if (survival) {
            if (item.id == 326 || item.id == 327) p.setSlot(p.heldSlot, Item(325, 0, 1)) else consume(p)
        }
    }

    private fun consume(p: Player) {
        val it = p.inventory[p.heldSlot] ?: return
        p.setSlot(p.heldSlot, if (it.count > 1) Item(it.id, it.data, it.count - 1, it.nbt) else null)
    }

    private fun useBed(p: Player, x: Int, y: Int, z: Int) {
        p.bedSpawn = doubleArrayOf(x + 0.5, y + 1.0, z + 0.5)
        p.send(Pk.new(Pk.SET_SPAWN_POSITION).varint(0).blockCoords(x, y + 1, z).bool(false))
        val t = time % 24000
        if (t < 12541 || t > 23458) { p.popup("Точка возрождения установлена. Спать можно только ночью"); return }
        p.bedTime = ticks
        val alive = players.values.filter { it.alive }
        val awake = alive.filter { ticks - it.bedTime > 100 }
        if (awake.isEmpty()) {
            setWorldTime(time - t + 24000)
            broadcastMessage("§eДоброе утро! Ночь пропущена")
        } else {
            broadcastMessage("§e${p.name} лёг спать (${alive.size - awake.size} из ${alive.size})")
        }
    }

    fun setWorldTime(t: Int) {
        time = t
        broadcast { Pk.new(Pk.SET_TIME).varint(time) }
    }

    private fun boneMeal(x: Int, y: Int, z: Int, id: Int, data: Int): Boolean {
        when (id) {
            59, 141, 142, 244, 104, 105 -> { if (data >= 7) return false; setBlock(x, y, z, id, minOf(7, data + 2 + rnd.nextInt(3))); return true }
            6 -> { growTree(x, y, z, data and 7); return true }
            2 -> {
                for (i in 0 until 12) {
                    val ax = x + rnd.nextInt(7) - 3; val az = z + rnd.nextInt(7) - 3
                    if (world.getId(ax, y, az) == 2 && world.getId(ax, y + 1, az) == 0) {
                        if (rnd.nextInt(6) == 0) setBlock(ax, y + 1, az, if (rnd.nextBoolean()) 37 else 38, 0) else setBlock(ax, y + 1, az, 31, 1)
                    }
                }
                return true
            }
        }
        return false
    }

    private fun revert(p: Player, x: Int, y: Int, z: Int, face: Int) {
        sendBlock(p, x, y, z)
        val d = Place.FACE[face]
        sendBlock(p, x + d[0], y + d[1], z + d[2])
        sendBlock(p, x + d[0], y + d[1] + 1, z + d[2])
    }

    private fun breakBlock(p: Player, x: Int, y: Int, z: Int) {
        if (!p.alive || y < 0 || y > 255) return
        val id = world.getId(x, y, z)
        val data = world.getData(x, y, z)
        if (!canEdit(p) || !inReach(p, x, y, z) || (id == 7 && p.gamemode != 1)) {
            sendBlock(p, x, y, z); sendBlock(p, x, y + 1, z); sendBlock(p, x, y - 1, z)
            if (!p.canBuild) p.popup("§cВам нельзя ломать блоки на этом сервере")
            return
        }
        if (id == 0) return
        if (plugins.emit("blockBreak", mapOf("player" to p, "x" to x, "y" to y, "z" to z, "id" to id, "data" to data))) {
            sendBlock(p, x, y, z); sendBlock(p, x, y + 1, z)
            return
        }
        val tool = p.held.id
        if (p.gamemode == 0) {
            items.dropBlock(x, y, z, Survival.drops(id, data, tool))
            p.exhaustion += 0.005f
            if (Survival.hardness[id] > 0 && Survival.tools.containsKey(tool)) wearHeld(p, if (Survival.rightTool(id, tool)) 1 else 2)
        }
        containers.broken(x, y, z)
        Place.removeWithPartner(this, x, y, z, id, data)
        val ev = Pk.new(Pk.LEVEL_EVENT).varint(2001).vec3(x + 0.5f, y + 0.5f, z + 0.5f).varint(id or (data shl 8)).toBytes()
        for (o in players.values) if (o !== p && o.spawned) o.send(W(ev.size).raw(ev))
    }

    // Ломание блока из плагина (лесоруб, жилы): с выпадением предметов, как от инструмента toolId
    fun breakBlockAt(x: Int, y: Int, z: Int, toolId: Int, drop: Boolean) {
        if (y < 0 || y > 255) return
        val id = world.getId(x, y, z)
        if (id == 0 || id == 7) return
        val data = world.getData(x, y, z)
        if (drop) items.dropBlock(x, y, z, Survival.drops(id, data, toolId))
        containers.broken(x, y, z)
        Place.removeWithPartner(this, x, y, z, id, data)
        val ev = Pk.new(Pk.LEVEL_EVENT).varint(2001).vec3(x + 0.5f, y + 0.5f, z + 0.5f).varint(id or (data shl 8)).toBytes()
        for (o in players.values) if (o.spawned) o.send(W(ev.size).raw(ev))
    }

    // ---------- Рост растений ----------
    private fun randomTicks() {
        if (players.isEmpty()) return
        for (c in world.loadedChunks().toList()) {
            val near = players.values.any { it.spawned && abs((floor(it.x).toInt() shr 4) - c.cx) <= 6 && abs((floor(it.z).toInt() shr 4) - c.cz) <= 6 }
            if (!near) continue
            for (i in 0 until 4) {
                val lx = rnd.nextInt(16); val lz = rnd.nextInt(16)
                val top = c.height[(lz shl 4) or lx]
                for (y in top - 1..top + 1) {
                    val id = c.getId(lx, y, lz)
                    if (id == 0) continue
                    val x = c.cx * 16 + lx; val z = c.cz * 16 + lz
                    val data = c.getData(lx, y, lz)
                    when (id) {
                        59, 141, 142, 244 -> if (data < 7 && rnd.nextInt(20) == 0) setBlock(x, y, z, id, data + 1)
                        104, 105 -> if (rnd.nextInt(20) == 0) {
                            if (data < 7) setBlock(x, y, z, id, data + 1) else {
                                val d = Place.FACE[2 + rnd.nextInt(4)]
                                val fx = x + d[0]; val fz = z + d[2]
                                val under = world.getId(fx, y - 1, fz)
                                if (world.getId(fx, y, fz) == 0 && (under == 2 || under == 3 || under == 60)) setBlock(fx, y, fz, if (id == 104) 86 else 103, 0)
                            }
                        }
                        6 -> if (rnd.nextInt(40) == 0) growTree(x, y, z, data and 7)
                        83 -> if (rnd.nextInt(30) == 0 && world.getId(x, y + 1, z) == 0 && world.getId(x, y - 2, z) != 83) setBlock(x, y + 1, z, 83, 0)
                    }
                }
            }
        }
    }

    // Саженец → дерево (дуб, ель, берёза, тропическое, акация, тёмный дуб)
    fun growTree(x: Int, y: Int, z: Int, kind: Int) {
        val logId = if (kind >= 4) 162 else 17
        val logData = if (kind >= 4) kind - 4 else kind and 3
        val leafId = if (kind >= 4) 161 else 18
        val h = 4 + rnd.nextInt(3) + if (kind == 1) 2 else 0
        for (i in 1..h + 1) {
            val b = world.getId(x, y + i, z)
            if (y + i > 255 || (b != 0 && b != 18 && b != 161)) return
        }
        val under = world.getId(x, y - 1, z)
        if (under != 2 && under != 3) return
        setBlock(x, y - 1, z, 3, 0)
        fun leaf(lx: Int, ly: Int, lz: Int) { if (world.getId(lx, ly, lz) == 0) setBlock(lx, ly, lz, leafId, logData) }
        if (kind == 1) {
            var rad = 0
            for (ly in h + 1 downTo 2) {
                for (dx in -rad..rad) for (dz in -rad..rad) if (abs(dx) + abs(dz) <= rad + 1 && !(dx == 0 && dz == 0)) leaf(x + dx, y + ly, z + dz)
                rad = if (rad >= 2) 1 else rad + 1
            }
            leaf(x, y + h + 1, z); leaf(x, y + h + 2, z)
        } else {
            for (ly in h - 3..h) {
                val rad = if (ly >= h - 1) 1 else 2
                for (dx in -rad..rad) for (dz in -rad..rad) {
                    if (rad == 2 && abs(dx) == 2 && abs(dz) == 2 && rnd.nextBoolean()) continue
                    if (rad == 1 && ly == h && abs(dx) == 1 && abs(dz) == 1) continue
                    leaf(x + dx, y + ly, z + dz)
                }
            }
        }
        for (i in 0 until h) setBlock(x, y + i, z, logId, logData)
    }

    // ---------- Чат и рассылка ----------
    fun broadcast(make: () -> W) {
        val pk = make().toBytes()
        for (o in players.values) if (o.loggedIn) o.send(W(pk.size).raw(pk))
    }

    fun broadcastMessage(text: String) {
        log(text.replace(Regex("§."), ""))
        for (line in text.split('\n')) broadcast { Pk.new(Pk.TEXT).byte(Pk.TEXT_RAW).string(line) }
    }

    fun findPlayer(name: String): Player? {
        val n = name.lowercase()
        return players.values.firstOrNull { it.loggedIn && it.name.lowercase() == n }
            ?: players.values.firstOrNull { it.loggedIn && it.name.lowercase().startsWith(n) }
    }

    fun findPlayerExact(name: String): Player? = players.values.firstOrNull { it.loggedIn && it.name.equals(name, true) }

    fun onlineNames(): List<String> = players.values.filter { it.loggedIn }.map { it.name }

    fun onlineCount() = online.size

    // Команда от имени сервера (консоль, плагины) — с правами оператора
    fun runConsole(line: String) { commands.run(null, line) }

    fun commandsChanged() { commandsDirty = true }

    // ---------- Права ----------
    fun setOp(name: String, v: Boolean) { if (v) ops.add(name.lowercase()) else ops.remove(name.lowercase()); saveState(); findPlayer(name)?.let { it.op = v || it.isLocal; refreshBuild(it) } }
    fun setBuilder(name: String, v: Boolean) { if (v) builders.add(name.lowercase()) else builders.remove(name.lowercase()); saveState(); findPlayer(name)?.let { refreshBuild(it) } }
    fun ban(name: String) { bans.add(name.lowercase()); saveState(); findPlayer(name)?.disconnect("Вы забанены на этом сервере") }
    fun unban(name: String) { bans.remove(name.lowercase()); saveState() }
    fun allow(name: String, v: Boolean) { if (v) allowed.add(name.lowercase()) else allowed.remove(name.lowercase()); saveState() }
    fun setWhitelist(v: Boolean) { cfg.whitelist = v; saveState() }
    fun setSpawn(x: Double, y: Double, z: Double) { spawn = doubleArrayOf(x, y, z); saveState() }
    fun spawnPos() = spawn
    fun lists() = mapOf("ops" to ops.toList(), "builders" to builders.toList(), "bans" to bans.toList(), "whitelist" to allowed.toList())
    fun setRule(k: String, v: Boolean) { rules[k] = v; saveState() }
    fun changeDifficulty(d: Int) { difficulty = d; saveState(); broadcast { Pk.new(Pk.SET_DIFFICULTY).uvarint(d) } }

    private fun refreshBuild(p: Player) {
        p.canBuild = cfg.guestsBuild || p.op || builders.contains(p.name.lowercase())
        if (!p.canBuild && (p.gamemode == 0 || p.gamemode == 1)) setGamemode(p, 2)
        else if (p.canBuild && p.gamemode == 2) setGamemode(p, cfg.gamemode)
        else {
            sendAdventure(p)
            p.send(Pk.new(Pk.AVAILABLE_COMMANDS, 4096).string(commands.json(p)).string(""))
        }
    }

    // ---------- Сохранение ----------
    private fun loadState() {
        val f = File(dir, "world.json")
        if (f.exists()) try {
            val o = JSONObject(f.readText())
            if (o.has("seed")) cfg.seed = o.getInt("seed")
            time = o.optInt("time", 0)
            val s = o.optJSONArray("spawn")
            if (s != null && s.length() == 3) spawn = doubleArrayOf(s.getDouble(0), s.getDouble(1), s.getDouble(2))
            fun list(n: String, set: HashSet<String>) { val a = o.optJSONArray(n) ?: return; for (i in 0 until a.length()) set.add(a.getString(i)) }
            list("ops", ops); list("builders", builders); list("bans", bans); list("whitelist", allowed)
            o.optJSONObject("rules")?.let { r -> for (k in r.keys()) if (k in RULES) rules[k] = r.optBoolean(k) }
        } catch (e: Exception) {
            log("Не удалось прочитать world.json: $e")
        }
        // PvP и сложность задаются на экране сервера
        rules["pvp"] = cfg.pvp
        difficulty = cfg.difficulty
    }

    private fun saveState() {
        val o = JSONObject()
        o.put("seed", cfg.seed)
        o.put("time", time)
        o.put("spawn", JSONArray().put(spawn[0]).put(spawn[1]).put(spawn[2]))
        o.put("ops", JSONArray(ops.toList())); o.put("builders", JSONArray(builders.toList()))
        o.put("bans", JSONArray(bans.toList())); o.put("whitelist", JSONArray(allowed.toList()))
        o.put("rules", JSONObject().also { r -> for ((k, v) in rules) r.put(k, v) })
        dir.mkdirs()
        File(dir, "world.json").writeText(o.toString(2))
    }

    private fun savePlayer(p: Player) {
        if (!p.loggedIn) return
        val d = File(dir, "players").also { it.mkdirs() }
        try { File(d, p.name.lowercase() + ".json").writeText(p.toJson().toString()) } catch (e: Exception) { }
    }

    fun saveAll() {
        try {
            if (::world.isInitialized) world.save(true)
            saveState()
            containers.save()
            for (p in players.values) savePlayer(p)
        } catch (e: Exception) {
            log("Ошибка сохранения: $e")
        }
    }

    fun status(): JSONObject {
        val o = JSONObject()
        o.put("running", running)
        o.put("name", cfg.name)
        o.put("port", cfg.port)
        o.put("max", cfg.maxPlayers)
        o.put("players", JSONArray(online))
        o.put("chunks", if (::world.isInitialized) world.loaded() else 0)
        o.put("tunnel", tunnelStatus)
        o.put("plugins", JSONArray(pluginInfo))
        if (error != null) o.put("error", error)
        return o
    }

    companion object {
        val RULES = listOf("keepInventory", "pvp", "fallDamage", "naturalRegeneration", "doDaylightCycle", "showDeathMessages")
    }
}
