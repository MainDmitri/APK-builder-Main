package com.mcpehtml.app.server

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

// Установка блоков с ориентацией, двери/люки/калитки/рычаги, удаление парных блоков (как в одиночной игре клиента)
object Place {
    val FACE = arrayOf(intArrayOf(0, -1, 0), intArrayOf(0, 1, 0), intArrayOf(0, 0, -1), intArrayOf(0, 0, 1), intArrayOf(-1, 0, 0), intArrayOf(1, 0, 0))

    private val DOORS = setOf(64, 193, 194, 195, 196, 197)
    private val GATES = setOf(107, 183, 184, 185, 186, 187)
    private val STAIRS = setOf(53, 67, 108, 109, 114, 128, 134, 135, 136, 156, 163, 164, 180, 203)
    private val CROPS = setOf(59, 141, 142, 244, 104, 105)
    private val PLANTS = setOf(6, 31, 37, 38, 83)

    // Предметы, которые ставятся как блок
    private val ITEM_BLOCK = mapOf(
        324 to 64, 330 to 71, 427 to 193, 428 to 194, 429 to 195, 430 to 196, 431 to 197, 338 to 83,
        354 to 92, 331 to 55, 356 to 93, 404 to 149, 379 to 117, 380 to 118, 390 to 140, 295 to 59, 361 to 104,
        362 to 105, 391 to 141, 392 to 142, 458 to 244, 372 to 115, 410 to 154, 355 to 26, 326 to 9, 327 to 11
    )

    private fun yawDir(yaw: Float): Int = floor((((yaw % 360) + 360) % 360) / 90.0 + 0.5).toInt() and 3

    // Правый клик по блоку: открыть/закрыть дверь, люк, калитку, переключить рычаг, задержку повторителя
    fun toggle(s: MineServer, x: Int, y: Int, z: Int, id: Int, data: Int): Boolean {
        when {
            id in DOORS -> {
                val by = if (data and 8 != 0) y - 1 else y
                if (s.world.getId(x, by, z) != id) return false
                val nd = s.world.getData(x, by, z) xor 4
                s.setBlock(x, by, z, id, nd)
                s.setBlock(x, by + 1, z, id, s.world.getData(x, by + 1, z))
                doorSound(s, x, by, z)
            }
            id == 96 -> { s.setBlock(x, y, z, id, data xor 8); doorSound(s, x, y, z) }
            id in GATES -> { s.setBlock(x, y, z, id, data xor 4); doorSound(s, x, y, z) }
            id == 69 -> s.setBlock(x, y, z, id, data xor 8)
            id == 93 || id == 94 -> s.setBlock(x, y, z, id, (data and 3) or ((((data shr 2) + 1) and 3) shl 2))
            else -> return false
        }
        return true
    }

    // Звук двери (LevelEvent 1003) всем, у кого загружен этот чанк
    private fun doorSound(s: MineServer, x: Int, y: Int, z: Int) {
        val pk = Pk.new(Pk.LEVEL_EVENT).varint(1003).vec3(x + 0.5f, y + 0.5f, z + 0.5f).varint(0).toBytes()
        for (o in s.players.values) if (o.spawned) o.send(W(pk.size).raw(pk))
    }

    fun place(s: MineServer, p: Player, cx: Int, cy: Int, cz: Int, face: Int, fy: Float, clicked: Int, cdata: Int, item: Item): Boolean {
        var id = item.id
        var data = if (item.data < 0) 0 else item.data and 15
        if (id <= 0) return false
        if (id >= 256) {
            id = ITEM_BLOCK[id] ?: return false
            data = 0
            if (id in CROPS && (clicked != 60 || face != 1)) return false
            if (id == 115 && (clicked != 88 || face != 1)) return false
        }
        if (id > 255 || !Blocks.exists[id]) return false
        val w = s.world
        var x = cx; var y = cy; var z = cz
        if (!Blocks.replaceable[clicked]) {
            val d = FACE[face]
            x += d[0]; y += d[1]; z += d[2]
        }
        if (y < 0 || y > 255) return false
        if (!Blocks.replaceable[w.getId(x, y, z)]) return false
        if (id in PLANTS) {
            val ground = w.getId(x, y - 1, z)
            if (ground !in setOf(2, 3, 60, 12) || (id != 83 && ground == 12)) return false
        }
        if (Blocks.solid[id] && intersectsPlayer(s, x, y, z)) return false

        val dir = yawDir(p.yaw)
        val upper = face == 0 || (face > 1 && fy > 0.5f)
        val d = when {
            id == 17 || id == 162 || id == 170 -> (data and 3) or (if (face <= 1) 0 else if (face <= 3) 8 else 4)
            id == 50 || id == 75 || id == 76 -> intArrayOf(5, 5, 4, 3, 2, 1)[face]
            id == 93 || id == 94 -> dir
            id == 33 || id == 29 || id == 137 || id == 188 || id == 189 -> lookFacing(p)
            id == 65 -> if (face >= 2) face else 2
            id == 44 || id == 158 || id == 182 -> (data and 7) or (if (upper) 8 else 0)
            id in STAIRS -> intArrayOf(2, 1, 3, 0)[dir] or (if (upper) 4 else 0)
            id == 86 || id == 91 -> intArrayOf(2, 3, 0, 1)[dir]
            id == 54 || id == 61 || id == 62 || id == 130 || id == 146 || id == 23 || id == 125 -> intArrayOf(2, 5, 3, 4)[dir]
            id in GATES -> dir
            id == 96 || id == 167 -> intArrayOf(2, 1, 3, 0)[dir] or (if (upper) 4 else 0)
            else -> data
        }

        when {
            id in DOORS || id == 71 -> {
                if (y > 254 || !Blocks.replaceable[w.getId(x, y + 1, z)]) return false
                s.setBlock(x, y, z, id, (dir + 1) and 3)
                s.setBlock(x, y + 1, z, id, 8)
            }
            id == 26 -> {
                val off = arrayOf(intArrayOf(0, 1), intArrayOf(-1, 0), intArrayOf(0, -1), intArrayOf(1, 0))[dir]
                if (!Blocks.replaceable[w.getId(x + off[0], y, z + off[1])]) return false
                s.setBlock(x, y, z, 26, dir)
                s.setBlock(x + off[0], y, z + off[1], 26, dir or 8)
            }
            else -> s.setBlock(x, y, z, id, d)
        }
        return true
    }

    // Куда смотрит игрок (для поршня и командного блока): как Player.lookDir() клиента
    private fun lookFacing(p: Player): Int {
        val yaw = Math.toRadians(p.yaw.toDouble()); val pitch = Math.toRadians(p.pitch.toDouble())
        val dx = -sin(yaw) * cos(pitch); val dy = -sin(pitch); val dz = cos(yaw) * cos(pitch)
        val ax = abs(dx); val ay = abs(dy); val az = abs(dz)
        if (ay >= ax && ay >= az) return if (dy < 0) 1 else 0
        if (az >= ax) return if (dz < 0) 3 else 2
        return if (dx < 0) 5 else 4
    }

    // Твёрдый блок нельзя поставить внутрь игрока
    private fun intersectsPlayer(s: MineServer, x: Int, y: Int, z: Int): Boolean {
        for (o in s.players.values) {
            if (!o.spawned) continue
            if (o.x + 0.3 > x && o.x - 0.3 < x + 1 && o.y + 1.8 > y && o.y < y + 1 && o.z + 0.3 > z && o.z - 0.3 < z + 1) return true
        }
        return false
    }

    // Ломание: у дверей и кроватей убирается и вторая половина
    fun removeWithPartner(s: MineServer, x: Int, y: Int, z: Int, id: Int, data: Int) {
        s.setBlock(x, y, z, 0, 0)
        val w = s.world
        when {
            id in DOORS || id == 71 -> {
                val oy = if (data and 8 != 0) y - 1 else y + 1
                if (w.getId(x, oy, z) == id) s.setBlock(x, oy, z, 0, 0)
            }
            id == 26 -> {
                val off = arrayOf(intArrayOf(0, 1), intArrayOf(-1, 0), intArrayOf(0, -1), intArrayOf(1, 0))[data and 3]
                val sign = if (data and 8 != 0) -1 else 1
                val ox = x + off[0] * sign; val oz = z + off[1] * sign
                if (w.getId(ox, y, oz) == 26) s.setBlock(ox, y, oz, 0, 0)
            }
        }
        // Растения и факелы без опоры снизу исчезают
        if (y < 255) {
            val above = w.getId(x, y + 1, z)
            if (above in PLANTS || above in CROPS || above == 50 || above == 55 || above == 78 || above == 175) {
                s.setBlock(x, y + 1, z, 0, 0)
                if (above == 175 && w.getId(x, y + 2, z) == 175) s.setBlock(x, y + 2, z, 0, 0)
            }
        }
    }
}
