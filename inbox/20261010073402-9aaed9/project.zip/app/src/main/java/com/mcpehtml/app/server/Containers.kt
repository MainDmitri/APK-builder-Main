package com.mcpehtml.app.server

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// Сундуки (обычные и двойные), сундук Края и печи: содержимое хранится на сервере в containers.json
class Containers(private val s: MineServer) {
    class Store(val key: String, val x: Int, val y: Int, val z: Int, val items: Array<Item?>) {
        var burn = 0.0      // сколько ещё горит топливо, с
        var burnMax = 0.0
        var cook = 0.0      // ход готовки, с (из 10)
        var lastSent = -1
    }

    class Window(val id: Int, val type: Int, val x: Int, val y: Int, val z: Int, val parts: List<Array<Item?>>, val stores: List<Store>) {
        val size get() = parts.sumOf { it.size }
        fun get(i: Int): Item? { var k = i; for (p in parts) { if (k < p.size) return p[k]; k -= p.size }; return null }
        fun set(i: Int, it: Item?) { var k = i; for (p in parts) { if (k < p.size) { p[k] = it; return }; k -= p.size } }
        fun shows(st: Store) = stores.any { it === st }
    }

    private val stores = HashMap<String, Store>()
    private var nextWindow = 2

    private fun key(x: Int, y: Int, z: Int) = "$x,$y,$z"

    private fun store(x: Int, y: Int, z: Int, size: Int): Store =
        stores.getOrPut(key(x, y, z)) { Store(key(x, y, z), x, y, z, arrayOfNulls(size)) }

    // Правый клик по блоку-хранилищу; true — окно открыто
    fun open(p: Player, x: Int, y: Int, z: Int, id: Int): Boolean {
        val win = when (id) {
            54, 146 -> {
                val main = store(x, y, z, 27)
                val pair = listOf(intArrayOf(-1, 0), intArrayOf(1, 0), intArrayOf(0, -1), intArrayOf(0, 1))
                    .firstOrNull { s.world.getId(x + it[0], y, z + it[1]) == id }
                if (pair != null) {
                    val other = store(x + pair[0], y, z + pair[1], 27)
                    // Первая половина — с меньшей координатой, как у двойного сундука в MCPE
                    val first = if (pair[0] + pair[1] < 0) other else main
                    val second = if (first === main) other else main
                    Window(newId(), 0, x, y, z, listOf(first.items, second.items), listOf(first, second))
                } else Window(newId(), 0, x, y, z, listOf(main.items), listOf(main))
            }
            130 -> Window(newId(), 0, x, y, z, listOf(p.enderChest), emptyList())
            61, 62 -> { val st = store(x, y, z, 3); st.lastSent = -1; Window(newId(), 2, x, y, z, listOf(st.items), listOf(st)) }
            else -> return false
        }
        closeFor(p)
        p.window = win
        p.send(Pk.new(Pk.CONTAINER_OPEN).byte(win.id).byte(win.type).blockCoords(x, y, z).varlong(-1))
        sendContent(p, win)
        if (win.type == 2) sendFurnaceData(p, win.id, win.stores[0])
        if (win.type == 0) chestAnim(x, y, z, true)
        return true
    }

    private fun newId(): Int { val id = nextWindow; nextWindow = if (nextWindow >= 99) 2 else nextWindow + 1; return id }

    private fun sendContent(p: Player, win: Window) {
        val w = Pk.new(Pk.CONTAINER_SET_CONTENT, 1024).uvarint(win.id).varlong(p.eid).uvarint(win.size)
        for (i in 0 until win.size) (win.get(i) ?: Item.AIR).write(w)
        w.uvarint(0)
        p.send(w)
    }

    private fun chestAnim(x: Int, y: Int, z: Int, open: Boolean) {
        val viewers = s.players.values.count { it.window?.let { w -> w.type == 0 && w.x == x && w.y == y && w.z == z } == true }
        if (open && viewers > 1) return
        val pk = Pk.new(Pk.BLOCK_EVENT).blockCoords(x, y, z).varint(1).varint(if (open) 1 else 0).toBytes()
        for (o in s.players.values) if (o.spawned) o.send(W(pk.size).raw(pk))
    }

    fun closeFor(p: Player) {
        val w = p.window ?: return
        p.window = null
        if (w.type == 0) chestAnim(w.x, w.y, w.z, false)
        save()
    }

    fun onClose(p: Player, windowId: Int) {
        if (p.window?.id == windowId) closeFor(p)
    }

    // Изменение ячейки окна от клиента; остальным зрителям того же хранилища — обновление
    fun onSlot(p: Player, windowId: Int, slot: Int, item: Item): Boolean {
        val w = p.window ?: return false
        if (w.id != windowId || slot !in 0 until w.size) return false
        val it = if (item.id == 0 || item.count <= 0) null else item
        w.set(slot, it)
        for (o in s.players.values) {
            val ow = o.window ?: continue
            if (o === p) continue
            val same = ow.stores.any { st -> w.stores.any { it === st } }
            if (!same) continue
            sendContent(o, ow)
        }
        return true
    }

    // Блок сломан: содержимое выпадает
    fun broken(x: Int, y: Int, z: Int) {
        val st = stores.remove(key(x, y, z)) ?: return
        for (o in s.players.values) {
            val w = o.window ?: continue
            if (w.shows(st)) { o.send(Pk.new(Pk.CONTAINER_CLOSE).byte(w.id)); o.window = null }
        }
        s.items.dropBlock(x, y, z, st.items.filterNotNull())
        save()
    }

    // Содержимое хранилища (для плагинов): копия
    fun contents(x: Int, y: Int, z: Int): Array<Item?>? = stores[key(x, y, z)]?.items?.copyOf()

    fun put(x: Int, y: Int, z: Int, items: List<Item?>) {
        val st = store(x, y, z, 27)
        for (i in 0 until 27) st.items[i] = items.getOrNull(i)
        save()
    }

    // ---------- Печи ----------
    fun tick() {
        for (st in stores.values) {
            if (st.items.size != 3) continue
            if (!s.world.isLoaded(st.x shr 4, st.z shr 4)) continue
            val id = s.world.getId(st.x, st.y, st.z)
            if (id != 61 && id != 62) continue
            val wasLit = st.burn > 0
            val changed = tickFurnace(st, 0.05)
            val lit = st.burn > 0
            if (lit != wasLit) s.setBlock(st.x, st.y, st.z, if (lit) 62 else 61, s.world.getData(st.x, st.y, st.z))
            for (o in s.players.values) {
                val w = o.window ?: continue
                if (!w.shows(st)) continue
                if (changed) sendContent(o, w)
                if (s.ticks % 10 == 0 || changed) sendFurnaceData(o, w.id, st)
            }
        }
    }

    private fun sendFurnaceData(p: Player, win: Int, st: Store) {
        p.send(Pk.new(Pk.CONTAINER_SET_DATA).byte(win).varint(0).varint((st.cook * 20).toInt()))
        p.send(Pk.new(Pk.CONTAINER_SET_DATA).byte(win).varint(1).varint((st.burn * 20).toInt()))
        p.send(Pk.new(Pk.CONTAINER_SET_DATA).byte(win).varint(2).varint((st.burnMax * 20).toInt()))
    }

    // То же, что tickFurnace в survival.js: топливо горит FUEL×10 с, предмет готовится 10 с. true — изменились предметы
    private fun tickFurnace(f: Store, dt: Double): Boolean {
        var changed = false
        val input = f.items[0]
        val res = Survival.smeltResult(input)
        val out = f.items[2]
        val canOut = res != null && (out == null || (out.id == res.id && out.data == res.data && out.count < Survival.maxStack(res.id)))
        if (f.burn > 0) f.burn = maxOf(0.0, f.burn - dt)
        val fuel = f.items[1]
        if (f.burn <= 0 && canOut && fuel != null && Survival.fuel.containsKey(fuel.id)) {
            f.burn = Survival.fuel[fuel.id]!! * 10; f.burnMax = f.burn
            f.items[1] = if (fuel.count > 1) Item(fuel.id, fuel.data, fuel.count - 1) else if (fuel.id == 327) Item(325, 0, 1) else null
            changed = true
        }
        if (f.burn > 0 && canOut) {
            f.cook += dt
            if (f.cook >= 10) {
                f.cook = 0.0
                f.items[2] = if (out != null) Item(out.id, out.data, out.count + 1) else res
                f.items[0] = if (input!!.count > 1) Item(input.id, input.data, input.count - 1) else null
                changed = true
            }
        } else if (f.cook > 0) f.cook = maxOf(0.0, f.cook - dt * 2)
        return changed
    }

    // ---------- Сохранение ----------
    fun load(file: File) {
        if (!file.exists()) return
        try {
            val o = JSONObject(file.readText())
            for (k in o.keys()) {
                val e = o.getJSONObject(k)
                val c = k.split(',').map { it.toInt() }
                val a = e.getJSONArray("items")
                val st = Store(k, c[0], c[1], c[2], arrayOfNulls(a.length()))
                for (i in 0 until a.length()) {
                    val it = a.optJSONArray(i)
                    st.items[i] = if (it != null && it.length() == 3) Item(it.getInt(0), it.getInt(1), it.getInt(2)) else null
                }
                st.burn = e.optDouble("burn", 0.0); st.burnMax = e.optDouble("burnMax", 0.0); st.cook = e.optDouble("cook", 0.0)
                stores[k] = st
            }
        } catch (e: Exception) {
            s.log("Не удалось прочитать containers.json: $e")
        }
    }

    private var file: File? = null
    fun bind(f: File) { file = f; load(f) }

    fun save() {
        val f = file ?: return
        val o = JSONObject()
        for (st in stores.values) {
            if (st.items.all { it == null } && st.burn <= 0) continue
            val a = JSONArray()
            for (it in st.items) a.put(if (it == null) JSONArray() else JSONArray().put(it.id).put(it.data).put(it.count))
            o.put(st.key, JSONObject().put("items", a).put("burn", st.burn).put("burnMax", st.burnMax).put("cook", st.cook))
        }
        try { f.writeText(o.toString()) } catch (e: Exception) { }
    }
}
