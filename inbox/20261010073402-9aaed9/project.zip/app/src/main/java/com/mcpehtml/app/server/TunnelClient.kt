package com.mcpehtml.app.server

import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import java.net.URI
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

// Туннель до VPS с белым IP: игроки подключаются к домену (UDP 19132 на VPS),
// VPS пересылает их датаграммы сюда по WebSocket, ответы уходят обратно тем же путём.
// Кадры: [тип 1 байт][номер игрока 4 байта][данные]
//   VPS → телефон: 0 = вызов (nonce), 1 = датаграмма, 2 = новый игрок (порт 2 байта + IP), 3 = игрок пропал, 5 = ошибка (текст)
//   телефон → VPS: 4 = ответ на вызов (HMAC-SHA256 ключа от nonce), 1 = датаграмма
class TunnelClient(private val server: MineServer, private val url: String, private val key: String) : Transport {
    @Volatile private var ws: WebSocketClient? = null
    @Volatile private var stopped = false
    private val peers = ConcurrentHashMap<Int, Peer>()
    private var thread: Thread? = null
    private val lock = Object()

    fun start() {
        stopped = false
        thread = Thread({ loop() }, "mcpe-tunnel").also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        stopped = true
        try { ws?.closeBlocking() } catch (e: Exception) { }
        synchronized(lock) { lock.notifyAll() }
        thread?.join(2000)
        server.tunnelStatus = ""
    }

    // Переподключение с паузой 2…30 секунд, пока сервер работает
    private fun loop() {
        var delay = 2000L
        while (!stopped) {
            server.tunnelStatus = "Подключение к $url…"
            val authed = booleanArrayOf(false)
            val c = object : WebSocketClient(URI(url)) {
                override fun onOpen(h: ServerHandshake) {}
                override fun onMessage(message: String) {}
                override fun onMessage(bytes: ByteBuffer) {
                    val b = ByteArray(bytes.remaining()); bytes.get(b)
                    if (b.isEmpty()) return
                    when (b[0].toInt()) {
                        0 -> {
                            val nonce = b.copyOfRange(1, b.size)
                            val mac = Mac.getInstance("HmacSHA256")
                            mac.init(SecretKeySpec(key.toByteArray(Charsets.UTF_8), "HmacSHA256"))
                            val sig = mac.doFinal(nonce)
                            send(byteArrayOf(4) + sig)
                        }
                        6 -> {
                            authed[0] = true
                            server.tunnelStatus = "Туннель работает: игроки заходят по адресу VPS"
                            server.log("Туннель подключён к $url")
                        }
                        5 -> {
                            val msg = String(b, 1, b.size - 1, Charsets.UTF_8)
                            server.tunnelStatus = "Туннель: $msg"
                            server.log("Туннель: $msg")
                        }
                        2 -> if (b.size >= 7) {
                            val id = ByteBuffer.wrap(b, 1, 4).int
                            val port = ((b[5].toInt() and 0xff) shl 8) or (b[6].toInt() and 0xff)
                            val ip = String(b, 7, b.size - 7, Charsets.UTF_8)
                            peers[id] = Peer("t:$id", ip, port, this@TunnelClient)
                        }
                        3 -> if (b.size >= 5) peers.remove(ByteBuffer.wrap(b, 1, 4).int)
                        1 -> if (b.size >= 5) {
                            val id = ByteBuffer.wrap(b, 1, 4).int
                            val peer = peers[id] ?: return
                            server.inject(peer, b.copyOfRange(5, b.size))
                        }
                    }
                }
                override fun onClose(code: Int, reason: String, remote: Boolean) {
                    synchronized(lock) { lock.notifyAll() }
                }
                override fun onError(ex: Exception) {
                    server.tunnelStatus = "Туннель: ошибка ${ex.message ?: ex.javaClass.simpleName}"
                }
            }
            c.connectionLostTimeout = 30
            ws = c
            try {
                if (c.connectBlocking(15, java.util.concurrent.TimeUnit.SECONDS)) {
                    synchronized(lock) { while (!stopped && c.isOpen) lock.wait(1000) }
                }
            } catch (e: Exception) {
                server.tunnelStatus = "Туннель: ${e.message ?: e.javaClass.simpleName}"
            }
            peers.clear()
            if (authed[0]) delay = 2000L
            if (stopped) break
            if (!server.tunnelStatus.startsWith("Туннель: ")) server.tunnelStatus = "Туннель отключён, переподключение…"
            synchronized(lock) { if (!stopped) lock.wait(delay) }
            delay = minOf(delay * 2, 30000L)
        }
    }

    override fun send(peer: Peer, data: ByteArray) {
        val c = ws ?: return
        if (!c.isOpen) return
        val id = peer.key.substring(2).toIntOrNull() ?: return
        val f = ByteBuffer.allocate(5 + data.size)
        f.put(1).putInt(id).put(data)
        try { c.send(f.array()) } catch (e: Exception) { }
    }
}
