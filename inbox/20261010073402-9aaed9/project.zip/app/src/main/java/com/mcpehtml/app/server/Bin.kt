package com.mcpehtml.app.server

import java.io.ByteArrayOutputStream
import java.util.zip.Deflater
import java.util.zip.Inflater

// Запись двоичных данных протокола MCPE 1.1 (порядок байт и varint как в Nukkit BinaryStream)
class W(size: Int = 64) {
    private var buf = ByteArray(size)
    var pos = 0
        private set

    private fun ensure(n: Int) {
        if (pos + n > buf.size) buf = buf.copyOf(maxOf(buf.size * 2, pos + n))
    }

    fun byte(v: Int): W { ensure(1); buf[pos++] = v.toByte(); return this }
    fun bool(v: Boolean): W = byte(if (v) 1 else 0)
    fun raw(b: ByteArray, off: Int = 0, len: Int = b.size - off): W { ensure(len); System.arraycopy(b, off, buf, pos, len); pos += len; return this }
    fun short(v: Int): W { ensure(2); buf[pos++] = (v shr 8).toByte(); buf[pos++] = v.toByte(); return this }
    fun lshort(v: Int): W { ensure(2); buf[pos++] = v.toByte(); buf[pos++] = (v shr 8).toByte(); return this }
    fun triad(v: Int): W { ensure(3); buf[pos++] = v.toByte(); buf[pos++] = (v shr 8).toByte(); buf[pos++] = (v shr 16).toByte(); return this }
    fun int(v: Int): W { ensure(4); for (i in 3 downTo 0) buf[pos++] = (v shr (i * 8)).toByte(); return this }
    fun lint(v: Int): W { ensure(4); for (i in 0..3) buf[pos++] = (v shr (i * 8)).toByte(); return this }
    fun long(v: Long): W { ensure(8); for (i in 7 downTo 0) buf[pos++] = (v shr (i * 8)).toByte(); return this }
    fun llong(v: Long): W { ensure(8); for (i in 0..7) buf[pos++] = (v shr (i * 8)).toByte(); return this }
    fun lfloat(v: Float): W = lint(java.lang.Float.floatToIntBits(v))
    fun uvarint(v: Long): W {
        var x = v
        ensure(10)
        while (true) {
            if (x and 0x7fL.inv() == 0L) { buf[pos++] = x.toByte(); return this }
            buf[pos++] = ((x and 0x7f) or 0x80).toByte()
            x = x ushr 7
        }
    }
    fun uvarint(v: Int): W = uvarint(v.toLong() and 0xffffffffL)
    fun varint(v: Int): W = uvarint(((v shl 1) xor (v shr 31)).toLong() and 0xffffffffL)
    fun varlong(v: Long): W = uvarint((v shl 1) xor (v shr 63))
    fun string(s: String): W { val b = s.toByteArray(Charsets.UTF_8); uvarint(b.size); return raw(b) }
    fun bytes(b: ByteArray): W { uvarint(b.size); return raw(b) }
    fun vec3(x: Float, y: Float, z: Float): W = lfloat(x).lfloat(y).lfloat(z)
    fun blockCoords(x: Int, y: Int, z: Int): W = varint(x).uvarint(y).varint(z)
    fun uuid(msb: Long, lsb: Long): W = long(msb).long(lsb)
    fun toBytes(): ByteArray = buf.copyOf(pos)
}

class R(val buf: ByteArray, var pos: Int = 0, val end: Int = buf.size) {
    fun eof() = pos >= end
    fun remaining() = end - pos
    private fun need(n: Int) { if (pos + n > end) throw IllegalStateException("Пакет короче, чем нужно") }
    fun byte(): Int { need(1); return buf[pos++].toInt() and 0xff }
    fun bool() = byte() != 0
    fun raw(n: Int): ByteArray { need(n); val r = buf.copyOfRange(pos, pos + n); pos += n; return r }
    fun skip(n: Int) { need(n); pos += n }
    fun short(): Int { need(2); val v = ((buf[pos].toInt() and 0xff) shl 8) or (buf[pos + 1].toInt() and 0xff); pos += 2; return v }
    fun lshort(): Int { need(2); val v = (buf[pos].toInt() and 0xff) or ((buf[pos + 1].toInt() and 0xff) shl 8); pos += 2; return v }
    fun triad(): Int { need(3); val v = (buf[pos].toInt() and 0xff) or ((buf[pos + 1].toInt() and 0xff) shl 8) or ((buf[pos + 2].toInt() and 0xff) shl 16); pos += 3; return v }
    fun int(): Int { need(4); var v = 0; for (i in 0..3) v = (v shl 8) or (buf[pos++].toInt() and 0xff); return v }
    fun lint(): Int { need(4); var v = 0; for (i in 0..3) v = v or ((buf[pos++].toInt() and 0xff) shl (i * 8)); return v }
    fun long(): Long { need(8); var v = 0L; for (i in 0..7) v = (v shl 8) or (buf[pos++].toLong() and 0xff); return v }
    fun lfloat(): Float = java.lang.Float.intBitsToFloat(lint())
    fun uvarlong(): Long {
        var v = 0L
        var shift = 0
        while (shift < 70) {
            val b = byte()
            v = v or ((b and 0x7f).toLong() shl shift)
            if (b and 0x80 == 0) return v
            shift += 7
        }
        throw IllegalStateException("Слишком длинный varint")
    }
    fun uvarint(): Int = uvarlong().toInt()
    fun varint(): Int { val u = uvarint(); return (u ushr 1) xor -(u and 1) }
    fun varlong(): Long { val u = uvarlong(); return (u ushr 1) xor -(u and 1) }
    fun string(): String { val n = uvarint(); need(n); val s = String(buf, pos, n, Charsets.UTF_8); pos += n; return s }
    fun bytes(): ByteArray = raw(uvarint())
    fun blockCoords(): IntArray = intArrayOf(varint(), uvarint(), varint())
}

object Zlib {
    fun deflate(data: ByteArray, level: Int = 6): ByteArray {
        val d = Deflater(level)
        d.setInput(data)
        d.finish()
        val out = ByteArrayOutputStream(data.size / 2 + 64)
        val tmp = ByteArray(8192)
        while (!d.finished()) {
            val n = d.deflate(tmp)
            out.write(tmp, 0, n)
        }
        d.end()
        return out.toByteArray()
    }

    // Ограничение размера защищает от «zip-бомб» от клиентов
    fun inflate(data: ByteArray, max: Int = 8 * 1024 * 1024): ByteArray {
        val inf = Inflater()
        inf.setInput(data)
        val out = ByteArrayOutputStream(data.size * 3 + 64)
        val tmp = ByteArray(8192)
        try {
            while (!inf.finished()) {
                val n = inf.inflate(tmp)
                if (n == 0) {
                    if (inf.needsInput() || inf.needsDictionary()) break
                }
                out.write(tmp, 0, n)
                if (out.size() > max) throw IllegalStateException("Слишком большой пакет")
            }
        } finally {
            inf.end()
        }
        return out.toByteArray()
    }
}
