package com.mcpehtml.app.server

import org.json.JSONArray
import org.json.JSONObject
import org.mozilla.javascript.BaseFunction
import org.mozilla.javascript.Context
import org.mozilla.javascript.ContextFactory
import org.mozilla.javascript.Function
import org.mozilla.javascript.Scriptable
import org.mozilla.javascript.ScriptableObject
import java.io.File

// Плагины сервера на JavaScript (движок Rhino): файлы plugins/*.js, выключенные — *.js.off.
// Плагин видит только API сервера (server, plugin), без доступа к файлам и Java.
class Plugins(private val s: MineServer, private val dir: File) {
    class Plugin(val file: String) {
        var name = file.removeSuffix(".js")
        var version = "1.0"
        var description = ""
        var author = ""
        var error: String? = null
        var scope: Scriptable? = null
        var ticking = false
        val commands = ArrayList<String>()
        var errors = 0
    }

    class Cmd(val plugin: Plugin, val name: String, val description: String, val usage: String, val op: Boolean, val aliases: List<String>)

    val list = ArrayList<Plugin>()
    val commands = LinkedHashMap<String, Cmd>()
    @Volatile var available = true
        private set
    private var factory: ContextFactory? = null
    private var current: Plugin? = null

    private class Factory : ContextFactory() {
        override fun makeContext(): Context {
            val cx = super.makeContext()
            @Suppress("DEPRECATION")
            cx.optimizationLevel = -1
            cx.languageVersion = Context.VERSION_ES6
            cx.instructionObserverThreshold = 20000
            return cx
        }

        override fun observeInstructionCount(cx: Context, instructionCount: Int) {
            val d = cx.getThreadLocal("deadline") as? Long ?: return
            if (System.currentTimeMillis() > d) throw Error("плагин выполняется слишком долго (зацикливание?)")
        }
    }

    // ---------- Загрузка ----------
    fun loadAll() {
        unloadAll()
        dir.mkdirs()
        File(dir, "data").mkdirs()
        val f = try { factory ?: Factory().also { factory = it } } catch (e: Throwable) {
            available = false
            s.log("Плагины недоступны: движок JavaScript не загрузился ($e)")
            return
        }
        val files = dir.listFiles { x -> x.isFile && x.name.endsWith(".js") }?.sortedBy { it.name } ?: emptyList()
        for (file in files) {
            val p = Plugin(file.name)
            list.add(p)
            try {
                val src = file.readText()
                call(p, 3000) { cx ->
                    val scope = cx.initSafeStandardObjects()
                    p.scope = scope
                    ScriptableObject.putProperty(scope, "__N", natives(p, scope))
                    cx.evaluateString(scope, PRELUDE, "prelude", 1, null)
                    cx.evaluateString(scope, src, file.name, 1, null)
                    val meta = ScriptableObject.getProperty(scope, "plugin") as? Scriptable
                    if (meta != null) {
                        fun str(k: String, def: String): String { val v = ScriptableObject.getProperty(meta, k); return if (v is String || v is CharSequence) v.toString() else def }
                        p.name = str("name", p.name).take(40)
                        p.version = str("version", p.version).take(20)
                        p.description = str("description", "").take(200)
                        p.author = str("author", "").take(40)
                    }
                    callJs(cx, p, "__enable")
                }
                s.log("Плагин ${p.name} ${p.version} загружен")
            } catch (e: Throwable) {
                p.error = errorText(e)
                p.scope = null
                for (c in p.commands) commands.remove(c)
                s.log("Плагин ${file.name} не загружен: ${p.error}")
            }
        }
    }

    fun unloadAll() {
        for (p in list) if (p.scope != null) try { call(p, 1000) { cx -> callJs(cx, p, "__disable") } } catch (e: Throwable) { }
        list.clear()
        commands.clear()
    }

    private fun errorText(e: Throwable): String {
        val m = (e as? org.mozilla.javascript.RhinoException)?.let { it.details() + (it.lineNumber().takeIf { n -> n > 0 }?.let { n -> " (строка $n)" } ?: "") }
        return (m ?: e.message ?: e.toString()).take(300)
    }

    private fun <T> call(p: Plugin, budgetMs: Long, block: (Context) -> T): T {
        val f = factory ?: throw IllegalStateException("нет движка")
        val cx = f.enterContext()
        val prev = current
        current = p
        try {
            cx.putThreadLocal("deadline", System.currentTimeMillis() + budgetMs)
            return block(cx)
        } finally {
            current = prev
            Context.exit()
        }
    }

    private fun callJs(cx: Context, p: Plugin, fn: String, vararg args: Any?): Any? {
        val scope = p.scope ?: return null
        val f = ScriptableObject.getProperty(scope, fn) as? Function ?: return null
        return f.call(cx, scope, scope, args)
    }

    private fun safe(p: Plugin, what: String, block: (Context) -> Any?): Any? {
        if (p.scope == null) return null
        return try {
            call(p, 500, block)
        } catch (e: Throwable) {
            p.errors++
            if (p.errors <= 20) s.log("Ошибка в плагине ${p.name} ($what): ${errorText(e)}")
            if (e is Error && e.message?.contains("слишком долго") == true) {
                p.error = "отключён: ${e.message}"
                p.scope = null
                for (c in p.commands) commands.remove(c)
                s.log("Плагин ${p.name} отключён: ${e.message}")
            }
            null
        }
    }

    // ---------- События ----------
    // Возвращает изменённое событие (cancelled, message и т. п.) или null, если плагинов нет
    fun fire(event: String, data: Map<String, Any?>): JSONObject? {
        if (list.isEmpty()) return null
        var o = JSONObject()
        for ((k, v) in data) o.put(k, toJson(v))
        o.put("cancelled", false)
        for (p in list) {
            if (p.scope == null) continue
            val r = safe(p, event) { cx -> callJs(cx, p, "__emit", event, o.toString()) } ?: continue
            try { o = JSONObject(Context.toString(r)) } catch (e: Exception) { }
        }
        return o
    }

    // true — событие отменено плагином
    fun emit(event: String, data: Map<String, Any?>): Boolean = fire(event, data)?.optBoolean("cancelled", false) == true

    private fun toJson(v: Any?): Any? = when (v) {
        null -> JSONObject.NULL
        is Player -> snapshot(v)
        is Map<*, *> -> JSONObject().also { o -> for ((k, x) in v) o.put(k.toString(), toJson(x)) }
        is List<*> -> JSONArray().also { a -> for (x in v) a.put(toJson(x)) }
        is Item -> JSONObject().put("id", v.id).put("data", v.data).put("count", v.count)
        else -> v
    }

    fun snapshot(p: Player): JSONObject = JSONObject()
        .put("__player", p.name).put("name", p.name)
        .put("x", p.x).put("y", p.y).put("z", p.z).put("yaw", p.yaw.toDouble()).put("pitch", p.pitch.toDouble())
        .put("health", p.health.toDouble()).put("food", p.food).put("gamemode", p.gamemode)
        .put("op", p.op).put("ip", p.session.peer.ip).put("sneaking", p.sneaking).put("dead", p.dead)
        .put("held", JSONObject().put("id", p.held.id).put("data", p.held.data).put("count", p.held.count))

    // ---------- Команды ----------
    fun find(name: String): Cmd? = commands[name.lowercase()] ?: commands.values.firstOrNull { c -> c.aliases.any { it.equals(name, true) } }

    fun runCommand(sender: Player?, cmd: Cmd, args: List<String>, line: String) {
        val p = cmd.plugin
        safe(p, "/" + cmd.name) { cx ->
            callJs(cx, p, "__cmd", cmd.name, if (sender != null) snapshot(sender).toString() else "null", JSONArray(args).toString(), line)
        }
    }

    fun tick(tick: Int) {
        for (p in list) if (p.scope != null && p.ticking) safe(p, "таймер") { cx -> callJs(cx, p, "__tick", tick) }
    }

    fun info(): JSONArray {
        val a = JSONArray()
        for (p in list) a.put(JSONObject().put("file", p.file).put("name", p.name).put("version", p.version)
            .put("description", p.description).put("author", p.author).put("error", p.error ?: "").put("commands", JSONArray(p.commands)))
        return a
    }

    // ---------- Функции для JavaScript ----------
    private class NF(private val f: (Array<Any?>) -> Any?) : BaseFunction() {
        override fun call(cx: Context, scope: Scriptable, thisObj: Scriptable?, args: Array<Any?>): Any? {
            val r = f(args)
            return if (r == null || r == Unit) org.mozilla.javascript.Undefined.instance else r
        }
    }

    private fun natives(p: Plugin, scope: Scriptable): Scriptable {
        val o = Context.getCurrentContext().newObject(scope)
        fun def(name: String, f: (Array<Any?>) -> Any?) = ScriptableObject.putProperty(o, name, NF(f))
        fun str(a: Array<Any?>, i: Int) = if (i < a.size && a[i] != null && a[i] != org.mozilla.javascript.Undefined.instance) Context.toString(a[i]) else ""
        fun num(a: Array<Any?>, i: Int, def: Double = 0.0) = if (i < a.size && a[i] != null && a[i] != org.mozilla.javascript.Undefined.instance) Context.toNumber(a[i]).let { if (it.isNaN()) def else it } else def
        fun int(a: Array<Any?>, i: Int, def: Int = 0) = num(a, i, def.toDouble()).toInt()
        fun bool(a: Array<Any?>, i: Int) = i < a.size && Context.toBoolean(a[i])
        fun pl(a: Array<Any?>) = s.findPlayerExact(str(a, 0))
        val dataFile = File(File(dir, "data"), p.file.removeSuffix(".js") + ".json")

        // Сервер
        def("log") { a -> s.log("[${p.name}] ${str(a, 0).replace(Regex("§."), "")}") }
        def("broadcast") { a -> s.broadcastMessage(str(a, 0)) }
        def("players") { _ -> JSONArray().also { arr -> for (x in s.players.values) if (x.spawned) arr.put(snapshot(x)) }.toString() }
        def("player") { a -> pl(a)?.let { snapshot(it).toString() } ?: "null" }
        def("getBlock") { a -> val y = int(a, 1); if (y < 0 || y > 255) "[0,0]" else "[${s.world.getId(int(a, 0), y, int(a, 2))},${s.world.getData(int(a, 0), y, int(a, 2))}]" }
        def("setBlock") { a -> s.setBlock(int(a, 0), int(a, 1), int(a, 2), int(a, 3) and 255, int(a, 4) and 15) }
        def("breakBlock") { a -> s.breakBlockAt(int(a, 0), int(a, 1), int(a, 2), int(a, 3), bool(a, 4)) }
        def("dropItem") { a -> s.items.spawn(Item(int(a, 3), int(a, 4), int(a, 5, 1).coerceIn(1, 64)), num(a, 0), num(a, 1), num(a, 2), 0.0, 0.1, 0.0, 10); Unit }
        def("highest") { a -> s.world.highestY(int(a, 0), int(a, 1)) }
        def("time") { _ -> s.time }
        def("setTime") { a -> s.setWorldTime(int(a, 0)) }
        def("spawn") { _ -> s.spawnPos().let { "[${it[0]},${it[1]},${it[2]}]" } }
        def("run") { a -> s.runConsole(str(a, 0)) }
        def("info") { _ -> JSONObject().put("name", s.cfg.name).put("max", s.cfg.maxPlayers).put("port", s.cfg.port).put("tick", s.ticks).toString() }
        def("command") { a ->
            val name = str(a, 0).lowercase().trim()
            if (name.isNotEmpty() && Regex("^[a-z0-9_]{1,24}$").matches(name)) {
                val aliases = str(a, 4).split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
                commands[name] = Cmd(p, name, str(a, 1), str(a, 2), bool(a, 3), aliases)
                if (!p.commands.contains(name)) p.commands.add(name)
                s.commandsChanged()
            }
        }
        def("ticking") { a -> p.ticking = bool(a, 0) }
        def("load") { _ -> if (dataFile.exists()) dataFile.readText() else "" }
        def("store") { a -> val t = str(a, 0); if (t.length < 4_000_000) dataFile.writeText(t) }

        // Игрок (по нику)
        def("pSend") { a -> pl(a)?.message(str(a, 1)) }
        def("pPopup") { a -> pl(a)?.popup(str(a, 1)) }
        def("pTitle") { a -> pl(a)?.title(str(a, 1), str(a, 2)) }
        def("pTeleport") { a -> pl(a)?.let { s.teleport(it, num(a, 1), num(a, 2), num(a, 3)) } }
        def("pGamemode") { a -> pl(a)?.let { s.setGamemode(it, int(a, 1).coerceIn(0, 3)) } }
        def("pHealth") { a -> pl(a)?.let { s.setHealth(it, num(a, 1).toFloat()) } }
        def("pFood") { a -> pl(a)?.let { it.food = int(a, 1).coerceIn(0, 20); it.statsDirty = true } }
        def("pDamage") { a -> pl(a)?.let { s.damage(it, num(a, 1).toFloat(), "plugin", null) } }
        def("pGive") { a -> pl(a)?.give(Item(int(a, 1), int(a, 2), int(a, 3, 1).coerceIn(1, 64 * 36))) ?: -1 }
        def("pCount") { a -> pl(a)?.count(int(a, 1), int(a, 2, -1)) ?: 0 }
        def("pTake") { a -> pl(a)?.take(int(a, 1), int(a, 2, -1), int(a, 3, 1)) ?: false }
        def("pClear") { a -> pl(a)?.clearInventory() }
        def("pKick") { a -> pl(a)?.disconnect(str(a, 1).ifEmpty { "Вас выгнали" }) }
        def("pInventory") { a ->
            val x = pl(a)
            val arr = JSONArray()
            if (x != null) for (i in 0 until 36) x.inventory[i]?.let { arr.put(JSONObject().put("slot", i).put("id", it.id).put("data", it.data).put("count", it.count)) }
            arr.toString()
        }
        def("pSetSlot") { a -> pl(a)?.let { val c = int(a, 4); it.setSlot(int(a, 1).coerceIn(0, 35), if (c > 0) Item(int(a, 2), int(a, 3), c.coerceAtMost(64)) else null) } }
        def("pMotion") { a -> pl(a)?.let { it.send(Pk.new(Pk.SET_ENTITY_MOTION).varlong(it.eid).vec3(num(a, 1).toFloat(), num(a, 2).toFloat(), num(a, 3).toFloat())) } }
        return o
    }

    companion object {
        // Обёртка API на JavaScript: объекты server, plugin и игроков
        private val PRELUDE = """
var plugin = { name: '', version: '1.0', description: '', author: '', data: {} };
var console = { log: function () { __N.log(Array.prototype.join.call(arguments, ' ')); } };
var server = (function (N) {
  var handlers = {}, cmds = {}, tasks = [], nextTask = 1, enableFns = [], disableFns = [];
  function P(o) {
    if (!o) return null;
    var name = o.name;
    var p = {
      name: name, x: o.x, y: o.y, z: o.z, yaw: o.yaw, pitch: o.pitch, health: o.health, food: o.food,
      gamemode: o.gamemode, op: o.op, ip: o.ip, sneaking: o.sneaking, dead: o.dead, held: o.held,
      send: function (m) { N.pSend(name, String(m)); },
      popup: function (m) { N.pPopup(name, String(m)); },
      title: function (t, sub) { N.pTitle(name, String(t), sub ? String(sub) : ''); },
      teleport: function (x, y, z) { N.pTeleport(name, x, y, z); },
      setGamemode: function (g) { N.pGamemode(name, g); },
      setHealth: function (h) { N.pHealth(name, h); },
      setFood: function (f) { N.pFood(name, f); },
      damage: function (d) { N.pDamage(name, d); },
      give: function (id, data, count) { return N.pGive(name, id, data || 0, count || 1); },
      count: function (id, data) { return N.pCount(name, id, data === undefined ? -1 : data); },
      has: function (id, data, count) { return N.pCount(name, id, data === undefined ? -1 : data) >= (count || 1); },
      take: function (id, data, count) { return N.pTake(name, id, data === undefined ? -1 : data, count || 1); },
      clear: function () { N.pClear(name); },
      kick: function (r) { N.pKick(name, r ? String(r) : ''); },
      inventory: function () { return JSON.parse(N.pInventory(name)); },
      setSlot: function (slot, id, data, count) { N.pSetSlot(name, slot, id || 0, data || 0, count === undefined ? 1 : count); },
      push: function (x, y, z) { N.pMotion(name, x, y, z); },
      online: function () { return N.player(name) !== 'null'; },
      refresh: function () { return P(JSON.parse(N.player(name))); }
    };
    return p;
  }
  function wrap(v) {
    if (v && typeof v === 'object') {
      if (v.__player) return P(v);
      for (var k in v) v[k] = wrap(v[k]);
    }
    return v;
  }
  var api = {
    on: function (ev, fn) { (handlers[ev] = handlers[ev] || []).push(fn); },
    command: function (name, opts, fn) {
      if (typeof opts === 'function') { fn = opts; opts = {}; }
      opts = opts || {};
      cmds[String(name).toLowerCase()] = fn;
      N.command(String(name), opts.description || '', opts.usage || '', !!opts.op, (opts.aliases || []).join(','));
      for (var i = 0; opts.aliases && i < opts.aliases.length; i++) cmds[String(opts.aliases[i]).toLowerCase()] = fn;
    },
    onEnable: function (fn) { enableFns.push(fn); },
    onDisable: function (fn) { disableFns.push(fn); },
    later: function (ticks, fn) { var id = nextTask++; tasks.push({ id: id, at: -1, delay: Math.max(1, ticks | 0), every: 0, fn: fn }); N.ticking(true); return id; },
    every: function (ticks, fn) { var id = nextTask++; var t = Math.max(1, ticks | 0); tasks.push({ id: id, at: -1, delay: t, every: t, fn: fn }); N.ticking(true); return id; },
    cancel: function (id) { tasks = tasks.filter(function (t) { return t.id !== id; }); N.ticking(tasks.length > 0); },
    broadcast: function (m) { N.broadcast(String(m)); },
    log: function (m) { N.log(String(m)); },
    players: function () { return JSON.parse(N.players()).map(P); },
    player: function (name) { return P(JSON.parse(N.player(String(name)))); },
    getBlock: function (x, y, z) { var b = JSON.parse(N.getBlock(x, y, z)); return { id: b[0], data: b[1] }; },
    setBlock: function (x, y, z, id, data) { N.setBlock(x, y, z, id, data || 0); },
    breakBlock: function (x, y, z, tool, drop) { N.breakBlock(x, y, z, tool || 0, drop !== false); },
    dropItem: function (x, y, z, id, data, count) { N.dropItem(x, y, z, id, data || 0, count || 1); },
    highestY: function (x, z) { return N.highest(x, z); },
    time: function () { return N.time(); },
    setTime: function (t) { N.setTime(t); },
    spawn: function () { var s = JSON.parse(N.spawn()); return { x: s[0], y: s[1], z: s[2] }; },
    run: function (cmd) { N.run(String(cmd).replace(/^\//, '')); },
    info: function () { return JSON.parse(N.info()); }
  };
  this.__enable = function () {
    try { var d = N.load(); plugin.data = d ? JSON.parse(d) : {}; } catch (e) { plugin.data = {}; }
    plugin.save = function () { N.store(JSON.stringify(plugin.data)); };
    for (var i = 0; i < enableFns.length; i++) enableFns[i]();
  };
  this.__disable = function () { for (var i = 0; i < disableFns.length; i++) disableFns[i](); };
  this.__emit = function (ev, json) {
    var raw = JSON.parse(json);
    var e = wrap(JSON.parse(json));
    e.cancel = function () { e.cancelled = true; };
    var hs = handlers[ev] || [];
    for (var i = 0; i < hs.length; i++) { if (hs[i](e) === false) e.cancelled = true; }
    var out = {};
    for (var k in e) {
      var v = e[k];
      if (typeof v === 'function') continue;
      // Игроков передаём следующему плагину в исходном виде (со всеми полями)
      out[k] = v && typeof v === 'object' && typeof v.send === 'function' ? (raw[k] && raw[k].__player ? raw[k] : { __player: v.name }) : v;
    }
    return JSON.stringify(out);
  };
  this.__cmd = function (name, pj, aj, line) {
    var fn = cmds[name];
    if (!fn) return;
    var p = P(JSON.parse(pj));
    var r = fn(p, JSON.parse(aj), line);
    if (typeof r === 'string' && p) p.send(r);
  };
  this.__tick = function (tick) {
    var due = [];
    for (var i = 0; i < tasks.length; i++) {
      var t = tasks[i];
      if (t.at < 0) t.at = tick + t.delay;
      if (tick >= t.at) due.push(t);
    }
    for (var j = 0; j < due.length; j++) {
      var t2 = due[j];
      if (t2.every) t2.at = tick + t2.every; else tasks = tasks.filter(function (x) { return x !== t2; });
      t2.fn();
    }
    if (!tasks.length) N.ticking(false);
  };
  return api;
})(__N);
"""
    }
}
