package com.mcpehtml.app.server

// Имена предметов для /give, /setblock, /fill: "id", "id:data", "name", "name:data" (названия как в Minecraft)
object ItemNames {
    private const val TABLE = "air=0 stone=1 granite=1:1 diorite=1:3 andesite=1:5 grass=2 dirt=3 cobblestone=4 planks=5 wood=5 sapling=6 bedrock=7 " +
        "water=8 lava=10 sand=12 red_sand=12:1 gravel=13 gold_ore=14 iron_ore=15 coal_ore=16 log=17 oak_log=17 spruce_log=17:1 birch_log=17:2 " +
        "jungle_log=17:3 leaves=18 sponge=19 glass=20 lapis_ore=21 lapis_block=22 dispenser=23 sandstone=24 noteblock=25 bed_block=26 " +
        "golden_rail=27 powered_rail=27 detector_rail=28 sticky_piston=29 web=30 cobweb=30 tallgrass=31:1 deadbush=32 piston=33 wool=35 " +
        "yellow_flower=37 dandelion=37 red_flower=38 poppy=38 brown_mushroom=39 red_mushroom=40 gold_block=41 iron_block=42 double_stone_slab=43 " +
        "stone_slab=44 slab=44 brick_block=45 bricks=45 tnt=46 bookshelf=47 mossy_cobblestone=48 obsidian=49 torch=50 fire=51 mob_spawner=52 " +
        "oak_stairs=53 chest=54 redstone_wire=55 diamond_ore=56 diamond_block=57 crafting_table=58 workbench=58 wheat_block=59 farmland=60 " +
        "furnace=61 lit_furnace=62 standing_sign=63 wooden_door_block=64 ladder=65 rail=66 stone_stairs=67 cobblestone_stairs=67 wall_sign=68 " +
        "lever=69 stone_pressure_plate=70 iron_door_block=71 wooden_pressure_plate=72 redstone_ore=73 redstone_torch=76 stone_button=77 " +
        "snow_layer=78 ice=79 snow=80 cactus=81 clay=82 reeds_block=83 fence=85 pumpkin=86 netherrack=87 soul_sand=88 glowstone=89 portal=90 " +
        "lit_pumpkin=91 jack_o_lantern=91 cake_block=92 unpowered_repeater=93 trapdoor=96 monster_egg=97 stonebrick=98 stone_bricks=98 " +
        "brown_mushroom_block=99 red_mushroom_block=100 iron_bars=101 glass_pane=102 melon_block=103 pumpkin_stem=104 melon_stem=105 vine=106 " +
        "fence_gate=107 brick_stairs=108 stone_brick_stairs=109 mycelium=110 waterlily=111 lily_pad=111 nether_brick=112 nether_brick_fence=113 " +
        "nether_brick_stairs=114 nether_wart_block=115 enchanting_table=116 brewing_stand_block=117 cauldron_block=118 end_portal=119 " +
        "end_portal_frame=120 end_stone=121 dragon_egg=122 redstone_lamp=123 lit_redstone_lamp=124 dropper=125 activator_rail=126 cocoa=127 " +
        "sandstone_stairs=128 emerald_ore=129 ender_chest=130 tripwire_hook=131 tripwire=132 emerald_block=133 spruce_stairs=134 birch_stairs=135 " +
        "jungle_stairs=136 command_block=137 beacon=138 cobblestone_wall=139 flower_pot_block=140 carrots_block=141 potatoes_block=142 " +
        "wooden_button=143 skull_block=144 anvil=145 trapped_chest=146 light_weighted_pressure_plate=147 heavy_weighted_pressure_plate=148 " +
        "daylight_detector=151 redstone_block=152 quartz_ore=153 hopper_block=154 quartz_block=155 quartz_stairs=156 double_wooden_slab=157 " +
        "wooden_slab=158 stained_hardened_clay=159 terracotta=159 stained_glass_pane=160 leaves2=161 log2=162 acacia_log=162 dark_oak_log=162:1 " +
        "acacia_stairs=163 dark_oak_stairs=164 slime=165 slime_block=165 iron_trapdoor=167 prismarine=168 sea_lantern=169 hay_block=170 carpet=171 " +
        "hardened_clay=172 coal_block=173 packed_ice=174 double_plant=175 red_sandstone=179 red_sandstone_stairs=180 spruce_fence_gate=183 " +
        "birch_fence_gate=184 jungle_fence_gate=185 dark_oak_fence_gate=186 acacia_fence_gate=187 grass_path=198 item_frame_block=199 " +
        "chorus_flower=200 purpur_block=201 purpur_stairs=203 end_bricks=206 end_rod=208 end_gateway=209 magma=213 nether_wart_block2=214 " +
        "red_nether_brick=215 bone_block=216 shulker_box=218 glowingobsidian=246 reserved6=255 " +
        "iron_shovel=256 iron_pickaxe=257 iron_axe=258 flint_and_steel=259 apple=260 bow=261 arrow=262 coal=263 charcoal=263:1 diamond=264 " +
        "iron_ingot=265 gold_ingot=266 iron_sword=267 wooden_sword=268 wooden_shovel=269 wooden_pickaxe=270 wooden_axe=271 stone_sword=272 " +
        "stone_shovel=273 stone_pickaxe=274 stone_axe=275 diamond_sword=276 diamond_shovel=277 diamond_pickaxe=278 diamond_axe=279 stick=280 " +
        "bowl=281 mushroom_stew=282 golden_sword=283 gold_sword=283 golden_shovel=284 gold_shovel=284 golden_pickaxe=285 gold_pickaxe=285 " +
        "golden_axe=286 gold_axe=286 string=287 feather=288 gunpowder=289 wooden_hoe=290 stone_hoe=291 iron_hoe=292 diamond_hoe=293 " +
        "golden_hoe=294 gold_hoe=294 wheat_seeds=295 seeds=295 wheat=296 bread=297 leather_helmet=298 leather_chestplate=299 leather_leggings=300 " +
        "leather_boots=301 chainmail_helmet=302 chainmail_chestplate=303 chainmail_leggings=304 chainmail_boots=305 iron_helmet=306 " +
        "iron_chestplate=307 iron_leggings=308 iron_boots=309 diamond_helmet=310 diamond_chestplate=311 diamond_leggings=312 diamond_boots=313 " +
        "golden_helmet=314 gold_helmet=314 golden_chestplate=315 gold_chestplate=315 golden_leggings=316 gold_leggings=316 golden_boots=317 " +
        "gold_boots=317 flint=318 porkchop=319 cooked_porkchop=320 painting=321 golden_apple=322 sign=323 wooden_door=324 oak_door=324 bucket=325 " +
        "milk_bucket=325:1 water_bucket=326 lava_bucket=327 minecart=328 saddle=329 iron_door=330 redstone=331 snowball=332 boat=333 " +
        "leather=334 brick=336 clay_ball=337 sugarcane=338 reeds=338 paper=339 book=340 slime_ball=341 slimeball=341 chest_minecart=342 egg=344 " +
        "compass=345 fishing_rod=346 clock=347 glowstone_dust=348 fish=349 raw_fish=349 cooked_fish=350 dye=351 ink_sac=351 bone_meal=351:15 " +
        "bone=352 sugar=353 cake=354 bed=355 repeater=356 cookie=357 map=358 filled_map=358 shears=359 melon=360 pumpkin_seeds=361 " +
        "melon_seeds=362 beef=363 cooked_beef=364 steak=364 chicken=365 cooked_chicken=366 rotten_flesh=367 ender_pearl=368 blaze_rod=369 " +
        "ghast_tear=370 gold_nugget=371 nether_wart=372 potion=373 glass_bottle=374 spider_eye=375 fermented_spider_eye=376 blaze_powder=377 " +
        "magma_cream=378 brewing_stand=379 cauldron=380 ender_eye=381 speckled_melon=382 spawn_egg=383 experience_bottle=384 fire_charge=385 " +
        "emerald=388 item_frame=389 flower_pot=390 carrot=391 potato=392 baked_potato=393 poisonous_potato=394 empty_map=395 golden_carrot=396 " +
        "skull=397 carrot_on_a_stick=398 nether_star=399 pumpkin_pie=400 enchanted_book=403 comparator=404 netherbrick=405 quartz=406 " +
        "tnt_minecart=407 hopper_minecart=408 prismarine_shard=409 hopper=410 rabbit=411 cooked_rabbit=412 rabbit_stew=413 rabbit_foot=414 " +
        "rabbit_hide=415 leather_horse_armor=416 iron_horse_armor=417 golden_horse_armor=418 diamond_horse_armor=419 lead=420 name_tag=421 " +
        "prismarine_crystals=422 mutton=423 cooked_mutton=424 armor_stand=425 end_crystal=426 spruce_door=427 birch_door=428 jungle_door=429 " +
        "acacia_door=430 dark_oak_door=431 chorus_fruit=432 popped_chorus_fruit=433 dragon_breath=437 splash_potion=438 lingering_potion=441 " +
        "elytra=444 shulker_shell=445 totem=450 totem_of_undying=450 beetroot=457 beetroot_seeds=458 beetroot_soup=459 salmon=460 " +
        "clownfish=461 pufferfish=462 cooked_salmon=463 enchanted_golden_apple=466"

    private val map: Map<String, Pair<Int, Int>> by lazy {
        val m = HashMap<String, Pair<Int, Int>>()
        for (e in TABLE.split(' ')) {
            if (e.isEmpty()) continue
            val (k, v) = e.split('=')
            val p = v.split(':')
            m[k] = p[0].toInt() to (p.getOrNull(1)?.toInt() ?: 0)
        }
        m
    }

    // Список имён для подсказок
    val names: List<String> get() = map.keys.sorted()

    fun parse(text: String): Pair<Int, Int>? {
        var t = text.trim().lowercase().removePrefix("minecraft:")
        if (t.isEmpty()) return null
        var data: Int? = null
        val c = t.lastIndexOf(':')
        if (c > 0) {
            data = t.substring(c + 1).toIntOrNull() ?: return null
            t = t.substring(0, c)
        }
        val id = t.toIntOrNull()
        val base = if (id != null) (id to 0) else map[t] ?: map[t.replace(' ', '_')] ?: return null
        if (base.first !in 0..511) return null
        return base.first to (data ?: base.second).coerceIn(0, 32767)
    }

    fun name(id: Int, data: Int): String =
        map.entries.firstOrNull { it.value.first == id && it.value.second == data }?.key
            ?: map.entries.firstOrNull { it.value.first == id }?.key ?: id.toString()
}
