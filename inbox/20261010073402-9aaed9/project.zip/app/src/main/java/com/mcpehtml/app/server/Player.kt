package com.mcpehtml.app.server

import org.json.JSONArray
import org.json.JSONObject

class Player(val server: MineServer, val session: RakSession, val eid: Long) {
    var name = ""
    var uuidMsb = 0L
    var uuidLsb = 0L
    var skinId = "Standard_Custom"
    var skin = ByteArray(0)
    var loggedIn = false
    var spawned = false
    var closed = false

    var x = 0.0
    var y = 0.0   // ноги
    var z = 0.0
    var yaw = 0f
    var pitch = 0f
    var moved = false
    var onGround = true
    var sneaking = false
    var sprinting = false
    var gamemode = 1
    var savedGamemode = -1   // режим из сохранения игрока (-1 — ещё не заходил)
    var op = false
    var canBuild = true
    var flyAllowed = false   // /fly в выживании

    // Выживание
    var health = 20f
    var food = 20
    var saturation = 5f
    var exhaustion = 0f
    var dead = false
    var statsDirty = true
    var fallTop = Double.NaN      // высшая точка с момента отрыва от земли
    var hurtCooldown = 0          // тики неуязвимости после удара
    var regenTimer = 0
    var envTimer = 0
    var lastX = 0.0
    var lastZ = 0.0
    var bedSpawn: DoubleArray? = null
    var bedTime = -1000
    var lastDeath: DoubleArray? = null
    var lastAttacker: String? = null

    var chunkRadius = 4
    val sentChunks = HashSet<Long>()
    var radiusSet = false

    val inventory = arrayOfNulls<Item>(36)
    val armor = arrayOfNulls<Item>(4)
    val enderChest = arrayOfNulls<Item>(27)
    var held: Item = Item.AIR
    var selected = 0
    var heldSlot = 0           // ячейка инвентаря (0..35), которая сейчас в руке

    // Открытое окно (сундук, печь)
    var window: Containers.Window? = null
    val seenItems = HashSet<Long>()

    private val out = ArrayList<ByteArray>()
    private var outSize = 0

    val isLocal get() = session.peer.ip == "127.0.0.1" || session.peer.ip == "localhost"
    val survivalLike get() = gamemode == 0 || gamemode == 2
    val alive get() = spawned && !dead

    fun send(w: W) {
        if (closed) return
        val b = w.toBytes()
        out.add(b)
        outSize += b.size
        if (outSize > 256 * 1024) flush()
    }

    // Все пакеты за такт уходят одним сжатым batch-пакетом
    fun flush() {
        if (out.isEmpty() || closed) return
        val w = W(outSize + out.size * 5 + 16)
        for (b in out) w.bytes(b)
        out.clear()
        outSize = 0
        val z = Zlib.deflate(w.toBytes(), 6)
        val p = ByteArray(z.size + 1)
        p[0] = RakId.GAME.toByte()
        System.arraycopy(z, 0, p, 1, z.size)
        session.sendReliable(p)
    }

    // Многострочный текст — отдельными строками чата
    fun message(text: String) { for (line in text.split('\n')) send(Pk.new(Pk.TEXT).byte(Pk.TEXT_RAW).string(line)) }
    fun popup(text: String) = send(Pk.new(Pk.TEXT).byte(Pk.TEXT_TIP).string(text))
    fun title(text: String, sub: String) {
        if (sub.isNotEmpty()) send(Pk.new(Pk.SET_TITLE).varint(3).string(sub).varint(0).varint(0).varint(0))
        send(Pk.new(Pk.SET_TITLE).varint(2).string(text).varint(10).varint(60).varint(20))
    }

    fun flags(): Long {
        var f = (1L shl Meta.FLAG_CAN_SHOW_NAMETAG) or (1L shl Meta.FLAG_ALWAYS_SHOW_NAMETAG) or (1L shl Meta.FLAG_CAN_CLIMB) or (1L shl Meta.FLAG_BREATHING)
        if (sneaking) f = f or (1L shl Meta.FLAG_SNEAKING)
        if (sprinting) f = f or (1L shl Meta.FLAG_SPRINTING)
        if (gamemode == 3) f = f or (1L shl Meta.FLAG_INVISIBLE)
        return f
    }

    fun disconnect(reason: String) {
        if (closed) return
        send(Pk.new(Pk.DISCONNECT).bool(false).string(reason))
        flush()
        session.flush()
        server.removePlayer(this, reason)
        session.close(reason, true)
    }

    // ---------- Инвентарь ----------
    fun setSlot(i: Int, it: Item?) {
        inventory[i] = if (it == null || it.id == 0 || it.count <= 0) null else it
        send(Pk.new(Pk.CONTAINER_SET_SLOT).byte(Pk.WINDOW_INVENTORY).varint(i).varint(0).also { (inventory[i] ?: Item.AIR).write(it) }.byte(0))
        if (i == heldSlot) held = inventory[i] ?: Item.AIR
    }

    // Добавляет предметы в инвентарь (сначала к таким же стопкам); возвращает, сколько не влезло
    fun give(item: Item): Int {
        var left = item.count
        val max = Survival.maxStack(item.id)
        for (i in 0 until 36) {
            if (left <= 0) break
            val s = inventory[i] ?: continue
            if (s.id != item.id || s.data != item.data || s.count >= max || s.nbt.isNotEmpty() || item.nbt.isNotEmpty()) continue
            val n = minOf(left, max - s.count)
            setSlot(i, Item(s.id, s.data, s.count + n, s.nbt))
            left -= n
        }
        for (i in 0 until 36) {
            if (left <= 0) break
            if (inventory[i] != null) continue
            val n = minOf(left, max)
            setSlot(i, Item(item.id, item.data, n, item.nbt))
            left -= n
        }
        return left
    }

    fun count(id: Int, data: Int): Int = inventory.sumOf { if (it != null && it.id == id && (data < 0 || it.data == data)) it.count else 0 }

    // Забирает count предметов; false, если столько нет (тогда ничего не забирается)
    fun take(id: Int, data: Int, count: Int): Boolean {
        if (count(id, data) < count) return false
        var left = count
        for (i in 0 until 36) {
            if (left <= 0) break
            val s = inventory[i] ?: continue
            if (s.id != id || (data >= 0 && s.data != data)) continue
            val n = minOf(left, s.count)
            setSlot(i, if (s.count - n > 0) Item(s.id, s.data, s.count - n, s.nbt) else null)
            left -= n
        }
        return true
    }

    fun clearInventory() {
        for (i in 0 until 36) if (inventory[i] != null) setSlot(i, null)
        for (i in 0 until 4) armor[i] = null
        server.sendArmorAll(this)
    }

    // ---------- Сохранение ----------
    private fun items(a: Array<Item?>): JSONArray {
        val r = JSONArray()
        for (it in a) r.put(if (it == null || it.id == 0) JSONArray() else JSONArray().put(it.id).put(it.data).put(it.count))
        return r
    }

    private fun readItems(a: JSONArray?, into: Array<Item?>) {
        if (a == null) return
        for (i in 0 until minOf(into.size, a.length())) {
            val e = a.optJSONArray(i)
            into[i] = if (e != null && e.length() == 3) Item(e.getInt(0), e.getInt(1), e.getInt(2)) else null
        }
    }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("x", x); o.put("y", y); o.put("z", z); o.put("yaw", yaw.toDouble()); o.put("pitch", pitch.toDouble())
        o.put("inv", items(inventory))
        o.put("armor", items(armor))
        o.put("ender", items(enderChest))
        o.put("gm", gamemode)
        o.put("health", health.toDouble()); o.put("food", food); o.put("sat", saturation.toDouble())
        o.put("fly", flyAllowed)
        bedSpawn?.let { o.put("bed", JSONArray().put(it[0]).put(it[1]).put(it[2])) }
        lastDeath?.let { o.put("death", JSONArray().put(it[0]).put(it[1]).put(it[2])) }
        return o
    }

    fun fromJson(o: JSONObject) {
        x = o.optDouble("x", x); y = o.optDouble("y", y); z = o.optDouble("z", z)
        yaw = o.optDouble("yaw", 0.0).toFloat(); pitch = o.optDouble("pitch", 0.0).toFloat()
        readItems(o.optJSONArray("inv"), inventory)
        readItems(o.optJSONArray("armor"), armor)
        readItems(o.optJSONArray("ender"), enderChest)
        savedGamemode = o.optInt("gm", -1)
        health = o.optDouble("health", 20.0).toFloat().coerceIn(1f, 20f)
        food = o.optInt("food", 20).coerceIn(0, 20)
        saturation = o.optDouble("sat", 5.0).toFloat()
        flyAllowed = o.optBoolean("fly", false)
        o.optJSONArray("bed")?.let { if (it.length() == 3) bedSpawn = doubleArrayOf(it.getDouble(0), it.getDouble(1), it.getDouble(2)) }
        o.optJSONArray("death")?.let { if (it.length() == 3) lastDeath = doubleArrayOf(it.getDouble(0), it.getDouble(1), it.getDouble(2)) }
    }
}
