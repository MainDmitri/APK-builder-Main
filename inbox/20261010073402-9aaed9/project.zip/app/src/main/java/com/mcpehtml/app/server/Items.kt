package com.mcpehtml.app.server

import kotlin.math.abs
import kotlin.math.floor

// Выпавшие предметы: падают, лежат 5 минут, подбираются игроками
class Items(private val s: MineServer) {
    class Drop(val eid: Long, var item: Item, var x: Double, var y: Double, var z: Double, var vx: Double, var vy: Double, var vz: Double) {
        var age = 0
        var pickupDelay = 10
        var sx = x; var sy = y; var sz = z
        var picker: Player? = null
    }

    val list = LinkedHashMap<Long, Drop>()
    private val rnd = java.util.Random()

    private fun ck(x: Double, z: Double) = ((floor(x).toInt() shr 4).toLong() shl 32) or ((floor(z).toInt() shr 4).toLong() and 0xffffffffL)

    fun spawn(item: Item, x: Double, y: Double, z: Double, vx: Double, vy: Double, vz: Double, delay: Int): Drop? {
        if (item.id == 0 || item.count <= 0) return null
        while (list.size >= 500) remove(list.values.first(), null)
        val d = Drop(s.newEid(), item, x, y, z, vx, vy, vz)
        d.pickupDelay = delay
        list[d.eid] = d
        val k = ck(x, z)
        for (p in s.players.values) if (p.spawned && p.sentChunks.contains(k)) show(p, d)
        return d
    }

    // Предметы из сломанного блока: в центре блока с небольшим разлётом
    fun dropBlock(x: Int, y: Int, z: Int, items: List<Item>) {
        for (it in items) spawn(it, x + 0.25 + rnd.nextDouble() * 0.5, y + 0.25 + rnd.nextDouble() * 0.5, z + 0.25 + rnd.nextDouble() * 0.5,
            (rnd.nextDouble() - 0.5) * 0.2, 0.2, (rnd.nextDouble() - 0.5) * 0.2, 10)
    }

    private fun show(p: Player, d: Drop) {
        if (!p.seenItems.add(d.eid)) return
        val w = Pk.new(Pk.ADD_ITEM_ENTITY).varlong(d.eid).varlong(d.eid)
        d.item.write(w)
        w.vec3(d.x.toFloat(), d.y.toFloat(), d.z.toFloat()).vec3(d.vx.toFloat(), d.vy.toFloat(), d.vz.toFloat())
        p.send(w)
    }

    private fun remove(d: Drop, picker: Player?) {
        list.remove(d.eid)
        for (p in s.players.values) {
            if (!p.seenItems.remove(d.eid)) continue
            if (picker != null) p.send(Pk.new(Pk.TAKE_ITEM_ENTITY).varlong(d.eid).varlong(picker.eid))
            p.send(Pk.new(Pk.REMOVE_ENTITY).varlong(d.eid))
        }
    }

    // Показать игроку предметы в загруженных им чанках и скрыть остальные
    fun sync(p: Player) {
        for (d in list.values) {
            val has = p.sentChunks.contains(ck(d.x, d.z))
            if (has && !p.seenItems.contains(d.eid)) show(p, d)
            else if (!has && p.seenItems.remove(d.eid)) p.send(Pk.new(Pk.REMOVE_ENTITY).varlong(d.eid))
        }
    }

    private fun solidAt(x: Double, y: Double, z: Double): Boolean {
        val bx = floor(x).toInt(); val by = floor(y).toInt(); val bz = floor(z).toInt()
        if (by < 0 || by > 255) return false
        if (!s.world.isLoaded(bx shr 4, bz shr 4)) return true
        return Blocks.solid[s.world.getId(bx, by, bz)]
    }

    fun tick() {
        val gone = ArrayList<Drop>()
        for (d in list.values) {
            d.age++
            if (d.pickupDelay > 0) d.pickupDelay--
            if (d.age > 6000 || d.y < -64) { gone.add(d); continue }
            if (!s.world.isLoaded(floor(d.x).toInt() shr 4, floor(d.z).toInt() shr 4)) continue
            // Внутри блока (например, поставили блок на предмет) — выталкиваем вверх
            if (solidAt(d.x, d.y + 0.1, d.z)) { d.y = floor(d.y + 0.1) + 1.0; d.vy = 0.0 }
            d.vy -= 0.04
            val ny = d.y + d.vy
            if (d.vy < 0 && solidAt(d.x, ny, d.z)) { d.y = floor(ny) + 1.0; d.vy = 0.0; d.vx *= 0.5; d.vz *= 0.5 } else d.y = ny
            val nx = d.x + d.vx
            if (solidAt(nx, d.y + 0.1, d.z)) d.vx = 0.0 else d.x = nx
            val nz = d.z + d.vz
            if (solidAt(d.x, d.y + 0.1, nz)) d.vz = 0.0 else d.z = nz
            d.vx *= 0.98; d.vz *= 0.98; d.vy *= 0.98
            if (abs(d.x - d.sx) + abs(d.y - d.sy) + abs(d.z - d.sz) > 0.05 && d.age % 2 == 0) {
                d.sx = d.x; d.sy = d.y; d.sz = d.z
                val pk = Pk.new(Pk.MOVE_ENTITY).varlong(d.eid).vec3(d.x.toFloat(), d.y.toFloat(), d.z.toFloat()).byte(0).byte(0).byte(0).bool(d.vy == 0.0).bool(false).toBytes()
                for (p in s.players.values) if (p.seenItems.contains(d.eid)) p.send(W(pk.size).raw(pk))
            }
            if (d.pickupDelay > 0) continue
            for (p in s.players.values) {
                if (!p.alive || p.gamemode == 3) continue
                if (abs(p.x - d.x) > 1.5 || abs(p.z - d.z) > 1.5 || d.y < p.y - 1.0 || d.y > p.y + 2.3) continue
                if (s.plugins.emit("pickup", mapOf("player" to p, "id" to d.item.id, "data" to d.item.data, "count" to d.item.count))) continue
                val left = p.give(d.item)
                if (left == d.item.count) continue
                if (left > 0) {
                    d.item = Item(d.item.id, d.item.data, left, d.item.nbt)
                    for (o in s.players.values) if (o.seenItems.remove(d.eid)) o.send(Pk.new(Pk.REMOVE_ENTITY).varlong(d.eid))
                    for (o in s.players.values) if (o.spawned && o.sentChunks.contains(ck(d.x, d.z))) show(o, d)
                    continue
                }
                d.picker = p
                gone.add(d)
                break
            }
        }
        for (d in gone) remove(d, d.picker)
    }

    fun clear(): Int {
        val n = list.size
        for (d in list.values.toList()) remove(d, null)
        return n
    }
}
