package com.mcpehtml.app.server

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.floor

// Команды сервера. Отправитель null — консоль (экран сервера, плагины): у неё права оператора
class Commands(private val s: MineServer) {
    private class Cmd(val name: String, val usage: String, val desc: String, val op: Boolean, val aliases: List<String>, val run: (Player?, List<String>) -> Unit)

    private val list = ArrayList<Cmd>()

    private fun add(name: String, usage: String, desc: String, op: Boolean, vararg aliases: String, run: (Player?, List<String>) -> Unit) {
        list.add(Cmd(name, usage, desc, op, aliases.toList(), run))
    }

    private fun reply(p: Player?, text: String) { if (p != null) p.message(text) else s.log(text.replace(Regex("§."), "")) }

    // Цель команды: указанный игрок или сам отправитель
    private fun target(p: Player?, a: List<String>, i: Int): Player? {
        val n = a.getOrNull(i)
        if (n == null) { if (p == null) reply(null, "Укажите игрока"); return p }
        val t = if (n == "@s" || n == "@p") p else s.findPlayer(n)
        if (t == null) reply(p, "§cИгрок $n не в сети")
        return t
    }

    private fun parseGamemode(t: String): Int? = when (t.lowercase()) {
        "0", "s", "survival", "выживание" -> 0
        "1", "c", "creative", "творческий", "креатив" -> 1
        "2", "a", "adventure", "приключение" -> 2
        "3", "sp", "spectator", "наблюдатель" -> 3
        else -> null
    }

    private val modeNames = arrayOf("выживание", "творческий", "приключение", "наблюдатель")

    init {
        add("help", "[страница]", "Список команд", false, "?") { p, a ->
            val op = p?.op ?: true
            val all = ArrayList<String>()
            for (c in list) if (!c.op || op) all.add("§a/${c.name}${if (c.usage.isEmpty()) "" else " " + c.usage} §7— ${c.desc}")
            for (c in s.plugins.commands.values) if (!c.op || op) all.add("§b/${c.name}${if (c.usage.isEmpty()) "" else " " + c.usage} §7— ${c.description} §8[${c.plugin.name}]")
            val per = 8
            val pages = (all.size + per - 1) / per
            val page = (a.getOrNull(0)?.toIntOrNull() ?: 1).coerceIn(1, maxOf(1, pages))
            reply(p, "§eКоманды ($page/$pages), дальше: /help ${page % pages + 1}")
            for (l in all.drop((page - 1) * per).take(per)) reply(p, l)
        }
        add("list", "", "Кто в игре", false) { p, _ ->
            val n = s.onlineNames()
            reply(p, "§eВ игре ${n.size}/${s.cfg.maxPlayers}: §f${n.joinToString(", ")}")
        }
        add("spawn", "", "Телепорт на точку появления", false) { p, _ ->
            if (p == null) return@add
            val sp = s.spawnPos()
            s.teleport(p, sp[0], sp[1], sp[2])
            reply(p, "§aВы на точке появления")
        }
        add("me", "<действие>", "Действие от третьего лица", false) { p, a ->
            if (a.isEmpty()) { reply(p, "§cИспользование: /me <действие>"); return@add }
            s.broadcastMessage("§d* ${p?.name ?: "Сервер"} ${a.joinToString(" ")}")
        }
        add("tell", "<игрок> <сообщение>", "Личное сообщение", false, "msg", "w") { p, a ->
            if (a.size < 2) { reply(p, "§cИспользование: /tell <игрок> <сообщение>"); return@add }
            val t = s.findPlayer(a[0]) ?: run { reply(p, "§cИгрок ${a[0]} не в сети"); return@add }
            val msg = a.drop(1).joinToString(" ")
            t.message("§7${p?.name ?: "Сервер"} шепчет вам: $msg")
            reply(p, "§7Вы шепчете ${t.name}: $msg")
        }
        add("seed", "", "Зерно мира", false) { p, _ -> reply(p, "§eЗерно мира: §f${s.cfg.seed}") }
        add("plugins", "", "Установленные плагины", false, "pl") { p, _ ->
            val pl = s.plugins.list
            if (pl.isEmpty()) { reply(p, "§eПлагинов нет"); return@add }
            reply(p, "§eПлагины (${pl.size}): " + pl.joinToString("§f, ") { (if (it.error == null) "§a" else "§c") + it.name })
        }
        add("kill", "[игрок]", "Убить себя или игрока", false) { p, a ->
            if (a.isNotEmpty() && p != null && !p.op) { reply(p, "§cУбить другого игрока может только оператор"); return@add }
            val t = target(p, a, 0) ?: return@add
            s.die(t, "kill", null)
        }
        add("gamemode", "<0|1|2|3> [игрок]", "Режим игры: 0 выживание, 1 творческий, 2 приключение, 3 наблюдатель", true, "gm") { p, a ->
            val gm = a.getOrNull(0)?.let { parseGamemode(it) } ?: run { reply(p, "§cИспользование: /gamemode <0|1|2|3> [игрок]"); return@add }
            val t = target(p, a, 1) ?: return@add
            s.setGamemode(t, gm)
            t.message("§aВаш режим игры: ${modeNames[gm]}")
            if (t !== p) reply(p, "§aРежим ${t.name}: ${modeNames[gm]}")
        }
        add("give", "<игрок> <предмет> [количество] [вариант]", "Выдать предмет (номер или название: diamond, 276, 35:14)", true, "i") { p, a ->
            if (a.size < 2) { reply(p, "§cИспользование: /give <игрок> <предмет> [количество] [вариант]"); return@add }
            val t = target(p, a, 0) ?: return@add
            val it = ItemNames.parse(a[1]) ?: run { reply(p, "§cНеизвестный предмет: ${a[1]}"); return@add }
            val count = (a.getOrNull(2)?.toIntOrNull() ?: 1).coerceIn(1, 64 * 36)
            val data = a.getOrNull(3)?.toIntOrNull() ?: it.second
            val left = t.give(Item(it.first, data, count))
            reply(p, "§aВыдано ${t.name}: ${it.first}:$data × ${count - left}" + if (left > 0) " §7(не влезло $left)" else "")
        }
        add("clear", "[игрок]", "Очистить инвентарь", true) { p, a ->
            val t = target(p, a, 0) ?: return@add
            t.clearInventory()
            reply(p, "§aИнвентарь ${t.name} очищен")
        }
        add("heal", "[игрок]", "Вылечить", true) { p, a ->
            val t = target(p, a, 0) ?: return@add
            s.setHealth(t, 20f); t.food = 20; t.saturation = 5f; t.statsDirty = true
            t.message("§aВы вылечены")
        }
        add("feed", "[игрок]", "Накормить", true) { p, a ->
            val t = target(p, a, 0) ?: return@add
            t.food = 20; t.saturation = 5f; t.statsDirty = true
            t.message("§aВы сыты")
        }
        add("fly", "[игрок]", "Включить или выключить полёт", true) { p, a ->
            val t = target(p, a, 0) ?: return@add
            s.setFly(t, !t.flyAllowed)
            t.message(if (t.flyAllowed) "§aПолёт включён: дважды нажмите прыжок" else "§eПолёт выключен")
        }
        add("tp", "<игрок> | <x> <y> <z> | <игрок> <игрок> | <игрок> <x> <y> <z>", "Телепорт", true, "teleport") { p, a ->
            when (a.size) {
                1 -> {
                    if (p == null) return@add
                    val t = s.findPlayer(a[0]) ?: run { reply(p, "§cИгрок ${a[0]} не в сети"); return@add }
                    s.teleport(p, t.x, t.y, t.z); reply(p, "§aТелепорт к ${t.name}")
                }
                2 -> {
                    val f = s.findPlayer(a[0]) ?: run { reply(p, "§cИгрок ${a[0]} не в сети"); return@add }
                    val t = s.findPlayer(a[1]) ?: run { reply(p, "§cИгрок ${a[1]} не в сети"); return@add }
                    s.teleport(f, t.x, t.y, t.z); reply(p, "§a${f.name} перемещён к ${t.name}")
                }
                3, 4 -> {
                    val who = if (a.size == 4) s.findPlayer(a[0]) else p
                    if (who == null) { reply(p, "§cИгрок не найден"); return@add }
                    val o = a.size - 3
                    val x = coord(a[o], who.x); val y = coord(a[o + 1], who.y); val z = coord(a[o + 2], who.z)
                    if (x == null || y == null || z == null || y < -64 || y > 320) { reply(p, "§cНеверные координаты"); return@add }
                    s.teleport(who, x, y, z); reply(p, "§a${who.name} → ${fmt(x)} ${fmt(y)} ${fmt(z)}")
                }
                else -> reply(p, "§cИспользование: /tp <игрок> или /tp <x> <y> <z>")
            }
        }
        add("setspawn", "", "Точка появления мира здесь", true, "setworldspawn") { p, _ ->
            if (p == null) return@add
            s.setSpawn(floor(p.x) + 0.5, p.y, floor(p.z) + 0.5)
            reply(p, "§aТочка появления мира: ${floor(p.x).toInt()} ${floor(p.y).toInt()} ${floor(p.z).toInt()}")
        }
        add("spawnpoint", "[игрок]", "Личная точка возрождения здесь", true) { p, a ->
            val t = target(p, a, 0) ?: return@add
            t.bedSpawn = doubleArrayOf(t.x, t.y, t.z)
            t.message("§aТочка возрождения установлена")
        }
        add("time", "<set|add> <день|ночь|число> | query", "Время суток", true) { p, a ->
            var args = a
            var add = false
            when (args.getOrNull(0)?.lowercase()) {
                "set" -> args = args.drop(1)
                "add" -> { add = true; args = args.drop(1) }
                "query" -> { reply(p, "§eВремя: ${s.time % 24000}, день ${s.time / 24000 + 1}"); return@add }
            }
            val v = when (args.getOrNull(0)?.lowercase()) {
                "day", "день" -> 1000
                "noon", "полдень" -> 6000
                "night", "ночь" -> 13000
                "midnight", "полночь" -> 18000
                null -> { reply(p, "§eВремя: ${s.time % 24000}"); return@add }
                else -> args[0].toIntOrNull()
            }
            if (v == null || v < 0) { reply(p, "§cИспользование: /time set day|night|число"); return@add }
            s.setWorldTime(if (add) s.time + v else s.time - s.time % 24000 + v)
            reply(p, "§aВремя установлено")
        }
        add("difficulty", "<0|1|2|3>", "Сложность: мирная, лёгкая, нормальная, сложная", true) { p, a ->
            val d = when (a.getOrNull(0)?.lowercase()) {
                "0", "p", "peaceful", "мирная" -> 0
                "1", "e", "easy", "лёгкая", "легкая" -> 1
                "2", "n", "normal", "нормальная" -> 2
                "3", "h", "hard", "сложная" -> 3
                else -> { reply(p, "§eСложность: ${s.difficulty}. Использование: /difficulty 0..3"); return@add }
            }
            s.changeDifficulty(d)
            reply(p, "§aСложность: $d")
        }
        add("gamerule", "<правило> [true|false]", "Правила: keepInventory, pvp, fallDamage, naturalRegeneration, doDaylightCycle, showDeathMessages", true) { p, a ->
            val k = MineServer.RULES.firstOrNull { it.equals(a.getOrNull(0), true) }
            if (k == null) { reply(p, "§eПравила: " + s.rules.entries.joinToString(", ") { "${it.key}=${it.value}" }); return@add }
            val v = a.getOrNull(1)?.lowercase()
            if (v == null) { reply(p, "§e$k = ${s.rules[k]}"); return@add }
            if (v != "true" && v != "false") { reply(p, "§cЗначение: true или false"); return@add }
            s.setRule(k, v == "true")
            reply(p, "§a$k = $v")
        }
        add("setblock", "<x> <y> <z> <блок> [вариант]", "Поставить блок", true) { p, a ->
            if (a.size < 4) { reply(p, "§cИспользование: /setblock x y z блок [вариант]"); return@add }
            val x = coord(a[0], p?.x ?: 0.0); val y = coord(a[1], p?.y ?: 0.0); val z = coord(a[2], p?.z ?: 0.0)
            val b = ItemNames.parse(a[3])
            if (x == null || y == null || z == null || b == null || b.first > 255) { reply(p, "§cНеверные координаты или блок"); return@add }
            s.setBlock(floor(x).toInt(), floor(y).toInt(), floor(z).toInt(), b.first, a.getOrNull(4)?.toIntOrNull() ?: b.second)
            reply(p, "§aБлок поставлен")
        }
        add("fill", "<x1> <y1> <z1> <x2> <y2> <z2> <блок> [вариант]", "Заполнить область (до 32768 блоков)", true) { p, a ->
            if (a.size < 7) { reply(p, "§cИспользование: /fill x1 y1 z1 x2 y2 z2 блок [вариант]"); return@add }
            val c = (0 until 6).map { i -> coord(a[i], when (i % 3) { 0 -> p?.x ?: 0.0; 1 -> p?.y ?: 0.0; else -> p?.z ?: 0.0 })?.let { floor(it).toInt() } }
            val b = ItemNames.parse(a[6])
            if (c.any { it == null } || b == null || b.first > 255) { reply(p, "§cНеверные координаты или блок"); return@add }
            val x1 = minOf(c[0]!!, c[3]!!); val x2 = maxOf(c[0]!!, c[3]!!)
            val y1 = maxOf(0, minOf(c[1]!!, c[4]!!)); val y2 = minOf(255, maxOf(c[1]!!, c[4]!!))
            val z1 = minOf(c[2]!!, c[5]!!); val z2 = maxOf(c[2]!!, c[5]!!)
            val n = (x2 - x1 + 1).toLong() * (y2 - y1 + 1) * (z2 - z1 + 1)
            if (n > 32768) { reply(p, "§cСлишком большая область: $n блоков (можно до 32768)"); return@add }
            val data = a.getOrNull(7)?.toIntOrNull() ?: b.second
            for (x in x1..x2) for (y in y1..y2) for (z in z1..z2) s.setBlock(x, y, z, b.first, data)
            reply(p, "§aЗаполнено блоков: $n")
        }
        add("clearitems", "", "Убрать все выпавшие предметы", true, "killitems") { p, _ -> reply(p, "§aУбрано предметов: ${s.items.clear()}") }
        add("say", "<сообщение>", "Объявление всем", true) { p, a ->
            if (a.isEmpty()) { reply(p, "§cИспользование: /say <сообщение>"); return@add }
            s.broadcastMessage("§d[${p?.name ?: "Сервер"}] ${a.joinToString(" ")}")
        }
        add("kick", "<игрок> [причина]", "Выгнать игрока", true) { p, a ->
            val t = a.getOrNull(0)?.let { s.findPlayer(it) } ?: run { reply(p, "§cИгрок не в сети"); return@add }
            val reason = if (a.size > 1) a.drop(1).joinToString(" ") else "Вас выгнали с сервера"
            t.disconnect(reason)
            s.broadcastMessage("§e${t.name} выгнан: $reason")
        }
        add("ban", "<игрок>", "Забанить игрока", true) { p, a ->
            val n = a.getOrNull(0) ?: run { reply(p, "§cИспользование: /ban <игрок>"); return@add }
            val found = s.findPlayer(n)
            if (found?.isLocal == true) { reply(p, "§cНельзя забанить владельца"); return@add }
            val name = found?.name ?: n
            s.ban(name); s.broadcastMessage("§e$name забанен")
        }
        add("unban", "<игрок>", "Снять бан", true, "pardon") { p, a ->
            val n = a.getOrNull(0) ?: run { reply(p, "§cИспользование: /unban <игрок>"); return@add }
            s.unban(n); reply(p, "§a$n разбанен")
        }
        add("op", "<игрок>", "Дать права оператора", true) { p, a ->
            val n = a.getOrNull(0) ?: run { reply(p, "§cИспользование: /op <игрок>"); return@add }
            val name = s.findPlayer(n)?.name ?: n
            s.setOp(name, true); reply(p, "§a$name теперь оператор")
            s.findPlayer(name)?.message("§aВы стали оператором сервера")
        }
        add("deop", "<игрок>", "Забрать права оператора", true) { p, a ->
            val n = a.getOrNull(0) ?: run { reply(p, "§cИспользование: /deop <игрок>"); return@add }
            val name = s.findPlayer(n)?.name ?: n
            s.setOp(name, false); reply(p, "§a$name больше не оператор")
        }
        add("build", "<игрок>", "Разрешить строить", true) { p, a ->
            val n = a.getOrNull(0) ?: run { reply(p, "§cИспользование: /build <игрок>"); return@add }
            val name = s.findPlayer(n)?.name ?: n
            s.setBuilder(name, true); reply(p, "§a$name может строить")
            s.findPlayer(name)?.message("§aВам разрешили строить")
        }
        add("unbuild", "<игрок>", "Запретить строить", true) { p, a ->
            val n = a.getOrNull(0) ?: run { reply(p, "§cИспользование: /unbuild <игрок>"); return@add }
            val name = s.findPlayer(n)?.name ?: n
            s.setBuilder(name, false); reply(p, "§a$name больше не может строить (если гостям строить нельзя)")
        }
        add("whitelist", "<on|off|add|remove|list> [игрок]", "Белый список", true) { p, a ->
            when (a.getOrNull(0)?.lowercase()) {
                "on" -> { s.setWhitelist(true); reply(p, "§aБелый список включён") }
                "off" -> { s.setWhitelist(false); reply(p, "§aБелый список выключен") }
                "add" -> { val n = a.getOrNull(1) ?: return@add reply(p, "§cУкажите ник"); s.allow(n, true); reply(p, "§a$n добавлен в белый список") }
                "remove" -> { val n = a.getOrNull(1) ?: return@add reply(p, "§cУкажите ник"); s.allow(n, false); reply(p, "§a$n убран из белого списка") }
                "list" -> reply(p, "§eБелый список (${if (s.cfg.whitelist) "вкл" else "выкл"}): §f${s.lists()["whitelist"]!!.joinToString(", ")}")
                else -> reply(p, "§cИспользование: /whitelist on|off|add|remove|list")
            }
        }
        add("reload", "", "Перезагрузить плагины", true) { p, _ -> s.requestReload(); reply(p, "§aПлагины перезагружаются…") }
        add("save", "", "Сохранить мир", true, "save-all") { p, _ -> s.saveAll(); reply(p, "§aМир сохранён") }
        add("stop", "", "Остановить сервер", true) { _, _ -> s.broadcastMessage("§cСервер останавливается"); Thread { s.stop() }.start() }
    }

    private fun coord(t: String, base: Double): Double? =
        if (t.startsWith("~")) (if (t.length == 1) 0.0 else t.substring(1).toDoubleOrNull())?.plus(base) else t.toDoubleOrNull()

    private fun fmt(v: Double) = String.format(java.util.Locale.US, "%.1f", v)

    private fun find(name: String): Cmd? = list.firstOrNull { it.name == name } ?: list.firstOrNull { name in it.aliases }

    fun run(p: Player?, line: String) {
        val parts = line.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (parts.isEmpty()) return
        val name = parts[0].lowercase().removePrefix("/")
        val args = parts.drop(1)
        val isOp = p?.op ?: true
        if (p != null && s.plugins.emit("command", mapOf("player" to p, "command" to name, "line" to line))) return
        val c = find(name)
        if (c != null) {
            if (c.op && !isOp) { reply(p, "§cЭта команда только для операторов"); return }
            s.log("${p?.name ?: "Консоль"}: /$line")
            c.run(p, args)
            return
        }
        val pc = s.plugins.find(name)
        if (pc != null) {
            if (pc.op && !isOp) { reply(p, "§cЭта команда только для операторов"); return }
            s.plugins.runCommand(p, pc, args, line)
            return
        }
        reply(p, "§cНеизвестная команда. Список: /help")
    }

    // Список команд для подсказок клиента (AvailableCommandsPacket протокола 113)
    fun json(p: Player): String {
        val o = JSONObject()
        fun put(name: String, desc: String, aliases: List<String>) {
            val param = JSONObject().put("name", "args").put("type", "rawtext").put("optional", true)
            val overload = JSONObject()
                .put("input", JSONObject().put("parameters", JSONArray().put(param)))
                .put("output", JSONObject())
            val ver = JSONObject()
                .put("aliases", JSONArray(aliases))
                .put("description", desc)
                .put("overloads", JSONObject().put("default", overload))
                .put("permission", "any")
            o.put(name, JSONObject().put("versions", JSONArray().put(ver)))
        }
        for (c in list) if (!c.op || p.op) put(c.name, c.desc, c.aliases)
        for (c in s.plugins.commands.values) if ((!c.op || p.op) && !o.has(c.name)) put(c.name, c.description, c.aliases)
        return o.toString()
    }
}
