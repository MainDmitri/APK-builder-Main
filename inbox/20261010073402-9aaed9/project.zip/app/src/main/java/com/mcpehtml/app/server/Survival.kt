package com.mcpehtml.app.server

import java.util.Random

// Правила выживания на сервере: инструменты, броня, еда, выпадение блоков, рецепты и переплавка (как в одиночной игре клиента)
object Survival {
    class Tool(val type: Int, val tier: Int, val durability: Int, val damage: Int)
    class Food(val hunger: Int, val saturation: Float, val remainder: Int)
    class Recipe(val shaped: Boolean, val w: Int, val h: Int, val input: List<Item>, val out: Item, val uuid: ByteArray)

    const val T_PICKAXE = 1
    const val T_AXE = 2
    const val T_SHOVEL = 3
    const val T_SHEARS = 4
    const val T_SWORD = 5
    const val T_HOE = 6

    private fun pairs(s: String) = s.split(' ').filter { it.isNotEmpty() }.map { it.split(':') }

    val tools: Map<Int, Tool> = pairs(SurvivalData.TOOLS).associate { it[0].toInt() to Tool(it[1].toInt(), it[2].toInt(), it[3].toInt(), it[4].toInt()) }
    // id → [ячейка, очки защиты, прочность]
    val armorInfo: Map<Int, IntArray> = pairs(SurvivalData.ARMOR).associate { it[0].toInt() to intArrayOf(it[1].toInt(), it[2].toInt(), it[3].toInt()) }
    val food: Map<Int, Food> = pairs(SurvivalData.FOOD).associate { it[0].toInt() to Food(it[1].toInt(), it[2].toFloat(), it[3].toInt()) }
    val fuel: Map<Int, Double> = pairs(SurvivalData.FUEL).associate { it[0].toInt() to it[1].toDouble() }
    private val smelt: List<IntArray> = pairs(SurvivalData.SMELT).map { intArrayOf(it[0].toInt(), it[1].toInt(), it[2].toInt(), it[3].toInt()) }
    private val one = SurvivalData.ONE.split(' ').map { it.toInt() }.toHashSet()
    private val sixteen = SurvivalData.SIXTEEN.split(' ').map { it.toInt() }.toHashSet()
    private val needTier: Map<Int, Int> = pairs(SurvivalData.NEED_TIER).associate { it[0].toInt() to it[1].toInt() }
    private val blockTool = IntArray(256) { SurvivalData.BLOCK_TOOL[it] - '0' }
    private val blockHand = BooleanArray(256) { SurvivalData.BLOCK_HAND[it] == '1' }
    val hardness = SurvivalData.HARDNESS.split(' ').map { it.toDouble() }.toDoubleArray()

    fun maxStack(id: Int) = if (one.contains(id)) 1 else if (sixteen.contains(id)) 16 else 64
    fun hasDurability(id: Int) = tools.containsKey(id) || armorInfo.containsKey(id)
    fun durability(id: Int) = tools[id]?.durability ?: armorInfo[id]?.get(2) ?: 0
    fun attackDamage(id: Int) = tools[id]?.damage ?: 1

    fun armorPoints(armor: Array<Item?>): Int = minOf(20, armor.sumOf { if (it == null) 0 else armorInfo[it.id]?.get(1) ?: 0 })

    fun canHarvest(id: Int, toolId: Int): Boolean {
        if (id !in 0..255 || blockHand[id] || blockTool[id] == 0) return true
        val t = tools[toolId] ?: return false
        if (t.type != blockTool[id]) return false
        return t.tier >= (needTier[id] ?: 1)
    }

    // Подходит ли инструмент к блоку (такой инструмент изнашивается на 1, другой — на 2)
    fun rightTool(id: Int, toolId: Int): Boolean = id in 0..255 && tools[toolId]?.type == blockTool[id]

    private val rnd = Random()
    private fun r(a: Int, b: Int) = a + rnd.nextInt(b - a + 1)
    private fun mk(id: Int, d: Int, c: Int) = Item(id, d, c)

    fun drops(id: Int, data: Int, toolId: Int): List<Item> {
        if (!canHarvest(id, toolId)) return emptyList()
        val shears = tools[toolId]?.type == T_SHEARS
        val chance = { p: Double -> rnd.nextDouble() < p }
        return when (id) {
            0, 7, 8, 9, 10, 11, 20, 51, 52, 79, 90, 95, 102, 160, 92, 217, 250 -> emptyList()
            1 -> listOf(mk(if (data == 0) 4 else 1, data, 1))
            2, 60, 110, 198, 243 -> listOf(mk(3, 0, 1))
            13 -> listOf(if (chance(0.1)) mk(318, 0, 1) else mk(13, 0, 1))
            16 -> listOf(mk(263, 0, 1))
            17 -> listOf(mk(17, data and 3, 1))
            162 -> listOf(mk(162, data and 1, 1))
            18, 161 -> {
                if (shears) listOf(mk(id, data and 3, 1)) else {
                    val out = ArrayList<Item>()
                    if (chance(0.05)) out.add(mk(6, if (id == 161) 4 + (data and 1) else data and 3, 1))
                    if (id == 18 && (data and 3) == 0 && chance(0.005)) out.add(mk(260, 0, 1))
                    out
                }
            }
            21 -> listOf(mk(351, 4, r(4, 8)))
            26 -> if (data and 8 != 0) emptyList() else listOf(mk(355, 0, 1))
            31 -> if (shears) listOf(mk(31, data, 1)) else if (chance(0.125)) listOf(mk(295, 0, 1)) else emptyList()
            32 -> if (shears) listOf(mk(32, 0, 1)) else r(0, 2).let { n -> if (n > 0) listOf(mk(280, 0, n)) else emptyList() }
            43 -> listOf(mk(44, data and 7, 2))
            44 -> listOf(mk(44, data and 7, 1))
            157 -> listOf(mk(158, data and 7, 2))
            158 -> listOf(mk(158, data and 7, 1))
            47 -> listOf(mk(340, 0, 3))
            55 -> listOf(mk(331, 0, 1))
            56 -> listOf(mk(264, 0, 1))
            59 -> if (data >= 7) listOf(mk(296, 0, 1), mk(295, 0, r(1, 3))) else listOf(mk(295, 0, 1))
            62 -> listOf(mk(61, 0, 1))
            63, 68 -> listOf(mk(323, 0, 1))
            64 -> if (data and 8 != 0) emptyList() else listOf(mk(324, 0, 1))
            71 -> if (data and 8 != 0) emptyList() else listOf(mk(330, 0, 1))
            73, 74 -> listOf(mk(331, 0, r(4, 5)))
            75, 76 -> listOf(mk(76, 0, 1))
            78 -> listOf(mk(332, 0, 1))
            80 -> listOf(mk(332, 0, 4))
            82 -> listOf(mk(337, 0, 4))
            83 -> listOf(mk(338, 0, 1))
            89 -> listOf(mk(348, 0, r(2, 4)))
            93, 94 -> listOf(mk(356, 0, 1))
            103 -> listOf(mk(360, 0, r(3, 7)))
            104, 105 -> listOf(mk(if (id == 104) 361 else 362, 0, r(1, 3)))
            106 -> if (shears) listOf(mk(106, 0, 1)) else emptyList()
            115 -> listOf(mk(372, 0, if (data >= 3) r(2, 4) else 1))
            117 -> listOf(mk(379, 0, 1))
            118 -> listOf(mk(380, 0, 1))
            124 -> listOf(mk(123, 0, 1))
            127 -> listOf(mk(351, 3, if (data >= 8) 3 else 1))
            129 -> listOf(mk(388, 0, 1))
            140 -> listOf(mk(390, 0, 1))
            141 -> listOf(mk(391, 0, if (data >= 7) r(1, 4) else 1))
            142 -> listOf(mk(392, 0, if (data >= 7) r(1, 4) else 1))
            149, 150 -> listOf(mk(404, 0, 1))
            153 -> listOf(mk(406, 0, 1))
            178 -> listOf(mk(151, 0, 1))
            175 -> if (data and 8 != 0) emptyList() else listOf(mk(175, data and 7, 1))
            193, 194, 195, 196, 197 -> if (data and 8 != 0) emptyList() else listOf(mk(427 + id - 193, 0, 1))
            244 -> if (data >= 7) listOf(mk(457, 0, 1), mk(458, 0, r(1, 3))) else listOf(mk(458, 0, 1))
            else -> if (id !in 0..255 || !Blocks.exists[id]) emptyList() else listOf(mk(id, if (Blocks.variants[id] > 1) data else 0, 1))
        }
    }

    fun smeltResult(item: Item?): Item? {
        if (item == null || item.id == 0) return null
        val e = smelt.firstOrNull { it[0] == item.id && (it[1] < 0 || it[1] == item.data) } ?: return null
        return Item(e[2], e[3], 1)
    }

    // ---------- Рецепты ----------
    val recipes: List<Recipe> by lazy {
        val list = ArrayList<Recipe>()
        var n = 0
        for (line in SurvivalData.RECIPES.split('\n')) {
            val parts = line.split('|')
            if (parts.size != 3) continue
            val cells = parts[1].split(';').map { c -> val a = c.split(','); Item(a[0].toInt(), a[1].toInt(), if (a[0] == "0") 0 else 1) }
            val o = parts[2].split(',')
            val out = Item(o[0].toInt(), o[1].toInt(), o[2].toInt())
            val u = java.util.UUID.nameUUIDFromBytes("mcpehtml-recipe-${n++}".toByteArray())
            val uuid = W(16).uuid(u.mostSignificantBits, u.leastSignificantBits).toBytes()
            if (parts[0].startsWith("S")) {
                val wh = parts[0].substring(1).split('x')
                list.add(Recipe(true, wh[0].toInt(), wh[1].toInt(), cells, out, uuid))
            } else list.add(Recipe(false, 0, 0, cells, out, uuid))
        }
        list
    }

    fun recipe(uuid: ByteArray): Recipe? = recipes.firstOrNull { it.uuid.contentEquals(uuid) }

    // Пакет CraftingData: без него клиент MCPE не может ничего скрафтить
    val craftingPacket: ByteArray by lazy {
        val w = Pk.new(Pk.CRAFTING_DATA, 32768)
        w.uvarint(recipes.size + smelt.size)
        for (r in recipes) {
            if (r.shaped) {
                w.varint(1).varint(r.w).varint(r.h)
                for (c in r.input) c.write(w)
            } else {
                w.varint(0).uvarint(r.input.size)
                for (c in r.input) c.write(w)
            }
            w.uvarint(1)
            r.out.write(w)
            w.raw(r.uuid)
        }
        for (s in smelt) {
            if (s[1] < 0) w.varint(2).varint(s[0]) else w.varint(3).varint(s[0]).varint(s[1])
            Item(s[2], s[3], 1).write(w)
        }
        w.bool(true)
        w.toBytes()
    }
}
