package com.mcpehtml.app.server

import java.util.concurrent.ConcurrentHashMap

// Откуда пришла датаграмма и как ответить: свой UDP-сокет или туннель через VPS
interface Transport {
    fun send(peer: Peer, data: ByteArray)
}

class Peer(val key: String, val ip: String, val port: Int, val transport: Transport) {
    fun send(data: ByteArray) = transport.send(this, data)
}

interface RakListener {
    fun onOpen(s: RakSession)
    fun onGamePacket(s: RakSession, batch: ByteArray)
    fun onClose(s: RakSession, reason: String)
}

object RakId {
    const val CONNECTED_PING = 0x00
    const val UNCONNECTED_PING = 0x01
    const val UNCONNECTED_PING_OPEN = 0x02
    const val CONNECTED_PONG = 0x03
    const val OCR1 = 0x05
    const val OCR_REPLY1 = 0x06
    const val OCR2 = 0x07
    const val OCR_REPLY2 = 0x08
    const val CONNECTION_REQUEST = 0x09
    const val CONNECTION_ACCEPTED = 0x10
    const val NEW_INCOMING = 0x13
    const val DISCONNECT = 0x15
    const val UNCONNECTED_PONG = 0x1c
    const val GAME = 0xfe
    val MAGIC = byteArrayOf(0x00, 0xff.toByte(), 0xff.toByte(), 0x00, 0xfe.toByte(), 0xfe.toByte(), 0xfe.toByte(), 0xfe.toByte(),
        0xfd.toByte(), 0xfd.toByte(), 0xfd.toByte(), 0xfd.toByte(), 0x12, 0x34, 0x56, 0x78)

    fun writeAddress(w: W, ip: String, port: Int) {
        val parts = ip.split('.')
        if (parts.size == 4 && parts.all { it.toIntOrNull() in 0..255 }) {
            w.byte(4)
            for (p in parts) w.byte(p.toInt().inv() and 0xff)
        } else {
            w.byte(4)
            for (i in 0 until 4) w.byte(0xff)
        }
        w.short(port)
    }

    fun skipAddress(r: R) {
        val v = r.byte()
        if (v == 4) r.skip(6) else r.skip(2 + 2 + 4 + 16 + 4)
    }
}

// Сервер RakNet: офлайн-сообщения (пинг, рукопожатие) и сеансы игроков
class RakServer(private val guid: Long, private val listener: RakListener, private val motd: () -> String) {
    val sessions = ConcurrentHashMap<String, RakSession>()
    var maxSessions = 40

    fun handle(peer: Peer, d: ByteArray) {
        if (d.isEmpty()) return
        val s = sessions[peer.key]
        val id = d[0].toInt() and 0xff
        try {
            if (s != null && id and 0x80 != 0) { s.receive(d); return }
            handleOffline(peer, d, id)
        } catch (e: Exception) {
            // Повреждённая датаграмма от клиента не должна ронять сервер
        }
    }

    private fun handleOffline(peer: Peer, d: ByteArray, id: Int) {
        val r = R(d, 1)
        when (id) {
            RakId.UNCONNECTED_PING, RakId.UNCONNECTED_PING_OPEN -> {
                val time = r.long()
                val m = motd().toByteArray(Charsets.UTF_8)
                val w = W(64 + m.size).byte(RakId.UNCONNECTED_PONG).long(time).long(guid).raw(RakId.MAGIC).short(m.size).raw(m)
                peer.send(w.toBytes())
            }
            RakId.OCR1 -> {
                if (sessions.size >= maxSessions && sessions[peer.key] == null) return
                val mtu = minOf(d.size + 28, 1464)
                peer.send(W(32).byte(RakId.OCR_REPLY1).raw(RakId.MAGIC).long(guid).byte(0).short(mtu).toBytes())
            }
            RakId.OCR2 -> {
                r.skip(16)
                RakId.skipAddress(r)
                val mtu = minOf(maxOf(r.short(), 400), 1464)
                val clientGuid = r.long()
                var s = sessions[peer.key]
                if (s == null) {
                    if (sessions.size >= maxSessions) return
                    s = RakSession(this, peer, mtu, clientGuid)
                    sessions[peer.key] = s
                }
                val w = W(40).byte(RakId.OCR_REPLY2).raw(RakId.MAGIC).long(guid)
                RakId.writeAddress(w, peer.ip, peer.port)
                w.short(mtu).byte(0)
                peer.send(w.toBytes())
            }
        }
    }

    fun tick() {
        val now = System.currentTimeMillis()
        for (s in sessions.values) {
            s.tick(now)
            if (s.closed) sessions.remove(s.peer.key)
        }
    }

    internal fun opened(s: RakSession) = listener.onOpen(s)
    internal fun game(s: RakSession, batch: ByteArray) = listener.onGamePacket(s, batch)
    internal fun closed(s: RakSession, reason: String) { sessions.remove(s.peer.key); listener.onClose(s, reason) }
}

class RakSession(private val server: RakServer, val peer: Peer, private val mtu: Int, val clientGuid: Long) {
    var connected = false
        private set
    var closed = false
        private set
    var latency = 0L
    private val started = System.currentTimeMillis()
    private var lastReceive = started
    private var lastPing = 0L

    // Приём
    private val ackQueue = ArrayList<Int>()
    private val nackQueue = HashSet<Int>()
    private var highestSeq = -1
    private val received = HashSet<Int>()
    private var reliableWindowStart = 0
    private val splits = HashMap<Int, Array<ByteArray?>>()
    private var orderExpected = 0
    private val orderQueue = HashMap<Int, ByteArray>()

    // Отправка
    private var sendSeq = 0
    private var messageIndex = 0
    private var orderIndex = 0
    private var splitId = 0
    private val queue = ArrayList<ByteArray>()
    private var queueSize = 0
    private class Sent(var data: ByteArray, var time: Long)
    private val recovery = LinkedHashMap<Int, Sent>()

    private fun isReliable(r: Int) = r == 2 || r == 3 || r == 4 || r == 6 || r == 7
    private fun isSequenced(r: Int) = r == 1 || r == 4
    private fun isOrdered(r: Int) = r == 1 || r == 3 || r == 4 || r == 7

    fun receive(d: ByteArray) {
        if (closed) return
        lastReceive = System.currentTimeMillis()
        val id = d[0].toInt() and 0xff
        when {
            id and 0x40 != 0 -> handleAck(d, false)
            id and 0x20 != 0 -> handleAck(d, true)
            else -> handleFrames(d)
        }
    }

    private fun handleAck(d: ByteArray, nack: Boolean) {
        val r = R(d, 1)
        val count = r.short()
        var i = 0
        while (i < count && !r.eof()) {
            val single = r.byte() != 0
            val start = r.triad()
            val end = if (single) start else r.triad()
            var s = start
            while (s <= end && s - start < 4096) {
                val pk = recovery.remove(s)
                if (pk != null && nack) resend(pk)
                s++
            }
            i++
        }
    }

    private fun resend(pk: Sent) {
        val seq = sendSeq++ and 0xffffff
        pk.data[1] = seq.toByte(); pk.data[2] = (seq shr 8).toByte(); pk.data[3] = (seq shr 16).toByte()
        pk.time = System.currentTimeMillis()
        recovery[seq] = pk
        peer.send(pk.data)
    }

    private fun handleFrames(d: ByteArray) {
        val r = R(d, 1)
        val seq = r.triad()
        ackQueue.add(seq)
        nackQueue.remove(seq)
        if (highestSeq >= 0 && seq > highestSeq + 1) {
            var s = highestSeq + 1
            while (s < seq && s - highestSeq < 512) { nackQueue.add(s); s++ }
        }
        if (seq > highestSeq) highestSeq = seq
        while (!r.eof()) {
            val flags = r.byte()
            val rel = (flags and 0xe0) shr 5
            val split = flags and 0x10 != 0
            val len = (r.short() + 7) / 8
            var msgIndex = -1
            var ordIndex = 0
            if (isReliable(rel)) msgIndex = r.triad()
            if (isSequenced(rel)) r.triad()
            if (isOrdered(rel)) { ordIndex = r.triad(); r.byte() }
            var sCount = 0; var sId = 0; var sIndex = 0
            if (split) { sCount = r.int(); sId = r.short(); sIndex = r.int() }
            if (len == 0) break
            val payload = r.raw(len)
            if (msgIndex >= 0) {
                if (msgIndex < reliableWindowStart || !received.add(msgIndex)) continue
                while (received.size > 2048 || received.contains(reliableWindowStart) && received.size > 512) {
                    received.remove(reliableWindowStart)
                    reliableWindowStart++
                }
            }
            var full = payload
            if (split) {
                if (sCount <= 0 || sCount > 2048 || sIndex < 0 || sIndex >= sCount) continue
                val parts = splits.getOrPut(sId) { arrayOfNulls(sCount) }
                if (parts.size != sCount) continue
                parts[sIndex] = payload
                if (parts.any { it == null }) continue
                splits.remove(sId)
                val total = parts.sumOf { it!!.size }
                full = ByteArray(total)
                var o = 0
                for (p in parts) { System.arraycopy(p!!, 0, full, o, p.size); o += p.size }
            }
            if (isOrdered(rel) && !isSequenced(rel)) deliverOrdered(ordIndex, full) else handlePacket(full)
            if (closed) return
        }
    }

    private fun deliverOrdered(index: Int, data: ByteArray) {
        if (index < orderExpected) return
        if (index > orderExpected) { if (orderQueue.size < 4096) orderQueue[index] = data; return }
        handlePacket(data)
        orderExpected++
        while (true) {
            val next = orderQueue.remove(orderExpected) ?: break
            handlePacket(next)
            orderExpected++
        }
    }

    private fun now() = System.currentTimeMillis() - started

    private fun handlePacket(data: ByteArray) {
        if (data.isEmpty()) return
        val r = R(data, 1)
        when (data[0].toInt() and 0xff) {
            RakId.CONNECTED_PING -> {
                val t = r.long()
                sendReliable(W(17).byte(RakId.CONNECTED_PONG).long(t).long(now()).toBytes(), true)
            }
            RakId.CONNECTED_PONG -> {
                val t = r.long()
                val l = maxOf(0L, now() - t)
                latency = if (latency == 0L) l else (latency * 6 + l * 4) / 10
            }
            RakId.CONNECTION_REQUEST -> {
                r.long()
                val time = r.long()
                val w = W(128).byte(RakId.CONNECTION_ACCEPTED)
                RakId.writeAddress(w, peer.ip, peer.port)
                w.short(0)
                for (i in 0 until 10) RakId.writeAddress(w, "0.0.0.0", 0)
                w.long(time).long(now())
                sendReliable(w.toBytes(), true)
            }
            RakId.NEW_INCOMING -> {
                if (!connected) { connected = true; server.opened(this) }
            }
            RakId.DISCONNECT -> close("Игрок отключился", false)
            RakId.GAME -> if (connected) server.game(this, data.copyOfRange(1, data.size))
        }
    }

    // Надёжная упорядоченная отправка (reliability 3, канал 0) с разбиением на части по MTU
    fun sendReliable(payload: ByteArray, immediate: Boolean = false) {
        if (closed) return
        val max = mtu - 60
        if (payload.size > max) {
            val count = (payload.size + max - 1) / max
            val sid = splitId++ and 0xffff
            val oi = orderIndex++
            for (i in 0 until count) {
                val from = i * max
                val to = minOf(payload.size, from + max)
                enqueue(frame(payload, from, to - from, oi, count, sid, i))
            }
        } else {
            enqueue(frame(payload, 0, payload.size, orderIndex++, 0, 0, 0))
        }
        if (immediate) flush()
    }

    private fun frame(p: ByteArray, off: Int, len: Int, oi: Int, sCount: Int, sId: Int, sIndex: Int): ByteArray {
        val w = W(len + 24)
        w.byte((3 shl 5) or (if (sCount > 0) 0x10 else 0))
        w.short(len * 8)
        w.triad(messageIndex++ and 0xffffff)
        w.triad(oi and 0xffffff)
        w.byte(0)
        if (sCount > 0) { w.int(sCount); w.short(sId); w.int(sIndex) }
        w.raw(p, off, len)
        return w.toBytes()
    }

    private fun enqueue(f: ByteArray) {
        if (queueSize + f.size + 4 > mtu - 28) flush()
        queue.add(f)
        queueSize += f.size
    }

    fun flush() {
        if (queue.isEmpty()) return
        val w = W(queueSize + 4)
        val seq = sendSeq++ and 0xffffff
        w.byte(0x84).triad(seq)
        for (f in queue) w.raw(f)
        val data = w.toBytes()
        recovery[seq] = Sent(data, System.currentTimeMillis())
        queue.clear()
        queueSize = 0
        peer.send(data)
    }

    private fun sendAcks(list: Collection<Int>, flag: Int) {
        if (list.isEmpty()) return
        val sorted = list.toSortedSet().toIntArray()
        val w = W(16 + sorted.size * 7)
        w.byte(flag)
        val records = ArrayList<IntArray>()
        var start = sorted[0]
        var last = sorted[0]
        for (i in 1 until sorted.size) {
            if (sorted[i] == last + 1) { last = sorted[i]; continue }
            records.add(intArrayOf(start, last)); start = sorted[i]; last = sorted[i]
        }
        records.add(intArrayOf(start, last))
        w.short(records.size)
        for (rc in records) {
            if (rc[0] == rc[1]) w.byte(1).triad(rc[0]) else w.byte(0).triad(rc[0]).triad(rc[1])
        }
        peer.send(w.toBytes())
    }

    fun tick(now: Long) {
        if (closed) return
        if (ackQueue.isNotEmpty()) { sendAcks(ackQueue, 0xc0); ackQueue.clear() }
        if (nackQueue.isNotEmpty()) { sendAcks(nackQueue, 0xa0); nackQueue.clear() }
        flush()
        if (recovery.isNotEmpty()) {
            val old = recovery.entries.filter { now - it.value.time > 1200 }.take(64)
            for (e in old) { recovery.remove(e.key); resend(e.value) }
            // Клиент давно не подтверждает: не держим бесконечную очередь
            if (recovery.size > 8192) close("Слишком много потерянных пакетов", true)
        }
        if (connected && now - lastPing > 2000) {
            lastPing = now
            sendReliable(W(9).byte(RakId.CONNECTED_PING).long(now()).toBytes(), true)
        }
        if (now - lastReceive > 20000) close("Превышено время ожидания", false)
    }

    fun close(reason: String, notify: Boolean) {
        if (closed) return
        if (notify && connected) {
            sendReliable(byteArrayOf(RakId.DISCONNECT.toByte()), true)
        }
        closed = true
        server.closed(this, reason)
    }
}
