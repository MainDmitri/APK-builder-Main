package com.mcpehtml.app.server

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import kotlin.math.floor
import kotlin.math.max

// Чанк 16×256×16: секции по 16 блоков высотой, индексы как в сети MCPE 1.1 (x<<8 | z<<4 | y)
class Chunk(val cx: Int, val cz: Int) {
    val ids = arrayOfNulls<ByteArray>(16)
    val meta = arrayOfNulls<ByteArray>(16)
    val height = IntArray(256)
    var modified = false
    var lastUsed = System.currentTimeMillis()
    private var netCache: ByteArray? = null

    fun getId(x: Int, y: Int, z: Int): Int {
        if (y < 0 || y > 255) return 0
        val s = ids[y shr 4] ?: return 0
        return s[(x shl 8) or (z shl 4) or (y and 15)].toInt() and 0xff
    }

    fun getData(x: Int, y: Int, z: Int): Int {
        if (y < 0 || y > 255) return 0
        val s = meta[y shr 4] ?: return 0
        return s[(x shl 8) or (z shl 4) or (y and 15)].toInt() and 15
    }

    fun set(x: Int, y: Int, z: Int, id: Int, data: Int) {
        if (y < 0 || y > 255) return
        val sy = y shr 4
        if (ids[sy] == null) {
            if (id == 0) return
            ids[sy] = ByteArray(4096); meta[sy] = ByteArray(4096)
        }
        val i = (x shl 8) or (z shl 4) or (y and 15)
        ids[sy]!![i] = id.toByte()
        meta[sy]!![i] = (data and 15).toByte()
        netCache = null
        val hi = (z shl 4) or x
        if (y >= height[hi] && Blocks.blocksLight[id]) height[hi] = minOf(255, y + 1)
        else if (y + 1 == height[hi] && !Blocks.blocksLight[id]) recalcColumn(x, z)
    }

    fun recalcColumn(x: Int, z: Int) {
        var h = 0
        for (y in 255 downTo 0) if (Blocks.blocksLight[getId(x, y, z)]) { h = y + 1; break }
        height[(z shl 4) or x] = h
    }

    fun recalcHeight() { for (x in 0 until 16) for (z in 0 until 16) recalcColumn(x, z) }

    // Пакет FullChunkData в формате Nukkit (Anvil.requestChunkTask): секции, карта высот, биомы
    fun network(biome: (Int, Int) -> Int): ByteArray {
        netCache?.let { return it }
        var count = 0
        for (i in 15 downTo 0) if (ids[i] != null && ids[i]!!.any { it.toInt() != 0 }) { count = i + 1; break }
        val w = W(count * 10241 + 1024)
        w.byte(count)
        val data = ByteArray(2048)
        val sky = ByteArray(2048)
        val blockLight = ByteArray(2048)
        val empty = ByteArray(4096)
        for (sy in 0 until count) {
            w.byte(0)
            val sid = ids[sy] ?: empty
            val sm = meta[sy] ?: empty
            w.raw(sid)
            for (j in 0 until 2048) data[j] = ((sm[j shl 1].toInt() and 15) or ((sm[(j shl 1) or 1].toInt() and 15) shl 4)).toByte()
            w.raw(data)
            // Небесный свет: 15 над картой высот, 0 ниже (клиент досчитывает остальное сам)
            for (x in 0 until 16) for (z in 0 until 16) {
                val h = height[(z shl 4) or x]
                for (y in 0 until 16 step 2) {
                    val wy = (sy shl 4) + y
                    val a = if (wy >= h) 15 else 0
                    val b = if (wy + 1 >= h) 15 else 0
                    sky[(x shl 7) or (z shl 3) or (y shr 1)] = (a or (b shl 4)).toByte()
                }
            }
            w.raw(sky)
            w.raw(blockLight)
        }
        for (i in 0 until 256) w.byte(height[i])
        w.raw(ByteArray(256))
        for (z in 0 until 16) for (x in 0 until 16) w.byte(biome(cx * 16 + x, cz * 16 + z))
        w.byte(0)
        w.varint(0)
        val out = w.toBytes()
        netCache = out
        return out
    }

    fun save(f: File) {
        val tmp = File(f.path + ".tmp")
        DataOutputStream(tmp.outputStream().buffered()).use { o ->
            var mask = 0
            for (i in 0 until 16) if (ids[i] != null) mask = mask or (1 shl i)
            o.writeShort(mask)
            val raw = java.io.ByteArrayOutputStream()
            for (i in 0 until 16) if (ids[i] != null) { raw.write(ids[i]!!); raw.write(meta[i]!!) }
            val z = Zlib.deflate(raw.toByteArray(), 4)
            o.writeInt(z.size)
            o.write(z)
        }
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
        modified = false
    }

    companion object {
        fun load(cx: Int, cz: Int, f: File): Chunk? {
            return try {
                DataInputStream(f.inputStream().buffered()).use { inp ->
                    val mask = inp.readUnsignedShort()
                    val n = inp.readInt()
                    val z = ByteArray(n)
                    inp.readFully(z)
                    val raw = Zlib.inflate(z, 16 * 8192 + 16)
                    val c = Chunk(cx, cz)
                    var o = 0
                    for (i in 0 until 16) if (mask and (1 shl i) != 0) {
                        c.ids[i] = raw.copyOfRange(o, o + 4096); o += 4096
                        c.meta[i] = raw.copyOfRange(o, o + 4096); o += 4096
                    }
                    c.recalcHeight()
                    c
                }
            } catch (e: Exception) {
                null
            }
        }
    }
}

// Шум Перлина и хеш — та же математика, что в js/noise.js (одинаковый мир по зерну)
class Perlin(seed: Int) {
    private val perm = IntArray(512)

    init {
        val rnd = mulberry32(seed)
        val p = IntArray(256) { it }
        for (i in 255 downTo 1) {
            val j = floor(rnd() * (i + 1)).toInt()
            val t = p[i]; p[i] = p[j]; p[j] = t
        }
        for (i in 0 until 512) perm[i] = p[i and 255]
    }

    private fun fade(t: Double) = t * t * t * (t * (t * 6 - 15) + 10)
    private fun lerp(a: Double, b: Double, t: Double) = a + t * (b - a)
    private fun grad2(h: Int, x: Double, y: Double): Double = when (h and 7) {
        0 -> x + y; 1 -> -x + y; 2 -> x - y; 3 -> -x - y; 4 -> x; 5 -> -x; 6 -> y; else -> -y
    }
    private fun grad3(h: Int, x: Double, y: Double, z: Double): Double {
        val g = h and 15
        val u = if (g < 8) x else y
        val v = if (g < 4) y else if (g == 12 || g == 14) x else z
        return (if (g and 1 == 0) u else -u) + (if (g and 2 == 0) v else -v)
    }

    fun noise2(xi: Double, yi: Double): Double {
        val P = perm
        val X = floor(xi).toInt() and 255
        val Y = floor(yi).toInt() and 255
        val x = xi - floor(xi)
        val y = yi - floor(yi)
        val u = fade(x); val v = fade(y)
        val a = P[X] + Y; val b = P[X + 1] + Y
        return lerp(lerp(grad2(P[a], x, y), grad2(P[b], x - 1, y), u),
            lerp(grad2(P[a + 1], x, y - 1), grad2(P[b + 1], x - 1, y - 1), u), v) * 0.7071
    }

    fun noise3(xi: Double, yi: Double, zi: Double): Double {
        val P = perm
        val X = floor(xi).toInt() and 255; val Y = floor(yi).toInt() and 255; val Z = floor(zi).toInt() and 255
        val x = xi - floor(xi); val y = yi - floor(yi); val z = zi - floor(zi)
        val u = fade(x); val v = fade(y); val w = fade(z)
        val A = P[X] + Y; val AA = P[A] + Z; val AB = P[A + 1] + Z
        val B = P[X + 1] + Y; val BA = P[B] + Z; val BB = P[B + 1] + Z
        return lerp(
            lerp(lerp(grad3(P[AA], x, y, z), grad3(P[BA], x - 1, y, z), u), lerp(grad3(P[AB], x, y - 1, z), grad3(P[BB], x - 1, y - 1, z), u), v),
            lerp(lerp(grad3(P[AA + 1], x, y, z - 1), grad3(P[BA + 1], x - 1, y, z - 1), u), lerp(grad3(P[AB + 1], x, y - 1, z - 1), grad3(P[BB + 1], x - 1, y - 1, z - 1), u), v), w)
    }

    fun fbm2(x: Double, y: Double, octaves: Int): Double {
        var sum = 0.0; var amp = 1.0; var freq = 1.0; var norm = 0.0
        for (i in 0 until octaves) {
            sum += noise2(x * freq, y * freq) * amp
            norm += amp; amp *= 0.5; freq *= 2
        }
        return sum / norm
    }

    companion object {
        fun mulberry32(seed: Int): () -> Double {
            var a = seed
            return {
                a += 0x6d2b79f5
                var t = (a xor (a ushr 15)) * (1 or a)
                t = (t + (t xor (t ushr 7)) * (61 or t)) xor t
                ((t xor (t ushr 14)).toLong() and 0xffffffffL) / 4294967296.0
            }
        }

        fun hash3(seed: Int, x: Int, y: Int, z: Int): Double {
            var h = seed xor (x * 374761393) xor (y * 668265263) xor (z * 2147483647)
            h = (h xor (h ushr 13)) * 1274126177
            h = h xor (h ushr 16)
            return (h.toLong() and 0xffffffffL) / 4294967296.0
        }
    }
}

// Генератор ландшафта: тот же, что в одиночной игре (js/world.js)
class Generator(val seed: Int) {
    private val n1 = Perlin(seed)
    private val n2 = Perlin(seed + 1)
    private val n3 = Perlin(seed + 2)
    private val cave = Perlin(seed + 3)
    private val biome = Perlin(seed + 4)
    val SEA = 62

    fun heightAt(x: Int, z: Int): Int {
        val base = n1.fbm2(x / 160.0, z / 160.0, 4)
        val hills = n2.fbm2(x / 60.0, z / 60.0, 3)
        val mount = max(0.0, n3.fbm2(x / 300.0, z / 300.0, 2)) * 2.2
        return floor(64 + base * 14 + hills * 6 + mount * mount * 40).toInt()
    }

    // 0 равнины, 1 пустыня, 2 тайга
    fun biomeAt(x: Int, z: Int): Int {
        val v = biome.fbm2(x / 400.0, z / 400.0, 2)
        return if (v > 0.25) 1 else if (v < -0.3) 2 else 0
    }

    // Номер биома MCPE для цвета травы и листвы у клиента
    fun mcpeBiome(x: Int, z: Int): Int = when (biomeAt(x, z)) { 1 -> 2; 2 -> 30; else -> 1 }

    fun generate(cx: Int, cz: Int): Chunk {
        val c = Chunk(cx, cz)
        val H = seed
        for (x in 0 until 16) for (z in 0 until 16) {
            val wx = cx * 16 + x; val wz = cz * 16 + z
            val h = heightAt(wx, wz)
            val b = biomeAt(wx, wz)
            val beach = h <= SEA + 1
            val sandy = b == 1 || beach
            c.set(x, 0, z, 7, 0)
            for (y in 1..3) if (Perlin.hash3(H, wx, y, wz) < 0.5) c.set(x, y, z, 7, 0)
            for (y in 1..minOf(h, 255)) {
                if (c.getId(x, y, z) == 7) continue
                var id: Int
                if (y == h) id = if (sandy) 12 else if (h > 110) 1 else 2
                else if (y > h - 4) id = if (sandy) (if (y > h - 3) 12 else 24) else 3
                else {
                    id = 1
                    val r = Perlin.hash3(H + 7, wx, y, wz)
                    if (y < 128 && r < 0.012) id = 16
                    else if (y < 64 && r < 0.019) id = 15
                    else if (y < 32 && r < 0.0215) id = 14
                    else if (y < 16 && r < 0.0245) id = 73
                    else if (y < 16 && r < 0.0258) id = 56
                    else if (y < 30 && r < 0.0268) id = 21
                    else if (r > 0.985) id = 13
                }
                if (y > 4 && y < h - 3) {
                    val cv = cave.noise3(wx / 28.0, y / 18.0, wz / 28.0)
                    if (cv > 0.42) id = if (y < 11) 11 else 0
                }
                if (id != 0) c.set(x, y, z, id, 0)
            }
            for (y in h + 1..SEA) c.set(x, y, z, 9, 0)
            if (h >= SEA && h > 105 && b != 1) c.set(x, h + 1, z, 78, 0)
            if (b == 2 && h > SEA && c.getId(x, h, z) == 2) c.set(x, h + 1, z, 78, 0)
            if (h > SEA && c.getId(x, h, z) == 2 && c.getId(x, h + 1, z) == 0) {
                val r = Perlin.hash3(H + 11, wx, 0, wz)
                if (r < 0.10) c.set(x, h + 1, z, 31, 1)
                else if (r < 0.112) c.set(x, h + 1, z, 37, 0)
                else if (r < 0.124) c.set(x, h + 1, z, 38, floor(Perlin.hash3(H + 12, wx, 1, wz) * 9).toInt())
            }
            if (b == 1 && h > SEA && Perlin.hash3(H + 13, wx, 0, wz) < 0.004) {
                val tall = 1 + floor(Perlin.hash3(H + 14, wx, 0, wz) * 3).toInt()
                for (y in 1..tall) c.set(x, h + y, z, 81, 0)
            }
            if (b == 1 && h > SEA && Perlin.hash3(H + 15, wx, 0, wz) > 0.994) c.set(x, h + 1, z, 32, 0)
        }
        for (tx in cx * 16 - 3 until cx * 16 + 19) for (tz in cz * 16 - 3 until cz * 16 + 19) {
            val r = Perlin.hash3(H + 21, tx, 0, tz)
            val b = biomeAt(tx, tz)
            val chance = if (b == 2) 0.02 else if (b == 0) 0.012 else 0.0
            if (r >= chance) continue
            val h = heightAt(tx, tz)
            if (h <= SEA + 1 || h > 115) continue
            if (cave.noise3(tx / 28.0, h / 18.0, tz / 28.0) > 0.42) continue
            val kind = if (b == 2) 1 else if (Perlin.hash3(H + 22, tx, 0, tz) < 0.2) 2 else 0
            placeTree(c, tx, h + 1, tz, kind, Perlin.hash3(H + 23, tx, 0, tz))
        }
        c.recalcHeight()
        return c
    }

    private fun placeTree(c: Chunk, tx: Int, ty: Int, tz: Int, kind: Int, r: Double) {
        fun put(x: Int, y: Int, z: Int, id: Int, d: Int, onlyAir: Boolean) {
            val lx = x - c.cx * 16; val lz = z - c.cz * 16
            if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 0 || y > 255) return
            if (onlyAir) { val cur = c.getId(lx, y, lz); if (cur != 0 && cur != 31 && cur != 78) return }
            c.set(lx, y, lz, id, d)
        }
        val trunk = 4 + floor(r * 3).toInt()
        if (kind == 1) {
            for (y in 0 until trunk + 2) put(tx, ty + y, tz, 17, 1, false)
            var rad = 0
            for (y in trunk + 2 downTo 2) {
                for (dx in -rad..rad) for (dz in -rad..rad) {
                    if (Math.abs(dx) + Math.abs(dz) > rad + 1 || (dx == 0 && dz == 0 && y < trunk + 2)) continue
                    put(tx + dx, ty + y, tz + dz, 18, 1, true)
                }
                rad = if (rad >= 2) 1 else rad + 1
            }
            put(tx, ty + trunk + 2, tz, 18, 1, true)
            put(tx, ty + trunk + 3, tz, 18, 1, true)
            return
        }
        val leaf = if (kind == 2) 2 else 0
        for (y in 0 until trunk) put(tx, ty + y, tz, 17, leaf, false)
        for (y in trunk - 3..trunk) {
            val rad = if (y >= trunk - 1) 1 else 2
            for (dx in -rad..rad) for (dz in -rad..rad) {
                if (rad == 2 && Math.abs(dx) == 2 && Math.abs(dz) == 2 && Perlin.hash3(seed + 31, tx + dx, ty + y, tz + dz) < 0.5) continue
                if (rad == 1 && y == trunk && Math.abs(dx) == 1 && Math.abs(dz) == 1) continue
                put(tx + dx, ty + y, tz + dz, 18, leaf, true)
            }
        }
    }

    fun findSpawn(): DoubleArray {
        for (i in 0 until 400) {
            val x = floor(Math.cos(i.toDouble()) * i * 2).toInt()
            val z = floor(Math.sin(i.toDouble()) * i * 2).toInt()
            val h = heightAt(x, z)
            if (h > SEA + 1 && biomeAt(x, z) != 1) return doubleArrayOf(x + 0.5, h + 1.0, z + 0.5)
        }
        return doubleArrayOf(0.5, heightAt(0, 0) + 2.0, 0.5)
    }
}

// Мир сервера: чанки в памяти, генерация, сохранение в папку
class World(val dir: File, val gen: Generator) {
    private val chunks = HashMap<Long, Chunk>()
    private val chunkDir = File(dir, "chunks").also { it.mkdirs() }

    private fun key(cx: Int, cz: Int) = (cx.toLong() shl 32) or (cz.toLong() and 0xffffffffL)

    fun chunk(cx: Int, cz: Int): Chunk {
        val k = key(cx, cz)
        chunks[k]?.let { it.lastUsed = System.currentTimeMillis(); return it }
        val f = File(chunkDir, "$cx.$cz.chk")
        val c = (if (f.exists()) Chunk.load(cx, cz, f) else null) ?: gen.generate(cx, cz)
        chunks[k] = c
        return c
    }

    fun loaded() = chunks.size
    fun isLoaded(cx: Int, cz: Int) = chunks.containsKey(key(cx, cz))
    fun loadedChunks(): Collection<Chunk> = chunks.values

    fun getId(x: Int, y: Int, z: Int): Int = chunk(x shr 4, z shr 4).getId(x and 15, y, z and 15)
    fun getData(x: Int, y: Int, z: Int): Int = chunk(x shr 4, z shr 4).getData(x and 15, y, z and 15)

    fun setBlock(x: Int, y: Int, z: Int, id: Int, data: Int) {
        if (y < 0 || y > 255) return
        val c = chunk(x shr 4, z shr 4)
        c.set(x and 15, y, z and 15, id, data)
        c.modified = true
    }

    fun highestY(x: Int, z: Int): Int {
        val c = chunk(x shr 4, z shr 4)
        for (y in 255 downTo 0) if (Blocks.solid[c.getId(x and 15, y, z and 15)]) return y
        return 0
    }

    fun save(all: Boolean) {
        for (c in chunks.values) if (c.modified) c.save(File(chunkDir, "${c.cx}.${c.cz}.chk"))
        if (all) return
    }

    // Выгрузка чанков, рядом с которыми нет игроков (с сохранением изменённых)
    fun unloadUnused(keep: (Int, Int) -> Boolean) {
        val now = System.currentTimeMillis()
        val it = chunks.values.iterator()
        while (it.hasNext()) {
            val c = it.next()
            if (keep(c.cx, c.cz) || now - c.lastUsed < 30000) continue
            if (c.modified) c.save(File(chunkDir, "${c.cx}.${c.cz}.chk"))
            it.remove()
        }
    }
}
