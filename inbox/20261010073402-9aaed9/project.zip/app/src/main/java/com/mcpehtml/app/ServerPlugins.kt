package com.mcpehtml.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Файлы плагинов сервера: папка filesDir/server/plugins, файлы .js (выключенные — .js.off).
 * Встроенные плагины копируются из assets/www/server-plugins, если игрок их не удалял.
 */
object ServerPlugins {
    private const val ASSETS = "www/server-plugins"
    private const val MAX_SIZE = 512 * 1024

    fun dir(ctx: Context): File = File(ctx.filesDir, "server/plugins").also { it.mkdirs() }

    private fun removedFile(ctx: Context) = File(dir(ctx), ".removed")

    private fun removed(ctx: Context): MutableSet<String> {
        val f = removedFile(ctx)
        return if (f.exists()) f.readLines().map { it.trim() }.filter { it.isNotEmpty() }.toMutableSet() else mutableSetOf()
    }

    private fun saveRemoved(ctx: Context, set: Set<String>) { removedFile(ctx).writeText(set.joinToString("\n")) }

    private fun builtIn(ctx: Context): List<String> =
        try { ctx.assets.list(ASSETS)?.filter { it.endsWith(".js") }?.sorted() ?: emptyList() } catch (e: Exception) { emptyList() }

    // Копирует встроенные плагины, которых ещё нет (и которые игрок не удалял)
    fun installBuiltIn(ctx: Context) {
        val d = dir(ctx)
        val gone = removed(ctx)
        for (name in builtIn(ctx)) {
            if (name in gone || File(d, name).exists() || File(d, "$name.off").exists()) continue
            try {
                ctx.assets.open("$ASSETS/$name").use { input -> File(d, name).outputStream().use { input.copyTo(it) } }
            } catch (e: Exception) {
            }
        }
    }

    private fun safeName(name: String): String? {
        var n = File(name).name.trim().replace(Regex("[^A-Za-z0-9_.-]"), "_")
        if (n.endsWith(".off")) n = n.removeSuffix(".off")
        if (!n.endsWith(".js")) n = n.substringBeforeLast('.').ifEmpty { n } + ".js"
        if (n.length < 4 || n.length > 64 || n.startsWith(".")) return null
        return n
    }

    // Описание из исходника: plugin.description = '...'
    private fun meta(text: String, key: String): String =
        Regex("plugin\\.$key\\s*=\\s*(['\"])(.*?)\\1").find(text)?.groupValues?.get(2) ?: ""

    fun list(ctx: Context, running: JSONArray?): JSONArray {
        val d = dir(ctx)
        val builtins = builtIn(ctx).toSet()
        val info = HashMap<String, JSONObject>()
        if (running != null) for (i in 0 until running.length()) running.optJSONObject(i)?.let { info[it.optString("file")] = it }
        val out = JSONArray()
        val files = d.listFiles { f -> f.isFile && (f.name.endsWith(".js") || f.name.endsWith(".js.off")) }?.sortedBy { it.name.lowercase() } ?: emptyList()
        for (f in files) {
            val enabled = f.name.endsWith(".js")
            val file = f.name.removeSuffix(".off")
            val text = try { f.readText() } catch (e: Exception) { "" }
            val o = JSONObject()
                .put("file", file)
                .put("enabled", enabled)
                .put("builtIn", file in builtins)
                .put("size", f.length())
                .put("name", meta(text, "name").ifEmpty { file.removeSuffix(".js") })
                .put("version", meta(text, "version"))
                .put("description", meta(text, "description"))
                .put("loaded", false)
            info[file]?.let { r ->
                if (enabled) {
                    o.put("name", r.optString("name", o.optString("name")))
                    o.put("error", r.optString("error", ""))
                    o.put("loaded", r.optString("error", "").isEmpty())
                    o.put("commands", r.optJSONArray("commands") ?: JSONArray())
                }
            }
            out.put(o)
        }
        return out
    }

    // Добавить или заменить плагин; "" — успех, иначе текст ошибки
    fun add(ctx: Context, name: String, text: String): String {
        val n = safeName(name) ?: return "Неверное имя файла"
        if (text.isBlank()) return "Файл пустой"
        if (text.length > MAX_SIZE) return "Файл больше 512 КБ"
        if (text.contains("<?php") || Regex("^\\s*package\\s+[a-z]", RegexOption.MULTILINE).containsMatchIn(text))
            return "Это плагин для PocketMine/Nukkit. Здесь работают только плагины на JavaScript (.js)"
        val d = dir(ctx)
        File(d, "$n.off").delete()
        File(d, n).writeText(text)
        val gone = removed(ctx)
        if (gone.remove(n)) saveRemoved(ctx, gone)
        return ""
    }

    fun toggle(ctx: Context, file: String, on: Boolean): Boolean {
        val n = safeName(file) ?: return false
        val d = dir(ctx)
        val js = File(d, n)
        val off = File(d, "$n.off")
        return if (on) off.exists() && off.renameTo(js) || js.exists() else js.exists() && js.renameTo(off) || off.exists()
    }

    fun delete(ctx: Context, file: String): Boolean {
        val n = safeName(file) ?: return false
        val d = dir(ctx)
        val ok = File(d, n).delete() or File(d, "$n.off").delete()
        if (ok && n in builtIn(ctx)) { val gone = removed(ctx); gone.add(n); saveRemoved(ctx, gone) }
        return ok
    }

    // Вернуть удалённые встроенные плагины
    fun restoreBuiltIn(ctx: Context) {
        removedFile(ctx).delete()
        installBuiltIn(ctx)
    }

    fun read(ctx: Context, file: String): String {
        val n = safeName(file) ?: return ""
        val d = dir(ctx)
        val f = File(d, n).takeIf { it.exists() } ?: File(d, "$n.off")
        return if (f.exists()) f.readText() else ""
    }
}
