// Чат: префиксы [Админ]/[Игрок], защита от спама и повторов, /mute <игрок> [минуты], /unmute <игрок>.
plugin.name = 'ChatPlus';
plugin.version = '1.0';
plugin.description = 'Префиксы в чате, антиспам, /mute, /unmute';
plugin.author = 'Minecraft HTML';

var last = {};      // ник -> { at, text }
var INTERVAL = 1500; // не чаще одного сообщения в 1,5 с
var REPEAT = 10000;  // одинаковое сообщение — не чаще раза в 10 с

function mutes() { if (!plugin.data.mutes) plugin.data.mutes = {}; return plugin.data.mutes; }

function muted(name) {
  var m = mutes()[name.toLowerCase()];
  if (m === undefined) return 0;
  if (m !== 0 && m < Date.now()) { delete mutes()[name.toLowerCase()]; plugin.save(); return 0; }
  return m === 0 ? -1 : m;
}

function muteText(m) { return m === -1 ? 'навсегда' : 'ещё ' + Math.ceil((m - Date.now()) / 60000) + ' мин'; }

server.on('chat', function (e) {
  var p = e.player;
  var m = muted(p.name);
  if (m) { e.cancel(); p.send('§cВы не можете писать в чат (' + muteText(m) + ')'); return; }
  var k = p.name.toLowerCase(), now = Date.now();
  var msg = String(e.message).trim();
  if (!p.op && last[k]) {
    if (now - last[k].at < INTERVAL) { e.cancel(); p.send('§cНе так быстро'); return; }
    if (last[k].text === msg.toLowerCase() && now - last[k].at < REPEAT) { e.cancel(); p.send('§cНе повторяйтесь'); return; }
  }
  last[k] = { at: now, text: msg.toLowerCase() };
  // Капс у обычных игроков — в нижний регистр
  if (!p.op && msg.length > 8 && msg.replace(/[^A-ZА-ЯЁ]/g, '').length > msg.length * 0.7) msg = msg.toLowerCase();
  var prefix = p.op ? '§c[Админ] ' : '§7[Игрок] ';
  e.text = prefix + '§f' + p.name + '§7: §f' + msg;
});

// Замученный игрок не пишет и через /me, /tell
server.on('command', function (e) {
  if (['me', 'tell', 'msg', 'w', 'say'].indexOf(e.command) < 0) return;
  var m = muted(e.player.name);
  if (m) { e.cancel(); e.player.send('§cВы не можете писать (' + muteText(m) + ')'); }
});

server.command('mute', { description: 'Запретить игроку писать', usage: '/mute <игрок> [минуты]', op: true }, function (p, a) {
  if (!a[0]) return p ? '§cИспользование: /mute <игрок> [минуты]' : undefined;
  var min = Math.floor(Number(a[1]) || 0);
  mutes()[a[0].toLowerCase()] = min > 0 ? Date.now() + min * 60000 : 0;
  plugin.save();
  var t = server.player(a[0]);
  if (t) t.send('§cВам запретили писать в чат' + (min > 0 ? ' на ' + min + ' мин' : ''));
  var msg = '§a' + a[0] + ' не может писать' + (min > 0 ? ' ' + min + ' мин' : ' до /unmute');
  if (p) return msg;
  server.log(msg);
});

server.command('unmute', { description: 'Разрешить игроку писать', usage: '/unmute <игрок>', op: true }, function (p, a) {
  if (!a[0]) return p ? '§cИспользование: /unmute <игрок>' : undefined;
  delete mutes()[a[0].toLowerCase()];
  plugin.save();
  var t = server.player(a[0]);
  if (t) t.send('§aВам снова можно писать в чат');
  if (p) return '§a' + a[0] + ' снова может писать';
});

server.on('quit', function (e) { delete last[e.player.name.toLowerCase()]; });
