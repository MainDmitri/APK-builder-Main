// Жилы: присядьте и сломайте руду киркой — выкопается вся жила (до 64 блоков). Работает, только если кирка подходит для руды.
plugin.name = 'VeinMiner';
plugin.version = '1.0';
plugin.description = 'Присесть + кирка: выкопать всю жилу руды';
plugin.author = 'Minecraft HTML';

var PICKS = { 270: 1, 285: 1, 274: 2, 257: 3, 278: 4 };
// Руда -> нужный уровень кирки (1 дерево/золото, 2 камень, 3 железо)
var ORES = { 16: 1, 15: 2, 21: 2, 14: 3, 73: 3, 74: 3, 56: 3, 129: 3, 153: 1, 89: 0 };
var MAX = 64;

function same(a, b) { return a === b || ((a === 73 || a === 74) && (b === 73 || b === 74)); }

server.on('blockBreak', function (e) {
  var p = e.player;
  if (!p.sneaking || ORES[e.id] === undefined) return;
  var tier = PICKS[p.held.id];
  if (!tier || tier < ORES[e.id]) return;
  var tool = p.held.id, drop = p.gamemode !== 1;
  var seen = {}, queue = [[e.x, e.y, e.z]], found = [];
  seen[e.x + ',' + e.y + ',' + e.z] = 1;
  while (queue.length && found.length < MAX) {
    var c = queue.shift();
    for (var dx = -1; dx <= 1; dx++) for (var dy = -1; dy <= 1; dy++) for (var dz = -1; dz <= 1; dz++) {
      if (!dx && !dy && !dz) continue;
      var x = c[0] + dx, y = c[1] + dy, z = c[2] + dz, k = x + ',' + y + ',' + z;
      if (seen[k]) continue;
      seen[k] = 1;
      if (!same(server.getBlock(x, y, z).id, e.id)) continue;
      found.push([x, y, z]);
      queue.push([x, y, z]);
    }
  }
  if (!found.length) return;
  server.later(1, function () {
    for (var i = 0; i < found.length; i++) {
      var b = found[i];
      if (same(server.getBlock(b[0], b[1], b[2]).id, e.id)) server.breakBlock(b[0], b[1], b[2], tool, drop);
    }
  });
  p.popup('§bЖила: +' + found.length);
});
