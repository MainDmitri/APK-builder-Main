// Готовые постройки: базы и ловушки. Каждая собирается кодом в схему того же формата, что и .schematic,
// и показывается голограммой во вкладке «Схемы» (её можно двигать, поворачивать, строить принтером или сразу).
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  // Номера блоков MCPE 1.1
  const B = {
    stone: 1, grass: 2, dirt: 3, cobble: 4, planks: 5, sand: 12, log: 17, leaves: 18, glass: 20, wool: 35, flowerY: 37, flowerR: 38,
    tnt: 46, bookshelf: 47, mossy: 48, torch: 50, oakStairs: 53, chest: 54, wire: 55, table: 58, furnace: 61, door: 64, ladder: 65,
    cobStairs: 67, plate: 70, snow: 80, cactus: 81, fence: 85, glowstone: 89, trapdoor: 96, sbrick: 98, bars: 101, pane: 102,
    gate: 107, brickStairs: 108, sbStairs: 109, lava: 11, water: 9, slab: 44, woodSlab: 158, quartz: 155, quartzStairs: 156,
    spruceStairs: 134, darkStairs: 164, carpet: 171, seaLantern: 169, terracotta: 159, bed: 26, web: 30, flowerPot: 140, lantern: 124,
    tallGrass: 31, stoneSlab: 44, ironBlock: 42, lever: 69, sandstone: 24, sandStairs: 128, bricks: 45, ironDoor: 71, farmland: 60,
    wheat: 59, carrots: 141, potatoes: 142, hay: 170, anvil: 145, enchant: 116, brewing: 117, cauldron: 118, enderChest: 130,
    ice: 79, packedIce: 174, log2: 162, leaves2: 161, lily: 111, vine: 106, obsidian: 49, deadBush: 32, pumpkin: 86, jackO: 91,
    gravel: 13, birchStairs: 135, jungleStairs: 136, sprucePlanks: 5, spruceGate: 183, darkGate: 186
  };
  // Ступени: высокая сторона на восток 0, запад 1, юг 2, север 3; +4 — перевёрнутые
  const ST = { e: 0, w: 1, s: 2, n: 3 };

  class Builder {
    constructor(name) { this.name = name; this.map = new Map(); }
    set(x, y, z, id, d) { this.map.set(x + ',' + y + ',' + z, [id, d || 0]); }
    fill(x0, y0, z0, x1, y1, z1, id, d) {
      for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) for (let z = Math.min(z0, z1); z <= Math.max(z0, z1); z++) this.set(x, y, z, id, d);
    }
    // Стены коробки без пола и потолка
    walls(x0, y0, z0, x1, y1, z1, id, d) {
      for (let y = y0; y <= y1; y++) {
        for (let x = x0; x <= x1; x++) { this.set(x, y, z0, id, d); this.set(x, y, z1, id, d); }
        for (let z = z0; z <= z1; z++) { this.set(x0, y, z, id, d); this.set(x1, y, z, id, d); }
      }
    }
    clear(x0, y0, z0, x1, y1, z1) { this.fill(x0, y0, z0, x1, y1, z1, 0, 0); }
    // Дверь: нижняя половина (направление), верхняя — бит 8
    door(x, y, z, dir, id) { this.set(x, y, z, id || B.door, dir); this.set(x, y + 1, z, id || B.door, 8); }
    // Двускатная крыша вдоль X над стенами z0..z1 (x0..x1): скаты из ступеней с выносом на 1 блок,
    // фронтоны на x0 и x1 из блока gable, конёк — плитой ridge
    roofX(x0, x1, z0, z1, y, stairs, gable, gd, ridge, rd) {
      for (let k = 0; ; k++) {
        const zn = z0 - 1 + k, zs = z1 + 1 - k, yy = y + k;
        if (zn > zs) break;
        for (let x = x0 - 1; x <= x1 + 1; x++) {
          if (zn === zs) this.set(x, yy, zn, ridge, rd);
          else { this.set(x, yy, zn, stairs, ST.s); this.set(x, yy, zs, stairs, ST.n); }
        }
        for (let z = zn + 1; z < zs; z++) { this.set(x0, yy, z, gable, gd); this.set(x1, yy, z, gable, gd); }
        if (zn === zs || zn + 1 === zs) break;
      }
    }
    // Купол: полусфера радиуса r (только оболочка толщиной 1) с центром в (cx, cy, cz), sy — сплюснутость по высоте
    // Оболочка — блоки купола, у которых хотя бы один сосед снаружи (без дыр при любой сплюснутости)
    dome(cx, cy, cz, r, id, d, sy) {
      const k = sy || 1;
      const inside = (dx, dy, dz) => dy < 0 || dx * dx + dz * dz + (dy * k) * (dy * k) <= (r + 0.5) * (r + 0.5);
      for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) for (let dy = 0; dy <= r; dy++) {
        if (!inside(dx, dy, dz)) continue;
        const shell = !inside(dx + 1, dy, dz) || !inside(dx - 1, dy, dz) || !inside(dx, dy + 1, dz) || !inside(dx, dy, dz + 1) || !inside(dx, dy, dz - 1);
        this.set(cx + dx, cy + dy, cz + dz, shell ? id : 0, shell ? d : 0);
      }
    }
    // Круг (диск) радиуса r на высоте y
    disk(cx, y, cz, r, id, d) {
      for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) if (dx * dx + dz * dz <= (r + 0.5) * (r + 0.5)) this.set(cx + dx, y, cz + dz, id, d);
    }
    // Кольцо толщиной 1 по краю диска
    ring(cx, y, cz, r, id, d) {
      for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) {
        const q = dx * dx + dz * dz;
        if (q <= (r + 0.5) * (r + 0.5) && q > (r - 0.5) * (r - 0.5)) this.set(cx + dx, y, cz + dz, id, d);
      }
    }
    // Дерево: ствол и шапка листвы
    tree(x, y, z, h, log, ld, leaves, lfd) {
      for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) for (let dy = h - 2; dy <= h + 1; dy++) {
        const r = dy >= h ? 1 : 2;
        if (Math.abs(dx) > r || Math.abs(dz) > r || (Math.abs(dx) === r && Math.abs(dz) === r && (dy === h + 1 || r === 2))) continue;
        this.set(x + dx, y + dy, z + dz, leaves, lfd);
      }
      this.fill(x, y, z, x, y + h - 1, z, log, ld);
    }
    // Кровать: ножки и изголовье (изголовье смещено по направлению)
    bed(x, y, z, dir) {
      const off = [[0, 1], [-1, 0], [0, -1], [1, 0]][dir];
      this.set(x, y, z, B.bed, dir);
      this.set(x + off[0], y, z + off[1], B.bed, dir | 8);
    }
    // Схема: в неё попадают только блоки (clear убирает ранее поставленные блоки самой постройки)
    result() {
      let x0 = Infinity, y0 = Infinity, z0 = Infinity, x1 = -Infinity, y1 = -Infinity, z1 = -Infinity;
      for (const k of this.map.keys()) {
        const [x, y, z] = k.split(',').map(Number);
        if (x < x0) x0 = x; if (y < y0) y0 = y; if (z < z0) z0 = z;
        if (x > x1) x1 = x; if (y > y1) y1 = y; if (z > z1) z1 = z;
      }
      const w = x1 - x0 + 1, h = y1 - y0 + 1, l = z1 - z0 + 1;
      const ids = new Uint8Array(w * h * l), meta = new Uint8Array(w * h * l);
      let count = 0;
      for (const [k, v] of this.map) {
        if (!v[0]) continue;
        const [x, y, z] = k.split(',').map(Number);
        const i = ((y - y0) * l + (z - z0)) * w + (x - x0);
        ids[i] = v[0];
        meta[i] = v[1] & 15;
        count++;
      }
      // ground — сколько слоёв лежит ниже слоя земли (y = 0): пруды, колодцы, фундаменты
      return { name: this.name, w, h, l, ids, meta, count, skipped: 0, added: 0, builtin: true, ground: Math.max(0, -y0) };
    }
  }

  // ---------- Уютный дом: каменный фундамент, бревенчатый каркас, двускатная крыша, сад ----------
  function cozyHouse() {
    const b = new Builder('Уютный дом');
    // Сад: трава и дорожка
    b.fill(-3, 0, -4, 13, 0, 12, B.grass);
    b.fill(4, 0, -4, 6, 0, -1, B.cobble);
    // Фундамент и пол
    b.fill(0, 0, 0, 10, 0, 8, B.sbrick);
    b.fill(1, 0, 1, 9, 0, 7, B.planks, 5);
    // Каркас: бревна по углам и у двери, стены из еловых досок
    b.walls(0, 1, 0, 10, 4, 8, B.planks, 1);
    for (const [x, z] of [[0, 0], [10, 0], [0, 8], [10, 8], [5, 8], [3, 0], [7, 0]]) b.fill(x, 1, z, x, 4, z, B.log, 0);
    b.fill(0, 4, 0, 10, 4, 0, B.log, 4); b.fill(0, 4, 8, 10, 4, 8, B.log, 4);
    b.fill(0, 4, 0, 0, 4, 8, B.log, 8); b.fill(10, 4, 0, 10, 4, 8, B.log, 8);
    b.clear(1, 1, 1, 9, 4, 7);
    // Окна
    for (const x of [1, 2, 8, 9]) b.fill(x, 2, 0, x, 3, 0, B.pane);
    for (const x of [2, 3, 7, 8]) b.fill(x, 2, 8, x, 3, 8, B.pane);
    for (const z of [3, 5]) { b.fill(0, 2, z, 0, 3, z, B.pane); b.fill(10, 2, z, 10, 3, z, B.pane); }
    // Дверь и крыльцо со ступенями
    b.door(5, 1, 0, 1);
    b.clear(4, 1, -1, 6, 3, -1);
    b.set(5, 0, -1, B.sbStairs, ST.s);
    b.set(4, 1, -1, B.fence); b.set(6, 1, -1, B.fence);
    b.set(4, 2, -1, B.torch, 5); b.set(6, 2, -1, B.torch, 5);
    // Двускатная крыша из ступеней тёмного дуба, фронтоны из досок
    for (let k = 0; k <= 4; k++) {
      const y = 5 + k;
      for (let x = -1; x <= 11; x++) { b.set(x, y, -1 + k, B.darkStairs, ST.s); b.set(x, y, 9 - k, B.darkStairs, ST.n); }
      if (k < 4) for (let z = k; z <= 8 - k; z++) { b.set(0, y, z, B.planks, 1); b.set(10, y, z, B.planks, 1); }
      if (k < 4) b.clear(1, y, k + 1, 9, y, 7 - k);
    }
    for (let x = -1; x <= 11; x++) b.set(x, 9, 4, B.woodSlab, 5);
    b.set(0, 6, 4, B.pane); b.set(10, 6, 4, B.pane);
    // Труба
    b.fill(8, 5, 6, 8, 10, 6, B.sbrick);
    b.set(8, 1, 6, B.furnace, 2);
    // Внутри: кровать, сундуки, верстак, печь, книжные полки, ковёр, свет
    b.bed(2, 1, 6, 0);
    b.bed(3, 1, 6, 0);
    b.set(1, 1, 7, B.chest, 2); b.set(9, 1, 7, B.chest, 2);
    b.set(9, 1, 1, B.table); b.set(9, 1, 2, B.furnace, 4);
    b.fill(6, 1, 7, 7, 3, 7, B.bookshelf);
    b.fill(3, 1, 3, 7, 1, 5, B.carpet, 14);
    b.fill(4, 1, 4, 6, 1, 4, B.carpet, 4);
    b.set(5, 0, 4, B.glowstone);
    b.set(1, 3, 4, B.torch, 1); b.set(9, 3, 4, B.torch, 2); b.set(5, 3, 7, B.torch, 4);
    // Сад: забор, цветы, деревья
    for (let x = -3; x <= 13; x++) { if (x < 4 || x > 6) b.set(x, 1, -4, B.fence); b.set(x, 1, 12, B.fence); }
    for (let z = -4; z <= 12; z++) { b.set(-3, 1, z, B.fence); b.set(13, 1, z, B.fence); }
    b.set(4, 1, -4, B.fence); b.set(6, 1, -4, B.fence); b.set(5, 1, -4, B.gate, 0);
    for (const [x, z, f] of [[1, -2, B.flowerR], [2, -3, B.flowerY], [8, -2, B.flowerY], [9, -3, B.flowerR], [-1, 2, B.flowerR], [11, 5, B.flowerY], [1, 10, B.flowerR], [9, 10, B.flowerY]]) b.set(x, 1, z, f);
    for (const [tx, tz] of [[-1, 10], [11, 10]]) {
      b.fill(tx, 1, tz, tx, 4, tz, B.log, 0);
      for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) for (let dy = 3; dy <= 5; dy++) {
        if (Math.abs(dx) + Math.abs(dz) + (dy - 3) > 4 || (dx === 0 && dz === 0 && dy < 5)) continue;
        if (tx + dx < -3 || tx + dx > 13 || tz + dz > 12) continue;
        b.set(tx + dx, dy, tz + dz, B.leaves, 0);
      }
    }
    return b.result();
  }

  // ---------- Башня-замок: круглая каменная башня с зубцами, этажами, лестницей и окнами ----------
  function castleTower() {
    const b = new Builder('Башня-замок');
    const R = 5, H = 16, cx = 0, cz = 0;
    const inDisk = (dx, dz, r) => dx * dx + dz * dz <= (r + 0.5) * (r + 0.5);
    for (let dx = -R - 1; dx <= R + 1; dx++) for (let dz = -R - 1; dz <= R + 1; dz++) {
      if (!inDisk(dx, dz, R)) continue;
      const wall = !inDisk(dx, dz, R - 1);
      b.set(cx + dx, 0, cz + dz, B.sbrick);
      for (let y = 1; y <= H; y++) {
        if (wall) b.set(cx + dx, y, cz + dz, (dx * 7 + dz * 3 + y) % 5 === 0 ? B.mossy : B.sbrick);
        else if (y % 5 === 0) b.set(cx + dx, y, cz + dz, B.planks, 5);
        else b.set(cx + dx, y, cz + dz, 0);
      }
      // Площадка наверху и зубцы
      b.set(cx + dx, H + 1, cz + dz, wall ? B.sbrick : B.planks, wall ? 0 : 5);
      if (wall && ((dx + dz) & 1) === 0) b.set(cx + dx, H + 2, cz + dz, B.sbrick);
    }
    // Пол этажей с проёмом для лестницы у северной стены
    for (const y of [5, 10, 15, H + 1]) { b.set(cx, y, cz - R + 1, 0); b.set(cx, y, cz - R + 2, 0); }
    for (let y = 1; y <= H + 1; y++) b.set(cx, y, cz - R + 1, B.ladder, 3);
    // Вход с дверью и аркой
    b.clear(cx - 1, 1, cz + R, cx + 1, 3, cz + R);
    b.door(cx, 1, cz + R, 3);
    b.set(cx - 1, 1, cz + R, B.sbrick); b.set(cx + 1, 1, cz + R, B.sbrick);
    b.set(cx - 1, 2, cz + R, B.sbrick); b.set(cx + 1, 2, cz + R, B.sbrick);
    b.set(cx - 1, 3, cz + R, B.sbStairs, ST.e | 4); b.set(cx + 1, 3, cz + R, B.sbStairs, ST.w | 4); b.set(cx, 3, cz + R, B.sbrick);
    b.set(cx - 1, 2, cz + R + 1, B.torch, 3); b.set(cx + 1, 2, cz + R + 1, B.torch, 3);
    // Окна-бойницы на каждом этаже
    for (const y of [3, 7, 8, 12, 13]) {
      b.set(cx + R, y, cz, B.bars); b.set(cx - R, y, cz, B.bars);
      if (y > 5) b.set(cx, y, cz + R, B.bars);
    }
    // Свет и обстановка
    for (const y of [2, 7, 12]) { b.set(cx + R - 1, y + 1, cz, B.torch, 2); b.set(cx - R + 1, y + 1, cz, B.torch, 1); }
    b.set(cx + 2, 1, cz - 2, B.table); b.set(cx + 3, 1, cz - 1, B.furnace, 4); b.set(cx - 3, 1, cz - 1, B.chest, 5); b.set(cx - 3, 1, cz, B.chest, 5);
    b.bed(cx + 2, 6, cz + 1, 2);
    b.fill(cx - 3, 6, cz + 1, cx - 3, 8, cz + 2, B.bookshelf);
    b.set(cx, 11, cz, B.glowstone);
    b.set(cx, H + 2, cz, B.fence); b.set(cx, H + 3, cz, B.fence); b.set(cx, H + 4, cz, B.wool, 14); b.set(cx + 1, H + 4, cz, B.wool, 14); b.set(cx + 1, H + 3, cz, B.wool, 14);
    // Ров с водой вокруг; каменные бортики с обеих сторон, чтобы вода не растекалась
    for (let dx = -R - 5; dx <= R + 5; dx++) for (let dz = -R - 5; dz <= R + 5; dz++) {
      const d = dx * dx + dz * dz;
      if (d > (R + 4.5) ** 2 || inDisk(dx, dz, R)) continue;
      if (d <= (R + 1.5) ** 2 || d > (R + 3.5) ** 2) { b.set(cx + dx, 0, cz + dz, B.sbrick); continue; }
      b.set(cx + dx, -1, cz + dz, B.sbrick);
      b.set(cx + dx, 0, cz + dz, B.water);
    }
    // Мост через ров к двери
    for (let z = R + 1; z <= R + 5; z++) b.fill(cx - 1, 0, cz + z, cx + 1, 0, cz + z, B.planks, 1);
    return b.result();
  }

  // ---------- Современный дом: кварц, большие окна, плоская крыша, бассейн ----------
  function modernHouse() {
    const b = new Builder('Современный дом');
    b.fill(-2, 0, -6, 15, 0, 10, B.grass);
    b.fill(0, 0, 0, 13, 0, 8, B.quartz);
    // Первый этаж
    b.walls(0, 1, 0, 13, 3, 8, B.quartz);
    b.clear(1, 1, 1, 12, 3, 7);
    for (let x = 1; x <= 12; x++) if (x < 6 || x > 7) b.fill(x, 1, 0, x, 3, 0, B.glass);
    for (let z = 2; z <= 6; z++) b.fill(13, 1, z, 13, 3, z, B.glass);
    b.door(6, 1, 0, 1); b.door(7, 1, 0, 1);
    b.fill(0, 4, 0, 13, 4, 8, B.quartz);
    // Второй этаж со сдвигом и террасой
    b.walls(4, 5, 2, 13, 7, 8, B.quartz);
    b.clear(5, 5, 3, 12, 7, 7);
    for (let x = 5; x <= 12; x++) b.fill(x, 5, 2, x, 7, 2, B.glass);
    b.fill(4, 8, 2, 13, 8, 8, B.slab, 6);
    for (let x = 0; x <= 3; x++) b.set(x, 5, 0, B.bars); for (let z = 0; z <= 8; z++) b.set(0, 5, z, B.bars);
    // Лестница внутри: проём в потолке над ней
    b.clear(2, 4, 7, 5, 4, 7);
    for (let i = 0; i < 4; i++) b.set(2 + i, 1 + i, 7, B.quartzStairs, ST.e);
    // Свет и мебель
    for (const [x, z] of [[3, 3], [9, 3], [3, 6], [9, 6]]) b.set(x, 4, z, B.seaLantern);
    b.set(8, 8, 5, B.seaLantern);
    b.fill(8, 1, 3, 10, 1, 5, B.carpet, 7);
    b.set(12, 1, 7, B.table); b.set(12, 1, 6, B.furnace, 4); b.set(11, 1, 7, B.chest, 2);
    b.bed(7, 5, 6, 0); b.bed(8, 5, 6, 0);
    b.set(12, 5, 7, B.chest, 2);
    b.set(1, 1, 1, B.flowerPot); b.set(12, 1, 1, B.flowerPot);
    // Бассейн перед домом
    b.fill(1, -2, -5, 12, -1, -2, B.quartz);
    b.walls(1, 0, -5, 12, 0, -2, B.quartz);
    b.fill(2, -1, -4, 11, 0, -3, B.water);
    b.set(1, 1, -5, B.seaLantern); b.set(12, 1, -5, B.seaLantern);
    return b.result();
  }

  // ---------- Стартовая хижина: маленький дом из того, что есть в начале игры ----------
  function starterCabin() {
    const b = new Builder('Стартовая хижина');
    b.fill(-1, 0, -2, 7, 0, 7, B.grass);
    b.fill(0, 0, 0, 6, 0, 6, B.cobble);
    b.walls(0, 1, 0, 6, 3, 6, B.planks, 0);
    for (const [x, z] of [[0, 0], [6, 0], [0, 6], [6, 6]]) b.fill(x, 1, z, x, 3, z, B.log, 0);
    b.clear(1, 1, 1, 5, 3, 5);
    b.set(0, 2, 3, B.pane); b.set(6, 2, 3, B.pane); b.set(2, 2, 6, B.pane); b.set(4, 2, 6, B.pane);
    b.door(3, 1, 0, 1);
    b.roofX(0, 6, 0, 6, 4, B.oakStairs, B.planks, 0, B.woodSlab, 0);
    b.bed(1, 1, 4, 0);
    b.set(5, 1, 5, B.chest, 2); b.set(4, 1, 5, B.chest, 2);
    b.set(5, 1, 1, B.table); b.set(5, 1, 2, B.furnace, 4);
    b.set(1, 3, 2, B.torch, 1); b.set(5, 3, 3, B.torch, 2);
    b.set(2, 1, -1, B.fence); b.set(2, 2, -1, B.torch, 5); b.set(4, 1, -1, B.fence); b.set(4, 2, -1, B.torch, 5);
    b.set(-1, 1, 2, B.flowerR); b.set(7, 1, 4, B.flowerY);
    return b.result();
  }

  // ---------- Двухэтажный дом: каменный низ, деревянный верх, балкон, лестница внутри ----------
  function twoStoryHouse() {
    const b = new Builder('Двухэтажный дом');
    b.fill(-2, 0, -4, 12, 0, 10, B.grass);
    b.fill(4, 0, -4, 6, 0, -1, B.gravel);
    b.fill(0, 0, 0, 10, 0, 8, B.cobble);
    b.fill(1, 0, 1, 9, 0, 7, B.planks, 1);
    // Первый этаж — булыжник, второй — еловые доски; бревна по углам
    b.walls(0, 1, 0, 10, 4, 8, B.cobble);
    b.fill(0, 5, 0, 10, 5, 8, B.planks, 1);
    b.walls(0, 6, 0, 10, 8, 8, B.planks, 1);
    for (const [x, z] of [[0, 0], [10, 0], [0, 8], [10, 8]]) b.fill(x, 1, z, x, 8, z, B.log, 1);
    b.clear(1, 1, 1, 9, 4, 7); b.clear(1, 6, 1, 9, 8, 7);
    // Окна
    for (const x of [2, 3, 7, 8]) { b.set(x, 2, 0, B.pane); b.set(x, 3, 0, B.pane); b.set(x, 7, 8, B.pane); }
    for (const z of [3, 5]) for (const y of [2, 3, 7]) { b.set(0, y, z, B.pane); b.set(10, y, z, B.pane); }
    b.set(2, 7, 0, B.pane); b.set(8, 7, 0, B.pane);
    // Входная дверь и дверь на балкон
    b.door(5, 1, 0, 1);
    b.door(5, 6, 0, 1);
    b.set(4, 3, -1, B.torch, 4); b.set(6, 3, -1, B.torch, 4);
    // Балкон над входом
    b.fill(2, 5, -2, 8, 5, -1, B.planks, 1);
    for (let x = 2; x <= 8; x++) b.set(x, 6, -2, B.fence, 1);
    b.set(2, 6, -1, B.fence, 1); b.set(8, 6, -1, B.fence, 1);
    b.fill(2, 1, -2, 2, 4, -2, B.log, 1); b.fill(8, 1, -2, 8, 4, -2, B.log, 1);
    // Крыша
    b.roofX(0, 10, 0, 8, 9, B.darkStairs, B.planks, 1, B.woodSlab, 5);
    b.set(0, 10, 4, B.pane); b.set(10, 10, 4, B.pane);
    // Лестница на второй этаж вдоль задней стены, проём в перекрытии
    for (let i = 0; i < 5; i++) b.set(1 + i, 1 + i, 7, B.oakStairs, ST.e);
    b.clear(1, 5, 7, 4, 5, 7);
    // Первый этаж: кухня и мастерская
    b.set(9, 1, 1, B.table); b.set(9, 1, 2, B.furnace, 4); b.set(9, 1, 3, B.furnace, 4);
    b.set(9, 1, 7, B.chest, 2); b.set(8, 1, 7, B.chest, 2); b.set(7, 1, 7, B.chest, 2);
    b.fill(2, 1, 2, 5, 1, 4, B.carpet, 12);
    b.set(1, 1, 1, B.flowerPot);
    b.set(5, 4, 4, B.glowstone);
    // Второй этаж: спальня и библиотека
    b.bed(7, 6, 5, 0); b.bed(8, 6, 5, 0);
    b.fill(1, 6, 1, 1, 7, 4, B.bookshelf);
    b.set(9, 6, 1, B.chest, 4);
    b.fill(3, 6, 2, 6, 6, 4, B.carpet, 14);
    b.set(5, 9, 4, B.glowstone);
    // Деревья у дома
    b.tree(-1, 1, 8, 5, B.log, 2, B.leaves, 2);
    b.tree(11, 1, -2, 5, B.log, 0, B.leaves, 0);
    return b.result();
  }

  // ---------- Крепость: стены с зубцами, 4 башни, ворота, донжон, ферма и колодец внутри ----------
  function fortress() {
    const b = new Builder('Крепость');
    const N = 26, H = 6;
    b.fill(0, 0, 0, N, 0, N, B.grass);
    // Стены и дорожка по верху
    for (let y = 1; y <= H; y++) for (let i = 0; i <= N; i++) for (const [x, z] of [[i, 0], [i, N], [0, i], [N, i]]) {
      b.set(x, y, z, (x * 3 + z * 5 + y) % 7 === 0 ? B.mossy : B.sbrick);
    }
    for (let i = 1; i < N; i++) for (const [x, z] of [[i, 1], [i, N - 1], [1, i], [N - 1, i]]) b.set(x, H, z, B.planks, 5);
    for (let i = 0; i <= N; i += 2) for (const [x, z] of [[i, 0], [i, N], [0, i], [N, i]]) b.set(x, H + 1, z, B.sbrick);
    // Башни по углам 5×5 с лестницами
    for (const [tx, tz] of [[-1, -1], [N - 3, -1], [-1, N - 3], [N - 3, N - 3]]) {
      b.walls(tx, 0, tz, tx + 4, H + 4, tz + 4, B.sbrick);
      b.fill(tx + 1, 0, tz + 1, tx + 3, 0, tz + 3, B.sbrick);
      b.clear(tx + 1, 1, tz + 1, tx + 3, H + 4, tz + 3);
      b.fill(tx + 1, H, tz + 1, tx + 3, H, tz + 3, B.planks, 5);
      b.fill(tx + 1, H + 4, tz + 1, tx + 3, H + 4, tz + 3, B.planks, 5);
      for (let i = 0; i <= 4; i += 2) for (const [x, z] of [[tx + i, tz], [tx + i, tz + 4], [tx, tz + i], [tx + 4, tz + i]]) b.set(x, H + 5, z, B.sbrick);
      for (let y = 1; y <= H + 4; y++) b.set(tx + 2, y, tz + 1, B.ladder, 3);
      // Выход из башни на стену
      const cx = tx < 0 ? tx + 4 : tx, cz = tz < 0 ? tz + 4 : tz;
      b.clear(tx + 2, H + 1, cz, tx + 2, H + 2, cz); b.clear(cx, H + 1, tz + 2, cx, H + 2, tz + 2);
      for (const y of [3, 8]) { b.set(tx + 2, y, tz < 0 ? tz : tz + 4, B.bars); b.set(tx < 0 ? tx : tx + 4, y, tz + 2, B.bars); }
      b.set(tx + 2, H + 5, tz + 2, B.fence); b.set(tx + 2, H + 6, tz + 2, B.glowstone);
    }
    // Вход в башни с земли
    for (const [x, z] of [[3, 2], [N - 3, 2], [3, N - 2], [N - 3, N - 2]]) b.clear(x, 1, z, x, 2, z);
    // Ворота
    b.clear(12, 1, 0, 14, 4, 0);
    b.set(12, 4, 0, B.sbStairs, ST.e | 4); b.set(14, 4, 0, B.sbStairs, ST.w | 4);
    b.set(11, 3, -1, B.torch, 4); b.set(15, 3, -1, B.torch, 4);
    b.set(11, 3, 1, B.torch, 3); b.set(15, 3, 1, B.torch, 3);
    // Мощёная дорога к донжону
    b.fill(12, 0, -3, 14, 0, 15, B.cobble);
    // Донжон
    b.fill(8, 0, 15, 18, 0, 24, B.sbrick);
    b.walls(8, 1, 15, 18, 7, 24, B.sbrick);
    b.clear(9, 1, 16, 17, 7, 23);
    b.fill(8, 8, 15, 18, 8, 24, B.sbrick);
    for (let i = 0; i <= 10; i += 2) { b.set(8 + i, 9, 15, B.sbrick); b.set(8 + i, 9, 24, B.sbrick); }
    for (let i = 0; i <= 9; i += 3) { b.set(8, 9, 15 + i, B.sbrick); b.set(18, 9, 15 + i, B.sbrick); }
    b.door(13, 1, 15, 1);
    b.fill(9, 4, 16, 17, 4, 23, B.planks, 5);
    for (let i = 0; i < 4; i++) b.set(17, 1 + i, 19 + i, B.sbStairs, ST.s);
    b.clear(17, 4, 19, 17, 4, 21);
    for (const x of [10, 11, 15, 16]) { b.set(x, 2, 15, B.bars); b.set(x, 6, 15, B.bars); b.set(x, 6, 24, B.bars); }
    // Низ: оружейная и мастерская
    b.set(9, 1, 16, B.table); b.set(9, 1, 17, B.furnace, 5); b.set(9, 1, 18, B.furnace, 5); b.set(9, 1, 19, B.anvil, 0);
    for (let x = 9; x <= 13; x++) b.set(x, 1, 23, B.chest, 2);
    b.set(13, 3, 19, B.glowstone);
    b.set(9, 3, 21, B.torch, 1); b.set(16, 3, 17, B.torch, 2);
    // Верх: спальня и зачарования
    b.bed(10, 5, 21, 0); b.bed(11, 5, 21, 0); b.bed(12, 5, 21, 0);
    b.set(14, 5, 19, B.enchant);
    for (const [x, z] of [[12, 17], [13, 17], [14, 17], [15, 17], [16, 17], [12, 18], [16, 18], [12, 19], [16, 19]]) b.fill(x, 5, z, x, 6, z, B.bookshelf);
    b.set(9, 5, 16, B.brewing); b.set(10, 5, 16, B.cauldron); b.set(9, 5, 17, B.enderChest, 5);
    b.set(13, 7, 20, B.glowstone);
    // Ферма с водой посередине
    b.fill(2, -1, 4, 10, -1, 12, B.dirt);
    b.fill(2, 0, 4, 10, 0, 12, B.farmland, 7);
    b.fill(2, 1, 4, 10, 1, 12, B.wheat, 7);
    b.fill(6, 0, 4, 6, 0, 12, B.water);
    b.clear(6, 1, 4, 6, 1, 12);
    for (let z = 4; z <= 12; z += 4) b.set(6, 1, z, B.lily);
    // Колодец
    b.fill(19, -3, 5, 21, -1, 7, B.cobble);
    b.walls(19, 0, 5, 21, 1, 7, B.cobble);
    b.set(20, -2, 6, B.water); b.set(20, -1, 6, B.water); b.set(20, 0, 6, B.water); b.set(20, 1, 6, 0);
    for (const [x, z] of [[19, 5], [21, 5], [19, 7], [21, 7]]) b.fill(x, 2, z, x, 3, z, B.fence);
    b.fill(19, 4, 5, 21, 4, 7, B.slab, 3);
    // Загон для животных
    for (let x = 18; x <= 24; x++) { b.set(x, 1, 10, B.fence); b.set(x, 1, 13, B.fence); }
    for (let z = 10; z <= 13; z++) b.set(18, 1, z, B.fence);
    b.set(18, 1, 11, B.gate, 1);
    b.set(23, 1, 12, B.hay); b.set(24, 1, 12, B.hay); b.set(24, 2, 12, B.hay);
    return b.result();
  }

  // ---------- Пустынный дом: песчаник, терракота, плоская крыша с выходом, кактусовый сад ----------
  function desertHouse() {
    const b = new Builder('Пустынный дом');
    b.fill(-3, 0, -4, 13, 0, 13, B.sand);
    b.fill(0, 0, 0, 10, 0, 10, B.sandstone, 2);
    b.walls(0, 1, 0, 10, 4, 10, B.sandstone, 0);
    for (const [x, z] of [[0, 0], [10, 0], [0, 10], [10, 10]]) b.fill(x, 1, z, x, 5, z, B.sandstone, 2);
    for (let i = 1; i <= 9; i++) for (const [x, z] of [[i, 0], [i, 10], [0, i], [10, i]]) b.set(x, 4, z, B.sandstone, 1);
    b.clear(1, 1, 1, 9, 4, 9);
    b.fill(0, 5, 0, 10, 5, 10, B.sandstone, 2);
    for (let i = 0; i <= 10; i++) for (const [x, z] of [[i, 0], [i, 10], [0, i], [10, i]]) b.set(x, 6, z, B.slab, 1);
    // Полоса из оранжевой терракоты и окна
    for (let i = 1; i <= 9; i++) for (const [x, z] of [[i, 0], [i, 10], [0, i], [10, i]]) b.set(x, 1, z, B.terracotta, 1);
    for (const i of [2, 3, 7, 8]) { b.fill(i, 2, 0, i, 3, 0, B.pane); b.fill(i, 2, 10, i, 3, 10, B.pane); b.fill(0, 2, i, 0, 3, i, B.pane); b.fill(10, 2, i, 10, 3, i, B.pane); }
    b.door(5, 1, 0, 1);
    b.set(5, 0, -1, B.sandStairs, ST.s);
    b.set(4, 3, -1, B.torch, 4); b.set(6, 3, -1, B.torch, 4);
    // Выход на крышу
    for (let y = 1; y <= 5; y++) b.set(9, y, 9, B.ladder, 4);
    // Обстановка
    b.fill(2, 0, 2, 8, 0, 8, B.terracotta, 0);
    b.fill(3, 1, 3, 7, 1, 7, B.carpet, 1);
    b.fill(4, 1, 4, 6, 1, 6, B.carpet, 14);
    b.bed(1, 1, 7, 0); b.bed(2, 1, 7, 0);
    b.set(9, 1, 1, B.table); b.set(9, 1, 2, B.furnace, 4); b.set(9, 1, 3, B.chest, 4); b.set(9, 1, 4, B.chest, 4);
    b.set(1, 1, 1, B.flowerPot); b.set(9, 1, 7, B.flowerPot);
    b.set(5, 5, 5, B.glowstone);
    // Навес на крыше
    for (const [x, z] of [[2, 2], [5, 2], [2, 5], [5, 5]]) b.fill(x, 6, z, x, 7, z, B.fence);
    b.fill(2, 8, 2, 5, 8, 5, B.wool, 14);
    // Кактусы и сухие кусты вокруг
    for (const [x, z] of [[-2, -3], [-2, 6], [12, -2], [12, 9], [3, 12], [8, 12]]) b.fill(x, 1, z, x, 2, z, B.cactus);
    for (const [x, z] of [[-1, 2], [11, 4], [6, 12], [1, -3], [9, -3]]) b.set(x, 1, z, B.deadBush);
    return b.result();
  }

  // ---------- Японский дом: веранда, бумажные стены, широкая крыша, пруд и сакура ----------
  function japaneseHouse() {
    const b = new Builder('Японский дом');
    b.fill(-6, 0, -9, 16, 0, 12, B.grass);
    b.fill(-1, 0, -1, 11, 0, 9, B.cobble);
    b.fill(-1, 1, -1, 11, 1, 9, B.planks, 1);
    // Стены: тёмные балки и белые «бумажные» панели
    b.walls(0, 2, 0, 10, 4, 8, B.wool, 0);
    for (const x of [0, 3, 7, 10]) { b.fill(x, 2, 0, x, 4, 0, B.log2, 1); b.fill(x, 2, 8, x, 4, 8, B.log2, 1); }
    for (const z of [4]) { b.fill(0, 2, z, 0, 4, z, B.log2, 1); b.fill(10, 2, z, 10, 4, z, B.log2, 1); }
    b.fill(0, 5, 0, 10, 5, 8, B.planks, 5);
    b.clear(1, 2, 1, 9, 4, 7);
    for (const x of [1, 2, 8, 9]) b.set(x, 3, 0, B.pane);
    b.door(5, 2, 0, 1);
    // Крыша с широким выносом и приподнятыми углами
    for (let k = 0; k <= 5; k++) {
      const y = 6 + k;
      if (k > 4) break;
      for (let x = -2 + k; x <= 12 - k; x++) { b.set(x, y, -2 + k, B.darkStairs, ST.s); b.set(x, y, 10 - k, B.darkStairs, ST.n); }
      for (let z = -1 + k; z <= 9 - k; z++) { b.set(-2 + k, y, z, B.darkStairs, ST.e); b.set(12 - k, y, z, B.darkStairs, ST.w); }
      if (k < 4) b.fill(-1 + k, y, -1 + k, 11 - k, y, 9 - k, B.planks, 5);
    }
    b.fill(3, 10, 3, 7, 10, 5, B.woodSlab, 5);
    for (const [x, z] of [[-2, -2], [12, -2], [-2, 10], [12, 10]]) b.set(x, 6, z, B.darkStairs, ST.e | 4);
    // Фонари на столбах у входа и по углам веранды
    for (const [x, z] of [[-1, -1], [11, -1], [-1, 9], [11, 9]]) { b.fill(x, 2, z, x, 5, z, B.fence, 5); }
    for (const [x, z] of [[2, -4], [8, -4]]) { b.fill(x, 1, z, x, 2, z, B.fence, 5); b.set(x, 3, z, B.glowstone); b.set(x, 4, z, B.woodSlab, 5); }
    b.fill(4, 0, -8, 6, 0, -2, B.gravel);
    b.set(5, 1, -2, B.planks, 1);
    // Комната: низкий стол, подушки, свитки
    b.fill(4, 2, 3, 6, 2, 5, B.woodSlab, 5);
    for (const [x, z] of [[3, 4], [7, 4], [5, 2], [5, 6]]) b.set(x, 2, z, B.carpet, 14);
    b.bed(1, 2, 6, 0); b.bed(9, 2, 6, 0);
    b.set(1, 2, 1, B.chest, 5); b.set(9, 2, 1, B.table); b.set(9, 2, 2, B.furnace, 4);
    b.set(5, 5, 4, B.glowstone);
    // Пруд с кувшинками
    b.fill(-5, -1, -8, 1, -1, -3, B.cobble);
    b.fill(-4, 0, -7, 0, 0, -4, B.water);
    for (const [x, z] of [[-3, -6], [-1, -5]]) b.set(x, 1, z, B.lily);
    // Сакура: тёмный ствол и розовая крона
    b.tree(13, 1, -5, 5, B.log2, 1, B.wool, 6);
    b.tree(-4, 1, 9, 4, B.log2, 1, B.wool, 6);
    return b.result();
  }

  // ---------- Дом на дереве: огромное дерево, площадка с перилами, хижина вокруг ствола ----------
  function treeHouse() {
    const b = new Builder('Дом на дереве');
    b.fill(-8, 0, -8, 9, 0, 9, B.grass);
    // Крона: несколько шаров листвы
    const blob = (cx, cy, cz, r) => {
      for (let dx = -r; dx <= r; dx++) for (let dy = -r; dy <= r; dy++) for (let dz = -r; dz <= r; dz++) {
        if (dx * dx + dy * dy * 2 + dz * dz <= r * r + 1) b.set(cx + dx, cy + dy, cz + dz, B.leaves, 3);
      }
    };
    blob(0, 16, 0, 5); blob(4, 14, 3, 3); blob(-3, 15, -3, 3); blob(3, 15, -3, 3); blob(-3, 14, 3, 3);
    // Ствол 2×2 из тропического дерева и корни
    b.fill(0, 1, 0, 1, 16, 1, B.log, 3);
    for (const [x, z] of [[-1, 0], [2, 1], [1, -1], [0, 2]]) b.set(x, 1, z, B.log, 3);
    // Площадка с перилами
    b.fill(-5, 8, -5, 6, 8, 6, B.planks, 3);
    b.fill(0, 8, 0, 1, 8, 1, B.log, 3);
    for (let i = -5; i <= 6; i++) for (const [x, z] of [[i, -5], [i, 6], [-5, i], [6, i]]) b.set(x, 9, z, B.fence, 3);
    for (const [x, z] of [[-5, -5], [6, -5], [-5, 6], [6, 6]]) b.fill(x, 1, z, x, 7, z, B.log, 3);
    // Хижина вокруг ствола
    b.walls(-3, 9, -3, 4, 11, 4, B.planks, 3);
    for (const [x, z] of [[-3, -3], [4, -3], [-3, 4], [4, 4]]) b.fill(x, 9, z, x, 11, z, B.log, 3);
    b.clear(-2, 9, -2, 3, 11, 3);
    b.fill(0, 9, 0, 1, 11, 1, B.log, 3);
    for (const i of [-1, 2]) { b.set(i, 10, -3, B.pane); b.set(i, 10, 4, B.pane); b.set(-3, 10, i, B.pane); b.set(4, 10, i, B.pane); }
    b.door(-1, 9, 4, 3);
    b.roofX(-3, 4, -3, 4, 12, B.jungleStairs, B.planks, 3, B.woodSlab, 3);
    // Лестница по стволу и лаз в полу хижины
    for (let y = 1; y <= 8; y++) b.set(0, y, -1, B.ladder, 2);
    b.set(0, 8, -1, B.ladder, 2);
    // Внутри
    b.bed(2, 9, 2, 0);
    b.set(-2, 9, 3, B.chest, 2); b.set(-2, 9, -2, B.table); b.set(3, 9, -2, B.furnace, 4);
    b.set(-2, 11, 0, B.torch, 1); b.set(3, 11, 0, B.torch, 2);
    for (const [x, z] of [[-5, -2], [6, 2], [2, -5], [-2, 6]]) b.set(x, 10, z, B.torch, 5);
    // Лоза на стволе
    for (let y = 2; y <= 7; y++) { if (y % 2) b.set(2, y, 0, B.vine, 2); else b.set(-1, y, 1, B.vine, 8); }
    return b.result();
  }

  // ---------- Иглу: снежный купол, ледяные окна, вход-тоннель ----------
  function igloo() {
    const b = new Builder('Иглу');
    const R = 5;
    b.disk(0, 0, 0, R + 4, B.snow);
    b.disk(0, 0, 0, R - 1, B.packedIce);
    b.dome(0, 1, 0, R, B.snow, 0, 1);
    // Ледяные окна
    for (const [x, z] of [[R, 0], [-R, 0], [0, -R]]) b.set(x, 2, z, B.ice);
    // Тоннель на юг
    b.walls(-1, 1, R - 1, 1, 3, R + 2, B.snow);
    b.fill(-1, 4, R - 1, 1, 4, R + 2, B.snow);
    b.clear(0, 1, R - 1, 0, 2, R + 2);
    b.clear(-1, 1, R + 2, 1, 3, R + 2);
    b.fill(-1, 1, R + 2, -1, 3, R + 2, B.snow); b.fill(1, 1, R + 2, 1, 3, R + 2, B.snow);
    b.set(0, 3, R + 2, B.snow);
    // Внутри
    b.fill(-2, 1, -2, 2, 1, 2, B.carpet, 3);
    b.bed(-3, 1, -1, 2);
    b.set(3, 1, -1, B.furnace, 4); b.set(3, 1, 1, B.chest, 4); b.set(2, 1, -3, B.table);
    b.set(0, 1, 0, B.carpet, 0);
    b.set(0, R, 0, B.glowstone);
    b.set(-1, 3, R + 3, B.torch, 3); b.set(1, 3, R + 3, B.torch, 3);
    return b.result();
  }

  // ---------- Ферма: две грядки 9×9 с водой, амбар, пугало ----------
  function farm() {
    const b = new Builder('Ферма');
    b.fill(-3, 0, -4, 29, 0, 12, B.grass);
    b.fill(-1, -1, -1, 19, -1, 9, B.dirt);
    for (const [ox, crop] of [[0, B.wheat], [10, B.carrots]]) {
      b.fill(ox, 0, 0, ox + 8, 0, 8, B.farmland, 7);
      for (let x = ox; x <= ox + 8; x++) for (let z = 0; z <= 8; z++) {
        const c = ox === 10 && x > ox + 4 ? B.potatoes : crop;
        b.set(x, 1, z, c, 7);
      }
      b.set(ox + 4, 0, 4, B.water);
      b.set(ox + 4, 1, 4, B.lily);
    }
    b.fill(9, 0, 0, 9, 0, 8, B.gravel);
    // Забор с калиткой
    for (let x = -1; x <= 19; x++) { b.set(x, 1, -1, B.fence); b.set(x, 1, 9, B.fence); }
    for (let z = -1; z <= 9; z++) { b.set(-1, 1, z, B.fence); b.set(19, 1, z, B.fence); }
    b.set(9, 1, -1, B.gate, 0);
    b.set(19, 1, 4, B.gate, 1);
    // Пугало
    b.set(9, 1, 4, B.fence); b.set(9, 2, 4, B.hay); b.set(9, 3, 4, B.jackO, 2);
    // Амбар: красные стены, белые углы, двускатная крыша
    const ax = 21;
    b.fill(ax, 0, 0, ax + 7, 0, 8, B.planks, 1);
    b.walls(ax, 1, 0, ax + 7, 4, 8, B.terracotta, 14);
    for (const [x, z] of [[ax, 0], [ax + 7, 0], [ax, 8], [ax + 7, 8]]) b.fill(x, 1, z, x, 4, z, B.quartz);
    b.clear(ax + 1, 1, 1, ax + 6, 4, 7);
    b.clear(ax, 1, 3, ax, 3, 5);
    b.roofX(ax, ax + 7, 0, 8, 5, B.darkStairs, B.terracotta, 14, B.woodSlab, 5);
    for (const [x, z] of [[ax + 5, 1], [ax + 6, 1], [ax + 6, 2], [ax + 5, 7], [ax + 6, 7], [ax + 6, 6]]) b.set(x, 1, z, B.hay);
    b.set(ax + 6, 2, 1, B.hay);
    b.set(ax + 1, 1, 7, B.chest, 2); b.set(ax + 2, 1, 7, B.chest, 2); b.set(ax + 1, 1, 1, B.table);
    b.set(ax + 3, 3, 1, B.torch, 3); b.set(ax + 3, 3, 7, B.torch, 4);
    b.set(ax - 1, 3, 2, B.torch, 2); b.set(ax - 1, 3, 6, B.torch, 2);
    return b.result();
  }

  // ---------- Маяк: полосатая башня, комната со светом, балкон ----------
  function lighthouse() {
    const b = new Builder('Маяк');
    const R = 3, H = 18;
    b.disk(0, 0, 0, R + 4, B.cobble);
    b.disk(0, 0, 0, R - 1, B.planks, 0);
    for (let y = 1; y <= H; y++) b.ring(0, y, 0, R, Math.floor((y - 1) / 3) % 2 ? B.wool : B.quartz, Math.floor((y - 1) / 3) % 2 ? 14 : 0);
    for (let y = 1; y <= H; y++) b.disk(0, y, 0, R - 1, 0);
    // Лестница у северной стены, вход с юга
    for (let y = 1; y <= H + 1; y++) b.set(0, y, -R + 1, B.ladder, 3);
    b.door(0, 1, R, 3);
    b.set(-1, 3, R + 1, B.torch, 3); b.set(1, 3, R + 1, B.torch, 3);
    for (const y of [6, 12]) { b.set(R, y, 0, B.pane); b.set(-R, y, 0, B.pane); b.set(0, y, R, B.pane); }
    // Балкон и площадка
    b.disk(0, H + 1, 0, R + 1, B.sbrick);
    b.set(0, H + 1, -R + 1, B.ladder, 3);
    b.ring(0, H + 2, 0, R + 1, B.fence);
    // Фонарная комната: стекло, светокамень, красная крыша
    b.ring(0, H + 2, 0, R - 1, B.glass); b.ring(0, H + 3, 0, R - 1, B.glass); b.ring(0, H + 4, 0, R - 1, B.glass);
    b.set(0, H + 2, -R + 1, 0); b.set(0, H + 3, -R + 1, 0);
    b.fill(0, H + 2, 0, 0, H + 4, 0, B.glowstone);
    b.disk(0, H + 5, 0, R - 1, B.wool, 14);
    b.disk(0, H + 6, 0, R - 2, B.wool, 14);
    b.set(0, H + 7, 0, B.wool, 14);
    // Каморка смотрителя
    b.set(1, 1, -1, B.chest, 4); b.bed(-1, 1, -1, 0); b.set(1, 1, 1, B.table);
    b.set(R - 1, 4, 0, B.torch, 2); b.set(-R + 1, 10, 0, B.torch, 1); b.set(R - 1, 16, 0, B.torch, 2);
    return b.result();
  }

  // ---------- Купол-оранжерея: стеклянная полусфера, сад и пруд внутри ----------
  function glassDome() {
    const b = new Builder('Купол-оранжерея');
    const R = 9;
    b.disk(0, -1, 0, R + 1, B.stone);
    b.disk(0, 0, 0, R + 1, B.quartz);
    b.disk(0, 0, 0, R - 2, B.grass);
    b.dome(0, 1, 0, R, B.glass, 0, 1.2);
    // Дорожка, вход и светильники в полу
    b.fill(-1, 0, 2, 1, 0, R + 1, B.quartz);
    b.door(0, 1, R, 3);
    b.set(-1, 1, R, B.glass); b.set(1, 1, R, B.glass); b.set(-1, 2, R, B.glass); b.set(1, 2, R, B.glass);
    for (const [x, z] of [[-6, -3], [6, -3], [-6, 4], [6, 4], [0, -7]]) b.set(x, 0, z, B.seaLantern);
    // Пруд в центре
    b.fill(-2, -2, -2, 2, -2, 2, B.stone);
    b.disk(0, -1, 0, 2, B.water);
    b.disk(0, 0, 0, 2, B.water);
    b.ring(0, 0, 0, 3, B.quartz);
    b.set(1, 1, -1, B.lily);
    // Деревья и цветы
    b.tree(-5, 1, -4, 4, B.log, 2, B.leaves, 2);
    b.tree(5, 1, -4, 4, B.log, 0, B.leaves, 0);
    for (const [x, z, f] of [[-4, 2, B.flowerR], [-3, 4, B.flowerY], [4, 2, B.flowerY], [3, 5, B.flowerR], [-6, 0, B.flowerR], [6, 0, B.flowerY], [0, -5, B.flowerR]]) b.set(x, 1, z, f);
    // Уголок для жилья
    b.bed(-6, 1, 5, 2); b.bed(-5, 1, 5, 2);
    b.set(5, 1, 6, B.chest, 2); b.set(6, 1, 5, B.table); b.set(6, 1, 4, B.furnace, 4);
    b.set(0, 8, 0, B.glowstone);
    return b.result();
  }

  // ---------- Ловушка: динамит под нажимной плитой ----------
  // Плита стоит на траве; под травой 3×3 динамита. Игрок или моб наступает — динамит поджигается (4 секунды)
  function tntTrap() {
    const b = new Builder('Ловушка: динамит под плитой');
    b.fill(-2, 0, -2, 2, 0, 2, B.dirt);
    b.fill(-1, 0, -1, 1, 0, 1, B.tnt);
    b.fill(-2, 1, -2, 2, 1, 2, B.grass);
    b.set(0, 2, 0, B.plate);
    b.set(-2, 2, -2, B.tallGrass, 1); b.set(2, 2, 1, B.tallGrass, 1); b.set(1, 2, -2, B.flowerR);
    return b.result();
  }

  // ---------- Ловушка: коридор с люком над лавой ----------
  // В коридоре нажимная плита: блок под ней запитан, соседний люк открывается, и идущий дальше падает в лаву
  function lavaTrap() {
    const b = new Builder('Ловушка: люк над лавой');
    // Коридор вдоль Z: стены x=0 и x=2, пол на y=3
    b.fill(0, 0, 0, 2, 3, 6, B.sbrick);
    b.walls(0, 4, 0, 2, 5, 6, B.sbrick);
    b.clear(1, 4, 0, 1, 5, 6);
    b.fill(0, 6, 0, 2, 6, 6, B.sbrick);
    // Яма 1×1 глубиной 3 с лавой на дне
    b.set(1, 1, 3, 0); b.set(1, 2, 3, 0);
    b.set(1, 0, 3, B.lava);
    // Люк заподлицо с полом (верхняя половина, закрыт) и плита перед ним
    b.set(1, 3, 3, B.trapdoor, 4);
    b.set(1, 4, 2, B.plate);
    // Входы с обоих концов и факел на стене
    b.clear(1, 4, 0, 1, 5, 0);
    b.clear(1, 4, 6, 1, 5, 6);
    b.set(1, 5, 1, B.torch, 1);
    return b.result();
  }

  // ---------- Ловушка: паутина и кактусы ----------
  // Яма 3×3 глубиной 6 в травяной площадке: паутина на полпути замедляет, внизу кактусы на песке.
  // Мобы и игроки, которые в неё падают, погибают
  function cactusPit() {
    const b = new Builder('Ловушка: яма с кактусами');
    b.fill(-3, 0, -3, 3, 6, 3, B.dirt);
    b.fill(-3, 6, -3, 3, 6, 3, B.grass);
    b.clear(-1, 1, -1, 1, 6, 1);
    b.fill(-1, 0, -1, 1, 0, 1, B.sand);
    for (const [x, z] of [[-1, -1], [1, -1], [-1, 1], [1, 1], [0, 0]]) b.set(x, 1, z, B.cactus);
    for (const [x, z] of [[0, -1], [-1, 0], [1, 0], [0, 1]]) b.set(x, 3, z, B.web);
    b.set(-3, 7, -3, B.tallGrass, 1); b.set(3, 7, 2, B.tallGrass, 1); b.set(2, 7, -3, B.flowerY);
    return b.result();
  }

  const LIST = [
    { id: 'cozy', kind: 'base', make: cozyHouse, desc: 'дом с садом, кроватями, печью и сундуками' },
    { id: 'tower', kind: 'base', make: castleTower, desc: 'круглая башня 3 этажа, ров и мост' },
    { id: 'modern', kind: 'base', make: modernHouse, desc: 'кварц, большие окна, терраса и бассейн' },
    { id: 'starter', kind: 'base', make: starterCabin, desc: 'маленькая хижина 7×7 для первой ночи' },
    { id: 'twostory', kind: 'base', make: twoStoryHouse, desc: 'два этажа, балкон, спальня и библиотека' },
    { id: 'fortress', kind: 'base', make: fortress, desc: 'стены, 4 башни, донжон, ферма и колодец' },
    { id: 'desert', kind: 'base', make: desertHouse, desc: 'песчаник, плоская крыша с навесом, кактусы' },
    { id: 'japan', kind: 'base', make: japaneseHouse, desc: 'веранда, широкая крыша, пруд и сакура' },
    { id: 'treehouse', kind: 'base', make: treeHouse, desc: 'хижина на огромном дереве с лестницей' },
    { id: 'igloo', kind: 'base', make: igloo, desc: 'снежный купол с тоннелем и ледяными окнами' },
    { id: 'farm', kind: 'base', make: farm, desc: 'пшеница, морковь, картофель, амбар и пугало' },
    { id: 'lighthouse', kind: 'base', make: lighthouse, desc: 'полосатая башня с фонарём и балконом' },
    { id: 'dome', kind: 'base', make: glassDome, desc: 'стеклянный купол с садом и прудом' },
    { id: 'tnt', kind: 'trap', make: tntTrap, desc: 'плита на траве, под ней динамит' },
    { id: 'lava', kind: 'trap', make: lavaTrap, desc: 'плита в коридоре открывает люк над лавой' },
    { id: 'cactus', kind: 'trap', make: cactusPit, desc: 'яма с паутиной и кактусами для мобов' }
  ];
  const cache = {};
  function get(id) {
    if (!cache[id]) { const s = LIST.find((x) => x.id === id); cache[id] = s.make(); }
    return cache[id];
  }

  MC.Structures = { LIST, get };
})();
