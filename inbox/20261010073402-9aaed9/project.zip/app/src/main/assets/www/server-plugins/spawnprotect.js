// Защита спавна: рядом с точкой спавна обычные игроки не ломают и не ставят блоки, не открывают сундуки и не дерутся.
// /spawnprotect <радиус> — изменить радиус (оператор), 0 — выключить.
plugin.name = 'SpawnProtect';
plugin.version = '1.0';
plugin.description = 'Защита спавна от гриферов и PvP';
plugin.author = 'Minecraft HTML';

function radius() { return plugin.data.radius === undefined ? 16 : plugin.data.radius; }

function near(x, z) {
  var r = radius();
  if (r <= 0) return false;
  var s = server.spawn();
  return Math.abs(x - s.x) <= r && Math.abs(z - s.z) <= r;
}

function guard(e) {
  if (e.player.op || !near(e.x, e.z)) return;
  e.cancel();
  e.player.popup('§cСпавн защищён');
}

server.on('blockBreak', guard);
server.on('blockPlace', guard);
server.on('interact', function (e) {
  // Сундуки, печи, двери и рычаги на спавне — только операторам
  if ([54, 146, 61, 62, 64, 71, 69, 77, 143, 96, 107, 145].indexOf(e.id) >= 0) guard(e);
});
server.on('attack', function (e) {
  if (near(e.player.x, e.player.z) || near(e.target.x, e.target.z)) { e.cancel(); e.player.popup('§cНа спавне нельзя драться'); }
});

server.command('spawnprotect', { description: 'Радиус защиты спавна', usage: '/spawnprotect <радиус>', op: true }, function (p, a) {
  var r = Math.floor(Number(a[0]));
  var msg;
  if (isNaN(r) || r < 0 || r > 256) msg = '§7Радиус защиты: ' + radius() + '. Изменить: /spawnprotect <0-256>';
  else { plugin.data.radius = r; plugin.save(); msg = r ? '§aСпавн защищён в радиусе ' + r : '§aЗащита спавна выключена'; }
  if (p) return msg;
  server.log(msg);
});
