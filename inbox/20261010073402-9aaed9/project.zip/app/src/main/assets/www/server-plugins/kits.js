// Наборы: /kit — список, /kit <имя> — получить. Стартовый выдаётся один раз, остальные с перезарядкой.
plugin.name = 'Kits';
plugin.version = '1.0';
plugin.description = 'Наборы предметов: /kit start, tools, food, armor';
plugin.author = 'Minecraft HTML';

var KITS = {
  start: { title: 'Стартовый', once: true, items: [[268, 0, 1], [270, 0, 1], [271, 0, 1], [269, 0, 1], [297, 0, 8], [50, 0, 16], [58, 0, 1]] },
  tools: { title: 'Каменные инструменты', cooldown: 600, items: [[272, 0, 1], [274, 0, 1], [275, 0, 1], [273, 0, 1]] },
  food: { title: 'Еда', cooldown: 300, items: [[297, 0, 16], [364, 0, 8], [260, 0, 8]] },
  armor: { title: 'Железная броня', cooldown: 3600, items: [[306, 0, 1], [307, 0, 1], [308, 0, 1], [309, 0, 1]] },
  builder: { title: 'Строитель (оператор)', op: true, cooldown: 0, items: [[5, 0, 64], [4, 0, 64], [20, 0, 64], [17, 0, 32], [50, 0, 32], [45, 0, 64]] }
};

function fmt(sec) {
  if (sec >= 3600) return Math.floor(sec / 3600) + ' ч ' + Math.floor(sec % 3600 / 60) + ' мин';
  if (sec >= 60) return Math.floor(sec / 60) + ' мин ' + (sec % 60) + ' с';
  return sec + ' с';
}

server.command('kit', { description: 'Наборы предметов', usage: '/kit [имя]', aliases: ['kits'] }, function (p, args) {
  if (!p) return;
  if (!args[0]) {
    var names = Object.keys(KITS).filter(function (k) { return !KITS[k].op || p.op; });
    return '§aНаборы: §f' + names.map(function (k) { return k + ' §7(' + KITS[k].title + ')§f'; }).join(', ') + '\n§7Получить: /kit <имя>';
  }
  var name = args[0].toLowerCase();
  var kit = KITS[name];
  if (!kit || (kit.op && !p.op)) return '§cНет набора «' + name + '»';
  var k = p.name.toLowerCase();
  var used = plugin.data[k] = plugin.data[k] || {};
  var now = Date.now();
  if (kit.once && used[name]) return '§cЭтот набор выдаётся один раз';
  if (kit.cooldown && used[name] && now - used[name] < kit.cooldown * 1000)
    return '§cНабор снова будет доступен через ' + fmt(Math.ceil((kit.cooldown * 1000 - (now - used[name])) / 1000));
  var lost = 0;
  for (var i = 0; i < kit.items.length; i++) {
    var it = kit.items[i];
    var left = p.give(it[0], it[1], it[2]);
    if (left > 0) { server.dropItem(p.x, p.y + 1, p.z, it[0], it[1], left); lost++; }
  }
  used[name] = now;
  plugin.save();
  return '§aВы получили набор «' + kit.title + '»' + (lost ? ' §7(инвентарь полон, часть выпала рядом)' : '');
});
