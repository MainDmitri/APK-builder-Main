// Экономика: монеты за руду, магазин, продажа, переводы.
// /money [игрок], /pay <игрок> <сумма>, /baltop, /shop, /buy <товар> [кол-во], /sell [all], /eco give|take|set <игрок> <сумма> (оператор)
plugin.name = 'Economy';
plugin.version = '1.0';
plugin.description = 'Монеты: /money, /pay, /baltop, /shop, /buy, /sell';
plugin.author = 'Minecraft HTML';

var START = 100;
// Награда за добычу руды в режиме выживания
var ORE = { 16: 1, 15: 3, 14: 5, 73: 2, 74: 2, 21: 4, 56: 15, 129: 20, 153: 2 };
// Товары: имя -> [id, data, кол-во за покупку, цена покупки, цена продажи за штуку]
var SHOP = {
  bread: [297, 0, 4, 10, 1], steak: [364, 0, 4, 20, 2], apple: [260, 0, 4, 8, 1], golden_apple: [322, 0, 1, 150, 30],
  torch: [50, 0, 16, 8, 0], log: [17, 0, 16, 20, 1], planks: [5, 0, 32, 10, 0], cobblestone: [4, 0, 64, 10, 0],
  glass: [20, 0, 16, 16, 0], coal: [263, 0, 8, 16, 1], iron: [265, 0, 4, 40, 6], gold: [266, 0, 4, 60, 9],
  diamond: [264, 0, 1, 120, 25], emerald: [388, 0, 1, 150, 30], redstone: [331, 0, 16, 32, 1], lapis: [351, 4, 8, 32, 2],
  iron_pickaxe: [257, 0, 1, 90, 0], diamond_pickaxe: [278, 0, 1, 400, 0], diamond_sword: [276, 0, 1, 280, 0],
  bow: [261, 0, 1, 60, 0], arrow: [262, 0, 16, 20, 0], bucket: [325, 0, 1, 40, 0], bed: [355, 0, 1, 40, 0],
  saddle: [329, 0, 1, 100, 0], tnt: [46, 0, 4, 80, 0], wool: [35, 0, 16, 24, 0]
};

function bal() { if (!plugin.data.bal) plugin.data.bal = {}; return plugin.data.bal; }
function get(name) { var b = bal(), k = name.toLowerCase(); if (b[k] === undefined) b[k] = START; return b[k]; }
function set(name, v) { bal()[name.toLowerCase()] = Math.max(0, Math.floor(v)); plugin.save(); }
function money(v) { return v + ' монет'; }
function reply(p, m) { if (p) p.send(m); else server.log(m.replace(/§./g, '')); }

function priceOf(id, data) {
  for (var k in SHOP) if (SHOP[k][0] === id && SHOP[k][1] === data && SHOP[k][4] > 0) return SHOP[k][4];
  return 0;
}

server.on('join', function (e) { get(e.player.name); plugin.save(); });

server.on('blockBreak', function (e) {
  var p = e.player;
  if (p.gamemode !== 0 || !ORE[e.id]) return;
  // Без кирки руда ничего не даёт
  if ([270, 274, 257, 285, 278].indexOf(p.held.id) < 0) return;
  var r = ORE[e.id];
  set(p.name, get(p.name) + r);
  p.popup('§6+' + money(r));
});

server.command('money', { description: 'Баланс', usage: '/money [игрок]', aliases: ['bal', 'balance'] }, function (p, a) {
  if (a[0]) return reply(p, '§aБаланс ' + a[0] + ': §6' + money(get(a[0])));
  if (!p) return;
  return '§aВаш баланс: §6' + money(get(p.name));
});

server.command('pay', { description: 'Перевести монеты', usage: '/pay <игрок> <сумма>' }, function (p, a) {
  if (!p) return;
  var amount = Math.floor(Number(a[1]));
  if (!a[0] || !(amount > 0)) return '§cИспользование: /pay <игрок> <сумма>';
  var t = server.player(a[0]);
  if (!t) return '§cИгрок не в сети';
  if (t.name === p.name) return '§cНельзя перевести себе';
  if (get(p.name) < amount) return '§cНе хватает монет. Баланс: ' + money(get(p.name));
  set(p.name, get(p.name) - amount);
  set(t.name, get(t.name) + amount);
  t.send('§a' + p.name + ' перевёл вам §6' + money(amount));
  return '§aПереведено §6' + money(amount) + '§a игроку ' + t.name;
});

server.command('baltop', { description: 'Самые богатые игроки', aliases: ['moneytop'] }, function (p) {
  var b = bal();
  var top = Object.keys(b).sort(function (x, y) { return b[y] - b[x]; }).slice(0, 10);
  var lines = ['§6Богачи сервера:'];
  for (var i = 0; i < top.length; i++) lines.push('§e' + (i + 1) + '. §f' + top[i] + ' §7— §6' + money(b[top[i]]));
  return reply(p, lines.join('\n'));
});

server.command('shop', { description: 'Магазин', usage: '/shop [страница]' }, function (p, a) {
  var keys = Object.keys(SHOP);
  var page = Math.max(1, Math.floor(Number(a[0]) || 1));
  var pages = Math.ceil(keys.length / 9);
  if (page > pages) page = pages;
  var lines = ['§6Магазин (' + page + '/' + pages + '): §7/buy <товар> [раз], /sell — продать в руке'];
  keys.slice((page - 1) * 9, page * 9).forEach(function (k) {
    var s = SHOP[k];
    lines.push('§e' + k + ' §fx' + s[2] + ' §7— §6' + s[3] + (s[4] ? ' §7(продажа ' + s[4] + '/шт)' : ''));
  });
  if (page < pages) lines.push('§7Дальше: /shop ' + (page + 1));
  return reply(p, lines.join('\n'));
});

server.command('buy', { description: 'Купить товар', usage: '/buy <товар> [раз]' }, function (p, a) {
  if (!p) return;
  var s = SHOP[(a[0] || '').toLowerCase()];
  if (!s) return '§cНет такого товара. Список: /shop';
  var times = Math.max(1, Math.min(64, Math.floor(Number(a[1]) || 1)));
  var cost = s[3] * times;
  if (get(p.name) < cost) return '§cНужно ' + money(cost) + ', у вас ' + money(get(p.name));
  set(p.name, get(p.name) - cost);
  var left = p.give(s[0], s[1], s[2] * times);
  if (left > 0) server.dropItem(p.x, p.y + 1, p.z, s[0], s[1], left);
  return '§aКуплено: ' + a[0].toLowerCase() + ' x' + (s[2] * times) + ' за §6' + money(cost);
});

server.command('sell', { description: 'Продать предмет в руке или всё', usage: '/sell [all]' }, function (p, a) {
  if (!p) return;
  var total = 0, count = 0;
  if ((a[0] || '').toLowerCase() === 'all') {
    var inv = p.inventory();
    for (var i = 0; i < inv.length; i++) {
      var price = priceOf(inv[i].id, inv[i].data);
      if (!price) continue;
      p.setSlot(inv[i].slot, 0, 0, 0);
      total += price * inv[i].count; count += inv[i].count;
    }
  } else {
    var h = p.held;
    var pr = h ? priceOf(h.id, h.data) : 0;
    if (!pr) return '§cЭтот предмет не покупают. Что можно продать: /shop';
    if (!p.take(h.id, h.data, h.count)) return '§cНе удалось забрать предмет';
    total = pr * h.count; count = h.count;
  }
  if (!count) return '§cНечего продавать';
  set(p.name, get(p.name) + total);
  return '§aПродано ' + count + ' шт. за §6' + money(total);
});

server.command('eco', { description: 'Управление монетами', usage: '/eco <give|take|set> <игрок> <сумма>', op: true }, function (p, a) {
  var n = Math.floor(Number(a[2]));
  if (!a[1] || isNaN(n)) return reply(p, '§cИспользование: /eco <give|take|set> <игрок> <сумма>');
  var cur = get(a[1]);
  if (a[0] === 'give') set(a[1], cur + n);
  else if (a[0] === 'take') set(a[1], cur - n);
  else if (a[0] === 'set') set(a[1], n);
  else return reply(p, '§cИспользование: /eco <give|take|set> <игрок> <сумма>');
  reply(p, '§aБаланс ' + a[1] + ': §6' + money(get(a[1])));
});
