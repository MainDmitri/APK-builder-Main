// Состояния блоков Java Edition 1.13+ («minecraft:oak_stairs[facing=east,half=top]») → номер и данные Java 1.12.
// Нужны для схем .schem (WorldEdit/Sponge), .litematic (Litematica) и .nbt (структурный блок).
// Блоки, которых нет в 1.12, заменяются похожими (approx), чтобы постройка не разваливалась.
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  const COLORS = ['white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink', 'gray', 'light_gray', 'cyan', 'purple', 'blue', 'brown', 'green', 'red', 'black'];
  const WOODS = ['oak', 'spruce', 'birch', 'jungle', 'acacia', 'dark_oak'];
  // Новые породы дерева (1.16+) — как ближайшая из 1.12
  const WOOD_ALIAS = { crimson: 'dark_oak', warped: 'jungle', mangrove: 'jungle', cherry: 'birch', bamboo: 'jungle', pale_oak: 'birch' };

  const H_SWNE = { south: 0, west: 1, north: 2, east: 3 }; // кровать, тыква, калитка, повторитель, наковальня
  const H_NSWE = { north: 2, south: 3, west: 4, east: 5 }; // сундук, печь, лестница, табличка на стене
  const F6 = { down: 0, up: 1, north: 2, south: 3, west: 4, east: 5 }; // поршень, раздатчик, наблюдатель
  const STAIR = { east: 0, west: 1, south: 2, north: 3 };
  const DOOR = { east: 0, south: 1, west: 2, north: 3 };
  const TORCH = { east: 1, west: 2, south: 3, north: 4 };
  const TRAP = { north: 0, south: 1, west: 2, east: 3 };
  const AXIS = { y: 0, x: 4, z: 8 };
  const RAIL = { north_south: 0, east_west: 1, ascending_east: 2, ascending_west: 3, ascending_north: 4, ascending_south: 5, south_east: 6, south_west: 7, north_west: 8, north_east: 9 };

  const STAIRS = {
    oak: 53, cobblestone: 67, brick: 108, stone_brick: 109, nether_brick: 114, sandstone: 128, spruce: 134, birch: 135, jungle: 136,
    quartz: 156, acacia: 163, dark_oak: 164, red_sandstone: 180, purpur: 203
  };
  // Плиты: [одинарная, двойная, данные]
  const SLABS = {
    smooth_stone: [44, 43, 0], stone: [44, 43, 0], sandstone: [44, 43, 1], petrified_oak: [44, 43, 2], cobblestone: [44, 43, 3], brick: [44, 43, 4],
    stone_brick: [44, 43, 5], nether_brick: [44, 43, 6], quartz: [44, 43, 7], red_sandstone: [182, 181, 0], purpur: [205, 204, 0]
  };
  WOODS.forEach((w, i) => { SLABS[w] = [126, 125, i]; });
  const FENCE = { oak: 85, spruce: 188, birch: 189, jungle: 190, dark_oak: 191, acacia: 192 };
  const GATE = { oak: 107, spruce: 183, birch: 184, jungle: 185, dark_oak: 186, acacia: 187 };
  const DOORS = { oak: 64, iron: 71, spruce: 193, birch: 194, jungle: 195, acacia: 196, dark_oak: 197 };

  // Простые блоки: имя → [id, data]
  const S = {
    air: null, cave_air: null, void_air: null, structure_void: null, barrier: null, light: null, moving_piston: null, piston_head: null,
    stone: [1, 0], granite: [1, 1], polished_granite: [1, 2], diorite: [1, 3], polished_diorite: [1, 4], andesite: [1, 5], polished_andesite: [1, 6],
    grass_block: [2, 0], dirt: [3, 0], coarse_dirt: [3, 1], podzol: [3, 2], cobblestone: [4, 0], bedrock: [7, 0],
    sand: [12, 0], red_sand: [12, 1], gravel: [13, 0], gold_ore: [14, 0], iron_ore: [15, 0], coal_ore: [16, 0],
    sponge: [19, 0], wet_sponge: [19, 1], glass: [20, 0], lapis_ore: [21, 0], lapis_block: [22, 0],
    sandstone: [24, 0], chiseled_sandstone: [24, 1], cut_sandstone: [24, 2], smooth_sandstone: [24, 2],
    note_block: [25, 0], cobweb: [30, 0], grass: [31, 1], short_grass: [31, 1], fern: [31, 2], dead_bush: [32, 0],
    dandelion: [37, 0], poppy: [38, 0], blue_orchid: [38, 1], allium: [38, 2], azure_bluet: [38, 3], red_tulip: [38, 4], orange_tulip: [38, 5],
    white_tulip: [38, 6], pink_tulip: [38, 7], oxeye_daisy: [38, 8], cornflower: [38, 1], lily_of_the_valley: [38, 6],
    brown_mushroom: [39, 0], red_mushroom: [40, 0], gold_block: [41, 0], iron_block: [42, 0], bricks: [45, 0], tnt: [46, 0],
    bookshelf: [47, 0], mossy_cobblestone: [48, 0], obsidian: [49, 0], spawner: [52, 0], diamond_ore: [56, 0], diamond_block: [57, 0],
    crafting_table: [58, 0], redstone_ore: [73, 0], ice: [79, 0], snow_block: [80, 0], cactus: [81, 0], clay: [82, 0], sugar_cane: [83, 0],
    jukebox: [84, 0], pumpkin: [86, 0], netherrack: [87, 0], soul_sand: [88, 0], glowstone: [89, 0],
    stone_bricks: [98, 0], mossy_stone_bricks: [98, 1], cracked_stone_bricks: [98, 2], chiseled_stone_bricks: [98, 3],
    infested_stone: [97, 0], infested_cobblestone: [97, 1], infested_stone_bricks: [97, 2], infested_mossy_stone_bricks: [97, 3],
    infested_cracked_stone_bricks: [97, 4], infested_chiseled_stone_bricks: [97, 5],
    brown_mushroom_block: [99, 14], red_mushroom_block: [100, 14], mushroom_stem: [99, 15],
    iron_bars: [101, 0], glass_pane: [102, 0], melon: [103, 0], mycelium: [110, 0], lily_pad: [111, 0], nether_bricks: [112, 0],
    nether_brick_fence: [113, 0], enchanting_table: [116, 0], brewing_stand: [117, 0], end_stone: [121, 0], dragon_egg: [122, 0],
    emerald_ore: [129, 0], emerald_block: [133, 0], beacon: [138, 0], cobblestone_wall: [139, 0], mossy_cobblestone_wall: [139, 1],
    flower_pot: [140, 0], redstone_block: [152, 0], nether_quartz_ore: [153, 0], quartz_block: [155, 0], chiseled_quartz_block: [155, 1],
    smooth_quartz: [155, 0], slime_block: [165, 0], prismarine: [168, 0], prismarine_bricks: [168, 1], dark_prismarine: [168, 2],
    sea_lantern: [169, 0], terracotta: [172, 0], coal_block: [173, 0], packed_ice: [174, 0], blue_ice: [174, 0],
    red_sandstone: [179, 0], chiseled_red_sandstone: [179, 1], cut_red_sandstone: [179, 2], smooth_red_sandstone: [179, 2],
    chorus_plant: [199, 0], chorus_flower: [200, 0], purpur_block: [201, 0], end_stone_bricks: [206, 0], grass_path: [208, 0], dirt_path: [208, 0],
    magma_block: [213, 0], nether_wart_block: [214, 0], red_nether_bricks: [215, 0], frosted_ice: [212, 0],
    smooth_stone: [43, 8], tripwire: [132, 0], end_portal: [119, 0], end_gateway: [209, 0], nether_portal: [90, 1], fire: null, soul_fire: null,
    structure_block: null, jigsaw: null
  };
  // Похожие замены для блоков, которых нет в 1.12 (помечаются approx)
  const APPROX = {
    seagrass: null, tall_seagrass: null, kelp: null, kelp_plant: null, bubble_column: null,
    dried_kelp_block: [173, 0], conduit: [169, 0], sea_pickle: [169, 0], turtle_egg: null,
    smooth_basalt: [1, 5], basalt: [1, 5], polished_basalt: [1, 6], blackstone: [173, 0], polished_blackstone: [173, 0], polished_blackstone_bricks: [173, 0],
    gilded_blackstone: [173, 0], chiseled_polished_blackstone: [173, 0], cracked_polished_blackstone_bricks: [173, 0],
    deepslate: [1, 5], cobbled_deepslate: [4, 0], polished_deepslate: [1, 6], deepslate_bricks: [98, 0], cracked_deepslate_bricks: [98, 2],
    deepslate_tiles: [98, 0], cracked_deepslate_tiles: [98, 2], chiseled_deepslate: [98, 3], reinforced_deepslate: [49, 0],
    tuff: [1, 5], calcite: [155, 0], dripstone_block: [1, 5], amethyst_block: [201, 0], budding_amethyst: [201, 0],
    copper_block: [45, 0], cut_copper: [45, 0], exposed_copper: [45, 0], weathered_copper: [168, 0], oxidized_copper: [168, 0],
    raw_iron_block: [42, 0], raw_gold_block: [41, 0], raw_copper_block: [45, 0], netherite_block: [173, 0], ancient_debris: [87, 0],
    crying_obsidian: [49, 0], respawn_anchor: [49, 0], lodestone: [98, 3], target: [170, 0], honey_block: [165, 0], honeycomb_block: [170, 0],
    bee_nest: [170, 0], beehive: [5, 0], shroomlight: [89, 0], crimson_nylium: [87, 0], warped_nylium: [87, 0], soul_soil: [88, 0],
    warped_wart_block: [168, 2], moss_block: [2, 0], rooted_dirt: [3, 1], mud: [3, 0], packed_mud: [3, 1], mud_bricks: [45, 0],
    sculk: [173, 0], smooth_quartz_block: [155, 0], quartz_bricks: [155, 1], cracked_nether_bricks: [112, 0], chiseled_nether_bricks: [112, 0],
    lantern: [89, 0], soul_lantern: [89, 0], ochre_froglight: [89, 0], verdant_froglight: [89, 0], pearlescent_froglight: [89, 0],
    composter: [5, 0], barrel: [5, 0], smoker: [61, 0], blast_furnace: [61, 0], cartography_table: [58, 0], fletching_table: [58, 0],
    smithing_table: [58, 0], loom: [58, 0], stonecutter: [43, 8], grindstone: [1, 0], lectern: [47, 0], bell: [41, 0], scaffolding: null,
    tinted_glass: [95, 15], glow_lichen: null, cave_vines: null, cave_vines_plant: null, spore_blossom: null, big_dripleaf: null, small_dripleaf: null,
    azalea: [18, 0], flowering_azalea: [18, 0], hanging_roots: null, moss_carpet: [171, 5], pointed_dripstone: null, sweet_berry_bush: null,
    bamboo: null, bamboo_sapling: null, wither_rose: [38, 0], torchflower: [37, 0], pitcher_plant: null
  };
  for (const c of ['tube', 'brain', 'bubble', 'fire', 'horn']) {
    const col = { tube: 11, brain: 6, bubble: 10, fire: 14, horn: 4 }[c];
    APPROX[c + '_coral_block'] = [35, col]; APPROX['dead_' + c + '_coral_block'] = [35, 7];
    for (const f of ['_coral', '_coral_fan', '_coral_wall_fan']) { APPROX[c + f] = null; APPROX['dead_' + c + f] = null; }
  }

  function bool(v) { return v === true || v === 'true' || v === 1 || v === '1'; }
  function num(v, d) { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; }
  function woodOf(prefix) {
    if (WOODS.includes(prefix)) return { w: prefix, approx: false };
    if (WOOD_ALIAS[prefix]) return { w: WOOD_ALIAS[prefix], approx: true };
    return null;
  }
  const R = (id, data, approx) => ({ id, data: data & 15, approx: !!approx });

  // Разбор строки «minecraft:name[a=b,c=d]»
  function parseState(str) {
    const i = str.indexOf('[');
    const name = i < 0 ? str : str.slice(0, i);
    const props = {};
    if (i >= 0) {
      for (const kv of str.slice(i + 1, str.lastIndexOf(']')).split(',')) {
        const e = kv.indexOf('=');
        if (e > 0) props[kv.slice(0, e).trim()] = kv.slice(e + 1).trim();
      }
    }
    return { name, props };
  }

  function stairsData(p) { return (STAIR[p.facing] || 0) | (p.half === 'top' ? 4 : 0); }
  function slab(t, p) {
    if (p.type === 'double') return R(t[1], t[2]);
    return R(t[0], t[2] | (p.type === 'top' ? 8 : 0));
  }
  function door(id, p) {
    if (p.half === 'upper') return R(id, 8 | (p.hinge === 'right' ? 1 : 0) | (bool(p.powered) ? 2 : 0));
    return R(id, (DOOR[p.facing] || 0) | (bool(p.open) ? 4 : 0));
  }
  function gate(id, p) { return R(id, (H_SWNE[p.facing] || 0) | (bool(p.open) ? 4 : 0)); }
  function trapdoor(id, p) { return R(id, (TRAP[p.facing] || 0) | (bool(p.open) ? 4 : 0) | (p.half === 'top' ? 8 : 0)); }
  // Кнопки и рычаги в 1.12: 0 потолок, 1–4 стена (восток, запад, юг, север), 5 пол
  function button(id, p) {
    let d = p.face === 'ceiling' ? 0 : p.face === 'floor' ? 5 : (TORCH[p.facing] || 1);
    return R(id, d | (bool(p.powered) ? 8 : 0));
  }
  function lever(p) {
    const ns = p.facing === 'north' || p.facing === 'south';
    let d = p.face === 'ceiling' ? (ns ? 7 : 0) : p.face === 'floor' ? (ns ? 5 : 6) : (TORCH[p.facing] || 1);
    return R(69, d | (bool(p.powered) ? 8 : 0));
  }
  function rail(id, p) { return R(id, (RAIL[p.shape] || 0) | (id !== 66 && bool(p.powered) ? 8 : 0)); }
  function log(w, p, wood) {
    const i = WOODS.indexOf(w);
    const id = i < 4 ? 17 : 162;
    return R(id, (i & 3) | (wood ? 12 : (AXIS[p.axis] || 0)));
  }

  // Имена Java 1.12 (Litematica для 1.12 хранит их со свойствами variant/color/type)
  const OLD = {
    planks: (p) => R(5, Math.max(0, WOODS.indexOf(p.variant))),
    log: (p) => R(17, Math.max(0, WOODS.indexOf(p.variant)) | (p.axis === 'none' ? 12 : AXIS[p.axis] || 0)),
    log2: (p) => R(162, Math.max(0, WOODS.indexOf(p.variant) - 4) | (p.axis === 'none' ? 12 : AXIS[p.axis] || 0)),
    leaves: (p) => R(18, Math.max(0, WOODS.indexOf(p.variant)) | 4),
    leaves2: (p) => R(161, Math.max(0, WOODS.indexOf(p.variant) - 4) | 4),
    sapling: (p) => R(6, Math.max(0, WOODS.indexOf(p.type))),
    wool: (p) => R(35, Math.max(0, COLORS.indexOf(color12(p.color)))),
    stained_glass: (p) => R(95, Math.max(0, COLORS.indexOf(color12(p.color)))),
    stained_glass_pane: (p) => R(160, Math.max(0, COLORS.indexOf(color12(p.color)))),
    stained_hardened_clay: (p) => R(159, Math.max(0, COLORS.indexOf(color12(p.color)))),
    carpet: (p) => R(171, Math.max(0, COLORS.indexOf(color12(p.color)))),
    concrete: (p) => R(251, Math.max(0, COLORS.indexOf(color12(p.color)))),
    concrete_powder: (p) => R(252, Math.max(0, COLORS.indexOf(color12(p.color)))),
    hardened_clay: () => R(172, 0),
    stonebrick: (p) => R(98, Math.max(0, ['stonebrick', 'mossy_stonebrick', 'cracked_stonebrick', 'chiseled_stonebrick'].indexOf(p.variant))),
    brick_block: () => R(45, 0), nether_brick: () => R(112, 0), red_nether_brick: () => R(215, 0), end_bricks: () => R(206, 0),
    magma: () => R(213, 0), melon_block: () => R(103, 0), web: () => R(30, 0), noteblock: () => R(25, 0), waterlily: () => R(111, 0),
    deadbush: () => R(32, 0), yellow_flower: () => R(37, 0), lit_pumpkin: (p) => R(91, H_SWNE[p.facing] || 0),
    lit_redstone_lamp: () => R(124, 0), lit_furnace: (p) => R(62, H_NSWE[p.facing] || 2), quartz_ore: () => R(153, 0),
    stone_stairs: (p) => R(67, stairsData(p)), fence: () => R(85, 0), fence_gate: (p) => gate(107, p), trapdoor: (p) => trapdoor(96, p),
    wooden_door: (p) => door(64, p), wooden_button: (p) => button12(143, p), wooden_pressure_plate: () => R(72, 0),
    unlit_redstone_torch: (p) => R(75, p.facing === 'up' ? 5 : TORCH[p.facing] || 5),
    tallgrass: (p) => R(31, p.type === 'fern' ? 2 : p.type === 'dead_bush' ? 0 : 1),
    double_plant: (p) => R(175, p.half === 'upper' ? 10 : Math.max(0, ['sunflower', 'syringa', 'double_grass', 'double_fern', 'double_rose', 'paeonia'].indexOf(p.variant))),
    red_flower: (p) => R(38, Math.max(0, ['poppy', 'blue_orchid', 'allium', 'houstonia', 'red_tulip', 'orange_tulip', 'white_tulip', 'pink_tulip', 'oxeye_daisy'].indexOf(p.type))),
    stone_slab: (p) => R(44, Math.max(0, ['stone', 'sand', 'wood_old', 'cobblestone', 'brick', 'smoothStoneBrick', 'netherBrick', 'quartz'].indexOf(p.variant)) | (p.half === 'top' ? 8 : 0)),
    double_stone_slab: (p) => R(43, Math.max(0, ['stone', 'sand', 'wood_old', 'cobblestone', 'brick', 'smoothStoneBrick', 'netherBrick', 'quartz'].indexOf(p.variant))),
    wooden_slab: (p) => R(126, Math.max(0, WOODS.indexOf(p.variant)) | (p.half === 'top' ? 8 : 0)),
    double_wooden_slab: (p) => R(125, Math.max(0, WOODS.indexOf(p.variant))),
    stone_slab2: (p) => R(182, p.half === 'top' ? 8 : 0), purpur_slab: (p) => R(205, p.half === 'top' ? 8 : 0),
    silver_glazed_terracotta: (p) => R(243, H_SWNE[p.facing] || 0),
    prismarine: (p) => R(168, Math.max(0, ['prismarine', 'prismarine_bricks', 'dark_prismarine'].indexOf(p.variant))),
    quartz_block: (p) => R(155, Math.max(0, ['default', 'chiseled', 'lines_y', 'lines_x', 'lines_z'].indexOf(p.variant))),
    sand: (p) => R(12, p.variant === 'red_sand' ? 1 : 0),
    dirt: (p) => R(3, Math.max(0, ['dirt', 'coarse_dirt', 'podzol'].indexOf(p.variant))),
    sandstone: (p) => R(24, Math.max(0, ['sandstone', 'chiseled_sandstone', 'smooth_sandstone'].indexOf(p.type))),
    red_sandstone: (p) => R(179, Math.max(0, ['red_sandstone', 'chiseled_red_sandstone', 'smooth_red_sandstone'].indexOf(p.type))),
    monster_egg: () => R(97, 0), mob_spawner: () => R(52, 0), snow_layer: (p) => R(78, num(p.layers, 1) - 1), snow: () => R(80, 0),
    reeds: () => R(83, 0), golden_rail: (p) => rail(27, p), standing_sign: (p) => R(63, num(p.rotation, 0)),
    flowing_water: () => null, flowing_lava: () => null, grass: () => R(2, 0)
  };
  // Цвета 1.12: silver = светло-серый
  function color12(c) { return c === 'silver' ? 'light_gray' : c; }
  function button12(id, p) {
    const d = p.facing === 'down' ? 0 : p.facing === 'up' ? 5 : (TORCH[p.facing] || 1);
    return R(id, d | (bool(p.powered) ? 8 : 0));
  }

  // DataVersion < 1451 — схема из Java 1.12 и старше (старые имена)
  function legacy(fullName, props, old) {
    const p = props || {};
    if (!fullName) return null;
    const ci = fullName.indexOf(':');
    const ns = ci < 0 ? 'minecraft' : fullName.slice(0, ci);
    const n = ci < 0 ? fullName : fullName.slice(ci + 1);
    if (ns !== 'minecraft') return null;
    if (old && OLD[n]) return OLD[n](p);
    if (S[n] !== undefined) return S[n] ? R(S[n][0], S[n][1]) : null;

    // Жидкости: только источники
    if (n === 'water' || n === 'lava') return num(p.level, 0) === 0 ? R(n === 'water' ? 9 : 11, 0) : null;

    // Цветные блоки
    for (let c = 0; c < 16; c++) {
      const col = COLORS[c];
      if (!n.startsWith(col + '_')) continue;
      const rest = n.slice(col.length + 1);
      switch (rest) {
        case 'wool': return R(35, c);
        case 'stained_glass': return R(95, c);
        case 'stained_glass_pane': return R(160, c);
        case 'terracotta': return R(159, c);
        case 'carpet': return R(171, c);
        case 'concrete': return R(251, c);
        case 'concrete_powder': return R(252, c);
        case 'glazed_terracotta': return R(235 + c, H_SWNE[p.facing] || 0);
        case 'shulker_box': return R(219 + c, F6[p.facing] || 1);
        case 'bed': return R(26, (H_SWNE[p.facing] || 0) | (p.part === 'head' ? 8 : 0));
        case 'banner': case 'wall_banner': return null;
        case 'candle': case 'candle_cake': return null;
      }
    }
    if (n === 'shulker_box') return R(229, F6[p.facing] || 1);
    if (n.endsWith('_banner') || n.endsWith('_head') || n.endsWith('_skull')) return null;

    // Дерево
    for (const suf of ['_planks', '_log', '_wood', '_leaves', '_sapling', '_slab', '_stairs', '_fence', '_fence_gate', '_door', '_trapdoor', '_button', '_pressure_plate', '_sign', '_wall_sign', '_hanging_sign', '_wall_hanging_sign', '_stem', '_hyphae']) {
      if (!n.endsWith(suf)) continue;
      let pre = n.slice(0, n.length - suf.length);
      const stripped = pre.startsWith('stripped_');
      if (stripped) pre = pre.slice(9);
      const wd = woodOf(pre);
      if (!wd) continue;
      const w = wd.w, a = wd.approx || stripped, wi = WOODS.indexOf(w);
      let r = null;
      switch (suf) {
        case '_planks': r = R(5, wi); break;
        case '_log': case '_stem': r = log(w, p, false); break;
        case '_wood': case '_hyphae': r = log(w, p, true); break;
        case '_leaves': r = R(wi < 4 ? 18 : 161, (wi & 3) | 4); break;
        case '_sapling': r = R(6, wi); break;
        case '_slab': r = slab(SLABS[w], p); break;
        case '_stairs': r = R(STAIRS[w], stairsData(p)); break;
        case '_fence': r = R(FENCE[w], 0); break;
        case '_fence_gate': r = gate(GATE[w], p); break;
        case '_door': r = door(DOORS[w], p); break;
        case '_trapdoor': r = trapdoor(96, p); break;
        case '_button': r = button(143, p); break;
        case '_pressure_plate': r = R(72, 0); break;
        case '_sign': case '_hanging_sign': r = R(63, num(p.rotation, 0)); break;
        case '_wall_sign': case '_wall_hanging_sign': r = R(68, H_NSWE[p.facing] || 2); break;
      }
      if (r) { r.approx = r.approx || a || (suf === '_trapdoor' && w !== 'oak'); return r; }
    }

    // Лестницы, плиты, стены из камня
    if (n.endsWith('_stairs')) {
      const m = n.slice(0, -7);
      if (STAIRS[m]) return R(STAIRS[m], stairsData(p));
      return R(approxStairs(m), stairsData(p), true);
    }
    if (n.endsWith('_slab')) {
      const m = n.slice(0, -5);
      if (SLABS[m]) return slab(SLABS[m], p);
      const r = slab(approxSlab(m), p);
      r.approx = true;
      return r;
    }
    if (n.endsWith('_wall')) return R(139, n.startsWith('mossy') ? 1 : 0, n !== 'cobblestone_wall' && n !== 'mossy_cobblestone_wall');
    if (n === 'iron_door') return door(71, p);
    if (n === 'iron_trapdoor') return trapdoor(167, p);

    switch (n) {
      case 'torch': return R(50, 5);
      case 'wall_torch': return R(50, TORCH[p.facing] || 1);
      case 'soul_torch': return R(50, 5, true);
      case 'soul_wall_torch': return R(50, TORCH[p.facing] || 1, true);
      case 'redstone_torch': return R(p.lit !== undefined && !bool(p.lit) ? 75 : 76, 5);
      case 'redstone_wall_torch': return R(p.lit !== undefined && !bool(p.lit) ? 75 : 76, TORCH[p.facing] || 1);
      case 'chest': return R(54, H_NSWE[p.facing] || 2);
      case 'trapped_chest': return R(146, H_NSWE[p.facing] || 2);
      case 'ender_chest': return R(130, H_NSWE[p.facing] || 2);
      case 'furnace': return R(bool(p.lit) ? 62 : 61, H_NSWE[p.facing] || 2);
      case 'ladder': return R(65, H_NSWE[p.facing] || 2);
      case 'wall_sign': return R(68, H_NSWE[p.facing] || 2);
      case 'sign': return R(63, num(p.rotation, 0));
      case 'dispenser': return R(23, F6[p.facing] || 0);
      case 'dropper': return R(158, F6[p.facing] || 0);
      case 'observer': return R(218, F6[p.facing] || 0);
      case 'command_block': return R(137, (F6[p.facing] || 0) | (bool(p.conditional) ? 8 : 0));
      case 'repeating_command_block': return R(210, (F6[p.facing] || 0) | (bool(p.conditional) ? 8 : 0));
      case 'chain_command_block': return R(211, (F6[p.facing] || 0) | (bool(p.conditional) ? 8 : 0));
      case 'end_rod': return R(198, F6[p.facing] || 1);
      case 'lightning_rod': return R(198, F6[p.facing] || 1, true);
      case 'piston': return R(33, (F6[p.facing] || 0) | (bool(p.extended) ? 8 : 0));
      case 'sticky_piston': return R(29, (F6[p.facing] || 0) | (bool(p.extended) ? 8 : 0));
      case 'hopper': return R(154, F6[p.facing] || 0);
      case 'carved_pumpkin': return R(86, H_SWNE[p.facing] || 0);
      case 'jack_o_lantern': return R(91, H_SWNE[p.facing] || 0);
      case 'end_portal_frame': return R(120, (H_SWNE[p.facing] || 0) | (bool(p.eye) ? 4 : 0));
      case 'anvil': return R(145, H_SWNE[p.facing] || 0);
      case 'chipped_anvil': return R(145, (H_SWNE[p.facing] || 0) | 4);
      case 'damaged_anvil': return R(145, (H_SWNE[p.facing] || 0) | 8);
      case 'repeater': return R(bool(p.powered) ? 94 : 93, (H_SWNE[p.facing] || 0) | ((num(p.delay, 1) - 1) << 2));
      case 'comparator': return R(bool(p.powered) ? 150 : 149, (H_SWNE[p.facing] || 0) | (p.mode === 'subtract' ? 4 : 0));
      case 'cocoa': return R(127, (H_SWNE[p.facing] || 0) | (num(p.age, 0) << 2));
      case 'lever': return lever(p);
      case 'stone_button': return button(77, p);
      case 'polished_blackstone_button': return button(77, p);
      case 'stone_pressure_plate': return R(70, 0);
      case 'polished_blackstone_pressure_plate': return R(70, 0, true);
      case 'light_weighted_pressure_plate': return R(147, 0);
      case 'heavy_weighted_pressure_plate': return R(148, 0);
      case 'rail': return rail(66, p);
      case 'powered_rail': return rail(27, p);
      case 'detector_rail': return rail(28, p);
      case 'activator_rail': return rail(157, p);
      case 'redstone_wire': return R(55, num(p.power, 0));
      case 'redstone_lamp': return R(bool(p.lit) ? 124 : 123, 0);
      case 'redstone_ore': return R(bool(p.lit) ? 74 : 73, 0);
      case 'daylight_detector': return R(bool(p.inverted) ? 178 : 151, num(p.power, 0));
      case 'tripwire_hook': return R(131, (H_SWNE[p.facing] || 0) | (bool(p.attached) ? 4 : 0));
      case 'wheat': return R(59, num(p.age, 0));
      case 'carrots': return R(141, num(p.age, 0));
      case 'potatoes': return R(142, num(p.age, 0));
      case 'beetroots': return R(207, num(p.age, 0));
      case 'nether_wart': return R(115, num(p.age, 0));
      case 'pumpkin_stem': case 'attached_pumpkin_stem': return R(104, num(p.age, 7));
      case 'melon_stem': case 'attached_melon_stem': return R(105, num(p.age, 7));
      case 'farmland': return R(60, num(p.moisture, 0));
      case 'snow': return R(78, num(p.layers, 1) - 1);
      case 'cake': return R(92, num(p.bites, 0));
      case 'cauldron': return R(118, 0);
      case 'water_cauldron': return R(118, num(p.level, 3));
      case 'lava_cauldron': case 'powder_snow_cauldron': return R(118, 0, true);
      case 'vine': return R(106, (bool(p.south) ? 1 : 0) | (bool(p.west) ? 2 : 0) | (bool(p.north) ? 4 : 0) | (bool(p.east) ? 8 : 0));
      case 'hay_block': return R(170, AXIS[p.axis] || 0);
      case 'bone_block': return R(216, AXIS[p.axis] || 0);
      case 'quartz_pillar': return R(155, { y: 2, x: 3, z: 4 }[p.axis] || 2);
      case 'purpur_pillar': return R(202, AXIS[p.axis] || 0);
      case 'sunflower': case 'lilac': case 'tall_grass': case 'large_fern': case 'rose_bush': case 'peony':
        return R(175, p.half === 'upper' ? 10 : ['sunflower', 'lilac', 'tall_grass', 'large_fern', 'rose_bush', 'peony'].indexOf(n));
      case 'nether_portal': return R(90, p.axis === 'z' ? 2 : 1);
    }
    if (n.startsWith('potted_')) return R(140, 0);
    if (APPROX[n] !== undefined) return APPROX[n] ? R(APPROX[n][0], APPROX[n][1], true) : null;
    // Медь и её варианты (waxed_*, *_cut_copper) — как кирпич
    if (n.includes('copper')) return R(45, 0, true);
    if (n.includes('deepslate')) return R(n.includes('brick') || n.includes('tile') ? 98 : 1, n.includes('brick') || n.includes('tile') ? 0 : 5, true);
    if (n.endsWith('_ore')) return R(16, 0, true);
    return null;
  }

  function approxStairs(m) {
    if (/sandstone/.test(m)) return m.includes('red') ? 180 : 128;
    if (/quartz/.test(m)) return 156;
    if (/nether|blackstone/.test(m)) return 114;
    if (/purpur/.test(m)) return 203;
    if (/brick|tile|prismarine|deepslate|end_stone/.test(m)) return 109;
    if (/wood|bamboo|crimson|warped|mangrove|cherry/.test(m)) return 53;
    return 67;
  }
  function approxSlab(m) {
    if (/sandstone/.test(m)) return m.includes('red') ? SLABS.red_sandstone : SLABS.sandstone;
    if (/quartz/.test(m)) return SLABS.quartz;
    if (/nether|blackstone/.test(m)) return SLABS.nether_brick;
    if (/purpur/.test(m)) return SLABS.purpur;
    if (/brick|tile|prismarine|deepslate|end_stone/.test(m)) return SLABS.stone_brick;
    if (/wood|bamboo|crimson|warped|mangrove|cherry/.test(m)) return SLABS.oak;
    if (/cobble/.test(m)) return SLABS.cobblestone;
    return SLABS.smooth_stone;
  }

  MC.BlockStates = { parseState, legacy };
})();
