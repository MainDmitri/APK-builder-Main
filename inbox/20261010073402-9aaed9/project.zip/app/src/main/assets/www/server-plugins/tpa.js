// Запросы на телепорт: /tpa <игрок>, /tpahere <игрок>, /tpaccept, /tpdeny. Запрос действует 60 секунд.
plugin.name = 'TPA';
plugin.version = '1.0';
plugin.description = 'Телепорт по запросу: /tpa, /tpahere, /tpaccept, /tpdeny';
plugin.author = 'Minecraft HTML';

var requests = {}; // кому -> { from, here, at }
var TIMEOUT = 60000;

function find(name) {
  var n = String(name || '').toLowerCase();
  var list = server.players();
  for (var i = 0; i < list.length; i++) if (list[i].name.toLowerCase() === n) return list[i];
  for (var j = 0; j < list.length; j++) if (list[j].name.toLowerCase().indexOf(n) === 0) return list[j];
  return null;
}

function ask(p, args, here) {
  if (!p) return;
  if (!args[0]) return '§cУкажите игрока';
  var t = find(args[0]);
  if (!t) return '§cИгрок не в сети';
  if (t.name === p.name) return '§cНельзя отправить запрос себе';
  requests[t.name.toLowerCase()] = { from: p.name, here: here, at: Date.now() };
  t.send('§e' + p.name + (here ? ' зовёт вас к себе' : ' хочет телепортироваться к вам') + '. §a/tpaccept§e — принять, §c/tpdeny§e — отказать');
  return '§aЗапрос отправлен игроку ' + t.name;
}

server.command('tpa', { description: 'Попросить телепорт к игроку', usage: '/tpa <игрок>' }, function (p, a) { return ask(p, a, false); });
server.command('tpahere', { description: 'Позвать игрока к себе', usage: '/tpahere <игрок>' }, function (p, a) { return ask(p, a, true); });

server.command('tpaccept', { description: 'Принять запрос на телепорт', aliases: ['tpyes'] }, function (p) {
  if (!p) return;
  var k = p.name.toLowerCase();
  var r = requests[k];
  delete requests[k];
  if (!r || Date.now() - r.at > TIMEOUT) return '§cНет запросов на телепорт';
  var from = server.player(r.from);
  if (!from) return '§c' + r.from + ' уже не в сети';
  if (r.here) p.teleport(from.x, from.y, from.z);
  else from.teleport(p.x, p.y, p.z);
  from.send('§a' + p.name + ' принял запрос');
  return '§aЗапрос принят';
});

server.command('tpdeny', { description: 'Отклонить запрос на телепорт', aliases: ['tpno'] }, function (p) {
  if (!p) return;
  var k = p.name.toLowerCase();
  var r = requests[k];
  delete requests[k];
  if (!r) return '§cНет запросов на телепорт';
  var from = server.player(r.from);
  if (from) from.send('§c' + p.name + ' отклонил запрос');
  return '§7Запрос отклонён';
});

server.on('quit', function (e) { delete requests[e.player.name.toLowerCase()]; });
