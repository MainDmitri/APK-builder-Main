// Дома: /sethome [имя], /home [имя], /delhome <имя>, /homes. До 3 домов на игрока (у операторов до 10).
plugin.name = 'Homes';
plugin.version = '1.0';
plugin.description = 'Точки дома: /sethome, /home, /delhome, /homes';
plugin.author = 'Minecraft HTML';

var MAX = 3, MAX_OP = 10;

function homesOf(p) {
  var k = p.name.toLowerCase();
  if (!plugin.data[k]) plugin.data[k] = {};
  return plugin.data[k];
}

server.command('sethome', { description: 'Сохранить дом', usage: '/sethome [имя]' }, function (p, args) {
  if (!p) return;
  var name = (args[0] || 'home').toLowerCase().replace(/[^a-z0-9а-яё_-]/g, '').slice(0, 16) || 'home';
  var h = homesOf(p);
  var max = p.op ? MAX_OP : MAX;
  if (!h[name] && Object.keys(h).length >= max) return '§cМаксимум домов: ' + max + '. Удалите лишний: /delhome <имя>';
  h[name] = { x: p.x, y: p.y, z: p.z };
  plugin.save();
  return '§aДом «' + name + '» сохранён';
});

server.command('home', { description: 'Телепорт домой', usage: '/home [имя]', aliases: ['h'] }, function (p, args) {
  if (!p) return;
  var h = homesOf(p);
  var name = (args[0] || 'home').toLowerCase();
  var t = h[name];
  if (!t) {
    var names = Object.keys(h);
    if (!args[0] && names.length === 1) t = h[names[0]];
    else return names.length ? '§cНет дома «' + name + '». Ваши дома: ' + names.join(', ') : '§cУ вас нет дома. Сохраните его: /sethome';
  }
  p.teleport(t.x, t.y, t.z);
  return '§aДобро пожаловать домой';
});

server.command('delhome', { description: 'Удалить дом', usage: '/delhome <имя>' }, function (p, args) {
  if (!p) return;
  var h = homesOf(p);
  var name = (args[0] || 'home').toLowerCase();
  if (!h[name]) return '§cНет дома «' + name + '»';
  delete h[name];
  plugin.save();
  return '§aДом «' + name + '» удалён';
});

server.command('homes', { description: 'Список домов' }, function (p) {
  if (!p) return;
  var h = homesOf(p);
  var names = Object.keys(h);
  if (!names.length) return '§7У вас нет домов. /sethome — сохранить';
  return '§aДома (' + names.length + '): §f' + names.map(function (n) {
    return n + ' §7(' + Math.floor(h[n].x) + ' ' + Math.floor(h[n].y) + ' ' + Math.floor(h[n].z) + ')§f';
  }).join(', ');
});
