// Лесоруб: срубите нижнее бревно топором — упадёт всё дерево (до 150 брёвен). Присядьте, чтобы рубить по одному.
plugin.name = 'Lumberjack';
plugin.version = '1.0';
plugin.description = 'Топором рубится всё дерево целиком';
plugin.author = 'Minecraft HTML';

var AXES = [271, 275, 258, 286, 279];
var LOGS = { 17: 1, 162: 1 };
var MAX = 150;

server.on('blockBreak', function (e) {
  var p = e.player;
  if (!LOGS[e.id] || p.sneaking || AXES.indexOf(p.held.id) < 0) return;
  var tool = p.held.id, drop = p.gamemode === 0;
  var seen = {}, queue = [[e.x, e.y, e.z]], found = [];
  seen[e.x + ',' + e.y + ',' + e.z] = 1;
  // Соседние брёвна вверх и вбок, включая диагонали (ветки акации и тёмного дуба)
  while (queue.length && found.length < MAX) {
    var c = queue.shift();
    for (var dx = -1; dx <= 1; dx++) for (var dy = 0; dy <= 1; dy++) for (var dz = -1; dz <= 1; dz++) {
      if (!dx && !dy && !dz) continue;
      var x = c[0] + dx, y = c[1] + dy, z = c[2] + dz, k = x + ',' + y + ',' + z;
      if (seen[k]) continue;
      seen[k] = 1;
      if (!LOGS[server.getBlock(x, y, z).id]) continue;
      found.push([x, y, z]);
      queue.push([x, y, z]);
    }
  }
  if (!found.length) return;
  // Ломаем на следующем тике, после основного блока
  server.later(1, function () {
    for (var i = 0; i < found.length; i++) {
      var b = found[i];
      if (LOGS[server.getBlock(b[0], b[1], b[2]).id]) server.breakBlock(b[0], b[1], b[2], tool, drop);
    }
  });
});
