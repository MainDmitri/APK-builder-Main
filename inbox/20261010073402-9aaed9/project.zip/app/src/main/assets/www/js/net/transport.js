// Транспорт UDP-датаграмм через ретранслятор WebSocket ↔ UDP (relay/relay.js)
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  class RelayTransport {
    constructor(ws, info) {
      this.ws = ws;
      this.address = info.address;
      this.port = info.port;
      this.family = info.family;
      this.ondatagram = null;
      this.onclose = null;
      this.closed = false;
      ws.onmessage = (ev) => {
        if (typeof ev.data === 'string') {
          let msg;
          try { msg = JSON.parse(ev.data); } catch (e) { return; }
          if (msg.type === 'error') this.close('Ретранслятор: ' + msg.message);
          return;
        }
        if (this.ondatagram) this.ondatagram(new Uint8Array(ev.data));
      };
      ws.onclose = () => this.close('Соединение с ретранслятором закрыто');
      ws.onerror = () => this.close('Ошибка соединения с ретранслятором');
    }

    send(data) {
      if (!this.closed && this.ws.readyState === 1) this.ws.send(data);
    }

    close(reason) {
      if (this.closed) return;
      this.closed = true;
      try { this.ws.close(); } catch (e) { /* уже закрыт */ }
      if (this.onclose) this.onclose(reason || 'Отключено');
    }

    // Открывает WebSocket к ретранслятору и просит его создать UDP-сокет к host:port.
    // Встроенный ретранслятор APK при обрыве перезапускается приложением (AndroidRelay.getUrl), поэтому пробуем ещё дважды
    static async open(relayUrl, host, port, timeoutMs) {
      const builtIn = window.AndroidRelay && MC.Storage && MC.Storage.isLocalRelay(relayUrl);
      let url = relayUrl;
      for (let attempt = 0; ; attempt++) {
        try {
          return await RelayTransport.openOnce(url, host, port, timeoutMs);
        } catch (e) {
          if (!builtIn || !e.relayDown || attempt >= 2) throw e;
          await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
          url = MC.Storage.relayUrl({ relay: '' });
        }
      }
    }

    static openOnce(relayUrl, host, port, timeoutMs) {
      return new Promise((resolve, reject) => {
        let ws;
        try {
          ws = new WebSocket(relayUrl);
        } catch (e) {
          reject(new Error('Неверный адрес ретранслятора: ' + relayUrl));
          return;
        }
        ws.binaryType = 'arraybuffer';
        let done = false;
        const timer = setTimeout(() => {
          if (done) return;
          done = true;
          try { ws.close(); } catch (e) { /* игнор */ }
          reject(new Error('Ретранслятор не ответил (' + relayUrl + ')'));
        }, timeoutMs || 8000);
        ws.onopen = () => ws.send(JSON.stringify({ type: 'connect', host: host, port: port }));
        ws.onmessage = (ev) => {
          if (done || typeof ev.data !== 'string') return;
          let msg;
          try { msg = JSON.parse(ev.data); } catch (e) { return; }
          done = true;
          clearTimeout(timer);
          if (msg.type === 'ready') {
            resolve(new RelayTransport(ws, msg));
          } else {
            try { ws.close(); } catch (e) { /* игнор */ }
            reject(new Error(msg.message || 'Ретранслятор отказал'));
          }
        };
        ws.onerror = () => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          const err = new Error('Нет связи с ретранслятором ' + relayUrl + '. Он запущен?');
          err.relayDown = true;
          reject(err);
        };
        ws.onclose = () => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          reject(new Error('Ретранслятор закрыл соединение'));
        };
      });
    }
  }

  MC.RelayTransport = RelayTransport;
})();
