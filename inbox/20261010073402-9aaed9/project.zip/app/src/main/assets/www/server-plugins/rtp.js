// /rtp — случайный телепорт в радиусе 300–2000 блоков от спавна на безопасный блок. Перезарядка 60 секунд.
plugin.name = 'RandomTP';
plugin.version = '1.0';
plugin.description = '/rtp — случайный телепорт в безопасное место';
plugin.author = 'Minecraft HTML';

var MIN = 300, MAX = 2000, COOLDOWN = 60000;
var last = {};
// Нельзя приземляться на воду, лаву, кактус, огонь, листву
var BAD = { 0: 1, 8: 1, 9: 1, 10: 1, 11: 1, 18: 1, 161: 1, 51: 1, 81: 1 };
// Проходимые: воздух, трава, цветы, снег
var FREE = { 0: 1, 31: 1, 32: 1, 37: 1, 38: 1, 78: 1, 175: 1 };

server.command('rtp', { description: 'Случайный телепорт', aliases: ['wild'] }, function (p) {
  if (!p) return;
  var k = p.name.toLowerCase();
  var now = Date.now();
  if (!p.op && last[k] && now - last[k] < COOLDOWN) return '§cПодождите ещё ' + Math.ceil((COOLDOWN - (now - last[k])) / 1000) + ' с';
  var sp = server.spawn();
  for (var i = 0; i < 12; i++) {
    var ang = Math.random() * Math.PI * 2;
    var dist = MIN + Math.random() * (MAX - MIN);
    var x = Math.floor(sp.x + Math.cos(ang) * dist);
    var z = Math.floor(sp.z + Math.sin(ang) * dist);
    var y = server.highestY(x, z); // верхний твёрдый блок
    if (y <= 1 || y >= 250) continue;
    if (BAD[server.getBlock(x, y, z).id]) continue;
    // Над ним два проходимых блока (не вода)
    if (!FREE[server.getBlock(x, y + 1, z).id] || !FREE[server.getBlock(x, y + 2, z).id]) continue;
    last[k] = now;
    p.teleport(x + 0.5, y + 1.1, z + 0.5);
    p.title('§aСлучайный телепорт', '§7' + x + ' ' + (y + 1) + ' ' + z);
    return '§aВы на ' + x + ' ' + (y + 1) + ' ' + z;
  }
  return '§cНе нашёл безопасного места, попробуйте ещё раз';
});
