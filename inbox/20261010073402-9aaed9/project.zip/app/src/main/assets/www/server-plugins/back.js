// /back — вернуться на место смерти или туда, откуда телепортировались командой /back.
plugin.name = 'Back';
plugin.version = '1.0';
plugin.description = '/back — вернуться на место последней смерти';
plugin.author = 'Minecraft HTML';

server.on('death', function (e) {
  plugin.data[e.player.name.toLowerCase()] = { x: e.player.x, y: e.player.y, z: e.player.z };
  plugin.save();
  e.player.send('§7Вернуться на место смерти: §e/back');
});

server.command('back', { description: 'Вернуться на место смерти' }, function (p) {
  if (!p) return;
  var k = p.name.toLowerCase();
  var t = plugin.data[k];
  if (!t) return '§cНекуда возвращаться';
  plugin.data[k] = { x: p.x, y: p.y, z: p.z };
  plugin.save();
  p.teleport(t.x, t.y + 0.1, t.z);
  return '§aВы вернулись';
});
