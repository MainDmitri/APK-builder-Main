// Варпы: общие точки телепорта. /setwarp и /delwarp — только операторы.
plugin.name = 'Warps';
plugin.version = '1.0';
plugin.description = 'Общие точки: /warp, /warps, /setwarp, /delwarp';
plugin.author = 'Minecraft HTML';

server.command('setwarp', { description: 'Создать варп', usage: '/setwarp <имя>', op: true }, function (p, args) {
  if (!p) return;
  var name = (args[0] || '').toLowerCase().replace(/[^a-z0-9а-яё_-]/g, '').slice(0, 16);
  if (!name) return '§cУкажите имя: /setwarp <имя>';
  plugin.data[name] = { x: p.x, y: p.y, z: p.z };
  plugin.save();
  return '§aВарп «' + name + '» создан';
});

server.command('delwarp', { description: 'Удалить варп', usage: '/delwarp <имя>', op: true }, function (p, args) {
  var name = (args[0] || '').toLowerCase();
  var msg = plugin.data[name] ? '§aВарп «' + name + '» удалён' : '§cНет варпа «' + name + '»';
  delete plugin.data[name];
  plugin.save();
  if (p) return msg;
  server.log(msg);
});

server.command('warp', { description: 'Телепорт на варп', usage: '/warp <имя>' }, function (p, args) {
  if (!p) return;
  var names = Object.keys(plugin.data);
  if (!args[0]) return names.length ? '§aВарпы: §f' + names.join(', ') : '§7Варпов пока нет';
  var w = plugin.data[args[0].toLowerCase()];
  if (!w) return '§cНет варпа «' + args[0] + '». Есть: ' + (names.join(', ') || 'нет');
  p.teleport(w.x, w.y, w.z);
  return '§aВы на варпе «' + args[0].toLowerCase() + '»';
});

server.command('warps', { description: 'Список варпов' }, function (p) {
  var names = Object.keys(plugin.data);
  var msg = names.length ? '§aВарпы: §f' + names.join(', ') : '§7Варпов пока нет';
  if (p) return msg;
  server.log(msg);
});
