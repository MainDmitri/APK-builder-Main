// Приветствие и объявления: заголовок при входе, сообщение о новичках, объявления каждые 5 минут.
// /announce list | add <текст> | remove <номер> | interval <минуты> — оператор.
plugin.name = 'Announcer';
plugin.version = '1.0';
plugin.description = 'Приветствие новичков и автообъявления';
plugin.author = 'Minecraft HTML';

var DEFAULT = [
  '§eКоманды сервера: §f/help',
  '§eСохраните дом: §f/sethome§e, вернуться: §f/home',
  '§eНаборы предметов: §f/kit',
  '§eМагазин: §f/shop§e, баланс: §f/money',
  '§eТелепорт к другу: §f/tpa <ник>',
  '§eСлучайное место для дома: §f/rtp'
];
var task = 0, idx = 0;

function msgs() { if (!plugin.data.messages) plugin.data.messages = DEFAULT.slice(); return plugin.data.messages; }
function interval() { return plugin.data.interval || 5; }

function schedule() {
  if (task) server.cancel(task);
  task = server.every(interval() * 60 * 20, function () {
    var m = msgs();
    if (!m.length || !server.players().length) return;
    server.broadcast('§6[!] §r' + m[idx++ % m.length]);
  });
}

server.onEnable(schedule);

server.on('join', function (e) {
  var p = e.player, k = p.name.toLowerCase();
  if (!plugin.data.seen) plugin.data.seen = {};
  var first = !plugin.data.seen[k];
  plugin.data.seen[k] = Date.now();
  plugin.save();
  p.title('§aДобро пожаловать', '§f' + server.info().name);
  if (first) e.message = '§d' + p.name + ' впервые на сервере! Поприветствуйте!';
});

server.command('announce', { description: 'Объявления', usage: '/announce <list|add|remove|interval>', op: true }, function (p, a) {
  var out = function (m) { if (p) p.send(m); else server.log(m.replace(/§./g, '')); };
  var m = msgs();
  var sub = (a[0] || 'list').toLowerCase();
  if (sub === 'add' && a.length > 1) {
    m.push(a.slice(1).join(' ').replace(/&([0-9a-fk-or])/g, '§$1'));
    plugin.save();
    return out('§aОбъявление добавлено (#' + m.length + ')');
  }
  if (sub === 'remove') {
    var n = Math.floor(Number(a[1]));
    if (!(n >= 1 && n <= m.length)) return out('§cУкажите номер от 1 до ' + m.length);
    m.splice(n - 1, 1);
    plugin.save();
    return out('§aОбъявление #' + n + ' удалено');
  }
  if (sub === 'interval') {
    var min = Math.floor(Number(a[1]));
    if (!(min >= 1 && min <= 120)) return out('§cИнтервал от 1 до 120 минут');
    plugin.data.interval = min;
    plugin.save();
    schedule();
    return out('§aОбъявления каждые ' + min + ' мин');
  }
  var lines = ['§6Объявления (каждые ' + interval() + ' мин):'];
  for (var i = 0; i < m.length; i++) lines.push('§e' + (i + 1) + '. §r' + m[i]);
  lines.push('§7/announce add <текст> (цвета через &), /announce remove <номер>');
  out(lines.join('\n'));
});
