package com.dahua.checker

import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF4FC3F7),
                    secondary = Color(0xFF81C784),
                    background = Color(0xFF121212),
                    surface = Color(0xFF1E1E1E),
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                DahuaCheckerApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DahuaCheckerApp() {
    var ipInput by remember { mutableStateOf("") }
    var isScanning by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<ScanProgress?>(null) }
    val results = remember { mutableStateListOf<ScanResult>() }
    var scanner by remember { mutableStateOf<DahuaScanner?>(null) }
    var parseError by remember { mutableStateOf<String?>(null) }
    var selectedResult by remember { mutableStateOf<ScanResult?>(null) }
    val scope = rememberCoroutineScope()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("Dahua Checker", fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = ipInput,
                onValueChange = {
                    ipInput = it
                    parseError = null
                },
                label = { Text("IP / диапазон / CIDR") },
                placeholder = { Text("192.168.1.1\n192.168.1.1-192.168.1.50\n10.0.0.0/24") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 6,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                isError = parseError != null,
                supportingText = parseError?.let { { Text(it, color = MaterialTheme.colorScheme.error) } },
                enabled = !isScanning
            )

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val ips = IpParser.parseMultiline(ipInput)
                        if (ips.isEmpty()) {
                            parseError = "Некорректный ввод. Примеры: 192.168.1.1, 10.0.0.1-10.0.0.50, 10.0.0.0/24"
                            return@Button
                        }
                        if (ips.size > 65536) {
                            parseError = "Максимум 65536 IP за раз"
                            return@Button
                        }
                        parseError = null
                        results.clear()
                        isScanning = true
                        progress = ScanProgress(ips.size, 0, 0, 0)
                        val s = DahuaScanner()
                        scanner = s

                        scope.launch {
                            s.scan(
                                ips = ips,
                                onResult = { r ->
                                    withContext(Dispatchers.Main) {
                                        results.add(r)
                                    }
                                },
                                onProgress = { p ->
                                    withContext(Dispatchers.Main) {
                                        progress = p
                                    }
                                }
                            )
                            withContext(Dispatchers.Main) {
                                isScanning = false
                            }
                        }
                    },
                    enabled = !isScanning && ipInput.isNotBlank(),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Сканировать")
                }

                if (isScanning) {
                    OutlinedButton(
                        onClick = {
                            scanner?.cancelled = true
                            isScanning = false
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFFEF5350)
                        )
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("Отмена")
                    }
                }
            }

            progress?.let { p ->
                Spacer(Modifier.height(12.dp))
                ProgressSection(p, isScanning)
            }

            Spacer(Modifier.height(12.dp))

            if (results.isNotEmpty()) {
                Text(
                    "Результаты: ${results.size}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(results) { result ->
                    ResultCard(result) { selectedResult = result }
                }
            }
        }

        selectedResult?.let { r ->
            SnapshotDialog(r) { selectedResult = null }
        }
    }
}

@Composable
fun ProgressSection(p: ScanProgress, scanning: Boolean) {
    val pct = if (p.total > 0) (p.checked.toFloat() / p.total) else 0f
    val speedIpSec = if (p.elapsedMs > 0) (p.checked * 1000.0 / p.elapsedMs) else 0.0
    val remainingMs = if (speedIpSec > 0 && p.checked < p.total) {
        ((p.total - p.checked) / speedIpSec * 1000).toLong()
    } else 0L

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("${p.checked}/${p.total}", fontSize = 13.sp)
                Text("${(pct * 100).toInt()}%", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { pct },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
            )
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("✅ ${p.successful}", fontSize = 12.sp, color = Color(0xFF81C784))
                Text("⚡ ${"%.1f".format(speedIpSec)} IP/с", fontSize = 12.sp)
                if (scanning && remainingMs > 0) {
                    val sec = (remainingMs / 1000).toInt()
                    Text("⏱ ${sec / 60}:%02d".format(sec % 60), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun ResultCard(result: ScanResult, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            result.snapshot?.let { bytes ->
                val bmp = remember(bytes) {
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                }
                if (bmp != null) {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.width(12.dp))
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    result.ip,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 15.sp
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    "${result.login}:${result.password}",
                    fontSize = 13.sp,
                    color = Color(0xFF81C784),
                    fontFamily = FontFamily.Monospace
                )
            }

            Icon(
                Icons.Default.CheckCircle,
                contentDescription = null,
                tint = Color(0xFF81C784),
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun SnapshotDialog(result: ScanResult, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Закрыть")
            }
        },
        title = {
            Text(result.ip, fontFamily = FontFamily.Monospace)
        },
        text = {
            Column {
                Text(
                    "Логин: ${result.login}\nПароль: ${result.password}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(8.dp))
                result.snapshot?.let { bytes ->
                    val bmp = remember(bytes) {
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    }
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.FillWidth
                        )
                    }
                }
            }
        }
    )
}
