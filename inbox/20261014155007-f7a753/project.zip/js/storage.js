// Слой надёжного хранения данных в localStorage под ключом app:v1
export const STORAGE_KEY = 'app:v1';

export const DEFAULT_COMMENTS = [
  { id: 'c1', text: 'Отличное видео, спасибо! 🔥', category: 'Поддержка', uses: 0 },
  { id: 'c2', text: 'Очень круто снято 👍', category: 'Поддержка', uses: 0 },
  { id: 'c3', text: 'Сохранил себе в избранное ⭐', category: 'Поддержка', uses: 0 },
  { id: 'c4', text: '🔥🔥🔥👏👏', category: 'Эмодзи', uses: 0 },
  { id: 'c5', text: 'Жду продолжения! Интригующе 👀', category: 'Вопрос', uses: 0 },
  { id: 'c6', text: 'Подняли настроение на весь день 😄', category: 'Юмор', uses: 0 }
];

export function getTodayKey() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function createDefaultState() {
  return {
    version: 1,
    settings: {
      watchSeconds: 15,
      likeDelaySeconds: 4,
      speedProfile: 'normal',
      autoLike: true,
      autoFavorite: true,
      favoriteEveryN: 1,
      autoComment: false,
      commentEveryN: 3,
      videoTopic: 'Рекомендации',
      onlyInTiktok: true,
      isTiktokActive: true,
      humanizeTiming: true,
      hourlyLimit: 120,
      largeAccessibility: false,
      soundFeedback: true,
      overlayVisible: true,
      overlayMinimized: false
    },
    stats: {
      totalVideos: 0,
      totalLikes: 0,
      totalFavorites: 0,
      totalComments: 0,
      totalWatchSeconds: 0,
      daily: {}
    },
    comments: DEFAULT_COMMENTS.map(item => ({ ...item })),
    history: []
  };
}

function clampNumber(val, min, max, fallback) {
  const num = Number(val);
  if (!Number.isFinite(num)) return fallback;
  return Math.min(max, Math.max(min, Math.round(num)));
}

export function sanitizeState(raw) {
  const base = createDefaultState();
  if (!raw || typeof raw !== 'object') return base;

  const s = raw.settings && typeof raw.settings === 'object' ? raw.settings : {};
  const watchSeconds = clampNumber(s.watchSeconds, 5, 120, base.settings.watchSeconds);
  const likeDelaySeconds = clampNumber(
    s.likeDelaySeconds,
    1,
    Math.max(1, watchSeconds - 1),
    Math.min(base.settings.likeDelaySeconds, Math.max(1, watchSeconds - 1))
  );

  base.settings = {
    watchSeconds,
    likeDelaySeconds,
    speedProfile: ['gentle', 'normal', 'fast'].includes(s.speedProfile) ? s.speedProfile : 'normal',
    autoLike: typeof s.autoLike === 'boolean' ? s.autoLike : true,
    autoFavorite: typeof s.autoFavorite === 'boolean' ? s.autoFavorite : true,
    favoriteEveryN: clampNumber(s.favoriteEveryN, 1, 50, 1),
    autoComment: typeof s.autoComment === 'boolean' ? s.autoComment : false,
    commentEveryN: clampNumber(s.commentEveryN, 1, 50, 3),
    videoTopic: typeof s.videoTopic === 'string' ? s.videoTopic.slice(0, 80) : 'Рекомендации',
    onlyInTiktok: typeof s.onlyInTiktok === 'boolean' ? s.onlyInTiktok : true,
    isTiktokActive: typeof s.isTiktokActive === 'boolean' ? s.isTiktokActive : true,
    humanizeTiming: typeof s.humanizeTiming === 'boolean' ? s.humanizeTiming : true,
    hourlyLimit: clampNumber(s.hourlyLimit, 10, 500, 120),
    largeAccessibility: Boolean(s.largeAccessibility),
    soundFeedback: typeof s.soundFeedback === 'boolean' ? s.soundFeedback : true,
    overlayVisible: typeof s.overlayVisible === 'boolean' ? s.overlayVisible : true,
    overlayMinimized: Boolean(s.overlayMinimized)
  };

  const st = raw.stats && typeof raw.stats === 'object' ? raw.stats : {};
  base.stats = {
    totalVideos: clampNumber(st.totalVideos, 0, 10000000, 0),
    totalLikes: clampNumber(st.totalLikes, 0, 10000000, 0),
    totalFavorites: clampNumber(st.totalFavorites, 0, 10000000, 0),
    totalComments: clampNumber(st.totalComments, 0, 10000000, 0),
    totalWatchSeconds: clampNumber(st.totalWatchSeconds, 0, 100000000, 0),
    daily: st.daily && typeof st.daily === 'object' ? { ...st.daily } : {}
  };

  if (Array.isArray(raw.comments) && raw.comments.length > 0) {
    base.comments = raw.comments
      .filter(c => c && typeof c.text === 'string' && c.text.trim().length > 0)
      .map((c, idx) => ({
        id: typeof c.id === 'string' ? c.id : `c_${Date.now()}_${idx}`,
        text: c.text.trim().slice(0, 150),
        category: typeof c.category === 'string' ? c.category : 'Поддержка',
        uses: clampNumber(c.uses, 0, 1000000, 0)
      }));
  }

  if (Array.isArray(raw.history)) {
    base.history = raw.history
      .filter(h => h && typeof h === 'object' && typeof h.id === 'string')
      .slice(0, 150);
  }

  return base;
}

export function loadState() {
  try {
    const rawText = window.localStorage.getItem(STORAGE_KEY);
    if (!rawText) {
      const initial = createDefaultState();
      saveState(initial);
      return initial;
    }
    const parsed = JSON.parse(rawText);
    return sanitizeState(parsed);
  } catch (err) {
    const fallback = createDefaultState();
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(fallback));
    } catch (_) {
      // Игнорируем ошибку переполнения хранилища
    }
    return fallback;
  }
}

export function saveState(state) {
  try {
    const clean = sanitizeState(state);
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(clean));
    return true;
  } catch (err) {
    return false;
  }
}

export function recordActivity(state, payload) {
  const dayKey = getTodayKey();
  if (!state.stats.daily[dayKey]) {
    state.stats.daily[dayKey] = {
      videos: 0,
      likes: 0,
      favorites: 0,
      comments: 0,
      watchSeconds: 0
    };
  }
  const day = state.stats.daily[dayKey];

  if (payload.watched) {
    state.stats.totalVideos += 1;
    state.stats.totalWatchSeconds += payload.watchSeconds || 0;
    day.videos += 1;
    day.watchSeconds += payload.watchSeconds || 0;
  }

  if (payload.liked) {
    state.stats.totalLikes += 1;
    day.likes += 1;
  }

  if (payload.favorited) {
    state.stats.totalFavorites += 1;
    day.favorites += 1;
  }

  if (payload.commentText) {
    state.stats.totalComments += 1;
    day.comments += 1;
  }

  const nowIso = new Date().toISOString();
  const entry = {
    id: `act_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    timestamp: nowIso,
    videoNumber: state.stats.totalVideos,
    topic: state.settings.videoTopic || 'Рекомендации',
    liked: Boolean(payload.liked),
    favorited: Boolean(payload.favorited),
    commentText: payload.commentText || '',
    watchSeconds: payload.watchSeconds || 0
  };

  state.history.unshift(entry);
  if (state.history.length > 150) {
    state.history.length = 150;
  }

  saveState(state);
  return entry;
}
