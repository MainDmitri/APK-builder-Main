// Точка входа приложения «Помощник Тикток»
import {
  DEFAULT_COMMENTS,
  createDefaultState,
  loadState,
  recordActivity,
  sanitizeState,
  saveState
} from './storage.js';
import {
  hideBanner,
  playFeedbackTone,
  renderAll,
  renderCycleProgress,
  showBanner
} from './ui.js';

const state = loadState();

const runtime = {
  isRunning: false,
  elapsedSeconds: 0,
  currentTargetSeconds: state.settings.watchSeconds,
  currentLikeDelaySeconds: state.settings.likeDelaySeconds,
  likedInCurrentCycle: false,
  lastTickTime: 0,
  timerId: null,
  sessionActionsTimestamps: [],
  historyFilter: 'all'
};

function computeCycleTargets() {
  const baseWatch = state.settings.watchSeconds;
  const baseLike = Math.min(state.settings.likeDelaySeconds, Math.max(1, baseWatch - 1));

  if (!state.settings.humanizeTiming) {
    runtime.currentTargetSeconds = baseWatch;
    runtime.currentLikeDelaySeconds = baseLike;
    return;
  }

  // Небольшое естественное отклонение ±10% для защиты от анти-спам фильтров
  const jitterWatch = Math.round((Math.random() * 2 - 1) * Math.max(1, Math.round(baseWatch * 0.1)));
  const finalWatch = Math.max(5, Math.min(120, baseWatch + jitterWatch));
  const finalLike = Math.max(1, Math.min(finalWatch - 1, baseLike));

  runtime.currentTargetSeconds = finalWatch;
  runtime.currentLikeDelaySeconds = finalLike;
}

function checkHourlySafetyLimit() {
  const oneHourAgo = Date.now() - 3600 * 1000;
  runtime.sessionActionsTimestamps = runtime.sessionActionsTimestamps.filter(t => t > oneHourAgo);
  return runtime.sessionActionsTimestamps.length < state.settings.hourlyLimit;
}

async function copyTextSafe(text) {
  if (!text) return false;
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (_) {
    // Fallback ниже
  }
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    return true;
  } catch (_) {
    return false;
  }
}

function pickNextComment() {
  if (!state.comments || state.comments.length === 0) return '';
  // Выбираем шаблон с наименьшим количеством использований для разнообразия
  const sorted = [...state.comments].sort((a, b) => (a.uses || 0) - (b.uses || 0));
  const chosen = sorted[0];
  chosen.uses = (chosen.uses || 0) + 1;
  return chosen.text;
}

async function completeCurrentVideoCycle(manualTrigger = false) {
  if (state.settings.onlyInTiktok && !state.settings.isTiktokActive) {
    showBanner('Включите переключатель «Я в TikTok», чтобы помощник выполнял действия.', 'error');
    return;
  }

  if (!checkHourlySafetyLimit()) {
    stopAssistant();
    showBanner(
      `Достигнут безопасный лимит (${state.settings.hourlyLimit} действий/час). Помощник встал на паузу для защиты аккаунта.`,
      'error'
    );
    return;
  }

  const nextVideoIndex = state.stats.totalVideos + 1;
  const doLike = Boolean(state.settings.autoLike);
  const doFav =
    Boolean(state.settings.autoFavorite) &&
    nextVideoIndex % Math.max(1, state.settings.favoriteEveryN) === 0;
  const doComment =
    Boolean(state.settings.autoComment) &&
    state.comments.length > 0 &&
    nextVideoIndex % Math.max(1, state.settings.commentEveryN) === 0;

  let commentText = '';
  if (doComment) {
    commentText = pickNextComment();
    await copyTextSafe(commentText);
  }

  const watchedSec = manualTrigger
    ? Math.max(1, Math.round(runtime.elapsedSeconds || state.settings.watchSeconds))
    : runtime.currentTargetSeconds;

  recordActivity(state, {
    watched: true,
    watchSeconds: watchedSec,
    liked: doLike,
    favorited: doFav,
    commentText
  });

  if (doLike || doFav || commentText) {
    runtime.sessionActionsTimestamps.push(Date.now());
  }

  playFeedbackTone(state.settings.soundFeedback, 'next');

  if (commentText) {
    showBanner(`Комментарий скопирован в буфер: «${commentText}»`, 'success');
  }

  // Сброс для следующего ролика
  runtime.elapsedSeconds = 0;
  runtime.likedInCurrentCycle = false;
  computeCycleTargets();
  syncUI();
}

function tickLoop() {
  if (!runtime.isRunning) return;

  const now = performance.now();
  const dt = Math.min(1.0, Math.max(0, (now - runtime.lastTickTime) / 1000));
  runtime.lastTickTime = now;

  // Если включена защита «Только в TikTok» и пользователь вышел из режима TikTok — ждём
  if (state.settings.onlyInTiktok && !state.settings.isTiktokActive) {
    renderCycleProgress(state, runtime);
    return;
  }

  runtime.elapsedSeconds += dt;

  // Отмечаем момент постановки лайка внутри цикла просмотра
  if (
    state.settings.autoLike &&
    !runtime.likedInCurrentCycle &&
    runtime.elapsedSeconds >= runtime.currentLikeDelaySeconds
  ) {
    runtime.likedInCurrentCycle = true;
    playFeedbackTone(state.settings.soundFeedback, 'like');
  }

  if (runtime.elapsedSeconds >= runtime.currentTargetSeconds) {
    completeCurrentVideoCycle(false);
  } else {
    renderCycleProgress(state, runtime);
  }
}

function startAssistant() {
  if (runtime.isRunning) return;
  if (state.settings.onlyInTiktok && !state.settings.isTiktokActive) {
    showBanner('Сначала включите режим «Я в TikTok» в пульте.', 'error');
    return;
  }
  runtime.isRunning = true;
  runtime.elapsedSeconds = 0;
  runtime.likedInCurrentCycle = false;
  computeCycleTargets();
  runtime.lastTickTime = performance.now();
  if (runtime.timerId) clearInterval(runtime.timerId);
  runtime.timerId = setInterval(tickLoop, 200);
  showBanner('Авто-помощник запущен. Таймер просмотра и лайков работает.', 'success');
  syncUI();
}

function stopAssistant() {
  runtime.isRunning = false;
  if (runtime.timerId) {
    clearInterval(runtime.timerId);
    runtime.timerId = null;
  }
  syncUI();
}

function updateSetting(key, value) {
  state.settings[key] = value;

  // Валидация соотношения времени просмотра и задержки лайка
  state.settings.watchSeconds = Math.min(120, Math.max(5, Math.round(Number(state.settings.watchSeconds) || 15)));
  const maxLikeDelay = Math.max(1, state.settings.watchSeconds - 1);
  state.settings.likeDelaySeconds = Math.min(
    maxLikeDelay,
    Math.max(1, Math.round(Number(state.settings.likeDelaySeconds) || 4))
  );

  saveState(state);
  computeCycleTargets();
  syncUI();
}

function syncUI() {
  renderAll(state, runtime, {
    onUseComment: async commentId => {
      const found = state.comments.find(c => c.id === commentId);
      if (!found) return;
      found.uses = (found.uses || 0) + 1;
      await copyTextSafe(found.text);
      recordActivity(state, {
        watched: false,
        watchSeconds: 0,
        liked: false,
        favorited: false,
        commentText: found.text
      });
      showBanner(`Фраза скопирована в буфер и учтена: «${found.text}»`, 'success');
      syncUI();
    },
    onDeleteComment: commentId => {
      state.comments = state.comments.filter(c => c.id !== commentId);
      saveState(state);
      showBanner('Шаблон комментария удалён.', 'info');
      syncUI();
    }
  });
  renderCycleProgress(state, runtime);
}

// Навигация через hash (#/panel, #/comments, #/stats, #/settings)
function applyRoute() {
  const hash = window.location.hash.replace(/^#/, '') || '/panel';
  const validRoutes = ['/panel', '/comments', '/stats', '/settings'];
  const currentRoute = validRoutes.includes(hash) ? hash : '/panel';

  document.querySelectorAll('.screen').forEach(sec => {
    const r = sec.getAttribute('data-route');
    sec.classList.toggle('hidden', r !== currentRoute);
  });

  document.querySelectorAll('.bottom-nav__item').forEach(link => {
    const nav = link.getAttribute('data-nav');
    link.classList.toggle('active', nav === currentRoute);
  });
}

function bindEvents() {
  window.addEventListener('hashchange', applyRoute);

  const alertClose = document.getElementById('alertBannerClose');
  if (alertClose) alertClose.addEventListener('click', hideBanner);

  // Показ / скрытие и сворачивание всплывающего пульта
  const toggleOverlayBtn = document.getElementById('toggleOverlayBtn');
  if (toggleOverlayBtn) {
    toggleOverlayBtn.addEventListener('click', () => {
      updateSetting('overlayVisible', !state.settings.overlayVisible);
    });
  }

  const minimizeOverlayBtn = document.getElementById('minimizeOverlayBtn');
  if (minimizeOverlayBtn) {
    minimizeOverlayBtn.addEventListener('click', () => {
      updateSetting('overlayMinimized', !state.settings.overlayMinimized);
    });
  }

  // Переключатель «Я в TikTok»
  const tiktokSwitch = document.getElementById('tiktokContextSwitch');
  if (tiktokSwitch) {
    tiktokSwitch.addEventListener('click', () => {
      const nextVal = !state.settings.isTiktokActive;
      updateSetting('isTiktokActive', nextVal);
      if (!nextVal && runtime.isRunning) {
        showBanner('Вы вышли из режима TikTok — таймер временно приостановлен.', 'info');
      } else if (nextVal && runtime.isRunning) {
        showBanner('Режим TikTok активен — работа помощника продолжена.', 'success');
      }
    });
  }

  // Слайдеры в пульте
  const overlayWatchRange = document.getElementById('overlayWatchRange');
  if (overlayWatchRange) {
    overlayWatchRange.addEventListener('input', e => {
      updateSetting('watchSeconds', Number(e.target.value));
    });
  }

  const overlayLikeDelayRange = document.getElementById('overlayLikeDelayRange');
  if (overlayLikeDelayRange) {
    overlayLikeDelayRange.addEventListener('input', e => {
      updateSetting('likeDelaySeconds', Number(e.target.value));
    });
  }

  // Кнопки +/- шагов времени
  document.querySelectorAll('[data-step-target]').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.getAttribute('data-step-target');
      const step = Number(btn.getAttribute('data-step')) || 0;
      const current = Number(state.settings[target]) || 0;
      updateSetting(target, current + step);
    });
  });

  // Пресеты-чипсы
  document.querySelectorAll('.preset-chips').forEach(group => {
    const target = group.getAttribute('data-preset-target');
    group.querySelectorAll('.preset-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const val = Number(chip.getAttribute('data-value'));
        if (Number.isFinite(val)) {
          updateSetting(target, val);
        }
      });
    });
  });

  // Пилюли авто-действий в пульте
  const pillLike = document.getElementById('pillLikeToggle');
  if (pillLike) {
    pillLike.addEventListener('click', () => updateSetting('autoLike', !state.settings.autoLike));
  }
  const pillFav = document.getElementById('pillFavToggle');
  if (pillFav) {
    pillFav.addEventListener('click', () => updateSetting('autoFavorite', !state.settings.autoFavorite));
  }
  const pillComment = document.getElementById('pillCommentToggle');
  if (pillComment) {
    pillComment.addEventListener('click', () => updateSetting('autoComment', !state.settings.autoComment));
  }

  // Главные кнопки Старт/Стоп и Следующее видео
  const startStopBtn = document.getElementById('startStopBtn');
  if (startStopBtn) {
    startStopBtn.addEventListener('click', () => {
      if (runtime.isRunning) {
        stopAssistant();
        showBanner('Авто-помощник остановлен.', 'info');
      } else {
        startAssistant();
      }
    });
  }

  const manualNextBtn = document.getElementById('manualNextVideoBtn');
  if (manualNextBtn) {
    manualNextBtn.addEventListener('click', () => {
      completeCurrentVideoCycle(true);
    });
  }

  const simulateActionNowBtn = document.getElementById('simulateActionNowBtn');
  if (simulateActionNowBtn) {
    simulateActionNowBtn.addEventListener('click', () => {
      recordActivity(state, {
        watched: true,
        watchSeconds: state.settings.watchSeconds,
        liked: true,
        favorited: true,
        commentText: ''
      });
      playFeedbackTone(state.settings.soundFeedback, 'like');
      showBanner('Выполнен разовый лайк и сохранение в избранное!', 'success');
      syncUI();
    });
  }

  // Поля ввода на экране Пульт
  bindNumberInput('inputWatchSeconds', 'watchSeconds', 5, 120);
  bindNumberInput('inputLikeDelaySeconds', 'likeDelaySeconds', 1, 119);
  bindNumberInput('inputFavoriteEveryN', 'favoriteEveryN', 1, 50);
  bindNumberInput('inputCommentEveryN', 'commentEveryN', 1, 50);
  bindNumberInput('inputHourlyLimit', 'hourlyLimit', 10, 500);

  const selectSpeedProfile = document.getElementById('selectSpeedProfile');
  if (selectSpeedProfile) {
    selectSpeedProfile.addEventListener('change', e => {
      updateSetting('speedProfile', e.target.value);
    });
  }

  bindCheckbox('chkAutoLike', 'autoLike');
  bindCheckbox('chkAutoFavorite', 'autoFavorite');
  bindCheckbox('chkAutoComment', 'autoComment');
  bindCheckbox('chkOnlyInTiktok', 'onlyInTiktok');
  bindCheckbox('chkHumanizeTiming', 'humanizeTiming');
  bindCheckbox('chkLargeAccessibility', 'largeAccessibility');
  bindCheckbox('chkSoundFeedback', 'soundFeedback');

  const inputVideoTopic = document.getElementById('inputVideoTopic');
  if (inputVideoTopic) {
    inputVideoTopic.addEventListener('input', e => {
      state.settings.videoTopic = e.target.value.slice(0, 80);
      saveState(state);
      renderCycleProgress(state, runtime);
    });
  }

  // Добавление нового шаблона комментария
  const addCommentForm = document.getElementById('addCommentForm');
  if (addCommentForm) {
    addCommentForm.addEventListener('submit', e => {
      e.preventDefault();
      const textInput = document.getElementById('newCommentText');
      const catSelect = document.getElementById('newCommentCategory');
      const rawText = textInput ? textInput.value.trim() : '';
      if (!rawText) {
        showBanner('Введите текст шаблона комментария.', 'error');
        return;
      }
      if (rawText.length > 150) {
        showBanner('Комментарий не должен превышать 150 символов.', 'error');
        return;
      }
      state.comments.unshift({
        id: `c_${Date.now()}`,
        text: rawText,
        category: catSelect ? catSelect.value : 'Поддержка',
        uses: 0
      });
      saveState(state);
      if (textInput) textInput.value = '';
      showBanner('Шаблон комментария добавлен!', 'success');
      syncUI();
    });
  }

  const restoreDefaultCommentsBtn = document.getElementById('restoreDefaultCommentsBtn');
  if (restoreDefaultCommentsBtn) {
    restoreDefaultCommentsBtn.addEventListener('click', () => {
      state.comments = DEFAULT_COMMENTS.map(c => ({ ...c }));
      saveState(state);
      showBanner('Стандартные шаблоны комментариев восстановлены.', 'success');
      syncUI();
    });
  }

  // Фильтр журнала
  const historyFilterSelect = document.getElementById('historyFilterSelect');
  if (historyFilterSelect) {
    historyFilterSelect.addEventListener('change', e => {
      runtime.historyFilter = e.target.value;
      syncUI();
    });
  }

  // Экспорт данных в JSON
  const exportDataBtn = document.getElementById('exportDataBtn');
  if (exportDataBtn) {
    exportDataBtn.addEventListener('click', () => {
      try {
        const jsonStr = JSON.stringify(state, null, 2);
        const blob = new Blob([jsonStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `tiktok-assistant-backup-${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 5000);
        showBanner('Файл со статистикой и настройками сохранён.', 'success');
      } catch (_) {
        showBanner('Не удалось создать файл резервной копии.', 'error');
      }
    });
  }

  // Импорт данных из JSON
  const importFileInput = document.getElementById('importFileInput');
  if (importFileInput) {
    importFileInput.addEventListener('change', e => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const parsed = JSON.parse(String(reader.result || '{}'));
          const restored = sanitizeState(parsed);
          Object.assign(state, restored);
          saveState(state);
          syncUI();
          showBanner('Данные и статистика успешно загружены из файла!', 'success');
        } catch (_) {
          showBanner('Ошибка чтения файла: выберите корректный JSON-файл резервной копии.', 'error');
        }
      };
      reader.readAsText(file);
      importFileInput.value = '';
    });
  }

  // Сброс статистики
  const resetAllStatsBtn = document.getElementById('resetAllStatsBtn');
  if (resetAllStatsBtn) {
    resetAllStatsBtn.addEventListener('click', () => {
      const confirmed = window.confirm('Вы уверены, что хотите обнулить статистику и очистить журнал действий?');
      if (!confirmed) return;
      const fresh = createDefaultState();
      state.stats = fresh.stats;
      state.history = [];
      saveState(state);
      showBanner('Статистика и журнал действий очищены.', 'info');
      syncUI();
    });
  }
}

function bindNumberInput(id, settingKey, min, max) {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('change', e => {
    const val = Number(e.target.value);
    if (!Number.isFinite(val)) {
      e.target.value = String(state.settings[settingKey]);
      return;
    }
    const clamped = Math.min(max, Math.max(min, Math.round(val)));
    updateSetting(settingKey, clamped);
  });
}

function bindCheckbox(id, settingKey) {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('change', e => {
    updateSetting(settingKey, Boolean(e.target.checked));
  });
}

// Инициализация приложения
computeCycleTargets();
bindEvents();
applyRoute();
syncUI();
