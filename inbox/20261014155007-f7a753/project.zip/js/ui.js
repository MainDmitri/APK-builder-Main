// Отрисовка интерфейса, графиков, списков и звуковой обратной связи
import { getTodayKey } from './storage.js';

let audioCtx = null;

export function playFeedbackTone(enabled, type = 'like') {
  if (!enabled) return;
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    if (!audioCtx) {
      audioCtx = new AudioContextClass();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sine';
    const now = audioCtx.currentTime;

    if (type === 'like') {
      osc.frequency.setValueAtTime(520, now);
      osc.frequency.exponentialRampToValueAtTime(760, now + 0.09);
    } else if (type === 'next') {
      osc.frequency.setValueAtTime(420, now);
      osc.frequency.exponentialRampToValueAtTime(540, now + 0.08);
    } else {
      osc.frequency.setValueAtTime(640, now);
    }

    gain.gain.setValueAtTime(0.06, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);

    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start(now);
    osc.stop(now + 0.12);
  } catch (_) {
    // Без звука если Web Audio недоступен
  }
}

export function showBanner(message, variant = 'info') {
  const banner = document.getElementById('alertBanner');
  const textEl = document.getElementById('alertBannerText');
  if (!banner || !textEl) return;

  textEl.textContent = message;
  banner.classList.remove('hidden', 'alert-banner--error', 'alert-banner--success');
  if (variant === 'error') {
    banner.classList.add('alert-banner--error');
  } else if (variant === 'success') {
    banner.classList.add('alert-banner--success');
  }
}

export function hideBanner() {
  const banner = document.getElementById('alertBanner');
  if (banner) {
    banner.classList.add('hidden');
  }
}

export function formatDuration(totalSeconds) {
  const sec = Math.max(0, Math.round(totalSeconds || 0));
  if (sec < 60) return `${sec} сек`;
  const mins = Math.floor(sec / 60);
  const remSec = sec % 60;
  if (mins < 60) {
    return remSec > 0 ? `${mins} мин ${remSec} с` : `${mins} мин`;
  }
  const hours = Math.floor(mins / 60);
  const remMins = mins % 60;
  return `${hours} ч ${remMins} мин`;
}

export function formatTimeShort(isoString) {
  try {
    const d = new Date(isoString);
    return d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  } catch (_) {
    return '';
  }
}

export function renderAll(state, runtime, callbacks) {
  const { settings, stats } = state;

  document.body.classList.toggle('large-accessibility', Boolean(settings.largeAccessibility));

  // Шапка и плавающий пульт
  const overlayEl = document.getElementById('floatingOverlay');
  const overlayDot = document.getElementById('overlayDot');
  if (overlayEl) {
    overlayEl.classList.toggle('hidden', !settings.overlayVisible);
    overlayEl.classList.toggle('minimized', Boolean(settings.overlayMinimized));
  }
  if (overlayDot) {
    overlayDot.classList.toggle('active', Boolean(settings.overlayVisible));
  }

  const statusHeaderText = document.getElementById('statusHeaderText');
  const overlayStatusIndicator = document.getElementById('overlayStatusIndicator');
  if (statusHeaderText) {
    if (runtime.isRunning) {
      statusHeaderText.textContent = settings.isTiktokActive
        ? `Работает в TikTok • Ролик #${stats.totalVideos + 1}`
        : 'Пауза: ожидание входа в TikTok';
    } else {
      statusHeaderText.textContent = 'Готов к работе • Защита активна';
    }
  }
  if (overlayStatusIndicator) {
    overlayStatusIndicator.classList.toggle('running', Boolean(runtime.isRunning && settings.isTiktokActive));
  }

  // Переключатель «Я в TikTok»
  const tiktokSwitch = document.getElementById('tiktokContextSwitch');
  const tiktokHint = document.getElementById('tiktokGuardHint');
  if (tiktokSwitch) {
    tiktokSwitch.setAttribute('aria-checked', String(Boolean(settings.isTiktokActive)));
  }
  if (tiktokHint) {
    tiktokHint.textContent = settings.isTiktokActive
      ? 'TikTok активен — авто-действия разрешены'
      : 'Вне TikTok — действия заблокированы';
  }

  // Слайдеры и поля времени
  const overlayWatchRange = document.getElementById('overlayWatchRange');
  const overlayWatchValue = document.getElementById('overlayWatchValue');
  const inputWatchSeconds = document.getElementById('inputWatchSeconds');
  if (overlayWatchRange) overlayWatchRange.value = String(settings.watchSeconds);
  if (overlayWatchValue) overlayWatchValue.textContent = `${settings.watchSeconds} сек`;
  if (inputWatchSeconds && document.activeElement !== inputWatchSeconds) {
    inputWatchSeconds.value = String(settings.watchSeconds);
  }

  const overlayLikeDelayRange = document.getElementById('overlayLikeDelayRange');
  const overlayLikeDelayValue = document.getElementById('overlayLikeDelayValue');
  const inputLikeDelaySeconds = document.getElementById('inputLikeDelaySeconds');
  if (overlayLikeDelayRange) {
    overlayLikeDelayRange.max = String(Math.max(1, settings.watchSeconds - 1));
    overlayLikeDelayRange.value = String(settings.likeDelaySeconds);
  }
  if (overlayLikeDelayValue) overlayLikeDelayValue.textContent = `через ${settings.likeDelaySeconds} сек`;
  if (inputLikeDelaySeconds && document.activeElement !== inputLikeDelaySeconds) {
    inputLikeDelaySeconds.value = String(settings.likeDelaySeconds);
  }

  // Маркер момента лайка на прогресс-баре
  const cycleLikeMarker = document.getElementById('cycleLikeMarker');
  if (cycleLikeMarker) {
    const pct = Math.min(95, Math.max(5, (settings.likeDelaySeconds / settings.watchSeconds) * 100));
    cycleLikeMarker.style.left = `${pct}%`;
    cycleLikeMarker.style.display = settings.autoLike ? 'flex' : 'none';
  }

  // Кнопки-пилюли в пульте
  const pillLike = document.getElementById('pillLikeToggle');
  const pillFav = document.getElementById('pillFavToggle');
  const pillComment = document.getElementById('pillCommentToggle');
  if (pillLike) pillLike.classList.toggle('active', Boolean(settings.autoLike));
  if (pillFav) pillFav.classList.toggle('active', Boolean(settings.autoFavorite));
  if (pillComment) pillComment.classList.toggle('active', Boolean(settings.autoComment));

  // Кнопка Старт/Стоп
  const startStopBtn = document.getElementById('startStopBtn');
  if (startStopBtn) {
    startStopBtn.classList.toggle('running', Boolean(runtime.isRunning));
    startStopBtn.textContent = runtime.isRunning
      ? '⏸ Остановить авто-помощник'
      : '▶ Запустить авто-помощник';
  }

  // Мини-статистика в пульте
  setText('miniStatVideos', stats.totalVideos);
  setText('miniStatLikes', stats.totalLikes);
  setText('miniStatFavs', stats.totalFavorites);
  setText('miniStatComments', stats.totalComments);

  // Оценка безопасности темпа
  const safetyBadge = document.getElementById('safetyRateBadge');
  if (safetyBadge) {
    const videosPerHour = Math.round(3600 / Math.max(5, settings.watchSeconds));
    if (videosPerHour > settings.hourlyLimit) {
      safetyBadge.textContent = `Быстрый темп (~${videosPerHour}/ч)`;
    } else {
      safetyBadge.textContent = `Безопасный темп (~${videosPerHour}/ч)`;
    }
  }

  // Форма настроек на главном экране
  setSelectValue('selectSpeedProfile', settings.speedProfile);
  setCheckbox('chkAutoLike', settings.autoLike);
  setCheckbox('chkAutoFavorite', settings.autoFavorite);
  setInputValue('inputFavoriteEveryN', settings.favoriteEveryN);
  setCheckbox('chkAutoComment', settings.autoComment);
  setInputValue('inputCommentEveryN', settings.commentEveryN);
  setInputValue('inputVideoTopic', settings.videoTopic);

  // Подсветка чипсов пресетов
  document.querySelectorAll('.preset-chips').forEach(group => {
    const target = group.getAttribute('data-preset-target');
    const currentVal = Number(settings[target]);
    group.querySelectorAll('.preset-chip').forEach(chip => {
      chip.classList.toggle('active', Number(chip.getAttribute('data-value')) === currentVal);
    });
  });

  // Настройки безопасности
  setCheckbox('chkOnlyInTiktok', settings.onlyInTiktok);
  setCheckbox('chkHumanizeTiming', settings.humanizeTiming);
  setInputValue('inputHourlyLimit', settings.hourlyLimit);
  setCheckbox('chkLargeAccessibility', settings.largeAccessibility);
  setCheckbox('chkSoundFeedback', settings.soundFeedback);

  // Статистика
  const todayKey = getTodayKey();
  const todayStats = stats.daily[todayKey] || { videos: 0, likes: 0, favorites: 0, comments: 0 };
  setText('statsTodayDateBadge', `Сегодня (${todayKey})`);
  setText('statTotalLikes', stats.totalLikes);
  setText('statTodayLikes', todayStats.likes);
  setText('statTotalComments', stats.totalComments);
  setText('statTodayComments', todayStats.comments);
  setText('statTotalFavorites', stats.totalFavorites);
  setText('statTodayFavorites', todayStats.favorites);
  setText('statTotalVideos', stats.totalVideos);
  setText('statTotalWatchTime', formatDuration(stats.totalWatchSeconds));

  renderCommentsList(state, callbacks);
  renderWeeklyChart(state);
  renderHistoryList(state, runtime.historyFilter || 'all');
}

export function renderCycleProgress(state, runtime) {
  const phaseLabel = document.getElementById('cyclePhaseLabel');
  const timerDisplay = document.getElementById('cycleTimerDisplay');
  const progressFill = document.getElementById('cycleProgressFill');
  const progressWrap = document.getElementById('cycleProgressBarWrap');
  const currentVideoTag = document.getElementById('currentVideoTag');

  const targetSec = runtime.currentTargetSeconds || state.settings.watchSeconds;
  const elapsedSec = Math.min(targetSec, runtime.elapsedSeconds || 0);
  const pct = Math.min(100, Math.round((elapsedSec / Math.max(1, targetSec)) * 100));

  if (timerDisplay) {
    timerDisplay.textContent = `${elapsedSec.toFixed(1)} / ${targetSec} сек`;
  }
  if (progressFill) {
    progressFill.style.width = `${pct}%`;
  }
  if (progressWrap) {
    progressWrap.setAttribute('aria-valuenow', String(pct));
  }
  if (currentVideoTag) {
    currentVideoTag.textContent = `Ролик #${state.stats.totalVideos + 1} • ${state.settings.videoTopic || 'Лента'}`;
  }
  if (phaseLabel) {
    if (!runtime.isRunning) {
      phaseLabel.textContent = 'На паузе (нажмите Запустить)';
    } else if (state.settings.onlyInTiktok && !state.settings.isTiktokActive) {
      phaseLabel.textContent = 'Ожидание: откройте TikTok';
    } else if (runtime.likedInCurrentCycle) {
      phaseLabel.textContent = '♥ Лайк поставлен • Досматриваем';
    } else {
      phaseLabel.textContent = '👀 Просмотр видео...';
    }
  }
}

function renderCommentsList(state, callbacks) {
  const container = document.getElementById('commentsListContainer');
  const badge = document.getElementById('commentsCountBadge');
  if (badge) badge.textContent = String(state.comments.length);
  if (!container) return;

  container.replaceChildren();

  if (state.comments.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.textContent = 'Список шаблонов пуст. Добавьте свою фразу выше или верните стандартные.';
    container.appendChild(empty);
    return;
  }

  state.comments.forEach(item => {
    const card = document.createElement('div');
    card.className = 'comment-item';

    const top = document.createElement('div');
    top.className = 'comment-item__top';

    const textP = document.createElement('p');
    textP.className = 'comment-item__text';
    textP.textContent = item.text;

    const catBadge = document.createElement('span');
    catBadge.className = 'badge';
    catBadge.textContent = `${item.category} • исп. ${item.uses || 0}`;

    top.appendChild(textP);
    top.appendChild(catBadge);

    const actions = document.createElement('div');
    actions.className = 'comment-item__actions';

    const copyBtn = document.createElement('button');
    copyBtn.type = 'button';
    copyBtn.className = 'btn btn--tonal btn--small';
    copyBtn.textContent = '📋 Скопировать и учесть';
    copyBtn.addEventListener('click', () => callbacks.onUseComment(item.id));

    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.className = 'btn btn--danger btn--small';
    delBtn.textContent = 'Удалить';
    delBtn.addEventListener('click', () => callbacks.onDeleteComment(item.id));

    actions.appendChild(copyBtn);
    actions.appendChild(delBtn);

    card.appendChild(top);
    card.appendChild(actions);
    container.appendChild(card);
  });
}

function renderWeeklyChart(state) {
  const container = document.getElementById('weeklyChartContainer');
  if (!container) return;
  container.replaceChildren();

  const days = [];
  const now = new Date();
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(now.getDate() - i);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const key = `${y}-${m}-${day}`;
    const label = d.toLocaleDateString('ru-RU', { weekday: 'short', day: 'numeric' });
    const record = state.stats.daily[key] || { likes: 0, comments: 0, favorites: 0, videos: 0 };
    days.push({ key, label, likes: record.likes || 0, comments: record.comments || 0 });
  }

  const maxVal = Math.max(5, ...days.map(d => d.likes + d.comments));
  const barsWrap = document.createElement('div');
  barsWrap.className = 'chart-bars';

  days.forEach(d => {
    const totalActions = d.likes + d.comments;
    const heightPct = Math.max(8, Math.round((totalActions / maxVal) * 100));

    const col = document.createElement('div');
    col.className = 'chart-col';

    const valSpan = document.createElement('span');
    valSpan.className = 'chart-col__val';
    valSpan.textContent = String(totalActions);

    const bar = document.createElement('div');
    bar.className = 'chart-col__bar';
    bar.style.height = `${heightPct}%`;
    bar.title = `Лайков: ${d.likes}, Комментариев: ${d.comments}`;

    const daySpan = document.createElement('span');
    daySpan.className = 'chart-col__day';
    daySpan.textContent = d.label;

    col.appendChild(valSpan);
    col.appendChild(bar);
    col.appendChild(daySpan);
    barsWrap.appendChild(col);
  });

  container.appendChild(barsWrap);
}

function renderHistoryList(state, filter) {
  const container = document.getElementById('historyListContainer');
  if (!container) return;
  container.replaceChildren();

  const filtered = state.history.filter(item => {
    if (filter === 'like') return item.liked;
    if (filter === 'favorite') return item.favorited;
    if (filter === 'comment') return Boolean(item.commentText);
    return true;
  });

  if (filtered.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.textContent = 'Пока нет записей в журнале. Запустите авто-помощник или нажмите «Разовый лайк».';
    container.appendChild(empty);
    return;
  }

  filtered.slice(0, 40).forEach(item => {
    const row = document.createElement('div');
    row.className = 'history-item';

    const info = document.createElement('div');
    info.className = 'history-item__info';

    const badges = [];
    if (item.liked) badges.push('♥ Лайк');
    if (item.favorited) badges.push('★ Избранное');
    if (item.commentText) badges.push(`💬 «${item.commentText}»`);
    if (badges.length === 0) badges.push('👀 Просмотр');

    const title = document.createElement('div');
    title.className = 'history-item__title';
    title.textContent = `Ролик #${item.videoNumber} (${item.topic}): ${badges.join(' • ')}`;

    const meta = document.createElement('div');
    meta.className = 'history-item__meta';
    meta.textContent = `${formatTimeShort(item.timestamp)} • Просмотр ${item.watchSeconds} сек`;

    info.appendChild(title);
    info.appendChild(meta);
    row.appendChild(info);
    container.appendChild(row);
  });
}

function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = String(val);
}

function setCheckbox(id, val) {
  const el = document.getElementById(id);
  if (el) el.checked = Boolean(val);
}

function setInputValue(id, val) {
  const el = document.getElementById(id);
  if (el && document.activeElement !== el) {
    el.value = String(val ?? '');
  }
}

function setSelectValue(id, val) {
  const el = document.getElementById(id);
  if (el) el.value = String(val);
}
