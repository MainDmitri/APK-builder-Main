package com.mcpehtml.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.ServerSocket

/**
 * Оболочка игры: полноэкранный WebView с игрой из assets/www, встроенный ретранслятор
 * WebSocket <-> UDP (RelayServer) и папка игры в хранилище (паки, скрипты, скины).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var relay: RelayServer? = null
    private var relayPort = 0
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    // Файл, открытый через «Открыть с помощью» / «Поделиться»: забирается из JS
    @Volatile private var pendingName: String? = null
    @Volatile private var pendingData: String? = null

    private val prefs by lazy { getSharedPreferences("game", MODE_PRIVATE) }

    // Выбор файлов для <input type=file>: любые типы, можно несколько сразу
    private val fileChooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val cb = fileCallback
        fileCallback = null
        if (cb == null) return@registerForActivityResult
        val data = result.data
        if (result.resultCode != Activity.RESULT_OK || data == null) { cb.onReceiveValue(null); return@registerForActivityResult }
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { uris.add(it) }
        else data.data?.let { uris.add(it) }
        cb.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
    }

    // Выбор папки игры (Storage Access Framework): доступ сохраняется между запусками
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        var ok = false
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (e: SecurityException) {
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e2: SecurityException) {}
            }
            prefs.edit().putString("folder", uri.toString()).apply()
            ensureSubfolders(uri)
            ok = true
        }
        web.evaluateJavascript("window.MC && MC.GameFolder && MC.GameFolder.onPicked($ok)", null)
    }

    // Доступен в JS как window.AndroidRelay
    inner class RelayBridge {
        @JavascriptInterface
        fun getUrl(): String = "ws://127.0.0.1:$relayPort"

        @JavascriptInterface
        fun isRunning(): Boolean = relay != null
    }

    // Доступен в JS как window.AndroidStorage
    inner class StorageBridge {
        @JavascriptInterface
        fun pickFolder() { runOnUiThread { folderPicker.launch(null) } }

        @JavascriptInterface
        fun folderName(): String {
            val tree = folderUri() ?: return ""
            return try {
                val doc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
                queryString(doc, DocumentsContract.Document.COLUMN_DISPLAY_NAME) ?: ""
            } catch (e: Exception) { "" }
        }

        // Файлы корня папки и подпапок packs, scripts, skins, schematics: [{id, name, dir, size, modified}]
        @JavascriptInterface
        fun list(): String {
            val tree = folderUri() ?: return "[]"
            val out = JSONArray()
            try {
                val rootId = DocumentsContract.getTreeDocumentId(tree)
                for (child in children(tree, rootId)) {
                    if (child.isDir) {
                        if (child.name.lowercase() in SUBFOLDERS) {
                            for (f in children(tree, child.id)) if (!f.isDir) out.put(f.toJson(child.name))
                        }
                    } else out.put(child.toJson(""))
                }
            } catch (e: Exception) {
                return "[]"
            }
            return out.toString()
        }

        // Содержимое файла в base64 ("" при ошибке)
        @JavascriptInterface
        fun read(id: String): String {
            val tree = folderUri() ?: return ""
            return try {
                val uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                Base64.encodeToString(readBytes(uri) ?: return "", Base64.NO_WRAP)
            } catch (e: Exception) { "" }
        }

        // Записывает файл (base64) в подпапку dir выбранной папки, заменяя файл с тем же именем. "" — успех, иначе текст ошибки
        @JavascriptInterface
        fun write(dir: String, name: String, b64: String): String {
            val tree = folderUri() ?: return "Папка игры не выбрана"
            if (!contentResolver.persistedUriPermissions.any { it.uri == tree && it.isWritePermission }) return "Нет разрешения на запись в папку"
            if (name.isEmpty() || name.contains('/') || dir.contains('/')) return "Недопустимое имя файла"
            return try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                val rootId = DocumentsContract.getTreeDocumentId(tree)
                var parentId = rootId
                if (dir.isNotEmpty()) {
                    val sub = children(tree, rootId).firstOrNull { it.isDir && it.name.equals(dir, ignoreCase = true) }
                    parentId = sub?.id ?: run {
                        val created = DocumentsContract.createDocument(contentResolver, DocumentsContract.buildDocumentUriUsingTree(tree, rootId), DocumentsContract.Document.MIME_TYPE_DIR, dir)
                            ?: return "Не удалось создать папку $dir"
                        DocumentsContract.getDocumentId(created)
                    }
                }
                val existing = children(tree, parentId).firstOrNull { !it.isDir && it.name == name }
                val target: Uri = if (existing != null) DocumentsContract.buildDocumentUriUsingTree(tree, existing.id)
                else DocumentsContract.createDocument(contentResolver, DocumentsContract.buildDocumentUriUsingTree(tree, parentId), "application/octet-stream", name)
                    ?: return "Не удалось создать файл"
                contentResolver.openOutputStream(target, "wt")?.use { it.write(bytes) } ?: return "Не удалось открыть файл для записи"
                ""
            } catch (e: Exception) {
                e.message ?: "Ошибка записи"
            }
        }

        @JavascriptInterface
        fun takePending(): String {
            val data = pendingData ?: return ""
            val name = pendingName ?: "pack.mcpack"
            pendingData = null
            pendingName = null
            return JSONObject().put("name", name).put("data", data).toString()
        }
    }

    private class Doc(val id: String, val name: String, val isDir: Boolean, val size: Long, val modified: Long) {
        fun toJson(dir: String): JSONObject = JSONObject().put("id", id).put("name", name).put("dir", dir).put("size", size).put("modified", modified)
    }

    private fun folderUri(): Uri? {
        val s = prefs.getString("folder", null) ?: return null
        val uri = Uri.parse(s)
        val granted = contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
        return if (granted) uri else null
    }

    private fun children(tree: Uri, parentId: String): List<Doc> {
        val list = ArrayList<Doc>()
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        contentResolver.query(uri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                val dir = c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR
                list.add(Doc(id, name, dir, if (c.isNull(3)) 0 else c.getLong(3), if (c.isNull(4)) 0 else c.getLong(4)))
            }
        }
        return list
    }

    private fun ensureSubfolders(tree: Uri) {
        try {
            val rootId = DocumentsContract.getTreeDocumentId(tree)
            val root = DocumentsContract.buildDocumentUriUsingTree(tree, rootId)
            val existing = children(tree, rootId).filter { it.isDir }.map { it.name.lowercase() }.toSet()
            for (name in SUBFOLDERS) {
                if (name !in existing) DocumentsContract.createDocument(contentResolver, root, DocumentsContract.Document.MIME_TYPE_DIR, name)
            }
        } catch (e: Exception) {
            // Папка только для чтения: файлы можно класть прямо в корень
        }
    }

    private fun queryString(uri: Uri, column: String): String? {
        var c: Cursor? = null
        return try {
            c = contentResolver.query(uri, arrayOf(column), null, null, null)
            if (c != null && c.moveToFirst()) c.getString(0) else null
        } catch (e: Exception) { null } finally { c?.close() }
    }

    private fun readBytes(uri: Uri): ByteArray? {
        contentResolver.openInputStream(uri)?.use { input ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(64 * 1024)
            var total = 0L
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                total += n
                if (total > MAX_FILE) throw IOException("Файл больше 64 МБ")
                out.write(buf, 0, n)
            }
            return out.toByteArray()
        }
        return null
    }

    @Suppress("DEPRECATION")
    private fun streamExtra(intent: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)

    // .mcpack/.zip/.js, открытый из проводника или присланный через «Поделиться»
    private fun handleIncoming(intent: Intent?) {
        if (intent == null) return
        val uri: Uri = when (intent.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> streamExtra(intent)
            else -> null
        } ?: return
        Thread {
            try {
                val bytes = readBytes(uri) ?: return@Thread
                val name = queryString(uri, OpenableColumns.DISPLAY_NAME) ?: uri.lastPathSegment ?: "pack.mcpack"
                pendingName = name
                pendingData = Base64.encodeToString(bytes, Base64.NO_WRAP)
                runOnUiThread { if (::web.isInitialized) web.evaluateJavascript("window.MC && MC.App && MC.App.ui && MC.GameFolder && MC.GameFolder.onIncoming()", null) }
            } catch (e: Exception) {
                // Файл недоступен: пропускаем
            }
        }.start()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        startRelay()

        web = WebView(this)
        web.setBackgroundColor(0xFF000000.toInt())
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.displayZoomControls = false
        s.textZoom = 100

        // Игра лежит в assets/www и открывается с постоянного https-адреса, как в профиле A движка
        val loader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url
                if (url.host == "appassets.androidplatform.net") {
                    val path = url.path ?: "/"
                    val mapped = if (path == "/" || path.isEmpty()) "/www/index.html" else "/www$path"
                    return loader.shouldInterceptRequest(Uri.parse("https://appassets.androidplatform.net$mapped"))
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.host == "appassets.androidplatform.net") return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, url))
                    true
                } catch (e: Exception) {
                    true
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(webView: WebView, filePathCallback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                // Фильтр по расширению (.mcpack, .js) Android не понимает, поэтому показываем все файлы
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    val types = params.acceptTypes.filter { it.contains('/') }
                    type = if (types.size == 1) types[0] else "*/*"
                    if (params.mode == FileChooserParams.MODE_OPEN_MULTIPLE) putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                return try {
                    fileChooser.launch(Intent.createChooser(intent, "Выберите файл"))
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        web.addJavascriptInterface(RelayBridge(), "AndroidRelay")
        web.addJavascriptInterface(StorageBridge(), "AndroidStorage")
        setContentView(web)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.MC && MC.App && typeof MC.App.androidBack === 'function') ? MC.App.androidBack() : false") { value ->
                    if (value != "true") finish()
                }
            }
        })

        handleIncoming(intent)
        web.loadUrl("https://appassets.androidplatform.net/index.html")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncoming(intent)
    }

    private fun startRelay() {
        if (relay != null) return
        var port = 0
        try {
            val probe = ServerSocket(0)
            port = probe.localPort
            probe.close()
        } catch (e: IOException) {}
        if (port == 0) port = 28080
        relayPort = port
        val server = RelayServer(port)
        server.start()
        relay = server
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        web.onResume()
        web.resumeTimers()
    }

    override fun onPause() {
        web.onPause()
        web.pauseTimers()
        super.onPause()
    }

    override fun onDestroy() {
        relay?.shutdown()
        relay = null
        web.destroy()
        super.onDestroy()
    }

    companion object {
        private val SUBFOLDERS = listOf("packs", "scripts", "skins", "schematics")
        private const val MAX_FILE = 64L * 1024 * 1024
    }
}
