// Точка входа: связывает рендер, управление, интерфейс и игровую сессию
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  const App = {
    settings: null,
    renderer: null,
    input: null,
    ui: null,
    game: null,
    active: false,
    connectAttempt: 0,

    async init() {
      this.settings = MC.Storage.loadSettings();
      // Файлы из папки игры и открытый в проводнике .mcpack импортируются до наложения паков
      this.startupNotes = [];
      try {
        const r = await MC.GameFolder.takePending();
        if (r) {
          if (r.kind === 'pack' && r.shaders) { this.settings.shaders = 'pack'; MC.Storage.saveSettings(this.settings); }
          this.startupNotes.push((r.kind === 'pack' ? 'Пак «' : r.kind === 'schematic' ? 'Схема «' : 'Скрипт «') + r.name + '» добавлен' + (r.kind === 'schematic' ? 'а' : ''));
        }
      } catch (e) { this.startupNotes.push('Файл не импортирован: ' + e.message); }
      try {
        if (MC.GameFolder.available() && await MC.GameFolder.name()) {
          const r = await MC.GameFolder.sync(false);
          if (r.packs || r.scripts || r.schematics || r.errors.length) this.startupNotes.push('Папка игры: ' + MC.GameFolder.summary(r));
        }
      } catch (e) { console.warn('Папка игры', e); }
      // Текстур-паки накладываются до загрузки атласов в рендер и интерфейс
      try { await MC.Packs.apply(); } catch (e) { console.warn('Текстур-паки не применены', e); }
      MC.Sound.load();
      const canvas = document.getElementById('game');
      this.renderer = new MC.Renderer(canvas);
      await this.renderer.init();
      await MC.Items.loadImages();
      this.ui = new MC.UI(this);
      await this.ui.init();
      this.input = new MC.Input(canvas, document.getElementById('touch'), this.settings);
      this.bindInput();
      this.applySettings();
      window.addEventListener('resize', () => this.resize());
      // При закрытии страницы сообщаем серверу об отключении, чтобы игрок не «висел» до тайм-аута
      window.addEventListener('pagehide', () => {
        if (this.game && this.game.client) this.game.client.disconnect();
      });
      document.addEventListener('visibilitychange', () => {
        if (document.hidden && this.game && this.game.mode === 'sp') this.game.save().catch((e) => console.warn('Сохранение', e));
      });
      this.ui.showHud(false);
      this.ui.showMain();
      let last = performance.now();
      const loop = (t) => {
        const dt = Math.min(0.1, (t - last) / 1000);
        last = t;
        if (this.game && this.game.ready && !this.game.stopped) this.game.frame(dt, this.active);
        requestAnimationFrame(loop);
      };
      requestAnimationFrame(loop);
    },

    bindInput() {
      const inp = this.input;
      inp.on('pause', () => this.pause());
      inp.on('players', () => this.showPlayers());
      inp.on('unlocked', () => this.pause());
      inp.on('escape', () => {
        if (this.game && this.game.ready && (this.ui.current === 'pause' || this.ui.current === 'inventory' || this.ui.current === 'build')) this.resume();
      });
      inp.on('chat', (prefix) => this.openChat(prefix));
      inp.on('inventory', () => this.openInventory());
      inp.on('hotbar', (i) => this.selectHotbar(i));
      inp.on('scroll', (d) => {
        if (!this.game) return;
        if (this.game.zooming) this.game.zoomScroll(d);
        else this.selectHotbar(this.game.selected + d);
      });
      inp.on('pick', () => this.game && this.game.pickBlock());
      inp.on('drop', () => this.game && this.game.ready && this.game.dropSelected(false));
      inp.on('toggleFly', () => this.game && this.game.toggleFly());
      inp.on('tbtn', (name) => {
        if (!this.game) return;
        if (name === 'chat') this.openChat('');
        else if (name === 'pause') this.pause();
        else if (name === 'hitbox') {
          const s = this.settings;
          s.hitboxes = !s.hitboxes;
          MC.Storage.saveSettings(s);
          this.applySettings();
          this.ui.setPopup(s.hitboxes ? 'Хитбоксы: показаны' : 'Хитбоксы: скрыты');
        }
        else if (name === 'view') {
          // Переключение вида: от первого лица → сзади → спереди
          const order = ['first', 'back', 'front'];
          const s = this.settings;
          s.camera = order[(order.indexOf(s.camera || 'first') + 1) % 3];
          MC.Storage.saveSettings(s);
          this.ui.setPopup(s.camera === 'first' ? 'Вид от первого лица' : s.camera === 'back' ? 'Вид от третьего лица (сзади)' : 'Вид от третьего лица (спереди)');
        }
        else if (name === 'inv') this.openInventory();
        else if (name === 'eb') this.openBuild();
        else if (name === 'undo' || name === 'redo') {
          if (this.game.building) this.game.building[name]();
        }
        else if (name === 'waypoint') {
          if (this.game.pvp) { const w = this.game.pvp.addWaypoint(''); this.ui.setPopup('Точка «' + w.name + '» добавлена: ' + w.x + ' ' + w.y + ' ' + w.z); }
        }
        else if (name === 'mapzoom') {
          if (this.game.pvp) { const c = this.game.pvp.cfg; c.mapZoom = c.mapZoom >= 4 ? 1 : c.mapZoom * 2; MC.Storage.saveSettings(this.settings); this.game.pvp.mapT = 0; }
        }
        else this.game.touchButton(name);
      });
    },

    resize() {
      const w = window.innerWidth, h = window.innerHeight;
      this.renderer.resize(w, h, Math.min(window.devicePixelRatio || 1, 2) * (this.settings.renderScale || 1));
      // Единица интерфейса: панель предметов (182 пикселя текстуры) занимает около половины ширины экрана
      const u = Math.max(1.5, Math.min(4, Math.min(w * 0.42, h * 1.1) / 182));
      document.documentElement.style.setProperty('--u', u.toFixed(2) + 'px');
    },

    applySettings() {
      const s = this.settings;
      this.renderer.fov = s.fov;
      this.renderer.clouds = s.clouds !== false;
      this.renderer.fancy = s.shaders !== 'fast';
      this.renderer.usePack = s.shaders === 'pack';
      this.renderer.showHitboxes = !!s.hitboxes;
      const hb = this.input && this.input.touchButtons && this.input.touchButtons.hitbox;
      if (hb && hb.el) hb.el.classList.toggle('on', !!s.hitboxes);
      this.renderer.brightness = typeof s.brightness === 'number' ? s.brightness : 1;
      if (this.game && this.game.particles) this.game.applyParticleSetting();
      this.resize();
      MC.Sound.setVolume(s.volume);
      this.renderer.renderDistance = this.game && this.game.mode === 'mp' ? Math.min(s.renderDistance, this.game.serverRadius) : s.renderDistance;
      this.input.refreshTouchMode();
      document.body.classList.toggle('touch', this.input.touchMode);
    },

    // ---------- Переходы между экранами ----------
    enterGame() {
      // Пользовательские скрипты запускаются один раз на игру
      const game = this.game;
      if (game && !game.scriptsStarted) {
        game.scriptsStarted = true;
        MC.Scripts.attach(game).then((rt) => { if (rt && (game.stopped || this.game !== game)) rt.stop(); else game.scripts = rt; });
      }
      this.ui.showPanorama(false);
      this.ui.clear();
      this.ui.showHud(true);
      // Кнопка смены режима — только в одиночной игре
      document.body.classList.toggle('sp', !!this.game && this.game.mode === 'sp');
      this.applySettings();
      this.active = true;
      this.input.setEnabled(true);
      this.input.lockPointer();
    },

    pause() {
      if (!this.game || !this.game.ready || !this.active) return;
      if (this.ui.chatOpen) return;
      this.active = false;
      this.input.setEnabled(false);
      this.ui.showPause(this.game);
    },

    // Список игроков сервера (Tab или кнопка в меню паузы)
    showPlayers() {
      if (!this.game || !this.game.ready || !this.active || this.game.mode !== 'mp') return;
      if (this.ui.chatOpen) return;
      this.active = false;
      this.input.setEnabled(false);
      this.ui.showPlayers(this.game, () => this.resume());
    },

    resume() {
      if (!this.game || !this.game.ready) return;
      this.game.closeInventory();
      if (this.game.dead) { this.showDeath(); return; }
      this.ui.clear();
      this.active = true;
      this.input.setEnabled(true);
      this.input.lockPointer();
    },

    openChat(prefix) {
      if (!this.game || !this.game.ready) return;
      this.active = false;
      this.input.setEnabled(false);
      this.ui.openChat(prefix);
    },

    openInventory() {
      if (!this.game || !this.game.ready || this.game.dead) return;
      this.active = false;
      this.input.setEnabled(false);
      this.game.openInventory();
    },

    showDeath(cause) {
      this.active = false;
      this.input.setEnabled(false);
      if (this.ui.chatOpen) this.ui.closeChat();
      this.ui.showDeath(cause);
    },

    // Меню строительства фигурами и схем (на сервере блоки ставятся пакетами в радиусе досягаемости)
    openBuild() {
      if (!this.game || !this.game.ready || this.game.dead) return;
      if (!this.game.building) return;
      this.active = false;
      this.input.setEnabled(false);
      this.ui.showBuild(this.game);
    },

    // Меню блока (верстак, печь, сундук) поверх игры
    openMenu(show) {
      this.active = false;
      this.input.setEnabled(false);
      show();
    },

    respawn() {
      if (!this.game) return;
      this.game.respawn();
      this.resume();
    },

    sendChat(text) { if (this.game) this.game.chat(text); },

    // Кнопка «Назад» на Android (вызывается из MainActivity.kt): true — обработано, false — закрыть приложение
    androidBack() {
      if (this.game && this.game.ready) {
        if (this.ui.chatOpen) { this.ui.closeChat(); return true; }
        if (this.game.invScreen) { this.resume(); return true; }
        if (this.active) { this.pause(); return true; }
        if (this.ui.current === 'pause' || this.ui.current === 'build') { this.resume(); return true; }
        return true;
      }
      if (this.ui.current && this.ui.current !== 'main') { this.ui.showMain(); return true; }
      return false;
    },

    selectHotbar(i) { if (this.game && this.game.ready) this.game.selectHotbar(i); },

    async stopGame() {
      const g = this.game;
      this.game = null;
      this.active = false;
      this.input.setEnabled(false);
      this.ui.showHud(false);
      this.ui.setNametags([]);
      if (g) await g.stop();
    },

    async quitToTitle() {
      const wasSp = this.game && this.game.mode === 'sp';
      await this.stopGame();
      if (wasSp) this.ui.showWorlds(); else this.ui.showMain();
    },

    async playWorld(w) {
      await this.stopGame();
      this.ui.showConnecting('Загрузка мира «' + w.name + '»...', () => this.quitToTitle());
      const g = new MC.Game(this, 'sp', { world: w });
      this.game = g;
      try {
        await g.start();
      } catch (e) {
        await this.stopGame();
        this.ui.showMessage('Ошибка', 'Не удалось загрузить мир: ' + e.message, () => this.ui.showWorlds());
        return;
      }
      if (this.game === g) this.enterGame();
    },

    async connect(srv) {
      await this.stopGame();
      const attempt = ++this.connectAttempt;
      const cancel = () => {
        this.connectAttempt++;
        this.stopGame().then(() => this.ui.showServers());
      };
      this.ui.showConnecting('Подключение к ' + srv.host + ':' + srv.port + '...', cancel);
      this.cancelConnect = cancel;
      const g = new MC.Game(this, 'mp', { server: srv });
      this.game = g;
      try {
        await g.start();
      } catch (e) {
        if (attempt !== this.connectAttempt) return;
        await this.stopGame();
        this.ui.showMessage('Не удалось подключиться', e.message, () => this.ui.showServers(), [['Повторить', () => this.connect(srv)]], 'К списку серверов');
        return;
      }
      if (attempt === this.connectAttempt && this.game === g) this.enterGame();
    },

    connectStatus(text) {
      if (this.ui.current === 'connecting') this.ui.showConnecting(text, this.cancelConnect);
    },

    transfer(srv) {
      this.connect(srv);
    },

    // Потеря связи: кнопка «Переподключиться»; при обрыве по тайм-ауту (плохой интернет) — само через 5 секунд.
    // После кика или бана сервера автоматически не заходим.
    async lostConnection(reason) {
      if (!this.game) return;
      const srv = this.game.opts && this.game.opts.server;
      await this.stopGame();
      if (!srv) { this.ui.showMessage('Соединение потеряно', reason || 'Отключено', () => this.ui.showServers()); return; }
      const timeout = /время ожидания|timeout|timed out/i.test(reason || '');
      const auto = timeout && this.settings.autoReconnect !== false;
      let timer = null;
      const stop = () => { if (timer) { clearInterval(timer); timer = null; } };
      const box = this.ui.showMessage('Соединение потеряно', reason || 'Отключено', () => { stop(); this.ui.showServers(); },
        [['Переподключиться', () => { stop(); this.connect(srv); }]], 'К списку серверов');
      if (!auto) return;
      let left = 5;
      const info = document.createElement('div');
      info.className = 'hint';
      box.insertBefore(info, box.querySelector('button'));
      const tick = () => {
        if (this.ui.current !== 'message') { stop(); return; }
        if (left <= 0) { stop(); this.connect(srv); return; }
        info.textContent = 'Переподключение через ' + left + ' с...';
        left--;
      };
      tick();
      timer = setInterval(tick, 1000);
    }
  };

  MC.App = App;

  window.addEventListener('load', () => {
    App.init().catch((e) => {
      console.error(e);
      const box = document.getElementById('fatal');
      box.textContent = 'Ошибка запуска: ' + e.message;
      box.style.display = 'block';
    });
    if ('serviceWorker' in navigator && !window.AndroidRelay && (location.protocol === 'https:' || location.protocol === 'http:')) {
      navigator.serviceWorker.register('sw.js').catch((e) => console.warn('Service worker не зарегистрирован', e));
    }
  });
})();
