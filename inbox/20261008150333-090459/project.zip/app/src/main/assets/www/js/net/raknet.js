// Клиент RakNet (UDP-протокол Minecraft PE) поверх транспорта датаграмм
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const { BinaryWriter, BinaryReader } = MC;

  const MAGIC = new Uint8Array([0x00, 0xff, 0xff, 0x00, 0xfe, 0xfe, 0xfe, 0xfe, 0xfd, 0xfd, 0xfd, 0xfd, 0x12, 0x34, 0x56, 0x78]);
  const RAKNET_PROTOCOL = 8;

  const ID = {
    CONNECTED_PING: 0x00,
    UNCONNECTED_PING: 0x01,
    CONNECTED_PONG: 0x03,
    OPEN_CONNECTION_REQUEST_1: 0x05,
    OPEN_CONNECTION_REPLY_1: 0x06,
    OPEN_CONNECTION_REQUEST_2: 0x07,
    OPEN_CONNECTION_REPLY_2: 0x08,
    CONNECTION_REQUEST: 0x09,
    CONNECTION_REQUEST_ACCEPTED: 0x10,
    NEW_INCOMING_CONNECTION: 0x13,
    NO_FREE_INCOMING_CONNECTIONS: 0x14,
    DISCONNECTION_NOTIFICATION: 0x15,
    CONNECTION_BANNED: 0x17,
    INCOMPATIBLE_PROTOCOL: 0x19,
    UNCONNECTED_PONG: 0x1c,
    GAME_PACKET: 0xfe
  };

  const isReliable = (r) => r === 2 || r === 3 || r === 4 || r === 6 || r === 7;
  const isSequenced = (r) => r === 1 || r === 4;
  const isOrdered = (r) => r === 1 || r === 3 || r === 4 || r === 7;

  function randomGuid() {
    const a = new Uint32Array(2);
    crypto.getRandomValues(a);
    return BigInt.asIntN(64, (BigInt(a[0]) << 32n) | BigInt(a[1]));
  }

  function writeAddress(w, address, port, family) {
    if (family === 6) {
      w.byte(6);
      w.lshort(23);
      w.short(port);
      w.int(0);
      const parts = expandIPv6(address);
      for (const p of parts) w.short(p);
      w.int(0);
    } else {
      w.byte(4);
      for (const p of address.split('.')) w.byte(~parseInt(p, 10) & 0xff);
      w.short(port);
    }
  }

  function expandIPv6(addr) {
    const [head, tail] = addr.split('::');
    const h = head ? head.split(':') : [];
    const t = tail !== undefined && tail ? tail.split(':') : [];
    const fill = tail !== undefined ? 8 - h.length - t.length : 0;
    const all = h.concat(new Array(fill).fill('0'), t);
    return all.map((x) => parseInt(x || '0', 16));
  }

  function readAddress(r) {
    const ver = r.byte();
    if (ver === 4) {
      const a = [];
      for (let i = 0; i < 4; i++) a.push(~r.byte() & 0xff);
      return { address: a.join('.'), port: r.short() };
    }
    r.lshort();
    const port = r.short();
    r.int();
    const parts = [];
    for (let i = 0; i < 8; i++) parts.push(r.short().toString(16));
    r.int();
    return { address: parts.join(':'), port };
  }

  class RakNetClient {
    constructor(transport) {
      this.t = transport;
      this.guid = randomGuid();
      this.serverGuid = 0n;
      this.mtu = 1400;
      this.state = 'idle';
      this.startTime = Date.now();
      this.lastReceive = Date.now();

      this.sendSeq = 0;
      this.messageIndex = 0;
      this.orderIndex = 0;
      this.splitId = 0;
      this.queue = [];
      this.queueSize = 0;
      this.recovery = new Map();
      this.ackQueue = [];
      this.nackQueue = [];
      this.highestSeq = -1;
      this.receivedReliable = new Set();
      this.reliableWindowStart = 0;
      this.splits = new Map();
      this.orderExpected = new Array(32).fill(0);
      this.orderQueues = Array.from({ length: 32 }, () => new Map());
      this.lastPing = 0;
      this.latency = 0;

      this.onconnect = null;
      this.onpacket = null;
      this.ondisconnect = null;

      transport.ondatagram = (d) => this.handleDatagram(d);
      transport.onclose = (reason) => this.finish(reason);
    }

    now() { return Date.now() - this.startTime; }

    raw(bytes) { this.t.send(bytes); }

    connect() {
      this.state = 'ocr1';
      const mtus = [1492, 1200, 576];
      let attempt = 0;
      const tryOcr1 = () => {
        if (this.state !== 'ocr1') return;
        if (attempt >= mtus.length * 4) {
          this.finish('Сервер не отвечает (нет ответа на запрос соединения RakNet)');
          return;
        }
        const mtu = mtus[Math.floor(attempt / 4)];
        attempt++;
        const w = new BinaryWriter(mtu);
        w.byte(ID.OPEN_CONNECTION_REQUEST_1).raw(MAGIC).byte(RAKNET_PROTOCOL);
        const pad = mtu - 28 - w.pos;
        w.raw(new Uint8Array(pad));
        this.raw(w.bytes());
        this.ocrTimer = setTimeout(tryOcr1, 500);
      };
      tryOcr1();
      this.tickTimer = setInterval(() => this.tick(), 50);
    }

    sendOcr2() {
      const w = new BinaryWriter(64);
      w.byte(ID.OPEN_CONNECTION_REQUEST_2).raw(MAGIC);
      writeAddress(w, this.t.address, this.t.port, this.t.family);
      w.short(this.mtu);
      w.long(this.guid);
      this.raw(w.bytes());
    }

    handleDatagram(d) {
      if (d.length === 0) return;
      this.lastReceive = Date.now();
      const id = d[0];
      try {
        if (id & 0x80) {
          if (id & 0x40) this.handleAck(d, false);
          else if (id & 0x20) this.handleAck(d, true);
          else this.handleDataFrame(d);
          return;
        }
        this.handleOffline(d);
      } catch (e) {
        console.warn('RakNet: ошибка разбора датаграммы', e);
      }
    }

    handleOffline(d) {
      const r = new BinaryReader(d, 1);
      switch (d[0]) {
        case ID.OPEN_CONNECTION_REPLY_1: {
          if (this.state !== 'ocr1') return;
          clearTimeout(this.ocrTimer);
          r.raw(16);
          this.serverGuid = r.long();
          r.byte();
          const mtu = r.short();
          this.mtu = Math.min(mtu, 1400);
          this.state = 'ocr2';
          let tries = 0;
          const tryOcr2 = () => {
            if (this.state !== 'ocr2') return;
            if (tries++ >= 8) {
              this.finish('Сервер не завершил подключение RakNet');
              return;
            }
            this.sendOcr2();
            this.ocrTimer = setTimeout(tryOcr2, 500);
          };
          tryOcr2();
          break;
        }
        case ID.OPEN_CONNECTION_REPLY_2: {
          if (this.state !== 'ocr2') return;
          clearTimeout(this.ocrTimer);
          r.raw(16);
          r.long();
          readAddress(r);
          const mtu = r.short();
          this.mtu = Math.min(mtu, 1400);
          this.state = 'handshake';
          const w = new BinaryWriter(32);
          w.byte(ID.CONNECTION_REQUEST).long(this.guid).long(this.now()).byte(0);
          this.sendReliable(w.bytes(), true);
          break;
        }
        case ID.INCOMPATIBLE_PROTOCOL:
          this.finish('Несовместимая версия RakNet на сервере');
          break;
        case ID.NO_FREE_INCOMING_CONNECTIONS:
          this.finish('Сервер переполнен');
          break;
        case ID.CONNECTION_BANNED:
          this.finish('Вы забанены на этом сервере');
          break;
        default:
          break;
      }
    }

    handleAck(d, nack) {
      const r = new BinaryReader(d, 1);
      const count = r.short();
      for (let i = 0; i < count && !r.eof(); i++) {
        const single = r.byte() !== 0;
        const start = r.ltriad();
        const end = single ? start : r.ltriad();
        for (let s = start; s <= end && s - start < 4096; s++) {
          const pk = this.recovery.get(s);
          if (!pk) continue;
          this.recovery.delete(s);
          if (nack) this.resend(pk);
        }
      }
    }

    resend(pk) {
      const seq = this.sendSeq++ & 0xffffff;
      pk.data[1] = seq & 0xff;
      pk.data[2] = (seq >>> 8) & 0xff;
      pk.data[3] = (seq >>> 16) & 0xff;
      pk.time = Date.now();
      this.recovery.set(seq, pk);
      this.raw(pk.data);
    }

    handleDataFrame(d) {
      const r = new BinaryReader(d, 1);
      const seq = r.ltriad();
      this.ackQueue.push(seq);
      if (seq > this.highestSeq + 1 && this.highestSeq >= 0) {
        for (let s = this.highestSeq + 1; s < seq && s - this.highestSeq < 512; s++) this.nackQueue.push(s);
      }
      if (seq > this.highestSeq) this.highestSeq = seq;
      const nackIdx = this.nackQueue.indexOf(seq);
      if (nackIdx >= 0) this.nackQueue.splice(nackIdx, 1);

      while (!r.eof()) {
        const flags = r.byte();
        const reliability = (flags & 0xe0) >> 5;
        const split = (flags & 0x10) !== 0;
        const len = Math.ceil(r.short() / 8);
        let messageIndex = -1, orderIndex = 0, orderChannel = 0;
        if (isReliable(reliability)) messageIndex = r.ltriad();
        if (isSequenced(reliability)) r.ltriad();
        if (isOrdered(reliability)) { orderIndex = r.ltriad(); orderChannel = r.byte(); }
        let splitCount = 0, sId = 0, splitIndex = 0;
        if (split) { splitCount = r.int(); sId = r.short(); splitIndex = r.int(); }
        if (len === 0) break;
        const payload = r.raw(len).slice();

        if (messageIndex >= 0) {
          if (messageIndex < this.reliableWindowStart || this.receivedReliable.has(messageIndex)) continue;
          this.receivedReliable.add(messageIndex);
          if (this.receivedReliable.size > 4096) {
            while (this.receivedReliable.has(this.reliableWindowStart) || this.receivedReliable.size > 4096) {
              this.receivedReliable.delete(this.reliableWindowStart);
              this.reliableWindowStart++;
            }
          }
        }

        let full = payload;
        if (split) {
          if (splitCount > 4096) continue;
          let entry = this.splits.get(sId);
          if (!entry) { entry = { count: splitCount, parts: new Array(splitCount), have: 0 }; this.splits.set(sId, entry); }
          if (!entry.parts[splitIndex]) { entry.parts[splitIndex] = payload; entry.have++; }
          if (entry.have < entry.count) continue;
          this.splits.delete(sId);
          let total = 0;
          for (const p of entry.parts) total += p.length;
          full = new Uint8Array(total);
          let o = 0;
          for (const p of entry.parts) { full.set(p, o); o += p.length; }
        }

        if (isOrdered(reliability) && !isSequenced(reliability) && orderChannel < 32) {
          this.deliverOrdered(orderChannel, orderIndex, full);
        } else {
          this.handleConnected(full);
        }
      }
    }

    deliverOrdered(ch, index, data) {
      const expected = this.orderExpected[ch];
      if (index < expected) return;
      if (index > expected) {
        this.orderQueues[ch].set(index, data);
        return;
      }
      this.handleConnected(data);
      this.orderExpected[ch]++;
      const q = this.orderQueues[ch];
      while (q.has(this.orderExpected[ch])) {
        const next = q.get(this.orderExpected[ch]);
        q.delete(this.orderExpected[ch]);
        this.handleConnected(next);
        this.orderExpected[ch]++;
      }
    }

    handleConnected(data) {
      const id = data[0];
      const r = new BinaryReader(data, 1);
      switch (id) {
        case ID.CONNECTED_PING: {
          const t = r.long();
          const w = new BinaryWriter(17);
          w.byte(ID.CONNECTED_PONG).long(t).long(this.now());
          this.sendReliable(w.bytes(), true);
          break;
        }
        case ID.CONNECTED_PONG: {
          const t = Number(r.long());
          // Сглаженный пинг: одиночный всплеск не дёргает цифру
          const l = Math.max(0, this.now() - t);
          this.latency = this.latency ? this.latency * 0.6 + l * 0.4 : l;
          break;
        }
        case ID.CONNECTION_REQUEST_ACCEPTED: {
          if (this.state !== 'handshake') return;
          const addr = readAddress(r);
          const w = new BinaryWriter(128);
          w.byte(ID.NEW_INCOMING_CONNECTION);
          writeAddress(w, this.t.address, this.t.port, this.t.family);
          for (let i = 0; i < 10; i++) writeAddress(w, '0.0.0.0', 0, 4);
          w.long(this.now()).long(this.now());
          this.sendReliable(w.bytes(), true);
          this.state = 'connected';
          this.serverAddressSeen = addr;
          if (this.onconnect) this.onconnect();
          break;
        }
        case ID.DISCONNECTION_NOTIFICATION:
          this.finish('Сервер закрыл соединение');
          break;
        case ID.GAME_PACKET:
          if (this.onpacket) this.onpacket(data.subarray(1));
          break;
        default:
          break;
      }
    }

    // Надёжная упорядоченная отправка (reliability 3, канал 0) с разбиением на части
    sendReliable(payload, immediate) {
      const maxPayload = this.mtu - 60;
      if (payload.length > maxPayload) {
        const count = Math.ceil(payload.length / maxPayload);
        const sid = this.splitId++ & 0xffff;
        const orderIndex = this.orderIndex++;
        for (let i = 0; i < count; i++) {
          const part = payload.subarray(i * maxPayload, Math.min(payload.length, (i + 1) * maxPayload));
          this.enqueue(this.encapsulate(part, orderIndex, { count, id: sid, index: i }));
        }
      } else {
        this.enqueue(this.encapsulate(payload, this.orderIndex++, null));
      }
      if (immediate) this.flush();
    }

    encapsulate(payload, orderIndex, split) {
      const w = new BinaryWriter(payload.length + 24);
      w.byte((3 << 5) | (split ? 0x10 : 0));
      w.short(payload.length * 8);
      w.ltriad(this.messageIndex++ & 0xffffff);
      w.ltriad(orderIndex & 0xffffff);
      w.byte(0);
      if (split) { w.int(split.count); w.short(split.id); w.int(split.index); }
      w.raw(payload);
      return w.bytes();
    }

    enqueue(frame) {
      if (this.queueSize + frame.length + 4 > this.mtu - 28) this.flush();
      this.queue.push(frame);
      this.queueSize += frame.length;
    }

    flush() {
      if (this.queue.length === 0) return;
      const w = new BinaryWriter(this.queueSize + 4);
      const seq = this.sendSeq++ & 0xffffff;
      w.byte(0x84).ltriad(seq);
      for (const f of this.queue) w.raw(f);
      const data = w.bytes();
      this.recovery.set(seq, { data, time: Date.now() });
      this.queue = [];
      this.queueSize = 0;
      this.raw(data);
    }

    sendAcks(list, flag) {
      if (list.length === 0) return;
      const sorted = Array.from(new Set(list)).sort((a, b) => a - b);
      const w = new BinaryWriter(16 + sorted.length * 7);
      w.byte(flag);
      const countPos = w.pos;
      w.short(0);
      let records = 0;
      let start = sorted[0], last = sorted[0];
      const push = () => {
        if (start === last) w.byte(1).ltriad(start);
        else w.byte(0).ltriad(start).ltriad(last);
        records++;
      };
      for (let i = 1; i < sorted.length; i++) {
        if (sorted[i] === last + 1) { last = sorted[i]; continue; }
        push();
        start = last = sorted[i];
      }
      push();
      w.view.setUint16(countPos, records, false);
      this.raw(w.bytes());
    }

    tick() {
      if (this.state === 'closed') return;
      if (this.ackQueue.length) { this.sendAcks(this.ackQueue, 0xc0); this.ackQueue = []; }
      if (this.nackQueue.length) { this.sendAcks(this.nackQueue, 0xa0); this.nackQueue = []; }
      this.flush();
      const now = Date.now();
      for (const [seq, pk] of this.recovery) {
        if (now - pk.time > 1500) {
          this.recovery.delete(seq);
          this.resend(pk);
        }
      }
      if (this.state === 'connected' && now - this.lastPing > 1000) {
        this.lastPing = now;
        const w = new BinaryWriter(9);
        w.byte(ID.CONNECTED_PING).long(this.now());
        this.sendReliable(w.bytes(), true);
      }
      if (this.state !== 'idle' && now - this.lastReceive > 20000) {
        this.finish('Превышено время ожидания ответа сервера');
      }
    }

    sendGamePacket(batch) {
      const data = new Uint8Array(batch.length + 1);
      data[0] = ID.GAME_PACKET;
      data.set(batch, 1);
      this.sendReliable(data, false);
    }

    disconnect() {
      if (this.state === 'connected') {
        this.sendReliable(new Uint8Array([ID.DISCONNECTION_NOTIFICATION]), true);
      }
      this.finish('Отключено');
    }

    finish(reason) {
      if (this.state === 'closed') return;
      this.state = 'closed';
      clearTimeout(this.ocrTimer);
      clearInterval(this.tickTimer);
      const t = this.t;
      setTimeout(() => t.close(reason), 100);
      if (this.ondisconnect) this.ondisconnect(reason);
    }
  }

  // Запрос информации о сервере (MOTD, онлайн, версия) без подключения
  async function pingServer(relayUrl, host, port) {
    const t = await MC.RelayTransport.open(relayUrl, host, port, 6000);
    const guid = randomGuid();
    const started = Date.now();
    return new Promise((resolve, reject) => {
      let tries = 0;
      let timer = null;
      const send = () => {
        if (tries++ >= 5) {
          t.close('timeout');
          reject(new Error('Сервер не отвечает'));
          return;
        }
        const w = new BinaryWriter(40);
        w.byte(ID.UNCONNECTED_PING).long(Date.now() - started).raw(MAGIC).long(guid);
        t.send(w.bytes());
        timer = setTimeout(send, 800);
      };
      t.onclose = (reason) => { clearTimeout(timer); reject(new Error(reason)); };
      t.ondatagram = (d) => {
        if (d[0] !== ID.UNCONNECTED_PONG) return;
        clearTimeout(timer);
        const r = new BinaryReader(d, 1);
        r.long();
        r.long();
        r.raw(16);
        const len = r.short();
        const motd = MC.utf8.decode(r.raw(Math.min(len, r.remaining())));
        const p = motd.split(';');
        t.onclose = null;
        t.close('done');
        resolve({
          edition: p[0],
          name: p[1] || '',
          protocol: parseInt(p[2], 10) || 0,
          version: p[3] || '',
          online: parseInt(p[4], 10) || 0,
          max: parseInt(p[5], 10) || 0,
          ping: Date.now() - started
        });
      };
      send();
    });
  }

  MC.RakNetClient = RakNetClient;
  MC.pingServer = pingServer;
})();
