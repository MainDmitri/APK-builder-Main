// Управление: клавиатура и мышь (ПК) и сенсорный экран (Android)
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  class Input {
    constructor(canvas, touchRoot, settings) {
      this.canvas = canvas;
      this.touchRoot = touchRoot;
      this.settings = settings;
      this.keys = new Set();
      this.lookDX = 0;
      this.lookDY = 0;
      this.attackHeld = false;
      this.useHeld = false;
      this.usePressed = false;
      this.attackPressed = false;
      this.enabled = false;
      this.handlers = {};
      this.lastSpace = 0;
      this.flyToggle = false;
      this.joy = { id: null, x: 0, y: 0, cx: 0, cy: 0, fx: 0, fy: 0 };
      this.lookTouch = null;
      this.touchButtons = {};
      // Время каждого клика для счётчика CPS (кадр может пропустить быстрые клики, поэтому считаем здесь)
      this.clicksL = [];
      this.clicksR = [];
      this.sneakToggle = false;
      this.joySprint = false;
      this.joyLastEnd = 0;
      this.touchMode = this.detectTouch();
      this.bindKeyboard();
      this.bindMouse();
      this.buildTouch();
    }

    on(name, fn) { this.handlers[name] = fn; }
    emit(name, arg) { if (this.handlers[name]) this.handlers[name](arg); }

    detectTouch() {
      if (this.settings.touch === 'on') return true;
      if (this.settings.touch === 'off') return false;
      return window.matchMedia && matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window && navigator.maxTouchPoints > 0;
    }

    setEnabled(v) {
      this.enabled = v;
      if (!v) {
        this.keys.clear();
        this.attackHeld = false;
        this.useHeld = false;
        this.joy.id = null;
        this.joy.fx = this.joy.fy = 0;
        if (this.padEl && this.dpad.id !== null) { this.dpad.id = null; this.setPadCell(null); }
        this.lookTouch = null;
        for (const b of Object.values(this.touchButtons)) b.held = false;
        if (document.pointerLockElement) document.exitPointerLock();
      }
      this.touchRoot.style.display = v && this.touchMode ? 'block' : 'none';
    }

    refreshTouchMode() {
      this.touchMode = this.detectTouch();
      const key = [this.settings.controls, this.settings.buttonScale, this.settings.buttonOpacity, this.settings.swapJumpSneak].join('|');
      if (key !== this.touchKey) { this.touchKey = key; this.buildTouch(); }
      this.touchRoot.style.display = this.enabled && this.touchMode ? 'block' : 'none';
    }

    lockPointer() {
      if (this.touchMode || document.pointerLockElement === this.canvas) return;
      const p = this.canvas.requestPointerLock && this.canvas.requestPointerLock();
      if (p && p.catch) p.catch(() => {});
    }

    bindKeyboard() {
      window.addEventListener('keydown', (e) => {
        if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
        if (!this.enabled) {
          if (e.code === 'Escape') this.emit('escape');
          return;
        }
        const code = e.code;
        if (code === 'Space' && !e.repeat) {
          const now = performance.now();
          if (now - this.lastSpace < 300) this.emit('toggleFly');
          this.lastSpace = now;
        }
        if (code === 'KeyT' || code === 'Enter') { e.preventDefault(); this.emit('chat', ''); return; }
        if (code === 'Slash') { e.preventDefault(); this.emit('chat', '/'); return; }
        if (code === 'KeyE') { this.emit('inventory'); return; }
        if (code === 'Escape') { this.emit('pause'); return; }
        if (code === 'Tab') { e.preventDefault(); this.emit('players'); return; }
        if (code === 'KeyQ') { this.emit('drop'); return; }
        if (code === 'F5') { e.preventDefault(); this.emit('tbtn', 'view'); return; }
        if (code === 'KeyG') { this.emit('tbtn', 'gm'); return; }
        if (code === 'KeyB') { this.emit('tbtn', 'hitbox'); return; }
        if (code === 'KeyV') { this.emit('tbtn', 'eb'); return; }
        if (code === 'KeyN') { this.emit('tbtn', 'waypoint'); return; }
        if (code === 'KeyM') { this.emit('tbtn', 'mapzoom'); return; }
        if (e.ctrlKey && code === 'KeyZ') { e.preventDefault(); this.emit('tbtn', 'undo'); return; }
        if (e.ctrlKey && code === 'KeyY') { e.preventDefault(); this.emit('tbtn', 'redo'); return; }
        if (code.startsWith('Digit')) {
          const n = parseInt(code.slice(5), 10);
          if (n >= 1 && n <= 9) this.emit('hotbar', n - 1);
        }
        if (['Space', 'ArrowUp', 'ArrowDown', 'Tab', 'AltLeft'].indexOf(code) >= 0) e.preventDefault();
        this.keys.add(code);
      });
      window.addEventListener('keyup', (e) => this.keys.delete(e.code));
      window.addEventListener('blur', () => { this.keys.clear(); this.attackHeld = false; this.useHeld = false; });
    }

    bindMouse() {
      const c = this.canvas;
      c.addEventListener('mousedown', (e) => {
        if (!this.enabled || this.touchMode) return;
        if (document.pointerLockElement !== c) { this.lockPointer(); return; }
        if (e.button === 0) { this.attackHeld = true; this.attackPressed = true; this.clicksL.push(performance.now()); }
        if (e.button === 2) { this.useHeld = true; this.usePressed = true; this.clicksR.push(performance.now()); }
        if (e.button === 1) { e.preventDefault(); this.emit('pick'); }
      });
      window.addEventListener('mouseup', (e) => {
        if (e.button === 0) this.attackHeld = false;
        if (e.button === 2) this.useHeld = false;
      });
      c.addEventListener('contextmenu', (e) => e.preventDefault());
      window.addEventListener('mousemove', (e) => {
        if (!this.enabled || document.pointerLockElement !== c) return;
        this.lookDX += e.movementX;
        this.lookDY += e.movementY;
      });
      c.addEventListener('wheel', (e) => {
        if (!this.enabled) return;
        e.preventDefault();
        this.emit('scroll', Math.sign(e.deltaY));
      }, { passive: false });
      document.addEventListener('pointerlockchange', () => {
        if (this.enabled && !this.touchMode && document.pointerLockElement !== c) this.emit('unlocked');
      });
    }

    // ---------- Сенсорное управление ----------
    // Две схемы: крестовина как в Minecraft PE 1.1 (кнопки из gui.png) или джойстик
    buildTouch() {
      const root = this.touchRoot;
      root.innerHTML = '';
      this.touchButtons = {};
      this.scheme = this.settings.controls === 'joystick' ? 'joystick' : 'dpad';
      // Как в Minecraft PE: прыжок и присед можно поменять местами (центр крестовины — прыжок, кнопка справа — присед)
      this.swap = !!this.settings.swapJumpSneak;
      this.center = this.swap ? 'jump' : 'sneak';
      root.style.setProperty('--tb', 'calc(min(13vh, 11vw) * ' + (this.settings.buttonScale || 1) + ')');
      root.style.setProperty('--to', String(this.settings.buttonOpacity || 0.75));
      root.className = 'scheme-' + this.scheme;
      this.joy = { id: null, x: 0, y: 0, cx: 0, cy: 0, fx: 0, fy: 0 };
      // fwd — ячейка движения, с которой палец съехал на центральный прыжок: движение сохраняется, пока палец на центре
      this.dpad = { id: null, cell: null, lastUp: 0, sprint: false, fwd: null };

      if (this.scheme === 'joystick') {
        const joy = document.createElement('div');
        joy.className = 'joy';
        const knob = document.createElement('div');
        knob.className = 'joy-knob';
        joy.appendChild(knob);
        root.appendChild(joy);
        this.joyEl = joy;
        this.knob = knob;
      } else {
        const pad = document.createElement('div');
        pad.className = 'dpad';
        this.padCells = {};
        // Ячейки 3x3: стрелки, центр — присесть, диагонали появляются при движении вперёд
        for (const [name, cls] of [['upleft', 'd-ul'], ['up', 'd-up'], ['upright', 'd-ur'], ['left', 'd-left'], [this.center, 'd-center' + (this.swap ? ' swapped' : '')], ['right', 'd-right'], ['down', 'd-down']]) {
          const c = document.createElement('div');
          c.className = 'dcell ' + cls;
          pad.appendChild(c);
          this.padCells[name] = c;
        }
        root.appendChild(pad);
        this.padEl = pad;
        pad.addEventListener('touchstart', (e) => this.padStart(e), { passive: false });
        pad.addEventListener('touchmove', (e) => this.padMove(e), { passive: false });
        pad.addEventListener('touchend', (e) => this.padEnd(e), { passive: false });
        pad.addEventListener('touchcancel', (e) => this.padEnd(e), { passive: false });
      }

      const mk = (name, cls, label) => {
        const b = document.createElement('div');
        b.className = 'tbtn ' + cls;
        if (label) b.textContent = label;
        root.appendChild(b);
        const state = { el: b, held: false };
        this.touchButtons[name] = state;
        b.addEventListener('touchstart', (e) => {
          e.preventDefault();
          e.stopPropagation();
          state.held = true;
          b.classList.add('down');
          if (name === 'jump') this.jumpLatch = true;
          this.emit('tbtn', name);
        }, { passive: false });
        const up = (e) => { e.preventDefault(); e.stopPropagation(); state.held = false; b.classList.remove('down'); };
        b.addEventListener('touchend', up, { passive: false });
        b.addEventListener('touchcancel', up, { passive: false });
        return state;
      };
      if (this.scheme === 'dpad' && this.swap) mk('sneak', 't-jump swapped');
      else mk('jump', 't-jump');
      if (this.scheme === 'joystick') mk('sneak', 't-sneak');
      mk('flyup', 't-flyup');
      mk('flydown', 't-flydown');
      mk('view', 't-view');
      mk('gm', 't-gm', '⛏');
      mk('hitbox', 't-hb', '▣');
      mk('eb', 't-eb', '⚒');
      mk('undo', 't-undo', '↶');
      mk('redo', 't-redo', '↷');
      mk('zoom', 't-zoom', '🔍');
      mk('flook', 't-flook', '👁');
      mk('chat', 't-chat');
      mk('pause', 't-pause');
      mk('inv', 't-inv', '•••');
      this.setFlyingButtons(!!this.flyingShown);

      if (!this.rootBound) {
        this.rootBound = true;
        root.addEventListener('touchstart', (e) => this.touchStart(e), { passive: false });
        root.addEventListener('touchmove', (e) => this.touchMove(e), { passive: false });
        root.addEventListener('touchend', (e) => this.touchEnd(e), { passive: false });
        root.addEventListener('touchcancel', (e) => this.touchEnd(e), { passive: false });
      }
    }

    // Ячейка крестовины под пальцем (палец можно вести с кнопки на кнопку, как в MCPE)
    padCellAt(t) {
      const r = this.padEl.getBoundingClientRect();
      const col = Math.floor((t.clientX - r.left) / (r.width / 3));
      const row = Math.floor((t.clientY - r.top) / (r.height / 3));
      if (col < 0 || col > 2 || row < 0 || row > 2) return null;
      return [['upleft', 'up', 'upright'], ['left', this.center, 'right'], [null, 'down', null]][row][col];
    }

    setPadCell(cell) {
      const d = this.dpad;
      if (d.cell === cell) return;
      if (cell === 'up' && d.cell !== 'upleft' && d.cell !== 'upright') {
        // Двойное касание «вперёд» — бег
        const now = performance.now();
        d.sprint = now - d.lastUp < 300;
        d.lastUp = now;
      }
      if (cell === this.center && d.cell === null) this.emit('tbtn', this.center);
      if (cell === 'jump') {
        this.jumpLatch = true;
        // Палец съехал с кнопки движения на прыжок: идём дальше и прыгаем (как в Minecraft PE)
        d.fwd = d.cell && d.cell !== 'jump' ? d.cell : null;
      } else {
        d.fwd = null;
      }
      d.cell = cell;
      for (const [name, c] of Object.entries(this.padCells)) c.classList.toggle('down', name === cell);
      const f = cell === 'jump' && d.fwd ? d.fwd : cell;
      this.padEl.classList.toggle('fwd', f === 'up' || f === 'upleft' || f === 'upright');
    }

    padStart(e) {
      e.preventDefault();
      e.stopPropagation();
      if (!this.enabled) return;
      for (const t of e.changedTouches) {
        if (this.dpad.id !== null) continue;
        const cell = this.padCellAt(t);
        // Диагонали работают, только пока идёт движение вперёд
        if (cell === 'upleft' || cell === 'upright' || !cell) continue;
        this.dpad.id = t.identifier;
        this.dpad.cell = null;
        this.setPadCell(cell);
      }
    }

    padMove(e) {
      e.preventDefault();
      e.stopPropagation();
      for (const t of e.changedTouches) {
        if (t.identifier !== this.dpad.id) continue;
        const cell = this.padCellAt(t);
        // На присед пальцем не съезжают (случайный присед мешает), а на прыжок — можно
        if (cell === 'sneak') continue;
        if ((cell === 'upleft' || cell === 'upright') && !this.padEl.classList.contains('fwd')) continue;
        this.setPadCell(cell);
      }
    }

    padEnd(e) {
      e.preventDefault();
      e.stopPropagation();
      for (const t of e.changedTouches) {
        if (t.identifier !== this.dpad.id) continue;
        this.dpad.id = null;
        this.dpad.sprint = false;
        this.setPadCell(null);
      }
    }

    // Панель предметов лежит под слоем кнопок, поэтому касание по ней ловим здесь по координатам
    hotbarHit(t) {
      const hb = document.querySelector('.hotbar');
      if (!hb) return -1;
      const r = hb.getBoundingClientRect();
      if (!r.width || t.clientX < r.left || t.clientX > r.right || t.clientY < r.top - 4 || t.clientY > r.bottom + 4) return -1;
      return Math.max(0, Math.min(8, Math.floor((t.clientX - r.left) / (r.width / 9))));
    }

    touchStart(e) {
      if (!this.enabled) return;
      e.preventDefault();
      for (const t of e.changedTouches) {
        const w = window.innerWidth;
        const hb = this.hotbarHit(t);
        if (hb >= 0) { this.emit('hotbar', hb); continue; }
        if (this.scheme === 'joystick' && t.clientX < w * 0.4 && this.joy.id === null) {
          const r = this.joyEl.getBoundingClientRect();
          this.joy.id = t.identifier;
          // Двойное касание джойстика — бег
          this.joySprint = performance.now() - this.joyLastEnd < 350;
          this.joy.cx = r.left + r.width / 2;
          this.joy.cy = r.top + r.height / 2;
          this.updateJoy(t);
        } else if (!this.lookTouch) {
          this.lookTouch = { id: t.identifier, x: t.clientX, y: t.clientY, sx: t.clientX, sy: t.clientY, start: performance.now(), moved: 0, holding: false };
          const lt = this.lookTouch;
          lt.timer = setTimeout(() => {
            if (this.lookTouch === lt && lt.moved < 14) {
              lt.holding = true;
              this.attackHeld = true;
              this.attackPressed = true;
            }
          }, 280);
        }
      }
    }

    touchMove(e) {
      if (!this.enabled) return;
      e.preventDefault();
      for (const t of e.changedTouches) {
        if (t.identifier === this.joy.id) this.updateJoy(t);
        else if (this.lookTouch && t.identifier === this.lookTouch.id) {
          const lt = this.lookTouch;
          const dx = t.clientX - lt.x, dy = t.clientY - lt.y;
          lt.moved += Math.abs(dx) + Math.abs(dy);
          lt.x = t.clientX;
          lt.y = t.clientY;
          // Пока палец удерживается для ломания, дрожание пальца не крутит камеру (иначе прицел уезжает на соседний блок и ломание начинается заново)
          if (lt.holding) {
            lt.holdMoved = (lt.holdMoved || 0) + Math.abs(dx) + Math.abs(dy);
            if (lt.holdMoved < 28) continue;
          }
          this.lookDX += dx * 2.2;
          this.lookDY += dy * 2.2;
        }
      }
    }

    touchEnd(e) {
      for (const t of e.changedTouches) {
        if (t.identifier === this.joy.id) {
          this.joy.id = null;
          this.joyLastEnd = performance.now();
          this.joySprint = false;
          this.joy.fx = this.joy.fy = 0;
          this.knob.style.transform = 'translate(-50%, -50%)';
        } else if (this.lookTouch && t.identifier === this.lookTouch.id) {
          const lt = this.lookTouch;
          clearTimeout(lt.timer);
          if (!lt.holding && lt.moved < 14 && performance.now() - lt.start < 280) {
            // Короткое касание: атака существа или использование/установка блока
            this.usePressed = true;
            this.tapPressed = true;
            this.clicksL.push(performance.now());
          }
          if (lt.holding) this.attackHeld = false;
          this.lookTouch = null;
        }
      }
    }

    updateJoy(t) {
      const max = this.joyEl.getBoundingClientRect().width * 0.4;
      let dx = t.clientX - this.joy.cx, dy = t.clientY - this.joy.cy;
      const l = Math.hypot(dx, dy);
      if (l > max) { dx = dx / l * max; dy = dy / l * max; }
      this.joy.fx = dx / max;
      this.joy.fy = dy / max;
      this.knob.style.transform = 'translate(calc(-50% + ' + dx + 'px), calc(-50% + ' + dy + 'px))';
    }

    setFlyingButtons(flying) {
      this.flyingShown = flying;
      const tb = this.touchButtons;
      tb.flyup.el.style.display = flying ? 'block' : 'none';
      tb.flydown.el.style.display = flying ? 'block' : 'none';
      if (tb.jump) tb.jump.el.style.display = flying ? 'none' : 'block';
      if (tb.sneak) tb.sneak.el.style.display = flying ? 'none' : 'block';
    }

    move() {
      const k = this.keys;
      let forward = (k.has('KeyW') || k.has('ArrowUp') ? 1 : 0) - (k.has('KeyS') || k.has('ArrowDown') ? 1 : 0);
      let strafe = (k.has('KeyD') || k.has('ArrowRight') ? 1 : 0) - (k.has('KeyA') || k.has('ArrowLeft') ? 1 : 0);
      let jump = k.has('Space');
      let sneak = k.has('ShiftLeft') || k.has('ShiftRight');
      let sprint = k.has('ControlLeft') || k.has('ControlRight');
      if (this.touchMode) {
        if (this.scheme === 'joystick' && this.joy.id !== null) {
          forward = -this.joy.fy;
          strafe = this.joy.fx;
          if (this.joySprint && forward > 0.5) sprint = true;
        }
        if (this.scheme === 'dpad' && this.dpad.cell) {
          const c = this.dpad.cell === 'jump' && this.dpad.fwd ? this.dpad.fwd : this.dpad.cell;
          forward = c === 'up' || c === 'upleft' || c === 'upright' ? 1 : c === 'down' ? -1 : 0;
          strafe = c === 'right' || c === 'upright' ? 1 : c === 'left' || c === 'upleft' ? -1 : 0;
          if (this.dpad.sprint && forward > 0) sprint = true;
        }
        if (this.padCells && this.padCells.sneak) this.padCells.sneak.classList.toggle('on', this.sneakToggle);
        if (this.touchButtons.sneak) this.touchButtons.sneak.el.classList.toggle('on', this.sneakToggle);
        const tb = this.touchButtons;
        // Короткое касание прыжка не должно теряться между кадрами
        jump = jump || this.jumpLatch || (tb.jump && tb.jump.held) || tb.flyup.held || (this.scheme === 'dpad' && this.dpad.cell === 'jump');
        this.jumpLatch = false;
        sneak = sneak || this.sneakToggle || tb.flydown.held;
      }
      return { forward, strafe, jump, sneak, sprint, autoJump: this.touchMode && this.settings.autoJump };
    }

    consumeLook() {
      const s = this.settings.sensitivity * 0.15;
      const r = { dx: this.lookDX * s, dy: this.lookDY * s * (this.settings.invertY ? -1 : 1) };
      this.lookDX = 0;
      this.lookDY = 0;
      return r;
    }

    // Зум: C (как в OptiFine) или кнопка 🔍; свободный обзор: левый Alt или кнопка 👁 (удерживать)
    zoomHeld() { return this.keys.has('KeyC') || !!(this.touchButtons.zoom && this.touchButtons.zoom.held); }
    freelookHeld() { return this.keys.has('AltLeft') || !!(this.touchButtons.flook && this.touchButtons.flook.held); }

    consumeUse() { const v = this.usePressed; this.usePressed = false; return v; }
    consumeAttack() { const v = this.attackPressed; this.attackPressed = false; return v; }
    consumeTap() { const v = this.tapPressed; this.tapPressed = false; return v; }
  }

  MC.Input = Input;
})();
