// Better PvP (своя реализация для MCPE 1.1): миникарта, точки маршрута и точка смерти, броня и прочность,
// эффекты с таймерами, панель цели, комбо, подсказка крита, предупреждение о низком здоровье
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const A = window.MC_ASSETS;

  const DEF = {
    minimap: true, mapSize: 128, mapZoom: 2, mapRotate: true, mapEntities: true,
    waypoints: true, deathPoint: true, armorHud: true, effects: true, lowHp: true,
    targetHud: true, combo: true, crit: true, aimSlow: true,
    // Как в Lunar/Badlion: клавиши на экране, CPS, зум, динамический FOV, наклон камеры от удара, стили прицела
    keystrokes: 'auto', cps: true, zoom: 4, smoothZoom: true, dynamicFov: true, hurtCam: true,
    crosshair: 'circle', crossColor: 'white', outline: 'black'
  };
  const CROSS_COLORS = { white: '#ffffff', green: '#55ff55', red: '#ff5555', cyan: '#55ffff', yellow: '#ffff55', pink: '#ff77ff' };
  const OUTLINES = { black: [0, 0, 0, 0.6], white: [1, 1, 1, 0.8], red: [1, 0.25, 0.25, 0.9], cyan: [0.3, 1, 1, 0.9], green: [0.35, 1, 0.35, 0.9] };

  const EFFECTS = {
    1: 'Скорость', 2: 'Замедление', 3: 'Спешка', 4: 'Усталость', 5: 'Сила', 6: 'Исцеление', 7: 'Вред', 8: 'Прыгучесть',
    9: 'Тошнота', 10: 'Регенерация', 11: 'Сопротивление', 12: 'Огнестойкость', 13: 'Подводное дыхание', 14: 'Невидимость',
    15: 'Слепота', 16: 'Ночное зрение', 17: 'Голод', 18: 'Слабость', 19: 'Отравление', 20: 'Иссушение', 21: 'Прилив здоровья',
    22: 'Поглощение', 23: 'Насыщение', 24: 'Левитация', 25: 'Сильный яд'
  };
  const BAD = new Set([2, 4, 7, 9, 15, 17, 18, 19, 20, 25]);
  const ROMAN = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];
  const WP_COLORS = ['#ff5555', '#55ff55', '#5599ff', '#ffff55', '#ff55ff', '#55ffff', '#ffaa00', '#ffffff'];
  // Тонировка травы, листвы и воды, если в атласе они серые
  const TINT = { 2: [0.55, 0.78, 0.35], 18: [0.45, 0.68, 0.3], 161: [0.45, 0.68, 0.3], 31: [0.55, 0.78, 0.35], 106: [0.45, 0.68, 0.3], 111: [0.4, 0.65, 0.3], 8: [0.25, 0.42, 0.9], 9: [0.25, 0.42, 0.9] };

  function settings(st) {
    st.pvp = Object.assign({}, DEF, st.pvp || {});
    return st.pvp;
  }

  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  };

  // Средний цвет верхней грани каждого блока (id, data) из атласа текущего ресурс-пака
  let colors = null, colorsLoading = null;
  function loadColors() {
    if (colors || colorsLoading) return colorsLoading;
    colorsLoading = new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const cv = document.createElement('canvas');
        cv.width = img.width; cv.height = img.height;
        const ctx = cv.getContext('2d');
        ctx.drawImage(img, 0, 0);
        const px = ctx.getImageData(0, 0, img.width, img.height).data;
        const grid = A.blockGrid, ts = img.width / grid;
        const tileColor = new Map();
        const avg = (tile) => {
          if (tileColor.has(tile)) return tileColor.get(tile);
          const tx = (tile % grid) * ts, ty = Math.floor(tile / grid) * ts;
          let r = 0, g = 0, b = 0, n = 0;
          for (let y = 0; y < ts; y++) for (let x = 0; x < ts; x++) {
            const i = ((ty + y) * img.width + tx + x) * 4;
            if (px[i + 3] < 40) continue;
            r += px[i]; g += px[i + 1]; b += px[i + 2]; n++;
          }
          const c = n ? [r / n, g / n, b / n] : null;
          tileColor.set(tile, c);
          return c;
        };
        colors = new Uint8Array(256 * 16 * 4);
        for (let id = 1; id < 256; id++) {
          const bl = MC.Blocks.list[id];
          if (!bl) continue;
          for (let d = 0; d < 16; d++) {
            let c;
            try { c = avg(bl.tex(d, 1)); } catch (e) { c = null; }
            if (!c) continue;
            const t = TINT[id];
            if (t && Math.abs(c[0] - c[1]) < 12 && Math.abs(c[1] - c[2]) < 12) c = [c[0] * t[0] * 1.3, c[1] * t[1] * 1.3, c[2] * t[2] * 1.3];
            const o = (id * 16 + d) * 4;
            colors[o] = Math.min(255, c[0]); colors[o + 1] = Math.min(255, c[1]); colors[o + 2] = Math.min(255, c[2]); colors[o + 3] = 255;
          }
        }
        resolve();
      };
      img.onerror = () => resolve();
      img.src = A.blockAtlas;
    });
    return colorsLoading;
  }

  class PvP {
    constructor(game) {
      this.g = game;
      this.cfg = settings(game.app.settings);
      this.tiles = new Map();
      this.dirtyTiles = new Set();
      this.mapT = 0;
      this.waypoints = [];
      this.wpKey = '';
      this.effects = new Map();
      this.target = null;
      this.combo = 0;
      this.comboT = 0;
      this.lastHitEid = null;
      this.lastHitT = 0;
      this.pendingHit = null;
      this.slow = false;
      this.root = null;
      game.world.onSectionDirty((cx, sy, cz) => { if (this.tiles.has(cx + ',' + cz)) this.dirtyTiles.add(cx + ',' + cz); });
      loadColors();
    }

    save() { MC.Storage.saveSettings(this.g.app.settings); }

    // Новый мир на сервере (смена измерения или лобби): старые плитки карты не годятся
    resetMap() {
      this.tiles.clear();
      this.dirtyTiles.clear();
      this.mapT = 0;
      this.target = null;
      this.lastHitEid = null;
      this.pendingHit = null;
      this.effects.clear();
    }

    // ---------- Точки маршрута ----------
    storeKey() {
      const g = this.g;
      if (g.mode === 'sp') return 'waypoints:w:' + g.record.id;
      const s = g.opts.server;
      return 'waypoints:s:' + s.host + ':' + s.port;
    }

    async loadWaypoints() {
      this.wpKey = this.storeKey();
      try {
        const v = await MC.Storage.kv.get(this.wpKey);
        this.waypoints = Array.isArray(v) ? v : [];
      } catch (e) {
        this.waypoints = [];
      }
    }

    saveWaypoints() {
      if (!this.wpKey) return;
      MC.Storage.kv.put(this.wpKey, this.waypoints).catch((e) => console.warn('Точки маршрута', e));
    }

    addWaypoint(name, death) {
      const p = this.g.player;
      if (death) this.waypoints = this.waypoints.filter((w) => !w.death);
      const wp = {
        name: name || 'Точка ' + (this.waypoints.filter((w) => !w.death).length + 1),
        x: Math.floor(p.x), y: Math.floor(p.y), z: Math.floor(p.z),
        color: death ? '#ff3333' : WP_COLORS[this.waypoints.length % WP_COLORS.length],
        death: !!death, on: true
      };
      this.waypoints.push(wp);
      this.saveWaypoints();
      return wp;
    }

    removeWaypoint(i) {
      this.waypoints.splice(i, 1);
      this.saveWaypoints();
    }

    onDeath() {
      if (this.cfg.deathPoint) this.addWaypoint('Смерть', true);
      this.combo = 0;
    }

    // ---------- Бой ----------
    onAttack(eid) {
      const now = performance.now();
      this.lastHitEid = eid;
      this.lastHitT = now;
      if (this.g.mode === 'mp') this.pendingHit = { eid, t: now };
    }

    // Подтверждённое попадание: в одиночной игре — сразу, на сервере — по событию «ранен» у цели
    onHitConfirmed(eid, crit) {
      const now = performance.now();
      if (now - this.comboT > 3000) this.combo = 0;
      this.combo++;
      this.comboT = now;
      this.hitFlash = now;
      this.critFlash = crit ? now : this.critFlash;
      this.lastHitEid = eid;
      this.lastHitT = now;
    }

    onEntityEvent(eid, ev) {
      if (ev === 2 && this.pendingHit && this.pendingHit.eid === eid && performance.now() - this.pendingHit.t < 600) {
        const p = this.g.player;
        this.onHitConfirmed(eid, !p.onGround && p.vy < 0);
        this.pendingHit = null;
      }
    }

    onHurt() { this.combo = 0; this.g.hurtCam = 1; }

    // Цвет обводки блока под прицелом для renderer (переливается при «радуга»)
    outlineColor() {
      if (this.cfg.outline === 'rainbow') {
        const h = (performance.now() / 12) % 360 / 60, x = 1 - Math.abs(h % 2 - 1);
        const rgb = h < 1 ? [1, x, 0] : h < 2 ? [x, 1, 0] : h < 3 ? [0, 1, x] : h < 4 ? [0, x, 1] : h < 5 ? [x, 0, 1] : [1, 0, x];
        return [rgb[0], rgb[1], rgb[2], 0.95];
      }
      return OUTLINES[this.cfg.outline] || OUTLINES.black;
    }

    // Клавиши на экране: W A S D, пробел, ЛКМ/ПКМ с CPS
    updateKeys() {
      const c = this.cfg, g = this.g, inp = g.input;
      const show = c.keystrokes === 'on' || (c.keystrokes === 'auto' && !inp.touchMode);
      this.keysBox.style.display = show ? '' : 'none';
      const now = performance.now();
      const L = inp.clicksL, R = inp.clicksR;
      while (L.length && now - L[0] > 1000) L.shift();
      while (R.length && now - R[0] > 1000) R.shift();
      const cpsText = c.cps ? 'CPS ' + L.length + (inp.touchMode ? '' : ' | ' + R.length) : '';
      if (this.cpsBox.textContent !== cpsText) this.cpsBox.textContent = cpsText;
      this.cpsBox.style.display = cpsText && !show ? '' : 'none';
      if (!show) return;
      const mv = g.lastMove || { forward: 0, strafe: 0, jump: false };
      const k = this.keyEls;
      k.w.classList.toggle('on', mv.forward > 0.3);
      k.s.classList.toggle('on', mv.forward < -0.3);
      k.a.classList.toggle('on', mv.strafe < -0.3);
      k.d.classList.toggle('on', mv.strafe > 0.3);
      k.jump.classList.toggle('on', !!mv.jump);
      k.l.classList.toggle('on', !!inp.attackHeld || now - (L[L.length - 1] || 0) < 90);
      k.r.classList.toggle('on', !!inp.useHeld || now - (R[R.length - 1] || 0) < 90);
      const lt = 'ЛКМ\n' + L.length + ' CPS', rt = 'ПКМ\n' + R.length + ' CPS';
      if (k.l.textContent !== lt) k.l.textContent = lt;
      if (k.r.textContent !== rt) k.r.textContent = rt;
    }

    // Стиль и цвет прицела
    applyCrosshair() {
      const cross = this.g.ui.hCross;
      if (!cross) return;
      const key = this.cfg.crosshair + ':' + this.cfg.crossColor;
      if (this.crossKey === key && cross.dataset.style) return;
      this.crossKey = key;
      cross.dataset.style = this.cfg.crosshair;
      cross.style.setProperty('--cross', CROSS_COLORS[this.cfg.crossColor] || '#ffffff');
    }

    onMobEffect(m) {
      if (m.ev === 3) this.effects.delete(m.id);
      else this.effects.set(m.id, { amp: m.amp, end: performance.now() + m.dur * 50 });
    }

    // Цель, по которой недавно попали, остаётся в прицеле, пока она рядом с перекрестием
    sticky(list, ent, cone) {
      if (ent || !this.lastHitEid || performance.now() - this.lastHitT > 1500) return ent;
      const p = this.g.player, d = p.lookDir();
      const e = list.find((x) => x.eid === this.lastHitEid);
      if (!e) return ent;
      const vx = e.x - p.x, vy = e.y + e.h / 2 - p.eyeY, vz = e.z - p.z;
      const len = Math.hypot(vx, vy, vz);
      if (len > 3.5 || len < 0.1) return ent;
      const cos = (vx * d[0] + vy * d[1] + vz * d[2]) / len;
      return cos > cone - 0.04 ? { eid: e.eid, t: len } : ent;
    }

    entityInfo(eid) {
      const g = this.g;
      if (g.mode === 'sp') {
        const m = g.ents.list.get(eid);
        if (!m || m.kind !== 'mob') return null;
        const look = MC.ENTITY_LOOK[m.type];
        return { name: look ? look[0] : 'Существо', x: m.body.x, y: m.body.y, z: m.body.z, hp: Math.max(0, m.hp), max: m.def.hp };
      }
      const e = g.entities.get(eid);
      if (!e) return null;
      const look = MC.ENTITY_LOOK[e.type];
      // Сервер MCPE 1.1 не присылает здоровье других игроков; показываем их снаряжение — по нему видно силу
      const gear = e.kind === 'player' ? [...(e.armor || []), e.held].filter((it) => it && it.id) : [];
      const name = e.kind === 'player' ? e.name : e.nametag ? e.nametag.split('\n')[0] : look ? look[0] : 'Существо';
      return { name, x: e.x, y: e.y, z: e.z, hp: null, gear };
    }

    // ---------- HUD ----------
    ensureDom() {
      const hud = this.g.ui.hud;
      if (this.root && this.root.parentNode === hud) return;
      this.root = el('div', 'pvp');
      this.vig = el('div', 'pvp-vig');
      this.root.appendChild(this.vig);
      this.wpTags = el('div', 'pvp-wps');
      this.root.appendChild(this.wpTags);
      this.mapBox = el('div', 'pvp-map');
      this.map = el('canvas');
      this.mapBox.appendChild(this.map);
      this.mapInfo = el('div', 'pvp-mapinfo');
      this.mapBox.appendChild(this.mapInfo);
      // Касание миникарты меняет масштаб
      const zoom = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.cfg.mapZoom = this.cfg.mapZoom >= 4 ? 1 : this.cfg.mapZoom * 2;
        this.save();
        this.mapT = 0;
      };
      this.mapBox.addEventListener('touchstart', zoom, { passive: false });
      this.mapBox.addEventListener('mousedown', zoom);
      // Справа сверху, под кнопками: слева миникарту закрывал чат (на серверах он почти всегда полон)
      this.right = el('div', 'pvp-right');
      this.root.appendChild(this.right);
      this.right.appendChild(this.mapBox);
      this.armorBox = el('div', 'pvp-armor');
      this.right.appendChild(this.armorBox);
      this.fxBox = el('div', 'pvp-fx');
      this.root.appendChild(this.fxBox);
      this.targetBox = el('div', 'pvp-target');
      this.root.appendChild(this.targetBox);
      this.comboBox = el('div', 'pvp-combo');
      this.root.appendChild(this.comboBox);
      this.keysBox = el('div', 'pvp-keys');
      this.keyEls = {};
      for (const [k, t] of [['w', 'W'], ['a', 'A'], ['s', 'S'], ['d', 'D'], ['l', ''], ['r', ''], ['jump', '———']]) {
        this.keyEls[k] = el('div', 'pvp-key k-' + k, t);
        this.keysBox.appendChild(this.keyEls[k]);
      }
      this.root.appendChild(this.keysBox);
      this.cpsBox = el('div', 'pvp-cps');
      this.root.appendChild(this.cpsBox);
      this.crossKey = null;
      hud.insertBefore(this.root, hud.firstChild.nextSibling);
      this.armorKey = this.fxKey = this.targetKey = null;
    }

    update(dt, ent) {
      const g = this.g, c = this.cfg, p = g.player, now = performance.now();
      this.ensureDom();
      this.slow = !!(c.aimSlow && ent && g.input.touchMode);
      if (this.pendingHit && now - this.pendingHit.t > 600) this.pendingHit = null;
      // Цель: под прицелом или та, по которой попали за последние 3 секунды
      let tid = ent ? ent.eid : null;
      if (tid === null && this.lastHitEid !== null && now - this.lastHitT < 3000) tid = this.lastHitEid;
      this.updateTarget(tid);
      if (now - this.comboT > 3000) this.combo = 0;
      const comboText = c.combo && this.combo >= 2 ? 'Комбо ×' + this.combo : '';
      if (this.comboBox.textContent !== comboText) this.comboBox.textContent = comboText;
      const cross = g.ui.hCross;
      if (cross) {
        cross.classList.toggle('crit', !!(c.crit && ent && !p.onGround && p.vy < 0 && !p.inWater && !p.flying));
        cross.classList.toggle('hitm', !!(this.hitFlash && now - this.hitFlash < 150));
      }
      const lowHp = c.lowHp && g.survival() && !g.dead && g.health <= 6;
      this.vig.style.opacity = lowHp ? String(0.35 + 0.25 * (1 - g.health / 6) + 0.15 * Math.sin(now / 200)) : '0';
      this.updateArmor();
      this.updateEffects(now);
      this.updateKeys();
      this.applyCrosshair();
      this.mapBox.style.display = c.minimap ? '' : 'none';
      if (c.minimap) {
        this.mapT -= dt;
        if (this.mapT <= 0) { this.mapT = 0.1; this.drawMap(); }
      }
    }

    updateTarget(eid) {
      const c = this.cfg;
      const info = c.targetHud && eid !== null ? this.entityInfo(eid) : null;
      if (!info) {
        if (this.targetKey !== '') { this.targetKey = ''; this.targetBox.innerHTML = ''; this.targetBox.style.display = 'none'; }
        return;
      }
      const p = this.g.player;
      const dist = Math.hypot(info.x - p.x, info.y - p.y, info.z - p.z);
      const gearKey = (info.gear || []).map((it) => it.id + '.' + (it.nbt ? it.nbt.length : 0)).join(',');
      const key = info.name + ':' + dist.toFixed(1) + ':' + info.hp + ':' + gearKey;
      if (key === this.targetKey) return;
      this.targetKey = key;
      this.targetBox.style.display = '';
      this.targetBox.innerHTML = '';
      const n = el('div', 'pvp-tname');
      n.appendChild(MC.formatted ? MC.formatted(info.name) : document.createTextNode(info.name));
      this.targetBox.appendChild(n);
      this.targetBox.appendChild(el('div', 'pvp-tdist', dist.toFixed(1) + ' м' + (dist > 3.5 ? ' — далеко для удара' : '')));
      if (info.gear && info.gear.length) {
        const row = el('div', 'pvp-tgear');
        for (const it of info.gear) {
          const cell = el('div', 'pvp-tgi');
          const img = el('img');
          img.src = MC.Items.icon(it.id, MC.Survival.isTool(it.id) ? 0 : it.data);
          img.alt = '';
          cell.appendChild(img);
          MC.Items.addGlint(cell, it, img.src);
          row.appendChild(cell);
        }
        this.targetBox.appendChild(row);
      }
      if (info.hp !== null) {
        const bar = el('div', 'pvp-tbar');
        const fill = el('div', 'pvp-tfill');
        const k = Math.max(0, Math.min(1, info.hp / info.max));
        fill.style.width = Math.round(k * 100) + '%';
        fill.style.background = 'hsl(' + Math.round(k * 120) + ', 85%, 45%)';
        bar.appendChild(fill);
        this.targetBox.appendChild(bar);
        this.targetBox.appendChild(el('div', 'pvp-thp', '❤ ' + Math.ceil(info.hp) + ' / ' + info.max));
      }
    }

    updateArmor() {
      const g = this.g, c = this.cfg;
      const items = c.armorHud ? [...(g.armor || []), g.heldItem()].filter((it) => it && it.id) : [];
      const key = items.map((it) => it.id + ':' + it.data + ':' + (it.count || 1)).join('|');
      if (key === this.armorKey) return;
      this.armorKey = key;
      this.armorBox.innerHTML = '';
      for (const it of items) {
        const max = MC.Survival.durabilityOf(it.id);
        if (!max && it !== items[items.length - 1]) continue;
        const row = el('div', 'pvp-arow');
        const img = el('img');
        img.src = MC.Items.icon(it.id, max ? 0 : it.data);
        img.alt = '';
        row.appendChild(img);
        if (max) {
          const left = Math.max(0, max - (it.data || 0));
          const s = el('span', null, left + '/' + max);
          s.style.color = 'hsl(' + Math.round(left / max * 120) + ', 90%, 60%)';
          row.appendChild(s);
        } else if ((it.count || 1) > 1) {
          // Для блоков и еды в руке показываем, сколько всего таких на панели
          let n = 0;
          for (const h of g.hotbarItems()) if (h && h.id === it.id && h.data === it.data) n += h.count || 1;
          row.appendChild(el('span', null, '×' + n));
        }
        this.armorBox.appendChild(row);
      }
    }

    updateEffects(now) {
      const g = this.g, c = this.cfg;
      const list = [];
      if (c.effects) {
        if (g.mode === 'sp') {
          const fx = g.fx;
          if (fx.regen > 0) list.push([10, 1, fx.regen]);
          if (fx.absorbT > 0 && fx.absorb > 0) list.push([22, 0, fx.absorbT]);
          if (fx.fireRes > 0) list.push([12, 0, fx.fireRes]);
        } else {
          for (const [id, e] of this.effects) {
            const left = (e.end - now) / 1000;
            if (left <= 0) { this.effects.delete(id); continue; }
            list.push([id, e.amp, left]);
          }
        }
      }
      const key = list.map((e) => e[0] + ':' + e[1] + ':' + Math.ceil(e[2])).join('|');
      if (key === this.fxKey) return;
      this.fxKey = key;
      this.fxBox.innerHTML = '';
      for (const [id, amp, left] of list) {
        const s = Math.ceil(left);
        const t = left > 3600 * 24 ? '∞' : Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
        const row = el('div', 'pvp-fxrow' + (BAD.has(id) ? ' bad' : ''), (EFFECTS[id] || 'Эффект ' + id) + (amp > 0 ? ' ' + (ROMAN[amp + 1] || amp + 1) : '') + ' · ' + t);
        this.fxBox.appendChild(row);
      }
    }

    // ---------- Миникарта ----------
    tile(cx, cz) {
      const k = cx + ',' + cz;
      let t = this.tiles.get(k);
      if (t && !this.dirtyTiles.has(k)) return t;
      const ch = this.g.world.getChunk(cx, cz);
      if (!ch || !colors) return t || null;
      if (this.budget <= 0) return t || null;
      this.budget--;
      this.dirtyTiles.delete(k);
      if (!t) {
        const cv = document.createElement('canvas');
        cv.width = cv.height = 16;
        t = { cv, ctx: cv.getContext('2d'), img: null };
        t.img = t.ctx.createImageData(16, 16);
        this.tiles.set(k, t);
      }
      const d = t.img.data;
      const hs = new Int16Array(256);
      for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) hs[(z << 4) | x] = ch.height[(z << 4) | x] - 1;
      for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
        const o = ((z << 4) | x) * 4;
        let y = hs[(z << 4) | x];
        let id = y >= 0 ? ch.getId(x, y, z) : 0;
        // Снег и трава сверху столбца не блокируют свет: смотрим на блок над высотой
        const above = y + 1 <= 255 ? ch.getId(x, y + 1, z) : 0;
        if (above === 78 || above === 171) { id = above; y++; }
        if (!id) { d[o] = d[o + 1] = d[o + 2] = 0; d[o + 3] = 0; continue; }
        const ci = (id * 16 + (ch.getData(x, y, z) & 15)) * 4;
        let r = colors[ci], g = colors[ci + 1], b = colors[ci + 2];
        if (!colors[ci + 3]) { const c0 = id * 64; r = colors[c0]; g = colors[c0 + 1]; b = colors[c0 + 2]; }
        // Тень по высоте: склон к северу темнее, к югу светлее
        const hn = z > 0 ? hs[((z - 1) << 4) | x] : y;
        let k = 1 + Math.max(-0.25, Math.min(0.25, (y - hn) * 0.08));
        if (id === 8 || id === 9) {
          // Глубина воды
          let depth = 0;
          for (let yy = y - 1; yy > 0 && depth < 12; yy--) { const w = ch.getId(x, yy, z); if (w !== 8 && w !== 9) break; depth++; }
          k = 1 - depth * 0.035;
        }
        d[o] = Math.min(255, r * k); d[o + 1] = Math.min(255, g * k); d[o + 2] = Math.min(255, b * k); d[o + 3] = 255;
      }
      t.ctx.putImageData(t.img, 0, 0);
      return t;
    }

    drawMap() {
      const g = this.g, c = this.cfg, p = g.player;
      // На низком экране телефона карта не больше трети высоты
      const size = Math.round(Math.max(64, Math.min(220, c.mapSize | 0, window.innerHeight * 0.34)));
      const cv = this.map;
      if (cv.width !== size) { cv.width = cv.height = size; this.mapBox.style.width = size + 'px'; }
      const ctx = cv.getContext('2d');
      ctx.imageSmoothingEnabled = false;
      ctx.fillStyle = '#111';
      ctx.fillRect(0, 0, size, size);
      const sc = c.mapZoom || 2;
      const rad = Math.ceil(size / sc / 2 * 1.45);
      const yawR = p.yaw * Math.PI / 180;
      ctx.save();
      ctx.translate(size / 2, size / 2);
      if (c.mapRotate) ctx.rotate(Math.PI - yawR);
      ctx.scale(sc, sc);
      ctx.translate(-p.x, -p.z);
      this.budget = 6;
      const cx0 = Math.floor((p.x - rad) / 16), cx1 = Math.floor((p.x + rad) / 16);
      const cz0 = Math.floor((p.z - rad) / 16), cz1 = Math.floor((p.z + rad) / 16);
      // Ближние чанки считаются первыми
      const order = [];
      for (let cx = cx0; cx <= cx1; cx++) for (let cz = cz0; cz <= cz1; cz++) order.push([Math.hypot(cx * 16 + 8 - p.x, cz * 16 + 8 - p.z), cx, cz]);
      order.sort((a, b) => a[0] - b[0]);
      for (const [, cx, cz] of order) {
        const t = this.tile(cx, cz);
        if (t) ctx.drawImage(t.cv, cx * 16, cz * 16);
      }
      const dot = (x, z, col, r) => {
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.arc(x, z, r / sc, 0, Math.PI * 2);
        ctx.fill();
      };
      if (c.mapEntities) {
        const lim = rad * rad;
        if (g.mode === 'sp') {
          for (const m of g.ents.list.values()) {
            if (m.kind !== 'mob' || m.dead) continue;
            const b = m.body;
            if ((b.x - p.x) ** 2 + (b.z - p.z) ** 2 > lim) continue;
            dot(b.x, b.z, m.def.hostile ? '#ff4040' : '#60ff60', 2.5);
          }
        } else {
          for (const e of g.entities.values()) {
            if (e.kind === 'item') continue;
            if ((e.x - p.x) ** 2 + (e.z - p.z) ** 2 > lim) continue;
            const col = e.kind === 'player' ? '#ffffff' : e.type >= 32 && e.type <= 55 ? '#ff4040' : '#60ff60';
            dot(e.x, e.z, col, e.kind === 'player' ? 3.2 : 2.5);
          }
        }
      }
      ctx.restore();
      // Точки маршрута: за краем карты прижимаются к краю
      if (c.waypoints) {
        const rot = c.mapRotate ? Math.PI - yawR : 0;
        const cs = Math.cos(rot), sn = Math.sin(rot);
        for (const w of this.waypoints) {
          if (!w.on) continue;
          const dx = (w.x + 0.5 - p.x) * sc, dz = (w.z + 0.5 - p.z) * sc;
          let sx = dx * cs - dz * sn, sy = dx * sn + dz * cs;
          const m = size / 2 - 5;
          const k = Math.max(Math.abs(sx), Math.abs(sy)) / m;
          if (k > 1) { sx /= k; sy /= k; }
          ctx.fillStyle = w.color;
          ctx.strokeStyle = '#000';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.rect(size / 2 + sx - 3, size / 2 + sy - 3, 6, 6);
          ctx.fill();
          ctx.stroke();
        }
      }
      // Игрок — стрелка в центре
      ctx.save();
      ctx.translate(size / 2, size / 2);
      if (!c.mapRotate) ctx.rotate(yawR - Math.PI);
      ctx.fillStyle = '#fff';
      ctx.strokeStyle = '#000';
      ctx.beginPath();
      ctx.moveTo(0, -6); ctx.lineTo(4.5, 5); ctx.lineTo(0, 2.5); ctx.lineTo(-4.5, 5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
      // Север
      const nx = c.mapRotate ? Math.sin(Math.PI - yawR) * (size / 2 - 8) : 0;
      const ny = c.mapRotate ? -Math.cos(Math.PI - yawR) * (size / 2 - 8) : -(size / 2 - 8);
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#ff5555';
      ctx.fillText('С', size / 2 + nx, size / 2 + ny);
      const dirs = ['Юг', 'Юго-запад', 'Запад', 'Северо-запад', 'Север', 'Северо-восток', 'Восток', 'Юго-восток'];
      const face = dirs[((Math.round(p.yaw / 45) % 8) + 8) % 8];
      const info = Math.floor(p.x) + ' ' + Math.floor(p.y) + ' ' + Math.floor(p.z) + ' · ' + face;
      if (this.mapInfo.textContent !== info) this.mapInfo.textContent = info;
    }

    // Подписи точек маршрута в мире с расстоянием
    drawLabels() {
      const g = this.g, c = this.cfg, p = g.player;
      const seen = new Set();
      if (c.waypoints) {
        this.waypoints.forEach((w, i) => {
          if (!w.on) return;
          const s = g.renderer.project(w.x + 0.5, w.y + 1.8, w.z + 0.5);
          if (!s || s.x < -50 || s.y < -50 || s.x > g.renderer.width + 50 || s.y > g.renderer.height + 50) return;
          const key = String(i);
          seen.add(key);
          let e = this.wpTags.querySelector('[data-k="' + key + '"]');
          if (!e) {
            e = el('div', 'pvp-wp');
            e.dataset.k = key;
            this.wpTags.appendChild(e);
          }
          const text = w.name + ' · ' + Math.round(Math.hypot(w.x + 0.5 - p.x, w.y - p.y, w.z + 0.5 - p.z)) + ' м';
          if (e.textContent !== text) e.textContent = text;
          e.style.borderColor = w.color;
          e.style.transform = 'translate(' + Math.round(s.x) + 'px,' + Math.round(s.y) + 'px) translate(-50%, -100%)';
        });
      }
      for (const e of Array.from(this.wpTags.children)) if (!seen.has(e.dataset.k)) e.remove();
    }
  }

  PvP.OUTLINES = OUTLINES;
  MC.PvP = PvP;
  MC.PvP.settings = settings;
})();
