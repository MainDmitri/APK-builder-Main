// Хранилище мира: чанки 16x256x16 из секций 16x16x16 (формат индексов как в сети MCPE 1.1: x<<8 | z<<4 | y)
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const Blocks = MC.Blocks;

  const key = (cx, cz) => cx + ',' + cz;

  class Chunk {
    constructor(cx, cz, sections) {
      this.cx = cx;
      this.cz = cz;
      this.sections = sections || new Array(16).fill(null);
      this.height = new Uint8Array(256);
      this.modified = false;
      this.recalcHeight();
    }

    getId(x, y, z) {
      const s = this.sections[y >> 4];
      return s ? s.ids[(x << 8) | (z << 4) | (y & 15)] : 0;
    }

    getData(x, y, z) {
      const s = this.sections[y >> 4];
      return s ? s.meta[(x << 8) | (z << 4) | (y & 15)] : 0;
    }

    set(x, y, z, id, data) {
      let s = this.sections[y >> 4];
      if (!s) {
        if (id === 0) return;
        s = this.sections[y >> 4] = { ids: new Uint8Array(4096), meta: new Uint8Array(4096) };
      }
      const i = (x << 8) | (z << 4) | (y & 15);
      s.ids[i] = id;
      s.meta[i] = data & 15;
      s.lit = undefined;
      const hi = (z << 4) | x;
      if (y >= this.height[hi] && blocksLight(id)) this.height[hi] = Math.min(255, y + 1);
      else if (y + 1 === this.height[hi] && !blocksLight(id)) this.recalcColumn(x, z);
    }

    recalcColumn(x, z) {
      let h = 0;
      for (let y = 255; y >= 0; y--) {
        if (blocksLight(this.getId(x, y, z))) { h = y + 1; break; }
      }
      this.height[(z << 4) | x] = h;
    }

    recalcHeight() {
      for (let x = 0; x < 16; x++) for (let z = 0; z < 16; z++) this.recalcColumn(x, z);
    }
  }

  function blocksLight(id) {
    if (id === 0) return false;
    const b = Blocks.list[id];
    return b.opaque || b.layer === 'cutout' && (id === 18 || id === 161) || b.liquid;
  }

  class World {
    constructor() {
      this.chunks = new Map();
      this.listeners = [];
      this.blockListeners = [];
      this.chunkListeners = [];
    }

    // Новый чанк (от сервера или из сохранения)
    onChunkSet(fn) { this.chunkListeners.push(fn); }

    onSectionDirty(fn) { this.listeners.push(fn); }
    dirty(cx, cy, cz) { for (const fn of this.listeners) fn(cx, cy, cz); }
    onBlockSet(fn) { this.blockListeners.push(fn); }

    getChunk(cx, cz) { return this.chunks.get(key(cx, cz)); }

    getId(x, y, z) {
      if (y < 0 || y > 255) return 0;
      const c = this.chunks.get(key(x >> 4, z >> 4));
      return c ? c.getId(x & 15, y, z & 15) : 0;
    }

    getData(x, y, z) {
      if (y < 0 || y > 255) return 0;
      const c = this.chunks.get(key(x >> 4, z >> 4));
      return c ? c.getData(x & 15, y, z & 15) : 0;
    }

    isLoaded(x, z) { return this.chunks.has(key(x >> 4, z >> 4)); }

    height(x, z) {
      const c = this.chunks.get(key(x >> 4, z >> 4));
      return c ? c.height[((z & 15) << 4) | (x & 15)] : 0;
    }

    setBlock(x, y, z, id, data) {
      if (y < 0 || y > 255) return;
      const cx = x >> 4, cz = z >> 4;
      const c = this.chunks.get(key(cx, cz));
      if (!c) return;
      const hi = ((z & 15) << 4) | (x & 15);
      const oldH = c.height[hi];
      const oldId = c.getId(x & 15, y, z & 15);
      c.set(x & 15, y, z & 15, id, data);
      c.modified = true;
      if (this.blockListeners.length) for (const fn of this.blockListeners) fn(x, y, z, id, data);
      const newH = c.height[hi];
      const sy = y >> 4, lx = x & 15, ly = y & 15, lz = z & 15;
      this.dirty(cx, sy, cz);
      if (lx === 0) this.dirty(cx - 1, sy, cz);
      if (lx === 15) this.dirty(cx + 1, sy, cz);
      if (lz === 0) this.dirty(cx, sy, cz - 1);
      if (lz === 15) this.dirty(cx, sy, cz + 1);
      if (ly === 0 && sy > 0) this.dirty(cx, sy - 1, cz);
      if (ly === 15 && sy < 15) this.dirty(cx, sy + 1, cz);
      // Свет от факела/лавы доходит до 15 блоков: при появлении или исчезновении источника,
      // а также если рядом со светом ставят/убирают непрозрачный блок, перестраиваем соседние секции
      const L = Blocks.LIGHT;
      if (L[id] !== L[oldId] || (Blocks.list[id].opaque !== Blocks.list[oldId].opaque && this.nearLight(x, y, z))) {
        for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) for (let ds = -1; ds <= 1; ds++) {
          if (sy + ds >= 0 && sy + ds <= 15) this.dirty(cx + dx, sy + ds, cz + dz);
        }
      }
      // Затенение под навесом зависит от карты высот столбца
      if (oldH !== newH) {
        const lo = Math.min(oldH, newH) >> 4, hiS = Math.max(0, Math.max(oldH, newH) - 1) >> 4;
        for (let s = lo; s <= hiS; s++) {
          if (s === sy) continue;
          this.dirty(cx, s, cz);
          if (lx === 0) this.dirty(cx - 1, s, cz);
          if (lx === 15) this.dirty(cx + 1, s, cz);
          if (lz === 0) this.dirty(cx, s, cz - 1);
          if (lz === 15) this.dirty(cx, s, cz + 1);
        }
      }
    }

    // Есть ли источник света в радиусе 14 блоков (по кэшу секций)
    nearLight(x, y, z) {
      const L = Blocks.LIGHT;
      for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
        const c = this.chunks.get(key((x >> 4) + dx, (z >> 4) + dz));
        if (!c) continue;
        for (let s = Math.max(0, (y - 14) >> 4); s <= Math.min(15, (y + 14) >> 4); s++) {
          const sec = c.sections[s];
          if (!sec) continue;
          if (sec.lit === undefined) { sec.lit = false; for (let i = 0; i < 4096; i++) if (L[sec.ids[i]]) { sec.lit = true; break; } }
          if (sec.lit) return true;
        }
      }
      return false;
    }

    setChunk(chunk) {
      this.chunks.set(key(chunk.cx, chunk.cz), chunk);
      for (const fn of this.chunkListeners) fn(chunk.cx, chunk.cz);
      for (let sy = 0; sy < 16; sy++) {
        this.dirty(chunk.cx, sy, chunk.cz);
        this.dirty(chunk.cx - 1, sy, chunk.cz);
        this.dirty(chunk.cx + 1, sy, chunk.cz);
        this.dirty(chunk.cx, sy, chunk.cz - 1);
        this.dirty(chunk.cx, sy, chunk.cz + 1);
      }
    }

    removeChunk(cx, cz) {
      this.chunks.delete(key(cx, cz));
    }
  }

  // ---------- Генератор мира для одиночной игры ----------
  class Generator {
    constructor(seed) {
      this.seed = seed | 0;
      this.n1 = new MC.Perlin(seed);
      this.n2 = new MC.Perlin(seed + 1);
      this.n3 = new MC.Perlin(seed + 2);
      this.cave = new MC.Perlin(seed + 3);
      this.biome = new MC.Perlin(seed + 4);
      this.SEA = 62;
    }

    heightAt(x, z) {
      const base = this.n1.fbm2(x / 160, z / 160, 4);
      const hills = this.n2.fbm2(x / 60, z / 60, 3);
      const mount = Math.max(0, this.n3.fbm2(x / 300, z / 300, 2)) * 2.2;
      return Math.floor(64 + base * 14 + hills * 6 + mount * mount * 40);
    }

    biomeAt(x, z) {
      const v = this.biome.fbm2(x / 400, z / 400, 2);
      return v > 0.25 ? 'desert' : v < -0.3 ? 'taiga' : 'plains';
    }

    generate(cx, cz) {
      const chunk = new Chunk(cx, cz);
      const set = (x, y, z, id, d) => chunk.set(x, y, z, id, d || 0);
      const H = this.seed;
      for (let x = 0; x < 16; x++) {
        for (let z = 0; z < 16; z++) {
          const wx = cx * 16 + x, wz = cz * 16 + z;
          const h = this.heightAt(wx, wz);
          const biome = this.biomeAt(wx, wz);
          const beach = h <= this.SEA + 1;
          set(x, 0, z, 7);
          for (let y = 1; y <= 3; y++) if (MC.hash3(H, wx, y, wz) < 0.5) set(x, y, z, 7);
          for (let y = 1; y <= h; y++) {
            if (chunk.getId(x, y, z) === 7) continue;
            let id;
            if (y === h) {
              if (biome === 'desert' || beach) id = 12;
              else if (h > 110) id = 1;
              else id = 2;
            } else if (y > h - 4) {
              id = biome === 'desert' || beach ? (y > h - 3 ? 12 : 24) : 3;
            } else {
              id = 1;
              const r = MC.hash3(H + 7, wx, y, wz);
              if (y < 128 && r < 0.012) id = 16;
              else if (y < 64 && r < 0.019) id = 15;
              else if (y < 32 && r < 0.0215) id = 14;
              else if (y < 16 && r < 0.0245) id = 73;
              else if (y < 16 && r < 0.0258) id = 56;
              else if (y < 30 && r < 0.0268) id = 21;
              else if (r > 0.985) id = 13;
            }
            // Пещеры
            if (y > 4 && y < h - 3) {
              const c = this.cave.noise3(wx / 28, y / 18, wz / 28);
              if (c > 0.42) id = y < 11 ? 11 : 0;
            }
            if (id) set(x, y, z, id);
          }
          for (let y = h + 1; y <= this.SEA; y++) set(x, y, z, 9);
          if (h >= this.SEA && h > 105 && biome !== 'desert') set(x, h + 1, z, 78, 0);
          if (biome === 'taiga' && h > this.SEA && chunk.getId(x, h, z) === 2) set(x, h + 1, z, 78, 0);
          // Растительность
          if (h > this.SEA && chunk.getId(x, h, z) === 2 && chunk.getId(x, h + 1, z) === 0) {
            const r = MC.hash3(H + 11, wx, 0, wz);
            if (r < 0.10) set(x, h + 1, z, 31, 1);
            else if (r < 0.112) set(x, h + 1, z, 37);
            else if (r < 0.124) set(x, h + 1, z, 38, Math.floor(MC.hash3(H + 12, wx, 1, wz) * 9));
          }
          if (biome === 'desert' && h > this.SEA && MC.hash3(H + 13, wx, 0, wz) < 0.004) {
            const tall = 1 + Math.floor(MC.hash3(H + 14, wx, 0, wz) * 3);
            for (let y = 1; y <= tall; y++) set(x, h + y, z, 81);
          }
          if (biome === 'desert' && h > this.SEA && MC.hash3(H + 15, wx, 0, wz) > 0.994) set(x, h + 1, z, 32);
        }
      }
      // Деревья, в том числе из соседних чанков, чьи кроны заходят в этот
      for (let tx = cx * 16 - 3; tx < cx * 16 + 19; tx++) {
        for (let tz = cz * 16 - 3; tz < cz * 16 + 19; tz++) {
          const r = MC.hash3(H + 21, tx, 0, tz);
          const biome = this.biomeAt(tx, tz);
          const chance = biome === 'taiga' ? 0.02 : biome === 'plains' ? 0.012 : 0;
          if (r >= chance) continue;
          const h = this.heightAt(tx, tz);
          if (h <= this.SEA + 1 || h > 115) continue;
          if (this.cave.noise3(tx / 28, h / 18, tz / 28) > 0.42) continue;
          const kind = biome === 'taiga' ? 1 : MC.hash3(H + 22, tx, 0, tz) < 0.2 ? 2 : 0;
          this.placeTree(chunk, cx, cz, tx, h + 1, tz, kind, MC.hash3(H + 23, tx, 0, tz));
        }
      }
      chunk.recalcHeight();
      return chunk;
    }

    placeTree(chunk, cx, cz, tx, ty, tz, kind, r) {
      const put = (x, y, z, id, d, onlyAir) => {
        const lx = x - cx * 16, lz = z - cz * 16;
        if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 0 || y > 255) return;
        if (onlyAir) {
          const cur = chunk.getId(lx, y, lz);
          if (cur !== 0 && cur !== 31 && cur !== 78) return;
        }
        chunk.set(lx, y, lz, id, d);
      };
      const trunk = 4 + Math.floor(r * 3);
      if (kind === 1) {
        for (let y = 0; y < trunk + 2; y++) put(tx, ty + y, tz, 17, 1);
        let rad = 0;
        for (let y = trunk + 2; y >= 2; y--) {
          for (let dx = -rad; dx <= rad; dx++) for (let dz = -rad; dz <= rad; dz++) {
            if (Math.abs(dx) + Math.abs(dz) > rad + 1 || (dx === 0 && dz === 0 && y < trunk + 2)) continue;
            put(tx + dx, ty + y, tz + dz, 18, 1, true);
          }
          rad = rad >= 2 ? 1 : rad + 1;
        }
        put(tx, ty + trunk + 2, tz, 18, 1, true);
        put(tx, ty + trunk + 3, tz, 18, 1, true);
        return;
      }
      const leaf = kind === 2 ? 2 : 0;
      for (let y = 0; y < trunk; y++) put(tx, ty + y, tz, 17, leaf);
      for (let y = trunk - 3; y <= trunk; y++) {
        const rad = y >= trunk - 1 ? 1 : 2;
        for (let dx = -rad; dx <= rad; dx++) for (let dz = -rad; dz <= rad; dz++) {
          if (rad === 2 && Math.abs(dx) === 2 && Math.abs(dz) === 2 && MC.hash3(this.seed + 31, tx + dx, ty + y, tz + dz) < 0.5) continue;
          if (rad === 1 && y === trunk && Math.abs(dx) === 1 && Math.abs(dz) === 1) continue;
          put(tx + dx, ty + y, tz + dz, 18, leaf, true);
        }
      }
    }

    findSpawn() {
      for (let i = 0; i < 400; i++) {
        const x = Math.floor(Math.cos(i) * i * 2), z = Math.floor(Math.sin(i) * i * 2);
        const h = this.heightAt(x, z);
        if (h > this.SEA + 1 && this.biomeAt(x, z) !== 'desert') return { x: x + 0.5, y: h + 1, z: z + 0.5 };
      }
      return { x: 0.5, y: this.heightAt(0, 0) + 2, z: 0.5 };
    }
  }

  MC.Chunk = Chunk;
  MC.World = World;
  MC.Generator = Generator;
  MC.chunkKey = key;
})();
