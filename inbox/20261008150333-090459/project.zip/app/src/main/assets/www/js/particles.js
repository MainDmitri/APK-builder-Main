// Частицы как в Minecraft: осколки ломаемого блока, крошки еды, криты, магические криты (чары), дым взрыва, пыль при приземлении.
// Рисуются квадратами, повёрнутыми к камере, тремя вызовами: текстуры блоков, текстуры предметов и цветные.
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const A = window.MC_ASSETS;
  const MAX = 900;
  const rnd = (a, b) => a + Math.random() * (b - a);

  // Цвета для цветных частиц: [r, g, b]
  const COLORS = {
    crit: [1, 0.95, 0.8],
    magic: [0.45, 0.75, 1],
    smoke: [0.55, 0.55, 0.55],
    flash: [1, 1, 0.9],
    heart: [1, 0.3, 0.35]
  };

  // Спрайты цветных частиц 16×8 в стиле пиксельной графики: 0 — клуб дыма (круг), 1 — искра крита (звёздочка)
  function spriteCanvas() {
    const c = document.createElement('canvas');
    c.width = 16; c.height = 8;
    const ctx = c.getContext('2d');
    const img = ctx.createImageData(16, 8);
    const put = (x, y, v) => { const o = (y * 16 + x) * 4; img.data[o] = img.data[o + 1] = img.data[o + 2] = v; img.data[o + 3] = 255; };
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
      const d = Math.hypot(x - 3.5, y - 3.5);
      if (d <= 3.6) put(x, y, Math.round(255 - d * 18 - ((x + y) % 3 === 0 ? 14 : 0)));
    }
    const star = ['...#....', '...#....', '.#.#.#..', '..###...', '#######.', '..###...', '.#.#.#..', '...#....'];
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) if (star[y][x] === '#') put(8 + x, y, x === 3 && y === 4 ? 255 : 225);
    ctx.putImageData(img, 0, 0);
    return c;
  }

  class Particles {
    constructor(game) {
      this.game = game;
      this.list = [];
      this.enabled = true;
      this.level = 1; // 0.5 — меньше частиц на слабых телефонах
    }

    clear() { this.list.length = 0; }

    add(p) {
      if (!this.enabled) return;
      if (this.list.length >= MAX) this.list.shift();
      this.list.push(p);
    }

    count(n) { return Math.max(1, Math.round(n * this.level)); }

    blockTile(id, data, face) {
      const b = MC.Blocks.list[id];
      if (!b || !b.tex) return null;
      const t = b.tex(b.variants > 1 ? data : 0, face, null);
      return typeof t === 'number' && t >= 0 ? t : null;
    }

    // Осколки сломанного блока (как в игре: решётка 4×4×4, здесь разреженная)
    blockBreak(x, y, z, id, data) {
      if (!id) return;
      const tile = this.blockTile(id, data, 2);
      if (tile === null) return;
      const n = this.count(36);
      for (let i = 0; i < n; i++) {
        const px = x + rnd(0.1, 0.9), py = y + rnd(0.1, 0.9), pz = z + rnd(0.1, 0.9);
        this.add({
          kind: 'block', tile, su: Math.floor(Math.random() * 3), sv: Math.floor(Math.random() * 3),
          x: px, y: py, z: pz,
          vx: (px - x - 0.5) * rnd(1.5, 3), vy: rnd(1, 3.5), vz: (pz - z - 0.5) * rnd(1.5, 3),
          life: rnd(0.4, 1.1), age: 0, size: rnd(0.06, 0.1), grav: 14, light: 1
        });
      }
    }

    // Крошки при ударах по блоку, вылетают из грани
    blockHit(x, y, z, id, data, face) {
      const tile = this.blockTile(id, data, face === undefined ? 2 : face);
      if (tile === null) return;
      const n = [[0, -1, 0], [0, 1, 0], [0, 0, -1], [0, 0, 1], [-1, 0, 0], [1, 0, 0]][face] || [0, 1, 0];
      for (let i = 0; i < this.count(3); i++) {
        const px = x + 0.5 + n[0] * 0.52 + (n[0] ? 0 : rnd(-0.45, 0.45));
        const py = y + 0.5 + n[1] * 0.52 + (n[1] ? 0 : rnd(-0.45, 0.45));
        const pz = z + 0.5 + n[2] * 0.52 + (n[2] ? 0 : rnd(-0.45, 0.45));
        this.add({
          kind: 'block', tile, su: Math.floor(Math.random() * 3), sv: Math.floor(Math.random() * 3),
          x: px, y: py, z: pz, vx: n[0] * 1.2 + rnd(-0.4, 0.4), vy: n[1] * 1.2 + rnd(0.2, 1), vz: n[2] * 1.2 + rnd(-0.4, 0.4),
          life: rnd(0.3, 0.6), age: 0, size: rnd(0.04, 0.07), grav: 14, light: 0.9
        });
      }
    }

    // Пыль при приземлении с высоты (частицы блока под ногами)
    landing(x, y, z, id, data, fall) {
      const tile = this.blockTile(id, data, 1);
      if (tile === null) return;
      const n = this.count(Math.min(40, 6 + fall * 4));
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2, s = rnd(0.8, 1.8 + fall * 0.15);
        this.add({
          kind: 'block', tile, su: Math.floor(Math.random() * 3), sv: Math.floor(Math.random() * 3),
          x: x + Math.cos(a) * 0.3, y: y + 0.05, z: z + Math.sin(a) * 0.3, vx: Math.cos(a) * s, vy: rnd(0.8, 2), vz: Math.sin(a) * s,
          life: rnd(0.3, 0.7), age: 0, size: rnd(0.04, 0.08), grav: 12, light: 1
        });
      }
    }

    // Бег по земле: редкие крошки из-под ног
    sprintDust(x, y, z, id, data) {
      const tile = this.blockTile(id, data, 1);
      if (tile === null) return;
      this.add({
        kind: 'block', tile, su: Math.floor(Math.random() * 3), sv: Math.floor(Math.random() * 3),
        x: x + rnd(-0.3, 0.3), y: y + 0.1, z: z + rnd(-0.3, 0.3), vx: rnd(-0.5, 0.5), vy: rnd(0.8, 1.5), vz: rnd(-0.5, 0.5),
        life: rnd(0.25, 0.45), age: 0, size: rnd(0.04, 0.06), grav: 12, light: 1
      });
    }

    // Крошки еды у рта (pos — точка перед глазами, dir — направление взгляда)
    eat(item, x, y, z, dir) {
      const tile = MC.Items.itemTexture(item.id, item.data);
      const block = item.id > 0 && item.id < 256;
      if (!block && (tile === null || tile === undefined)) return;
      for (let i = 0; i < this.count(4); i++) {
        const p = {
          x: x + dir[0] * 0.5 + rnd(-0.08, 0.08), y: y - 0.22 + rnd(-0.05, 0.05), z: z + dir[2] * 0.5 + rnd(-0.08, 0.08),
          vx: dir[0] * 1.2 + rnd(-0.6, 0.6), vy: rnd(0.6, 1.6), vz: dir[2] * 1.2 + rnd(-0.6, 0.6),
          life: rnd(0.4, 0.8), age: 0, size: rnd(0.02, 0.035), grav: 14, light: 1,
          su: Math.floor(Math.random() * 3), sv: Math.floor(Math.random() * 3)
        };
        if (block) {
          const t = this.blockTile(item.id, item.data, 2);
          if (t === null) return;
          p.kind = 'block'; p.tile = t;
        } else { p.kind = 'item'; p.tile = tile; }
        this.add(p);
      }
    }

    // Крит (удар в падении) и магический крит (оружие с чарами) вокруг цели
    crit(x, y, z, h, magic) {
      const n = this.count(14);
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2, s = rnd(1.5, 4);
        this.add({
          kind: 'color', color: magic ? 'magic' : 'crit', sprite: 1,
          x: x + Math.cos(a) * 0.3, y: y + rnd(0.2, h), z: z + Math.sin(a) * 0.3,
          vx: Math.cos(a) * s, vy: rnd(-0.5, 2.5), vz: Math.sin(a) * s,
          life: rnd(0.35, 0.7), age: 0, size: rnd(0.05, 0.08), grav: 4, drag: 3, light: rnd(0.75, 1), shrink: true
        });
      }
    }

    // Взрыв: вспышка и клубы дыма
    explosion(x, y, z, power) {
      const n = this.count(30 + (power || 4) * 10);
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2, e = rnd(-0.6, 1), r = rnd(0, (power || 4) * 0.6);
        this.add({
          kind: 'color', color: 'smoke', sprite: 0,
          x: x + Math.cos(a) * r, y: y + e * r * 0.6, z: z + Math.sin(a) * r,
          vx: Math.cos(a) * rnd(0.5, 2.5), vy: rnd(0.5, 2), vz: Math.sin(a) * rnd(0.5, 2.5),
          life: rnd(0.8, 2), age: 0, size: rnd(0.18, 0.42), grav: -0.6, drag: 1.5, light: rnd(0.55, 1), shrink: true
        });
      }
      for (let i = 0; i < this.count(8); i++) {
        this.add({
          kind: 'color', color: 'flash', sprite: 0, x: x + rnd(-1, 1), y: y + rnd(-0.5, 1), z: z + rnd(-1, 1),
          vx: 0, vy: 0, vz: 0, life: rnd(0.12, 0.25), age: 0, size: rnd(0.5, 0.9), grav: 0, light: 1, shrink: true
        });
      }
    }

    // Сердечки: приручение животного на сервере (EntityEvent 7)
    hearts(x, y, z) {
      for (let i = 0; i < this.count(6); i++) {
        this.add({
          kind: 'color', color: 'heart', sprite: 0, x: x + rnd(-0.5, 0.5), y: y + rnd(0.6, 1.2), z: z + rnd(-0.5, 0.5),
          vx: 0, vy: rnd(0.4, 0.8), vz: 0, life: rnd(0.8, 1.3), age: 0, size: 0.09, grav: -0.2, light: 1
        });
      }
    }

    update(dt) {
      const w = this.game.world;
      const list = this.list;
      let j = 0;
      for (let i = 0; i < list.length; i++) {
        const p = list[i];
        p.age += dt;
        if (p.age >= p.life) continue;
        p.vy -= p.grav * dt;
        if (p.drag) { const k = Math.exp(-p.drag * dt); p.vx *= k; p.vy *= k; p.vz *= k; }
        const nx = p.x + p.vx * dt, ny = p.y + p.vy * dt, nz = p.z + p.vz * dt;
        // Столкновение с блоком: частица ложится на поверхность и скользит с трением
        if (w && p.grav > 0) {
          const id = w.getId(Math.floor(nx), Math.floor(ny - p.size), Math.floor(nz));
          const b = id ? MC.Blocks.list[id] : null;
          if (b && b.solid) {
            if (p.vy < 0 && w.getId(Math.floor(nx), Math.floor(p.y - p.size), Math.floor(nz)) !== id) {
              p.y = Math.floor(ny - p.size) + 1 + p.size; p.vy = 0;
            } else { p.vx *= -0.3; p.vz *= -0.3; if (p.vy > 0) p.vy = 0; }
            p.vx *= 0.6; p.vz *= 0.6;
            p.x += p.vx * dt; p.z += p.vz * dt;
            list[j++] = p;
            continue;
          }
        }
        p.x = nx; p.y = ny; p.z = nz;
        list[j++] = p;
      }
      list.length = j;
    }

    // Вершины для отрисовки: {block: [], item: [], color: {имя: []}}; координаты относительно камеры
    build(cam) {
      const out = this.out || (this.out = { block: [], item: [], color: {} });
      out.block.length = 0; out.item.length = 0;
      for (const k in out.color) out.color[k].length = 0;
      if (!this.list.length) return out;
      const yaw = cam.yaw * Math.PI / 180, pitch = cam.pitch * Math.PI / 180;
      // Правый и верхний векторы камеры
      const rx = -Math.cos(yaw), rz = -Math.sin(yaw);
      const fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
      // Верхний вектор = взгляд × правый, нормализованный и направленный вверх
      let Ux = fy * rz, Uy = fz * rx - fx * rz, Uz = -fy * rx;
      const ul = Math.hypot(Ux, Uy, Uz) || 1;
      Ux /= ul; Uy /= ul; Uz /= ul;
      if (Uy < 0) { Ux = -Ux; Uy = -Uy; Uz = -Uz; }
      const bg = A.blockGrid, ig = A.itemGrid;
      const maxD2 = 48 * 48;
      for (const p of this.list) {
        const x = p.x - cam.x, y = p.y - cam.y, z = p.z - cam.z;
        if (x * x + y * y + z * z > maxD2) continue;
        const k = p.shrink ? 1 - p.age / p.life * 0.7 : 1;
        const s = p.size * k;
        const ax = rx * s, az = rz * s, bx = Ux * s, by = Uy * s, bz = Uz * s;
        let arr, u0, v0, u1, v1;
        if (p.kind === 'color') {
          arr = out.color[p.color] || (out.color[p.color] = []);
          u0 = (p.sprite || 0) * 0.5; v0 = 0; u1 = u0 + 0.5; v1 = 1;
        } else {
          const g = p.kind === 'block' ? bg : ig;
          arr = p.kind === 'block' ? out.block : out.item;
          const t = 1 / g, q = t / 4;
          u0 = (p.tile % g) * t + p.su * q; v0 = Math.floor(p.tile / g) * t + p.sv * q;
          u1 = u0 + q; v1 = v0 + q;
        }
        const l = p.light;
        // Два треугольника: (-a-b) (+a-b) (+a+b) и (-a-b) (+a+b) (-a+b)
        arr.push(
          x - ax - bx, y - by, z - az - bz, u0, v1, l,
          x + ax - bx, y - by, z + az - bz, u1, v1, l,
          x + ax + bx, y + by, z + az + bz, u1, v0, l,
          x - ax - bx, y - by, z - az - bz, u0, v1, l,
          x + ax + bx, y + by, z + az + bz, u1, v0, l,
          x - ax + bx, y + by, z - az + bz, u0, v0, l
        );
      }
      return out;
    }
  }

  Particles.COLORS = COLORS;
  Particles.spriteCanvas = spriteCanvas;
  MC.Particles = Particles;
})();
