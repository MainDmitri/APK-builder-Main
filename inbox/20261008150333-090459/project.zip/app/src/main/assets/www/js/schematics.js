// Схемы построек (как мод Schematica): файлы .schematic (формат MCEdit/Schematica, Java Edition до 1.12),
// голограмма постройки в мире, перемещение и поворот, показ по слоям, принтер (сам ставит блоки рядом с игроком),
// постройка целиком, список материалов, замена недостающих блоков, сохранение области в .schematic. Работает и на серверах.
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const KEY = 'schematics';
  const MAX_VOLUME = 4000000;

  // ---------- NBT (big endian) ----------
  class NbtReader {
    constructor(bytes) { this.b = bytes; this.v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength); this.o = 0; }
    byte() { return this.v.getInt8(this.o++); }
    short() { const r = this.v.getInt16(this.o); this.o += 2; return r; }
    int() { const r = this.v.getInt32(this.o); this.o += 4; return r; }
    long() { const hi = this.v.getInt32(this.o), lo = this.v.getUint32(this.o + 4); this.o += 8; return hi * 4294967296 + lo; }
    float() { const r = this.v.getFloat32(this.o); this.o += 4; return r; }
    double() { const r = this.v.getFloat64(this.o); this.o += 8; return r; }
    string() { const n = this.v.getUint16(this.o); this.o += 2; const s = new TextDecoder().decode(this.b.subarray(this.o, this.o + n)); this.o += n; return s; }
    payload(t) {
      switch (t) {
        case 1: return this.byte();
        case 2: return this.short();
        case 3: return this.int();
        case 4: return this.long();
        case 5: return this.float();
        case 6: return this.double();
        case 7: { const n = this.int(); const r = this.b.slice(this.o, this.o + n); this.o += n; return r; }
        case 8: return this.string();
        case 9: { const et = this.byte(), n = this.int(); const r = []; for (let i = 0; i < n; i++) r.push(this.payload(et)); return r; }
        case 10: {
          const r = {};
          for (;;) {
            const tt = this.byte();
            if (tt === 0) break;
            const name = this.string();
            r[name] = this.payload(tt);
          }
          return r;
        }
        case 11: { const n = this.int(); const r = new Int32Array(n); for (let i = 0; i < n; i++) r[i] = this.int(); return r; }
        // Массив long: пары 32-битных слов (младшее, старшее) — в число JS 64 бита без потерь не помещаются
        case 12: {
          const n = this.int(); const r = new Uint32Array(n * 2);
          for (let i = 0; i < n; i++) { r[i * 2 + 1] = this.v.getUint32(this.o); r[i * 2] = this.v.getUint32(this.o + 4); this.o += 8; }
          return r;
        }
        default: throw new Error('Неизвестный тег NBT ' + t);
      }
    }
    root() {
      const t = this.byte();
      if (t !== 10) throw new Error('Файл не похож на NBT');
      this.string();
      return this.payload(10);
    }
  }

  class NbtWriter {
    constructor() { this.parts = []; this.size = 0; }
    push(u8) { this.parts.push(u8); this.size += u8.length; }
    byte(v) { this.push(new Uint8Array([v & 255])); }
    short(v) { const b = new Uint8Array(2); new DataView(b.buffer).setInt16(0, v); this.push(b); }
    int(v) { const b = new Uint8Array(4); new DataView(b.buffer).setInt32(0, v); this.push(b); }
    string(s) { const e = new TextEncoder().encode(s); this.short(e.length); this.push(e); }
    tag(type, name) { this.byte(type); this.string(name); }
    result() { const out = new Uint8Array(this.size); let o = 0; for (const p of this.parts) { out.set(p, o); o += p.length; } return out; }
  }

  async function stream(bytes, ds) {
    const s = new Blob([bytes]).stream().pipeThrough(ds);
    return new Uint8Array(await new Response(s).arrayBuffer());
  }

  // ---------- Java Edition 1.12 ↔ MCPE 1.1 ----------
  // [java id] → [mcpe id, функция данных]
  const J2P = {
    95: [241], 125: [157], 126: [158], 157: [126], 158: [125], 166: [95],
    188: [85, () => 1], 189: [85, () => 2], 190: [85, () => 3], 191: [85, () => 4], 192: [85, () => 5],
    198: [208], 199: [240], 202: [201, () => 2], 204: [201], 205: [182, (d) => 1 | (d & 8)], 207: [244], 208: [198],
    212: [207], 218: [251], 251: [236], 252: [237],
    43: [43, (d) => swapSlab(d)], 44: [44, (d) => swapSlab(d)],
    77: [77, buttonData], 143: [143, buttonData],
    36: [0], 119: [0], 137: [0], 176: [0], 177: [0], 209: [0], 210: [0], 211: [0], 217: [0], 255: [0]
  };
  for (let i = 0; i < 16; i++) { J2P[219 + i] = [218, () => i]; J2P[235 + i] = [220 + i, (d) => d]; }
  // Каменные плиты: в Java 6 — кирпич Нижнего мира, 7 — кварц; в MCPE наоборот
  function swapSlab(d) { const t = d & 7; return (t === 6 ? 7 : t === 7 ? 6 : t) | (d & 8); }
  // Кнопки: Java 0 низ, 1 восток, 2 запад, 3 юг, 4 север, 5 верх → MCPE 0 низ, 1 верх, 2 север, 3 юг, 4 запад, 5 восток
  function buttonData(d) { return [0, 5, 4, 3, 2, 1, 0, 0][d & 7] | (d & 8); }
  function buttonBack(d) { return [0, 5, 4, 3, 2, 1, 0, 0][d & 7] | (d & 8); }

  function fromJava(id, data) {
    const m = J2P[id];
    let pid = id, pd = data;
    if (m) { pid = m[0]; pd = m[1] ? m[1](data) : data; }
    if (pid === 0) return null;
    const b = MC.Blocks.list[pid];
    if (!b || b.shape === 'none') return null;
    return [pid, pd & 15];
  }

  // MCPE → Java для сохранения
  function toJava(id, data) {
    if (id === 85 && data > 0) return [187 + data, 0];
    if (id === 44 || id === 43) return [id, swapSlab(data)];
    if (id === 77 || id === 143) return [id, buttonBack(data)];
    if (id === 218) return [219 + (data & 15), 0];
    if (id >= 220 && id <= 235) return [id + 15, data];
    if (id === 201) return [(data & 3) === 2 ? 202 : 201, 0];
    if (id === 182) return [205, data & 8];
    for (const k of Object.keys(J2P)) {
      const m = J2P[k];
      if (m[0] === id && !m[1] && +k !== 166 && m[0] !== 0) return [+k, data];
    }
    if (id === 95) return [166, 0];
    return [id, data];
  }

  // ---------- Разбор и запись файла ----------
  async function parse(bytes, name) {
    let raw = bytes;
    if (bytes[0] === 0x1f && bytes[1] === 0x8b) raw = await stream(bytes, new DecompressionStream('gzip'));
    const root = new NbtReader(raw).root();
    const base = name.replace(/\.(schematic|schem|litematic|nbt)$/i, '');
    if (root.Regions) return parseLitematic(root, base);
    if (root.Schematic && root.Schematic.Blocks) return parseSponge(root.Schematic, base);
    if (root.Palette && root.BlockData) return parseSponge(root, base);
    if (root.blocks && root.size && (root.palette || root.palettes)) return parseStructure(root, base);
    if (!root.Blocks || root.Width === undefined) throw new Error('Неизвестный формат схемы: поддерживаются .schematic, .schem, .litematic и .nbt');
    const w = root.Width & 0xffff, h = root.Height & 0xffff, l = root.Length & 0xffff;
    checkSize(w, h, l);
    const blocks = root.Blocks, data = root.Data || new Uint8Array(blocks.length), add = root.AddBlocks;
    // Schematica сохраняет свою таблицу «имя → номер»: блоки модов превращаются в воздух
    let remap = null;
    if (root.SchematicaMapping) {
      remap = {};
      for (const [n, v] of Object.entries(root.SchematicaMapping)) remap[v] = n.startsWith('minecraft:') ? v : 0;
    }
    const ids = new Uint8Array(w * h * l), meta = new Uint8Array(w * h * l);
    let count = 0, skipped = 0;
    for (let i = 0; i < blocks.length && i < ids.length; i++) {
      let id = blocks[i] & 255;
      if (add) id |= ((i & 1 ? add[i >> 1] & 15 : (add[i >> 1] >> 4) & 15) << 8);
      if (remap) id = remap[id] === undefined ? id : remap[id];
      if (!id) continue;
      const r = id < 256 ? fromJava(id, data[i] & 15) : null;
      if (!r) { skipped++; continue; }
      ids[i] = r[0];
      meta[i] = r[1];
      count++;
    }
    return { name: base, w, h, l, ids, meta, count, skipped, approx: 0, format: 'schematic', added: Date.now() };
  }

  function checkSize(w, h, l) {
    if (w <= 0 || h <= 0 || l <= 0) throw new Error('В схеме нет блоков');
    if (w * h * l > MAX_VOLUME) throw new Error('Схема слишком большая: ' + w + '×' + h + '×' + l);
    if (h > 256) throw new Error('Схема выше 256 блоков');
  }

  // Палитра состояний Java 1.13+ → блоки MCPE: [id, data, approx] или null (воздух / нет в MCPE)
  function mapState(name, props, old) {
    const j = MC.BlockStates.legacy(name, props, old);
    if (!j) return name && !/(^|:)(air|cave_air|void_air|structure_void)$/.test(name) ? { miss: true } : null;
    const r = fromJava(j.id, j.data);
    return r ? { id: r[0], data: r[1], approx: j.approx } : { miss: true };
  }

  // Заполнение схемы по палитре: put(i, paletteIndex)
  function fromPalette(base, w, h, l, pal, format, fill) {
    const n = w * h * l;
    const ids = new Uint8Array(n), meta = new Uint8Array(n);
    const res = { count: 0, skipped: 0, approx: 0 };
    fill((i, pi) => {
      const m = pal[pi];
      if (!m) return;
      if (m.miss) { res.skipped++; return; }
      ids[i] = m.id;
      meta[i] = m.data;
      res.count++;
      if (m.approx) res.approx++;
    });
    return { name: base, w, h, l, ids, meta, count: res.count, skipped: res.skipped, approx: res.approx, format, added: Date.now() };
  }

  // Sponge .schem (WorldEdit, FAWE): v1/v2 — Palette и BlockData в корне, v3 — в Blocks; номера в палитре — varint
  function parseSponge(r, base) {
    const w = r.Width & 0xffff, h = r.Height & 0xffff, l = r.Length & 0xffff;
    checkSize(w, h, l);
    const src = r.Blocks || r;
    const palette = src.Palette, data = src.BlockData || src.Data;
    if (!palette || !data) throw new Error('В .schem нет палитры блоков');
    const pal = [];
    for (const [k, v] of Object.entries(palette)) {
      const st = MC.BlockStates.parseState(k);
      pal[v] = mapState(st.name, st.props, false);
    }
    return fromPalette(base, w, h, l, pal, 'schem', (put) => {
      let o = 0;
      for (let i = 0; i < w * h * l && o < data.length; i++) {
        let v = 0, sh = 0, b;
        do { b = data[o++] & 255; v |= (b & 127) << sh; sh += 7; } while (b & 128 && o < data.length);
        put(i, v);
      }
    });
  }

  // Litematica: несколько областей (Regions), каждая со своей палитрой; размеры бывают отрицательными
  function parseLitematic(root, base) {
    const old = (root.MinecraftDataVersion || 9999) < 1451;
    const regs = [];
    let minX = Infinity, minY = Infinity, minZ = Infinity, maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    for (const reg of Object.values(root.Regions)) {
      const ps = reg.Position, sz = reg.Size;
      if (!ps || !sz || !reg.BlockStatePalette || !reg.BlockStates) continue;
      const sx = Math.abs(sz.x), sy = Math.abs(sz.y), szz = Math.abs(sz.z);
      if (!sx || !sy || !szz) continue;
      const x0 = sz.x < 0 ? ps.x + sz.x + 1 : ps.x, y0 = sz.y < 0 ? ps.y + sz.y + 1 : ps.y, z0 = sz.z < 0 ? ps.z + sz.z + 1 : ps.z;
      regs.push({ reg, x0, y0, z0, sx, sy, sz: szz });
      minX = Math.min(minX, x0); minY = Math.min(minY, y0); minZ = Math.min(minZ, z0);
      maxX = Math.max(maxX, x0 + sx - 1); maxY = Math.max(maxY, y0 + sy - 1); maxZ = Math.max(maxZ, z0 + szz - 1);
    }
    if (!regs.length) throw new Error('В .litematic нет областей с блоками');
    const w = maxX - minX + 1, h = maxY - minY + 1, l = maxZ - minZ + 1;
    checkSize(w, h, l);
    // Общая палитра: у каждой области свой сдвиг номеров
    const pal = [];
    for (const g of regs) {
      g.off = pal.length;
      for (const e of g.reg.BlockStatePalette) pal.push(mapState(e.Name, e.Properties, old));
    }
    return fromPalette(base, w, h, l, pal, 'litematic', (put) => {
      for (const g of regs) {
        const n = g.reg.BlockStatePalette.length;
        const bits = Math.max(2, Math.ceil(Math.log2(n)));
        const words = g.reg.BlockStates, mask = bits === 32 ? 0xffffffff : (1 << bits) - 1;
        const total = g.sx * g.sy * g.sz;
        // Значения уложены подряд по 64-битным числам, младшие биты первыми: читаем как поток 32-битных слов
        for (let i = 0; i < total; i++) {
          const bp = i * bits, wi = bp >>> 5, off = bp & 31;
          if (wi >= words.length) break;
          let v = words[wi] >>> off;
          if (off + bits > 32 && wi + 1 < words.length) v |= words[wi + 1] << (32 - off);
          v = (v & mask) >>> 0;
          if (!v || v >= n) continue;
          const x = i % g.sx, z = Math.floor(i / g.sx) % g.sz, y = Math.floor(i / (g.sx * g.sz));
          const wx = g.x0 - minX + x, wy = g.y0 - minY + y, wz = g.z0 - minZ + z;
          put((wy * l + wz) * w + wx, g.off + v);
        }
      }
    });
  }

  // Структурный блок (.nbt): список блоков с координатами
  function parseStructure(root, base) {
    const old = (root.DataVersion || 9999) < 1451;
    const [w, h, l] = root.size;
    checkSize(w, h, l);
    const list = root.palette || root.palettes[0];
    const pal = list.map((e) => mapState(e.Name, e.Properties, old));
    return fromPalette(base, w, h, l, pal, 'nbt', (put) => {
      for (const b of root.blocks) {
        const [x, y, z] = b.pos;
        if (x < 0 || y < 0 || z < 0 || x >= w || y >= h || z >= l) continue;
        put((y * l + z) * w + x, b.state);
      }
    });
  }

  // Индекс в .schematic: (y * length + z) * width + x
  async function encode(s) {
    const n = s.w * s.h * s.l;
    const blocks = new Uint8Array(n), data = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
      if (!s.ids[i]) continue;
      const j = toJava(s.ids[i], s.meta[i]);
      blocks[i] = j[0];
      data[i] = j[1] & 15;
    }
    const wr = new NbtWriter();
    wr.tag(10, 'Schematic');
    wr.tag(2, 'Width'); wr.short(s.w);
    wr.tag(2, 'Height'); wr.short(s.h);
    wr.tag(2, 'Length'); wr.short(s.l);
    wr.tag(8, 'Materials'); wr.string('Alpha');
    wr.tag(7, 'Blocks'); wr.int(n); wr.push(blocks);
    wr.tag(7, 'Data'); wr.int(n); wr.push(data);
    wr.tag(9, 'Entities'); wr.byte(10); wr.int(0);
    wr.tag(9, 'TileEntities'); wr.byte(10); wr.int(0);
    wr.byte(0);
    return stream(wr.result(), new CompressionStream('gzip'));
  }

  // Буфер копирования Effortless Building → схема
  function fromClip(clip, name) {
    let w = 0, h = 0, l = 0;
    for (const b of clip.blocks) { w = Math.max(w, b.x + 1); h = Math.max(h, b.y + 1); l = Math.max(l, b.z + 1); }
    const ids = new Uint8Array(w * h * l), meta = new Uint8Array(w * h * l);
    for (const b of clip.blocks) { const i = (b.y * l + b.z) * w + b.x; ids[i] = b.id; meta[i] = b.d; }
    return { name, w, h, l, ids, meta, count: clip.blocks.length, skipped: 0, added: Date.now() };
  }

  // ---------- Хранилище (IndexedDB) ----------
  async function list() { try { return (await MC.Storage.kv.get(KEY)) || []; } catch (e) { return []; } }
  async function saveList(l) { await MC.Storage.kv.put(KEY, l); }

  async function addFile(file) {
    const bytes = new Uint8Array(await file.arrayBuffer());
    const s = await parse(bytes, file.name);
    if (!s.count) throw new Error('В схеме нет блоков, которые есть в MCPE 1.1');
    await store(s);
    return s;
  }

  async function store(s) {
    const l = (await list()).filter((x) => x.name !== s.name);
    l.unshift(s);
    await saveList(l);
  }

  async function remove(name) { await saveList((await list()).filter((x) => x.name !== name)); }

  // Сохранение файла: в папку игры (APK), иначе скачивание
  async function exportFile(s) {
    const gz = await encode(s);
    const fname = s.name.replace(/[\\/:*?"<>|]/g, '_') + '.schematic';
    if (window.AndroidStorage && typeof window.AndroidStorage.write === 'function' && window.AndroidStorage.folderName()) {
      let bin = '';
      for (let i = 0; i < gz.length; i += 0x8000) bin += String.fromCharCode.apply(null, gz.subarray(i, i + 0x8000));
      const err = window.AndroidStorage.write('schematics', fname, btoa(bin));
      if (err) throw new Error(err);
      return 'Сохранено в папку игры: schematics/' + fname;
    }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([gz], { type: 'application/octet-stream' }));
    a.download = fname;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
    return 'Файл ' + fname + ' скачан';
  }

  // ---------- Голограмма в мире ----------
  const key3 = (x, y, z) => x + ',' + y + ',' + z;
  const rot = (id, d) => MC.Building.rotateData(id, d);
  const flip = (id, d) => MC.Building.flipData(id, d, 'x');
  // Один и тот же блок в разных состояниях (горящая печь, включённая лампа, текущая вода)
  const SAME = { 62: 61, 124: 123, 94: 93, 150: 149, 76: 75, 74: 73, 8: 9, 10: 11, 178: 151 };
  const base = (id) => SAME[id] || id;
  // Вид блока (цвет, порода): разный вид — это другой блок
  function variantOf(id, d) {
    if (id === 155) return Math.min(d, 2);
    if (id === 175) return d & 8 ? -1 : d & 7;
    const b = MC.Blocks.list[id], v = b && b.variants > 1 ? b.variants : 1;
    return v > 1 ? d % v : 0;
  }
  const LAYER_MODES = ['single', 'below', 'auto'];
  // Ключ предмета для подсчёта блоков: вид без поворота
  function itemKey(id, d) {
    const b = MC.Blocks.list[id], v = b && b.variants > 1 ? b.variants : 1;
    return id + ':' + (v > 1 ? d % v : 0);
  }
  // Цвета рамок: неверный блок, неверный поворот, клетка для Easy Place
  const MARK_WRONG = 0, MARK_ROT = 1;

  class View {
    constructor(game) {
      this.game = game;
      this.s = null;
      this.pos = { x: 0, y: 64, z: 0 };
      this.rot = 0;
      this.mirror = false;
      this.layer = -1;
      this.layerMode = 'single';
      this.printer = false;
      this.easyPlace = false;
      this.printT = 0;
      this.ghost = new MC.World();
      this.dirty = new Set();
      this.wrongs = new Set();
      this.rots = new Set();
      this.marksV = 0;
      this.easyCell = null;
      // Замены: клетка → id поставленного вместо нужного блока (placed — уже стоит в мире)
      this.subs = new Map();
      this.stats = { ok: 0, left: 0, wrong: 0, rot: 0 };
      this.rebuildT = 0;
      this.saveT = 0;
      this.ghost.onSectionDirty((cx, sy, cz) => this.dirty.add(cx + ',' + sy + ',' + cz));
      game.world.onBlockSet((x, y, z) => this.worldChanged(x, y, z));
      if (game.building) game.building.onSubst = (o) => this.markSub(o.x, o.y, o.z, o.nid);
      // На сервере чанки приходят позже: пересчитываем голограмму, когда загрузился чанк под схемой
      game.world.onChunkSet((cx, cz) => { if (this.s && this.coversChunk(cx, cz)) this.rebuildT = 0.4; });
      this.restore();
    }

    // ---------- Расположение схемы сохраняется для каждого мира и сервера ----------
    placeKey() {
      const g = this.game;
      if (g.mode === 'sp') return g.record ? 'schemPlace:w:' + g.record.id : '';
      const sv = g.opts && g.opts.server;
      return sv ? 'schemPlace:s:' + sv.host + ':' + sv.port : '';
    }

    savePlace() {
      const k = this.placeKey();
      if (!k) return;
      const v = this.s ? { name: this.s.name, builtin: !!this.s.builtin, pos: this.pos, rot: this.rot, mirror: this.mirror, layer: this.layer, layerMode: this.layerMode, easyPlace: this.easyPlace } : null;
      MC.Storage.kv.put(k, v).catch((e) => console.warn('Расположение схемы', e));
    }

    async restore() {
      const k = this.placeKey();
      if (!k) return;
      let v = null;
      try { v = await MC.Storage.kv.get(k); } catch (e) { return; }
      if (!v || !v.name || this.s) return;
      let s = null;
      if (v.builtin) {
        const st = MC.Structures.LIST.find((x) => MC.Structures.get(x.id).name === v.name);
        if (st) s = MC.Structures.get(st.id);
      } else s = (await list()).find((x) => x.name === v.name) || null;
      if (!s || this.s) return;
      this.s = s;
      this.pos = { x: v.pos.x | 0, y: v.pos.y | 0, z: v.pos.z | 0 };
      this.rot = v.rot & 3;
      this.mirror = !!v.mirror;
      this.layerMode = LAYER_MODES.includes(v.layerMode) ? v.layerMode : 'single';
      this.layer = typeof v.layer === 'number' ? Math.min(v.layer, s.h - 1) : -1;
      this.easyPlace = !!v.easyPlace;
      this.rebuild();
    }

    size() {
      const s = this.s;
      return this.rot & 1 ? { w: s.l, h: s.h, l: s.w } : { w: s.w, h: s.h, l: s.l };
    }

    coversChunk(cx, cz) {
      const sz = this.size();
      return cx * 16 + 15 >= this.pos.x && cx * 16 <= this.pos.x + sz.w - 1 && cz * 16 + 15 >= this.pos.z && cz * 16 <= this.pos.z + sz.l - 1;
    }

    layerOk(ly) {
      if (this.layer < 0) return true;
      return this.layerMode === 'below' ? ly <= this.layer : ly === this.layer;
    }

    // Блок схемы в мировых координатах (с поворотом и отражением) или null; all — без учёта слоя
    targetAt(x, y, z, all) {
      const s = this.s;
      if (!s) return null;
      const sz = this.size();
      let lx = x - this.pos.x, ly = y - this.pos.y, lz = z - this.pos.z;
      if (lx < 0 || ly < 0 || lz < 0 || lx >= sz.w || ly >= sz.h || lz >= sz.l) return null;
      if (!all && !this.layerOk(ly)) return null;
      // Обратный поворот: мировая клетка → клетка схемы
      // Один поворот по часовой: (x, z) в коробке W×L → (L-1-z, x); отменяем повороты в обратном порядке
      for (let j = this.rot - 1; j >= 0; j--) { const lj = j & 1 ? s.w : s.l; const ox = lx; lx = lz; lz = lj - 1 - ox; }
      if (this.mirror) lx = s.w - 1 - lx;
      const i = (ly * s.l + lz) * s.w + lx;
      const id = s.ids[i];
      if (!id) return null;
      let d = s.meta[i];
      if (this.mirror) d = flip(id, d);
      for (let r = 0; r < this.rot; r++) d = rot(id, d);
      return [id, d];
    }

    load(s) {
      this.s = s;
      this.rot = 0;
      this.mirror = false;
      this.layer = this.layerMode === 'auto' ? 0 : -1;
      this.subs.clear();
      // Перед игроком: схема начинается в 2 блоках по направлению взгляда
      const p = this.game.player;
      const yr = p.yaw * Math.PI / 180, fx = -Math.sin(yr), fz = Math.cos(yr);
      this.pos = { x: Math.floor(p.x + fx * 3) - (fx < -0.5 ? s.w - 1 : 0), y: Math.floor(p.y), z: Math.floor(p.z + fz * 3) - (fz < -0.5 ? s.l - 1 : 0) };
      this.changed();
    }

    unload() { this.s = null; this.printer = false; this.gather = null; this.subs.clear(); this.changed(); }

    changed() { this.rebuild(); this.savePlace(); }
    move(dx, dy, dz) { this.pos.x += dx; this.pos.y = Math.max(0, Math.min(255, this.pos.y + dy)); this.pos.z += dz; this.subs.clear(); this.changed(); }
    moveTo(p) { this.pos = { x: p.x, y: p.y, z: p.z }; this.subs.clear(); this.changed(); }
    rotate() { this.rot = (this.rot + 1) & 3; this.subs.clear(); this.changed(); }
    flipX() { this.mirror = !this.mirror; this.subs.clear(); this.changed(); }
    setLayer(v) { const h = this.s ? this.s.h : 1; this.layer = v < 0 ? -1 : Math.max(0, Math.min(h - 1, v)); this.changed(); }
    cycleLayerMode() {
      this.layerMode = LAYER_MODES[(LAYER_MODES.indexOf(this.layerMode) + 1) % LAYER_MODES.length];
      if (this.layerMode === 'auto' && this.layer < 0) this.layer = 0;
      this.changed();
    }
    setEasyPlace(v) { this.easyPlace = v; this.easyCell = null; this.marksV++; this.savePlace(); }
    layerModeLabel() { return { single: 'Только слой', below: 'Слой и ниже', auto: 'Слой по ходу стройки' }[this.layerMode]; }

    // Состояние клетки: ok — готово, left — не построено, wrong — стоит другой блок, rot — тот же блок, но повёрнут не так
    state(x, y, z, t, cur, curData) {
      const sub = this.subs.get(key3(x, y, z));
      if (sub && (cur === sub.id || !sub.placed)) return 'ok';
      if (cur && base(cur) === base(t[0])) {
        const vt = variantOf(t[0], t[1]), vc = variantOf(cur, curData);
        if (vt >= 0 && vc >= 0 && vt !== vc) return 'wrong';
        const ot = MC.Building.orientOf(t[0], t[1]);
        if (ot >= 0 && ot !== MC.Building.orientOf(cur, curData)) return 'rot';
        return 'ok';
      }
      if (cur && !MC.Blocks.list[cur].replaceable) return 'wrong';
      return 'left';
    }

    // Режим «по ходу стройки»: самый нижний слой, где ещё есть работа
    autoLayer() {
      const s = this.s, sz = this.size(), w = this.game.world;
      for (let y = 0; y < sz.h; y++) {
        const wy = this.pos.y + y;
        if (wy > 255) break;
        for (let x = 0; x < sz.w; x++) for (let z = 0; z < sz.l; z++) {
          const wx = this.pos.x + x, wz = this.pos.z + z;
          const t = this.targetAt(wx, wy, wz, true);
          // Чанк ещё не загружен — слой считаем недостроенным, пересчёт будет при загрузке чанка
          if (t && !w.getChunk(wx >> 4, wz >> 4)) return y;
          if (t && this.state(wx, wy, wz, t, w.getId(wx, wy, wz), w.getData(wx, wy, wz)) !== 'ok') return y;
        }
      }
      return s.h - 1;
    }

    // Голограмма показывает только блоки, которых ещё нет в мире
    rebuild() {
      const R = this.game.renderer;
      for (const k of this.ghost.chunks.keys()) {
        const [cx, cz] = k.split(',').map(Number);
        for (let sy = 0; sy < 16; sy++) R.removeGhostSection(cx, sy, cz);
      }
      this.ghost.chunks.clear();
      this.dirty.clear();
      this.wrongs.clear();
      this.rots.clear();
      this.marksV++;
      this.stats = { ok: 0, left: 0, wrong: 0, rot: 0 };
      if (!this.s) return;
      if (this.layerMode === 'auto' && this.layer >= 0) this.layer = this.autoLayer();
      const sz = this.size(), w = this.game.world;
      for (let x = 0; x < sz.w; x++) for (let z = 0; z < sz.l; z++) {
        const wx = this.pos.x + x, wz = this.pos.z + z;
        for (let y = 0; y < sz.h; y++) {
          const wy = this.pos.y + y;
          if (wy > 255) break;
          const t = this.targetAt(wx, wy, wz);
          if (!t) continue;
          const st = this.state(wx, wy, wz, t, w.getId(wx, wy, wz), w.getData(wx, wy, wz));
          this.stats[st]++;
          if (st === 'ok') continue;
          if (st === 'rot') { this.rots.add(key3(wx, wy, wz)); continue; }
          if (st === 'wrong') this.wrongs.add(key3(wx, wy, wz));
          let c = this.ghost.getChunk(wx >> 4, wz >> 4);
          if (!c) { c = new MC.Chunk(wx >> 4, wz >> 4); this.ghost.chunks.set((wx >> 4) + ',' + (wz >> 4), c); }
          c.set(wx & 15, wy, wz & 15, t[0], t[1]);
        }
      }
      // Блоки записаны напрямую в чанки (без пересчёта света на каждый блок) — перестраиваем все секции
      for (const c of this.ghost.chunks.values()) {
        c.recalcHeight();
        for (let sy = 0; sy < 16; sy++) if (c.sections[sy]) this.dirty.add(c.cx + ',' + sy + ',' + c.cz);
      }
    }

    worldChanged(x, y, z) {
      if (!this.s) return;
      const t = this.targetAt(x, y, z);
      if (!t) return;
      const k = key3(x, y, z);
      const w = this.game.world, cur = w.getId(x, y, z);
      // Замена встала в мир; если её потом сломали — клетка снова ждёт блок
      const sub = this.subs.get(k);
      if (sub) { if (cur === sub.id) sub.placed = true; else if (sub.placed) this.subs.delete(k); }
      const had = this.ghost.getId(x, y, z);
      const prev = had ? (this.wrongs.has(k) ? 'wrong' : 'left') : this.rots.has(k) ? 'rot' : 'ok';
      const now = this.state(x, y, z, t, cur, w.getData(x, y, z));
      if (prev === now) return;
      this.stats[prev] = Math.max(0, this.stats[prev] - 1);
      this.stats[now]++;
      if (now === 'wrong') this.wrongs.add(k); else this.wrongs.delete(k);
      if (now === 'rot') this.rots.add(k); else this.rots.delete(k);
      if (prev === 'wrong' || now === 'wrong' || prev === 'rot' || now === 'rot') this.marksV++;
      if (now === 'ok' || now === 'rot') { if (had) this.ghost.setBlock(x, y, z, 0, 0); }
      else if (!had) this.ghost.setBlock(x, y, z, t[0], t[1]);
      // Слой достроен — переходим к следующему
      if (this.layerMode === 'auto' && this.layer >= 0 && !this.stats.left && !this.stats.wrong && !this.stats.rot && this.layer < this.s.h - 1) this.rebuildT = 0.3;
    }

    // Поставлена замена (нужного блока не было): клетка считается готовой
    markSub(x, y, z, id) {
      if (!this.s || !this.targetAt(x, y, z)) return;
      this.subs.set(key3(x, y, z), { id, placed: this.game.world.getId(x, y, z) === id });
      this.worldChanged(x, y, z);
    }

    // Перестройка мешей голограммы понемногу каждый кадр
    update(dt) {
      if (!this.s) return;
      const g = this.game;
      if (this.rebuildT > 0) { this.rebuildT -= dt; if (this.rebuildT <= 0) { const l = this.layer; this.rebuild(); if (this.layer !== l) this.savePlace(); } }
      const R = g.renderer;
      let n = 0;
      for (const k of this.dirty) {
        this.dirty.delete(k);
        const [cx, sy, cz] = k.split(',').map(Number);
        if (!this.ghost.getChunk(cx, cz)) { R.removeGhostSection(cx, sy, cz); continue; }
        R.setGhostSection(cx, sy, cz, MC.Mesher.buildSection(this.ghost, cx, sy, cz));
        if (++n >= 4) break;
      }
      if (this.easyPlace) {
        const c = this.easyTarget();
        const ck = c ? key3(c[0], c[1], c[2]) : '';
        if (ck !== (this.easyCell ? key3(this.easyCell[0], this.easyCell[1], this.easyCell[2]) : '')) { this.easyCell = c; this.marksV++; }
      }
      if (this.gather) this.gatherStep();
      if (this.printer) {
        this.printT -= dt;
        if (this.printT <= 0) { this.printT = 0.12; this.print(); }
      }
    }

    // Рамки для отрисовки: красные — чужой блок, оранжевые — не тот поворот, белая — куда встанет блок Easy Place
    marks() {
      if (!this.s || (!this.wrongs.size && !this.rots.size && !this.easyCell)) return null;
      if (this.marksCache && this.marksCache.v === this.marksV) return this.marksCache;
      const list = [];
      const add = (set, kind) => { for (const k of set) { if (list.length >= 3000) break; const [x, y, z] = k.split(',').map(Number); list.push(x, y, z, kind); } };
      add(this.wrongs, MARK_WRONG);
      add(this.rots, MARK_ROT);
      this.marksCache = { v: this.marksV, list, easy: this.easyCell };
      return this.marksCache;
    }

    // Все клетки голограммы (не построенные): [x, y, z, id, data]
    forGhost(fn) {
      for (const [k, c] of this.ghost.chunks) {
        const [cx, cz] = k.split(',').map(Number);
        for (let sy = 0; sy < 16; sy++) {
          const sec = c.sections[sy];
          if (!sec) continue;
          for (let i = 0; i < 4096; i++) {
            const id = sec.ids[i];
            if (id) fn(cx * 16 + (i >> 8), sy * 16 + (i & 15), cz * 16 + ((i >> 4) & 15), id, sec.meta[i]);
          }
        }
      }
    }

    // Материалы: сколько каких блоков ещё нужно и сколько есть в инвентаре
    materials() {
      const need = new Map();
      this.forGhost((x, y, z, id, d) => {
        if (this.wrongs.has(key3(x, y, z))) return;
        const b = MC.Blocks.list[id], v = b && b.variants > 1 ? b.variants : 1;
        const k = id + ':' + (v > 1 ? d % v : 0);
        need.set(k, (need.get(k) || 0) + 1);
      });
      const stock = this.game.building ? this.game.building.stock() : new Map();
      const out = [];
      for (const [k, n] of need) {
        const [id, data] = k.split(':').map(Number);
        out.push({ id, data, need: n, have: stock.get(k) || 0, name: MC.Items.itemName(id, data) });
      }
      out.sort((a, b) => (b.need - b.have) - (a.need - a.have) || b.need - a.need);
      return out;
    }

    // Клетка голограммы на луче взгляда в пределах досягаемости, ближе блока под прицелом
    easyTarget() {
      const g = this.game, p = g.player, w = g.world;
      if (g.dead) return null;
      const reach = MC.Building.reachOf(g);
      const o = [p.x, p.eyeY, p.z], d = p.lookDir();
      let x = Math.floor(o[0]), y = Math.floor(o[1]), z = Math.floor(o[2]);
      const step = d.map((v) => (v > 0 ? 1 : v < 0 ? -1 : 0));
      const tDelta = d.map((v) => (v !== 0 ? Math.abs(1 / v) : Infinity));
      const tMax = [0, 1, 2].map((i) => (d[i] === 0 ? Infinity : d[i] > 0 ? ([x, y, z][i] + 1 - o[i]) / d[i] : (o[i] - [x, y, z][i]) / -d[i]));
      for (let i = 0; i < 24; i++) {
        const id = this.ghost.getId(x, y, z);
        if (id && !this.wrongs.has(key3(x, y, z))) return [x, y, z, id, this.ghost.getData(x, y, z)];
        const cur = w.getId(x, y, z);
        if (cur && !MC.Blocks.list[cur].replaceable) return null;
        let a = 0;
        if (tMax[1] < tMax[a]) a = 1;
        if (tMax[2] < tMax[a]) a = 2;
        if (tMax[a] > reach) return null;
        if (a === 0) x += step[0]; else if (a === 1) y += step[1]; else z += step[2];
        tMax[a] += tDelta[a];
      }
      return null;
    }

    // Easy Place (как в Litematica): нажатие «использовать» на голограмме ставит нужный блок с нужным поворотом
    easyUse() {
      const c = this.easyTarget();
      if (!c) return false;
      const g = this.game, w = g.world, eb = g.building;
      const [x, y, z, id, d] = c;
      if (g.mode === 'mp') {
        if (eb.netKeys.has(key3(x, y, z))) return true;
        eb.netEnqueue([{ x, y, z, oid: w.getId(x, y, z), odata: w.getData(x, y, z), nid: id, ndata: d }]);
        g.player.swingTime = 1;
        return true;
      }
      const r = this.placeSP(x, y, z, id, d, g.gamemode === 0 ? eb.stock() : null);
      if (r === true) { MC.Sound.block(w.getId(x, y, z), 'place', x + 0.5, y + 0.5, z + 0.5); g.player.swingTime = 1; }
      else if (r) g.ui.setPopup('Нет в инвентаре: ' + r);
      return true;
    }

    // Установка блока схемы в одиночной игре: true — поставлен, строка — чего не хватает, false — нельзя
    placeSP(x, y, z, id, d, stock) {
      const g = this.game, w = g.world, eb = g.building;
      if (!MC.Blocks.list[w.getId(x, y, z)].replaceable) return false;
      if (!eb.canPlaceAt(x, y, z, id)) return false;
      let pid = id, pd = d, sub = false;
      if (stock) {
        const b = MC.Blocks.list[id], v = b.variants > 1 ? b.variants : 1;
        let k = id + ':' + (v > 1 ? d % v : 0);
        if (!(stock.get(k) > 0)) {
          const s2 = eb.findSubstitute(id, d, stock);
          if (!s2) return MC.Items.itemName(id, v > 1 ? d % v : 0);
          pid = s2.id; pd = s2.data; k = s2.key; sub = true;
        }
        const [iid, idata] = k.split(':').map(Number);
        if (g.sinv.remove(iid, idata, 1) < 1) return false;
        stock.set(k, stock.get(k) - 1);
      }
      if (g.scripts && g.scripts.emit('blockPlace', { x, y, z, id: pid, data: pd }) === false) return false;
      if (sub) this.subs.set(key3(x, y, z), { id: pid, placed: false });
      w.setBlock(x, y, z, pid, pd);
      return true;
    }

    // Принтер: ставит недостающие блоки в радиусе досягаемости (в выживании — из инвентаря, при нехватке — замена по настройке)
    print() {
      const g = this.game, p = g.player, w = g.world;
      if (g.dead || this.gather) return;
      const reach = this.printRange(), per = g.gamemode === 1 ? 6 : 2;
      const ex = p.x, ey = p.eyeY, ez = p.z;
      const r = Math.ceil(reach);
      const cands = [];
      for (let x = Math.floor(ex) - r; x <= Math.floor(ex) + r; x++) for (let y = Math.floor(ey) - r; y <= Math.floor(ey) + r; y++) for (let z = Math.floor(ez) - r; z <= Math.floor(ez) + r; z++) {
        const id = this.ghost.getId(x, y, z);
        if (!id) continue;
        const d2 = (x + 0.5 - ex) ** 2 + (y + 0.5 - ey) ** 2 + (z + 0.5 - ez) ** 2;
        if (d2 > reach * reach) continue;
        cands.push([y * 1000 + d2, x, y, z, id, this.ghost.getData(x, y, z)]);
      }
      // Снизу вверх, затем ближние: у каждого блока появляется опора
      cands.sort((a, b) => a[0] - b[0]);
      const eb = g.building;
      // На сервере принтер отдаёт блоки в очередь строительства: она ставит их пакетами, как игрок
      if (g.mode === 'mp') {
        const ops = [];
        for (const [, x, y, z, id, d] of cands) {
          if (!MC.Blocks.list[w.getId(x, y, z)].replaceable || eb.netKeys.has(x + ',' + y + ',' + z)) continue;
          ops.push({ x, y, z, oid: w.getId(x, y, z), odata: w.getData(x, y, z), nid: id, ndata: d });
        }
        if (ops.length) eb.netEnqueue(ops);
        this.printMsg = '';
        return;
      }
      let placed = 0, missing = null;
      const stock = g.gamemode === 0 ? eb.stock() : null;
      for (const [, x, y, z, id, d] of cands) {
        if (placed >= per) break;
        const res = this.placeSP(x, y, z, id, d, stock);
        if (res === true) {
          if (placed === 0) MC.Sound.block(w.getId(x, y, z), 'place', x + 0.5, y + 0.5, z + 0.5);
          placed++;
        } else if (res) missing = missing || res;
      }
      if (placed) p.swingTime = 1;
      this.printMsg = missing && !placed ? 'нет в инвентаре: ' + missing : '';
    }

    // Дальность принтера: настройка (0 — вся досягаемость), но не дальше, чем примет сервер
    printRange() {
      const max = MC.Building.reachOf(this.game), r = +this.game.building.cfg.printRange || 0;
      return r > 0 ? Math.min(r, max) : max;
    }

    // ---------- Сначала блоки в инвентарь, потом стройка ----------
    // Чего не хватает в инвентаре: «id:data» → количество (в творческом режиме ничего)
    missing() {
      const out = new Map();
      if (this.game.gamemode === 1) return out;
      for (const m of this.materials()) if (m.need > m.have) out.set(m.id + ':' + m.data, m.need - m.have);
      return out;
    }

    // Запуск принтера или постройки целиком: сначала сбор блоков, затем стройка (then: 'print' | 'all')
    start(then) {
      const g = this.game;
      if (!this.s) return;
      if (g.gamemode === 1) {
        if (g.mode === 'sp') this.fillHotbar();
        this.afterGather(then, '');
        return;
      }
      if (g.mode === 'sp') {
        const n = this.pullChestsSP();
        this.afterGather(then, n ? 'Из сундуков взято блоков: ' + n : '');
        return;
      }
      // Сервер: открываем сундуки рядом обычным нажатием и забираем нужное, как игрок
      this.gather = { then, list: this.chestsNear(), i: 0, t: 0, taken: 0, behind: 0 };
      this.printer = false;
    }

    afterGather(then, note) {
      const g = this.game;
      this.gather = null;
      const miss = this.missing();
      let msg = note;
      if (miss.size) {
        const names = [...miss].slice(0, 3).map(([k, n]) => { const [id, d] = k.split(':').map(Number); return MC.Items.itemName(id, d) + ' ×' + n; });
        msg = (msg ? msg + '. ' : '') + '§eНе хватает: ' + names.join(', ') + (miss.size > 3 ? ' и ещё ' + (miss.size - 3) : '');
      } else if (g.gamemode === 0) msg = (msg ? msg + '. ' : '') + 'Все блоки для схемы есть';
      if (msg) g.ui.setPopup(msg);
      if (then === 'print') this.printer = true;
      else if (then === 'all') this.buildAllNow();
    }

    // Творческий режим: нужные блоки на панель быстрого доступа (самые нужные — первыми)
    fillHotbar() {
      const g = this.game, mats = this.materials();
      for (let i = 0; i < 9 && i < mats.length; i++) g.sinv.slots[i] = { id: mats[i].id, data: mats[i].data, count: 64 };
    }

    // Одиночная игра: недостающие блоки из сундуков в радиусе 8 блоков
    pullChestsSP() {
      const g = this.game, p = g.player, w = g.world;
      const miss = this.missing();
      if (!miss.size || !g.record.containers) return 0;
      let taken = 0;
      for (const key of Object.keys(g.record.containers)) {
        const [x, y, z] = key.split(',').map(Number);
        const id = w.getId(x, y, z);
        if (id !== 54 && id !== 146) continue;
        if ((x + 0.5 - p.x) ** 2 + (y + 0.5 - p.y) ** 2 + (z + 0.5 - p.z) ** 2 > 64) continue;
        const slots = g.record.containers[key];
        for (let i = 0; i < slots.length; i++) {
          const it = slots[i];
          if (!it || !it.id) continue;
          const k = itemKey(it.id, it.data), n = miss.get(k);
          if (!(n > 0)) continue;
          const want = Math.min(n, it.count);
          const moved = want - g.sinv.add({ id: it.id, data: it.data, count: want });
          if (!moved) continue;
          it.count -= moved;
          if (it.count <= 0) slots[i] = null;
          miss.set(k, n - moved);
          taken += moved;
        }
      }
      return taken;
    }

    // Сундуки в досягаемости на сервере, ближние первыми; у большого сундука одна половина
    chestsNear() {
      const g = this.game, p = g.player, w = g.world, reach = MC.Building.reachOf(g);
      const r = Math.ceil(reach), out = [], seen = new Set();
      for (let x = Math.floor(p.x) - r; x <= Math.floor(p.x) + r; x++) for (let y = Math.floor(p.eyeY) - r; y <= Math.floor(p.eyeY) + r; y++) for (let z = Math.floor(p.z) - r; z <= Math.floor(p.z) + r; z++) {
        const id = w.getId(x, y, z);
        if (id !== 54 && id !== 146) continue;
        const d2 = (x + 0.5 - p.x) ** 2 + (y + 0.5 - p.eyeY) ** 2 + (z + 0.5 - p.z) ** 2;
        if (d2 > reach * reach) continue;
        out.push({ x, y, z, id, d2 });
      }
      out.sort((a, b) => a.d2 - b.d2);
      return out.filter((c) => {
        if ([[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dz]) => seen.has((c.x + dx) + ',' + c.y + ',' + (c.z + dz)) && w.getId(c.x + dx, c.y, c.z + dz) === c.id)) return false;
        seen.add(c.x + ',' + c.y + ',' + c.z);
        return true;
      });
    }

    // Сервер: по одному сундуку — открыть, забрать нужное (это делает окно сундука), закрыть, следующий
    gatherStep() {
      const g = this.game, gt = this.gather, p = g.player, now = performance.now();
      if (g.invScreen || now < gt.t) return;
      if (!this.missing().size || gt.i >= gt.list.length) {
        this.afterGather(gt.then, (gt.taken ? 'Из сундуков взято блоков: ' + gt.taken : '') + (gt.behind && this.missing().size ? (gt.taken ? '. ' : '') + 'Повернитесь к сундукам за спиной (' + gt.behind + ') и запустите ещё раз' : ''));
        return;
      }
      const c = gt.list[gt.i++];
      // Сервер открывает сундук только перед игроком (как проверяет Nukkit)
      const yr = p.yaw * Math.PI / 180;
      if (-Math.sin(yr) * (c.x + 0.5 - p.x) + Math.cos(yr) * (c.z + 0.5 - p.z) < -0.4) { gt.behind++; return; }
      if (g.world.getId(c.x, c.y, c.z) !== c.id) return;
      this.autoTakeUntil = now + 2500;
      g.client.sendUseItem(c.x, c.y, c.z, 1, 0.5, 1, 0.5, p.x, p.eyeY, p.z, g.selected, g.heldItem(), c.id);
      g.client.sendSwing();
      p.swingTime = 1;
      gt.t = now + 3000;
    }

    // Окно сундука открылось по запросу сбора: вызывает экран сундука
    takenFromChest(n) {
      this.autoTakeUntil = 0;
      if (!this.gather) return;
      this.gather.taken += n;
      this.gather.t = performance.now() + 500;
    }

    // Все недостающие блоки сразу (через историю строительства, можно отменить)
    buildAll() { this.start('all'); }

    buildAllNow() {
      const g = this.game, w = g.world, ops = [];
      this.forGhost((x, y, z, id, d) => {
        if (!g.building.canPlaceAt(x, y, z, id)) return;
        ops.push({ x, y, z, oid: w.getId(x, y, z), odata: w.getData(x, y, z), nid: id, ndata: d });
      });
      ops.sort((a, b) => a.y - b.y);
      g.building.applyNew(ops, 'Построено по схеме');
    }

    // Исправление ошибок (творческий режим): чужие блоки и неверно повёрнутые заменяются нужными.
    // На сервере их можно только сломать — потом принтер или Easy Place поставят правильные
    fixErrors() {
      const g = this.game, w = g.world, ops = [];
      for (const k of [...this.wrongs, ...this.rots]) {
        const [x, y, z] = k.split(',').map(Number);
        const t = this.targetAt(x, y, z);
        const oid = w.getId(x, y, z);
        if (!t || !oid || MC.Blocks.list[oid].hardness < 0) continue;
        ops.push({ x, y, z, oid, odata: w.getData(x, y, z), nid: g.mode === 'mp' ? 0 : t[0], ndata: g.mode === 'mp' ? 0 : t[1] });
      }
      if (!ops.length) return 0;
      ops.sort((a, b) => a.y - b.y);
      g.building.applyNew(ops, g.mode === 'mp' ? 'Сломано мешающих' : 'Исправлено по схеме');
      return ops.length;
    }

    progress() {
      const st = this.stats, total = st.ok + st.left + st.wrong + st.rot;
      return total ? Math.floor(st.ok * 100 / total) : 100;
    }

    hint() {
      if (!this.s) return '';
      const st = this.stats;
      return 'Схема «' + this.s.name + '»: ' + this.progress() + '% · осталось ' + st.left + (st.wrong ? ' · §cне те блоки ' + st.wrong + '§r' : '') + (st.rot ? ' · §6не тот поворот ' + st.rot + '§r' : '') +
        (this.layer >= 0 ? ' · слой ' + (this.layer + 1) + '/' + this.s.h + (this.layerMode === 'below' ? ' и ниже' : this.layerMode === 'auto' ? ' (по ходу)' : '') : '') +
        (this.easyPlace ? ' · Easy Place' : '') +
        (this.gather ? ' · беру блоки из сундуков (' + this.gather.i + '/' + this.gather.list.length + ')' : '') +
        (this.printer ? ' · принтер включён' + (this.printMsg ? ' (' + this.printMsg + ')' : '') : '');
    }
  }

  // Количество в стаках: 130 → «2 ст. + 2»
  function stacks(n) {
    if (n < 64) return String(n);
    const s = Math.floor(n / 64), r = n % 64;
    return n + ' (' + s + ' ст.' + (r ? ' + ' + r : '') + ')';
  }

  MC.Schematics = { parse, encode, fromClip, list, addFile, store, remove, exportFile, stacks, itemKey, View };
})();
