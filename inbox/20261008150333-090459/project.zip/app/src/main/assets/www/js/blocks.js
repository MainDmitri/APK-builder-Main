// Таблица блоков Minecraft PE 1.1 (ID 0-255): текстуры из атласа APK, форма, прозрачность, прочность
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const A = window.MC_ASSETS;

  const MISSING = A.blockTiles.missing_tile;
  const T = (name) => (A.blockTiles[name] !== undefined ? A.blockTiles[name] : MISSING);

  const COLORS = ['white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink', 'gray', 'silver', 'cyan', 'purple', 'blue', 'brown', 'green', 'red', 'black'];
  const COLORS_RU = ['Белый', 'Оранжевый', 'Пурпурный', 'Голубой', 'Жёлтый', 'Лаймовый', 'Розовый', 'Серый', 'Светло-серый', 'Бирюзовый', 'Фиолетовый', 'Синий', 'Коричневый', 'Зелёный', 'Красный', 'Чёрный'];
  const WOOD = ['oak', 'spruce', 'birch', 'jungle', 'acacia', 'big_oak'];
  const WOOD_RU = ['дуб', 'ель', 'берёза', 'тропическое дерево', 'акация', 'тёмный дуб'];

  // Грани: 0 низ, 1 верх, 2 север (-Z), 3 юг (+Z), 4 запад (-X), 5 восток (+X)
  const FACE = { DOWN: 0, UP: 1, NORTH: 2, SOUTH: 3, WEST: 4, EAST: 5 };

  const blocks = new Array(256);

  function def(id, o) {
    const b = {
      id,
      name: o.name || ('Блок #' + id),
      shape: o.shape || 'cube',
      solid: o.solid !== undefined ? o.solid : true,
      opaque: o.opaque !== undefined ? o.opaque : (o.shape || 'cube') === 'cube' && !o.layer,
      layer: o.layer || 'solid',
      hardness: o.hardness !== undefined ? o.hardness : 1,
      tool: o.tool || null,
      hand: o.hand !== undefined ? o.hand : true,
      replaceable: !!o.replaceable,
      climbable: !!o.climbable,
      liquid: !!o.liquid,
      variants: o.variants || 1,
      names: o.names || null,
      tex: typeof o.tex === 'function' ? o.tex : texSpec(o.tex),
      boxes: o.boxes || null,
      drop: o.drop
    };
    blocks[id] = b;
    return b;
  }

  // tex: 'name' | {top, bottom, side} | {top, bottom, north, south, west, east}
  function texSpec(spec) {
    if (spec === undefined) return () => MISSING;
    if (typeof spec === 'string') { const t = T(spec); return () => t; }
    const top = T(spec.top || spec.side), bottom = T(spec.bottom || spec.top || spec.side), side = T(spec.side || spec.top);
    const n = spec.north ? T(spec.north) : side, s = spec.south ? T(spec.south) : side;
    const w = spec.west ? T(spec.west) : side, e = spec.east ? T(spec.east) : side;
    const arr = [bottom, top, n, s, w, e];
    return (data, face) => arr[face];
  }

  const byData = (list) => {
    const tiles = list.map((n) => T(n));
    return (data) => (tiles[data] !== undefined ? tiles[data] : tiles[0]);
  };

  // Ось бревна/колонны: (data >> 2) & 3 — 0 вертикально, 1 по X, 2 по Z, 3 кора со всех сторон
  function axisTex(sideNames, topNames, typeMask) {
    const sides = sideNames.map(T), tops = topNames.map(T);
    return (data, face) => {
      const type = data & typeMask;
      const axis = (data >> 2) & 3;
      const side = sides[type] !== undefined ? sides[type] : sides[0];
      const top = tops[type] !== undefined ? tops[type] : tops[0];
      if (axis === 3) return side;
      if (axis === 0) return face <= 1 ? top : side;
      if (axis === 1) return face >= 4 ? top : side;
      return face === 2 || face === 3 ? top : side;
    };
  }

  // Блоки с лицевой стороной (печь, тыква, сундук): data 2..5 = север/юг/запад/восток
  function facingTex(front, side, top, bottom) {
    const f = T(front), s = T(side), t = T(top || side), b = T(bottom || top || side);
    return (data, face) => {
      if (face === 0) return b;
      if (face === 1) return t;
      const dir = data >= 2 && data <= 5 ? data : 3;
      return face === dir ? f : s;
    };
  }

  const box = (x0, y0, z0, x1, y1, z1) => [x0, y0, z0, x1, y1, z1];
  const FULL = [box(0, 0, 0, 1, 1, 1)];

  // --------- Формы с несколькими параллелепипедами ---------
  function slabBoxes(data) { return data & 8 ? [box(0, 0.5, 0, 1, 1, 1)] : [box(0, 0, 0, 1, 0.5, 1)]; }

  function stairBoxes(data) {
    const up = (data & 4) !== 0;
    const base = up ? box(0, 0.5, 0, 1, 1, 1) : box(0, 0, 0, 1, 0.5, 1);
    const y0 = up ? 0 : 0.5, y1 = up ? 0.5 : 1;
    let step;
    switch (data & 3) {
      case 0: step = box(0.5, y0, 0, 1, y1, 1); break;
      case 1: step = box(0, y0, 0, 0.5, y1, 1); break;
      case 2: step = box(0, y0, 0.5, 1, y1, 1); break;
      default: step = box(0, y0, 0, 1, y1, 0.5); break;
    }
    return [base, step];
  }

  function connects(w, x, y, z, selfFamily) {
    const id = w.getId(x, y, z);
    const b = blocks[id];
    if (!b) return false;
    if (selfFamily(id)) return true;
    return b.opaque;
  }

  const isFenceLike = (id) => id === 85 || id === 113 || (id >= 183 && id <= 187) || id === 107;
  const isPaneLike = (id) => id === 101 || id === 102 || id === 160;
  const isWall = (id) => id === 139;

  function fenceBoxes(data, get, x, y, z, collide) {
    const h = collide ? 1.5 : 1;
    const out = [box(0.375, 0, 0.375, 0.625, h, 0.625)];
    if (!get) return out;
    if (connects(get, x, y, z - 1, isFenceLike)) out.push(box(0.4375, 0.375, 0, 0.5625, collide ? h : 0.9375, 0.375));
    if (connects(get, x, y, z + 1, isFenceLike)) out.push(box(0.4375, 0.375, 0.625, 0.5625, collide ? h : 0.9375, 1));
    if (connects(get, x - 1, y, z, isFenceLike)) out.push(box(0, 0.375, 0.4375, 0.375, collide ? h : 0.9375, 0.5625));
    if (connects(get, x + 1, y, z, isFenceLike)) out.push(box(0.625, 0.375, 0.4375, 1, collide ? h : 0.9375, 0.5625));
    return out;
  }

  function wallBoxes(data, get, x, y, z, collide) {
    const h = collide ? 1.5 : 1;
    const out = [box(0.25, 0, 0.25, 0.75, h, 0.75)];
    if (!get) return out;
    const hh = collide ? 1.5 : 0.8125;
    if (connects(get, x, y, z - 1, isWall)) out.push(box(0.3125, 0, 0, 0.6875, hh, 0.25));
    if (connects(get, x, y, z + 1, isWall)) out.push(box(0.3125, 0, 0.75, 0.6875, hh, 1));
    if (connects(get, x - 1, y, z, isWall)) out.push(box(0, 0, 0.3125, 0.25, hh, 0.6875));
    if (connects(get, x + 1, y, z, isWall)) out.push(box(0.75, 0, 0.3125, 1, hh, 0.6875));
    return out;
  }

  function paneBoxes(data, get, x, y, z) {
    const out = [box(0.4375, 0, 0.4375, 0.5625, 1, 0.5625)];
    if (!get) { out.push(box(0, 0, 0.4375, 1, 1, 0.5625)); return out; }
    const n = connects(get, x, y, z - 1, isPaneLike), s = connects(get, x, y, z + 1, isPaneLike);
    const w = connects(get, x - 1, y, z, isPaneLike), e = connects(get, x + 1, y, z, isPaneLike);
    if (!n && !s && !w && !e) { out.push(box(0, 0, 0.4375, 1, 1, 0.5625)); out.push(box(0.4375, 0, 0, 0.5625, 1, 1)); return out; }
    if (n) out.push(box(0.4375, 0, 0, 0.5625, 1, 0.4375));
    if (s) out.push(box(0.4375, 0, 0.5625, 0.5625, 1, 1));
    if (w) out.push(box(0, 0, 0.4375, 0.4375, 1, 0.5625));
    if (e) out.push(box(0.5625, 0, 0.4375, 1, 1, 0.5625));
    return out;
  }

  function doorBoxes(data, get, x, y, z) {
    let lower = data;
    if (data & 8) {
      lower = get ? get.getData(x, y - 1, z) : 0;
    }
    const dir = lower & 3;
    const open = (lower & 4) !== 0;
    const t = 0.1875;
    const panels = [box(0, 0, 0, t, 1, 1), box(0, 0, 0, 1, 1, t), box(1 - t, 0, 0, 1, 1, 1), box(0, 0, 1 - t, 1, 1, 1)];
    return [panels[open ? (dir + 1) & 3 : dir]];
  }

  function trapdoorBoxes(data) {
    const t = 0.1875;
    if (data & 8) {
      switch (data & 3) {
        case 0: return [box(0, 0, 1 - t, 1, 1, 1)];
        case 1: return [box(0, 0, 0, 1, 1, t)];
        case 2: return [box(1 - t, 0, 0, 1, 1, 1)];
        default: return [box(0, 0, 0, t, 1, 1)];
      }
    }
    return data & 4 ? [box(0, 1 - t, 0, 1, 1, 1)] : [box(0, 0, 0, 1, t, 1)];
  }

  function wallAttachBoxes(data) {
    const t = 0.125;
    switch (data) {
      case 2: return [box(0, 0, 1 - t, 1, 1, 1)];
      case 3: return [box(0, 0, 0, 1, 1, t)];
      case 4: return [box(1 - t, 0, 0, 1, 1, 1)];
      default: return [box(0, 0, 0, t, 1, 1)];
    }
  }

  function vineBoxes(data) {
    const t = 0.0625;
    const out = [];
    if (data & 1) out.push(box(0, 0, 1 - t, 1, 1, 1));
    if (data & 2) out.push(box(0, 0, 0, t, 1, 1));
    if (data & 4) out.push(box(0, 0, 0, 1, 1, t));
    if (data & 8) out.push(box(1 - t, 0, 0, 1, 1, 1));
    if (out.length === 0) out.push(box(0, 1 - t, 0, 1, 1, 1));
    return out;
  }

  const fixed = (...b) => () => b;
  // Сундук: рядом такой же — половины сливаются в один большой сундук
  const chestBoxes = (id) => (data, w, x, y, z) => {
    let x0 = 0.0625, z0 = 0.0625, x1 = 0.9375, z1 = 0.9375;
    if (w) {
      if (w.getId(x - 1, y, z) === id) x0 = 0;
      if (w.getId(x + 1, y, z) === id) x1 = 1;
      if (w.getId(x, y, z - 1) === id) z0 = 0;
      if (w.getId(x, y, z + 1) === id) z1 = 1;
    }
    return [box(x0, 0, z0, x1, 0.875, z1)];
  };

  // ----------- Определения -----------
  def(0, { name: 'Воздух', shape: 'none', solid: false, opaque: false, replaceable: true, hardness: 0 });
  def(1, { name: 'Камень', names: ['Камень', 'Гранит', 'Полированный гранит', 'Диорит', 'Полированный диорит', 'Андезит', 'Полированный андезит'], variants: 7, hardness: 1.5, tool: 'pickaxe', hand: false,
    tex: byData(['stone', 'stone_granite', 'stone_granite_smooth', 'stone_diorite', 'stone_diorite_smooth', 'stone_andesite', 'stone_andesite_smooth']) });
  def(2, { name: 'Трава', hardness: 0.6, tool: 'shovel', tex: { top: 'grass_top', bottom: 'dirt', side: 'grass_side' } });
  def(3, { name: 'Земля', variants: 2, names: ['Земля', 'Грубая земля'], hardness: 0.5, tool: 'shovel', tex: 'dirt' });
  def(4, { name: 'Булыжник', hardness: 2, tool: 'pickaxe', hand: false, tex: 'cobblestone' });
  def(5, { name: 'Доски', variants: 6, names: WOOD_RU.map((w) => 'Доски (' + w + ')'), hardness: 2, tool: 'axe', tex: byData(WOOD.map((w) => 'planks_' + w)) });
  def(6, { name: 'Саженец', variants: 6, shape: 'cross', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: byData(['sapling_oak', 'sapling_spruce', 'sapling_birch', 'sapling_jungle', 'sapling_acacia', 'sapling_roofed_oak']) });
  def(7, { name: 'Коренная порода', hardness: -1, tex: 'bedrock' });
  def(8, { name: 'Вода', shape: 'liquid', solid: false, opaque: false, layer: 'translucent', liquid: true, replaceable: true, hardness: -1, tex: { top: 'water_still', side: 'water_flow' } });
  def(9, { name: 'Вода', shape: 'liquid', solid: false, opaque: false, layer: 'translucent', liquid: true, replaceable: true, hardness: -1, tex: { top: 'water_still', side: 'water_flow' } });
  def(10, { name: 'Лава', shape: 'liquid', solid: false, opaque: false, layer: 'solid', liquid: true, replaceable: true, hardness: -1, tex: { top: 'lava_still', side: 'lava_flow' } });
  def(11, { name: 'Лава', shape: 'liquid', solid: false, opaque: false, layer: 'solid', liquid: true, replaceable: true, hardness: -1, tex: { top: 'lava_still', side: 'lava_flow' } });
  def(12, { name: 'Песок', variants: 2, names: ['Песок', 'Красный песок'], hardness: 0.5, tool: 'shovel', tex: byData(['sand', 'red_sand']) });
  def(13, { name: 'Гравий', hardness: 0.6, tool: 'shovel', tex: 'gravel' });
  def(14, { name: 'Золотая руда', hardness: 3, tool: 'pickaxe', hand: false, tex: 'gold_ore' });
  def(15, { name: 'Железная руда', hardness: 3, tool: 'pickaxe', hand: false, tex: 'iron_ore' });
  def(16, { name: 'Угольная руда', hardness: 3, tool: 'pickaxe', hand: false, tex: 'coal_ore' });
  def(17, { name: 'Бревно', variants: 4, names: WOOD_RU.slice(0, 4).map((w) => 'Бревно (' + w + ')'), hardness: 2, tool: 'axe',
    tex: axisTex(['log_oak', 'log_spruce', 'log_birch', 'log_jungle'], ['log_oak_top', 'log_spruce_top', 'log_birch_top', 'log_jungle_top'], 3) });
  def(18, { name: 'Листва', variants: 4, opaque: false, layer: 'cutout', hardness: 0.2, tool: 'shears',
    tex: (d) => [T('leaves_oak'), T('leaves_spruce'), T('leaves_birch'), T('leaves_jungle')][d & 3] });
  def(19, { name: 'Губка', variants: 2, hardness: 0.6, tex: byData(['sponge', 'sponge_wet']) });
  def(20, { name: 'Стекло', opaque: false, layer: 'cutout', hardness: 0.3, tex: 'glass' });
  def(21, { name: 'Лазуритовая руда', hardness: 3, tool: 'pickaxe', hand: false, tex: 'lapis_ore' });
  def(22, { name: 'Лазуритовый блок', hardness: 3, tool: 'pickaxe', hand: false, tex: 'lapis_block' });
  def(23, { name: 'Раздатчик', hardness: 3.5, tool: 'pickaxe', hand: false, tex: (d, f) => {
    const dir = d & 7; if (f === dir) return dir <= 1 ? T('dispenser_front_vertical') : T('dispenser_front_horizontal'); return f <= 1 ? T('furnace_top') : T('furnace_side'); } });
  def(24, { name: 'Песчаник', variants: 3, names: ['Песчаник', 'Резной песчаник', 'Гладкий песчаник'], hardness: 0.8, tool: 'pickaxe', hand: false,
    tex: (d, f) => f === 1 ? T('sandstone_top') : f === 0 ? T('sandstone_bottom') : [T('sandstone_normal'), T('sandstone_carved'), T('sandstone_smooth')][d & 3] || T('sandstone_normal') });
  def(25, { name: 'Нотный блок', hardness: 0.8, tool: 'axe', tex: 'noteblock' });
  def(26, { name: 'Кровать', shape: 'boxes', opaque: false, hardness: 0.2, boxes: fixed(box(0, 0, 0, 1, 0.5625, 1)),
    tex: (d, f) => { const head = (d & 8) !== 0; if (f === 1) return T(head ? 'bed_head_top' : 'bed_feet_top'); if (f === 0) return T('planks_oak'); return T(head ? 'bed_head_side' : 'bed_feet_side'); } });
  def(27, { name: 'Энергорельсы', shape: 'flat', solid: false, opaque: false, layer: 'cutout', hardness: 0.7, tex: (d) => T(d & 8 ? 'rail_golden_powered' : 'rail_golden') });
  def(28, { name: 'Нажимные рельсы', shape: 'flat', solid: false, opaque: false, layer: 'cutout', hardness: 0.7, tex: (d) => T(d & 8 ? 'rail_detector_powered' : 'rail_detector') });
  def(29, { name: 'Липкий поршень', hardness: 0.5, tex: { top: 'piston_top_sticky', bottom: 'piston_bottom', side: 'piston_side' } });
  def(30, { name: 'Паутина', shape: 'cross', solid: false, opaque: false, layer: 'cutout', hardness: 4, tool: 'sword', tex: 'web' });
  def(31, { name: 'Трава', variants: 3, names: ['Сухой куст', 'Высокая трава', 'Папоротник'], shape: 'cross', solid: false, opaque: false, layer: 'cutout', replaceable: true, hardness: 0,
    tex: byData(['deadbush', 'tallgrass', 'fern']) });
  def(32, { name: 'Мёртвый куст', shape: 'cross', solid: false, opaque: false, layer: 'cutout', replaceable: true, hardness: 0, tex: 'deadbush' });
  def(33, { name: 'Поршень', hardness: 0.5, tex: { top: 'piston_top_normal', bottom: 'piston_bottom', side: 'piston_side' } });
  def(34, { name: 'Головка поршня', hardness: 0.5, tex: { top: 'piston_top_normal', side: 'piston_side' } });
  def(35, { name: 'Шерсть', variants: 16, names: COLORS_RU.map((c) => c + ' шерсть'), hardness: 0.8, tool: 'shears', tex: byData(COLORS.map((c) => 'wool_colored_' + c)) });
  def(37, { name: 'Одуванчик', shape: 'cross', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: 'flower_dandelion' });
  def(38, { name: 'Цветок', variants: 9, names: ['Мак', 'Синяя орхидея', 'Лук-резанец', 'Хоустония', 'Красный тюльпан', 'Оранжевый тюльпан', 'Белый тюльпан', 'Розовый тюльпан', 'Ромашка'],
    shape: 'cross', solid: false, opaque: false, layer: 'cutout', hardness: 0,
    tex: byData(['flower_rose', 'flower_blue_orchid', 'flower_allium', 'flower_houstonia', 'flower_tulip_red', 'flower_tulip_orange', 'flower_tulip_white', 'flower_tulip_pink', 'flower_oxeye_daisy']) });
  def(39, { name: 'Коричневый гриб', shape: 'cross', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: 'mushroom_brown' });
  def(40, { name: 'Красный гриб', shape: 'cross', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: 'mushroom_red' });
  def(41, { name: 'Золотой блок', hardness: 3, tool: 'pickaxe', hand: false, tex: 'gold_block' });
  def(42, { name: 'Железный блок', hardness: 5, tool: 'pickaxe', hand: false, tex: 'iron_block' });

  const SLAB_TOP = ['stone_slab_top', 'sandstone_top', 'planks_oak', 'cobblestone', 'brick', 'stonebrick', 'quartz_block_top', 'nether_brick'];
  const SLAB_SIDE = ['stone_slab_side', 'sandstone_normal', 'planks_oak', 'cobblestone', 'brick', 'stonebrick', 'quartz_block_side', 'nether_brick'];
  const slabTex = (d, f) => T((f <= 1 ? SLAB_TOP : SLAB_SIDE)[d & 7]);
  const SLAB_NAMES = ['Каменная', 'Песчаниковая', 'Деревянная', 'Булыжная', 'Кирпичная', 'Каменно-кирпичная', 'Кварцевая', 'Адская кирпичная'];
  def(43, { name: 'Двойная плита', variants: 8, hardness: 2, tool: 'pickaxe', hand: false, tex: slabTex });
  def(44, { name: 'Плита', variants: 8, names: SLAB_NAMES.map((n) => n + ' плита'), shape: 'boxes', opaque: false, hardness: 2, tool: 'pickaxe', hand: false, boxes: slabBoxes, tex: slabTex });
  def(45, { name: 'Кирпичи', hardness: 2, tool: 'pickaxe', hand: false, tex: 'brick' });
  def(46, { name: 'Динамит', hardness: 0, tex: { top: 'tnt_top', bottom: 'tnt_bottom', side: 'tnt_side' } });
  def(47, { name: 'Книжная полка', hardness: 1.5, tool: 'axe', tex: { top: 'planks_oak', side: 'bookshelf' } });
  def(48, { name: 'Замшелый булыжник', hardness: 2, tool: 'pickaxe', hand: false, tex: 'cobblestone_mossy' });
  def(49, { name: 'Обсидиан', hardness: 50, tool: 'pickaxe', hand: false, tex: 'obsidian' });
  def(50, { name: 'Факел', shape: 'torch', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: 'torch_on' });
  def(51, { name: 'Огонь', shape: 'cross', solid: false, opaque: false, layer: 'cutout', replaceable: true, hardness: 0, tex: 'fire_0' });
  def(52, { name: 'Рассадник монстров', opaque: false, layer: 'cutout', hardness: 5, tool: 'pickaxe', hand: false, tex: 'mob_spawner' });

  const STAIRS = [[53, 'planks_oak', 'Дубовые ступеньки'], [67, 'cobblestone', 'Булыжные ступеньки'], [108, 'brick', 'Кирпичные ступеньки'], [109, 'stonebrick', 'Каменно-кирпичные ступеньки'],
    [114, 'nether_brick', 'Ступеньки из адского кирпича'], [128, ['sandstone_top', 'sandstone_normal'], 'Песчаниковые ступеньки'], [134, 'planks_spruce', 'Еловые ступеньки'], [135, 'planks_birch', 'Берёзовые ступеньки'],
    [136, 'planks_jungle', 'Тропические ступеньки'], [156, ['quartz_block_top', 'quartz_block_side'], 'Кварцевые ступеньки'], [163, 'planks_acacia', 'Ступеньки из акации'],
    [164, 'planks_big_oak', 'Ступеньки из тёмного дуба'], [180, ['red_sandstone_top', 'red_sandstone_normal'], 'Ступеньки из красного песчаника'], [203, 'purpur_block', 'Пурпурные ступеньки']];
  for (const [id, t, n] of STAIRS) {
    const wood = typeof t === 'string' && t.startsWith('planks');
    def(id, { name: n, shape: 'boxes', opaque: false, hardness: 2, tool: wood ? 'axe' : 'pickaxe', hand: wood, boxes: stairBoxes,
      tex: Array.isArray(t) ? { top: t[0], side: t[1] } : t });
  }

  def(54, { name: 'Сундук', shape: 'boxes', opaque: false, hardness: 2.5, tool: 'axe', boxes: chestBoxes(54), tex: facingTex('chest_front', 'chest_side', 'chest_top') });
  def(55, { name: 'Редстоун', shape: 'flat', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: 'redstone_dust_cross' });
  def(56, { name: 'Алмазная руда', hardness: 3, tool: 'pickaxe', hand: false, tex: 'diamond_ore' });
  def(57, { name: 'Алмазный блок', hardness: 5, tool: 'pickaxe', hand: false, tex: 'diamond_block' });
  def(58, { name: 'Верстак', hardness: 2.5, tool: 'axe', tex: { top: 'crafting_table_top', bottom: 'planks_oak', side: 'crafting_table_side', north: 'crafting_table_front', south: 'crafting_table_front' } });
  def(59, { name: 'Пшеница', shape: 'crop', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: (d) => T('wheat_stage_' + Math.min(7, d & 7)) });
  def(60, { name: 'Грядка', shape: 'boxes', opaque: false, hardness: 0.6, tool: 'shovel', boxes: fixed(box(0, 0, 0, 1, 0.9375, 1)),
    tex: (d, f) => f === 1 ? T(d > 0 ? 'farmland_wet' : 'farmland_dry') : T('dirt') });
  def(61, { name: 'Печь', hardness: 3.5, tool: 'pickaxe', hand: false, tex: facingTex('furnace_front_off', 'furnace_side', 'furnace_top') });
  def(62, { name: 'Горящая печь', hardness: 3.5, tool: 'pickaxe', hand: false, tex: facingTex('furnace_front_on', 'furnace_side', 'furnace_top') });
  def(63, { name: 'Табличка', shape: 'boxes', solid: false, opaque: false, hardness: 1, tool: 'axe', boxes: fixed(box(0.25, 0, 0.25, 0.75, 1, 0.75)), tex: 'planks_oak' });
  def(65, { name: 'Лестница', shape: 'boxes', solid: false, opaque: false, layer: 'cutout', climbable: true, hardness: 0.4, tool: 'axe', boxes: wallAttachBoxes, tex: 'ladder' });
  def(66, { name: 'Рельсы', shape: 'flat', solid: false, opaque: false, layer: 'cutout', hardness: 0.7, tex: (d) => T(d >= 6 && d <= 9 ? 'rail_normal_turned' : 'rail_normal') });
  def(68, { name: 'Табличка на стене', shape: 'boxes', solid: false, opaque: false, hardness: 1, tool: 'axe', boxes: (d) => wallAttachBoxes(d).map((b) => [b[0], 0.25, b[2], b[3], 0.75, b[5]]), tex: 'planks_oak' });
  def(69, { name: 'Рычаг', shape: 'torch', solid: false, opaque: false, layer: 'cutout', hardness: 0.5, tex: 'lever' });
  def(70, { name: 'Каменная нажимная плита', shape: 'boxes', solid: false, opaque: false, hardness: 0.5, tool: 'pickaxe', hand: false, boxes: fixed(box(0.0625, 0, 0.0625, 0.9375, 0.0625, 0.9375)), tex: 'stone' });
  def(72, { name: 'Деревянная нажимная плита', shape: 'boxes', solid: false, opaque: false, hardness: 0.5, tool: 'axe', boxes: fixed(box(0.0625, 0, 0.0625, 0.9375, 0.0625, 0.9375)), tex: 'planks_oak' });
  def(73, { name: 'Редстоуновая руда', hardness: 3, tool: 'pickaxe', hand: false, tex: 'redstone_ore' });
  def(74, { name: 'Редстоуновая руда', hardness: 3, tool: 'pickaxe', hand: false, tex: 'redstone_ore' });
  def(75, { name: 'Редстоуновый факел', shape: 'torch', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: 'redstone_torch_off' });
  def(76, { name: 'Редстоуновый факел', shape: 'torch', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: 'redstone_torch_on' });
  def(77, { name: 'Каменная кнопка', shape: 'boxes', solid: false, opaque: false, hardness: 0.5, boxes: fixed(box(0.3125, 0.375, 0.3125, 0.6875, 0.625, 0.6875)), tex: 'stone' });
  def(78, { name: 'Снег', shape: 'boxes', opaque: false, replaceable: true, hardness: 0.1, tool: 'shovel', boxes: (d) => [box(0, 0, 0, 1, ((d & 7) + 1) / 8, 1)], tex: 'snow' });
  def(79, { name: 'Лёд', opaque: false, layer: 'translucent', hardness: 0.5, tool: 'pickaxe', tex: 'ice' });
  def(80, { name: 'Снежный блок', hardness: 0.2, tool: 'shovel', tex: 'snow' });
  def(81, { name: 'Кактус', shape: 'cactus', opaque: false, layer: 'cutout', hardness: 0.4, boxes: fixed(box(0.0625, 0, 0.0625, 0.9375, 1, 0.9375)), tex: { top: 'cactus_top', bottom: 'cactus_bottom', side: 'cactus_side' } });
  def(82, { name: 'Глина', hardness: 0.6, tool: 'shovel', tex: 'clay' });
  def(83, { name: 'Сахарный тростник', shape: 'cross', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: 'reeds' });
  def(84, { name: 'Проигрыватель', hardness: 2, tool: 'axe', tex: { top: 'jukebox_top', side: 'jukebox_side' } });
  def(85, { name: 'Забор', variants: 6, names: WOOD_RU.map((w) => 'Забор (' + w + ')'), shape: 'fence', opaque: false, hardness: 2, tool: 'axe', boxes: fenceBoxes, tex: byData(WOOD.map((w) => 'planks_' + w)) });
  const pumpkinTex = (front) => (d, f) => {
    if (f <= 1) return T('pumpkin_top');
    const map = [3, 4, 2, 5];
    return f === map[d & 3] ? T(front) : T('pumpkin_side');
  };
  def(86, { name: 'Тыква', hardness: 1, tool: 'axe', tex: pumpkinTex('pumpkin_face_off') });
  def(87, { name: 'Адский камень', hardness: 0.4, tool: 'pickaxe', hand: false, tex: 'netherrack' });
  def(88, { name: 'Песок душ', shape: 'boxes', opaque: true, hardness: 0.5, tool: 'shovel', boxes: fixed(box(0, 0, 0, 1, 0.875, 1)), tex: 'soul_sand' });
  def(89, { name: 'Светокамень', hardness: 0.3, tex: 'glowstone' });
  def(90, { name: 'Портал', shape: 'boxes', solid: false, opaque: false, layer: 'translucent', hardness: -1, boxes: (d) => [d === 2 ? box(0.375, 0, 0, 0.625, 1, 1) : box(0, 0, 0.375, 1, 1, 0.625)], tex: 'portal' });
  def(91, { name: 'Светильник Джека', hardness: 1, tool: 'axe', tex: pumpkinTex('pumpkin_face_on') });
  def(92, { name: 'Торт', shape: 'boxes', opaque: false, hardness: 0.5, boxes: (d) => [box(0.0625 + (d & 7) * 0.125, 0, 0.0625, 0.9375, 0.5, 0.9375)],
    tex: (d, f) => f === 1 ? T('cake_top') : f === 0 ? T('cake_bottom') : T('cake_side') });
  def(93, { name: 'Повторитель', shape: 'boxes', opaque: false, layer: 'cutout', hardness: 0, boxes: fixed(box(0, 0, 0, 1, 0.125, 1)), tex: (d, f) => f === 1 ? T('repeater_off') : T('stone_slab_top') });
  def(94, { name: 'Повторитель', shape: 'boxes', opaque: false, layer: 'cutout', hardness: 0, boxes: fixed(box(0, 0, 0, 1, 0.125, 1)), tex: (d, f) => f === 1 ? T('repeater_on') : T('stone_slab_top') });
  def(95, { name: 'Невидимая коренная порода', shape: 'none', opaque: false, hardness: -1 });
  def(96, { name: 'Люк', shape: 'boxes', opaque: false, layer: 'cutout', hardness: 3, tool: 'axe', boxes: trapdoorBoxes, tex: 'trapdoor' });
  def(97, { name: 'Блок с чешуйницей', hardness: 0.75, tex: byData(['stone', 'cobblestone', 'stonebrick', 'stonebrick_mossy', 'stonebrick_cracked', 'stonebrick_carved']) });
  def(98, { name: 'Каменные кирпичи', variants: 4, names: ['Каменные кирпичи', 'Замшелые каменные кирпичи', 'Потрескавшиеся каменные кирпичи', 'Резные каменные кирпичи'], hardness: 1.5, tool: 'pickaxe', hand: false,
    tex: byData(['stonebrick', 'stonebrick_mossy', 'stonebrick_cracked', 'stonebrick_carved']) });
  const mushroomTex = (skin) => (d, f) => {
    if (d === 0) return T('mushroom_block_inside');
    if (d === 15) return T('mushroom_block_skin_stem');
    if (d === 10) return f <= 1 ? T('mushroom_block_inside') : T('mushroom_block_skin_stem');
    if (d === 14) return T(skin);
    return f === 1 ? T(skin) : f === 0 ? T('mushroom_block_inside') : T(skin);
  };
  def(99, { name: 'Блок коричневого гриба', hardness: 0.2, tool: 'axe', tex: mushroomTex('mushroom_block_skin_brown') });
  def(100, { name: 'Блок красного гриба', hardness: 0.2, tool: 'axe', tex: mushroomTex('mushroom_block_skin_red') });
  def(101, { name: 'Железная решётка', shape: 'pane', opaque: false, layer: 'cutout', hardness: 5, tool: 'pickaxe', hand: false, boxes: paneBoxes, tex: 'iron_bars' });
  def(102, { name: 'Стеклянная панель', shape: 'pane', opaque: false, layer: 'cutout', hardness: 0.3, boxes: paneBoxes, tex: 'glass' });
  def(103, { name: 'Арбуз', hardness: 1, tool: 'axe', tex: { top: 'melon_top', side: 'melon_side' } });
  def(104, { name: 'Росток тыквы', shape: 'crop', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: 'pumpkin_stem_disconnected' });
  def(105, { name: 'Росток арбуза', shape: 'crop', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: 'melon_stem_disconnected' });
  def(106, { name: 'Лоза', shape: 'boxes', solid: false, opaque: false, layer: 'cutout', climbable: true, replaceable: true, hardness: 0.2, tool: 'shears', boxes: vineBoxes, tex: 'vine' });
  const gate = (id, wood, n) => def(id, { name: n, shape: 'boxes', opaque: false, hardness: 2, tool: 'axe',
    boxes: (d) => (d & 4) ? [] : (d & 1) ? [box(0.4375, 0.375, 0, 0.5625, 1, 1)] : [box(0, 0.375, 0.4375, 1, 1, 0.5625)], tex: 'planks_' + wood });
  gate(107, 'oak', 'Калитка'); gate(183, 'spruce', 'Еловая калитка'); gate(184, 'birch', 'Берёзовая калитка'); gate(185, 'jungle', 'Тропическая калитка'); gate(186, 'big_oak', 'Калитка из тёмного дуба'); gate(187, 'acacia', 'Калитка из акации');
  def(110, { name: 'Мицелий', hardness: 0.6, tool: 'shovel', tex: { top: 'mycelium_top', bottom: 'dirt', side: 'mycelium_side' } });
  def(111, { name: 'Кувшинка', shape: 'flat', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: 'waterlily' });
  def(112, { name: 'Адский кирпич', hardness: 2, tool: 'pickaxe', hand: false, tex: 'nether_brick' });
  def(113, { name: 'Забор из адского кирпича', shape: 'fence', opaque: false, hardness: 2, tool: 'pickaxe', hand: false, boxes: fenceBoxes, tex: 'nether_brick' });
  def(115, { name: 'Адский нарост', shape: 'crop', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: (d) => T('nether_wart_stage_' + Math.min(2, d >> 1)) });
  def(116, { name: 'Стол зачаровывания', shape: 'boxes', opaque: false, hardness: 5, tool: 'pickaxe', hand: false, boxes: fixed(box(0, 0, 0, 1, 0.75, 1)),
    tex: { top: 'enchanting_table_top', bottom: 'enchanting_table_bottom', side: 'enchanting_table_side' } });
  def(117, { name: 'Варочная стойка', shape: 'cross', solid: true, opaque: false, layer: 'cutout', hardness: 0.5, tex: 'brewing_stand' });
  def(118, { name: 'Котёл', shape: 'boxes', opaque: false, hardness: 2, tool: 'pickaxe', hand: false, boxes: fixed(box(0, 0, 0, 1, 1, 1)), tex: { top: 'cauldron_top', bottom: 'cauldron_bottom', side: 'cauldron_side' } });
  def(120, { name: 'Рамка портала Края', shape: 'boxes', opaque: false, hardness: -1, boxes: fixed(box(0, 0, 0, 1, 0.8125, 1)), tex: { top: 'endframe_top', bottom: 'end_stone', side: 'endframe_side' } });
  def(121, { name: 'Камень Края', hardness: 3, tool: 'pickaxe', hand: false, tex: 'end_stone' });
  def(122, { name: 'Яйцо дракона', shape: 'boxes', opaque: false, hardness: 3, boxes: fixed(box(0.0625, 0, 0.0625, 0.9375, 1, 0.9375)), tex: 'dragon_egg' });
  def(123, { name: 'Лампа', hardness: 0.3, tex: 'redstone_lamp_off' });
  def(124, { name: 'Лампа', hardness: 0.3, tex: 'redstone_lamp_on' });
  def(125, { name: 'Выбрасыватель', hardness: 3.5, tool: 'pickaxe', hand: false, tex: (d, f) => {
    const dir = d & 7; if (f === dir) return dir <= 1 ? T('dropper_front_vertical') : T('dropper_front_horizontal'); return f <= 1 ? T('furnace_top') : T('furnace_side'); } });
  def(126, { name: 'Активирующие рельсы', shape: 'flat', solid: false, opaque: false, layer: 'cutout', hardness: 0.7, tex: (d) => T(d & 8 ? 'rail_activator_powered' : 'rail_activator') });
  def(127, { name: 'Какао', shape: 'boxes', opaque: false, layer: 'cutout', hardness: 0.2, boxes: fixed(box(0.3125, 0.4375, 0.3125, 0.6875, 0.75, 0.6875)), tex: (d) => T('cocoa_stage_' + Math.min(2, d >> 2)) });
  def(129, { name: 'Изумрудная руда', hardness: 3, tool: 'pickaxe', hand: false, tex: 'emerald_ore' });
  def(130, { name: 'Сундук Края', shape: 'boxes', opaque: false, hardness: 22.5, tool: 'pickaxe', hand: false, boxes: fixed(box(0.0625, 0, 0.0625, 0.9375, 0.875, 0.9375)), tex: facingTex('ender_chest_front', 'ender_chest_side', 'ender_chest_top') });
  def(131, { name: 'Крюк', shape: 'torch', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: 'trip_wire_source' });
  def(132, { name: 'Натяжная нить', shape: 'flat', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: 'trip_wire' });
  def(133, { name: 'Изумрудный блок', hardness: 5, tool: 'pickaxe', hand: false, tex: 'emerald_block' });
  def(138, { name: 'Маяк', opaque: false, layer: 'cutout', hardness: 3, tex: 'beacon' });
  def(139, { name: 'Булыжная стена', variants: 2, shape: 'fence', opaque: false, hardness: 2, tool: 'pickaxe', hand: false, boxes: wallBoxes, tex: byData(['cobblestone', 'cobblestone_mossy']) });
  def(140, { name: 'Цветочный горшок', shape: 'boxes', opaque: false, hardness: 0, boxes: fixed(box(0.3125, 0, 0.3125, 0.6875, 0.375, 0.6875)), tex: 'flower_pot' });
  def(141, { name: 'Морковь', shape: 'crop', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: (d) => T('carrots_stage_' + Math.min(3, d >> 1)) });
  def(142, { name: 'Картофель', shape: 'crop', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: (d) => T('potatoes_stage_' + Math.min(3, d >> 1)) });
  def(143, { name: 'Деревянная кнопка', shape: 'boxes', solid: false, opaque: false, hardness: 0.5, boxes: fixed(box(0.3125, 0.375, 0.3125, 0.6875, 0.625, 0.6875)), tex: 'planks_oak' });
  def(144, { name: 'Голова', shape: 'boxes', opaque: false, hardness: 1, boxes: fixed(box(0.25, 0, 0.25, 0.75, 0.5, 0.75)), tex: 'soul_sand' });
  def(145, { name: 'Наковальня', shape: 'boxes', opaque: false, hardness: 5, tool: 'pickaxe', hand: false, boxes: fixed(box(0.125, 0, 0.125, 0.875, 1, 0.875)), tex: { top: 'anvil_top_damaged_0', side: 'anvil_base' } });
  def(146, { name: 'Сундук-ловушка', shape: 'boxes', opaque: false, hardness: 2.5, tool: 'axe', boxes: chestBoxes(146), tex: facingTex('trapped_chest_front', 'chest_side', 'chest_top') });
  def(147, { name: 'Золотая нажимная плита', shape: 'boxes', solid: false, opaque: false, hardness: 0.5, boxes: fixed(box(0.0625, 0, 0.0625, 0.9375, 0.0625, 0.9375)), tex: 'gold_block' });
  def(148, { name: 'Железная нажимная плита', shape: 'boxes', solid: false, opaque: false, hardness: 0.5, boxes: fixed(box(0.0625, 0, 0.0625, 0.9375, 0.0625, 0.9375)), tex: 'iron_block' });
  def(149, { name: 'Компаратор', shape: 'boxes', opaque: false, layer: 'cutout', hardness: 0, boxes: fixed(box(0, 0, 0, 1, 0.125, 1)), tex: (d, f) => f === 1 ? T('comparator_off') : T('stone_slab_top') });
  def(150, { name: 'Компаратор', shape: 'boxes', opaque: false, layer: 'cutout', hardness: 0, boxes: fixed(box(0, 0, 0, 1, 0.125, 1)), tex: (d, f) => f === 1 ? T('comparator_on') : T('stone_slab_top') });
  def(151, { name: 'Датчик дневного света', shape: 'boxes', opaque: false, hardness: 0.2, tool: 'axe', boxes: fixed(box(0, 0, 0, 1, 0.375, 1)), tex: { top: 'daylight_detector_top', side: 'daylight_detector_side' } });
  def(152, { name: 'Редстоуновый блок', hardness: 5, tool: 'pickaxe', hand: false, tex: 'redstone_block' });
  def(153, { name: 'Кварцевая руда', hardness: 3, tool: 'pickaxe', hand: false, tex: 'quartz_ore' });
  def(154, { name: 'Воронка', shape: 'boxes', opaque: false, hardness: 3, tool: 'pickaxe', hand: false, boxes: fixed(box(0, 0.625, 0, 1, 1, 1), box(0.25, 0.25, 0.25, 0.75, 0.625, 0.75)), tex: { top: 'hopper_top', side: 'hopper_outside' } });
  def(155, { name: 'Кварцевый блок', variants: 3, names: ['Кварцевый блок', 'Резной кварцевый блок', 'Кварцевая колонна'], hardness: 0.8, tool: 'pickaxe', hand: false,
    tex: (d, f) => {
      const t = d & 3;
      if (t === 1) return f <= 1 ? T('quartz_block_chiseled_top') : T('quartz_block_chiseled');
      if (t === 2) { const axis = (d >> 2) & 3; const cap = axis === 0 ? f <= 1 : axis === 1 ? f >= 4 : f === 2 || f === 3; return cap ? T('quartz_block_lines_top') : T('quartz_block_lines'); }
      return f === 1 ? T('quartz_block_top') : f === 0 ? T('quartz_block_bottom') : T('quartz_block_side');
    } });
  def(157, { name: 'Двойная деревянная плита', variants: 6, hardness: 2, tool: 'axe', tex: (d) => T('planks_' + WOOD[d & 7] ) });
  def(158, { name: 'Деревянная плита', variants: 6, names: WOOD_RU.map((w) => 'Плита (' + w + ')'), shape: 'boxes', opaque: false, hardness: 2, tool: 'axe', boxes: slabBoxes, tex: (d) => T('planks_' + (WOOD[d & 7] || 'oak')) });
  def(159, { name: 'Окрашенная терракота', variants: 16, names: COLORS_RU.map((c) => c + ' терракота'), hardness: 1.25, tool: 'pickaxe', hand: false, tex: byData(COLORS.map((c) => 'hardened_clay_stained_' + c)) });
  def(160, { name: 'Окрашенная стеклянная панель', variants: 16, shape: 'pane', opaque: false, layer: 'cutout', hardness: 0.3, boxes: paneBoxes, tex: 'glass' });
  def(161, { name: 'Листва', variants: 2, opaque: false, layer: 'cutout', hardness: 0.2, tool: 'shears', tex: (d) => [T('leaves_acacia'), T('leaves_big_oak')][d & 1] });
  def(162, { name: 'Бревно', variants: 2, names: ['Бревно (акация)', 'Бревно (тёмный дуб)'], hardness: 2, tool: 'axe', tex: axisTex(['log_acacia', 'log_big_oak'], ['log_acacia_top', 'log_big_oak_top'], 1) });
  def(165, { name: 'Блок слизи', opaque: false, layer: 'translucent', hardness: 0, tex: 'slime' });
  def(167, { name: 'Железный люк', shape: 'boxes', opaque: false, layer: 'cutout', hardness: 5, tool: 'pickaxe', hand: false, boxes: trapdoorBoxes, tex: 'iron_trapdoor' });
  def(168, { name: 'Призмарин', variants: 3, names: ['Призмарин', 'Тёмный призмарин', 'Призмариновые кирпичи'], hardness: 1.5, tool: 'pickaxe', hand: false, tex: byData(['prismarine_rough', 'prismarine_dark', 'prismarine_bricks']) });
  def(169, { name: 'Морской фонарь', hardness: 0.3, tex: 'sea_lantern' });
  def(170, { name: 'Сноп сена', hardness: 0.5, tex: axisTex(['hay_block_side'], ['hay_block_top'], 0) });
  def(171, { name: 'Ковёр', variants: 16, names: COLORS_RU.map((c) => c + ' ковёр'), shape: 'boxes', opaque: false, hardness: 0.1, boxes: fixed(box(0, 0, 0, 1, 0.0625, 1)), tex: byData(COLORS.map((c) => 'wool_colored_' + c)) });
  def(172, { name: 'Терракота', hardness: 1.25, tool: 'pickaxe', hand: false, tex: 'hardened_clay' });
  def(173, { name: 'Угольный блок', hardness: 5, tool: 'pickaxe', hand: false, tex: 'coal_block' });
  def(174, { name: 'Плотный лёд', hardness: 0.5, tool: 'pickaxe', tex: 'ice_packed' });
  const DP = [['double_plant_sunflower_bottom', 'double_plant_sunflower_top'], ['double_plant_syringa_bottom', 'double_plant_syringa_top'], ['double_plant_grass_bottom', 'double_plant_grass_top'],
    ['double_plant_fern_bottom', 'double_plant_fern_top'], ['double_plant_rose_bottom', 'double_plant_rose_top'], ['double_plant_paeonia_bottom', 'double_plant_paeonia_top']];
  def(175, { name: 'Высокое растение', variants: 6, names: ['Подсолнух', 'Сирень', 'Высокая трава', 'Большой папоротник', 'Розовый куст', 'Пион'], shape: 'cross', solid: false, opaque: false, layer: 'cutout', replaceable: true, hardness: 0,
    tex: (d, f, ctx) => { const top = (d & 8) !== 0; const kind = top && ctx ? ctx.world.getData(ctx.x, ctx.y - 1, ctx.z) & 7 : d & 7; return T((DP[kind] || DP[2])[top ? 1 : 0]); } });
  def(179, { name: 'Красный песчаник', variants: 3, names: ['Красный песчаник', 'Резной красный песчаник', 'Гладкий красный песчаник'], hardness: 0.8, tool: 'pickaxe', hand: false,
    tex: (d, f) => f === 1 ? T('red_sandstone_top') : f === 0 ? T('red_sandstone_bottom') : [T('red_sandstone_normal'), T('red_sandstone_carved'), T('red_sandstone_smooth')][d & 3] || T('red_sandstone_normal') });
  def(181, { name: 'Двойная плита', variants: 2, hardness: 2, tool: 'pickaxe', hand: false, tex: (d, f) => (d & 7) === 1 ? T('purpur_block') : f <= 1 ? T('red_sandstone_top') : T('red_sandstone_normal') });
  def(182, { name: 'Плита', variants: 2, names: ['Плита из красного песчаника', 'Пурпурная плита'], shape: 'boxes', opaque: false, hardness: 2, tool: 'pickaxe', hand: false, boxes: slabBoxes,
    tex: (d, f) => (d & 7) === 1 ? T('purpur_block') : f <= 1 ? T('red_sandstone_top') : T('red_sandstone_normal') });
  const door = (id, n, wood, tool) => def(id, { name: n, shape: 'boxes', opaque: false, layer: 'cutout', hardness: tool === 'pickaxe' ? 5 : 3, tool, hand: tool !== 'pickaxe', boxes: doorBoxes,
    tex: (d) => T(d & 8 ? 'door_' + wood + '_upper' : 'door_' + wood + '_lower') });
  door(64, 'Дубовая дверь', 'wood', 'axe'); door(71, 'Железная дверь', 'iron', 'pickaxe'); door(193, 'Еловая дверь', 'spruce', 'axe'); door(194, 'Берёзовая дверь', 'birch', 'axe');
  door(195, 'Тропическая дверь', 'jungle', 'axe'); door(196, 'Дверь из акации', 'acacia', 'axe'); door(197, 'Дверь из тёмного дуба', 'dark_oak', 'axe');
  def(198, { name: 'Тропинка', shape: 'boxes', opaque: false, hardness: 0.6, tool: 'shovel', boxes: fixed(box(0, 0, 0, 1, 0.9375, 1)), tex: { top: 'grass_path_top', bottom: 'dirt', side: 'grass_path_side' } });
  def(199, { name: 'Рамка', shape: 'boxes', solid: false, opaque: false, hardness: 0.25, boxes: wallAttachBoxes, tex: 'itemframe_background' });
  def(200, { name: 'Цветок хоруса', hardness: 0.4, tex: 'chorus_flower' });
  def(201, { name: 'Пурпурный блок', variants: 3, hardness: 1.5, tool: 'pickaxe', hand: false, tex: (d, f) => (d & 3) === 2 ? (f <= 1 ? T('purpur_pillar_top') : T('purpur_pillar')) : T('purpur_block') });
  def(206, { name: 'Кирпичи Края', hardness: 0.8, tool: 'pickaxe', hand: false, tex: 'end_bricks' });
  def(207, { name: 'Подмёрзший лёд', opaque: false, layer: 'translucent', hardness: 0.5, tex: (d) => T('frosted_ice_' + Math.min(3, d & 3)) });
  def(208, { name: 'Стержень Края', shape: 'boxes', opaque: false, hardness: 0, boxes: fixed(box(0.4375, 0, 0.4375, 0.5625, 1, 0.5625)), tex: 'end_rod' });
  def(210, { name: 'Разрешить', tex: 'build_allow', hardness: -1 });
  def(211, { name: 'Запретить', tex: 'build_deny', hardness: -1 });
  def(212, { name: 'Граница', tex: 'border', hardness: -1 });
  def(213, { name: 'Магмовый блок', hardness: 0.5, tool: 'pickaxe', hand: false, tex: 'magma' });
  def(214, { name: 'Блок адского нароста', hardness: 1, tex: 'nether_wart_block' });
  def(215, { name: 'Красный адский кирпич', hardness: 2, tool: 'pickaxe', hand: false, tex: 'red_nether_brick' });
  def(216, { name: 'Костяной блок', hardness: 2, tool: 'pickaxe', hand: false, tex: axisTex(['bone_block_side'], ['bone_block_top'], 0) });
  def(218, { name: 'Шалкеровый ящик', variants: 16, hardness: 2, tool: 'pickaxe', tex: byData(COLORS.map((c) => 'shulker_top_' + c)) });
  const GLAZED = { 219: 'purple', 220: 'white', 221: 'orange', 222: 'magenta', 223: 'light_blue', 224: 'yellow', 225: 'lime', 226: 'pink', 227: 'gray', 228: 'silver', 229: 'cyan', 231: 'blue', 232: 'brown', 233: 'green', 234: 'red', 235: 'black' };
  for (const id of Object.keys(GLAZED)) def(+id, { name: 'Глазурованная терракота (' + COLORS_RU[COLORS.indexOf(GLAZED[id])].toLowerCase() + ')', hardness: 1.4, tool: 'pickaxe', hand: false, tex: 'glazed_terracotta_' + GLAZED[id] });
  def(236, { name: 'Бетон', variants: 16, names: COLORS_RU.map((c) => c + ' бетон'), hardness: 1.8, tool: 'pickaxe', hand: false, tex: byData(COLORS.map((c) => 'concrete_' + c)) });
  def(237, { name: 'Сухой бетон', variants: 16, names: COLORS_RU.map((c) => c + ' сухой бетон'), hardness: 0.5, tool: 'shovel', tex: byData(COLORS.map((c) => 'concrete_powder_' + c)) });
  def(240, { name: 'Растение хоруса', hardness: 0.4, tex: 'chorus_plant' });
  def(241, { name: 'Окрашенное стекло', variants: 16, opaque: false, layer: 'cutout', hardness: 0.3, tex: 'glass' });
  def(243, { name: 'Подзол', hardness: 0.5, tool: 'shovel', tex: { top: 'dirt_podzol_top', bottom: 'dirt', side: 'dirt_podzol_side' } });
  def(244, { name: 'Свёкла', shape: 'crop', solid: false, opaque: false, layer: 'cutout', hardness: 0, tex: (d) => T('beetroots_stage_' + Math.min(3, d >> 1)) });
  def(245, { name: 'Камнерез', hardness: 3.5, tool: 'pickaxe', tex: { top: 'stonecutter_top', bottom: 'stonecutter_bottom', side: 'stonecutter_side' } });
  def(246, { name: 'Светящийся обсидиан', hardness: 10, tool: 'pickaxe', hand: false, tex: 'glowing_obsidian' });
  def(247, { name: 'Ядро реактора', hardness: 3, tex: (d) => T('reactor_core_stage_' + Math.min(2, d)) });
  def(251, { name: 'Наблюдатель', hardness: 3, tool: 'pickaxe', hand: false, tex: (d, f) => {
    const dir = d & 7; if (f === dir) return T('observer_front'); if ((f ^ 1) === dir) return T('observer_back'); return f <= 1 ? T('observer_top') : T('observer_side'); } });
  def(252, { name: 'Структурный блок', hardness: -1, tex: 'structure_block' });

  // Все неизвестные ID — сплошные блоки с текстурой «нет текстуры», чтобы мир с сервера отображался полностью
  for (let i = 0; i < 256; i++) if (!blocks[i]) def(i, { name: 'Блок #' + i, tex: 'missing_tile' });

  // Вспомогательные функции
  function boxesOf(id, data, get, x, y, z, collide) {
    const b = blocks[id];
    switch (b.shape) {
      case 'cube': return FULL;
      case 'none': case 'cross': case 'crop': case 'flat': case 'liquid': case 'torch': return null;
      default: return b.boxes ? b.boxes(data, get, x, y, z, collide) : FULL;
    }
  }

  function collisionBoxes(id, data, get, x, y, z) {
    const b = blocks[id];
    if (!b.solid) return null;
    if (b.shape === 'cross' || b.shape === 'torch') return FULL;
    return boxesOf(id, data, get, x, y, z, true);
  }

  function selectionBoxes(id, data, get, x, y, z) {
    const b = blocks[id];
    if (id === 0 || b.liquid) return null;
    switch (b.shape) {
      case 'cross': case 'crop': return [box(0.1, 0, 0.1, 0.9, 0.8, 0.9)];
      case 'torch': return [box(0.375, 0, 0.375, 0.625, 0.625, 0.625)];
      case 'flat': return [box(0, 0, 0, 1, 0.0625, 1)];
      case 'none': return id === 95 ? FULL : null;
      default: {
        const bx = boxesOf(id, data, get, x, y, z, false);
        return bx && bx.length ? bx : [box(0, 0, 0, 1, 0.2, 1)];
      }
    }
  }

  // Время разрушения (сек) как на сервере Nukkit/PocketMine 1.1
  const TOOLS = {
    268: ['sword', 2], 269: ['shovel', 2], 270: ['pickaxe', 2], 271: ['axe', 2],
    272: ['sword', 4], 273: ['shovel', 4], 274: ['pickaxe', 4], 275: ['axe', 4],
    267: ['sword', 6], 256: ['shovel', 6], 257: ['pickaxe', 6], 258: ['axe', 6],
    276: ['sword', 8], 277: ['shovel', 8], 278: ['pickaxe', 8], 279: ['axe', 8],
    283: ['sword', 12], 284: ['shovel', 12], 285: ['pickaxe', 12], 286: ['axe', 12],
    359: ['shears', 1]
  };

  function breakTime(id, itemId, onGround, inWater) {
    const b = blocks[id];
    if (b.hardness < 0) return Infinity;
    if (b.hardness === 0) return 0;
    const tool = TOOLS[itemId];
    const toolType = tool ? tool[0] : null;
    const correct = !b.tool || b.tool === toolType;
    const base = ((correct || b.hand) ? 1.5 : 5.0) * b.hardness;
    let speed = 1 / base;
    if (correct) {
      if (toolType === 'sword') speed *= id === 30 ? 15 : 1;
      else if (toolType === 'shears') speed *= id === 35 ? 5 : 15;
      else if (toolType) speed *= tool[1];
    }
    if (inWater) speed *= 0.2;
    if (!inWater && !onGround) speed *= 0.2;
    return 1 / speed;
  }

  function displayName(id, data) {
    const b = blocks[id];
    if (b.names && b.names[data]) return b.names[data];
    return b.name;
  }

  // Яркость света от блока (0-15), как в Minecraft
  const LIGHT = new Uint8Array(256);
  for (const [id, l] of [[10, 15], [11, 15], [50, 14], [51, 15], [62, 13], [76, 7], [89, 15], [90, 11], [91, 15], [94, 9], [124, 15], [138, 15], [169, 15], [198, 0], [208, 14], [213, 3], [246, 12], [74, 9], [130, 7], [117, 1], [122, 1], [119, 15]]) LIGHT[id] = l;

  MC.Blocks = { LIGHT, list: blocks, FACE, T, boxesOf, collisionBoxes, selectionBoxes, breakTime, displayName, COLORS, WOOD, MISSING };
})();
