// Готовые постройки: базы и ловушки. Каждая собирается кодом в схему того же формата, что и .schematic,
// и показывается голограммой во вкладке «Схемы» (её можно двигать, поворачивать, строить принтером или сразу).
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  // Номера блоков MCPE 1.1
  const B = {
    stone: 1, grass: 2, dirt: 3, cobble: 4, planks: 5, sand: 12, log: 17, leaves: 18, glass: 20, wool: 35, flowerY: 37, flowerR: 38,
    tnt: 46, bookshelf: 47, mossy: 48, torch: 50, oakStairs: 53, chest: 54, wire: 55, table: 58, furnace: 61, door: 64, ladder: 65,
    cobStairs: 67, plate: 70, snow: 80, cactus: 81, fence: 85, glowstone: 89, trapdoor: 96, sbrick: 98, bars: 101, pane: 102,
    gate: 107, brickStairs: 108, sbStairs: 109, lava: 11, water: 9, slab: 44, woodSlab: 158, quartz: 155, quartzStairs: 156,
    spruceStairs: 134, darkStairs: 164, carpet: 171, seaLantern: 169, terracotta: 159, bed: 26, web: 30, flowerPot: 140, lantern: 124,
    tallGrass: 31, stoneSlab: 44, ironBlock: 42, lever: 69
  };
  // Ступени: высокая сторона на восток 0, запад 1, юг 2, север 3; +4 — перевёрнутые
  const ST = { e: 0, w: 1, s: 2, n: 3 };

  class Builder {
    constructor(name) { this.name = name; this.map = new Map(); }
    set(x, y, z, id, d) { this.map.set(x + ',' + y + ',' + z, [id, d || 0]); }
    fill(x0, y0, z0, x1, y1, z1, id, d) {
      for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) for (let z = Math.min(z0, z1); z <= Math.max(z0, z1); z++) this.set(x, y, z, id, d);
    }
    // Стены коробки без пола и потолка
    walls(x0, y0, z0, x1, y1, z1, id, d) {
      for (let y = y0; y <= y1; y++) {
        for (let x = x0; x <= x1; x++) { this.set(x, y, z0, id, d); this.set(x, y, z1, id, d); }
        for (let z = z0; z <= z1; z++) { this.set(x0, y, z, id, d); this.set(x1, y, z, id, d); }
      }
    }
    clear(x0, y0, z0, x1, y1, z1) { this.fill(x0, y0, z0, x1, y1, z1, 0, 0); }
    // Дверь: нижняя половина (направление), верхняя — бит 8
    door(x, y, z, dir) { this.set(x, y, z, B.door, dir); this.set(x, y + 1, z, B.door, 8); }
    // Кровать: ножки и изголовье (изголовье смещено по направлению)
    bed(x, y, z, dir) {
      const off = [[0, 1], [-1, 0], [0, -1], [1, 0]][dir];
      this.set(x, y, z, B.bed, dir);
      this.set(x + off[0], y, z + off[1], B.bed, dir | 8);
    }
    // Схема: в неё попадают только блоки (clear убирает ранее поставленные блоки самой постройки)
    result() {
      let x0 = Infinity, y0 = Infinity, z0 = Infinity, x1 = -Infinity, y1 = -Infinity, z1 = -Infinity;
      for (const k of this.map.keys()) {
        const [x, y, z] = k.split(',').map(Number);
        if (x < x0) x0 = x; if (y < y0) y0 = y; if (z < z0) z0 = z;
        if (x > x1) x1 = x; if (y > y1) y1 = y; if (z > z1) z1 = z;
      }
      const w = x1 - x0 + 1, h = y1 - y0 + 1, l = z1 - z0 + 1;
      const ids = new Uint8Array(w * h * l), meta = new Uint8Array(w * h * l);
      let count = 0;
      for (const [k, v] of this.map) {
        if (!v[0]) continue;
        const [x, y, z] = k.split(',').map(Number);
        const i = ((y - y0) * l + (z - z0)) * w + (x - x0);
        ids[i] = v[0];
        meta[i] = v[1] & 15;
        count++;
      }
      return { name: this.name, w, h, l, ids, meta, count, skipped: 0, added: 0, builtin: true };
    }
  }

  // ---------- Уютный дом: каменный фундамент, бревенчатый каркас, двускатная крыша, сад ----------
  function cozyHouse() {
    const b = new Builder('Уютный дом');
    // Сад: трава и дорожка
    b.fill(-3, 0, -4, 13, 0, 12, B.grass);
    b.fill(4, 0, -4, 6, 0, -1, B.cobble);
    // Фундамент и пол
    b.fill(0, 0, 0, 10, 0, 8, B.sbrick);
    b.fill(1, 0, 1, 9, 0, 7, B.planks, 5);
    // Каркас: бревна по углам и у двери, стены из еловых досок
    b.walls(0, 1, 0, 10, 4, 8, B.planks, 1);
    for (const [x, z] of [[0, 0], [10, 0], [0, 8], [10, 8], [5, 8], [3, 0], [7, 0]]) b.fill(x, 1, z, x, 4, z, B.log, 0);
    b.fill(0, 4, 0, 10, 4, 0, B.log, 4); b.fill(0, 4, 8, 10, 4, 8, B.log, 4);
    b.fill(0, 4, 0, 0, 4, 8, B.log, 8); b.fill(10, 4, 0, 10, 4, 8, B.log, 8);
    b.clear(1, 1, 1, 9, 4, 7);
    // Окна
    for (const x of [1, 2, 8, 9]) b.fill(x, 2, 0, x, 3, 0, B.pane);
    for (const x of [2, 3, 7, 8]) b.fill(x, 2, 8, x, 3, 8, B.pane);
    for (const z of [3, 5]) { b.fill(0, 2, z, 0, 3, z, B.pane); b.fill(10, 2, z, 10, 3, z, B.pane); }
    // Дверь и крыльцо со ступенями
    b.door(5, 1, 0, 1);
    b.clear(4, 1, -1, 6, 3, -1);
    b.set(5, 0, -1, B.sbStairs, ST.s);
    b.set(4, 1, -1, B.fence); b.set(6, 1, -1, B.fence);
    b.set(4, 2, -1, B.torch, 5); b.set(6, 2, -1, B.torch, 5);
    // Двускатная крыша из ступеней тёмного дуба, фронтоны из досок
    for (let k = 0; k <= 4; k++) {
      const y = 5 + k;
      for (let x = -1; x <= 11; x++) { b.set(x, y, -1 + k, B.darkStairs, ST.s); b.set(x, y, 9 - k, B.darkStairs, ST.n); }
      if (k < 4) for (let z = k; z <= 8 - k; z++) { b.set(0, y, z, B.planks, 1); b.set(10, y, z, B.planks, 1); }
      if (k < 4) b.clear(1, y, k + 1, 9, y, 7 - k);
    }
    for (let x = -1; x <= 11; x++) b.set(x, 9, 4, B.woodSlab, 5);
    b.set(0, 6, 4, B.pane); b.set(10, 6, 4, B.pane);
    // Труба
    b.fill(8, 5, 6, 8, 10, 6, B.sbrick);
    b.set(8, 1, 6, B.furnace, 2);
    // Внутри: кровать, сундуки, верстак, печь, книжные полки, ковёр, свет
    b.bed(2, 1, 6, 0);
    b.bed(3, 1, 6, 0);
    b.set(1, 1, 7, B.chest, 2); b.set(9, 1, 7, B.chest, 2);
    b.set(9, 1, 1, B.table); b.set(9, 1, 2, B.furnace, 4);
    b.fill(6, 1, 7, 7, 3, 7, B.bookshelf);
    b.fill(3, 1, 3, 7, 1, 5, B.carpet, 14);
    b.fill(4, 1, 4, 6, 1, 4, B.carpet, 4);
    b.set(5, 0, 4, B.glowstone);
    b.set(1, 3, 4, B.torch, 1); b.set(9, 3, 4, B.torch, 2); b.set(5, 3, 7, B.torch, 4);
    // Сад: забор, цветы, деревья
    for (let x = -3; x <= 13; x++) { if (x < 4 || x > 6) b.set(x, 1, -4, B.fence); b.set(x, 1, 12, B.fence); }
    for (let z = -4; z <= 12; z++) { b.set(-3, 1, z, B.fence); b.set(13, 1, z, B.fence); }
    b.set(4, 1, -4, B.fence); b.set(6, 1, -4, B.fence); b.set(5, 1, -4, B.gate, 0);
    for (const [x, z, f] of [[1, -2, B.flowerR], [2, -3, B.flowerY], [8, -2, B.flowerY], [9, -3, B.flowerR], [-1, 2, B.flowerR], [11, 5, B.flowerY], [1, 10, B.flowerR], [9, 10, B.flowerY]]) b.set(x, 1, z, f);
    for (const [tx, tz] of [[-1, 10], [11, 10]]) {
      b.fill(tx, 1, tz, tx, 4, tz, B.log, 0);
      for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) for (let dy = 3; dy <= 5; dy++) {
        if (Math.abs(dx) + Math.abs(dz) + (dy - 3) > 4 || (dx === 0 && dz === 0 && dy < 5)) continue;
        if (tx + dx < -3 || tx + dx > 13 || tz + dz > 12) continue;
        b.set(tx + dx, dy, tz + dz, B.leaves, 0);
      }
    }
    return b.result();
  }

  // ---------- Башня-замок: круглая каменная башня с зубцами, этажами, лестницей и окнами ----------
  function castleTower() {
    const b = new Builder('Башня-замок');
    const R = 5, H = 16, cx = 0, cz = 0;
    const inDisk = (dx, dz, r) => dx * dx + dz * dz <= (r + 0.5) * (r + 0.5);
    for (let dx = -R - 1; dx <= R + 1; dx++) for (let dz = -R - 1; dz <= R + 1; dz++) {
      if (!inDisk(dx, dz, R)) continue;
      const wall = !inDisk(dx, dz, R - 1);
      b.set(cx + dx, 0, cz + dz, B.sbrick);
      for (let y = 1; y <= H; y++) {
        if (wall) b.set(cx + dx, y, cz + dz, (dx * 7 + dz * 3 + y) % 5 === 0 ? B.mossy : B.sbrick);
        else if (y % 5 === 0) b.set(cx + dx, y, cz + dz, B.planks, 5);
        else b.set(cx + dx, y, cz + dz, 0);
      }
      // Площадка наверху и зубцы
      b.set(cx + dx, H + 1, cz + dz, wall ? B.sbrick : B.planks, wall ? 0 : 5);
      if (wall && ((dx + dz) & 1) === 0) b.set(cx + dx, H + 2, cz + dz, B.sbrick);
    }
    // Пол этажей с проёмом для лестницы у северной стены
    for (const y of [5, 10, 15, H + 1]) { b.set(cx, y, cz - R + 1, 0); b.set(cx, y, cz - R + 2, 0); }
    for (let y = 1; y <= H + 1; y++) b.set(cx, y, cz - R + 1, B.ladder, 3);
    // Вход с дверью и аркой
    b.clear(cx - 1, 1, cz + R, cx + 1, 3, cz + R);
    b.door(cx, 1, cz + R, 3);
    b.set(cx - 1, 1, cz + R, B.sbrick); b.set(cx + 1, 1, cz + R, B.sbrick);
    b.set(cx - 1, 2, cz + R, B.sbrick); b.set(cx + 1, 2, cz + R, B.sbrick);
    b.set(cx - 1, 3, cz + R, B.sbStairs, ST.e | 4); b.set(cx + 1, 3, cz + R, B.sbStairs, ST.w | 4); b.set(cx, 3, cz + R, B.sbrick);
    b.set(cx - 1, 2, cz + R + 1, B.torch, 3); b.set(cx + 1, 2, cz + R + 1, B.torch, 3);
    // Окна-бойницы на каждом этаже
    for (const y of [3, 7, 8, 12, 13]) {
      b.set(cx + R, y, cz, B.bars); b.set(cx - R, y, cz, B.bars);
      if (y > 5) b.set(cx, y, cz + R, B.bars);
    }
    // Свет и обстановка
    for (const y of [2, 7, 12]) { b.set(cx + R - 1, y + 1, cz, B.torch, 2); b.set(cx - R + 1, y + 1, cz, B.torch, 1); }
    b.set(cx + 2, 1, cz - 2, B.table); b.set(cx + 3, 1, cz - 1, B.furnace, 4); b.set(cx - 3, 1, cz - 1, B.chest, 5); b.set(cx - 3, 1, cz, B.chest, 5);
    b.bed(cx + 2, 6, cz + 1, 2);
    b.fill(cx - 3, 6, cz + 1, cx - 3, 8, cz + 2, B.bookshelf);
    b.set(cx, 11, cz, B.glowstone);
    b.set(cx, H + 2, cz, B.fence); b.set(cx, H + 3, cz, B.fence); b.set(cx, H + 4, cz, B.wool, 14); b.set(cx + 1, H + 4, cz, B.wool, 14); b.set(cx + 1, H + 3, cz, B.wool, 14);
    // Ров с водой вокруг; каменные бортики с обеих сторон, чтобы вода не растекалась
    for (let dx = -R - 5; dx <= R + 5; dx++) for (let dz = -R - 5; dz <= R + 5; dz++) {
      const d = dx * dx + dz * dz;
      if (d > (R + 4.5) ** 2 || inDisk(dx, dz, R)) continue;
      if (d <= (R + 1.5) ** 2 || d > (R + 3.5) ** 2) { b.set(cx + dx, 0, cz + dz, B.sbrick); continue; }
      b.set(cx + dx, -1, cz + dz, B.sbrick);
      b.set(cx + dx, 0, cz + dz, B.water);
    }
    // Мост через ров к двери
    for (let z = R + 1; z <= R + 5; z++) b.fill(cx - 1, 0, cz + z, cx + 1, 0, cz + z, B.planks, 1);
    return b.result();
  }

  // ---------- Современный дом: кварц, большие окна, плоская крыша, бассейн ----------
  function modernHouse() {
    const b = new Builder('Современный дом');
    b.fill(-2, 0, -6, 15, 0, 10, B.grass);
    b.fill(0, 0, 0, 13, 0, 8, B.quartz);
    // Первый этаж
    b.walls(0, 1, 0, 13, 3, 8, B.quartz);
    b.clear(1, 1, 1, 12, 3, 7);
    for (let x = 1; x <= 12; x++) if (x < 6 || x > 7) b.fill(x, 1, 0, x, 3, 0, B.glass);
    for (let z = 2; z <= 6; z++) b.fill(13, 1, z, 13, 3, z, B.glass);
    b.door(6, 1, 0, 1); b.door(7, 1, 0, 1);
    b.fill(0, 4, 0, 13, 4, 8, B.quartz);
    // Второй этаж со сдвигом и террасой
    b.walls(4, 5, 2, 13, 7, 8, B.quartz);
    b.clear(5, 5, 3, 12, 7, 7);
    for (let x = 5; x <= 12; x++) b.fill(x, 5, 2, x, 7, 2, B.glass);
    b.fill(4, 8, 2, 13, 8, 8, B.slab, 6);
    for (let x = 0; x <= 3; x++) b.set(x, 5, 0, B.bars); for (let z = 0; z <= 8; z++) b.set(0, 5, z, B.bars);
    // Лестница внутри: проём в потолке над ней
    b.clear(2, 4, 7, 5, 4, 7);
    for (let i = 0; i < 4; i++) b.set(2 + i, 1 + i, 7, B.quartzStairs, ST.e);
    // Свет и мебель
    for (const [x, z] of [[3, 3], [9, 3], [3, 6], [9, 6]]) b.set(x, 4, z, B.seaLantern);
    b.set(8, 8, 5, B.seaLantern);
    b.fill(8, 1, 3, 10, 1, 5, B.carpet, 7);
    b.set(12, 1, 7, B.table); b.set(12, 1, 6, B.furnace, 4); b.set(11, 1, 7, B.chest, 2);
    b.bed(7, 5, 6, 0); b.bed(8, 5, 6, 0);
    b.set(12, 5, 7, B.chest, 2);
    b.set(1, 1, 1, B.flowerPot); b.set(12, 1, 1, B.flowerPot);
    // Бассейн перед домом
    b.fill(1, -2, -5, 12, -1, -2, B.quartz);
    b.walls(1, 0, -5, 12, 0, -2, B.quartz);
    b.fill(2, -1, -4, 11, 0, -3, B.water);
    b.set(1, 1, -5, B.seaLantern); b.set(12, 1, -5, B.seaLantern);
    return b.result();
  }

  // ---------- Ловушка: динамит под нажимной плитой ----------
  // Плита стоит на траве; под травой 3×3 динамита. Игрок или моб наступает — динамит поджигается (4 секунды)
  function tntTrap() {
    const b = new Builder('Ловушка: динамит под плитой');
    b.fill(-2, 0, -2, 2, 0, 2, B.dirt);
    b.fill(-1, 0, -1, 1, 0, 1, B.tnt);
    b.fill(-2, 1, -2, 2, 1, 2, B.grass);
    b.set(0, 2, 0, B.plate);
    b.set(-2, 2, -2, B.tallGrass, 1); b.set(2, 2, 1, B.tallGrass, 1); b.set(1, 2, -2, B.flowerR);
    return b.result();
  }

  // ---------- Ловушка: коридор с люком над лавой ----------
  // В коридоре нажимная плита: блок под ней запитан, соседний люк открывается, и идущий дальше падает в лаву
  function lavaTrap() {
    const b = new Builder('Ловушка: люк над лавой');
    // Коридор вдоль Z: стены x=0 и x=2, пол на y=3
    b.fill(0, 0, 0, 2, 3, 6, B.sbrick);
    b.walls(0, 4, 0, 2, 5, 6, B.sbrick);
    b.clear(1, 4, 0, 1, 5, 6);
    b.fill(0, 6, 0, 2, 6, 6, B.sbrick);
    // Яма 1×1 глубиной 3 с лавой на дне
    b.set(1, 1, 3, 0); b.set(1, 2, 3, 0);
    b.set(1, 0, 3, B.lava);
    // Люк заподлицо с полом (верхняя половина, закрыт) и плита перед ним
    b.set(1, 3, 3, B.trapdoor, 4);
    b.set(1, 4, 2, B.plate);
    // Входы с обоих концов и факел на стене
    b.clear(1, 4, 0, 1, 5, 0);
    b.clear(1, 4, 6, 1, 5, 6);
    b.set(1, 5, 1, B.torch, 1);
    return b.result();
  }

  // ---------- Ловушка: паутина и кактусы ----------
  // Яма 3×3 глубиной 6 в травяной площадке: паутина на полпути замедляет, внизу кактусы на песке.
  // Мобы и игроки, которые в неё падают, погибают
  function cactusPit() {
    const b = new Builder('Ловушка: яма с кактусами');
    b.fill(-3, 0, -3, 3, 6, 3, B.dirt);
    b.fill(-3, 6, -3, 3, 6, 3, B.grass);
    b.clear(-1, 1, -1, 1, 6, 1);
    b.fill(-1, 0, -1, 1, 0, 1, B.sand);
    for (const [x, z] of [[-1, -1], [1, -1], [-1, 1], [1, 1], [0, 0]]) b.set(x, 1, z, B.cactus);
    for (const [x, z] of [[0, -1], [-1, 0], [1, 0], [0, 1]]) b.set(x, 3, z, B.web);
    b.set(-3, 7, -3, B.tallGrass, 1); b.set(3, 7, 2, B.tallGrass, 1); b.set(2, 7, -3, B.flowerY);
    return b.result();
  }

  const LIST = [
    { id: 'cozy', kind: 'base', make: cozyHouse, desc: 'дом с садом, кроватями, печью и сундуками' },
    { id: 'tower', kind: 'base', make: castleTower, desc: 'круглая башня 3 этажа, ров и мост' },
    { id: 'modern', kind: 'base', make: modernHouse, desc: 'кварц, большие окна, терраса и бассейн' },
    { id: 'tnt', kind: 'trap', make: tntTrap, desc: 'плита на траве, под ней динамит' },
    { id: 'lava', kind: 'trap', make: lavaTrap, desc: 'плита в коридоре открывает люк над лавой' },
    { id: 'cactus', kind: 'trap', make: cactusPit, desc: 'яма с паутиной и кактусами для мобов' }
  ];
  const cache = {};
  function get(id) {
    if (!cache[id]) { const s = LIST.find((x) => x.id === id); cache[id] = s.make(); }
    return cache[id];
  }

  MC.Structures = { LIST, get };
})();
