// Перевод сообщений сервера (ключи языка Minecraft PE) и разбор цветовых кодов §
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  const STRINGS = {
    'multiplayer.player.joined': '%s присоединился к игре',
    'multiplayer.player.left': '%s покинул игру',
    'chat.type.text': '<%s> %s',
    'chat.type.emote': '* %s %s',
    'chat.type.announcement': '[%s] %s',
    'commands.generic.permission': 'У вас нет прав на эту команду',
    'commands.generic.notFound': 'Неизвестная команда. Введите /help для списка команд',
    'commands.generic.unknown': 'Неизвестная команда: %s',
    'commands.generic.usage': 'Использование: %s',
    'commands.generic.player.notFound': 'Игрок не найден',
    'commands.players.list': 'Сейчас на сервере %s/%s игроков:',
    'disconnectionScreen.serverFull': 'Сервер переполнен',
    'disconnectionScreen.outdatedClient': 'Клиент устарел',
    'disconnectionScreen.outdatedServer': 'Сервер устарел',
    'disconnectionScreen.invalidName': 'Недопустимый ник (3-16 символов: латиница, цифры, _ и пробел)',
    'disconnectionScreen.invalidSkin': 'Недопустимый скин',
    'disconnectionScreen.noReason': 'Отключено сервером',
    'disconnectionScreen.notAuthenticated': 'Нужен вход через Xbox Live',
    'disconnectionScreen.loggedinOtherLocation': 'Вы вошли с другого устройства',
    'disconnectionScreen.resourcePack': 'Ошибка набора ресурсов',
    'disconnectionScreen.timeout': 'Превышено время ожидания',
    'disconnectionScreen.kicked': 'Вас выгнали с сервера',
    'disconnectionScreen.serverIdConflict': 'Конфликт идентификатора сервера',
    'death.attack.generic': '%s умер',
    'death.attack.fall': '%s разбился',
    'death.attack.player': '%s убит игроком %s',
    'death.attack.mob': '%s убит мобом %s',
    'death.attack.lava': '%s решил поплавать в лаве',
    'death.attack.drown': '%s утонул',
    'death.attack.outOfWorld': '%s выпал из мира',
    'death.attack.inFire': '%s сгорел',
    'death.attack.onFire': '%s сгорел заживо',
    'death.attack.explosion': '%s взорвался',
    'death.attack.explosion.player': '%s взорван игроком %s',
    'death.attack.cactus': '%s исколот кактусом',
    'death.attack.starve': '%s умер от голода',
    'death.attack.inWall': '%s задохнулся в стене',
    'death.attack.magic': '%s убит магией',
    'death.fell.accident.generic': '%s разбился',
    'tile.bed.noSleep': 'Спать можно только ночью',
    'gameMode.survival': 'Выживание',
    'gameMode.creative': 'Творческий',
    'gameMode.adventure': 'Приключение',
    'gameMode.spectator': 'Наблюдатель',
    'gameMode.changed': 'Режим игры изменён',
    'commands.gamemode.success.self': 'Ваш режим игры: %s',
    'commands.gamemode.success.other': 'Режим игры игрока %2$s: %1$s',
    'commands.time.set': 'Время установлено: %s',
    'commands.time.added': 'Ко времени добавлено %s',
    'commands.tp.success': '%s телепортирован к %s',
    'commands.tp.success.coordinates': '%s телепортирован на %s, %s, %s',
    'commands.give.success': 'Выдано %s x %s игроку %s',
    'commands.kill.successful': '%s убит',
    'commands.op.success': '%s теперь оператор',
    'commands.deop.success': '%s больше не оператор',
    'commands.weather.clear': 'Погода: ясно',
    'commands.weather.rain': 'Погода: дождь',
    'commands.weather.thunder': 'Погода: гроза',
    'commands.spawnpoint.success': 'Точка возрождения %s: %s, %s, %s',
    'commands.difficulty.success': 'Сложность: %s',
    'commands.generic.exception': 'Ошибка при выполнении команды',
    'commands.generic.num.invalid': 'Неверное число: %s',
    'commands.generic.syntax': 'Ошибка синтаксиса команды',
    'commands.help.header': 'Справка (страница %s из %s):',
    'commands.effect.success': 'Эффект %s (ID %s) уровня %s выдан игроку %s на %s сек.',
    'commands.effect.success.removed': 'Эффект %s снят с игрока %s',
    'potion.hunger': 'Голод',
    'potion.moveSpeed': 'Скорость',
    'potion.regeneration': 'Регенерация',
    'potion.damageBoost': 'Сила',
    'potion.heal': 'Исцеление',
    'potion.jump': 'Прыгучесть',
    'potion.fireResistance': 'Огнестойкость',
    'potion.waterBreathing': 'Подводное дыхание',
    'potion.invisibility': 'Невидимость',
    'potion.nightVision': 'Ночное зрение',
    'potion.poison': 'Отравление',
    'kick.reason.cheat': 'Обнаружен чит: %s',
    'commands.enchant.success': 'Чары наложены',
    'commands.enchant.noItem': 'У игрока нет предмета в руке',
    'commands.enchant.notFound': 'Нет чар с ID %s',
    'commands.enchant.cantEnchant': 'Эти чары нельзя наложить на предмет',
    'commands.xp.success': 'Выдано %s опыта игроку %s',
    'commands.xp.success.levels': 'Выдано уровней: %s, игроку %s',
    'commands.xp.success.negative.levels': 'Убрано уровней: %s у игрока %s',
    'commands.xp.failure.widthdrawXp': 'Нельзя отнять очки опыта, только уровни',
    'commands.clear.success': 'Инвентарь игрока %s очищен (предметов: %s)',
    'commands.clear.failure': 'У игрока %s нечего убирать',
    'commands.give.item.notFound': 'Нет такого предмета: %s',
    'commands.effect.notFound': 'Нет эффекта с ID %s',
    'commands.effect.success.removed.all': 'Сняты все эффекты с игрока %s',
    'commands.kick.success': '%s выгнан с сервера',
    'commands.kick.success.reason': '%s выгнан с сервера: %s',
    'commands.ban.success': '%s заблокирован',
    'commands.unban.success': '%s разблокирован',
    'commands.banip.success': 'IP %s заблокирован',
    'commands.setworldspawn.success': 'Точка появления мира: %s, %s, %s',
    'commands.spawnpoint.success.single': 'Точка возрождения %s: %s, %s, %s',
    'commands.time.query': 'Время: %s',
    'commands.weather.changed': 'Погода изменена',
    'commands.defaultgamemode.success': 'Режим игры по умолчанию: %s',
    'commands.save.success': 'Мир сохранён',
    'commands.save.start': 'Сохранение...',
    'commands.stop.start': 'Сервер останавливается',
    'commands.whitelist.add.success': '%s добавлен в белый список',
    'commands.whitelist.remove.success': '%s убран из белого списка',
    'commands.generic.player.notInGame': 'Игрок не в игре',
    'commands.generic.ingame': 'Команду можно выполнить только в игре',
    'commands.generic.num.tooSmall': 'Число %s меньше %s',
    'commands.generic.num.tooBig': 'Число %s больше %s',
    'commands.tp.notSameDimension': 'Игрок в другом измерении',
    'commands.particle.success': 'Частицы %s показаны %s раз',
    'commands.title.success': 'Заголовок показан',
    'commands.message.display.incoming': '%s шепчет вам: %s',
    'commands.message.display.outgoing': 'Вы шепчете %s: %s',
    'commands.message.sameTarget': 'Нельзя написать самому себе',
    'commands.me.usage': '/me <действие>',
    'chat.type.admin': '[%s: %s]',
    'death.attack.arrow': '%s застрелен игроком %s',
    'death.attack.arrow.item': '%s застрелен игроком %s с помощью %s',
    'death.attack.thrown': '%s забит игроком %s',
    'death.attack.fireball': '%s убит огненным шаром %s',
    'death.attack.indirectMagic': '%s убит магией игрока %s',
    'death.attack.thorns': '%s убит, пытаясь ранить %s',
    'death.attack.wither': '%s иссох',
    'death.attack.anvil': '%s раздавлен наковальней',
    'death.attack.fallingBlock': '%s раздавлен падающим блоком',
    'death.attack.lightningBolt': '%s убит молнией',
    'death.attack.player.item': '%s убит игроком %s с помощью %s',
    'death.attack.lava.player': '%s упал в лаву, убегая от %s',
    'death.attack.drown.player': '%s утонул, убегая от %s',
    'death.fell.accident.ladder': '%s упал с лестницы',
    'death.fell.accident.water': '%s выпал из воды',
    'death.fell.killer': '%s был обречён на падение',
    'tile.bed.occupied': 'Эта кровать занята',
    'tile.bed.notSafe': 'Нельзя спать, когда рядом монстры',
    'tile.bed.respawnSet': 'Точка возрождения установлена',
    'potion.digSpeed': 'Спешка',
    'potion.digSlowDown': 'Усталость',
    'potion.moveSlowdown': 'Замедление',
    'potion.harm': 'Вред',
    'potion.confusion': 'Тошнота',
    'potion.resistance': 'Сопротивление',
    'potion.blindness': 'Слепота',
    'potion.weakness': 'Слабость',
    'potion.wither': 'Иссушение',
    'potion.healthBoost': 'Прилив здоровья',
    'potion.absorption': 'Поглощение',
    'potion.saturation': 'Насыщение',
    'potion.levitation': 'Левитация',
    'enchantment.damage.all': 'Острота',
    'enchantment.protect.all': 'Защита',
    'enchantment.digging': 'Эффективность',
    'enchantment.durability': 'Прочность',
    'enchantment.fire': 'Заговор огня',
    'enchantment.knockback': 'Отдача',
    'enchantment.lootBonus': 'Добыча',
    'enchantment.arrowDamage': 'Сила',
    'enchantment.arrowInfinite': 'Бесконечность',
    'enchantment.untouching': 'Шёлковое касание',
    'enchantment.mending': 'Починка',
    'enchantment.level.1': 'I', 'enchantment.level.2': 'II', 'enchantment.level.3': 'III', 'enchantment.level.4': 'IV', 'enchantment.level.5': 'V'
  };

  function translate(msg, params) {
    params = params || [];
    msg = String(msg);
    const m = msg.match(/^((?:§.)*)%?([a-zA-Z0-9_]+\.[a-zA-Z0-9_.]+)$/);
    if (m) {
      if (STRINGS[m[2]]) return m[1] + fill(STRINGS[m[2]], params);
      return m[1] + m[2] + (params.length ? ': ' + params.map((p) => translate(p)).join(', ') : '');
    }
    // Ключи внутри строки вида "§e%multiplayer.player.joined" и шаблоны с %s
    const replaced = msg.replace(/%([a-zA-Z0-9_]+\.[a-zA-Z0-9_.]+)/g, (all, k) => (STRINGS[k] ? fill(STRINGS[k], params) : k));
    return /%(\d\$)?s/.test(replaced) ? fill(replaced, params) : replaced;
  }

  function fill(tpl, params) {
    let i = 0;
    return tpl.replace(/%(\d\$)?s/g, (all, idx) => {
      if (idx) return params[parseInt(idx, 10) - 1] !== undefined ? MC.translate(params[parseInt(idx, 10) - 1]) : '';
      const p = params[i++];
      return p !== undefined ? MC.translate(String(p)) : '';
    });
  }

  const COLORS = { 0: '#000000', 1: '#0000aa', 2: '#00aa00', 3: '#00aaaa', 4: '#aa0000', 5: '#aa00aa', 6: '#ffaa00', 7: '#aaaaaa', 8: '#555555', 9: '#5555ff', a: '#55ff55', b: '#55ffff', c: '#ff5555', d: '#ff55ff', e: '#ffff55', f: '#ffffff' };

  // Текст с кодами § -> DOM-фрагмент
  function formatted(text) {
    const frag = document.createDocumentFragment();
    let color = null, bold = false, italic = false;
    const parts = String(text).split('§');
    parts.forEach((part, i) => {
      let t = part;
      if (i > 0 && part.length) {
        const code = part[0].toLowerCase();
        t = part.slice(1);
        if (COLORS[code]) { color = COLORS[code]; bold = false; italic = false; }
        else if (code === 'l') bold = true;
        else if (code === 'o') italic = true;
        else if (code === 'r') { color = null; bold = false; italic = false; }
      }
      if (!t) return;
      const span = document.createElement('span');
      span.textContent = t;
      if (color) span.style.color = color;
      if (bold) span.style.fontWeight = 'bold';
      if (italic) span.style.fontStyle = 'italic';
      frag.appendChild(span);
    });
    return frag;
  }

  const strip = (text) => String(text).replace(/§./g, '');

  MC.translate = translate;
  MC.formatted = formatted;
  MC.stripFormat = strip;
  MC.stripColors = strip;
})();
