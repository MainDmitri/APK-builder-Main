// Синхронный zlib (RFC 1950/1951) для пакетов сервера.
// DecompressionStream асинхронный: каждый batch ждёт несколько циклов событий, и при толпе игроков
// (десятки пакетов движения в секунду) очередь растёт — игра «пингует». Здесь пакет разбирается сразу.
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  const LBASE = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
  const LEXT = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
  const DBASE = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
  const DEXT = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
  const CLORDER = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];

  // Таблица быстрого декодирования: индекс — следующие bits бит потока, значение — (символ << 4) | длина кода
  function buildTable(lengths, n) {
    let max = 0;
    const count = new Uint16Array(16);
    for (let i = 0; i < n; i++) { const l = lengths[i]; count[l]++; if (l > max) max = l; }
    count[0] = 0;
    if (max === 0) return { table: new Uint32Array(2), bits: 1 };
    const next = new Uint16Array(16);
    let code = 0;
    for (let b = 1; b <= 15; b++) { code = (code + count[b - 1]) << 1; next[b] = code; }
    const size = 1 << max;
    const table = new Uint32Array(size);
    for (let sym = 0; sym < n; sym++) {
      const len = lengths[sym];
      if (!len) continue;
      let c = next[len]++;
      let r = 0;
      for (let k = 0; k < len; k++) { r = (r << 1) | (c & 1); c >>= 1; }
      const v = (sym << 4) | len;
      for (let i = r; i < size; i += 1 << len) table[i] = v;
    }
    return { table, bits: max };
  }

  let FIXED_L = null, FIXED_D = null;
  function fixedTables() {
    if (FIXED_L) return;
    const l = new Uint8Array(288);
    for (let i = 0; i < 144; i++) l[i] = 8;
    for (let i = 144; i < 256; i++) l[i] = 9;
    for (let i = 256; i < 280; i++) l[i] = 7;
    for (let i = 280; i < 288; i++) l[i] = 8;
    FIXED_L = buildTable(l, 288);
    const d = new Uint8Array(30).fill(5);
    FIXED_D = buildTable(d, 30);
  }

  function inflate(src) {
    if (src.length < 2) throw new Error('zlib: пустые данные');
    const cmf = src[0], flg = src[1];
    if ((cmf & 0x0f) !== 8 || ((cmf << 8) | flg) % 31 !== 0) throw new Error('zlib: неверный заголовок');
    if (flg & 0x20) throw new Error('zlib: словарь не поддерживается');
    let pos = 2, buf = 0, cnt = 0;
    let out = new Uint8Array(Math.max(1024, src.length * 4));
    let op = 0;
    const end = src.length;

    const need = (n) => {
      while (cnt < n) {
        if (pos > end + 4) throw new Error('zlib: данные оборваны');
        buf |= (pos < end ? src[pos] : 0) << cnt;
        pos++;
        cnt += 8;
      }
    };
    const bits = (n) => {
      if (n === 0) return 0;
      need(n);
      const v = buf & ((1 << n) - 1);
      buf >>>= n; cnt -= n;
      return v;
    };
    const sym = (h) => {
      need(h.bits);
      const e = h.table[buf & ((1 << h.bits) - 1)];
      const len = e & 15;
      if (!len) throw new Error('zlib: неверный код');
      buf >>>= len; cnt -= len;
      return e >>> 4;
    };
    const grow = (n) => {
      if (op + n <= out.length) return;
      let size = out.length * 2;
      while (size < op + n) size *= 2;
      const o = new Uint8Array(size);
      o.set(out.subarray(0, op));
      out = o;
    };

    const lens = new Uint8Array(320);
    let final = 0;
    do {
      final = bits(1);
      const type = bits(2);
      if (type === 0) {
        // Несжатый блок: выравнивание на байт, лишние прочитанные байты возвращаются
        buf >>>= cnt & 7; cnt -= cnt & 7;
        pos -= cnt >> 3; buf = 0; cnt = 0;
        if (pos + 4 > end) throw new Error('zlib: данные оборваны');
        const len = src[pos] | (src[pos + 1] << 8);
        pos += 4;
        if (pos + len > end) throw new Error('zlib: данные оборваны');
        grow(len);
        out.set(src.subarray(pos, pos + len), op);
        op += len; pos += len;
        continue;
      }
      let lt, dt;
      if (type === 1) {
        fixedTables();
        lt = FIXED_L; dt = FIXED_D;
      } else if (type === 2) {
        const hlit = bits(5) + 257, hdist = bits(5) + 1, hclen = bits(4) + 4;
        const cl = new Uint8Array(19);
        for (let i = 0; i < hclen; i++) cl[CLORDER[i]] = bits(3);
        const ct = buildTable(cl, 19);
        lens.fill(0);
        let i = 0;
        while (i < hlit + hdist) {
          const s = sym(ct);
          if (s < 16) lens[i++] = s;
          else if (s === 16) {
            if (i === 0) throw new Error('zlib: неверные длины');
            const prev = lens[i - 1];
            for (let r = 3 + bits(2); r > 0; r--) lens[i++] = prev;
          } else if (s === 17) i += 3 + bits(3);
          else i += 11 + bits(7);
          if (i > hlit + hdist) throw new Error('zlib: неверные длины');
        }
        lt = buildTable(lens.subarray(0, hlit), hlit);
        dt = buildTable(lens.subarray(hlit, hlit + hdist), hdist);
      } else throw new Error('zlib: неверный тип блока');

      for (;;) {
        const s = sym(lt);
        if (s < 256) {
          if (op >= out.length) grow(1);
          out[op++] = s;
        } else if (s === 256) break;
        else {
          const li = s - 257;
          if (li >= 29) throw new Error('zlib: неверная длина');
          const len = LBASE[li] + bits(LEXT[li]);
          const di = sym(dt);
          if (di >= 30) throw new Error('zlib: неверное расстояние');
          const dist = DBASE[di] + bits(DEXT[di]);
          if (dist > op) throw new Error('zlib: расстояние за началом');
          grow(len);
          let from = op - dist;
          for (let k = 0; k < len; k++) out[op++] = out[from++];
        }
      }
    } while (!final);
    return out.slice(0, op);
  }

  function adler32(d) {
    let a = 1, b = 0;
    for (let i = 0; i < d.length;) {
      const stop = Math.min(d.length, i + 3800);
      for (; i < stop; i++) { a += d[i]; b += a; }
      a %= 65521; b %= 65521;
    }
    return ((b << 16) | a) >>> 0;
  }

  // Упаковка в zlib несжатыми блоками: исходящие пакеты маленькие (движение, клики),
  // сжатие им почти ничего не даёт, а отправка происходит в том же кадре
  function deflateStored(d) {
    const blocks = Math.max(1, Math.ceil(d.length / 65535));
    const out = new Uint8Array(2 + d.length + blocks * 5 + 4);
    out[0] = 0x78; out[1] = 0x01;
    let o = 2;
    for (let b = 0; b < blocks; b++) {
      const start = b * 65535, len = Math.min(65535, d.length - start);
      out[o++] = b === blocks - 1 ? 1 : 0;
      out[o++] = len & 0xff; out[o++] = len >> 8;
      out[o++] = ~len & 0xff; out[o++] = (~len >> 8) & 0xff;
      out.set(d.subarray(start, start + len), o);
      o += len;
    }
    const s = adler32(d);
    out[o++] = s >>> 24; out[o++] = (s >>> 16) & 0xff; out[o++] = (s >>> 8) & 0xff; out[o++] = s & 0xff;
    return out;
  }

  MC.Zlib = { inflate, deflateStored, adler32 };
})();
