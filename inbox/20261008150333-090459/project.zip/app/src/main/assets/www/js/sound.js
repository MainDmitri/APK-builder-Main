// Звук: файлы FSB5 из Minecraft PE 1.1.5 (PCM16 и FADPCM) декодируются в браузере и играются через Web Audio
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  const FREQ = [0, 8000, 11000, 11025, 16000, 22050, 24000, 32000, 44100, 48000];
  const FADPCM_COEFS = [[0, 0], [60, 0], [122, 60], [115, 52], [98, 55], [0, 0], [0, 0], [0, 0]];

  // Разбор контейнера FSB5: возвращает первый звук файла {rate, channels, data: Float32Array[]}
  function decodeFsb(bytes) {
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    if (String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]) !== 'FSB5') throw new Error('Не FSB5');
    const version = dv.getUint32(4, true);
    const count = dv.getUint32(8, true);
    const headersSize = dv.getUint32(12, true);
    const namesSize = dv.getUint32(16, true);
    const dataSize = dv.getUint32(20, true);
    const mode = dv.getUint32(24, true);
    const base = version === 0 ? 0x40 : 0x3c;
    const dataStart = base + headersSize + namesSize;
    let off = base;
    const samples = [];
    for (let i = 0; i < count; i++) {
      const lo = dv.getUint32(off, true), hi = dv.getUint32(off + 4, true);
      off += 8;
      let extra = lo & 1;
      let rate = FREQ[(lo >>> 1) & 15] || 44100;
      let channels = ((lo >>> 5) & 1) + 1;
      const dataOffset = ((lo >>> 6) + (hi & 3) * 0x4000000) * 16;
      const frames = hi >>> 2;
      while (extra) {
        const v = dv.getUint32(off, true);
        extra = v & 1;
        const size = (v >>> 1) & 0xffffff;
        const type = v >>> 25;
        off += 4;
        if (type === 1) channels = dv.getUint8(off);
        else if (type === 2) rate = dv.getUint32(off, true);
        off += size;
      }
      samples.push({ rate, channels, dataOffset, frames });
    }
    const s = samples[0];
    const end = samples.length > 1 ? samples[1].dataOffset : dataSize;
    const raw = bytes.subarray(dataStart + s.dataOffset, dataStart + end);
    const out = [];
    for (let c = 0; c < s.channels; c++) out.push(new Float32Array(s.frames));
    if (mode === 2) {
      const rv = new DataView(raw.buffer, raw.byteOffset, raw.byteLength);
      const n = Math.min(s.frames, Math.floor(raw.length / 2 / s.channels));
      for (let i = 0; i < n; i++) for (let c = 0; c < s.channels; c++) out[c][i] = rv.getInt16((i * s.channels + c) * 2, true) / 32768;
    } else if (mode === 16) {
      decodeFadpcm(raw, s.channels, s.frames, out);
    } else {
      throw new Error('Кодек FSB ' + mode + ' не поддерживается');
    }
    return { rate: s.rate, channels: s.channels, data: out };
  }

  // FMOD FADPCM: кадры по 0x8c байт (заголовок 0xc + 256 полубайтовых отсчётов), каналы чередуются по кадрам
  function decodeFadpcm(raw, channels, total, out) {
    const dv = new DataView(raw.buffer, raw.byteOffset, raw.byteLength);
    const FRAME = 0x8c;
    let pos = 0, written = 0;
    while (pos + FRAME * channels <= raw.length && written < total) {
      let n = 0;
      for (let c = 0; c < channels; c++) {
        const f = pos + c * FRAME;
        const coefs = dv.getUint32(f, true), shifts = dv.getUint32(f + 4, true);
        let hist1 = dv.getInt16(f + 8, true), hist2 = dv.getInt16(f + 10, true);
        n = 0;
        for (let i = 0; i < 8; i++) {
          const idx = ((coefs >>> (i * 4)) & 15) % 7;
          const shift = 22 - ((shifts >>> (i * 4)) & 15);
          const c1 = FADPCM_COEFS[idx][0], c2 = FADPCM_COEFS[idx][1];
          for (let j = 0; j < 4; j++) {
            const nib = dv.getUint32(f + 12 + i * 16 + j * 4, true);
            for (let k = 0; k < 8; k++) {
              let smp = ((nib >>> (k * 4)) & 15) << 28 >> shift;
              smp = (smp - hist2 * c2 + hist1 * c1) >> 6;
              if (smp > 32767) smp = 32767; else if (smp < -32768) smp = -32768;
              if (written + n < total) out[c][written + n] = smp / 32768;
              n++;
              hist2 = hist1;
              hist1 = smp;
            }
          }
        }
      }
      written += n;
      pos += FRAME * channels;
    }
  }

  const rand = (v, def) => {
    if (v === undefined || v === null) return def;
    if (Array.isArray(v)) return v[0] + Math.random() * (v[1] - v[0]);
    return v;
  };

  // Материал блока для звуков (таблицы block_sounds из sounds.json)
  const GRASS_IDS = new Set([2, 6, 18, 19, 31, 32, 37, 38, 39, 40, 46, 59, 83, 104, 105, 106, 110, 111, 141, 142, 161, 170, 175, 244]);
  const GRAVEL_IDS = new Set([3, 13, 60, 82, 198, 243]);
  const SAND_IDS = new Set([12, 88]);
  const CLOTH_IDS = new Set([35, 92, 171]);
  const GLASS_IDS = new Set([20, 79, 89, 95, 102, 160, 169, 174, 241]);
  const SNOW_IDS = new Set([78, 80]);
  const METAL_IDS = new Set([41, 42, 57, 101, 133, 145, 152]);
  function materialOf(id) {
    if (GRASS_IDS.has(id)) return 'grass';
    if (GRAVEL_IDS.has(id)) return 'gravel';
    if (SAND_IDS.has(id)) return 'sand';
    if (CLOTH_IDS.has(id)) return 'cloth';
    if (GLASS_IDS.has(id)) return 'glass';
    if (SNOW_IDS.has(id)) return 'snow';
    if (METAL_IDS.has(id)) return 'metal';
    if (id === 65) return 'ladder';
    const b = MC.Blocks && MC.Blocks.list[id];
    if (b && b.tool === 'axe') return 'wood';
    if (b && b.tool === 'shovel') return 'gravel';
    return 'stone';
  }

  // Имена существ в entity_sounds по типу сущности
  const ENTITY_NAMES = { 10: 'chicken', 11: 'cow', 12: 'pig', 13: 'sheep', 32: 'zombie', 33: 'creeper', 34: 'skeleton', 35: 'spider', 63: 'player' };

  const Sound = {
    ctx: null,
    master: null,
    volume: 1,
    buffers: new Map(),
    listener: { x: 0, y: 0, z: 0, yaw: 0 },
    loading: null,

    // Данные звуков подключаются отдельным скриптом после запуска, чтобы не задерживать загрузку страницы
    load() {
      if (this.loading) return this.loading;
      this.loading = new Promise((resolve) => {
        if (window.MC_SOUNDS) { resolve(true); return; }
        const s = document.createElement('script');
        s.src = 'js/sounds-data.js';
        s.onload = () => resolve(!!window.MC_SOUNDS);
        s.onerror = () => { console.warn('Файл звуков js/sounds-data.js не найден'); resolve(false); };
        document.head.appendChild(s);
      });
      const unlock = () => {
        this.ensureContext();
        if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
      };
      for (const ev of ['pointerdown', 'touchstart', 'keydown']) window.addEventListener(ev, unlock, { capture: true });
      return this.loading;
    },

    ensureContext() {
      if (this.ctx) return this.ctx;
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.volume;
      this.master.connect(this.ctx.destination);
      return this.ctx;
    },

    setVolume(v) {
      this.volume = typeof v === 'number' ? v : 1;
      if (this.master) this.master.gain.value = this.volume;
    },

    setListener(x, y, z, yaw) {
      const l = this.listener;
      l.x = x; l.y = y; l.z = z; l.yaw = yaw;
    },

    buffer(key) {
      if (this.buffers.has(key)) return this.buffers.get(key);
      let buf = null;
      try {
        const b64 = window.MC_SOUNDS.files[key];
        const bin = atob(b64);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        const d = decodeFsb(bytes);
        buf = this.ctx.createBuffer(d.channels, d.data[0].length, d.rate);
        for (let c = 0; c < d.channels; c++) buf.getChannelData(c).set(d.data[c]);
      } catch (e) {
        console.warn('Звук ' + key + ':', e.message);
      }
      this.buffers.set(key, buf);
      return buf;
    },

    // name — событие из sound_definitions.json; pos — точка в мире или null (звук интерфейса/самого игрока)
    play(name, pos, volume, pitch) {
      const S = window.MC_SOUNDS;
      if (!S || this.volume <= 0 || !name) return;
      const ctx = this.ensureContext();
      if (!ctx || ctx.state !== 'running') return;
      const list = S.defs[name];
      if (!list || !list.length) return;
      const pick = list[Math.floor(Math.random() * list.length)];
      const buf = this.buffer(pick.f);
      if (!buf) return;
      let gain = (volume === undefined ? 1 : volume) * pick.v;
      let pan = 0;
      if (pos) {
        const l = this.listener;
        const dx = pos.x - l.x, dy = pos.y - l.y, dz = pos.z - l.z;
        const dist = Math.hypot(dx, dy, dz);
        const range = 16 * Math.max(1, volume || 1);
        if (dist > range) return;
        gain = Math.min(1, gain) * (1 - dist / range);
        // Камера смотрит в (-sin yaw, cos yaw); правая сторона — (-cos yaw, -sin yaw)
        const yaw = l.yaw * Math.PI / 180;
        if (dist > 0.5) pan = Math.max(-1, Math.min(1, (dx * -Math.cos(yaw) + dz * -Math.sin(yaw)) / dist)) * 0.7;
      }
      if (gain <= 0.001) return;
      // Ограничение одновременных звуков: в толпе шаги и удары десятков игроков перегружают аудио в WebView
      this.voices = this.voices || 0;
      if (this.voices >= (pos ? 20 : 28)) return;
      this.voices++;
      const src = ctx.createBufferSource();
      src.onended = () => { this.voices--; };
      src.buffer = buf;
      src.playbackRate.value = Math.max(0.3, Math.min(3, (pitch === undefined ? 1 : pitch) * pick.p));
      const g = ctx.createGain();
      g.gain.value = Math.min(2, gain);
      src.connect(g);
      if (pan && ctx.createStereoPanner) {
        const p = ctx.createStereoPanner();
        p.pan.value = pan;
        g.connect(p);
        p.connect(this.master);
      } else {
        g.connect(this.master);
      }
      src.start();
    },

    // Событие из таблицы {sound, volume, pitch} или строка с именем звука
    playEntry(entry, pos, baseVol, basePitch) {
      if (!entry) return;
      if (typeof entry === 'string') { this.play(entry, pos, rand(baseVol, 1), rand(basePitch, 1)); return; }
      this.play(entry.sound, pos, rand(entry.volume, rand(baseVol, 1)), rand(entry.pitch, rand(basePitch, 1)));
    },

    // Блок: event = break | place | hit | item.use.on
    block(id, event, x, y, z) {
      const S = window.MC_SOUNDS;
      if (!S) return;
      const m = S.blocks[materialOf(id)] || S.blocks.normal;
      this.playEntry(m.events[event], { x, y, z }, m.volume, m.pitch);
    },

    // Шаги, приземление и прыжок по блоку под ногами: event = step | fall | jump
    step(id, event, x, y, z, volume) {
      const S = window.MC_SOUNDS;
      if (!S) return;
      const m = S.steps[materialOf(id)] || S.steps.normal;
      const e = m.events[event];
      if (!e) return;
      this.play(typeof e === 'string' ? e : e.sound, { x, y, z }, (volume || 0.3) * rand(m.volume, 1), rand(m.pitch, 1));
    },

    // Существо: event = ambient | hurt | death | step | fuse и т. д.
    entity(type, event, x, y, z) {
      const S = window.MC_SOUNDS;
      if (!S) return;
      const name = typeof type === 'number' ? ENTITY_NAMES[type] : type;
      const def = S.entities[name];
      const entry = (def && def.events[event]) || S.entityDefaults.events[event];
      if (!entry) return;
      this.playEntry(entry, { x, y, z }, def ? def.volume : S.entityDefaults.volume, def ? def.pitch : S.entityDefaults.pitch);
    },

    // Отдельные события из individual_event_sounds (explode, chest.open, pop...)
    event(name, x, y, z) {
      const S = window.MC_SOUNDS;
      if (!S) return;
      const e = S.events[name];
      if (e) this.playEntry(e, x === undefined ? null : { x, y, z });
    },

    // Звук от сервера MCPE (LevelSoundEventPacket); extra — id блока или тип существа
    network(id, x, y, z, extra) {
      const E = { 1: 'hit', 4: 'break', 5: 'place', 0: 'item.use.on' };
      if (E[id] !== undefined && extra > 0 && extra < 256) { this.block(extra, E[id], x, y, z); return; }
      if (id === 2 && extra > 0 && extra < 256) { this.step(extra, 'step', x, y, z); return; }
      const ENT = { 9: 'ambient', 13: 'death', 16: 'hurt', 48: 'fuse' };
      if (ENT[id]) { this.entity(ENTITY_NAMES[extra] || 'player', ENT[id], x, y, z); return; }
      const EV = { 20: 'bow', 26: 'fizz', 45: 'explode', 47: 'ignite', 55: 'levelup', 58: 'extinguish.fire', 60: 'chest.open', 61: 'chest.closed',
        70: 'pop', 80: 'burp', 81: 'bucket.fill.water', 82: 'bucket.fill.lava', 83: 'bucket.empty.water', 84: 'bucket.empty.lava', 98: 'glass' };
      if (EV[id]) { this.event(EV[id], x, y, z); return; }
      const DIRECT = { 23: 'damage.fallbig', 24: 'damage.fallsmall', 25: 'random.splash', 28: 'random.swim', 29: 'random.drink', 30: 'random.eat', 40: 'game.player.attack.nodamage' };
      if (DIRECT[id]) this.play(DIRECT[id], { x, y, z }, 1, 0.8 + Math.random() * 0.4);
    },

    click() { this.play('random.click', null, 0.6, 1); }
  };

  Sound.decodeFsb = decodeFsb;
  Sound.materialOf = materialOf;
  MC.Sound = Sound;
})();
