package com.maindmitri.botpanel

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class DeployPlan(
    val manifest: List<String>,
    val changed: Map<String, String>,
    val deletions: List<String>,
    val expectedRevision: Long?,
)

data class LogEntry(val time: String, val title: String, val body: String) {
    override fun toString(): String = "[$time] $title" + if (body.isEmpty()) "" else "\n$body"
}

class PanelViewModel(app: Application) : AndroidViewModel(app) {
    private val storage = Storage(app)

    val aiPrompt: String = storage.asset("ai_prompt.md")

    var token by mutableStateOf(storage.token)
        private set
    var modules by mutableStateOf<Map<String, String>>(storage.loadModules())
        private set
    var openModule by mutableStateOf<String?>(null)
        private set

    var testUserId by mutableStateOf(storage.testUserId)
        private set
    var testText by mutableStateOf(storage.testText)
        private set
    var runModule by mutableStateOf(storage.runModule)
        private set
    var runArgs by mutableStateOf(storage.runArgs)
        private set
    var runCtx by mutableStateOf(storage.runCtx)
        private set

    var busy by mutableStateOf(false)
        private set
    var output by mutableStateOf("")
        private set
    var outputIsError by mutableStateOf(false)
        private set
    var pendingDeploy by mutableStateOf<DeployPlan?>(null)
        private set
    var pendingPull by mutableStateOf<Map<String, String>?>(null)
        private set
    var pendingImport by mutableStateOf<Importer.Result?>(null)
        private set

    val logs = mutableStateListOf<LogEntry>()

    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.ROOT)

    /** Модули, которые можно выполнить в облаке (handlers/ и endpoints/). */
    val runnableModules: List<String>
        get() = modules.keys.filter { it.startsWith("handlers/") || it.startsWith("endpoints/") }

    fun log(title: String, body: String = "") {
        val entry = LogEntry(timeFormat.format(Date()), title, body)
        viewModelScope.launch(Dispatchers.Main.immediate) {
            logs.add(entry)
            if (logs.size > MAX_LOG_ENTRIES) logs.removeRange(0, logs.size - MAX_LOG_ENTRIES)
        }
    }

    fun clearLogs() = logs.clear()

    fun logsText(): String = logs.joinToString("\n\n")

    // ───────── Настройки ─────────

    fun updateToken(v: String) { token = v; storage.token = v.trim() }
    fun updateTestUserId(v: String) { testUserId = v; storage.testUserId = v.trim() }
    fun updateTestText(v: String) { testText = v; storage.testText = v }
    fun updateRunModule(v: String) { runModule = v; storage.runModule = v }
    fun updateRunArgs(v: String) { runArgs = v; storage.runArgs = v }
    fun updateRunCtx(v: String) { runCtx = v; storage.runCtx = v }

    // ───────── Модули ─────────

    fun open(name: String?) { openModule = name }

    fun updateModule(name: String, code: String) {
        modules = (modules + (name to code)).toSortedMap()
        storage.saveModule(name, code)
    }

    /** Создаёт модуль из заготовки. Возвращает текст ошибки или null. */
    fun addModule(rawName: String): String? {
        val name = Project.normalizeName(rawName)
        Project.checkName(name)?.let { return it }
        if (name in modules) return "Модуль $name уже есть"
        updateModule(name, Project.template(name))
        openModule = name
        log("Создан модуль $name")
        return null
    }

    fun renameModule(from: String, rawName: String): String? {
        val to = Project.normalizeName(rawName)
        if (to == from) return null
        Project.checkName(to)?.let { return it }
        if (to in modules) return "Модуль $to уже есть"
        val code = modules[from] ?: return "Модуль $from не найден"
        storage.saveModule(to, code)
        storage.deleteModule(from)
        modules = (modules - from + (to to code)).toSortedMap()
        if (openModule == from) openModule = to
        if (runModule == from) updateRunModule(to)
        log("Модуль $from переименован в $to")
        return null
    }

    fun deleteModule(name: String) {
        storage.deleteModule(name)
        modules = (modules - name).toSortedMap()
        if (openModule == name) openModule = null
        log("Удалён модуль $name")
    }

    fun loadExample() {
        val example = mapOf(
            "handlers/message" to storage.asset("example/handlers/message.js"),
            "handlers/callback_query" to storage.asset("example/handlers/callback_query.js"),
            "lib/keyboard" to storage.asset("example/lib/keyboard.js"),
        )
        pendingImport = Importer.Result(example, example.keys.map { "пример → $it" })
    }

    /** Открытые пользователем .js-файлы. */
    fun importFiles(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            try {
                val files = withContext(Dispatchers.IO) { uris.map { displayName(it) to readText(it) } }
                pendingImport = Importer.fromFiles(files)
            } catch (e: Exception) {
                show("Импорт: ${e.message ?: e.javaClass.simpleName}", true)
                log("✗ Импорт файлов", e.stackTraceToString())
            }
        }
    }

    /** ZIP с проектом tgcloud (папка tgcloud/ или handlers/, lib/, endpoints/, schema.js). */
    fun importZip(uri: Uri) {
        viewModelScope.launch {
            try {
                pendingImport = withContext(Dispatchers.IO) {
                    val resolver = getApplication<Application>().contentResolver
                    resolver.openInputStream(uri)?.use { Importer.fromZip(it) }
                        ?: throw IllegalStateException("Не удалось открыть архив")
                }
            } catch (e: Exception) {
                show("Импорт ZIP: ${e.message ?: e.javaClass.simpleName}", true)
                log("✗ Импорт ZIP", e.stackTraceToString())
            }
        }
    }

    /** Применяет импорт: `replace` — заменить весь проект, иначе добавить/перезаписать модули. */
    fun applyImport(replace: Boolean) {
        val result = pendingImport ?: return
        pendingImport = null
        val merged = if (replace) result.modules.toSortedMap() else (modules + result.modules).toSortedMap()
        storage.replaceAll(merged)
        modules = merged
        openModule = null
        val text = "Импортировано модулей: ${result.modules.size}\n" + result.notes.joinToString("\n")
        show(text, false)
        log("Импорт (${if (replace) "замена проекта" else "добавление"})", text)
    }

    fun cancelImport() { pendingImport = null }

    private fun readText(uri: Uri): String {
        val resolver = getApplication<Application>().contentResolver
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Не удалось открыть файл")
        if (bytes.size > MAX_FILE_BYTES) throw IllegalStateException("Файл больше 1 МБ")
        return String(bytes, Charsets.UTF_8)
    }

    private fun displayName(uri: Uri): String {
        val resolver = getApplication<Application>().contentResolver
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { return it }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "module.js"
    }

    // ───────── Вывод ─────────

    private fun show(text: String, error: Boolean) {
        output = text
        outputIsError = error
    }

    private fun apiOrNull(): TgCloudApi? {
        val t = token.trim()
        validateToken(t)?.let { show(it, true); return null }
        return TgCloudApi(t) { title, body -> log(title, body) }
    }

    private fun launchAction(title: String, action: suspend () -> String) {
        if (busy) return
        busy = true
        show("$title…", false)
        log("▶ $title")
        viewModelScope.launch {
            try {
                val result = action()
                show(result, false)
                log("✓ $title", result)
            } catch (e: TgCloudException) {
                val text = "$title: ${e.details()}"
                show(text, true)
                log("✗ $title", text)
            } catch (e: Exception) {
                show("$title: ${e.message ?: e.javaClass.simpleName}", true)
                log("✗ $title", e.stackTraceToString())
            } finally {
                busy = false
            }
        }
    }

    private fun lintReport(issues: List<Project.Issue>): String =
        issues.joinToString("\n") { it.toString() }

    // ───────── Действия ─────────

    /** Локальная проверка всех модулей, без сети. */
    fun check() {
        if (modules.isEmpty()) { show("В проекте нет модулей. Добавьте или импортируйте файлы.", true); return }
        val issues = Project.lint(modules)
        val errors = issues.count { it.error }
        val text = if (issues.isEmpty()) {
            "✅ Проблем не найдено.\nМодули: ${modules.keys.joinToString()}"
        } else {
            "Ошибок: $errors, предупреждений: ${issues.size - errors}\n\n" + lintReport(issues) +
                "\n\nПроверка локальная и приблизительная — окончательно код проверяет сервер при деплое."
        }
        show(text, errors > 0)
        log("Проверка кода", text)
    }

    fun status() {
        val api = apiOrNull() ?: return
        launchAction("Статус") {
            val state = api.getState()
            val wh = api.getWebhook()
            val diff = describeDiff(state.modules)
            buildString {
                appendLine("✅ Токен принят (${token.trim().substringBefore(':')})")
                appendLine("Ревизия в облаке: ${state.revision ?: "—"}")
                appendLine("Модули в облаке: ${state.modules.keys.sorted().joinToString().ifEmpty { "нет" }}")
                appendLine(diff)
                append(formatWebhook(wh))
            }
        }
    }

    private fun describeDiff(cloud: Map<String, String>): String {
        val added = modules.keys.filter { it !in cloud }
        val changed = modules.keys.filter { it in cloud && cloud[it] != modules[it] }
        val removed = cloud.keys.filter { it !in modules }
        if (added.isEmpty() && changed.isEmpty() && removed.isEmpty()) return "Локальный проект совпадает с облаком."
        return buildString {
            append("Отличия от облака:")
            added.forEach { append("\n  + $it (новый)") }
            changed.forEach { append("\n  ~ $it (изменён)") }
            removed.forEach { append("\n  - $it (есть только в облаке)") }
        }
    }

    /** Скачивает модули из облака (как `tgcloud pull`). */
    fun pull() {
        val api = apiOrNull() ?: return
        launchAction("Загрузка из облака") {
            val state = api.getState()
            if (state.modules.isEmpty()) return@launchAction "В облаке нет модулей."
            if (modules.isEmpty()) {
                applyPull(state.modules)
            } else {
                pendingPull = state.modules
                "Ожидает подтверждения: локальный проект будет заменён модулями из облака"
            }
        }
    }

    fun confirmPull() {
        val cloud = pendingPull ?: return
        pendingPull = null
        show(applyPull(cloud), false)
    }

    fun cancelPull() {
        pendingPull = null
        show("Загрузка из облака отменена", false)
    }

    private fun applyPull(cloud: Map<String, String>): String {
        val valid = cloud.filterKeys { Project.checkName(it) == null }.toSortedMap()
        storage.replaceAll(valid)
        modules = valid
        openModule = null
        val skipped = cloud.keys - valid.keys
        val text = "✅ Загружено из облака: ${valid.keys.joinToString()}" +
            if (skipped.isEmpty()) "" else "\nПропущены (неизвестный формат имени): ${skipped.joinToString()}"
        log("Загрузка из облака", text)
        return text
    }

    /** Деплой всего проекта (как `tgcloud push`). */
    fun deploy() {
        val api = apiOrNull() ?: return
        if (modules.isEmpty()) { show("В проекте нет модулей.", true); return }
        val badNames = modules.keys.mapNotNull { Project.checkName(it) }
        if (badNames.isNotEmpty()) { show("Исправьте имена модулей:\n" + badNames.joinToString("\n"), true); return }
        val issues = Project.lint(modules)
        if (issues.isNotEmpty()) log("Локальная проверка перед деплоем", lintReport(issues))
        launchAction("Деплой") {
            val state = api.getState()
            val manifest = modules.keys.toList()
            val changed = modules.filter { (name, code) -> state.modules[name] != code }
            val deletions = state.modules.keys.filter { it !in modules }.sorted()
            if (changed.isEmpty() && deletions.isEmpty()) {
                return@launchAction "Изменений нет: в облаке уже этот код (ревизия ${state.revision ?: "—"}).\n" +
                    formatWebhook(api.getWebhook())
            }
            val plan = DeployPlan(manifest, changed, deletions, state.revision)
            if (deletions.isNotEmpty()) {
                pendingDeploy = plan
                "Ожидает подтверждения: в облаке будут удалены ${deletions.joinToString()}"
            } else {
                runDeploy(api, plan)
            }
        }
    }

    fun confirmDeploy() {
        val plan = pendingDeploy ?: return
        pendingDeploy = null
        val api = apiOrNull() ?: return
        launchAction("Деплой") { runDeploy(api, plan) }
    }

    fun cancelDeploy() {
        pendingDeploy = null
        show("Деплой отменён", false)
    }

    private suspend fun runDeploy(api: TgCloudApi, plan: DeployPlan): String {
        val result = try {
            api.deploy(plan.manifest, plan.changed, plan.expectedRevision)
        } catch (e: TgCloudException) {
            if (e.isRevisionMismatch) {
                throw TgCloudException(
                    e.message + "\nБота изменили из другого места (CLI?) — нажмите «Статус», затем деплой ещё раз " +
                        "или «Из облака», чтобы забрать облачную версию.",
                    e.type, e.code, e.parameters, e.status,
                )
            }
            val issues = Project.lint(modules)
            if (issues.isEmpty()) throw e
            throw TgCloudException(
                e.message + "\n\nЛокальная проверка подсказывает:\n" + lintReport(issues),
                e.type, e.code, e.parameters, e.status,
            )
        }
        var wh = api.getWebhook()
        val fixed = !wh.inSync
        if (fixed) wh = api.syncWebhook(dropPending = false)
        return buildString {
            appendLine("✅ Задеплоено, ревизия ${result.revision ?: "—"}")
            appendLine("Отправлено: ${plan.changed.keys.joinToString()}")
            if (plan.deletions.isNotEmpty()) appendLine("Удалено: ${plan.deletions.joinToString()}")
            appendLine("В облаке: ${result.modules.joinToString()}")
            val db = result.dbChanges
            if (db != null && db.length() > 0) {
                appendLine("Схема базы отличается от базы (${db.length()} изм.) — деплой базу не меняет, примените миграцию: npx tgcloud migrate")
            }
            if (fixed) appendLine("Вебхук был не в синхронизации — исправлен.")
            append(formatWebhook(wh))
        }
    }

    fun syncWebhook(dropPending: Boolean) {
        val api = apiOrNull() ?: return
        launchAction("Вебхук") { "✅ Вебхук синхронизирован\n" + formatWebhook(api.syncWebhook(dropPending)) }
    }

    /** Шаблон аргументов для выбранного модуля. */
    fun fillArgsTemplate() {
        val userId = testUserId.trim().toLongOrNull() ?: 0L
        val text = testText.ifEmpty { "/start" }
        val from = JSONObject().put("id", userId).put("is_bot", false).put("first_name", "Test")
        val chat = JSONObject().put("id", userId).put("type", "private")
        val args = when (runModule) {
            "handlers/message", "handlers/edited_message", "handlers/business_message" -> JSONObject()
                .put("message_id", 1)
                .put("date", System.currentTimeMillis() / 1000)
                .put("chat", chat)
                .put("from", from)
                .put("text", text)
            "handlers/callback_query" -> JSONObject()
                .put("id", "1")
                .put("from", from)
                .put("chat_instance", "1")
                .put("data", text)
                .put("message", JSONObject().put("message_id", 1).put("date", System.currentTimeMillis() / 1000).put("chat", chat).put("text", "…"))
            "handlers/pre_checkout_query" -> JSONObject()
                .put("id", "1")
                .put("from", from)
                .put("currency", "XTR")
                .put("total_amount", 1)
                .put("invoice_payload", "test")
            "handlers/inline_query" -> JSONObject()
                .put("id", "1")
                .put("from", from)
                .put("query", text)
                .put("offset", "")
            else -> JSONObject()
        }
        updateRunArgs(args.toString(2))
        if (runModule.startsWith("endpoints/")) {
            updateRunCtx(JSONObject().put("initData", JSONObject().put("user", from)).toString(2))
        } else {
            updateRunCtx("{}")
        }
    }

    /** Выполняет модуль в облаке на локальном коде, без деплоя (как `tgcloud run`). */
    fun test() {
        val api = apiOrNull() ?: return
        val module = runModule
        if (module !in modules) { show("Выберите модуль для запуска (handlers/… или endpoints/…).", true); return }
        val args = parseObject(runArgs, "args") ?: return
        val ctx = parseObject(runCtx, "ctx") ?: return
        launchAction("Запуск $module") {
            val r = api.run(module, modules, args, ctx)
            buildString {
                appendLine("> $module(${args.toString().take(300)})")
                if (r.logs.isEmpty()) appendLine("(лог пуст)") else r.logs.forEach { appendLine(it) }
                append(if (r.failed) "✗ " else "< ").append(r.result)
                r.timeMs?.let { append("  ${it} мс") }
                if (module.startsWith("handlers/")) append("\n\nВызовы api.* выполнены по-настоящему: ответы бота приходят в Telegram.")
            }
        }
    }

    private fun parseObject(text: String, what: String): JSONObject? {
        if (text.isBlank()) return JSONObject()
        return try {
            JSONObject(text)
        } catch (e: Exception) {
            show("$what — не JSON-объект: ${e.message}", true)
            null
        }
    }

    private fun formatWebhook(wh: WebhookInfo): String = buildString {
        appendLine()
        appendLine("Вебхук: ${if (wh.inSync) "✅ в синхронизации" else "❌ НЕ в синхронизации"}")
        appendLine("url: ${wh.url.ifEmpty { "(не задан)" }}")
        appendLine("обновления: ${wh.allowedUpdates.joinToString().ifEmpty { "(нет)" }}")
        if (!wh.inSync) {
            wh.expectedUrl?.let { appendLine("ожидается url: $it") }
            if (wh.expectedUpdates.isNotEmpty()) appendLine("ожидаются обновления: ${wh.expectedUpdates.joinToString()}")
        }
        append("в очереди: ${wh.pendingUpdates}")
        wh.lastError?.let {
            append("\nпоследняя ошибка: $it")
            wh.lastErrorDate?.let { d -> append(" (${SimpleDateFormat("dd.MM HH:mm:ss", Locale.ROOT).format(Date(d * 1000))})") }
        }
    }

    private companion object {
        const val MAX_FILE_BYTES = 1_048_576
        const val MAX_LOG_ENTRIES = 500
    }
}
