package com.dahua.checker

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

object ResultStorage {

    private const val PREFS_NAME = "dahua_results"
    private const val KEY_RESULTS = "saved_results"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun save(context: Context, results: List<ScanResult>) {
        val arr = JSONArray()
        for (r in results) {
            if (r.blocked) continue
            val obj = JSONObject().apply {
                put("ip", r.ip)
                put("port", r.port)
                put("login", r.login)
                put("password", r.password)
                put("model", r.model)
                put("channels", r.channels)
                put("brand", r.brand)
                put("hasMic", r.hasMic)
                put("timestampMs", r.timestampMs)
                if (r.snapshot != null && r.snapshot.size > 100) {
                    put("snapshot", Base64.encodeToString(r.snapshot, Base64.NO_WRAP))
                }
            }
            arr.put(obj)
        }
        prefs(context).edit().putString(KEY_RESULTS, arr.toString()).apply()
    }

    fun load(context: Context): List<ScanResult> {
        val json = prefs(context).getString(KEY_RESULTS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(json)
            val list = mutableListOf<ScanResult>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val snap = if (obj.has("snapshot")) {
                    try { Base64.decode(obj.getString("snapshot"), Base64.NO_WRAP) } catch (_: Exception) { null }
                } else null
                list.add(ScanResult(
                    ip = obj.getString("ip"),
                    port = obj.getInt("port"),
                    login = obj.getString("login"),
                    password = obj.getString("password"),
                    model = obj.optString("model", ""),
                    channels = obj.optInt("channels", 0),
                    snapshot = snap,
                    brand = obj.optString("brand", "Dahua"),
                    hasMic = obj.optBoolean("hasMic", false),
                    timestampMs = obj.optLong("timestampMs", 0L)
                ))
            }
            list
        } catch (_: Exception) { emptyList() }
    }

    fun addResult(context: Context, result: ScanResult) {
        val existing = load(context).toMutableList()
        // Не дублировать по IP:port
        existing.removeAll { it.ip == result.ip && it.port == result.port }
        existing.add(0, result)
        save(context, existing)
    }

    fun addResults(context: Context, newResults: List<ScanResult>) {
        val existing = load(context).toMutableList()
        for (r in newResults) {
            if (r.blocked) continue
            existing.removeAll { it.ip == r.ip && it.port == r.port }
            existing.add(0, r)
        }
        save(context, existing)
    }

    fun clear(context: Context) {
        prefs(context).edit().remove(KEY_RESULTS).apply()
    }

    fun delete(context: Context, ip: String, port: Int) {
        val existing = load(context).toMutableList()
        existing.removeAll { it.ip == ip && it.port == port }
        save(context, existing)
    }
}
