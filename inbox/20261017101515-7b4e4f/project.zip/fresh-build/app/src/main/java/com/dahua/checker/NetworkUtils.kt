package com.dahua.checker

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.wifi.WifiManager
import android.os.Build
import java.net.Inet4Address
import java.net.NetworkInterface

data class LocalNetwork(
    val ip: String,
    val subnet: String,
    val prefix: Int
)

object NetworkUtils {

    fun getLocalNetwork(context: Context): LocalNetwork? {
        // Способ 1: ConnectivityManager (API 23+)
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return fallbackNetwork()
            val linkProps: LinkProperties = cm.getLinkProperties(network) ?: return fallbackNetwork()

            for (addr in linkProps.linkAddresses) {
                val inetAddr = addr.address
                if (inetAddr is Inet4Address && !inetAddr.isLoopbackAddress) {
                    val ip = inetAddr.hostAddress ?: continue
                    val prefix = addr.prefixLength
                    val subnet = calculateSubnet(ip, prefix)
                    return LocalNetwork(ip, subnet, prefix)
                }
            }
        } catch (_: Exception) {}

        return fallbackNetwork()
    }

    private fun fallbackNetwork(): LocalNetwork? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
            for (iface in interfaces.asSequence()) {
                if (iface.isLoopback || !iface.isUp) continue
                val name = iface.name.lowercase()
                if (name != "wlan0" && name != "eth0" && !name.startsWith("wlan")) continue

                for (ifAddr in iface.interfaceAddresses) {
                    val addr = ifAddr.address
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress ?: continue
                        val prefix = ifAddr.networkPrefixLength.toInt()
                        val subnet = calculateSubnet(ip, prefix)
                        return LocalNetwork(ip, subnet, prefix)
                    }
                }
            }
        } catch (_: Exception) {}
        return null
    }

    private fun calculateSubnet(ip: String, prefix: Int): String {
        val parts = ip.split(".")
        if (parts.size != 4) return "$ip/$prefix"

        val ipLong = parts.fold(0L) { acc, s ->
            (acc shl 8) or (s.toIntOrNull()?.toLong() ?: 0L)
        }

        val mask = if (prefix == 0) 0L else (0xFFFFFFFFL shl (32 - prefix)) and 0xFFFFFFFFL
        val network = ipLong and mask

        val a = (network shr 24) and 0xFF
        val b = (network shr 16) and 0xFF
        val c = (network shr 8) and 0xFF
        val d = network and 0xFF

        return "$a.$b.$c.$d/$prefix"
    }
}
