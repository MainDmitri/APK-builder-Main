package com.mcpehtml.app

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import java.io.IOException
import java.net.ServerSocket

/**
 * Оболочка игры: полноэкранный WebView с игрой из assets/www и встроенный ретранслятор
 * WebSocket <-> UDP (RelayServer), чтобы не запускать relay.js через Termux.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var relay: RelayServer? = null
    private var relayPort = 0
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data))
        fileCallback = null
    }

    // Доступен в JS как window.AndroidRelay
    inner class RelayBridge {
        @JavascriptInterface
        fun getUrl(): String = "ws://127.0.0.1:$relayPort"

        @JavascriptInterface
        fun isRunning(): Boolean = relay != null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        startRelay()

        web = WebView(this)
        web.setBackgroundColor(0xFF000000.toInt())
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.displayZoomControls = false
        s.textZoom = 100

        // Игра лежит в assets/www и открывается с постоянного https-адреса, как в профиле A движка
        val loader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url
                if (url.host == "appassets.androidplatform.net") {
                    val path = url.path ?: "/"
                    val mapped = if (path == "/" || path.isEmpty()) "/www/index.html" else "/www$path"
                    return loader.shouldInterceptRequest(Uri.parse("https://appassets.androidplatform.net$mapped"))
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.host == "appassets.androidplatform.net") return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, url))
                    true
                } catch (e: Exception) {
                    true
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(webView: WebView, filePathCallback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    fileChooser.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        web.addJavascriptInterface(RelayBridge(), "AndroidRelay")
        setContentView(web)

        onBackPressedDispatcher.addCallback(this) {
            web.evaluateJavascript("(window.MC && MC.App && typeof MC.App.androidBack === 'function') ? MC.App.androidBack() : false") { value ->
                if (value != "true") finish()
            }
        }

        web.loadUrl("https://appassets.androidplatform.net/index.html")
    }

    private fun startRelay() {
        if (relay != null) return
        var port = 0
        try {
            val probe = ServerSocket(0)
            port = probe.localPort
            probe.close()
        } catch (e: IOException) {}
        if (port == 0) port = 28080
        relayPort = port
        val server = RelayServer(port)
        server.start()
        relay = server
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        web.onResume()
        web.resumeTimers()
    }

    override fun onPause() {
        web.onPause()
        web.pauseTimers()
        super.onPause()
    }

    override fun onDestroy() {
        relay?.shutdown()
        relay = null
        web.destroy()
        super.onDestroy()
    }
}
