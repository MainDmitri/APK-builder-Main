// Физика игрока: гравитация, столкновения, плавание, полёт, лестницы; луч выбора блока
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const Blocks = MC.Blocks;

  const HALF = 0.3, HEIGHT = 1.8, EYE = 1.62;

  class Player {
    constructor(world) {
      this.world = world;
      this.x = 0; this.y = 80; this.z = 0;
      this.vx = 0; this.vy = 0; this.vz = 0;
      this.yaw = 0; this.pitch = 0;
      this.onGround = false;
      this.flying = false;
      this.canFly = true;
      this.noClip = false;
      this.inWater = false;
      this.inLava = false;
      this.headInWater = false;
      this.sprinting = false;
      this.sneaking = false;
      this.fallStart = null;
      this.walkDist = 0;
    }

    get eyeY() { return this.y + EYE; }

    aabb(x, y, z) { return [x - HALF, y, z - HALF, x + HALF, y + HEIGHT, z + HALF]; }

    blockBoxes(minX, minY, minZ, maxX, maxY, maxZ) {
      const out = [];
      const w = this.world;
      for (let x = Math.floor(minX); x <= Math.floor(maxX); x++) {
        for (let z = Math.floor(minZ); z <= Math.floor(maxZ); z++) {
          if (!w.isLoaded(x, z)) { out.push([x, -64, z, x + 1, 512, z + 1]); continue; }
          for (let y = Math.floor(minY) - 1; y <= Math.floor(maxY); y++) {
            const id = w.getId(x, y, z);
            if (id === 0) continue;
            const bx = Blocks.collisionBoxes(id, w.getData(x, y, z), w, x, y, z);
            if (!bx) continue;
            for (const b of bx) out.push([x + b[0], y + b[1], z + b[2], x + b[3], y + b[4], z + b[5]]);
          }
        }
      }
      return out;
    }

    moveAxis(axis, d) {
      if (d === 0) return 0;
      const bb = this.aabb(this.x, this.y, this.z);
      const lo = bb.slice(0, 3), hi = bb.slice(3);
      const qlo = lo.slice(), qhi = hi.slice();
      if (d > 0) qhi[axis] += d; else qlo[axis] += d;
      const boxes = this.blockBoxes(qlo[0], qlo[1], qlo[2], qhi[0], qhi[1], qhi[2]);
      const a1 = (axis + 1) % 3, a2 = (axis + 2) % 3;
      for (const b of boxes) {
        if (hi[a1] <= b[a1] + 1e-7 || lo[a1] >= b[a1 + 3] - 1e-7) continue;
        if (hi[a2] <= b[a2] + 1e-7 || lo[a2] >= b[a2 + 3] - 1e-7) continue;
        // Допуск 1 мм: координаты с сервера приходят во float и могут чуть «утопить» игрока в блок
        if (d > 0 && hi[axis] <= b[axis] + 1e-3) d = Math.min(d, b[axis] - hi[axis]);
        else if (d < 0 && lo[axis] >= b[axis + 3] - 1e-3) d = Math.max(d, b[axis + 3] - lo[axis]);
      }
      if (axis === 0) this.x += d; else if (axis === 1) this.y += d; else this.z += d;
      return d;
    }

    blockAt(x, y, z) { return this.world.getId(Math.floor(x), Math.floor(y), Math.floor(z)); }

    collidesAt(x, y, z) {
      const bb = this.aabb(x, y, z);
      return this.blockBoxes(bb[0] + 0.001, bb[1] + 0.001, bb[2] + 0.001, bb[3] - 0.001, bb[4] - 0.001, bb[5] - 0.001).some((b) =>
        bb[3] > b[0] && bb[0] < b[3] && bb[4] > b[1] && bb[1] < b[4] && bb[5] > b[2] && bb[2] < b[5]);
    }

    // input: {forward, strafe (-1..1), jump, sneak, sprint}; возвращает урон от падения в блоках (для одиночной игры)
    update(dt, input) {
      dt = Math.min(dt, 0.1);
      if (!this.world.isLoaded(Math.floor(this.x), Math.floor(this.z))) return 0;
      const feet = this.blockAt(this.x, this.y + 0.1, this.z);
      const body = this.blockAt(this.x, this.y + 0.9, this.z);
      const head = this.blockAt(this.x, this.y + EYE, this.z);
      const isWater = (id) => id === 8 || id === 9;
      const isLava = (id) => id === 10 || id === 11;
      this.inWater = isWater(feet) || isWater(body);
      this.inLava = isLava(feet) || isLava(body);
      this.headInWater = isWater(head);
      this.headInLava = isLava(head);
      const climbing = Blocks.list[feet].climbable || Blocks.list[body].climbable;
      this.sneaking = !!input.sneak && !this.flying;
      if (!this.canFly) this.flying = false;

      const yaw = this.yaw * Math.PI / 180;
      const fx = -Math.sin(yaw), fz = Math.cos(yaw);
      const rx = -fz, rz = fx;
      let mx = fx * input.forward + rx * input.strafe;
      let mz = fz * input.forward + rz * input.strafe;
      const len = Math.hypot(mx, mz);
      if (len > 1) { mx /= len; mz /= len; }
      this.sprinting = !!input.sprint && input.forward > 0 && !this.sneaking;

      let speed;
      if (this.flying) speed = this.sprinting ? 21.6 : 10.9;
      else if (this.inWater || this.inLava) speed = 2.2;
      else if (this.sneaking) speed = 1.3;
      else speed = this.sprinting ? 5.6 : 4.317;

      const accel = this.flying ? 10 : this.onGround ? 20 : this.inWater ? 10 : 5;
      const k = Math.min(1, accel * dt);
      this.vx += (mx * speed - this.vx) * k;
      this.vz += (mz * speed - this.vz) * k;

      if (this.flying) {
        const target = (input.jump ? 1 : 0) - (input.sneak ? 1 : 0);
        this.vy += (target * 7.5 - this.vy) * Math.min(1, 10 * dt);
      } else if (this.inWater || this.inLava) {
        this.vy -= 8 * dt;
        if (input.jump) this.vy = Math.min(this.vy + 30 * dt, 3.2);
        this.vy = Math.max(this.vy, -3);
      } else if (climbing) {
        this.vy -= 32 * dt;
        if (input.jump || (len > 0.1 && this.horizontalBlocked)) this.vy = 2.35;
        else if (this.sneaking) this.vy = 0;
        else this.vy = Math.max(this.vy, -2.3);
      } else {
        this.vy -= 32 * dt;
        this.vy = Math.max(this.vy, -78);
        if (input.jump && this.onGround) this.vy = 9.0;
      }

      const ox = this.x, oz = this.z;
      const startY = this.y;
      let dx = this.vx * dt, dz = this.vz * dt;
      // Осторожный шаг: при приседании не падать с края
      if (this.sneaking && this.onGround) {
        const step = 0.05;
        while (dx !== 0 && !this.collidesAt(this.x + dx, this.y - 0.6, this.z)) dx = Math.abs(dx) < step ? 0 : dx - Math.sign(dx) * step;
        while (dz !== 0 && !this.collidesAt(this.x, this.y - 0.6, this.z + dz)) dz = Math.abs(dz) < step ? 0 : dz - Math.sign(dz) * step;
      }
      const wantDy = this.vy * dt;
      const ry = this.moveAxis(1, wantDy);
      const rxm = this.moveAxis(0, dx);
      const rzm = this.moveAxis(2, dz);
      this.horizontalBlocked = Math.abs(rxm - dx) > 1e-4 || Math.abs(rzm - dz) > 1e-4;
      if (Math.abs(rxm - dx) > 1e-6) this.vx = 0;
      if (Math.abs(rzm - dz) > 1e-6) this.vz = 0;
      const wasGround = this.onGround;
      this.onGround = wantDy < 0 && ry > wantDy + 1e-6;
      if (Math.abs(ry - wantDy) > 1e-6) this.vy = 0;
      if (this.onGround && this.flying) this.flying = false;

      // Автопрыжок на блок высотой 1 (как в MCPE на сенсорном экране)
      if (input.autoJump && this.onGround && this.horizontalBlocked && len > 0.1 && !this.sneaking) {
        if (!this.collidesAt(this.x + mx * 0.4, this.y + 1.05, this.z + mz * 0.4)) this.vy = 9.0;
      }

      this.walkDist += Math.hypot(this.x - ox, this.z - oz);

      // Высота падения для урона
      let fall = 0;
      if (this.onGround || this.inWater || this.flying || climbing) {
        if (this.fallStart !== null && this.onGround && !wasGround) fall = this.fallStart - this.y;
        this.fallStart = null;
      } else if (this.fallStart === null || this.y > this.fallStart) {
        this.fallStart = Math.max(startY, this.y);
      }
      return fall;
    }

    lookDir() {
      const yaw = this.yaw * Math.PI / 180, pitch = this.pitch * Math.PI / 180;
      return [-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch)];
    }

    // Луч из глаз по направлению взгляда: ближайший блок с учётом формы
    raycast(maxDist) {
      const w = this.world;
      const o = [this.x, this.eyeY, this.z];
      const d = this.lookDir();
      let x = Math.floor(o[0]), y = Math.floor(o[1]), z = Math.floor(o[2]);
      const step = d.map((v) => (v > 0 ? 1 : v < 0 ? -1 : 0));
      const tDelta = d.map((v) => (v !== 0 ? Math.abs(1 / v) : Infinity));
      const tMax = [0, 1, 2].map((i) => {
        if (d[i] === 0) return Infinity;
        const cell = [x, y, z][i];
        return d[i] > 0 ? (cell + 1 - o[i]) / d[i] : (o[i] - cell) / -d[i];
      });
      for (let i = 0; i < 200; i++) {
        const id = w.getId(x, y, z);
        if (id !== 0) {
          const data = w.getData(x, y, z);
          const boxes = Blocks.selectionBoxes(id, data, w, x, y, z);
          if (boxes) {
            let best = null;
            for (const b of boxes) {
              const hit = rayBox(o, d, [x + b[0], y + b[1], z + b[2], x + b[3], y + b[4], z + b[5]]);
              if (hit && hit.t <= maxDist && (!best || hit.t < best.t)) best = hit;
            }
            if (best) {
              return { x, y, z, id, data, face: best.face, t: best.t, boxes, hit: [o[0] + d[0] * best.t, o[1] + d[1] * best.t, o[2] + d[2] * best.t] };
            }
          }
        }
        let a = 0;
        if (tMax[1] < tMax[a]) a = 1;
        if (tMax[2] < tMax[a]) a = 2;
        if (tMax[a] > maxDist) return null;
        if (a === 0) x += step[0]; else if (a === 1) y += step[1]; else z += step[2];
        tMax[a] += tDelta[a];
        if (y < -1 || y > 256) return null;
      }
      return null;
    }

    // Пересечение луча взгляда с сущностями: [{eid, x, y, z, w, h}]
    raycastEntities(list, maxDist) {
      const o = [this.x, this.eyeY, this.z];
      const d = this.lookDir();
      let best = null;
      for (const e of list) {
        const hw = e.w / 2;
        const hit = rayBox(o, d, [e.x - hw, e.y, e.z - hw, e.x + hw, e.y + e.h, e.z + hw]);
        if (hit && hit.t <= maxDist && (!best || hit.t < best.t)) best = { eid: e.eid, t: hit.t };
      }
      return best;
    }
  }

  function rayBox(o, d, b) {
    let tmin = -Infinity, tmax = Infinity, face = -1;
    for (let i = 0; i < 3; i++) {
      if (Math.abs(d[i]) < 1e-9) {
        if (o[i] < b[i] || o[i] > b[i + 3]) return null;
        continue;
      }
      let t1 = (b[i] - o[i]) / d[i], t2 = (b[i + 3] - o[i]) / d[i];
      let f1 = [4, 0, 2][i], f2 = [5, 1, 3][i];
      if (t1 > t2) { const t = t1; t1 = t2; t2 = t; const f = f1; f1 = f2; f2 = f; }
      if (t1 > tmin) { tmin = t1; face = f1; }
      if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return null;
    }
    if (tmax < 0) return null;
    return { t: Math.max(0, tmin), face };
  }

  MC.Player = Player;
  MC.PLAYER_EYE = EYE;
})();
