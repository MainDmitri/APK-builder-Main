// Экраны инвентаря в стиле Java Edition с управлением как в Minecraft Bedrock (касания) и Java (мышь):
// инвентарь с бронёй и крафтом 2x2, верстак 3x3, сундук, печь, творческий список. Один код для одиночной и сетевой игры.
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const S = () => MC.Survival;
  const ARMOR_WINDOW = 0x78;

  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined && text !== null) e.textContent = text;
    return e;
  }

  const copy = (it) => (it ? { id: it.id, data: it.data, count: it.count, nbt: it.nbt } : null);
  // Предметы с сервера приходят с пустым NBT (Uint8Array длины 0) — это «без NBT»
  const hasNbt = (it) => !!it.nbt && (it.nbt.length === undefined ? Object.keys(it.nbt).length > 0 : it.nbt.length > 0);
  const same = (a, b) => !!a && !!b && a.id === b.id && a.data === b.data && !hasNbt(a) && !hasNbt(b);

  // Вид игрока спереди из текстуры скина (64x32 или 64x64)
  const previewCache = new Map();
  function skinPreview(rgba) {
    const key = rgba.length + ':' + rgba[2000] + ':' + rgba[5000] + ':' + rgba[8000 % rgba.length];
    if (previewCache.has(key)) return previewCache.get(key);
    const h = rgba.length === 16384 ? 64 : 32;
    const src = document.createElement('canvas');
    src.width = 64;
    src.height = h;
    src.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(rgba), 64, h), 0, 0);
    const out = document.createElement('canvas');
    out.width = 16;
    out.height = 32;
    const g = out.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.drawImage(src, 8, 8, 8, 8, 4, 0, 8, 8);
    g.drawImage(src, 20, 20, 8, 12, 4, 8, 8, 12);
    g.drawImage(src, 44, 20, 4, 12, 0, 8, 4, 12);
    if (h === 64) g.drawImage(src, 36, 52, 4, 12, 12, 8, 4, 12); else g.drawImage(src, 44, 20, 4, 12, 12, 8, 4, 12);
    g.drawImage(src, 4, 20, 4, 12, 4, 20, 4, 12);
    if (h === 64) g.drawImage(src, 20, 52, 4, 12, 8, 20, 4, 12); else g.drawImage(src, 4, 20, 4, 12, 8, 20, 4, 12);
    g.drawImage(src, 40, 8, 8, 8, 4, 0, 8, 8);
    if (h === 64) {
      g.drawImage(src, 20, 36, 8, 12, 4, 8, 8, 12);
      g.drawImage(src, 44, 36, 4, 12, 0, 8, 4, 12);
      g.drawImage(src, 52, 52, 4, 12, 12, 8, 4, 12);
      g.drawImage(src, 4, 36, 4, 12, 4, 20, 4, 12);
      g.drawImage(src, 4, 52, 4, 12, 8, 20, 4, 12);
    }
    const url = out.toDataURL();
    previewCache.set(key, url);
    return url;
  }

  class InvScreen {
    // kind: survival | table | chest | furnace | creative; opts: {chest, furnace} (одиночная) или {window} (сервер)
    constructor(game, kind, opts) {
      this.game = game;
      this.kind = kind;
      this.opts = opts || {};
      this.mp = game.mode === 'mp';
      this.window = this.opts.window || null;
      this.held = null;
      this.heldFrom = null;
      this.heldOrigin = null;
      this.lastTake = null;
      this.slots = [];
      this.grid = kind === 'survival' ? new Array(4).fill(null) : kind === 'table' ? new Array(9).fill(null) : null;
      this.gridFrom = this.grid ? new Array(this.grid.length).fill(null) : null;
      this.gridSize = kind === 'survival' ? 2 : 3;
      this.dirty = new Set();
      this.lastTap = { slot: null, t: 0 };
      this.press = null;
      this.timer = 0;
      this.scrollTop = 0;
      this.touch = false;
      this.build();
    }

    get inv() { return this.game.sinv; }

    // Ячейка инвентаря: в одиночной игре — Inventory, на сервере — массив game.inv с отправкой изменений
    invSlotDef(i, x, y) {
      const g = this.game;
      if (this.mp) return { x, y, section: i < 9 ? 'hotbar' : 'main', index: i, get: () => g.inv[i] || null, set: (it) => { g.inv[i] = it; }, mp: { windowId: 0, slot: i } };
      return { x, y, section: i < 9 ? 'hotbar' : 'main', index: i, get: () => g.sinv.slots[i], set: (it) => { g.sinv.slots[i] = it; } };
    }

    // ---------- Построение экрана ----------
    build() {
      const ui = this.game.ui;
      this.slots = [];
      this.heldKey = undefined;
      const box = ui.screen('inventory', { overlay: true });
      box.classList.add('inv-java');
      const chestRows = this.kind === 'chest' ? Math.max(3, Math.ceil((this.window ? this.window.slots.length : this.opts.chest.length) / 9)) : 0;
      const sizes = { survival: [176, 166], table: [176, 166], chest: [176, 114 + chestRows * 18], furnace: [176, 166], creative: [176, 202] };
      const [W, H] = sizes[this.kind];
      const panel = el('div', 'inv-panel');
      // Под панелью ещё строка подсказки, поэтому по высоте оставляем запас, чтобы верхний и нижний ряды не уходили за экран
      panel.style.setProperty('--ip', 'min(calc((100vh - 52px) / ' + H + '), calc((100vw - 16px) / ' + W + '), 4px)');
      panel.style.width = 'calc(var(--ip) * ' + W + ')';
      panel.style.height = 'calc(var(--ip) * ' + H + ')';
      this.panel = panel;
      this.box = box;
      box.appendChild(panel);
      this.heldEl = el('div', 'inv-held');
      box.appendChild(this.heldEl);
      this.hint = el('div', 'inv-hint');
      box.appendChild(this.hint);
      const close = el('div', 'inv-close', '✕');
      close.addEventListener('click', () => this.game.app.resume());
      panel.appendChild(close);

      const title = (text, x, y) => {
        const t = el('div', 'inv-title', text);
        t.style.left = 'calc(var(--ip) * ' + x + ')';
        t.style.top = 'calc(var(--ip) * ' + y + ')';
        panel.appendChild(t);
      };
      const invGrid = (y) => {
        for (let i = 9; i < 36; i++) this.addSlot(this.invSlotDef(i, 8 + ((i - 9) % 9) * 18, y + Math.floor((i - 9) / 9) * 18));
        for (let i = 0; i < 9; i++) this.addSlot(this.invSlotDef(i, 8 + i * 18, y + 58));
      };
      const armorSlots = (xs, ys) => {
        const names = ['helmet', 'chestplate', 'leggings', 'boots'];
        for (let a = 0; a < 4; a++) {
          this.addSlot({ x: xs[a], y: ys[a], section: 'armor', armor: a, empty: 'empty_armor_slot_' + names[a], get: () => this.game.armor[a], set: (it) => { this.game.armor[a] = it; },
            accept: (it) => { const inf = S().armorInfo(it.id); return !!inf && inf[0] === a; }, mp: this.mp ? { windowId: ARMOR_WINDOW, slot: a } : null });
        }
      };

      if (this.kind === 'survival') {
        armorSlots([8, 8, 8, 8], [8, 26, 44, 62]);
        const pv = el('div', 'inv-player');
        const img = el('img');
        img.src = skinPreview(this.game.ownSkin || (this.game.app.settings.skin ? MC.Skin.fromBase64(this.game.app.settings.skin) : MC.Skin.defaultSkin()));
        img.alt = '';
        pv.appendChild(img);
        panel.appendChild(pv);
        title('Крафт', 97, 8);
        for (let i = 0; i < 4; i++) this.addSlot({ x: 98 + (i % 2) * 18, y: 18 + Math.floor(i / 2) * 18, section: 'craft', index: i, get: () => this.grid[i], set: (it) => { this.grid[i] = it; } });
        this.addArrow(135, 29);
        this.addSlot({ x: 154, y: 28, section: 'result', big: true, get: () => this.craftResult(), set: () => {} });
        this.addBook(104, 61);
        invGrid(84);
      } else if (this.kind === 'table') {
        title('Верстак', 28, 6);
        for (let i = 0; i < 9; i++) this.addSlot({ x: 30 + (i % 3) * 18, y: 17 + Math.floor(i / 3) * 18, section: 'craft', index: i, get: () => this.grid[i], set: (it) => { this.grid[i] = it; } });
        this.addArrow(90, 35);
        this.addSlot({ x: 124, y: 35, section: 'result', big: true, get: () => this.craftResult(), set: () => {} });
        this.addBook(5, 35);
        title('Инвентарь', 8, 72);
        invGrid(84);
      } else if (this.kind === 'chest') {
        const w = this.window;
        const chest = w ? w.slots : this.opts.chest;
        title(chestRows > 3 ? 'Большой сундук' : 'Сундук', 8, 6);
        for (let i = 0; i < chestRows * 9; i++) {
          this.addSlot({ x: 8 + (i % 9) * 18, y: 18 + Math.floor(i / 9) * 18, section: 'container', index: i, get: () => chest[i] || null, set: (it) => { chest[i] = it; }, mp: w ? { windowId: w.id, slot: i } : null });
        }
        const invY = 18 + chestRows * 18 + 14;
        title('Инвентарь', 8, invY - 10);
        invGrid(invY);
      } else if (this.kind === 'furnace') {
        const w = this.window;
        const f = w ? w : this.opts.furnace;
        const fget = (k) => (w ? w.slots[k] : f[['input', 'fuel', 'output'][k]]) || null;
        const fset = (k, it) => { if (w) w.slots[k] = it; else f[['input', 'fuel', 'output'][k]] = it; };
        title('Печь', 60, 6);
        this.addSlot({ x: 56, y: 17, section: 'container', index: 0, get: () => fget(0), set: (it) => fset(0, it), mp: w ? { windowId: w.id, slot: 0 } : null });
        this.addSlot({ x: 56, y: 53, section: 'container', index: 1, get: () => fget(1), set: (it) => fset(1, it), accept: (it) => !!S().FUEL[it.id], mp: w ? { windowId: w.id, slot: 1 } : null });
        this.addSlot({ x: 116, y: 35, section: 'result', index: 2, big: true, get: () => fget(2), set: (it) => fset(2, it), mp: w ? { windowId: w.id, slot: 2 } : null });
        this.flame = el('div', 'inv-flame');
        this.flame.style.left = 'calc(var(--ip) * 57)';
        this.flame.style.top = 'calc(var(--ip) * 36)';
        this.flame.style.backgroundImage = 'url(' + MC.Items.icon(51, 1) + ')';
        panel.appendChild(this.flame);
        this.arrow = this.addArrow(79, 35);
        title('Инвентарь', 8, 72);
        invGrid(84);
      } else if (this.kind === 'creative') {
        title('Предметы', 8, 6);
        const list = el('div', 'inv-list');
        list.style.left = 'calc(var(--ip) * 8)';
        list.style.top = 'calc(var(--ip) * 18)';
        list.style.width = 'calc(var(--ip) * 162)';
        list.style.height = 'calc(var(--ip) * 72)';
        panel.appendChild(list);
        this.list = list;
        const items = this.mp && this.game.creativeItems && this.game.creativeItems.length ? this.game.creativeItems : MC.Items.creativeList();
        const rows = Math.ceil(items.length / 9);
        const inner = el('div', 'inv-list-inner');
        inner.style.height = 'calc(var(--ip) * ' + (rows * 18) + ')';
        list.appendChild(inner);
        items.forEach((it, i) => {
          const item = { id: it.id, data: it.data < 0 ? 0 : it.data, count: it.id < 256 ? 64 : S().maxStack(it.id), nbt: it.nbt };
          this.addSlot({ x: (i % 9) * 18, y: Math.floor(i / 9) * 18, section: 'list', parent: inner, get: () => item, set: () => {}, creative: true });
        });
        list.addEventListener('scroll', () => { this.scrollTop = list.scrollTop; });
        armorSlots([8, 26, 44, 62], [94, 94, 94, 94]);
        this.addSlot({ x: 152, y: 94, section: 'trash', empty: 'bucket_empty', get: () => null, set: () => {}, trash: true });
        title('Инвентарь', 8, 115);
        invGrid(124);
      }

      panel.addEventListener('pointerdown', (e) => this.onDown(e));
      panel.addEventListener('contextmenu', (e) => e.preventDefault());
      box.addEventListener('pointerup', (e) => this.onUp(e));
      box.addEventListener('pointercancel', () => this.cancelPress());
      box.addEventListener('pointermove', (e) => this.onMove(e));
      box.addEventListener('pointerover', (e) => this.onHover(e));
      box.addEventListener('contextmenu', (e) => e.preventDefault());
      this.refresh();
      if (this.list) this.list.scrollTop = this.scrollTop;
    }

    addSlot(def) {
      const s = el('div', 'islot' + (def.big ? ' big' : ''));
      s.style.left = 'calc(var(--ip) * ' + (def.big ? def.x - 4 : def.x) + ')';
      s.style.top = 'calc(var(--ip) * ' + (def.big ? def.y - 4 : def.y) + ')';
      if (def.empty !== undefined && MC_ASSETS.itemTiles[def.empty] !== undefined) {
        const tile = MC_ASSETS.itemTiles[def.empty], grid = MC_ASSETS.itemGrid;
        const ph = el('div', 'islot-empty');
        ph.style.backgroundImage = 'url(' + MC_ASSETS.itemAtlas + ')';
        ph.style.backgroundSize = 'calc(var(--ip) * ' + (16 * grid) + ') calc(var(--ip) * ' + (16 * grid) + ')';
        ph.style.backgroundPosition = 'calc(var(--ip) * ' + (-(tile % grid) * 16) + ') calc(var(--ip) * ' + (-Math.floor(tile / grid) * 16) + ')';
        s.appendChild(ph);
      }
      const slot = Object.assign({ el: s, key: '' }, def);
      s.dataset.i = String(this.slots.length);
      (def.parent || this.panel).appendChild(s);
      this.slots.push(slot);
      return slot;
    }

    addArrow(x, y) {
      const a = el('div', 'inv-arrow');
      a.style.left = 'calc(var(--ip) * ' + x + ')';
      a.style.top = 'calc(var(--ip) * ' + y + ')';
      a.appendChild(el('div', 'inv-arrow-fill'));
      this.panel.appendChild(a);
      return a;
    }

    addBook(x, y) {
      const b = el('div', 'inv-book');
      b.style.left = 'calc(var(--ip) * ' + x + ')';
      b.style.top = 'calc(var(--ip) * ' + y + ')';
      const img = el('img');
      img.src = MC.Items.icon(340, 0);
      img.alt = '';
      b.appendChild(img);
      b.title = 'Рецепты';
      b.addEventListener('click', () => this.showRecipes());
      this.panel.appendChild(b);
    }

    // ---------- Отрисовка ----------
    itemKey(it) { return it && it.id ? it.id + ':' + it.data + ':' + it.count : ''; }

    renderItem(root, it, cls) {
      root.querySelectorAll('.islot-item').forEach((n) => n.remove());
      if (!it || !it.id) return;
      const wrap = el('div', 'islot-item' + (cls ? ' ' + cls : ''));
      const img = el('img');
      img.src = MC.Items.icon(it.id, S().isTool(it.id) || it.data < 0 ? 0 : it.data);
      img.alt = '';
      wrap.appendChild(img);
      if (it.count > 1) wrap.appendChild(el('span', 'icnt', String(it.count)));
      const max = S().durabilityOf(it.id);
      if (max && it.data > 0) {
        const left = Math.max(0, 1 - it.data / max);
        const bar = el('div', 'idur');
        const fill = el('div', 'idur-fill');
        fill.style.width = Math.round(left * 100) + '%';
        fill.style.background = 'hsl(' + Math.round(left * 120) + ', 90%, 45%)';
        bar.appendChild(fill);
        wrap.appendChild(bar);
      }
      root.appendChild(wrap);
    }

    refresh() {
      for (const s of this.slots) {
        const it = s.get();
        const key = this.itemKey(it);
        if (key === s.key) continue;
        s.key = key;
        this.renderItem(s.el, it);
        s.el.classList.toggle('has', !!(it && it.id));
      }
      for (const s of this.slots) s.el.classList.toggle('sel', !!this.held && s === this.heldFrom);
      const hk = this.itemKey(this.held);
      if (hk !== this.heldKey) {
        this.heldKey = hk;
        this.renderItem(this.heldEl, this.held);
        this.heldEl.style.display = this.held ? 'block' : 'none';
      }
      if (this.kind === 'furnace') {
        const f = this.window || this.opts.furnace;
        const burn = f.burnMax > 0 ? Math.min(1, f.burn / f.burnMax) : 0;
        this.flame.style.setProperty('--burn', burn.toFixed(3));
        this.arrow.style.setProperty('--cook', Math.min(1, f.cook / 10).toFixed(3));
      }
      if (!this.hover) this.showHint();
    }

    showHint() {
      if (this.held) this.hint.textContent = this.touch ? 'Нажмите на ячейку — положить или объединить · удерживайте — по одному · за окно — выбросить' : 'ЛКМ — положить · ПКМ — по одному · клик вне окна — выбросить';
      else if (this.kind === 'creative') this.hint.textContent = this.touch ? 'Нажмите — предмет в инвентарь · удерживайте — взять в руку · ячейка с ведром удаляет' : 'ЛКМ — взять · Shift+ЛКМ — в инвентарь · ячейка с ведром удаляет';
      else this.hint.textContent = this.touch ? 'Нажмите — выбрать, затем нажмите куда положить · два раза — быстрый перенос · удерживайте — половина · перетащите — положить точно' : 'ЛКМ — взять/положить · ПКМ — половина · Shift+ЛКМ — быстрый перенос';
    }

    tick() {
      if (this.kind === 'furnace') this.refresh();
    }

    // Сервер прислал содержимое: убираем дубликаты предметов, которые лежат в сетке крафта
    onServerUpdate() {
      if (this.grid && this.mp) {
        for (let i = 0; i < this.grid.length; i++) {
          const it = this.grid[i], from = this.gridFrom[i];
          if (!it || from === null || from === undefined) continue;
          const s = this.game.inv[from];
          if (s && same(s, it)) { s.count -= it.count; if (s.count <= 0) this.game.inv[from] = null; }
        }
      }
      this.refresh();
    }

    // ---------- Ввод ----------
    slotAt(target) {
      const n = target && target.closest ? target.closest('.islot') : null;
      return n ? this.slots[+n.dataset.i] : null;
    }

    moveHeld(e) {
      this.heldEl.style.left = Math.min(window.innerWidth - 48, e.clientX + (this.touch ? -22 : 8)) + 'px';
      this.heldEl.style.top = Math.max(0, e.clientY - (this.touch ? 60 : 8)) + 'px';
    }

    onHover(e) {
      if (this.touch) return;
      const slot = this.slotAt(e.target);
      const it = slot ? slot.get() : null;
      this.hover = !!(it && it.id);
      if (this.hover) this.hint.textContent = MC.Items.itemName(it.id, S().isTool(it.id) || it.data < 0 ? 0 : it.data); else this.showHint();
    }

    onDown(e) {
      if (e.button !== undefined && e.button > 2) return;
      const slot = this.slotAt(e.target);
      if (!slot) return;
      this.touch = e.pointerType !== 'mouse';
      if (!this.touch) e.preventDefault();
      this.press = { slot, x: e.clientX, y: e.clientY, done: false, id: e.pointerId, right: e.button === 2, shift: e.shiftKey, drag: false };
      clearTimeout(this.timer);
      if (this.touch) {
        this.timer = setTimeout(() => {
          if (!this.press || this.press.slot !== slot || this.press.drag) return;
          this.press.done = true;
          this.longPress(slot);
        }, 300);
      }
    }

    onMove(e) {
      if (this.held) this.moveHeld(e);
      const p = this.press;
      if (!p || e.pointerId !== p.id || p.done) return;
      if (Math.hypot(e.clientX - p.x, e.clientY - p.y) <= 12) return;
      // Перетаскивание: стопка берётся в руку и следует за пальцем
      clearTimeout(this.timer);
      if (p.slot.section === 'list' || p.slot.trash || p.slot.section === 'result' && this.kind !== 'furnace') { this.press = null; return; }
      const it = p.slot.get();
      if (!this.held && it && !p.right) {
        this.take(p.slot, it, it.count);
        this.refresh();
        this.moveHeld(e);
        p.drag = true;
      } else if (!this.held) {
        this.press = null;
      }
    }

    cancelPress() { clearTimeout(this.timer); this.press = null; }

    onUp(e) {
      const p = this.press;
      clearTimeout(this.timer);
      this.press = null;
      // На сенсоре указатель «захвачен» ячейкой, где началось касание, поэтому ищем элемент под пальцем
      const target = document.elementFromPoint(e.clientX, e.clientY) || e.target;
      if (!p) {
        if (this.held && !this.slotAt(target) && !this.panel.contains(target)) { this.outside(); }
        return;
      }
      if (p.done) return;
      const slot = this.slotAt(target);
      if (p.drag) {
        if (slot && slot !== p.slot) this.place(slot);
        else if (!slot && !this.panel.contains(target)) this.outside();
        this.flushMP();
        this.refresh();
        return;
      }
      if (slot !== p.slot) { if (!slot && !this.panel.contains(target) && this.held) this.outside(); return; }
      const now = performance.now();
      const dbl = this.lastTap.slot === slot && now - this.lastTap.t < 320 && !p.right;
      this.lastTap = { slot, t: dbl ? 0 : now };
      if (p.right) this.longPress(slot);
      else if (p.shift) this.quickTap(slot);
      else if (dbl && !this.touch) this.doubleClick(slot);
      else if (dbl) this.doubleTapTouch(slot);
      else if (this.touch) this.tapTouch(slot);
      else this.tap(slot);
      this.moveHeld(e);
      this.flushMP();
      this.refresh();
      MC.Sound.click();
    }

    // ---------- Базовые операции над ячейками ----------
    commit(slot, it) {
      slot.set(it && it.count > 0 ? it : null);
      if (slot.mp) this.dirty.add(slot);
    }

    // Взять n предметов из ячейки в руку
    take(slot, it, n) {
      n = Math.min(n, it.count);
      this.held = { id: it.id, data: it.data, count: n, nbt: it.nbt };
      this.heldFrom = slot;
      this.heldOrigin = slot.section === 'craft' ? this.gridFrom[slot.index] : slot.mp && slot.mp.windowId === 0 ? slot.index : null;
      this.lastTake = { slot, count: n === it.count ? n : 0 };
      const left = it.count - n;
      if (left > 0) { it.count = left; if (slot.mp) this.dirty.add(slot); } else this.commit(slot, null);
      if (slot.section === 'craft') this.gridFrom[slot.index] = null;
    }

    // Положить руку в ячейку (всю стопку или count штук): объединение, обмен
    place(slot, count) {
      if (!this.held) return;
      if (slot.creative) { this.held = null; return; }
      if (slot.trash) { this.held = null; return; }
      if (slot.section === 'result') return;
      if (slot.accept && !slot.accept(this.held)) return;
      const it = slot.get();
      const n = count === undefined ? this.held.count : Math.min(count, this.held.count);
      if (!it) {
        this.commit(slot, { id: this.held.id, data: this.held.data, count: n, nbt: this.held.nbt });
        this.held.count -= n;
      } else if (same(it, this.held)) {
        const k = Math.min(n, S().maxStack(it.id) - it.count);
        if (!k) return;
        it.count += k;
        this.commit(slot, it);
        this.held.count -= k;
      } else if (count === undefined) {
        // Обмен: положенный предмет наследует происхождение руки, взятый — происхождение ячейки
        const h = this.held;
        const nextOrigin = slot.section === 'craft' ? this.gridFrom[slot.index] : slot.mp && slot.mp.windowId === 0 ? slot.index : null;
        this.commit(slot, h);
        this.notePlaced(slot);
        this.held = { id: it.id, data: it.data, count: it.count, nbt: it.nbt };
        this.heldOrigin = nextOrigin;
        this.lastTake = null;
        return;
      } else {
        return;
      }
      this.notePlaced(slot);
      if (this.held.count <= 0) this.held = null;
    }

    // Учёт происхождения предмета для сетки крафта и для синхронизации с сервером
    notePlaced(slot) {
      if (slot.section === 'craft') {
        this.gridFrom[slot.index] = this.heldOrigin;
        if (this.mp && this.heldFrom && this.heldFrom.mp) this.dirty.delete(this.heldFrom);
      } else if (this.mp && this.heldOrigin !== null && this.heldOrigin !== undefined) {
        const origin = this.slots.find((s) => s.mp && s.mp.windowId === 0 && s.index === this.heldOrigin);
        if (origin && slot !== origin) this.dirty.add(origin);
      }
    }

    // Отправка изменённых ячеек серверу: когда рука пуста или изменились хотя бы две ячейки
    flushMP() {
      if (!this.mp || !this.dirty.size) return;
      if (this.held && this.dirty.size < 2) return;
      for (const s of this.dirty) this.game.mpSetSlot(s.mp.windowId, s.mp.slot, s.get());
      this.dirty.clear();
    }

    // ---------- Жесты ----------
    // Касание (Bedrock): пустая рука — быстрый перенос; с предметом — положить
    tapTouch(slot) {
      if (this.held) { this.place(slot); return; }
      if (slot.creative) { const it = slot.get(); if (this.inv0Add(copy(it))) this.game.ui.setPopup('§cИнвентарь полон'); return; }
      if (slot.section === 'result') { this.craftOne(slot); return; }
      const it = slot.get();
      if (!it) return;
      // Как в Pocket UI: нажатие выбирает стопку (она в руке), следующее нажатие кладёт, объединяет или меняет местами
      this.take(slot, it, it.count);
    }

    // Сенсор: двойное нажатие по стопке — быстрый перенос (панель ↔ инвентарь, в сундук, в печь, броня)
    doubleTapTouch(slot) {
      if (this.held && this.heldFrom === slot && !slot.get()) {
        const it = this.held;
        this.held = null;
        this.heldFrom = null;
        this.commit(slot, it);
        this.quickMove(slot, it);
        return;
      }
      this.tapTouch(slot);
    }

    // Сенсор: одно нажатие на результат — один крафт прямо в инвентарь (как в Pocket Edition)
    craftOne(slot) {
      if (this.kind === 'furnace') { this.takeResult(slot, true); return; }
      if (this.mp) { this.craftServer(1); return; }
      const r = this.craftRecipe();
      if (!r) return;
      const out = S().takeGrid(this.grid, r);
      const left = this.inv0Add(out);
      if (left) this.game.ents.spawnItem({ id: out.id, data: out.data, count: left }, this.game.player.x, this.game.player.y + 1, this.game.player.z);
    }

    // ЛКМ (Java): взять / положить / обменять; результат крафта — в руку
    tap(slot) {
      const it = slot.get();
      if (slot.creative) { this.held = this.held ? null : copy(it); return; }
      if (slot.trash) { this.held = null; return; }
      if (slot.section === 'result') { this.takeResult(slot, false); return; }
      if (!this.held) { if (it) this.take(slot, it, it.count); return; }
      this.place(slot);
    }

    // Удержание / ПКМ: пустая рука — половина, с предметом — один
    longPress(slot) {
      const it = slot.get();
      if (slot.creative) { if (it) this.held = this.held ? null : copy(it); this.refresh(); return; }
      if (slot.trash) { this.held = null; this.refresh(); return; }
      if (slot.section === 'result') { this.takeResult(slot, !this.held); this.flushMP(); this.refresh(); return; }
      if (this.held) this.place(slot, 1);
      else if (it) this.take(slot, it, Math.ceil(it.count / 2));
      this.flushMP();
      this.refresh();
      MC.Sound.click();
    }

    // Shift+ЛКМ: быстрый перенос
    quickTap(slot) {
      const it = slot.get();
      if (slot.creative) { if (this.inv0Add(copy(it))) this.game.ui.setPopup('§cИнвентарь полон'); return; }
      if (slot.section === 'result') { this.takeResult(slot, true); return; }
      if (!it || this.held) return;
      this.quickMove(slot, it);
    }

    // Двойной клик (Java): собрать в руку все такие же предметы
    doubleClick(slot) {
      if (!this.held) { this.tap(slot); return; }
      const max = S().maxStack(this.held.id);
      for (const s of this.slots) {
        if (this.held.count >= max) break;
        if (s.section === 'result' || s.creative || s.trash || s === slot) continue;
        const it = s.get();
        if (!it || !same(it, this.held)) continue;
        const n = Math.min(it.count, max - this.held.count);
        this.held.count += n;
        it.count -= n;
        this.commit(s, it);
      }
    }

    // ---------- Быстрый перенос ----------
    inv0Add(it) {
      if (!this.mp) return this.inv.add(it);
      const inv = this.game.inv;
      let left = it.count;
      const max = S().maxStack(it.id);
      for (let i = 0; i < 36 && left > 0; i++) { const s = inv[i]; if (s && same(s, it) && s.count < max) { const n = Math.min(left, max - s.count); s.count += n; left -= n; this.markInv(i); } }
      for (let i = 0; i < 36 && left > 0; i++) { if (!inv[i]) { const n = Math.min(left, max); inv[i] = { id: it.id, data: it.data, count: n, nbt: it.nbt }; left -= n; this.markInv(i); } }
      return left;
    }

    markInv(i) {
      const s = this.slots.find((x) => x.mp && x.mp.windowId === 0 && x.index === i);
      if (s) this.dirty.add(s);
    }

    // Переносит стопку в ячейки из списка диапазонов инвентаря; возвращает остаток
    moveToInv(it, ranges) {
      const get = (i) => (this.mp ? this.game.inv[i] : this.inv.slots[i]);
      const set = (i, v) => { if (this.mp) this.game.inv[i] = v; else this.inv.slots[i] = v; this.markInv(i); };
      let left = it.count;
      const max = S().maxStack(it.id);
      for (const [a, b] of ranges) for (let i = a; i < b && left > 0; i++) {
        const s = get(i);
        if (s && same(s, it) && s.count < max) { const n = Math.min(left, max - s.count); s.count += n; left -= n; this.markInv(i); }
      }
      for (const [a, b] of ranges) for (let i = a; i < b && left > 0; i++) {
        if (!get(i)) { const n = Math.min(left, max); set(i, { id: it.id, data: it.data, count: n, nbt: it.nbt }); left -= n; }
      }
      return left;
    }

    quickMove(slot, it) {
      let left = it.count;
      const container = this.kind === 'chest' || this.kind === 'furnace';
      if (slot.section === 'hotbar' || slot.section === 'main') {
        const inf = S().armorInfo(it.id);
        const armorSlot = inf && this.slots.find((s) => s.section === 'armor' && s.armor === inf[0]);
        if (armorSlot && !armorSlot.get()) { this.commit(armorSlot, copy(it)); this.commit(slot, null); return; }
        if (container) left = this.toContainer(it);
        else left = this.moveToInv(it, slot.section === 'hotbar' ? [[9, 36]] : [[0, 9]]);
      } else {
        left = this.moveToInv(it, [[0, 9], [9, 36]]);
      }
      if (left <= 0) this.commit(slot, null);
      else { it.count = left; this.commit(slot, it); }
      if (slot.section === 'craft') this.gridFrom[slot.index] = null;
    }

    toContainer(it) {
      const slots = this.slots.filter((s) => s.section === 'container' && (!s.accept || s.accept(it)) && s.index !== 2);
      let left = it.count;
      const max = S().maxStack(it.id);
      for (const s of slots) { const c = s.get(); if (left > 0 && c && same(c, it) && c.count < max) { const n = Math.min(left, max - c.count); c.count += n; left -= n; this.commit(s, c); } }
      for (const s of slots) { if (left > 0 && !s.get()) { const n = Math.min(left, max); this.commit(s, { id: it.id, data: it.data, count: n, nbt: it.nbt }); left -= n; } }
      return left;
    }

    // ---------- Крафт и результат ----------
    craftRecipe() { return this.grid && !this.mp ? S().matchGrid(this.grid, this.gridSize) : null; }

    craftResult() {
      if (!this.grid) return null;
      if (this.mp) { const r = S().matchServerRecipe(this.game.recipes, this.grid, this.gridSize); return r ? { id: r.out.id, data: r.out.data, count: r.out.count } : null; }
      const r = this.craftRecipe();
      return r ? { id: r.out.id, data: r.out.data, count: r.out.count } : null;
    }

    // Результат: печь — взять в руку/в инвентарь; крафт — один в руку (Java) или всё в инвентарь (quick)
    takeResult(slot, quick) {
      if (this.kind === 'furnace') {
        const it = slot.get();
        if (!it) return;
        if (quick) { const left = this.inv0Add(copy(it)); this.commit(slot, left > 0 ? { id: it.id, data: it.data, count: left } : null); return; }
        if (!this.held) { this.take(slot, it, it.count); } else if (same(this.held, it)) {
          const n = Math.min(it.count, S().maxStack(it.id) - this.held.count);
          this.held.count += n; it.count -= n;
          this.commit(slot, it);
        }
        return;
      }
      if (this.mp) { this.craftServer(quick ? 64 : 1); return; }
      if (quick) { this.craftAll(); return; }
      const r = this.craftRecipe();
      if (!r) return;
      if (this.held && (!same(this.held, r.out) || this.held.count + r.out.count > S().maxStack(r.out.id))) return;
      const out = S().takeGrid(this.grid, r);
      if (this.held) this.held.count += out.count; else this.held = out;
      this.heldOrigin = null;
      this.lastTake = null;
    }

    craftAll() {
      let r = this.craftRecipe();
      let n = 0;
      while (r && n < 64) {
        const out = S().takeGrid(this.grid, r);
        const left = this.inv.add(out);
        if (left) this.game.ents.spawnItem({ id: out.id, data: out.data, count: left }, this.game.player.x, this.game.player.y + 1, this.game.player.z);
        n++;
        r = this.craftRecipe();
      }
    }

    // На сервере результат кладёт сам сервер; клиент только расходует сетку и шлёт CraftingEvent
    craftServer(max) {
      for (let n = 0; n < max; n++) {
        const out = this.game.mpCraft(this.grid, this.gridSize);
        if (!out) break;
        for (let i = 0; i < this.grid.length; i++) {
          const c = this.grid[i];
          if (!c || !c.id) continue;
          c.count--;
          if (c.count <= 0) { this.grid[i] = null; this.gridFrom[i] = null; }
        }
      }
    }

    // Список рецептов: нажатие раскладывает ингредиенты из инвентаря по сетке
    showRecipes() {
      const ui = this.game.ui;
      const box = ui.screen('inventory', { overlay: true });
      box.appendChild(el('h2', 'title', this.kind === 'table' ? 'Рецепты верстака' : 'Рецепты (2x2)'));
      const list = el('div', 'list craft-list');
      box.appendChild(list);
      const table = this.kind === 'table';
      const count = (id, data) => {
        let n = 0;
        const slots = this.mp ? this.game.inv : this.inv.slots;
        for (const s of slots) if (s && s.id === id && (data < 0 || s.data === data)) n += s.count;
        return n;
      };
      const fits = (r) => {
        const sh = S().SHAPES[r.out.id];
        let total = 0;
        for (const n of r.need) total += n.count;
        if (sh && sh.join('').replace(/ /g, '').length === total) return sh.length <= this.gridSize && sh[0].length <= this.gridSize;
        return total <= this.gridSize * this.gridSize;
      };
      const recipes = S().RECIPES.filter((r) => (table || !r.table) && fits(r)).map((r) => ({ r, ok: r.need.every((n) => count(n.id, n.data) >= n.count) })).sort((a, b) => b.ok - a.ok);
      for (const { r, ok } of recipes) {
        const row = el('div', 'list-item craft-row' + (ok ? '' : ' dim'));
        const cell = el('div', 'islot static');
        this.renderItem(cell, r.out);
        row.appendChild(cell);
        const info = el('div', 'craft-info');
        info.appendChild(el('div', 'li-title', MC.Items.itemName(r.out.id, r.out.data) + (r.out.count > 1 ? ' x' + r.out.count : '')));
        info.appendChild(el('div', 'li-sub', r.need.map((n) => MC.Items.itemName(n.id, n.data < 0 ? 0 : n.data) + ' ' + count(n.id, n.data) + '/' + n.count).join(', ')));
        row.appendChild(info);
        if (ok) row.addEventListener('click', () => { this.fillGrid(r); this.build(); });
        list.appendChild(row);
      }
      ui.button(box, 'Назад', () => this.build());
    }

    fillGrid(r) {
      this.returnGrid();
      const slots = this.mp ? this.game.inv : this.inv.slots;
      const sh = S().SHAPES[r.out.id];
      let total = 0;
      for (const n of r.need) total += n.count;
      const take = (need) => {
        for (let i = 0; i < 36; i++) {
          const s = slots[i];
          if (s && s.id === need.id && (need.data < 0 || s.data === need.data)) {
            s.count--;
            if (s.count <= 0) slots[i] = null;
            return { item: { id: s.id, data: s.data, count: 1 }, from: i };
          }
        }
        return null;
      };
      const put = (cell, need) => { const t = take(need); if (t) { this.grid[cell] = t.item; this.gridFrom[cell] = t.from; } };
      if (sh && sh.join('').replace(/ /g, '').length === total) {
        const h = sh.length, w = sh[0].length;
        const ox = Math.floor((this.gridSize - w) / 2), oy = Math.floor((this.gridSize - h) / 2);
        for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
          const ch = sh[y][x];
          if (ch === ' ') continue;
          put((oy + y) * this.gridSize + ox + x, ch === 'S' ? { id: 280, data: 0 } : r.need[ch === 'B' ? 1 : ch === 'C' ? 2 : 0] || r.need[0]);
        }
      } else {
        let i = 0;
        for (const n of r.need) for (let k = 0; k < n.count; k++) put(i++, n);
      }
    }

    // Содержимое сетки крафта возвращается в инвентарь (на сервере — в исходные ячейки, сервер их не менял)
    returnGrid() {
      if (!this.grid) return;
      for (let i = 0; i < this.grid.length; i++) {
        const it = this.grid[i], from = this.gridFrom[i];
        this.grid[i] = null;
        this.gridFrom[i] = null;
        if (!it) continue;
        if (this.mp && from !== null && from !== undefined) {
          const s = this.game.inv[from];
          if (!s) { this.game.inv[from] = it; continue; }
          if (same(s, it) && s.count + it.count <= S().maxStack(it.id)) { s.count += it.count; continue; }
        }
        this.giveBack(it);
      }
    }

    giveBack(it) {
      const g = this.game;
      const left = this.inv0Add(it);
      if (left && !this.mp && g.ents) g.ents.spawnItem({ id: it.id, data: it.data, count: left }, g.player.x, g.player.y + 1, g.player.z);
    }

    // Нажатие вне окна: выбросить предмет из руки (в творческом режиме — удалить)
    outside() {
      if (!this.held) return;
      const g = this.game;
      if (this.kind === 'creative' && !this.mp) { this.held = null; this.refresh(); return; }
      if (this.mp) {
        g.client.sendDropItem(this.held);
        if (this.heldFrom && this.heldFrom.mp) this.dirty.delete(this.heldFrom);
        const origin = this.heldOrigin !== null && this.heldOrigin !== undefined ? this.slots.find((s) => s.mp && s.mp.windowId === 0 && s.index === this.heldOrigin) : null;
        if (origin) this.dirty.delete(origin);
      } else {
        const p = g.player, d = p.lookDir();
        g.ents.spawnItem(this.held, p.x + d[0] * 0.3, p.eyeY - 0.3, p.z + d[2] * 0.3, d[0] * 5, d[1] * 5 + 2, d[2] * 5, 1.5);
      }
      this.held = null;
      this.heldOrigin = null;
      this.flushMP();
      this.refresh();
    }

    close() {
      this.returnGrid();
      if (this.held) {
        if (this.kind !== 'creative' || this.mp) this.giveBack(this.held);
        this.held = null;
      }
      this.flushMP();
      if (this.window && this.mp) {
        this.game.client.sendContainerClose(this.window.id);
        this.game.windows.delete(this.window.id);
        this.window = null;
      }
    }
  }

  MC.InvScreen = InvScreen;
})();
