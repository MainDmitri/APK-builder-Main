// Отрисовка мира, игроков, сущностей и рамки выделения через WebGL
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const A = window.MC_ASSETS;

  // ---------- Матрицы 4x4 (столбцами, как в WebGL) ----------
  const M4 = {
    perspective(fovy, aspect, near, far) {
      const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
      return new Float32Array([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0]);
    },
    lookAt(eye, target, up) {
      let zx = eye[0] - target[0], zy = eye[1] - target[1], zz = eye[2] - target[2];
      let l = Math.hypot(zx, zy, zz); zx /= l; zy /= l; zz /= l;
      let xx = up[1] * zz - up[2] * zy, xy = up[2] * zx - up[0] * zz, xz = up[0] * zy - up[1] * zx;
      l = Math.hypot(xx, xy, xz) || 1; xx /= l; xy /= l; xz /= l;
      const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
      return new Float32Array([xx, yx, zx, 0, xy, yy, zy, 0, xz, yz, zz, 0,
        -(xx * eye[0] + xy * eye[1] + xz * eye[2]), -(yx * eye[0] + yy * eye[1] + yz * eye[2]), -(zx * eye[0] + zy * eye[1] + zz * eye[2]), 1]);
    },
    mul(a, b) {
      const o = new Float32Array(16);
      for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
        o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
      }
      return o;
    }
  };

  // a_light = освещение (0..1) + 2 * флаг: 1 — качается как листва, 2 — поверхность воды
  const VS = `
attribute vec3 a_pos;
attribute vec2 a_uv;
attribute float a_light;
uniform mat4 u_mvp;
uniform vec3 u_offset;
uniform vec3 u_cam;
uniform float u_time;
uniform float u_fancy;
varying vec2 v_uv;
varying float v_light;
varying float v_dist;
void main() {
  vec3 p = a_pos + u_offset;
  float flag = floor(a_light / 2.0);
  float light = a_light - flag * 2.0;
  if (u_fancy > 0.5 && flag > 0.5) {
    vec3 w = p + u_cam;
    if (flag < 1.5) {
      float s = sin(u_time * 1.4 + w.x * 0.9 + w.z * 0.7 + w.y * 0.4);
      p.x += s * 0.03;
      p.z += cos(u_time * 1.1 + w.z * 0.8 + w.x * 0.5) * 0.03;
    } else {
      p.y += (sin(u_time * 1.8 + w.x * 1.3 + w.z * 0.9) * 0.5 + sin(u_time * 2.6 + w.z * 1.7) * 0.5) * 0.045 - 0.02;
    }
  }
  gl_Position = u_mvp * vec4(p, 1.0);
  v_uv = a_uv;
  v_light = light;
  v_dist = length(p);
}`;

  const FS = `
precision mediump float;
uniform sampler2D u_tex;
uniform vec4 u_tint;
uniform float u_daylight;
uniform float u_alphaTest;
uniform vec3 u_fog;
uniform vec2 u_fogRange;
varying vec2 v_uv;
varying float v_light;
varying float v_dist;
uniform highp float u_fancy;
void main() {
  vec4 c = texture2D(u_tex, v_uv) * u_tint;
  if (c.a < u_alphaTest) discard;
  c.rgb *= v_light * u_daylight;
  float f = clamp((v_dist - u_fogRange.x) / (u_fogRange.y - u_fogRange.x), 0.0, 1.0);
  if (u_fancy > 0.5) {
    // Плавный туман и чуть более сочные цвета
    f = f * f * (3.0 - 2.0 * f);
    float g = dot(c.rgb, vec3(0.299, 0.587, 0.114));
    c.rgb = mix(vec3(g), c.rgb, 1.12);
  }
  c.rgb = mix(c.rgb, u_fog, f);
  gl_FragColor = c;
}`;

  // Небо: градиент от горизонта к зениту, заря у солнца, звёзды ночью (рисуется одним треугольником на весь экран)
  const SKY_VS = `
attribute vec2 a_pos;
varying vec2 v_ndc;
void main() { v_ndc = a_pos; gl_Position = vec4(a_pos, 0.999, 1.0); }`;
  const SKY_FS = `
precision mediump float;
uniform vec3 u_fwd;
uniform vec3 u_right;
uniform vec3 u_up;
uniform vec2 u_tan;
uniform vec3 u_horizon;
uniform vec3 u_zenith;
uniform vec3 u_sun;
uniform float u_daylight;
varying vec2 v_ndc;
float hash(vec3 q) { return fract(sin(dot(q, vec3(12.9898, 78.233, 37.719))) * 43758.5453); }
void main() {
  vec3 dir = normalize(u_fwd + u_right * (v_ndc.x * u_tan.x) + u_up * (v_ndc.y * u_tan.y));
  float t = clamp(dir.y, 0.0, 1.0);
  vec3 c = mix(u_horizon, u_zenith, pow(t, 0.55));
  if (dir.y < 0.0) c = mix(u_horizon, u_zenith * 0.5, clamp(-dir.y * 3.0, 0.0, 1.0));
  float sunH = u_sun.y;
  float dawn = 1.0 - clamp(abs(sunH) / 0.32, 0.0, 1.0);
  if (dawn > 0.0) {
    float toSun = max(0.0, dot(normalize(vec3(dir.x, 0.0, dir.z)), normalize(vec3(u_sun.x, 0.0, u_sun.z))));
    float band = pow(1.0 - clamp(abs(dir.y) * 2.2, 0.0, 1.0), 2.0);
    c = mix(c, vec3(1.0, 0.45, 0.12), dawn * band * pow(toSun, 3.0) * 0.85);
  }
  if (u_daylight < 0.6 && dir.y > 0.02) {
    vec3 cell = floor(dir * 140.0);
    float h = hash(cell);
    vec3 f = fract(dir * 140.0) - 0.5;
    float star = step(0.994, h) * smoothstep(0.22, 0.0, length(f)) * (0.6 + 0.4 * sin(h * 40.0));
    c += vec3(star) * (1.0 - u_daylight / 0.6);
  }
  gl_FragColor = vec4(c, 1.0);
}`;

  function compile(gl, type, src) {
    const s = gl.createShader(type);
    gl.shaderSource(s, src);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('Ошибка шейдера: ' + gl.getShaderInfoLog(s));
    return s;
  }

  function loadImage(src) {
    return new Promise((res, rej) => {
      const im = new Image();
      im.onload = () => res(im);
      im.onerror = () => rej(new Error('Не удалось загрузить текстуру'));
      im.src = src;
    });
  }

  // Модель игрока (раскладка скина 64x32 / 64x64)
  const PX = 1.8 / 32;
  const PARTS = [
    { name: 'head', size: [8, 8, 8], uv: [0, 0], pivot: [0, 24, 0], origin: [-4, 0, -4] },
    { name: 'body', size: [8, 12, 4], uv: [16, 16], pivot: [0, 12, 0], origin: [-4, 0, -2] },
    { name: 'rarm', size: [4, 12, 4], uv: [40, 16], pivot: [-6, 24, 0], origin: [-2, -12, -2] },
    { name: 'larm', size: [4, 12, 4], uv: [40, 16], uv64: [32, 48], pivot: [6, 24, 0], origin: [-2, -12, -2] },
    { name: 'rleg', size: [4, 12, 4], uv: [0, 16], pivot: [-2, 12, 0], origin: [-2, -12, -2] },
    { name: 'lleg', size: [4, 12, 4], uv: [0, 16], uv64: [16, 48], pivot: [2, 12, 0], origin: [-2, -12, -2] },
    { name: 'hat', size: [8, 8, 8], uv: [32, 0], pivot: [0, 24, 0], origin: [-4, 0, -4], inflate: 0.5 }
  ];

  const ENTITY_LOOK = {
    10: ['Курица', [0.95, 0.95, 0.95], [0.4, 0.7, 0.4]], 11: ['Корова', [0.35, 0.25, 0.18], [0.9, 1.4, 1.4]], 12: ['Свинья', [0.95, 0.65, 0.65], [0.9, 0.9, 1.2]],
    13: ['Овца', [0.92, 0.92, 0.92], [0.9, 1.3, 1.2]], 14: ['Волк', [0.8, 0.8, 0.8], [0.6, 0.85, 1.0]], 15: ['Житель', [0.55, 0.4, 0.3], [0.6, 1.9, 0.6]],
    16: ['Грибная корова', [0.7, 0.2, 0.2], [0.9, 1.4, 1.4]], 17: ['Спрут', [0.2, 0.3, 0.45], [0.8, 0.8, 0.8]], 18: ['Кролик', [0.6, 0.5, 0.4], [0.4, 0.5, 0.4]],
    19: ['Летучая мышь', [0.25, 0.2, 0.15], [0.5, 0.9, 0.5]], 20: ['Железный голем', [0.8, 0.78, 0.72], [1.4, 2.7, 1.4]], 21: ['Снежный голем', [0.95, 0.95, 1], [0.7, 1.9, 0.7]],
    22: ['Оцелот', [0.85, 0.7, 0.3], [0.6, 0.7, 0.9]], 23: ['Лошадь', [0.5, 0.33, 0.2], [1.4, 1.6, 1.8]], 32: ['Зомби', [0.25, 0.5, 0.3], [0.6, 1.95, 0.6]],
    33: ['Крипер', [0.3, 0.7, 0.3], [0.6, 1.7, 0.6]], 34: ['Скелет', [0.8, 0.8, 0.8], [0.6, 1.99, 0.6]], 35: ['Паук', [0.2, 0.17, 0.15], [1.4, 0.9, 1.4]],
    36: ['Зомби-свиночеловек', [0.85, 0.6, 0.55], [0.6, 1.95, 0.6]], 37: ['Слизень', [0.4, 0.8, 0.35], [1.0, 1.0, 1.0]], 38: ['Эндермен', [0.1, 0.1, 0.12], [0.6, 2.9, 0.6]],
    39: ['Чешуйница', [0.55, 0.55, 0.55], [0.4, 0.3, 0.4]], 40: ['Пещерный паук', [0.1, 0.2, 0.25], [0.7, 0.5, 0.7]], 41: ['Гаст', [0.95, 0.95, 0.95], [4, 4, 4]],
    42: ['Магмовый куб', [0.5, 0.15, 0.05], [1.0, 1.0, 1.0]], 43: ['Ифрит', [0.95, 0.75, 0.2], [0.6, 1.8, 0.6]], 44: ['Зомби-житель', [0.3, 0.5, 0.3], [0.6, 1.95, 0.6]],
    45: ['Ведьма', [0.3, 0.2, 0.3], [0.6, 1.95, 0.6]], 46: ['Зимогор', [0.6, 0.7, 0.75], [0.6, 1.99, 0.6]], 47: ['Кадавр', [0.6, 0.55, 0.4], [0.6, 1.95, 0.6]],
    48: ['Скелет-иссушитель', [0.15, 0.15, 0.15], [0.7, 2.4, 0.7]], 49: ['Страж', [0.35, 0.6, 0.55], [0.85, 0.85, 0.85]],
    65: ['Динамит', [0.85, 0.2, 0.15], [0.98, 0.98, 0.98]], 66: ['Падающий блок', [0.8, 0.75, 0.55], [0.98, 0.98, 0.98]], 69: ['Опыт', [0.6, 0.95, 0.2], [0.25, 0.25, 0.25]],
    80: ['Стрела', [0.6, 0.5, 0.4], [0.15, 0.15, 0.5]], 81: ['Снежок', [1, 1, 1], [0.25, 0.25, 0.25]], 82: ['Яйцо', [0.95, 0.9, 0.75], [0.25, 0.25, 0.25]],
    84: ['Вагонетка', [0.45, 0.45, 0.5], [0.98, 0.7, 0.98]], 90: ['Лодка', [0.6, 0.45, 0.25], [1.4, 0.45, 1.4]]
  };

  // Существа: тип сущности -> [геометрии из mobs.json, текстура, масштаб, анимация]
  const MOBS = {
    10: [['chicken'], 'chicken', 1, 'chicken'], 11: [['cow'], 'cow', 1, 'quad'], 12: [['pig'], 'pig', 1, 'quad'],
    13: [['sheep.sheared', 'sheep'], 'sheep', 1, 'quad'], 14: [['wolf'], 'wolf', 1, 'wolf'], 15: [['villager'], 'villager', 1, 'villager'],
    16: [['mooshroom'], 'mooshroom', 1, 'quad'], 17: [['squid'], 'squid', 1, 'none'], 18: [['rabbit'], 'rabbit', 1, 'none'],
    19: [['bat'], 'bat', 1, 'none'], 20: [['irongolem'], 'iron_golem', 1, 'golem'], 21: [['snowgolem'], 'snow_golem', 1, 'none'],
    22: [['ocelot'], 'ocelot', 1, 'ocelot'], 28: [['polarbear'], 'polarbear', 1, 'quad'], 32: [['zombie'], 'zombie', 1, 'zombie'],
    33: [['creeper'], 'creeper', 1, 'creeper'], 34: [['skeleton'], 'skeleton', 1, 'humanoid'], 35: [['spider'], 'spider', 1, 'spider'],
    36: [['pigzombie'], 'pigzombie', 1, 'zombie'], 37: [['slime'], 'slime', 1, 'none'], 38: [['enderman'], 'enderman', 1, 'humanoid'],
    39: [['silverfish'], 'silverfish', 1, 'none'], 40: [['spider'], 'cave_spider', 0.7, 'spider'], 41: [['ghast'], 'ghast', 4.5, 'none'],
    42: [['lavaslime'], 'magmacube', 1, 'none'], 43: [['blaze'], 'blaze', 1, 'none'], 44: [['zombie.villager'], 'zombie_villager', 1, 'zombie'],
    45: [['villager.witch'], 'witch', 1, 'villager'], 46: [['skeleton.stray'], 'stray', 1, 'humanoid'], 47: [['zombie.husk'], 'husk', 1, 'zombie'],
    48: [['skeleton.wither'], 'wither_skeleton', 1.2, 'humanoid'], 49: [['guardian'], 'guardian', 1, 'none'], 57: [['vindicator'], 'vindicator', 1, 'none'],
    104: [['evoker'], 'evoker', 1, 'none'], 105: [['vex'], 'vex', 0.5, 'none']
  };

  const PI = Math.PI;
  const DEG = 180 / PI;
  // Поза костей (углы как в Java-моделях Minecraft, радианы): ls — фаза шага, amt — сила шага, pitch — наклон головы
  function animate(family, ls, amt, pitch) {
    const r = {};
    const c = Math.cos(ls * 0.6662) * 1.4 * amt;
    r.head = [pitch, 0, 0];
    if (family === 'quad' || family === 'wolf' || family === 'creeper') {
      r.leg0 = [c, 0, 0]; r.leg3 = [c, 0, 0]; r.leg1 = [-c, 0, 0]; r.leg2 = [-c, 0, 0];
      if (family === 'wolf') { r.body = [PI / 2, 0, 0]; r.upperBody = [PI / 2, 0, 0]; r.tail = [PI / 5, 0, 0]; }
    }
    if (family === 'quad') r.body = [PI / 2, 0, 0];
    if (family === 'chicken') {
      r.body = [PI / 2, 0, 0]; r.beak = r.head; r.comb = r.head;
      r.leg0 = [c, 0, 0]; r.leg1 = [-c, 0, 0];
    }
    if (family === 'humanoid' || family === 'zombie') {
      r.rightLeg = [c, 0, 0]; r.leftLeg = [-c, 0, 0]; r.hat = r.head;
      const arm = Math.cos(ls * 0.6662) * amt;
      if (family === 'zombie') { r.rightArm = [-PI / 2 + arm * 0.1, 0, 0]; r.leftArm = [-PI / 2 - arm * 0.1, 0, 0]; }
      else { r.rightArm = [-arm, 0, 0]; r.leftArm = [arm, 0, 0]; }
    }
    if (family === 'villager') {
      r.leg0 = [c * 0.5, 0, 0]; r.leg1 = [-c * 0.5, 0, 0]; r.arms = [-0.75, 0, 0];
    }
    if (family === 'golem') {
      r.leg0 = [c * 0.7, 0, 0]; r.leg1 = [-c * 0.7, 0, 0]; r.arm0 = [-c * 0.6, 0, 0]; r.arm1 = [c * 0.6, 0, 0];
    }
    if (family === 'ocelot') {
      const o = Math.cos(ls * 0.6662) * amt;
      r.body = [PI / 2, 0, 0]; r.frontLegL = [o, 0, 0]; r.frontLegR = [-o, 0, 0]; r.backLegL = [-o, 0, 0]; r.backLegR = [o, 0, 0];
    }
    if (family === 'spider') {
      const zr = [-PI / 4, PI / 4, -0.58119464, 0.58119464, -0.58119464, 0.58119464, -PI / 4, PI / 4];
      const yr = [PI / 4, -PI / 4, PI / 8, -PI / 8, -PI / 8, PI / 8, -PI / 4, PI / 4];
      const w = ls * 0.6662 * 2;
      const fy = [0, PI, PI / 2, PI * 1.5].map((ph) => -Math.cos(w + ph) * 0.4 * amt);
      const fz = [0, PI, PI / 2, PI * 1.5].map((ph) => Math.abs(Math.sin(ls * 0.6662 + ph) * 0.4) * amt);
      for (let i = 0; i < 8; i++) {
        const sign = i % 2 ? -1 : 1, k = i >> 1;
        r['leg' + i] = [0, yr[i] + fy[k] * sign, zr[i] + fz[k] * sign];
      }
    }
    return r;
  }

  // Грань куба: углы (верх-лево, верх-право, низ-право, низ-лево текстуры) и затенение.
  // Координаты Bedrock: y вверх, морда смотрит в -z, правая сторона существа в -x.
  function cubeFaces(c) {
    const inf = c.i || 0;
    const x0 = c.o[0] - inf, y0 = c.o[1] - inf, z0 = c.o[2] - inf;
    const x1 = c.o[0] + c.s[0] + inf, y1 = c.o[1] + c.s[1] + inf, z1 = c.o[2] + c.s[2] + inf;
    const w = c.s[0], h = c.s[1], d = c.s[2], u = c.uv[0], v = c.uv[1];
    let right = [u, v + d, d, h], left = [u + d + w, v + d, d, h];
    if (c.m) { const t = right; right = left; left = t; }
    return [
      { r: [u + d, v + d, w, h], p: [[x0, y1, z0], [x1, y1, z0], [x1, y0, z0], [x0, y0, z0]], l: 0.85 },          // морда
      { r: [u + d + d + w, v + d, w, h], p: [[x1, y1, z1], [x0, y1, z1], [x0, y0, z1], [x1, y0, z1]], l: 0.85 },  // спина
      { r: right, p: [[x0, y1, z1], [x0, y1, z0], [x0, y0, z0], [x0, y0, z1]], l: 0.65 },                       // правый бок
      { r: left, p: [[x1, y1, z0], [x1, y1, z1], [x1, y0, z1], [x1, y0, z0]], l: 0.65 },                        // левый бок
      { r: [u + d, v, w, d], p: [[x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0]], l: 1 },                // верх
      { r: [u + d + w, v, w, d], p: [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]], l: 0.5 }           // низ
    ];
  }

  // Поворот точки вокруг шарнира кости: углы Java переводятся в систему Bedrock (ось y развёрнута)
  function rotateAround(v, pivot, rot) {
    let x = v[0] - pivot[0], y = v[1] - pivot[1], z = v[2] - pivot[2];
    const ax = -rot[0], ay = rot[1], az = -rot[2];
    if (ax) { const c = Math.cos(ax), s = Math.sin(ax); const t = y * c - z * s; z = y * s + z * c; y = t; }
    if (ay) { const c = Math.cos(ay), s = Math.sin(ay); const t = x * c + z * s; z = -x * s + z * c; x = t; }
    if (az) { const c = Math.cos(az), s = Math.sin(az); const t = x * c - y * s; y = x * s + y * c; x = t; }
    return [x + pivot[0], y + pivot[1], z + pivot[2]];
  }

  // Вершины модели существа в координатах Bedrock (пиксели) для заданной позы
  function poseModel(geo, pose, out) {
    const all = new Map();
    for (const b of geo.hidden) all.set(b.name, b);
    for (const b of geo.bones) all.set(b.name, b);
    for (const b of geo.bones) {
      const chain = [];
      for (let n = b; n; n = n.parent ? all.get(n.parent) : null) {
        const st = n.rotation, an = pose[n.name];
        const rot = [st[0] / DEG + (an ? an[0] : 0), st[1] / DEG + (an ? an[1] : 0), st[2] / DEG + (an ? an[2] : 0)];
        chain.push([n.pivot, rot]);
        if (chain.length > 8) break;
      }
      for (const c of b.cubes) {
        for (const f of cubeFaces(c)) {
          const pts = f.p.map((p0) => {
            let p = p0;
            for (const [pv, rot] of chain) if (rot[0] || rot[1] || rot[2]) p = rotateAround(p, pv, rot);
            return p;
          });
          out.push({ pts, r: f.r, l: f.l });
        }
      }
    }
    return out;
  }

  class Renderer {
    constructor(canvas) {
      this.canvas = canvas;
      const opts = { antialias: false, alpha: false, preserveDrawingBuffer: false };
      const gl = canvas.getContext('webgl2', opts) || canvas.getContext('webgl', opts) || canvas.getContext('experimental-webgl', opts);
      if (!gl) throw new Error('WebGL не поддерживается этим устройством');
      this.gl = gl;
      this.sections = new Map();
      this.skins = new Map();
      this.renderDistance = 8;
      this.fov = 70;
      this.clouds = true;
      this.width = 1;
      this.height = 1;
    }

    async init() {
      const gl = this.gl;
      const prog = gl.createProgram();
      gl.attachShader(prog, compile(gl, gl.VERTEX_SHADER, VS));
      gl.attachShader(prog, compile(gl, gl.FRAGMENT_SHADER, FS));
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error('Ошибка шейдерной программы: ' + gl.getProgramInfoLog(prog));
      this.prog = prog;
      this.a = { pos: gl.getAttribLocation(prog, 'a_pos'), uv: gl.getAttribLocation(prog, 'a_uv'), light: gl.getAttribLocation(prog, 'a_light') };
      this.u = {};
      for (const n of ['u_mvp', 'u_offset', 'u_tex', 'u_tint', 'u_daylight', 'u_alphaTest', 'u_fog', 'u_fogRange', 'u_cam', 'u_time', 'u_fancy']) this.u[n] = gl.getUniformLocation(prog, n);
      const sky = gl.createProgram();
      gl.attachShader(sky, compile(gl, gl.VERTEX_SHADER, SKY_VS));
      gl.attachShader(sky, compile(gl, gl.FRAGMENT_SHADER, SKY_FS));
      gl.linkProgram(sky);
      if (!gl.getProgramParameter(sky, gl.LINK_STATUS)) throw new Error('Ошибка шейдера неба: ' + gl.getProgramInfoLog(sky));
      this.skyProg = sky;
      this.skyA = gl.getAttribLocation(sky, 'a_pos');
      this.skyU = {};
      for (const n of ['u_fwd', 'u_right', 'u_up', 'u_tan', 'u_horizon', 'u_zenith', 'u_sun', 'u_daylight']) this.skyU[n] = gl.getUniformLocation(sky, n);
      this.skyBuf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, this.skyBuf);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
      this.scratch = new Float32Array(6 * 4096);
      this.fancy = true;
      this.startTime = performance.now();
      const [bi, ii] = await Promise.all([loadImage(A.blockAtlas), loadImage(A.itemAtlas)]);
      this.blockTex = this.texture(bi);
      this.itemTex = this.texture(ii);
      this.white = this.texture(null);
      this.mobTex = {};
      const names = Object.keys(A.entityTextures);
      const imgs = await Promise.all(names.map((n) => loadImage(A.entityTextures[n].uri)));
      names.forEach((n, i) => { this.mobTex[n] = { tex: this.texture(imgs[i]), w: A.entityTextures[n].w, h: A.entityTextures[n].h }; });
      this.mobAnim = new Map();
      this.mobLift = new Map();
      const [di, si, mi, ci] = await Promise.all([loadImage(A.destroyStages), loadImage(A.sky.sun), loadImage(A.sky.moon), loadImage(A.sky.clouds)]);
      this.destroyTex = this.texture(di);
      this.sunTex = this.texture(si);
      this.moonTex = this.texture(mi);
      this.cloudTex = this.texture(ci, true);
      this.dyn = gl.createBuffer();
      this.lineBuf = gl.createBuffer();
      gl.enable(gl.DEPTH_TEST);
      gl.enable(gl.CULL_FACE);
      gl.cullFace(gl.BACK);
    }

    texture(img, repeat) {
      const gl = this.gl;
      const t = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, t);
      if (img) gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);
      else gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([255, 255, 255, 255]));
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, repeat ? gl.REPEAT : gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, repeat ? gl.REPEAT : gl.CLAMP_TO_EDGE);
      return t;
    }

    // Скин игрока из сырых RGBA-данных (64x32 или 64x64)
    skinTexture(key, rgba) {
      if (this.skins.has(key)) return this.skins.get(key);
      const gl = this.gl;
      const h = rgba && rgba.length === 64 * 64 * 4 ? 64 : 32;
      const t = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, t);
      const data = rgba && (rgba.length === 8192 || rgba.length === 16384) ? rgba : MC.Skin.defaultSkin();
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 64, data.length === 16384 ? 64 : 32, 0, gl.RGBA, gl.UNSIGNED_BYTE, data);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      const s = { tex: t, h: data.length === 16384 ? 64 : h };
      this.skins.set(key, s);
      return s;
    }

    dropSkin(key) {
      const s = this.skins.get(key);
      if (s) { this.gl.deleteTexture(s.tex); this.skins.delete(key); }
    }

    resize(w, h, ratio) {
      const cw = Math.floor(w * ratio), ch = Math.floor(h * ratio);
      if (this.canvas.width !== cw || this.canvas.height !== ch) {
        this.canvas.width = cw;
        this.canvas.height = ch;
      }
      this.width = w;
      this.height = h;
    }

    setSection(cx, sy, cz, mesh) {
      const gl = this.gl;
      const k = cx + ',' + sy + ',' + cz;
      let s = this.sections.get(k);
      if (!s) {
        if (!mesh.solid.length && !mesh.trans.length) return;
        s = { cx, sy, cz, vbo: gl.createBuffer(), tbo: gl.createBuffer(), n: 0, tn: 0 };
        this.sections.set(k, s);
      }
      s.n = mesh.solid.length / 6;
      s.tn = mesh.trans.length / 6;
      gl.bindBuffer(gl.ARRAY_BUFFER, s.vbo);
      gl.bufferData(gl.ARRAY_BUFFER, mesh.solid, gl.STATIC_DRAW);
      gl.bindBuffer(gl.ARRAY_BUFFER, s.tbo);
      gl.bufferData(gl.ARRAY_BUFFER, mesh.trans, gl.STATIC_DRAW);
    }

    removeSection(cx, sy, cz) {
      const k = cx + ',' + sy + ',' + cz;
      const s = this.sections.get(k);
      if (!s) return;
      this.gl.deleteBuffer(s.vbo);
      this.gl.deleteBuffer(s.tbo);
      this.sections.delete(k);
    }

    clearSections() {
      for (const s of this.sections.values()) { this.gl.deleteBuffer(s.vbo); this.gl.deleteBuffer(s.tbo); }
      this.sections.clear();
    }

    bindAttribs(buf) {
      const gl = this.gl;
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.enableVertexAttribArray(this.a.pos);
      gl.enableVertexAttribArray(this.a.uv);
      gl.enableVertexAttribArray(this.a.light);
      gl.vertexAttribPointer(this.a.pos, 3, gl.FLOAT, false, 24, 0);
      gl.vertexAttribPointer(this.a.uv, 2, gl.FLOAT, false, 24, 12);
      gl.vertexAttribPointer(this.a.light, 1, gl.FLOAT, false, 24, 20);
    }

    // data: Float32Array или обычный массив; массив копируется в общий буфер без новых выделений памяти
    drawDynamic(data, mode) {
      const gl = this.gl;
      let buf = data;
      if (!(data instanceof Float32Array)) {
        if (this.scratch.length < data.length) this.scratch = new Float32Array(Math.max(data.length, this.scratch.length * 2));
        this.scratch.set(data);
        buf = this.scratch.subarray(0, data.length);
      }
      if (!buf.length) return;
      gl.bindBuffer(gl.ARRAY_BUFFER, this.dyn);
      gl.bufferData(gl.ARRAY_BUFFER, buf, gl.STREAM_DRAW);
      this.bindAttribs(this.dyn);
      gl.drawArrays(mode === undefined ? gl.TRIANGLES : mode, 0, buf.length / 6);
    }

    static skyColor(daylight) {
      const day = [0.49, 0.67, 1.0], night = [0.02, 0.03, 0.08];
      const t = Math.max(0, Math.min(1, (daylight - 0.25) / 0.75));
      return [night[0] + (day[0] - night[0]) * t, night[1] + (day[1] - night[1]) * t, night[2] + (day[2] - night[2]) * t];
    }

    // cam: {x, y, z, yaw, pitch}; scene: {daylight, underwater, entities, players, items, selection}
    render(cam, scene) {
      const gl = this.gl;
      gl.viewport(0, 0, this.canvas.width, this.canvas.height);
      const daylight = scene.daylight;
      let fog = Renderer.skyColor(daylight);
      let fogNear = this.renderDistance * 16 * 0.6, fogFar = this.renderDistance * 16 - 2;
      if (scene.underwater) { fog = [0.05, 0.12, 0.35].map((v) => v * daylight); fogNear = 2; fogFar = 24; }
      if (scene.inLava) { fog = [0.6, 0.15, 0.0]; fogNear = 0.2; fogFar = 3; }
      gl.clearColor(fog[0], fog[1], fog[2], 1);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

      const yaw = cam.yaw * Math.PI / 180, pitch = cam.pitch * Math.PI / 180;
      const fwd = [-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch)];
      const proj = M4.perspective(this.fov * Math.PI / 180, this.width / this.height, 0.05, this.renderDistance * 16 + 48);
      const view = M4.lookAt([0, 0, 0], fwd, [0, 1, 0]);
      const vp = M4.mul(proj, view);
      this.vp = vp;
      this.cam = cam;
      const planes = frustumPlanes(vp);
      if (this.fancy && !scene.underwater && !scene.inLava) this.renderSkyGradient(scene, fwd, fog, daylight);

      gl.useProgram(this.prog);
      gl.uniformMatrix4fv(this.u.u_mvp, false, vp);
      gl.uniform1i(this.u.u_tex, 0);
      gl.uniform3f(this.u.u_cam, cam.x, cam.y, cam.z);
      gl.uniform1f(this.u.u_time, (performance.now() - this.startTime) / 1000 % 10000);
      gl.uniform1f(this.u.u_fancy, this.fancy ? 1 : 0);
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      gl.uniform1f(this.u.u_daylight, daylight);
      gl.uniform3f(this.u.u_fog, fog[0], fog[1], fog[2]);
      gl.uniform2f(this.u.u_fogRange, fogNear, fogFar);
      gl.uniform1f(this.u.u_alphaTest, 0.5);
      gl.activeTexture(gl.TEXTURE0);
      if (!scene.underwater && !scene.inLava) this.renderSky(scene);
      gl.bindTexture(gl.TEXTURE_2D, this.blockTex);

      const maxDist = this.renderDistance * 16 + 24;
      const visible = [];
      for (const s of this.sections.values()) {
        const ox = s.cx * 16 - cam.x, oy = s.sy * 16 - cam.y, oz = s.cz * 16 - cam.z;
        const dx = ox + 8, dy = oy + 8, dz = oz + 8;
        const d2 = dx * dx + dz * dz;
        if (d2 > maxDist * maxDist) continue;
        if (!boxInFrustum(planes, ox, oy, oz, ox + 16, oy + 16, oz + 16)) continue;
        visible.push({ s, ox, oy, oz, d: d2 + dy * dy });
      }
      visible.sort((a, b) => a.d - b.d);

      gl.disable(gl.BLEND);
      gl.depthMask(true);
      for (const v of visible) {
        if (!v.s.n) continue;
        gl.uniform3f(this.u.u_offset, v.ox, v.oy, v.oz);
        this.bindAttribs(v.s.vbo);
        gl.drawArrays(gl.TRIANGLES, 0, v.s.n);
      }

      this.renderEntities(scene, cam);

      // Полупрозрачные блоки (вода, лёд) — от дальних к ближним
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      gl.depthMask(false);
      gl.disable(gl.CULL_FACE);
      gl.uniform1f(this.u.u_alphaTest, 0.01);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 0.75);
      for (let i = visible.length - 1; i >= 0; i--) {
        const v = visible[i];
        if (!v.s.tn) continue;
        gl.uniform3f(this.u.u_offset, v.ox, v.oy, v.oz);
        this.bindAttribs(v.s.tbo);
        gl.drawArrays(gl.TRIANGLES, 0, v.s.tn);
      }
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      if (this.clouds && !scene.underwater && !scene.inLava) this.renderClouds(scene, cam, fogFar);
      gl.depthMask(true);
      gl.enable(gl.CULL_FACE);

      if (scene.selection) this.renderSelection(scene.selection, cam, scene.breakProgress || 0);
      gl.disable(gl.BLEND);
      if (scene.hand) this.renderHand(scene.hand);
    }

    renderSkyGradient(scene, fwd, horizon, daylight) {
      const gl = this.gl;
      const time = scene.time || 0;
      const a = (((time % 24000) + 24000) % 24000) / 24000 * Math.PI * 2;
      const right = [fwd[2], 0, -fwd[0]];
      const rl = Math.hypot(right[0], right[2]) || 1;
      right[0] /= rl; right[2] /= rl;
      const up = [right[1] * fwd[2] - right[2] * fwd[1], right[2] * fwd[0] - right[0] * fwd[2], right[0] * fwd[1] - right[1] * fwd[0]];
      const tanY = Math.tan(this.fov * Math.PI / 360), tanX = tanY * this.width / this.height;
      const zenith = Renderer.skyColor(daylight).map((v, i) => v * [0.62, 0.72, 1.0][i]);
      gl.useProgram(this.skyProg);
      gl.disable(gl.DEPTH_TEST);
      gl.depthMask(false);
      gl.uniform3f(this.skyU.u_fwd, fwd[0], fwd[1], fwd[2]);
      gl.uniform3f(this.skyU.u_right, right[0], right[1], right[2]);
      gl.uniform3f(this.skyU.u_up, up[0], up[1], up[2]);
      gl.uniform2f(this.skyU.u_tan, tanX, tanY);
      gl.uniform3f(this.skyU.u_horizon, horizon[0], horizon[1], horizon[2]);
      gl.uniform3f(this.skyU.u_zenith, zenith[0], zenith[1], zenith[2]);
      gl.uniform3f(this.skyU.u_sun, Math.cos(a), Math.sin(a), 0);
      gl.uniform1f(this.skyU.u_daylight, daylight);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.skyBuf);
      gl.enableVertexAttribArray(this.skyA);
      gl.vertexAttribPointer(this.skyA, 2, gl.FLOAT, false, 8, 0);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      gl.disableVertexAttribArray(this.skyA);
      gl.depthMask(true);
      gl.enable(gl.DEPTH_TEST);
    }

    // Солнце и луна (фаза по номеру дня), как в Minecraft: восходят на востоке (+x), заходят на западе
    renderSky(scene) {
      const gl = this.gl;
      const time = scene.time || 0;
      const a = (((time % 24000) + 24000) % 24000) / 24000 * Math.PI * 2;
      const dir = [Math.cos(a), Math.sin(a), 0];
      const side = [-Math.sin(a), Math.cos(a), 0];
      const dist = 60, size = 18;
      const quad = (d, sz, u0, v0, u1, v1) => {
        const cx = d[0] * dist, cy = d[1] * dist;
        const sx = side[0] * sz, sy = side[1] * sz;
        const p = [[cx - sx, cy - sy, -sz, u0, v1], [cx + sx, cy + sy, -sz, u1, v1], [cx + sx, cy + sy, sz, u1, v0], [cx - sx, cy - sy, sz, u0, v0]];
        const out = [];
        for (const k of [0, 1, 2, 0, 2, 3]) out.push(p[k][0], p[k][1], p[k][2], p[k][3], p[k][4], 1);
        return new Float32Array(out);
      };
      gl.disable(gl.DEPTH_TEST);
      gl.disable(gl.CULL_FACE);
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.ONE, gl.ONE);
      gl.uniform3f(this.u.u_offset, 0, 0, 0);
      gl.uniform1f(this.u.u_daylight, 1);
      gl.uniform2f(this.u.u_fogRange, 10000, 20000);
      gl.uniform1f(this.u.u_alphaTest, 0);
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      gl.bindTexture(gl.TEXTURE_2D, this.sunTex);
      this.drawDynamic(quad(dir, size, 0, 0, 1, 1));
      const phase = Math.floor(time / 24000) % 8;
      const mu = (phase % 4) / 4, mv = Math.floor(phase / 4) / 2;
      gl.bindTexture(gl.TEXTURE_2D, this.moonTex);
      this.drawDynamic(quad([-dir[0], -dir[1], 0], size * 0.8, mu, mv, mu + 0.25, mv + 0.5));
      gl.disable(gl.BLEND);
      gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      gl.enable(gl.DEPTH_TEST);
      gl.enable(gl.CULL_FACE);
      gl.uniform1f(this.u.u_daylight, scene.daylight);
      gl.uniform2f(this.u.u_fogRange, this.renderDistance * 16 * 0.6, this.renderDistance * 16 - 2);
      gl.uniform1f(this.u.u_alphaTest, 0.5);
    }

    // Облака clouds.png на высоте 128: один пиксель текстуры — 12 блоков, медленно плывут на запад
    renderClouds(scene, cam, fogFar) {
      const gl = this.gl;
      const y = 128.33 - cam.y;
      const r = this.renderDistance * 16 + 32;
      const span = 256 * 12;
      const drift = (scene.time || 0) * 0.03;
      const u = (wx) => (wx + drift) / span, v = (wz) => wz / span;
      // Сетка из клеток, чтобы туман считался по расстоянию до каждой части слоя
      const n = 24, step = (r * 2) / n;
      const out = [];
      for (let i = 0; i < n; i++) {
        for (let j = 0; j < n; j++) {
          const ax = -r + i * step, az = -r + j * step, bx = ax + step, bz = az + step;
          const p = [[ax, az], [bx, az], [bx, bz], [ax, bz]];
          for (const k of [0, 1, 2, 0, 2, 3]) out.push(p[k][0], y, p[k][1], u(cam.x + p[k][0]), v(cam.z + p[k][1]), 1);
        }
      }
      gl.disable(gl.CULL_FACE);
      gl.uniform3f(this.u.u_offset, 0, 0, 0);
      gl.uniform1f(this.u.u_alphaTest, 0.5);
      gl.uniform2f(this.u.u_fogRange, fogFar * 0.5, r);
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 0.8);
      gl.bindTexture(gl.TEXTURE_2D, this.cloudTex);
      this.drawDynamic(out);
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      gl.uniform2f(this.u.u_fogRange, this.renderDistance * 16 * 0.6, fogFar);
    }

    renderSelection(sel, cam, progress) {
      const gl = this.gl;
      const out = [];
      const e = 0.002;
      for (const b of sel.boxes) {
        const x0 = sel.x + b[0] - e - cam.x, y0 = sel.y + b[1] - e - cam.y, z0 = sel.z + b[2] - e - cam.z;
        const x1 = sel.x + b[3] + e - cam.x, y1 = sel.y + b[4] + e - cam.y, z1 = sel.z + b[5] + e - cam.z;
        const c = [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], [x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]];
        const edges = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]];
        for (const [a, b2] of edges) {
          out.push(c[a][0], c[a][1], c[a][2], 0, 0, 1, c[b2][0], c[b2][1], c[b2][2], 0, 0, 1);
        }
      }
      gl.uniform3f(this.u.u_offset, 0, 0, 0);
      gl.bindTexture(gl.TEXTURE_2D, this.white);
      gl.uniform1f(this.u.u_daylight, 1);
      gl.uniform2f(this.u.u_fogRange, 1000, 2000);
      gl.uniform1f(this.u.u_alphaTest, 0);
      gl.uniform4f(this.u.u_tint, 0, 0, 0, 0.6);
      this.drawDynamic(out, gl.LINES);
      // Трещины на блоке по мере разрушения (destroy_stage_0..9)
      if (progress > 0) {
        const stage = Math.min(9, Math.floor(progress * 10));
        const F = MC.Mesher.FACES;
        const tri = [];
        for (const b of sel.boxes) {
          const bx = [sel.x + b[0] - 0.003 - cam.x, sel.y + b[1] - 0.003 - cam.y, sel.z + b[2] - 0.003 - cam.z,
            sel.x + b[3] + 0.003 - cam.x, sel.y + b[4] + 0.003 - cam.y, sel.z + b[5] + 0.003 - cam.z];
          for (let f = 0; f < 6; f++) {
            const q = [];
            for (let k = 0; k < 4; k++) {
              const c = F[f].c[k];
              const uv = MC.Mesher.faceUV(f, c[0], c[1], c[2]);
              q.push([c[0] ? bx[3] : bx[0], c[1] ? bx[4] : bx[1], c[2] ? bx[5] : bx[2], (stage + uv[0]) / 10, uv[1]]);
            }
            for (const k of [0, 1, 2, 0, 2, 3]) tri.push(q[k][0], q[k][1], q[k][2], q[k][3], q[k][4], 1);
          }
        }
        gl.disable(gl.CULL_FACE);
        gl.bindTexture(gl.TEXTURE_2D, this.destroyTex);
        gl.blendFunc(gl.DST_COLOR, gl.SRC_COLOR);
        gl.uniform1f(this.u.u_alphaTest, 0.05);
        gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
        this.drawDynamic(tri);
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
        gl.enable(gl.CULL_FACE);
      }
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
    }

    renderEntities(scene, cam) {
      const gl = this.gl;
      gl.uniform3f(this.u.u_offset, 0, 0, 0);
      gl.uniform1f(this.u.u_alphaTest, 0.1);
      // Игроки со своими скинами
      for (const p of scene.players) {
        const skin = this.skinTexture(p.skinKey, p.skin);
        const verts = [];
        buildPlayer(verts, p, cam, skin.h);
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, skin.tex);
        gl.disable(gl.CULL_FACE);
        if (p.hurt > 0) gl.uniform4f(this.u.u_tint, 1, 0.45, 0.45, 1);
        this.drawDynamic(verts);
        gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
        gl.enable(gl.CULL_FACE);
      }
      // Существа: модели и текстуры из ресурсов игры
      if (scene.entities.length) {
        const now = performance.now();
        const anim = new Map();
        const cull = (this.renderDistance * 16 + 16) ** 2;
        for (const e of scene.entities) {
          if ((e.x - cam.x) ** 2 + (e.z - cam.z) ** 2 > cull) continue;
          let flash = null;
          if (e.hurt > 0 || e.dead) flash = [1, 0.45, 0.45];
          else if (e.fuse > 0 && Math.sin(e.fuse * 25) > 0) flash = [1.6, 1.6, 1.6];
          const def = MOBS[e.type];
          if (!def || !this.mobTex[def[1]]) {
            const look = ENTITY_LOOK[e.type] || ['Существо #' + e.type, [0.7, 0.3, 0.7], [0.6, 1.0, 0.6]];
            const verts = [];
            if (e.type === 65 || (e.type === 66 && e.blockId)) {
              const id = e.type === 65 ? 46 : e.blockId;
              const b = MC.Blocks.list[id];
              const x = e.x - cam.x, y = e.y - cam.y, z = e.z - cam.z;
              pushBox(verts, [x - 0.49, y, z - 0.49, x + 0.49, y + 0.98, z + 0.49], (f) => b.tex(e.blockData || 0, f, null), 1, A.blockGrid);
              gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
              const c = flash || [1, 1, 1];
              gl.uniform4f(this.u.u_tint, c[0], c[1], c[2], 1);
            } else {
              pushRotatedBox(verts, e.x - cam.x, e.y - cam.y, e.z - cam.z, look[2][0], look[2][1], look[2][2], -e.yaw * Math.PI / 180);
              gl.bindTexture(gl.TEXTURE_2D, this.white);
              const c = flash || look[1];
              gl.uniform4f(this.u.u_tint, c[0], c[1], c[2], 1);
            }
            this.drawDynamic(verts);
            continue;
          }
          // Сила шага по скорости движения (как limbSwingAmount в Minecraft)
          const prev = this.mobAnim.get(e.eid);
          const walk = e.walk || 0;
          let amt = 0;
          if (prev) {
            const dt = Math.max(0.001, (now - prev.t) / 1000);
            const target = Math.min(1, Math.max(0, walk - prev.walk) / dt / 5);
            amt = prev.amt + (target - prev.amt) * Math.min(1, dt * 8);
          }
          anim.set(e.eid, { walk, amt, t: now });
          const pose = animate(def[3], walk * 4, amt, (e.pitch || 0) * Math.PI / 180);
          const tex = this.mobTex[def[1]];
          const verts = [];
          const scale = def[2] / 16;
          const yawR = -e.yaw * Math.PI / 180;
          const cy = Math.cos(yawR), sy = Math.sin(yawR);
          for (const gname of def[0]) {
            const geo = A.geometry[gname];
            const faces = poseModel(geo, pose, []);
            let lift = this.mobLift.get(gname + def[3]);
            if (lift === undefined) {
              lift = 0;
              for (const f of poseModel(geo, animate(def[3], 0, 0, 0), [])) for (const pt of f.pts) lift = Math.min(lift, pt[1]);
              lift = -lift;
              this.mobLift.set(gname + def[3], lift);
            }
            const ox = e.x - cam.x, oy = e.y - cam.y, oz = e.z - cam.z;
            for (const f of faces) {
              const r = f.r;
              const uv = [[r[0], r[1]], [r[0] + r[2], r[1]], [r[0] + r[2], r[1] + r[3]], [r[0], r[1] + r[3]]];
              const v = f.pts.map((pt, k) => {
                const mx = pt[0] * scale, my = (pt[1] + lift) * scale, mz = -pt[2] * scale;
                return [ox + mx * cy + mz * sy, oy + my, oz - mx * sy + mz * cy, uv[k][0] / tex.w, uv[k][1] / tex.h];
              });
              for (const k of [0, 1, 2, 0, 2, 3]) verts.push(v[k][0], v[k][1], v[k][2], v[k][3], v[k][4], f.l);
            }
          }
          gl.bindTexture(gl.TEXTURE_2D, tex.tex);
          const c = flash || [1, 1, 1];
          gl.uniform4f(this.u.u_tint, c[0], c[1], c[2], 1);
          gl.disable(gl.CULL_FACE);
          this.drawDynamic(verts);
          gl.enable(gl.CULL_FACE);
        }
        this.mobAnim = anim;
        gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      }
      // Выброшенные предметы
      for (const it of scene.items) {
        const verts = [];
        const s = 0.25;
        const bob = Math.sin(performance.now() / 400 + it.eid) * 0.05;
        const x = it.x - cam.x, y = it.y - cam.y + 0.15 + bob, z = it.z - cam.z;
        if (it.item.id > 0 && it.item.id < 256) {
          const b = MC.Blocks.list[it.item.id];
          const d = b.variants > 1 ? it.item.data : 0;
          pushBox(verts, [x - s / 2, y, z - s / 2, x + s / 2, y + s, z + s / 2], (f) => b.tex(d, f, null), 1, A.blockGrid);
          gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
        } else {
          const tile = MC.Items.itemTexture(it.item.id, it.item.data);
          if (tile === null) continue;
          const a = performance.now() / 1000 + it.eid;
          const dx = Math.cos(a) * s, dz = Math.sin(a) * s;
          const [u0, v0] = [(tile % A.itemGrid) / A.itemGrid, Math.floor(tile / A.itemGrid) / A.itemGrid];
          const t = 1 / A.itemGrid;
          const q = [[x - dx, y, z - dz, u0, v0 + t], [x + dx, y, z + dz, u0 + t, v0 + t], [x + dx, y + 2 * s, z + dz, u0 + t, v0], [x - dx, y + 2 * s, z - dz, u0, v0]];
          for (const k of [0, 1, 2, 0, 2, 3]) verts.push(q[k][0], q[k][1], q[k][2], q[k][3], q[k][4], 1);
          gl.bindTexture(gl.TEXTURE_2D, this.itemTex);
          gl.disable(gl.CULL_FACE);
        }
        this.drawDynamic(verts);
        gl.enable(gl.CULL_FACE);
      }
      gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
      gl.uniform1f(this.u.u_alphaTest, 0.5);
    }

    // Рука или предмет в руке от первого лица.
    // hand: {item, swing (1 → 0 во время взмаха), walk, skinKey, skin, daylight, eating}
    renderHand(hand) {
      const gl = this.gl;
      gl.clear(gl.DEPTH_BUFFER_BIT);
      const proj = M4.perspective(70 * Math.PI / 180, this.width / this.height, 0.02, 10);
      gl.uniformMatrix4fv(this.u.u_mvp, false, proj);
      gl.uniform3f(this.u.u_offset, 0, 0, 0);
      gl.uniform1f(this.u.u_daylight, Math.max(0.35, hand.daylight));
      gl.uniform2f(this.u.u_fogRange, 1000, 2000);
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      gl.uniform1f(this.u.u_alphaTest, 0.1);
      gl.disable(gl.CULL_FACE);
      // Взмах и покачивание при ходьбе, как в Minecraft
      const f = hand.swing > 0 ? 1 - hand.swing : 0;
      const sf = Math.sin(Math.sqrt(f) * Math.PI);
      const bobX = Math.sin(hand.walk * Math.PI) * 0.025, bobY = -Math.abs(Math.cos(hand.walk * Math.PI)) * 0.04;
      let tx = 0.56 + bobX - sf * 0.35, ty = -0.52 + bobY + Math.sin(Math.sqrt(f) * Math.PI * 2) * 0.18, tz = -0.72 - Math.sin(f * Math.PI) * 0.2;
      let rx = -sf * 60, ry = -Math.sin(f * f * Math.PI) * 20;
      if (hand.eating > 0) {
        tx -= 0.35; ty += 0.12 + Math.abs(Math.sin(hand.eating * 25)) * 0.05; rx += 25;
      }
      const verts = [];
      const it = hand.item;
      if (!it || !it.id) {
        const skin = this.skinTexture(hand.skinKey, hand.skin);
        buildArm(verts, skin.h);
        transform(verts, 1, [100 + rx * 0.6, 15 + ry, 0], [tx + 0.1, ty - 0.02, tz + 0.75]);
        gl.bindTexture(gl.TEXTURE_2D, skin.tex);
      } else if (it.id < 256 && MC.Blocks.list[it.id].shape !== 'cross' && MC.Blocks.list[it.id].shape !== 'torch' && MC.Blocks.list[it.id].shape !== 'crop') {
        const b = MC.Blocks.list[it.id];
        const d = b.variants > 1 ? it.data : 0;
        pushBox(verts, [-0.5, -0.5, -0.5, 0.5, 0.5, 0.5], (fc) => b.tex(d, fc, null), 1, A.blockGrid);
        transform(verts, 0.26, [rx + 10, ry + 45, 0], [tx - 0.02, ty + 0.14, tz - 0.05]);
        gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
      } else {
        let tile, grid, tex;
        if (it.id < 256) { tile = MC.Blocks.list[it.id].tex(it.data, 2, null); grid = A.blockGrid; tex = this.blockTex; }
        else { tile = MC.Items.itemTexture(it.id, it.data); grid = A.itemGrid; tex = this.itemTex; }
        if (tile === null || tile === undefined) { tile = MC.Blocks.MISSING; grid = A.blockGrid; tex = this.blockTex; }
        const u0 = (tile % grid) / grid, v0 = Math.floor(tile / grid) / grid, t = 1 / grid;
        const q = [[-0.5, -0.5, 0, u0, v0 + t], [0.5, -0.5, 0, u0 + t, v0 + t], [0.5, 0.5, 0, u0 + t, v0], [-0.5, 0.5, 0, u0, v0]];
        for (const k of [0, 1, 2, 0, 2, 3]) verts.push(q[k][0], q[k][1], q[k][2], q[k][3], q[k][4], 0.95);
        transform(verts, 0.45, [rx, ry - 70, 25], [tx, ty + 0.12, tz]);
        gl.bindTexture(gl.TEXTURE_2D, tex);
      }
      this.drawDynamic(verts);
      gl.enable(gl.CULL_FACE);
      gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
      gl.uniform1f(this.u.u_alphaTest, 0.5);
    }

    // Мировая точка -> экранные координаты CSS (для ников над головами)
    project(x, y, z) {
      if (!this.vp || !this.cam) return null;
      const m = this.vp;
      const px = x - this.cam.x, py = y - this.cam.y, pz = z - this.cam.z;
      const cx = m[0] * px + m[4] * py + m[8] * pz + m[12];
      const cy = m[1] * px + m[5] * py + m[9] * pz + m[13];
      const cw = m[3] * px + m[7] * py + m[11] * pz + m[15];
      if (cw <= 0.1) return null;
      return { x: (cx / cw * 0.5 + 0.5) * this.width, y: (1 - (cy / cw * 0.5 + 0.5)) * this.height, d: cw };
    }
  }

  // ---------- Геометрия ----------
  function pushBox(out, b, texFn, light, grid) {
    const F = MC.Mesher.FACES;
    for (let f = 0; f < 6; f++) {
      let tu = 0, tv = 0, ts = 1;
      if (texFn) { const tile = texFn(f); ts = 1 / grid; tu = (tile % grid) * ts; tv = Math.floor(tile / grid) * ts; }
      const verts = [];
      for (let k = 0; k < 4; k++) {
        const c = F[f].c[k];
        const uv = MC.Mesher.faceUV(f, c[0], c[1], c[2]);
        verts.push([c[0] ? b[3] : b[0], c[1] ? b[4] : b[1], c[2] ? b[5] : b[2], tu + uv[0] * ts, tv + uv[1] * ts]);
      }
      const l = light * F[f].shade;
      for (const k of [0, 1, 2, 0, 2, 3]) out.push(verts[k][0], verts[k][1], verts[k][2], verts[k][3], verts[k][4], l);
    }
  }

  function pushRotatedBox(out, x, y, z, w, h, d, yaw) {
    const cos = Math.cos(yaw), sin = Math.sin(yaw);
    const F = MC.Mesher.FACES;
    for (let f = 0; f < 6; f++) {
      const verts = [];
      for (let k = 0; k < 4; k++) {
        const c = F[f].c[k];
        const lx = (c[0] - 0.5) * w, lz = (c[2] - 0.5) * d;
        verts.push([x + lx * cos + lz * sin, y + c[1] * h, z - lx * sin + lz * cos]);
      }
      const l = F[f].shade;
      for (const k of [0, 1, 2, 0, 2, 3]) out.push(verts[k][0], verts[k][1], verts[k][2], 0.5, 0.5, l);
    }
  }

  // Масштаб, поворот (градусы X, Y, Z) и перенос вершин (шаг 6 чисел)
  function transform(v, scale, rot, pos) {
    const [ax, ay, az] = rot.map((r) => r * Math.PI / 180);
    const cx = Math.cos(ax), sx = Math.sin(ax), cy = Math.cos(ay), sy = Math.sin(ay), cz = Math.cos(az), sz = Math.sin(az);
    for (let i = 0; i < v.length; i += 6) {
      let x = v[i] * scale, y = v[i + 1] * scale, z = v[i + 2] * scale;
      let t = x * cz - y * sz; y = x * sz + y * cz; x = t;
      t = y * cx - z * sx; z = y * sx + z * cx; y = t;
      t = x * cy + z * sy; z = -x * sy + z * cy; x = t;
      v[i] = x + pos[0]; v[i + 1] = y + pos[1]; v[i + 2] = z + pos[2];
    }
  }

  // Правая рука игрока из скина, единицы — блоки, плечо в начале координат
  function buildArm(out, skinH) {
    const F = MC.Mesher.FACES;
    const rects = skinRects(40, 16, 4, 12, 4);
    const s = 1 / 16;
    for (let f = 0; f < 6; f++) {
      const r = rects[f];
      const verts = [];
      for (let k = 0; k < 4; k++) {
        const c = F[f].c[k];
        const uv = MC.Mesher.faceUV(f, c[0], c[1], c[2]);
        verts.push([(-2 + c[0] * 4) * s, (-12 + c[1] * 12) * s, (-2 + c[2] * 4) * s, (r[0] + uv[0] * r[2]) / 64, (r[1] + uv[1] * r[3]) / skinH]);
      }
      for (const k of [0, 1, 2, 0, 2, 3]) out.push(verts[k][0], verts[k][1], verts[k][2], verts[k][3], verts[k][4], F[f].shade);
    }
  }

  // Развёртка грани параллелепипеда по скину: [u, v, w, h] в пикселях скина для каждой грани
  function skinRects(u, v, w, h, d) {
    return [
      [u + d + w, v, w, d],       // низ
      [u + d, v, w, d],           // верх
      [u + d + w + d, v + d, w, h], // север (спина)
      [u + d, v + d, w, h],       // юг (лицо)
      [u, v + d, d, h],           // запад (правый бок модели)
      [u + d + w, v + d, d, h]    // восток (левый бок модели)
    ];
  }

  function buildPlayer(out, p, cam, skinH) {
    const yaw = -p.yaw * Math.PI / 180;
    const cy = Math.cos(yaw), sy = Math.sin(yaw);
    const swing = Math.sin(p.walk * 0.6) * Math.min(1, p.walkAmount) * 0.8;
    const armSwing = p.swingTime > 0 ? Math.sin((1 - p.swingTime) * Math.PI) * 1.2 : 0;
    const F = MC.Mesher.FACES;
    for (const part of PARTS) {
      const uvBase = skinH === 64 && part.uv64 ? part.uv64 : part.uv;
      const rects = skinRects(uvBase[0], uvBase[1], part.size[0], part.size[1], part.size[2]);
      let rotX = 0;
      if (part.name === 'head' || part.name === 'hat') rotX = p.pitch * Math.PI / 180;
      else if (part.name === 'rarm') rotX = -swing - armSwing;
      else if (part.name === 'larm') rotX = swing;
      else if (part.name === 'rleg') rotX = swing;
      else if (part.name === 'lleg') rotX = -swing;
      const crx = Math.cos(rotX), srx = Math.sin(rotX);
      const mirror = skinH !== 64 && (part.name === 'larm' || part.name === 'lleg');
      for (let f = 0; f < 6; f++) {
        const r = rects[f];
        const verts = [];
        for (let k = 0; k < 4; k++) {
          const c = F[f].c[k];
          // Локальные координаты в пикселях модели относительно шарнира
          const inf = part.inflate || 0;
          let lx = part.origin[0] - inf + c[0] * (part.size[0] + inf * 2);
          let ly = part.origin[1] - inf + c[1] * (part.size[1] + inf * 2);
          let lz = part.origin[2] - inf + c[2] * (part.size[2] + inf * 2);
          // Поворот вокруг оси X (кивок головы, взмах рук и ног)
          const ry = ly * crx - lz * srx;
          const rz = ly * srx + lz * crx;
          ly = ry; lz = rz;
          let mx = (part.pivot[0] + lx) * PX, my = (part.pivot[1] + ly) * PX, mz = (part.pivot[2] + lz) * PX;
          // Поворот всей модели по направлению взгляда
          const wx = mx * cy + mz * sy, wz = -mx * sy + mz * cy;
          const uv = MC.Mesher.faceUV(f, c[0], c[1], c[2]);
          let uu = uv[0];
          if (mirror) uu = 1 - uu;
          verts.push([p.x - cam.x + wx, p.y - cam.y + my, p.z - cam.z + wz, (r[0] + uu * r[2]) / 64, (r[1] + uv[1] * r[3]) / skinH]);
        }
        const l = F[f].shade * (p.hurt > 0 ? 0.6 : 1);
        for (const k of [0, 1, 2, 0, 2, 3]) out.push(verts[k][0], verts[k][1], verts[k][2], verts[k][3], verts[k][4], l);
      }
    }
  }

  function frustumPlanes(m) {
    const p = [];
    const rows = (i) => [m[i], m[4 + i], m[8 + i], m[12 + i]];
    const r0 = rows(0), r1 = rows(1), r2 = rows(2), r3 = rows(3);
    const add = (a, s) => [r3[0] + s * a[0], r3[1] + s * a[1], r3[2] + s * a[2], r3[3] + s * a[3]];
    p.push(add(r0, 1), add(r0, -1), add(r1, 1), add(r1, -1), add(r2, 1), add(r2, -1));
    return p;
  }

  function boxInFrustum(planes, x0, y0, z0, x1, y1, z1) {
    for (const pl of planes) {
      const x = pl[0] >= 0 ? x1 : x0, y = pl[1] >= 0 ? y1 : y0, z = pl[2] >= 0 ? z1 : z0;
      if (pl[0] * x + pl[1] * y + pl[2] * z + pl[3] < 0) return false;
    }
    return true;
  }

  MC.Renderer = Renderer;
  MC.ENTITY_LOOK = ENTITY_LOOK;
})();
