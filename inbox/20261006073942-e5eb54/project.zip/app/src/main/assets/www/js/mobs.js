// Существа и выброшенные предметы одиночной игры: появление, поведение, бой, взрывы, подбор предметов
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const Blocks = MC.Blocks;

  // hp, скорость (доля от скорости игрока), враждебность, урон, добыча [id, data, min, max]
  const DEFS = {
    10: { hp: 4, speed: 0.4, drops: [[288, 0, 0, 2], [365, 0, 1, 1]], cooked: { 365: 366 } },
    11: { hp: 10, speed: 0.35, drops: [[334, 0, 0, 2], [363, 0, 1, 3]], cooked: { 363: 364 } },
    12: { hp: 10, speed: 0.4, drops: [[319, 0, 1, 3]], cooked: { 319: 320 } },
    13: { hp: 8, speed: 0.4, drops: [[35, 0, 1, 1], [423, 0, 1, 2]], cooked: { 423: 424 } },
    32: { hp: 20, speed: 0.55, hostile: true, damage: 3, burns: true, kill: 'Убит зомби', drops: [[367, 0, 0, 2]] },
    33: { hp: 20, speed: 0.5, hostile: true, creeper: true, drops: [[289, 0, 0, 2]] },
    35: { hp: 16, speed: 0.7, hostile: true, damage: 2, dayNeutral: true, kill: 'Убит пауком', drops: [[287, 0, 0, 2], [375, 0, 0, 1]] }
  };
  const PASSIVE = [12, 11, 13, 10];
  const HOSTILE = [32, 32, 33, 35];
  const MOB_CAP = 10, HOSTILE_CAP = 8;

  const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  const yawTo = (dx, dz) => Math.atan2(-dx, dz) * 180 / Math.PI;

  class Entities {
    constructor(game) {
      this.game = game;
      this.world = game.world;
      this.list = new Map();
      this.nextId = 1;
      this.spawnTimer = 0;
    }

    // ---------- Предметы ----------
    spawnItem(item, x, y, z, vx, vy, vz, delay) {
      if (!item || !item.id || item.count <= 0) return;
      const eid = this.nextId++;
      this.list.set(eid, {
        kind: 'item', eid, item: { id: item.id, data: item.data, count: item.count },
        x, y, z, vx: vx === undefined ? (Math.random() - 0.5) * 2 : vx, vy: vy === undefined ? 3 : vy, vz: vz === undefined ? (Math.random() - 0.5) * 2 : vz,
        age: 0, delay: delay === undefined ? 0.5 : delay
      });
    }

    solidAt(x, y, z) {
      const bx = Math.floor(x), by = Math.floor(y), bz = Math.floor(z);
      const id = this.world.getId(bx, by, bz);
      if (!id) return false;
      const boxes = Blocks.collisionBoxes(id, this.world.getData(bx, by, bz), this.world, bx, by, bz);
      if (!boxes) return false;
      return boxes.some((b) => y - by >= b[1] - 1e-4 && y - by < b[4] && x - bx >= b[0] && x - bx <= b[3] && z - bz >= b[2] && z - bz <= b[5]);
    }

    updateItem(e, dt) {
      e.age += dt;
      e.delay -= dt;
      if (e.age > 300) { this.list.delete(e.eid); return; }
      const w = this.world;
      if (!w.isLoaded(Math.floor(e.x), Math.floor(e.z))) return;
      const inWater = (() => { const id = w.getId(Math.floor(e.x), Math.floor(e.y), Math.floor(e.z)); return id === 8 || id === 9; })();
      e.vy -= (inWater ? 4 : 20) * dt;
      if (inWater) e.vy = Math.max(e.vy, 1);
      const nx = e.x + e.vx * dt, nz = e.z + e.vz * dt, ny = e.y + e.vy * dt;
      if (!this.solidAt(nx, e.y + 0.05, e.z)) e.x = nx; else e.vx = 0;
      if (!this.solidAt(e.x, e.y + 0.05, nz)) e.z = nz; else e.vz = 0;
      if (e.vy < 0 && this.solidAt(e.x, ny, e.z)) {
        const by = Math.floor(ny);
        const id = w.getId(Math.floor(e.x), by, Math.floor(e.z));
        const boxes = Blocks.collisionBoxes(id, w.getData(Math.floor(e.x), by, Math.floor(e.z)), w, Math.floor(e.x), by, Math.floor(e.z)) || [[0, 0, 0, 1, 1, 1]];
        e.y = by + Math.max(...boxes.map((b) => b[4]));
        e.vy = 0;
        e.vx *= Math.pow(0.02, dt);
        e.vz *= Math.pow(0.02, dt);
      } else if (e.vy > 0 && this.solidAt(e.x, ny + 0.25, e.z)) {
        e.vy = 0;
      } else {
        e.y = ny;
      }
      if (this.solidAt(e.x, e.y + 0.1, e.z)) e.y = Math.floor(e.y + 0.1) + 1;
      // Подбор игроком
      const p = this.game.player;
      if (e.delay <= 0 && !this.game.dead && Math.abs(e.x - p.x) < 1.4 && Math.abs(e.z - p.z) < 1.4 && e.y > p.y - 0.8 && e.y < p.y + 2.2) {
        const left = this.game.sinv.add(e.item);
        if (left < e.item.count) this.game.onPickup(e.item);
        if (left <= 0) this.list.delete(e.eid); else e.item.count = left;
      }
    }

    // ---------- Существа ----------
    spawnMob(type, x, y, z) {
      const def = DEFS[type];
      if (!def) return null;
      const body = new MC.Player(this.world);
      body.canFly = false;
      body.x = x; body.y = y; body.z = z;
      body.yaw = Math.random() * 360;
      const eid = this.nextId++;
      const m = { kind: 'mob', eid, type, def, body, hp: def.hp, hurt: 0, invuln: 0, wander: 0, walking: false, flee: 0, angry: 0, attackCd: 0, fuse: 0, burn: 0, lava: 0, dead: 0 };
      this.list.set(eid, m);
      return m;
    }

    hurtMob(m, dmg, fromX, fromZ, byPlayer) {
      if (m.dead || m.invuln > 0) return false;
      m.hp -= dmg;
      m.hurt = 0.4;
      m.invuln = 0.5;
      const dx = m.body.x - fromX, dz = m.body.z - fromZ;
      const l = Math.hypot(dx, dz) || 1;
      m.body.vx += dx / l * 7;
      m.body.vz += dz / l * 7;
      m.body.vy = 5;
      if (byPlayer) { m.flee = 4; m.angry = 30; }
      MC.Sound.entity(m.type, m.hp <= 0 ? 'death' : 'hurt', m.body.x, m.body.y + 1, m.body.z);
      if (m.hp <= 0) {
        m.dead = 0.6;
        if (byPlayer) {
          for (const [id, data, a, b] of m.def.drops) {
            const n = rnd(a, b);
            if (n > 0) this.spawnItem({ id: m.burn > 0 && m.def.cooked && m.def.cooked[id] ? m.def.cooked[id] : id, data, count: n }, m.body.x, m.body.y + 0.5, m.body.z);
          }
        }
      }
      return true;
    }

    hostileCount() {
      let h = 0, a = 0;
      for (const e of this.list.values()) if (e.kind === 'mob') { if (e.def.hostile) h++; else a++; }
      return [a, h];
    }

    trySpawn() {
      const g = this.game, w = this.world, p = g.player;
      const [passive, hostile] = this.hostileCount();
      const night = g.daylight() < 0.45;
      const ang = Math.random() * Math.PI * 2, dist = 24 + Math.random() * 20;
      const x = Math.floor(p.x + Math.cos(ang) * dist), z = Math.floor(p.z + Math.sin(ang) * dist);
      if (!w.isLoaded(x, z) || !w.isLoaded(x + 1, z + 1) || !w.isLoaded(x - 1, z - 1)) return;
      const top = w.height(x, z);
      if (Math.random() < 0.5 && passive < MOB_CAP) {
        if (w.getId(x, top - 1, z) !== 2 || w.getId(x, top, z) !== 0 || w.getId(x, top + 1, z) !== 0) return;
        const type = PASSIVE[rnd(0, PASSIVE.length - 1)];
        const n = rnd(1, 3);
        for (let i = 0; i < n; i++) this.spawnMob(type, x + 0.5 + i * 0.3, top, z + 0.5);
        return;
      }
      if (hostile >= HOSTILE_CAP) return;
      // Ночью — на поверхности, в любое время — в пещерах под землёй
      let y = -1;
      if (night && w.getId(x, top, z) === 0 && w.getId(x, top + 1, z) === 0 && Blocks.list[w.getId(x, top - 1, z)].solid && !Blocks.list[w.getId(x, top - 1, z)].liquid) y = top;
      else {
        for (let t = 0; t < 6 && y < 0; t++) {
          const yy = rnd(6, Math.max(7, top - 8));
          if (w.getId(x, yy, z) === 0 && w.getId(x, yy + 1, z) === 0 && Blocks.list[w.getId(x, yy - 1, z)].opaque) y = yy;
        }
      }
      if (y < 0) return;
      this.spawnMob(HOSTILE[rnd(0, HOSTILE.length - 1)], x + 0.5, y, z + 0.5);
    }

    updateMob(m, dt) {
      const g = this.game, p = g.player, b = m.body, w = this.world;
      if (!w.isLoaded(Math.floor(b.x), Math.floor(b.z))) { this.list.delete(m.eid); return; }
      m.hurt = Math.max(0, m.hurt - dt);
      m.invuln = Math.max(0, m.invuln - dt);
      m.attackCd = Math.max(0, m.attackCd - dt);
      m.flee = Math.max(0, m.flee - dt);
      m.angry = Math.max(0, m.angry - dt);
      if (m.dead) {
        m.dead -= dt;
        if (m.dead <= 0) this.list.delete(m.eid);
        return;
      }
      const dx = p.x - b.x, dz = p.z - b.z, dy = p.y - b.y;
      const dist = Math.hypot(dx, dz, dy);
      const def = m.def;
      if (def.hostile && dist > 72) { this.list.delete(m.eid); return; }
      const input = { forward: 0, strafe: 0, jump: b.inWater || b.inLava, sneak: false, sprint: false, autoJump: true };
      const target = !g.dead && g.survival() && dist < 16;
      const aggressive = def.hostile && target && (!def.dayNeutral || g.daylight() < 0.6 || m.angry > 0);
      // Голоса существ время от времени
      m.ambient = (m.ambient === undefined ? Math.random() * 8 : m.ambient) - dt;
      if (m.ambient <= 0) {
        m.ambient = 6 + Math.random() * 10;
        if (dist < 16) MC.Sound.entity(m.type, 'ambient', b.x, b.y + 1, b.z);
      }
      if (def.creeper && target && dist < 3.2) {
        if (m.fuse === 0) MC.Sound.entity(m.type, 'fuse', b.x, b.y + 1, b.z);
        m.fuse += dt;
        b.yaw = yawTo(dx, dz);
        if (m.fuse >= 1.5) { this.explode(b.x, b.y + 0.5, b.z, 3); this.list.delete(m.eid); return; }
      } else {
        m.fuse = Math.max(0, m.fuse - dt);
        if (aggressive) {
          b.yaw = yawTo(dx, dz);
          input.forward = def.speed;
          if (def.damage && m.attackCd <= 0 && Math.hypot(dx, dz) < 1.5 && Math.abs(dy) < 1.6) {
            m.attackCd = 1;
            g.damagePlayer(def.damage, b.x, b.z, def.kill);
          }
        } else if (m.flee > 0) {
          // Направление бегства меняется раз в полсекунды, иначе модель дёргается каждый кадр
          m.fleeT = (m.fleeT || 0) - dt;
          if (m.fleeT <= 0) { m.fleeT = 0.5; m.fleeYaw = (Math.random() - 0.5) * 40; }
          b.yaw = yawTo(-dx, -dz) + m.fleeYaw;
          input.forward = Math.min(1, def.speed * 1.8);
        } else {
          m.wander -= dt;
          if (m.wander <= 0) {
            m.walking = Math.random() < 0.6;
            b.yaw = Math.random() * 360;
            m.wander = 1 + Math.random() * 4;
          }
          if (m.walking) input.forward = def.speed * 0.6;
        }
      }
      const fall = b.update(dt, input);
      if (fall > 3) this.hurtMob(m, Math.floor(fall - 3), b.x, b.z, false);
      if (b.inLava) {
        m.lava -= dt;
        if (m.lava <= 0) { m.lava = 0.5; this.hurtMob(m, 4, b.x, b.z, false); }
      }
      // Зомби горят на солнце
      if (def.burns && g.daylight() > 0.75 && !b.inWater && b.y + 1.6 >= w.height(Math.floor(b.x), Math.floor(b.z))) {
        m.burn += dt;
        if (m.burn >= 1) { m.burn = 0.01; m.invuln = 0; this.hurtMob(m, 1, b.x, b.z, false); }
      }
      if (b.y < -64) this.list.delete(m.eid);
    }

    // ---------- Динамит ----------
    primeTnt(x, y, z, fuse) {
      const eid = this.nextId++;
      this.list.set(eid, { kind: 'tnt', eid, x: x + 0.5, y, z: z + 0.5, vy: 2, fuse });
      MC.Sound.play('random.fuse', { x: x + 0.5, y: y + 0.5, z: z + 0.5 }, 1, 1);
    }

    updateTnt(e, dt) {
      e.fuse -= dt;
      e.vy -= 20 * dt;
      const ny = e.y + e.vy * dt;
      if (e.vy < 0 && this.solidAt(e.x, ny, e.z)) { e.y = Math.floor(ny) + 1; e.vy = 0; } else e.y = ny;
      if (e.fuse <= 0) {
        this.list.delete(e.eid);
        this.explode(e.x, e.y + 0.5, e.z, 4);
      }
    }

    // ---------- Взрыв ----------
    explode(x, y, z, power) {
      const w = this.world, g = this.game;
      const r = Math.ceil(power);
      MC.Sound.event('explode', x, y, z);
      for (let bx = -r; bx <= r; bx++) for (let by = -r; by <= r; by++) for (let bz = -r; bz <= r; bz++) {
        const d = Math.hypot(bx, by, bz);
        if (d > power * (0.7 + Math.random() * 0.45)) continue;
        const X = Math.floor(x) + bx, Y = Math.floor(y) + by, Z = Math.floor(z) + bz;
        const id = w.getId(X, Y, Z);
        if (!id) continue;
        const blk = Blocks.list[id];
        if (blk.hardness < 0 || blk.hardness >= 50 || blk.liquid) continue;
        const data = w.getData(X, Y, Z);
        if (id !== 46 && Math.random() < 0.3) for (const it of MC.Survival.blockDrops(id, data, 278)) this.spawnItem(it, X + 0.5, Y + 0.5, Z + 0.5);
        g.removeBlockSP(X, Y, Z, false);
      }
      const p = g.player;
      const pd = Math.hypot(p.x - x, p.y + 0.9 - y, p.z - z);
      if (pd < power * 2) {
        const impact = 1 - pd / (power * 2);
        g.damagePlayer(Math.floor((impact * impact + impact) * 3.5 * power + 1), x, z, 'Взорван');
      }
      for (const e of this.list.values()) {
        if (e.kind !== 'mob') continue;
        const ed = Math.hypot(e.body.x - x, e.body.y - y, e.body.z - z);
        if (ed < power * 2) {
          const impact = 1 - ed / (power * 2);
          e.invuln = 0;
          this.hurtMob(e, Math.floor((impact * impact + impact) * 3.5 * power + 1), x, z, false);
        }
      }
      g.ui.addChat('§7Бабах!');
    }

    // ---------- Кадр ----------
    update(dt) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        this.spawnTimer = 1.5;
        if (this.game.survival() || this.hostileCount()[0] < MOB_CAP) this.trySpawn();
      }
      for (const e of Array.from(this.list.values())) {
        if (e.kind === 'item') this.updateItem(e, dt);
        else if (e.kind === 'tnt') this.updateTnt(e, dt);
        else this.updateMob(e, dt);
      }
    }

    sceneLists() {
      const mobs = [], items = [];
      for (const e of this.list.values()) {
        if (e.kind === 'item') items.push(e);
        else if (e.kind === 'tnt') mobs.push({ eid: e.eid, type: 65, x: e.x, y: e.y, z: e.z, yaw: 0, fuse: 4 - e.fuse, hurt: 0 });
        else {
          const b = e.body;
          mobs.push({ eid: e.eid, type: e.type, x: b.x, y: b.y, z: b.z, yaw: b.yaw, walk: b.walkDist, hurt: e.hurt, fuse: e.fuse, dead: e.dead > 0 });
        }
      }
      return { mobs, items };
    }

    targets() {
      const out = [];
      for (const e of this.list.values()) {
        if (e.kind !== 'mob' || e.dead) continue;
        const look = MC.ENTITY_LOOK[e.type];
        out.push({ eid: e.eid, x: e.body.x, y: e.body.y, z: e.body.z, w: look[2][0], h: look[2][1] });
      }
      return out;
    }

    nearHostile(x, y, z, r) {
      for (const e of this.list.values()) {
        if (e.kind === 'mob' && e.def.hostile && !e.dead && Math.hypot(e.body.x - x, e.body.y - y, e.body.z - z) < r) return true;
      }
      return false;
    }

    clear() { this.list.clear(); }
  }

  Entities.TYPES = { zombie: 32, creeper: 33, spider: 35, pig: 12, cow: 11, sheep: 13, chicken: 10 };
  MC.Entities = Entities;
})();
