// Правила выживания для одиночной игры: инвентарь, инструменты, выпадение блоков, еда, крафт, переплавка
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const Blocks = MC.Blocks;

  // ---------- Инструменты: [тип, уровень, прочность, урон] ----------
  const TOOLS = {
    268: ['sword', 1, 60, 4], 269: ['shovel', 1, 60, 1], 270: ['pickaxe', 1, 60, 2], 271: ['axe', 1, 60, 3], 290: ['hoe', 1, 60, 1],
    272: ['sword', 2, 132, 5], 273: ['shovel', 2, 132, 2], 274: ['pickaxe', 2, 132, 3], 275: ['axe', 2, 132, 4], 291: ['hoe', 2, 132, 1],
    267: ['sword', 3, 251, 6], 256: ['shovel', 3, 251, 3], 257: ['pickaxe', 3, 251, 4], 258: ['axe', 3, 251, 5], 292: ['hoe', 3, 251, 1],
    276: ['sword', 4, 1562, 7], 277: ['shovel', 4, 1562, 4], 278: ['pickaxe', 4, 1562, 5], 279: ['axe', 4, 1562, 6], 293: ['hoe', 4, 1562, 1],
    283: ['sword', 1, 33, 4], 284: ['shovel', 1, 33, 1], 285: ['pickaxe', 1, 33, 2], 286: ['axe', 1, 33, 3], 294: ['hoe', 1, 33, 1],
    359: ['shears', 1, 239, 1], 259: ['flint', 0, 65, 1], 261: ['bow', 0, 385, 1]
  };

  // Минимальный уровень кирки для добычи
  const NEED_TIER = { 49: 4, 56: 3, 14: 3, 129: 3, 73: 3, 74: 3, 57: 3, 41: 3, 133: 3, 15: 2, 21: 2, 42: 2, 22: 2 };

  // ---------- Броня: id → [слот (0 шлем, 1 нагрудник, 2 поножи, 3 ботинки), очки защиты, прочность] ----------
  const ARMOR = {};
  const ARMOR_SETS = [[298, [1, 3, 2, 1], [55, 80, 75, 65]], [302, [2, 5, 4, 1], [165, 240, 225, 195]], [306, [2, 6, 5, 2], [165, 240, 225, 195]],
    [310, [3, 8, 6, 3], [363, 528, 495, 429]], [314, [2, 5, 3, 1], [77, 112, 105, 91]]];
  for (const [base, pts, dur] of ARMOR_SETS) for (let s = 0; s < 4; s++) ARMOR[base + s] = [s, pts[s], dur[s]];

  const ONE = new Set([256, 257, 258, 259, 261, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 282, 283, 284, 285, 286,
    290, 291, 292, 293, 294, 326, 327, 335, 346, 359, 459, 325, 329, 333, 342, 345, 347, 358, 395, 403, 407, 408, 416, 417, 418, 419, 444, 450]);
  for (const id of Object.keys(ARMOR)) ONE.add(+id);
  const SIXTEEN = new Set([323, 332, 344, 368, 355, 390, 384]);

  function toolInfo(id) { return TOOLS[id] || null; }
  function armorInfo(id) { return ARMOR[id] || null; }
  function maxStack(id) { return ONE.has(id) ? 1 : SIXTEEN.has(id) ? 16 : 64; }
  // Предметы с прочностью: у них data — износ, а не вариант
  function isTool(id) { return !!TOOLS[id] || !!ARMOR[id]; }
  function durabilityOf(id) { return TOOLS[id] ? TOOLS[id][2] : ARMOR[id] ? ARMOR[id][2] : 0; }
  // Очки защиты надетой брони (как в Minecraft, максимум 20)
  function armorPoints(armor) {
    let n = 0;
    for (const it of armor) if (it && ARMOR[it.id]) n += ARMOR[it.id][1];
    return Math.min(20, n);
  }

  // Урон атаки предметом в руке (сердечки x2)
  function attackDamage(id) { const t = TOOLS[id]; return t ? t[3] : 1; }

  function canHarvest(id, toolId) {
    const b = Blocks.list[id];
    if (b.hand !== false || !b.tool) return true;
    const t = TOOLS[toolId];
    if (!t || t[0] !== b.tool) return false;
    return t[1] >= (NEED_TIER[id] || 1);
  }

  // ---------- Выпадение блоков ----------
  const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));

  function blockDrops(id, data, toolId) {
    if (!canHarvest(id, toolId)) return [];
    const t = TOOLS[toolId];
    const shears = t && t[0] === 'shears';
    const it = (i, d, c) => ({ id: i, data: d, count: c });
    switch (id) {
      case 0: case 7: case 8: case 9: case 10: case 11: case 20: case 51: case 52: case 79: case 90: case 95: case 102: case 160:
        return [];
      case 1: return [it(data === 0 ? 4 : 1, data, 1)];
      case 2: case 60: case 110: case 198: case 243: return [it(3, 0, 1)];
      case 13: return Math.random() < 0.1 ? [it(318, 0, 1)] : [it(13, 0, 1)];
      case 16: return [it(263, 0, 1)];
      case 17: return [it(17, data & 3, 1)];
      case 162: return [it(162, data & 1, 1)];
      case 18: case 161: {
        if (shears) return [it(id, data & 3, 1)];
        const out = [];
        if (Math.random() < 0.05) out.push(it(6, id === 161 ? 4 + (data & 1) : data & 3, 1));
        if (id === 18 && (data & 3) === 0 && Math.random() < 0.005) out.push(it(260, 0, 1));
        return out;
      }
      case 21: return [it(351, 4, rnd(4, 8))];
      case 26: return data & 8 ? [] : [it(355, 0, 1)];
      case 31: return shears ? [it(31, data, 1)] : Math.random() < 0.125 ? [it(295, 0, 1)] : [];
      case 32: return shears ? [it(32, 0, 1)] : [it(280, 0, rnd(0, 2))].filter((x) => x.count);
      case 43: return [it(44, data & 7, 2)];
      case 44: return [it(44, data & 7, 1)];
      case 157: return [it(158, data & 7, 2)];
      case 158: return [it(158, data & 7, 1)];
      case 47: return [it(340, 0, 3)];
      case 55: return [it(331, 0, 1)];
      case 56: return [it(264, 0, 1)];
      case 59: return data >= 7 ? [it(296, 0, 1), it(295, 0, rnd(1, 3))] : [it(295, 0, 1)];
      case 62: return [it(61, 0, 1)];
      case 63: case 68: return [it(323, 0, 1)];
      case 64: return data & 8 ? [] : [it(324, 0, 1)];
      case 71: return data & 8 ? [] : [it(330, 0, 1)];
      case 73: case 74: return [it(331, 0, rnd(4, 5))];
      case 75: case 76: return [it(76, 0, 1)];
      case 78: return [it(332, 0, 1)];
      case 80: return [it(332, 0, 4)];
      case 82: return [it(337, 0, 4)];
      case 83: return [it(338, 0, 1)];
      case 89: return [it(348, 0, rnd(2, 4))];
      case 92: return [];
      case 93: case 94: return [it(356, 0, 1)];
      case 103: return [it(360, 0, rnd(3, 7))];
      case 104: case 105: return [it(id === 104 ? 361 : 362, 0, rnd(1, 3))];
      case 106: return shears ? [it(106, 0, 1)] : [];
      case 115: return [it(372, 0, data >= 3 ? rnd(2, 4) : 1)];
      case 117: return [it(379, 0, 1)];
      case 118: return [it(380, 0, 1)];
      case 124: return [it(123, 0, 1)];
      case 127: return [it(351, 3, data >= 8 ? 3 : 1)];
      case 129: return [it(388, 0, 1)];
      case 140: return [it(390, 0, 1)];
      case 141: return [it(391, 0, data >= 7 ? rnd(1, 4) : 1)];
      case 142: return [it(392, 0, data >= 7 ? rnd(1, 4) : 1)];
      case 149: case 150: return [it(404, 0, 1)];
      case 153: return [it(406, 0, 1)];
      case 175: return data & 8 ? [] : [it(175, data & 7, 1)];
      case 193: case 194: case 195: case 196: case 197: return data & 8 ? [] : [it(427 + id - 193, 0, 1)];
      case 244: return data >= 7 ? [it(457, 0, 1), it(458, 0, rnd(1, 3))] : [it(458, 0, 1)];
      default: {
        const b = Blocks.list[id];
        if (b.name.startsWith('Блок #')) return [];
        return [it(id, b.variants > 1 ? data : 0, 1)];
      }
    }
  }

  // ---------- Еда: [голод, насыщение, остаток] ----------
  const FOOD = {
    260: [4, 2.4], 297: [5, 6], 319: [3, 1.8], 320: [8, 12.8], 363: [3, 1.8], 364: [8, 12.8], 365: [2, 1.2], 366: [6, 7.2],
    349: [2, 0.4], 350: [5, 6], 391: [3, 3.6], 392: [1, 0.6], 393: [5, 6], 357: [2, 0.4], 360: [2, 1.2], 322: [4, 9.6],
    466: [4, 9.6], 423: [2, 1.2], 424: [6, 9.6], 367: [4, 0.8], 375: [2, 3.2], 282: [6, 7.2, 281], 459: [6, 7.2, 281],
    457: [1, 1.2], 400: [8, 4.8], 411: [3, 1.8], 412: [5, 6], 413: [10, 12, 281], 460: [2, 0.4], 463: [6, 9.6]
  };

  // ---------- Рецепты (как список крафта в MCPE): out [id, data, count], need [[id, data|-1, count]], table ----------
  const R = [];
  const add = (out, need, table) => R.push({ out: { id: out[0], data: out[1], count: out[2] }, need: need.map((n) => ({ id: n[0], data: n[1], count: n[2] })), table: !!table });
  for (let d = 0; d < 4; d++) add([5, d, 4], [[17, d, 1]]);
  for (let d = 0; d < 2; d++) add([5, 4 + d, 4], [[162, d, 1]]);
  add([280, 0, 4], [[5, -1, 2]]);
  add([58, 0, 1], [[5, -1, 4]]);
  add([50, 0, 4], [[263, -1, 1], [280, 0, 1]]);
  add([54, 0, 1], [[5, -1, 8]], true);
  add([61, 0, 1], [[4, 0, 8]], true);
  const MATS = [[5, -1, [268, 269, 270, 271, 290]], [4, 0, [272, 273, 274, 275, 291]], [265, 0, [267, 256, 257, 258, 292]],
    [266, 0, [283, 284, 285, 286, 294]], [264, 0, [276, 277, 278, 279, 293]]];
  for (const [m, md, ids] of MATS) {
    add([ids[2], 0, 1], [[m, md, 3], [280, 0, 2]], true);
    add([ids[3], 0, 1], [[m, md, 3], [280, 0, 2]], true);
    add([ids[1], 0, 1], [[m, md, 1], [280, 0, 2]], true);
    add([ids[0], 0, 1], [[m, md, 2], [280, 0, 1]], true);
    add([ids[4], 0, 1], [[m, md, 2], [280, 0, 2]], true);
  }
  add([65, 0, 3], [[280, 0, 7]], true);
  add([85, 0, 3], [[5, -1, 4], [280, 0, 2]], true);
  add([107, 0, 1], [[5, -1, 2], [280, 0, 4]], true);
  add([324, 0, 3], [[5, -1, 6]], true);
  add([330, 0, 3], [[265, 0, 6]], true);
  add([96, 0, 2], [[5, -1, 6]], true);
  add([355, 0, 1], [[35, -1, 3], [5, -1, 3]], true);
  add([323, 0, 3], [[5, -1, 6], [280, 0, 1]], true);
  add([281, 0, 4], [[5, -1, 3]], true);
  add([297, 0, 1], [[296, 0, 3]], true);
  add([282, 0, 1], [[39, 0, 1], [40, 0, 1], [281, 0, 1]]);
  add([35, 0, 1], [[287, 0, 4]]);
  add([98, 0, 4], [[1, 0, 4]]);
  add([24, 0, 1], [[12, 0, 4]]);
  add([45, 0, 1], [[336, 0, 4]]);
  add([80, 0, 1], [[332, 0, 4]]);
  add([82, 0, 1], [[337, 0, 4]]);
  add([89, 0, 1], [[348, 0, 4]]);
  add([44, 0, 6], [[1, 0, 3]], true);
  add([44, 3, 6], [[4, 0, 3]], true);
  add([44, 1, 6], [[24, 0, 3]], true);
  add([44, 5, 6], [[98, 0, 3]], true);
  add([44, 4, 6], [[45, 0, 3]], true);
  add([158, 0, 6], [[5, 0, 3]], true);
  add([53, 0, 4], [[5, 0, 6]], true);
  add([67, 0, 4], [[4, 0, 6]], true);
  add([108, 0, 4], [[45, 0, 6]], true);
  add([109, 0, 4], [[98, 0, 6]], true);
  add([128, 0, 4], [[24, 0, 6]], true);
  add([139, 0, 6], [[4, 0, 6]], true);
  add([46, 0, 1], [[289, 0, 5], [12, -1, 4]], true);
  add([47, 0, 1], [[5, -1, 6], [340, 0, 3]], true);
  add([340, 0, 1], [[339, 0, 3], [334, 0, 1]]);
  add([339, 0, 3], [[338, 0, 3]], true);
  add([353, 0, 1], [[338, 0, 1]]);
  add([325, 0, 1], [[265, 0, 3]], true);
  add([359, 0, 1], [[265, 0, 2]]);
  add([259, 0, 1], [[265, 0, 1], [318, 0, 1]]);
  add([261, 0, 1], [[280, 0, 3], [287, 0, 3]], true);
  add([262, 0, 4], [[318, 0, 1], [280, 0, 1], [288, 0, 1]], true);
  add([102, 0, 16], [[20, 0, 6]], true);
  add([101, 0, 16], [[265, 0, 6]], true);
  add([91, 0, 1], [[86, 0, 1], [50, 0, 1]]);
  add([103, 0, 1], [[360, 0, 9]], true);
  add([351, 15, 3], [[352, 0, 1]]);
  add([69, 0, 1], [[280, 0, 1], [4, 0, 1]]);
  add([77, 0, 1], [[1, 0, 1]]);
  add([70, 0, 1], [[1, 0, 2]]);
  add([72, 0, 1], [[5, -1, 2]]);
  add([322, 0, 1], [[266, 0, 8], [260, 0, 1]], true);
  add([357, 0, 8], [[296, 0, 2], [351, 3, 1]], true);
  add([400, 0, 1], [[86, 0, 1], [353, 0, 1], [344, 0, 1]]);
  add([346, 0, 1], [[280, 0, 3], [287, 0, 2]], true);
  add([333, 0, 1], [[5, 0, 5]], true);
  add([66, 0, 16], [[265, 0, 6], [280, 0, 1]], true);
  add([328, 0, 1], [[265, 0, 5]], true);
  add([345, 0, 1], [[265, 0, 4], [331, 0, 1]], true);
  add([347, 0, 1], [[266, 0, 4], [331, 0, 1]], true);
  add([116, 0, 1], [[340, 0, 1], [264, 0, 2], [49, 0, 4]], true);
  add([145, 0, 1], [[42, 0, 3], [265, 0, 4]], true);
  add([379, 0, 1], [[369, 0, 1], [4, 0, 3]], true);
  add([25, 0, 1], [[5, -1, 8], [331, 0, 1]], true);
  add([84, 0, 1], [[5, -1, 8], [264, 0, 1]], true);
  add([123, 0, 1], [[331, 0, 4], [89, 0, 1]], true);
  add([76, 0, 1], [[331, 0, 1], [280, 0, 1]]);
  add([298, 0, 1], [[334, 0, 5]], true);
  add([299, 0, 1], [[334, 0, 8]], true);
  add([300, 0, 1], [[334, 0, 7]], true);
  add([301, 0, 1], [[334, 0, 4]], true);
  for (const [base, mat] of [[306, 265], [310, 264], [314, 266]]) {
    add([base, 0, 1], [[mat, 0, 5]], true);
    add([base + 1, 0, 1], [[mat, 0, 8]], true);
    add([base + 2, 0, 1], [[mat, 0, 7]], true);
    add([base + 3, 0, 1], [[mat, 0, 4]], true);
  }
  const BLOCK9 = [[42, 265, 0], [41, 266, 0], [57, 264, 0], [173, 263, 0], [22, 351, 4], [152, 331, 0], [133, 388, 0], [170, 296, 0]];
  for (const [blk, item, d] of BLOCK9) {
    add([blk, 0, 1], [[item, d, 9]], true);
    add([item, d, 9], [[blk, 0, 1]]);
  }
  for (let c = 1; c < 16; c++) add([35, c, 1], [[351, 15 - c, 1], [35, 0, 1]]);

  // ---------- Формы рецептов для сетки крафта ('#'/'A' — первый ингредиент, 'B'/'C' — второй/третий, 'S' — палка) ----------
  const SHAPES = {};
  const shape = (ids, rows) => { for (const id of ids) SHAPES[id] = rows; };
  shape([280], ['#', '#']);
  shape([72, 70], ['##']);
  shape([270, 274, 257, 285, 278], ['###', ' S ', ' S ']);
  shape([271, 275, 258, 286, 279], ['##', '#S', ' S']);
  shape([269, 273, 256, 284, 277], ['#', 'S', 'S']);
  shape([268, 272, 267, 283, 276], ['#', '#', 'S']);
  shape([290, 291, 292, 294, 293], ['##', ' S', ' S']);
  shape([324, 330, 427, 428, 429, 430, 431], ['##', '##', '##']);
  shape([96, 101, 102, 139], ['###', '###']);
  shape([53, 67, 108, 109, 128], ['#  ', '## ', '###']);
  shape([298, 302, 306, 310, 314], ['###', '# #']);
  shape([299, 303, 307, 311, 315], ['# #', '###', '###']);
  shape([300, 304, 308, 312, 316], ['###', '# #', '# #']);
  shape([301, 305, 309, 313, 317], ['# #', '# #']);
  shape([58, 98, 24, 45, 80, 82, 89, 35], ['##', '##']);
  shape([54, 61], ['###', '# #', '###']);
  shape([50, 76, 91, 69], ['A', 'B']);
  shape([65], ['# #', '###', '# #']);
  shape([85], ['#S#', '#S#']);
  shape([107], ['S#S', 'S#S']);
  shape([323], ['###', '###', ' S ']);
  shape([261], [' AB', 'A B', ' AB']);
  shape([262], ['A', 'B', 'C']);
  shape([46], ['ABA', 'BAB', 'ABA']);
  shape([47], ['AAA', 'BBB', 'AAA']);
  shape([355], ['AAA', 'BBB']);
  shape([44, 158, 297, 339], ['###']);
  shape([103, 42, 41, 57, 173, 22, 152, 133, 170], ['###', '###', '###']);
  shape([66], ['A A', 'ASA', 'A A']);
  shape([328], ['A A', 'AAA']);
  shape([325], ['A A', ' A ']);
  shape([345, 347, 123], [' A ', 'ABA', ' A ']);
  shape([116], [' A ', 'BCB', 'CCC']);
  shape([145], ['AAA', ' B ', 'BBB']);
  shape([379], [' A ', 'BBB']);
  shape([333], ['# #', '###']);
  shape([357], ['ABA']);
  shape([322], ['AAA', 'ABA', 'AAA']);
  shape([281], ['# #', ' # ']);
  shape([359], [' #', '# ']);
  shape([259], ['A ', ' B']);
  shape([346], ['  S', ' SB', 'S B']);
  shape([25, 84], ['AAA', 'ABA', 'AAA']);

  function sameItem(cell, e) { return !!cell && cell.id === e.id && (e.data < 0 || cell.data === e.data); }

  function patternCell(r, ch) {
    if (ch === ' ') return null;
    if (ch === 'S') return { id: 280, data: 0 };
    const i = ch === 'B' ? 1 : ch === 'C' ? 2 : 0;
    return r.need[i] || r.need[0];
  }

  // Ищет рецепт по содержимому сетки крафта (grid — size*size ячеек по строкам)
  function matchGrid(grid, size) {
    let x0 = size, y0 = size, x1 = -1, y1 = -1, cells = 0;
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
      const c = grid[y * size + x];
      if (!c || !c.id) continue;
      cells++;
      x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y);
    }
    if (!cells) return null;
    const w = x1 - x0 + 1, h = y1 - y0 + 1;
    for (const r of R) {
      if (r.table && size < 3) continue;
      let total = 0;
      for (const n of r.need) total += n.count;
      const sh = SHAPES[r.out.id];
      if (sh && sh.join('').replace(/ /g, '').length === total) {
        if (sh.length !== h || sh[0].length !== w) continue;
        let ok = true, okMirror = true;
        for (let y = 0; y < h && (ok || okMirror); y++) for (let x = 0; x < w; x++) {
          const cell = grid[(y0 + y) * size + x0 + x];
          const want = patternCell(r, sh[y][x]), wantM = patternCell(r, sh[y][w - 1 - x]);
          const has = cell && cell.id ? cell : null;
          if ((want === null) !== (has === null) || (want && !sameItem(has, want))) ok = false;
          if ((wantM === null) !== (has === null) || (wantM && !sameItem(has, wantM))) okMirror = false;
        }
        if (ok || okMirror) return r;
      } else {
        if (total !== cells) continue;
        let ok = true;
        for (const n of r.need) {
          let k = 0;
          for (const c of grid) if (sameItem(c, n)) k++;
          if (k !== n.count) { ok = false; break; }
        }
        if (ok) return r;
      }
    }
    return null;
  }

  // Рецепт сервера (из CraftingData) по содержимому сетки: формованные сравниваются по положению, остальные — по набору
  function matchServerRecipe(recipes, grid, size) {
    let x0 = size, y0 = size, x1 = -1, y1 = -1;
    const present = [];
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
      const c = grid[y * size + x];
      if (!c || !c.id) continue;
      present.push(c);
      x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y);
    }
    if (!present.length) return null;
    const w = x1 - x0 + 1, h = y1 - y0 + 1;
    const eq = (cell, want) => (!want || !want.id ? !cell : !!cell && cell.id === want.id && (want.data < 0 || want.data === cell.data));
    for (const r of recipes) {
      if (!r.out || !r.out.id) continue;
      if (r.type === 'shaped') {
        if (r.w !== w || r.h !== h || r.w > size || r.h > size) continue;
        let ok = true, okM = true;
        for (let y = 0; y < h && (ok || okM); y++) for (let x = 0; x < w; x++) {
          const cell = grid[(y0 + y) * size + x0 + x];
          if (!eq(cell && cell.id ? cell : null, r.input[y * w + x])) ok = false;
          if (!eq(cell && cell.id ? cell : null, r.input[y * w + (w - 1 - x)])) okM = false;
        }
        if (ok || okM) return r;
      } else {
        const need = r.input.filter((i) => i && i.id);
        if (need.length !== present.length || need.length > size * size) continue;
        const left = present.slice();
        let ok = true;
        for (const n of need) {
          const k = left.findIndex((c) => eq(c, n));
          if (k < 0) { ok = false; break; }
          left.splice(k, 1);
        }
        if (ok) return r;
      }
    }
    return null;
  }

  // Забирает по одному предмету из каждой занятой ячейки; возвращает результат рецепта
  function takeGrid(grid, r) {
    for (let i = 0; i < grid.length; i++) {
      const c = grid[i];
      if (!c || !c.id) continue;
      c.count--;
      if (c.count <= 0) grid[i] = c.id === 325 && (c.data === 1 || c.data === 8 || c.data === 10) ? { id: 325, data: 0, count: 1 } : null;
    }
    return { id: r.out.id, data: r.out.data, count: r.out.count };
  }

  // ---------- Переплавка ----------
  const SMELT = [
    [4, 0, 1, 0], [12, -1, 20, 0], [15, 0, 265, 0], [14, 0, 266, 0], [17, -1, 263, 1], [162, -1, 263, 1], [337, 0, 336, 0], [82, 0, 172, 0],
    [319, 0, 320, 0], [363, 0, 364, 0], [365, 0, 366, 0], [349, 0, 350, 0], [392, 0, 393, 0], [423, 0, 424, 0], [411, 0, 412, 0], [81, 0, 351, 2],
    [87, 0, 405, 0], [56, 0, 264, 0], [16, 0, 263, 0], [129, 0, 388, 0], [21, 0, 351, 4], [73, 0, 331, 0], [153, 0, 406, 0], [98, 0, 98, 2],
    [460, 0, 463, 0], [24, 0, 179, 0]
  ].map(([i, d, o, od]) => ({ need: { id: i, data: d, count: 1 }, out: { id: o, data: od, count: 1 } }));

  function smeltResult(item) {
    if (!item || !item.id) return null;
    const e = SMELT.find((s) => s.need.id === item.id && (s.need.data < 0 || s.need.data === item.data));
    return e ? { id: e.out.id, data: e.out.data, count: 1 } : null;
  }

  // Сколько предметов переплавляет одна единица топлива
  const FUEL = { 263: 8, 173: 80, 327: 100, 17: 1.5, 162: 1.5, 5: 1.5, 280: 0.5, 6: 0.5, 158: 0.75, 85: 1.5, 107: 1.5, 54: 1.5, 58: 1.5,
    47: 1.5, 65: 1.5, 268: 1, 269: 1, 270: 1, 271: 1, 290: 1, 369: 12, 170: 4.5 };

  // Печь: {input, fuel, output, burn, burnMax, cook}; топливо горит FUEL×10 с, предмет готовится 10 с. Возвращает true, если горит
  function tickFurnace(f, dt) {
    const res = smeltResult(f.input);
    const canOut = !!res && (!f.output || (f.output.id === res.id && f.output.data === res.data && f.output.count < maxStack(res.id)));
    if (f.burn > 0) f.burn = Math.max(0, f.burn - dt);
    if (f.burn <= 0 && canOut && f.fuel && FUEL[f.fuel.id]) {
      f.burnMax = f.burn = FUEL[f.fuel.id] * 10;
      f.fuel.count--;
      if (f.fuel.count <= 0) f.fuel = f.fuel.id === 327 ? { id: 325, data: 0, count: 1 } : null;
    }
    if (f.burn > 0 && canOut) {
      f.cook += dt;
      if (f.cook >= 10) {
        f.cook = 0;
        if (f.output) f.output.count++; else f.output = res;
        f.input.count--;
        if (f.input.count <= 0) f.input = null;
      }
    } else if (f.cook > 0) {
      f.cook = Math.max(0, f.cook - dt * 2);
    }
    return f.burn > 0;
  }

  // ---------- Инвентарь из 36 ячеек (0..8 — панель быстрого доступа) ----------
  class Inventory {
    constructor(slots) {
      this.slots = new Array(36).fill(null);
      if (slots) slots.forEach((s, i) => { if (i < 36 && s && s.id && s.count > 0) this.slots[i] = { id: s.id, data: s.data || 0, count: s.count }; });
    }

    toJSON() { return this.slots.map((s) => (s ? { id: s.id, data: s.data, count: s.count } : null)); }

    // Кладёт предметы, возвращает сколько не поместилось
    add(item) {
      let left = item.count;
      const max = maxStack(item.id);
      if (max > 1) {
        for (let i = 0; i < 36 && left > 0; i++) {
          const s = this.slots[i];
          if (s && s.id === item.id && s.data === item.data && s.count < max) {
            const n = Math.min(left, max - s.count);
            s.count += n;
            left -= n;
          }
        }
      }
      for (let i = 0; i < 36 && left > 0; i++) {
        if (!this.slots[i]) {
          const n = Math.min(left, max);
          this.slots[i] = { id: item.id, data: item.data, count: n };
          left -= n;
        }
      }
      return left;
    }

    count(id, data) {
      let n = 0;
      for (const s of this.slots) if (s && s.id === id && (data < 0 || s.data === data)) n += s.count;
      return n;
    }

    remove(id, data, count) {
      let left = count;
      for (let i = 35; i >= 0 && left > 0; i--) {
        const s = this.slots[i];
        if (s && s.id === id && (data < 0 || s.data === data)) {
          const n = Math.min(left, s.count);
          s.count -= n;
          left -= n;
          if (s.count <= 0) this.slots[i] = null;
        }
      }
      return count - left;
    }

    takeFromSlot(i, count) {
      const s = this.slots[i];
      if (!s) return null;
      const n = Math.min(count, s.count);
      s.count -= n;
      if (s.count <= 0) this.slots[i] = null;
      return { id: s.id, data: s.data, count: n };
    }

    swap(a, b) { const t = this.slots[a]; this.slots[a] = this.slots[b]; this.slots[b] = t; }

    clear() { const all = this.slots.filter(Boolean); this.slots.fill(null); return all; }
  }

  function canCraft(inv, r) {
    return r.need.every((n) => inv.count(n.id, n.data) >= n.count);
  }

  function craft(inv, r) {
    if (!canCraft(inv, r)) return -1;
    for (const n of r.need) inv.remove(n.id, n.data, n.count);
    const left = inv.add({ id: r.out.id, data: r.out.data, count: r.out.count });
    return left;
  }

  MC.Survival = { Inventory, TOOLS, ARMOR, toolInfo, armorInfo, armorPoints, durabilityOf, maxStack, isTool, attackDamage, canHarvest, blockDrops, FOOD, RECIPES: R, SHAPES, matchGrid, matchServerRecipe, takeGrid, SMELT, FUEL, smeltResult, tickFurnace, canCraft, craft };
})();
