package com.mcpehtml.app.server

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.floor

// Команды сервера: /help, /tp, /time, /op, /ban, /whitelist и другие
class Commands(private val s: MineServer) {
    private class Cmd(val name: String, val usage: String, val desc: String, val op: Boolean, val run: (Player, List<String>) -> Unit)

    private val list = ArrayList<Cmd>()

    private fun add(name: String, usage: String, desc: String, op: Boolean, run: (Player, List<String>) -> Unit) {
        list.add(Cmd(name, usage, desc, op, run))
    }

    init {
        add("help", "", "Список команд", false) { p, _ ->
            p.message("§eКоманды сервера:")
            for (c in list) if (!c.op || p.op) p.message("§a/${c.name}${if (c.usage.isEmpty()) "" else " " + c.usage} §7— ${c.desc}")
        }
        add("list", "", "Кто в игре", false) { p, _ ->
            val n = s.onlineNames()
            p.message("§eВ игре ${n.size}/${s.cfg.maxPlayers}: §f${n.joinToString(", ")}")
        }
        add("spawn", "", "Телепорт на точку появления", false) { p, _ ->
            val sp = s.spawnPos()
            s.teleport(p, sp[0], sp[1], sp[2])
            p.message("§aВы на точке появления")
        }
        add("me", "<действие>", "Действие от третьего лица", false) { p, a ->
            if (a.isEmpty()) { p.message("§cИспользование: /me <действие>"); return@add }
            s.broadcastMessage("§d* ${p.name} ${a.joinToString(" ")}")
        }
        add("tell", "<игрок> <сообщение>", "Личное сообщение", false) { p, a ->
            if (a.size < 2) { p.message("§cИспользование: /tell <игрок> <сообщение>"); return@add }
            val t = s.findPlayer(a[0]) ?: run { p.message("§cИгрок ${a[0]} не в сети"); return@add }
            val msg = a.drop(1).joinToString(" ")
            t.message("§7${p.name} шепчет вам: $msg")
            p.message("§7Вы шепчете ${t.name}: $msg")
        }
        add("seed", "", "Зерно мира", false) { p, _ -> p.message("§eЗерно мира: §f${s.cfg.seed}") }
        add("tp", "<игрок> | <x> <y> <z> | <игрок> <игрок>", "Телепорт", true) { p, a ->
            when (a.size) {
                1 -> {
                    val t = s.findPlayer(a[0]) ?: run { p.message("§cИгрок ${a[0]} не в сети"); return@add }
                    s.teleport(p, t.x, t.y, t.z); p.message("§aТелепорт к ${t.name}")
                }
                2 -> {
                    val f = s.findPlayer(a[0]) ?: run { p.message("§cИгрок ${a[0]} не в сети"); return@add }
                    val t = s.findPlayer(a[1]) ?: run { p.message("§cИгрок ${a[1]} не в сети"); return@add }
                    s.teleport(f, t.x, t.y, t.z); p.message("§a${f.name} перемещён к ${t.name}")
                }
                3 -> {
                    val x = coord(a[0], p.x); val y = coord(a[1], p.y); val z = coord(a[2], p.z)
                    if (x == null || y == null || z == null || y < -64 || y > 320) { p.message("§cНеверные координаты"); return@add }
                    s.teleport(p, x, y, z); p.message("§aТелепорт на ${fmt(x)} ${fmt(y)} ${fmt(z)}")
                }
                else -> p.message("§cИспользование: /tp <игрок> или /tp <x> <y> <z>")
            }
        }
        add("setspawn", "", "Точка появления здесь", true) { p, _ ->
            s.setSpawn(floor(p.x) + 0.5, p.y, floor(p.z) + 0.5)
            p.message("§aТочка появления установлена: ${floor(p.x).toInt()} ${floor(p.y).toInt()} ${floor(p.z).toInt()}")
        }
        add("time", "<day|night|noon|midnight|число>", "Время суток", true) { p, a ->
            val v = when (a.getOrNull(0)?.lowercase()) {
                "day", "день" -> 1000
                "noon", "полдень" -> 6000
                "night", "ночь" -> 13000
                "midnight", "полночь" -> 18000
                null -> { p.message("§eВремя: ${s.time % 24000}"); return@add }
                else -> a[0].toIntOrNull()
            }
            if (v == null || v < 0) { p.message("§cИспользование: /time day|night|число"); return@add }
            s.time = v
            s.broadcast { Pk.new(Pk.SET_TIME).varint(v) }
            p.message("§aВремя установлено: $v")
        }
        add("say", "<сообщение>", "Объявление всем", true) { p, a ->
            if (a.isEmpty()) { p.message("§cИспользование: /say <сообщение>"); return@add }
            s.broadcastMessage("§d[${p.name}] ${a.joinToString(" ")}")
        }
        add("kick", "<игрок> [причина]", "Выгнать игрока", true) { p, a ->
            val t = a.getOrNull(0)?.let { s.findPlayer(it) } ?: run { p.message("§cИгрок не в сети"); return@add }
            val reason = if (a.size > 1) a.drop(1).joinToString(" ") else "Вас выгнали с сервера"
            t.disconnect(reason)
            s.broadcastMessage("§e${t.name} выгнан: $reason")
        }
        add("ban", "<игрок>", "Забанить игрока", true) { p, a ->
            val n = a.getOrNull(0) ?: run { p.message("§cИспользование: /ban <игрок>"); return@add }
            val name = s.findPlayer(n)?.name ?: n
            if (s.findPlayer(n)?.isLocal == true) { p.message("§cНельзя забанить владельца"); return@add }
            s.ban(name); s.broadcastMessage("§e$name забанен")
        }
        add("unban", "<игрок>", "Снять бан", true) { p, a ->
            val n = a.getOrNull(0) ?: run { p.message("§cИспользование: /unban <игрок>"); return@add }
            s.unban(n); p.message("§a$n разбанен")
        }
        add("op", "<игрок>", "Дать права оператора", true) { p, a ->
            val n = a.getOrNull(0) ?: run { p.message("§cИспользование: /op <игрок>"); return@add }
            val name = s.findPlayer(n)?.name ?: n
            s.setOp(name, true); p.message("§a$name теперь оператор")
            s.findPlayer(name)?.message("§aВы стали оператором сервера")
        }
        add("deop", "<игрок>", "Забрать права оператора", true) { p, a ->
            val n = a.getOrNull(0) ?: run { p.message("§cИспользование: /deop <игрок>"); return@add }
            val name = s.findPlayer(n)?.name ?: n
            s.setOp(name, false); p.message("§a$name больше не оператор")
        }
        add("build", "<игрок>", "Разрешить строить", true) { p, a ->
            val n = a.getOrNull(0) ?: run { p.message("§cИспользование: /build <игрок>"); return@add }
            val name = s.findPlayer(n)?.name ?: n
            s.setBuilder(name, true); p.message("§a$name может строить")
            s.findPlayer(name)?.message("§aВам разрешили строить")
        }
        add("unbuild", "<игрок>", "Запретить строить", true) { p, a ->
            val n = a.getOrNull(0) ?: run { p.message("§cИспользование: /unbuild <игрок>"); return@add }
            val name = s.findPlayer(n)?.name ?: n
            s.setBuilder(name, false); p.message("§a$name больше не может строить (если гостям строить нельзя)")
        }
        add("whitelist", "<on|off|add|remove|list> [игрок]", "Белый список", true) { p, a ->
            when (a.getOrNull(0)?.lowercase()) {
                "on" -> { s.setWhitelist(true); p.message("§aБелый список включён") }
                "off" -> { s.setWhitelist(false); p.message("§aБелый список выключен") }
                "add" -> { val n = a.getOrNull(1) ?: return@add p.message("§cУкажите ник"); s.allow(n, true); p.message("§a$n добавлен в белый список") }
                "remove" -> { val n = a.getOrNull(1) ?: return@add p.message("§cУкажите ник"); s.allow(n, false); p.message("§a$n убран из белого списка") }
                "list" -> p.message("§eБелый список (${if (s.cfg.whitelist) "вкл" else "выкл"}): §f${s.lists()["whitelist"]!!.joinToString(", ")}")
                else -> p.message("§cИспользование: /whitelist on|off|add|remove|list")
            }
        }
        add("save", "", "Сохранить мир", true) { p, _ -> s.saveAll(); p.message("§aМир сохранён") }
    }

    private fun coord(t: String, base: Double): Double? =
        if (t.startsWith("~")) (if (t.length == 1) 0.0 else t.substring(1).toDoubleOrNull())?.plus(base) else t.toDoubleOrNull()

    private fun fmt(v: Double) = String.format(java.util.Locale.US, "%.1f", v)

    fun run(p: Player, line: String) {
        val parts = line.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (parts.isEmpty()) return
        val name = parts[0].lowercase().removePrefix("/")
        val c = list.firstOrNull { it.name == name }
        if (c == null) { p.message("§cНеизвестная команда. Список: /help"); return }
        if (c.op && !p.op) { p.message("§cЭта команда только для операторов"); return }
        s.log("${p.name}: /$line")
        c.run(p, parts.drop(1))
    }

    // Список команд для подсказок клиента (AvailableCommandsPacket протокола 113)
    fun json(p: Player): String {
        val o = JSONObject()
        for (c in list) {
            if (c.op && !p.op) continue
            val param = JSONObject().put("name", "args").put("type", "rawtext").put("optional", true)
            val overload = JSONObject()
                .put("input", JSONObject().put("parameters", JSONArray().put(param)))
                .put("output", JSONObject())
            val ver = JSONObject()
                .put("aliases", JSONArray())
                .put("description", c.desc)
                .put("overloads", JSONObject().put("default", overload))
                .put("permission", "any")
            o.put(c.name, JSONObject().put("versions", JSONArray().put(ver)))
        }
        return o.toString()
    }
}
