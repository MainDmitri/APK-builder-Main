package com.mcpehtml.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.mcpehtml.app.server.MineServer
import com.mcpehtml.app.server.ServerConfig
import com.mcpehtml.app.server.TunnelClient
import org.json.JSONObject
import java.io.File

/**
 * Сервер Minecraft PE 1.1 в фоне: работает, пока включён, даже если игра закрыта.
 * Держит процесс через foreground-уведомление, процессор и Wi-Fi — через WakeLock и WifiLock.
 */
class MineServerService : Service() {
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            updateNotification()
            val s = server
            if (s != null && !s.running && starting.not()) { stopSelf(); return }
            handler.postDelayed(this, 5000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Сервер", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Работающий сервер Minecraft"
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIFY_ID, buildNotification("Запуск сервера…"), type)
        if (server?.running == true || starting) return START_NOT_STICKY
        val json = intent?.getStringExtra(EXTRA_CONFIG)
            ?: getSharedPreferences("game", MODE_PRIVATE).getString("server_config", null)
            ?: "{}"
        acquireLocks()
        starting = true
        lastError = null
        Thread({ launch(json) }, "mcpe-start").start()
        handler.removeCallbacks(refresh)
        handler.postDelayed(refresh, 2000)
        return START_NOT_STICKY
    }

    private fun launch(json: String) {
        try {
            val o = JSONObject(json)
            val cfg = ServerConfig.fromJson(o)
            val s = MineServer(cfg, File(filesDir, "server")) { }
            s.start()
            server = s
            val url = o.optString("tunnelUrl", "").trim()
            val key = o.optString("tunnelKey", "")
            if (url.isNotEmpty() && key.isNotEmpty()) {
                val full = if (url.startsWith("ws://") || url.startsWith("wss://")) url else "ws://$url"
                tunnel = TunnelClient(s, full, key).also { it.start() }
            }
        } catch (e: Exception) {
            lastError = if (e is java.net.BindException) "Порт занят: на телефоне уже работает другой сервер" else (e.message ?: e.toString())
            handler.post { stopSelf() }
        } finally {
            starting = false
        }
    }

    @SuppressLint("WakelockTimeout")
    private fun acquireLocks() {
        if (wake == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mcpehtml:server").also { it.setReferenceCounted(false); it.acquire() }
        }
        if (wifi == null) {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_HIGH_PERF else WifiManager.WIFI_MODE_FULL
            wifi = wm.createWifiLock(mode, "mcpehtml:server").also { it.setReferenceCounted(false); it.acquire() }
        }
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, MineServerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_server)
            .setContentTitle(server?.cfg?.name ?: "Сервер Minecraft")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, "Остановить", stop)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun updateNotification() {
        val s = server ?: return
        val n = s.onlineCount()
        val text = buildString {
            append("Игроков: $n из ${s.cfg.maxPlayers} · порт ${s.cfg.port}")
            if (s.tunnelStatus.isNotEmpty()) append(if (s.tunnelStatus.startsWith("Туннель работает")) " · туннель ✓" else " · туннель ✗")
        }
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIFY_ID, buildNotification(text))
        } catch (e: SecurityException) {
            // Уведомления запрещены: сервер работает и без них
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(refresh)
        val s = server
        val t = tunnel
        server = null
        tunnel = null
        // Остановка с сохранением мира — в отдельном потоке, чтобы не держать главный поток
        Thread({
            try { t?.stop() } catch (e: Exception) { }
            try { s?.stop() } catch (e: Exception) { }
        }, "mcpe-stop").start()
        try { wake?.release() } catch (e: Exception) { }
        try { wifi?.release() } catch (e: Exception) { }
        wake = null
        wifi = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "server"
        private const val NOTIFY_ID = 19132
        private const val ACTION_STOP = "com.mcpehtml.app.STOP_SERVER"
        private const val EXTRA_CONFIG = "config"

        @Volatile var server: MineServer? = null
            private set
        @Volatile var tunnel: TunnelClient? = null
            private set
        @Volatile var starting = false
            private set
        @Volatile var lastError: String? = null
            private set

        fun start(ctx: Context, config: String) {
            val i = Intent(ctx, MineServerService::class.java).putExtra(EXTRA_CONFIG, config)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, MineServerService::class.java))
        }
    }
}
