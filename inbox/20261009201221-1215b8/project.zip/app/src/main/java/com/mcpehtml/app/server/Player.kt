package com.mcpehtml.app.server

import org.json.JSONArray
import org.json.JSONObject

class Player(val server: MineServer, val session: RakSession, val eid: Long) {
    var name = ""
    var uuidMsb = 0L
    var uuidLsb = 0L
    var skinId = "Standard_Custom"
    var skin = ByteArray(0)
    var loggedIn = false
    var spawned = false
    var closed = false

    var x = 0.0
    var y = 0.0   // ноги
    var z = 0.0
    var yaw = 0f
    var pitch = 0f
    var moved = false
    var sneaking = false
    var sprinting = false
    var gamemode = 1
    var op = false
    var canBuild = true

    var chunkRadius = 4
    val sentChunks = HashSet<Long>()
    var radiusSet = false

    val inventory = arrayOfNulls<Item>(36)
    val armor = arrayOfNulls<Item>(4)
    var held: Item = Item.AIR
    var selected = 0

    private val out = ArrayList<ByteArray>()
    private var outSize = 0

    val isLocal get() = session.peer.ip == "127.0.0.1" || session.peer.ip == "localhost"

    fun send(w: W) {
        if (closed) return
        val b = w.toBytes()
        out.add(b)
        outSize += b.size
        if (outSize > 256 * 1024) flush()
    }

    // Все пакеты за такт уходят одним сжатым batch-пакетом
    fun flush() {
        if (out.isEmpty() || closed) return
        val w = W(outSize + out.size * 5 + 16)
        for (b in out) w.bytes(b)
        out.clear()
        outSize = 0
        val z = Zlib.deflate(w.toBytes(), 6)
        val p = ByteArray(z.size + 1)
        p[0] = RakId.GAME.toByte()
        System.arraycopy(z, 0, p, 1, z.size)
        session.sendReliable(p)
    }

    fun message(text: String) = send(Pk.new(Pk.TEXT).byte(Pk.TEXT_RAW).string(text))
    fun popup(text: String) = send(Pk.new(Pk.TEXT).byte(Pk.TEXT_TIP).string(text))

    fun flags(): Long {
        var f = (1L shl Meta.FLAG_CAN_SHOW_NAMETAG) or (1L shl Meta.FLAG_ALWAYS_SHOW_NAMETAG) or (1L shl Meta.FLAG_CAN_CLIMB) or (1L shl Meta.FLAG_BREATHING)
        if (sneaking) f = f or (1L shl Meta.FLAG_SNEAKING)
        if (sprinting) f = f or (1L shl Meta.FLAG_SPRINTING)
        return f
    }

    fun disconnect(reason: String) {
        if (closed) return
        send(Pk.new(Pk.DISCONNECT).bool(false).string(reason))
        flush()
        session.flush()
        server.removePlayer(this, reason)
        session.close(reason, true)
    }

    // ---------- Сохранение ----------
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("x", x); o.put("y", y); o.put("z", z); o.put("yaw", yaw.toDouble()); o.put("pitch", pitch.toDouble())
        val inv = JSONArray()
        for (it in inventory) inv.put(if (it == null || it.id == 0) JSONArray() else JSONArray().put(it.id).put(it.data).put(it.count))
        o.put("inv", inv)
        val arm = JSONArray()
        for (it in armor) arm.put(if (it == null || it.id == 0) JSONArray() else JSONArray().put(it.id).put(it.data).put(it.count))
        o.put("armor", arm)
        return o
    }

    fun fromJson(o: JSONObject) {
        x = o.optDouble("x", x); y = o.optDouble("y", y); z = o.optDouble("z", z)
        yaw = o.optDouble("yaw", 0.0).toFloat(); pitch = o.optDouble("pitch", 0.0).toFloat()
        val inv = o.optJSONArray("inv")
        if (inv != null) for (i in 0 until minOf(36, inv.length())) {
            val a = inv.optJSONArray(i)
            inventory[i] = if (a != null && a.length() == 3) Item(a.getInt(0), a.getInt(1), a.getInt(2)) else null
        }
        val arm = o.optJSONArray("armor")
        if (arm != null) for (i in 0 until minOf(4, arm.length())) {
            val a = arm.optJSONArray(i)
            armor[i] = if (a != null && a.length() == 3) Item(a.getInt(0), a.getInt(1), a.getInt(2)) else null
        }
    }
}
