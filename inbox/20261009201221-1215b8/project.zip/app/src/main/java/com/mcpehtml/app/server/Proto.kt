package com.mcpehtml.app.server

// Номера пакетов MCPE 1.1 (протокол 113) и запись общих структур
object Pk {
    const val PROTOCOL = 113
    const val VERSION = "1.1.5"

    const val LOGIN = 0x01
    const val PLAY_STATUS = 0x02
    const val DISCONNECT = 0x05
    const val RESOURCE_PACKS_INFO = 0x06
    const val RESOURCE_PACK_STACK = 0x07
    const val RESOURCE_PACK_CLIENT_RESPONSE = 0x08
    const val TEXT = 0x09
    const val SET_TIME = 0x0a
    const val START_GAME = 0x0b
    const val ADD_PLAYER = 0x0c
    const val REMOVE_ENTITY = 0x0e
    const val MOVE_PLAYER = 0x13
    const val REMOVE_BLOCK = 0x15
    const val UPDATE_BLOCK = 0x16
    const val LEVEL_SOUND_EVENT = 0x19
    const val LEVEL_EVENT = 0x1a
    const val ENTITY_EVENT = 0x1c
    const val UPDATE_ATTRIBUTES = 0x1e
    const val MOB_EQUIPMENT = 0x1f
    const val MOB_ARMOR_EQUIPMENT = 0x20
    const val INTERACT = 0x21
    const val USE_ITEM = 0x23
    const val PLAYER_ACTION = 0x24
    const val SET_ENTITY_DATA = 0x27
    const val SET_HEALTH = 0x2a
    const val SET_SPAWN_POSITION = 0x2b
    const val ANIMATE = 0x2c
    const val RESPAWN = 0x2d
    const val DROP_ITEM = 0x2e
    const val CONTAINER_CLOSE = 0x31
    const val CONTAINER_SET_SLOT = 0x32
    const val CONTAINER_SET_CONTENT = 0x34
    const val ADVENTURE_SETTINGS = 0x37
    const val FULL_CHUNK_DATA = 0x3a
    const val SET_DIFFICULTY = 0x3c
    const val SET_PLAYER_GAME_TYPE = 0x3e
    const val PLAYER_LIST = 0x3f
    const val REQUEST_CHUNK_RADIUS = 0x45
    const val CHUNK_RADIUS_UPDATED = 0x46
    const val AVAILABLE_COMMANDS = 0x4e
    const val COMMAND_STEP = 0x4f

    const val TEXT_RAW = 0
    const val TEXT_CHAT = 1
    const val TEXT_POPUP = 3
    const val TEXT_TIP = 4

    const val WINDOW_INVENTORY = 0
    const val WINDOW_ARMOR = 0x78
    const val WINDOW_CREATIVE = 0x79

    fun new(id: Int, size: Int = 64): W = W(size).byte(id)
}

class Item(val id: Int, val data: Int, val count: Int, val nbt: ByteArray = EMPTY) {
    companion object {
        val EMPTY = ByteArray(0)
        val AIR = Item(0, 0, 0)

        fun read(r: R): Item {
            val id = r.varint()
            if (id <= 0) return AIR
            val aux = r.varint()
            var data = aux shr 8
            if (data == 0x7fff) data = -1
            val count = aux and 0xff
            val n = r.lshort()
            val nbt = if (n > 0) r.raw(n) else EMPTY
            val a = r.varint(); for (i in 0 until a) r.string()
            val b = r.varint(); for (i in 0 until b) r.string()
            return Item(id, data, count, nbt)
        }
    }

    fun write(w: W) {
        if (id == 0) { w.varint(0); return }
        w.varint(id)
        w.varint(((if (data < 0) 0x7fff else data) and 0x7fff) shl 8 or (count and 0xff))
        w.lshort(nbt.size)
        w.raw(nbt)
        w.varint(0)
        w.varint(0)
    }

    fun toJson(): String = "[$id,$data,$count]"
}

// Метаданные игрока (флаги, ник, воздух, масштаб) — как Entity.dataProperties в Nukkit
object Meta {
    const val FLAG_SNEAKING = 1
    const val FLAG_SPRINTING = 3
    const val FLAG_INVISIBLE = 5
    const val FLAG_CAN_SHOW_NAMETAG = 14
    const val FLAG_ALWAYS_SHOW_NAMETAG = 15
    const val FLAG_CAN_CLIMB = 19
    const val FLAG_BREATHING = 33

    fun write(w: W, flags: Long, nametag: String) {
        w.uvarint(6)
        w.uvarint(0).uvarint(7).varlong(flags)
        w.uvarint(7).uvarint(1).lshort(400)
        w.uvarint(43).uvarint(1).lshort(400)
        w.uvarint(4).uvarint(4).string(nametag)
        w.uvarint(38).uvarint(7).varlong(-1)
        w.uvarint(39).uvarint(3).lfloat(1f)
    }
}

// Минимальный base64 (стандартный и url-safe): java.util.Base64 нет на Android 7
object B64 {
    private val dec = IntArray(256) { -1 }.also { t ->
        val a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
        for (i in a.indices) t[a[i].code] = i
        t['-'.code] = 62; t['_'.code] = 63
    }

    fun decode(s: String): ByteArray {
        val out = java.io.ByteArrayOutputStream(s.length * 3 / 4 + 3)
        var buf = 0; var bits = 0
        for (ch in s) {
            if (ch == '=') break
            val v = if (ch.code < 256) dec[ch.code] else -1
            if (v < 0) continue
            buf = (buf shl 6) or v; bits += 6
            if (bits >= 8) { bits -= 8; out.write((buf shr bits) and 0xff) }
        }
        return out.toByteArray()
    }
}
