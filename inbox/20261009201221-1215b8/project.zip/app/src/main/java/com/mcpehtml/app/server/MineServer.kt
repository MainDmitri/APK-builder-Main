package com.mcpehtml.app.server

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sqrt

class ServerConfig(
    var name: String = "Мой сервер",
    var port: Int = 19132,
    var maxPlayers: Int = 10,
    var seed: Int = 0,
    var guestsBuild: Boolean = true,
    var whitelist: Boolean = false,
    var viewDistance: Int = 6,
    var owner: String = ""
) {
    companion object {
        fun fromJson(o: JSONObject): ServerConfig {
            val c = ServerConfig()
            c.name = o.optString("name", c.name).take(40).ifBlank { "Мой сервер" }
            c.port = o.optInt("port", 19132).coerceIn(1024, 65535)
            c.maxPlayers = o.optInt("maxPlayers", 10).coerceIn(1, 40)
            val s = o.optString("seed", "")
            c.seed = if (s.isBlank()) 0 else s.toIntOrNull() ?: s.hashCode()
            c.guestsBuild = o.optBoolean("guestsBuild", true)
            c.whitelist = o.optBoolean("whitelist", false)
            c.viewDistance = o.optInt("viewDistance", 6).coerceIn(3, 10)
            c.owner = o.optString("owner", "").trim()
            return c
        }
    }
}

// Сервер Minecraft PE 1.1 (протокол 113) прямо в приложении: свой мир, игроки, чат, команды, творческий режим
class MineServer(val cfg: ServerConfig, val dir: File, private val logger: (String) -> Unit) : RakListener, Transport {
    @Volatile var running = false
        private set
    @Volatile var error: String? = null
        private set

    private val inbox = LinkedBlockingQueue<Pair<Peer, ByteArray>>(20000)
    private var socket: DatagramSocket? = null
    private var loop: Thread? = null
    private var reader: Thread? = null
    private val guid = java.util.Random().nextLong()
    val rak = RakServer(guid, this) { motd() }
    lateinit var world: World
        private set

    val players = LinkedHashMap<RakSession, Player>()
    private var nextEid = 1L
    var time = 0
    private var spawn = doubleArrayOf(0.5, 70.0, 0.5)
    private val ops = HashSet<String>()
    private val builders = HashSet<String>()
    private val bans = HashSet<String>()
    private val allowed = HashSet<String>()
    private val logLines = ArrayDeque<String>()
    private val commands = Commands(this)
    @Volatile var tunnelStatus = ""
    // Ники игроков в сети для других потоков (уведомление, экран сервера)
    @Volatile private var online: List<String> = emptyList()

    fun log(s: String) {
        synchronized(logLines) {
            logLines.addLast(s)
            while (logLines.size > 200) logLines.removeFirst()
        }
        logger(s)
    }

    fun logs(): List<String> = synchronized(logLines) { logLines.toList() }

    private fun motd(): String {
        val n = cfg.name.replace(";", "\\;")
        return "MCPE;$n;${Pk.PROTOCOL};${Pk.VERSION};${players.size};${cfg.maxPlayers}"
    }

    // ---------- Запуск и остановка ----------
    fun start() {
        if (running) return
        dir.mkdirs()
        loadState()
        world = World(File(dir, "world"), Generator(cfg.seed))
        if (!File(dir, "world.json").exists()) {
            spawn = world.gen.findSpawn()
            saveState()
        }
        val s = DatagramSocket(null)
        s.reuseAddress = true
        s.broadcast = true
        s.bind(InetSocketAddress(cfg.port))
        s.receiveBufferSize = 1 shl 20
        socket = s
        running = true
        error = null
        reader = Thread({ readLoop(s) }, "mcpe-udp").also { it.isDaemon = true; it.start() }
        loop = Thread({ mainLoop() }, "mcpe-server").also { it.isDaemon = true; it.start() }
        log("Сервер «${cfg.name}» запущен на порту ${cfg.port}, зерно мира ${cfg.seed}")
    }

    fun stop() {
        if (!running) return
        running = false
        loop?.join(3000)
        socket?.close()
        reader?.join(1000)
        log("Сервер остановлен")
    }

    private fun readLoop(s: DatagramSocket) {
        val buf = ByteArray(2048)
        val peers = HashMap<String, Peer>()
        while (running) {
            try {
                val p = DatagramPacket(buf, buf.size)
                s.receive(p)
                val ip = p.address.hostAddress ?: continue
                val key = "u:$ip:${p.port}"
                val peer = peers.getOrPut(key) { Peer(key, ip, p.port, this) }
                if (peers.size > 5000) peers.clear()
                inbox.offer(peer to p.data.copyOfRange(p.offset, p.offset + p.length))
            } catch (e: Exception) {
                if (running) Thread.sleep(5)
            }
        }
    }

    // Отправка через UDP-сокет сервера
    override fun send(peer: Peer, data: ByteArray) {
        try {
            socket?.send(DatagramPacket(data, data.size, InetSocketAddress(peer.ip, peer.port)))
        } catch (e: Exception) {
        }
    }

    // Датаграмма из туннеля (игроки, пришедшие через VPS)
    fun inject(peer: Peer, data: ByteArray) { inbox.offer(peer to data) }

    private fun mainLoop() {
        var nextTick = System.currentTimeMillis()
        var lastSave = nextTick
        var lastUnload = nextTick
        try {
            while (running) {
                val first = inbox.poll(5, TimeUnit.MILLISECONDS)
                if (first != null) {
                    rak.handle(first.first, first.second)
                    var n = 0
                    while (n++ < 4000) { val e = inbox.poll() ?: break; rak.handle(e.first, e.second) }
                }
                val now = System.currentTimeMillis()
                if (now >= nextTick) {
                    tick()
                    nextTick += 50
                    if (now - nextTick > 1000) nextTick = now + 50
                }
                for (p in players.values) p.flush()
                rak.tick()
                if (now - lastSave > 60000) { lastSave = now; saveAll() }
                if (now - lastUnload > 10000) {
                    lastUnload = now
                    world.unloadUnused { cx, cz -> players.values.any { abs((floor(it.x).toInt() shr 4) - cx) <= it.chunkRadius + 2 && abs((floor(it.z).toInt() shr 4) - cz) <= it.chunkRadius + 2 } }
                }
            }
        } catch (e: Throwable) {
            error = e.toString()
            log("Ошибка сервера: $e")
        } finally {
            for (p in players.values.toList()) p.disconnect("Сервер остановлен")
            for (p in players.values) p.flush()
            rak.tick()
            saveAll()
            running = false
        }
    }

    // ---------- Такт (20 в секунду) ----------
    private fun tick() {
        time++
        online = onlineNames()
        if (time % 200 == 0) broadcast { Pk.new(Pk.SET_TIME).varint(time) }
        for (p in players.values.toList()) {
            if (!p.loggedIn || !p.radiusSet || p.closed) continue
            sendChunks(p, 6)
            if (!p.spawned && spawnReady(p)) firstSpawn(p)
        }
        for (p in players.values) {
            if (!p.moved || !p.spawned) continue
            p.moved = false
            for (o in players.values) if (o !== p && o.spawned) o.send(movePacket(p, 0))
        }
    }

    // ---------- RakNet ----------
    override fun onOpen(s: RakSession) {
        if (bans.contains("ip:" + s.peer.ip)) { s.close("Бан", true); return }
        players[s] = Player(this, s, nextEid++)
    }

    override fun onGamePacket(s: RakSession, batch: ByteArray) {
        val p = players[s] ?: return
        val data = try { Zlib.inflate(batch) } catch (e: Exception) { return }
        val r = R(data)
        var count = 0
        while (!r.eof() && count++ < 512) {
            val pk = try { r.bytes() } catch (e: Exception) { return }
            if (pk.isEmpty()) continue
            try {
                handle(p, pk)
            } catch (e: Exception) {
                // Неизвестная версия пакета не должна отключать игрока
            }
            if (p.closed) return
        }
    }

    override fun onClose(s: RakSession, reason: String) {
        val p = players[s] ?: return
        removePlayer(p, reason)
    }

    fun removePlayer(p: Player, reason: String) {
        if (p.closed) return
        p.closed = true
        players.remove(p.session)
        if (p.loggedIn) {
            savePlayer(p)
            for (o in players.values) {
                if (p.spawned) o.send(Pk.new(Pk.REMOVE_ENTITY).varlong(p.eid))
                o.send(Pk.new(Pk.PLAYER_LIST).byte(1).uvarint(1).uuid(p.uuidMsb, p.uuidLsb))
            }
            if (p.spawned) broadcastMessage("§e${p.name} вышел из игры")
            log("${p.name} вышел: $reason")
        }
    }

    // ---------- Пакеты ----------
    private fun handle(p: Player, b: ByteArray) {
        val id = b[0].toInt() and 0xff
        val r = R(b, 1)
        if (!p.loggedIn && id != Pk.LOGIN && id != Pk.RESOURCE_PACK_CLIENT_RESPONSE) return
        when (id) {
            Pk.LOGIN -> login(p, r)
            Pk.RESOURCE_PACK_CLIENT_RESPONSE -> {
                when (r.byte()) {
                    3 -> p.send(Pk.new(Pk.RESOURCE_PACK_STACK).bool(false).uvarint(0).uvarint(0))
                    4 -> if (!p.loggedIn) completeLogin(p)
                    1 -> p.disconnect("Нужно принять наборы ресурсов")
                }
            }
            Pk.REQUEST_CHUNK_RADIUS -> {
                p.chunkRadius = r.varint().coerceIn(2, cfg.viewDistance)
                p.send(Pk.new(Pk.CHUNK_RADIUS_UPDATED).varint(p.chunkRadius))
                p.radiusSet = true
            }
            Pk.MOVE_PLAYER -> {
                r.varlong()
                val x = r.lfloat().toDouble(); val y = r.lfloat().toDouble(); val z = r.lfloat().toDouble()
                val pitch = r.lfloat(); r.lfloat(); val yaw = r.lfloat()
                if (!p.spawned || x.isNaN() || y.isNaN() || z.isNaN() || abs(x) > 3.0e7 || abs(z) > 3.0e7) return
                p.x = x; p.y = y - 1.62; p.z = z; p.yaw = yaw; p.pitch = pitch
                p.moved = true
            }
            Pk.TEXT -> {
                val type = r.byte()
                if (type != Pk.TEXT_CHAT) return
                r.string()
                val msg = r.string().trim().take(256)
                if (msg.isEmpty()) return
                if (msg.startsWith("/")) { commands.run(p, msg.substring(1)); return }
                val clean = if (p.op) msg else msg.replace(Regex("§."), "")
                log("<${p.name}> $clean")
                broadcast { Pk.new(Pk.TEXT).byte(Pk.TEXT_CHAT).string(p.name).string(clean) }
            }
            Pk.COMMAND_STEP -> {
                val name = r.string()
                r.string()
                r.uvarint(); r.uvarint(); r.bool(); r.varlong()
                val argsJson = r.string()
                val args = StringBuilder()
                try {
                    val o = JSONObject(argsJson)
                    if (o.has("args")) args.append(o.get("args").toString())
                    else for (k in o.keys()) { if (args.isNotEmpty()) args.append(' '); args.append(o.get(k).toString()) }
                } catch (e: Exception) {
                }
                commands.run(p, (name + " " + args).trim())
            }
            Pk.USE_ITEM -> {
                val c = r.blockCoords()
                r.uvarint()
                val face = r.varint()
                val fx = r.lfloat(); val fy = r.lfloat(); val fz = r.lfloat()
                r.lfloat(); r.lfloat(); r.lfloat()
                r.varint()
                val item = Item.read(r)
                if (face < 0 || face > 5) return
                useItem(p, c[0], c[1], c[2], face, fy, item)
            }
            Pk.REMOVE_BLOCK -> {
                val c = r.blockCoords()
                breakBlock(p, c[0], c[1], c[2])
            }
            Pk.PLAYER_ACTION -> {
                r.varlong()
                when (r.varint()) {
                    9 -> { p.sprinting = true; sendData(p) }
                    10 -> { p.sprinting = false; sendData(p) }
                    11 -> { p.sneaking = true; sendData(p) }
                    12 -> { p.sneaking = false; sendData(p) }
                    7 -> { p.send(Pk.new(Pk.RESPAWN).vec3(spawn[0].toFloat(), spawn[1].toFloat(), spawn[2].toFloat())); teleport(p, spawn[0], spawn[1], spawn[2]) }
                }
            }
            Pk.ANIMATE -> {
                val action = r.uvarint()
                if (action == 1) for (o in players.values) if (o !== p && o.spawned) o.send(Pk.new(Pk.ANIMATE).uvarint(1).varlong(p.eid))
            }
            Pk.MOB_EQUIPMENT -> {
                r.varlong()
                val item = Item.read(r)
                r.byte()
                val sel = r.byte()
                p.held = item
                p.selected = sel
                for (o in players.values) if (o !== p && o.spawned) o.send(equipmentPacket(p))
            }
            Pk.CONTAINER_SET_SLOT -> {
                val window = r.byte()
                val slot = r.varint()
                r.varint()
                val item = Item.read(r)
                if (window == Pk.WINDOW_INVENTORY && slot in 0..35) p.inventory[slot] = if (item.id == 0) null else item
                else if (window == Pk.WINDOW_ARMOR && slot in 0..3) {
                    p.armor[slot] = if (item.id == 0) null else item
                    for (o in players.values) if (o !== p && o.spawned) o.send(armorPacket(p))
                }
            }
            Pk.LEVEL_SOUND_EVENT -> {
                // Звуки действий игрока (шаги, установка блока) слышат остальные
                for (o in players.values) if (o !== p && o.spawned) o.send(W(b.size).raw(b))
            }
            Pk.CONTAINER_CLOSE -> p.send(Pk.new(Pk.CONTAINER_CLOSE).byte(r.byte()))
        }
    }

    // ---------- Вход ----------
    private fun login(p: Player, r: R) {
        val protocol = r.int()
        if (protocol != Pk.PROTOCOL) {
            p.send(Pk.new(Pk.PLAY_STATUS).int(if (protocol < Pk.PROTOCOL) 1 else 2))
            p.disconnect(if (protocol < Pk.PROTOCOL) "Нужен Minecraft PE 1.1" else "Сервер для Minecraft PE 1.1")
            return
        }
        r.byte()
        val inner = R(r.bytes())
        val chainStr = String(inner.raw(inner.lint()), Charsets.UTF_8)
        val clientJwt = String(inner.raw(inner.lint()), Charsets.UTF_8)
        var name = ""
        var identity = ""
        val chain = JSONObject(chainStr).getJSONArray("chain")
        for (i in 0 until chain.length()) {
            val body = jwtBody(chain.getString(i)) ?: continue
            val extra = body.optJSONObject("extraData") ?: continue
            name = extra.optString("displayName", name)
            identity = extra.optString("identity", identity)
        }
        val client = jwtBody(clientJwt)
        if (client != null) {
            p.skinId = client.optString("SkinId", "Standard_Custom")
            p.skin = B64.decode(client.optString("SkinData", ""))
            if (p.skin.size != 8192 && p.skin.size != 16384) p.skin = ByteArray(8192)
        }
        name = name.trim()
        if (!Regex("^[\\p{L}\\p{N}_ ]{1,16}$").matches(name)) { p.disconnect("Недопустимый ник"); return }
        p.name = name
        val lower = name.lowercase()
        try {
            val u = java.util.UUID.fromString(identity)
            p.uuidMsb = u.mostSignificantBits; p.uuidLsb = u.leastSignificantBits
        } catch (e: Exception) {
            val u = java.util.UUID.nameUUIDFromBytes(("OfflinePlayer:$name").toByteArray())
            p.uuidMsb = u.mostSignificantBits; p.uuidLsb = u.leastSignificantBits
        }
        if (bans.contains(lower)) { p.disconnect("Вы забанены на этом сервере"); return }
        p.op = p.isLocal || ops.contains(lower) || (cfg.owner.isNotEmpty() && p.isLocal && lower == cfg.owner.lowercase())
        if (cfg.whitelist && !p.op && !allowed.contains(lower)) { p.disconnect("Вас нет в белом списке сервера"); return }
        if (players.values.count { it.loggedIn } >= cfg.maxPlayers && !p.op) { p.disconnect("Сервер заполнен"); return }
        for (o in players.values.toList()) if (o !== p && o.loggedIn && o.name.equals(name, true)) o.disconnect("Вход с другого устройства")
        p.send(Pk.new(Pk.PLAY_STATUS).int(0))
        p.send(Pk.new(Pk.RESOURCE_PACKS_INFO).bool(false).lshort(0).lshort(0))
    }

    private fun jwtBody(jwt: String): JSONObject? {
        val parts = jwt.split('.')
        if (parts.size < 2) return null
        return try { JSONObject(String(B64.decode(parts[1]), Charsets.UTF_8)) } catch (e: Exception) { null }
    }

    private fun completeLogin(p: Player) {
        val lower = p.name.lowercase()
        p.canBuild = cfg.guestsBuild || p.op || builders.contains(lower)
        p.gamemode = if (p.canBuild) 1 else 2
        p.x = spawn[0]; p.y = spawn[1]; p.z = spawn[2]
        val f = File(dir, "players/$lower.json")
        if (f.exists()) try { p.fromJson(JSONObject(f.readText())) } catch (e: Exception) { }
        world.chunk(floor(p.x).toInt() shr 4, floor(p.z).toInt() shr 4)
        p.loggedIn = true

        val sg = Pk.new(Pk.START_GAME, 256)
        sg.varlong(p.eid).varlong(p.eid).varint(p.gamemode)
        sg.vec3(p.x.toFloat(), p.y.toFloat(), p.z.toFloat()).lfloat(p.yaw).lfloat(p.pitch)
        sg.varint(cfg.seed).varint(0).varint(1).varint(p.gamemode).varint(1)
        sg.blockCoords(floor(spawn[0]).toInt(), floor(spawn[1]).toInt(), floor(spawn[2]).toInt())
        sg.bool(true).varint(-1).bool(false).lfloat(0f).lfloat(0f).bool(true).bool(false)
        sg.uvarint(0).string("").string(cfg.name).string("").bool(false).llong(time.toLong())
        p.send(sg)
        p.send(Pk.new(Pk.SET_TIME).varint(time))
        sendAttributes(p)
        p.send(dataPacket(p))
        p.send(Pk.new(Pk.SET_SPAWN_POSITION).varint(1).blockCoords(floor(spawn[0]).toInt(), floor(spawn[1]).toInt(), floor(spawn[2]).toInt()).bool(false))
        p.send(Pk.new(Pk.SET_DIFFICULTY).uvarint(1))
        sendAdventure(p)
        val cr = Pk.new(Pk.CONTAINER_SET_CONTENT, 8192).uvarint(Pk.WINDOW_CREATIVE).varlong(p.eid)
        if (p.gamemode == 1) {
            cr.uvarint(Blocks.creative.size)
            for (it in Blocks.creative) Item(it[0], it[1], 1).write(cr)
        } else cr.uvarint(0)
        cr.uvarint(0)
        p.send(cr)
        sendInventory(p)
        p.send(Pk.new(Pk.AVAILABLE_COMMANDS, 4096).string(commands.json(p)).string(""))
        val pl = Pk.new(Pk.PLAYER_LIST, 20000).byte(0)
        val listed = players.values.filter { it.loggedIn }
        pl.uvarint(listed.size)
        for (o in listed) pl.uuid(o.uuidMsb, o.uuidLsb).varlong(o.eid).string(o.name).string(o.skinId).bytes(o.skin)
        p.send(pl)
        for (o in players.values) if (o !== p && o.loggedIn) {
            o.send(Pk.new(Pk.PLAYER_LIST, 20000).byte(0).uvarint(1).uuid(p.uuidMsb, p.uuidLsb).varlong(p.eid).string(p.name).string(p.skinId).bytes(p.skin))
        }
        log("${p.name} подключился (${p.session.peer.ip})" + if (p.op) " — оператор" else "")
    }

    private fun sendAttributes(p: Player) {
        val w = Pk.new(Pk.UPDATE_ATTRIBUTES, 256).varlong(p.eid).uvarint(6)
        fun a(min: Float, max: Float, v: Float, def: Float, n: String) { w.lfloat(min).lfloat(max).lfloat(v).lfloat(def).string(n) }
        a(0f, 20f, 20f, 20f, "minecraft:health")
        a(0f, 20f, 20f, 20f, "minecraft:player.hunger")
        a(0f, 20f, 20f, 20f, "minecraft:player.saturation")
        a(0f, Float.MAX_VALUE, 0.1f, 0.1f, "minecraft:movement")
        a(0f, 24791f, 0f, 0f, "minecraft:player.level")
        a(0f, 1f, 0f, 0f, "minecraft:player.experience")
        p.send(w)
        p.send(Pk.new(Pk.SET_HEALTH).uvarint(20))
    }

    fun sendAdventure(p: Player) {
        var flags = 1 shl 5
        if (p.gamemode == 2) flags = flags or 1
        if (p.gamemode == 1) flags = flags or (1 shl 6)
        p.send(Pk.new(Pk.ADVENTURE_SETTINGS).uvarint(flags).uvarint(if (p.op) 1 else 0))
    }

    private fun sendInventory(p: Player) {
        val w = Pk.new(Pk.CONTAINER_SET_CONTENT, 1024).uvarint(Pk.WINDOW_INVENTORY).varlong(p.eid).uvarint(36)
        for (it in p.inventory) (it ?: Item.AIR).write(w)
        w.uvarint(9)
        for (i in 0 until 9) w.varint(i + 9)
        p.send(w)
        val a = Pk.new(Pk.CONTAINER_SET_CONTENT, 128).uvarint(Pk.WINDOW_ARMOR).varlong(p.eid).uvarint(4)
        for (it in p.armor) (it ?: Item.AIR).write(a)
        a.uvarint(0)
        p.send(a)
    }

    private fun dataPacket(p: Player): W {
        val w = Pk.new(Pk.SET_ENTITY_DATA, 96).varlong(p.eid)
        Meta.write(w, p.flags(), p.name)
        return w
    }

    private fun sendData(p: Player) {
        val pk = dataPacket(p).toBytes()
        for (o in players.values) if (o.spawned) o.send(W(pk.size).raw(pk))
    }

    // ---------- Чанки ----------
    private fun ck(cx: Int, cz: Int) = (cx.toLong() shl 32) or (cz.toLong() and 0xffffffffL)

    private fun sendChunks(p: Player, budget: Int) {
        val pcx = floor(p.x).toInt() shr 4
        val pcz = floor(p.z).toInt() shr 4
        val r = p.chunkRadius
        // Забываем далёкие чанки, чтобы при возвращении прислать их заново
        p.sentChunks.removeIf { k ->
            val cx = (k shr 32).toInt(); val cz = k.toInt()
            abs(cx - pcx) > r + 1 || abs(cz - pcz) > r + 1
        }
        var sent = 0
        for (d in 0..r) {
            for (dx in -d..d) for (dz in -d..d) {
                if (maxOf(abs(dx), abs(dz)) != d || dx * dx + dz * dz > r * r + r) continue
                val cx = pcx + dx; val cz = pcz + dz
                val k = ck(cx, cz)
                if (p.sentChunks.contains(k)) continue
                val c = world.chunk(cx, cz)
                val data = c.network { x, z -> world.gen.mcpeBiome(x, z) }
                p.send(Pk.new(Pk.FULL_CHUNK_DATA, data.size + 16).varint(cx).varint(cz).bytes(data))
                p.sentChunks.add(k)
                if (++sent >= budget) return
            }
        }
    }

    private fun spawnReady(p: Player): Boolean {
        val pcx = floor(p.x).toInt() shr 4
        val pcz = floor(p.z).toInt() shr 4
        for (dx in -2..2) for (dz in -2..2) if (!p.sentChunks.contains(ck(pcx + dx, pcz + dz))) return false
        return true
    }

    private fun firstSpawn(p: Player) {
        p.spawned = true
        p.send(Pk.new(Pk.RESPAWN).vec3(p.x.toFloat(), p.y.toFloat(), p.z.toFloat()))
        p.send(Pk.new(Pk.PLAY_STATUS).int(3))
        p.send(movePacket(p, 1))
        for (o in players.values) {
            if (o === p || !o.spawned) continue
            p.send(addPlayerPacket(o)); p.send(armorPacket(o))
            o.send(addPlayerPacket(p)); o.send(armorPacket(p))
        }
        broadcastMessage("§e${p.name} зашёл в игру")
        if (!p.canBuild) p.message("§7Строить могут только игроки, которым разрешил владелец сервера")
        p.message("§aДобро пожаловать на «${cfg.name}»! Команды: /help")
    }

    private fun addPlayerPacket(o: Player): W {
        val w = Pk.new(Pk.ADD_PLAYER, 256)
        w.uuid(o.uuidMsb, o.uuidLsb).string(o.name).varlong(o.eid).varlong(o.eid)
        w.vec3(o.x.toFloat(), o.y.toFloat(), o.z.toFloat()).vec3(0f, 0f, 0f).lfloat(o.pitch).lfloat(o.yaw).lfloat(o.yaw)
        o.held.write(w)
        Meta.write(w, o.flags(), o.name)
        return w
    }

    private fun equipmentPacket(o: Player): W {
        val w = Pk.new(Pk.MOB_EQUIPMENT).varlong(o.eid)
        o.held.write(w)
        return w.byte(o.selected + 9).byte(o.selected).byte(0)
    }

    private fun armorPacket(o: Player): W {
        val w = Pk.new(Pk.MOB_ARMOR_EQUIPMENT).varlong(o.eid)
        for (it in o.armor) (it ?: Item.AIR).write(w)
        return w
    }

    fun movePacket(p: Player, mode: Int): W =
        Pk.new(Pk.MOVE_PLAYER).varlong(p.eid).vec3(p.x.toFloat(), (p.y + 1.62).toFloat(), p.z.toFloat())
            .lfloat(p.pitch).lfloat(p.yaw).lfloat(p.yaw).byte(mode).bool(true).varlong(0)

    fun teleport(p: Player, x: Double, y: Double, z: Double) {
        p.x = x; p.y = y; p.z = z
        p.send(movePacket(p, 1))
        for (o in players.values) if (o !== p && o.spawned) o.send(movePacket(p, 0))
    }

    // ---------- Блоки ----------
    private fun inReach(p: Player, x: Int, y: Int, z: Int): Boolean {
        val dx = x + 0.5 - p.x; val dy = y + 0.5 - (p.y + 1.62); val dz = z + 0.5 - p.z
        return sqrt(dx * dx + dy * dy + dz * dz) <= 14.0
    }

    private fun sendBlock(p: Player, x: Int, y: Int, z: Int) {
        if (y < 0 || y > 255) return
        p.send(Pk.new(Pk.UPDATE_BLOCK).blockCoords(x, y, z).uvarint(world.getId(x, y, z)).uvarint((0xb shl 4) or world.getData(x, y, z)))
    }

    fun setBlock(x: Int, y: Int, z: Int, id: Int, data: Int) {
        if (y < 0 || y > 255) return
        world.setBlock(x, y, z, id, data)
        val k = ck(x shr 4, z shr 4)
        val pk = Pk.new(Pk.UPDATE_BLOCK).blockCoords(x, y, z).uvarint(id).uvarint((0xb shl 4) or (data and 15)).toBytes()
        for (o in players.values) if (o.loggedIn && o.sentChunks.contains(k)) o.send(W(pk.size).raw(pk))
    }

    private fun useItem(p: Player, x: Int, y: Int, z: Int, face: Int, fy: Float, item: Item) {
        if (!p.spawned || y < 0 || y > 255) return
        val clicked = world.getId(x, y, z)
        val cdata = world.getData(x, y, z)
        if (!p.sneaking && Place.toggle(this, x, y, z, clicked, cdata)) return
        if (!p.canBuild || p.gamemode != 1) { revert(p, x, y, z, face); if (!p.canBuild) p.popup("§cВам нельзя строить на этом сервере"); return }
        if (!inReach(p, x, y, z)) { revert(p, x, y, z, face); return }
        if (!Place.place(this, p, x, y, z, face, fy, clicked, cdata, item)) revert(p, x, y, z, face)
    }

    private fun revert(p: Player, x: Int, y: Int, z: Int, face: Int) {
        sendBlock(p, x, y, z)
        val d = Place.FACE[face]
        sendBlock(p, x + d[0], y + d[1], z + d[2])
        sendBlock(p, x + d[0], y + d[1] + 1, z + d[2])
    }

    private fun breakBlock(p: Player, x: Int, y: Int, z: Int) {
        if (!p.spawned || y < 0 || y > 255) return
        if (!p.canBuild || p.gamemode != 1 || !inReach(p, x, y, z)) {
            sendBlock(p, x, y, z); sendBlock(p, x, y + 1, z); sendBlock(p, x, y - 1, z)
            if (!p.canBuild) p.popup("§cВам нельзя ломать блоки на этом сервере")
            return
        }
        val id = world.getId(x, y, z)
        val data = world.getData(x, y, z)
        if (id == 0) return
        Place.removeWithPartner(this, x, y, z, id, data)
        val ev = Pk.new(Pk.LEVEL_EVENT).varint(2001).vec3(x + 0.5f, y + 0.5f, z + 0.5f).varint(id or (data shl 8)).toBytes()
        for (o in players.values) if (o !== p && o.spawned) o.send(W(ev.size).raw(ev))
    }

    // ---------- Чат и рассылка ----------
    fun broadcast(make: () -> W) {
        val pk = make().toBytes()
        for (o in players.values) if (o.loggedIn) o.send(W(pk.size).raw(pk))
    }

    fun broadcastMessage(text: String) {
        log(text.replace(Regex("§."), ""))
        broadcast { Pk.new(Pk.TEXT).byte(Pk.TEXT_RAW).string(text) }
    }

    fun findPlayer(name: String): Player? {
        val n = name.lowercase()
        return players.values.firstOrNull { it.loggedIn && it.name.lowercase() == n }
            ?: players.values.firstOrNull { it.loggedIn && it.name.lowercase().startsWith(n) }
    }

    fun onlineNames(): List<String> = players.values.filter { it.loggedIn }.map { it.name }

    fun onlineCount() = online.size

    // ---------- Права ----------
    fun setOp(name: String, v: Boolean) { if (v) ops.add(name.lowercase()) else ops.remove(name.lowercase()); saveState(); findPlayer(name)?.let { it.op = v || it.isLocal; refreshBuild(it) } }
    fun setBuilder(name: String, v: Boolean) { if (v) builders.add(name.lowercase()) else builders.remove(name.lowercase()); saveState(); findPlayer(name)?.let { refreshBuild(it) } }
    fun ban(name: String) { bans.add(name.lowercase()); saveState(); findPlayer(name)?.disconnect("Вы забанены на этом сервере") }
    fun unban(name: String) { bans.remove(name.lowercase()); saveState() }
    fun allow(name: String, v: Boolean) { if (v) allowed.add(name.lowercase()) else allowed.remove(name.lowercase()); saveState() }
    fun setWhitelist(v: Boolean) { cfg.whitelist = v; saveState() }
    fun setSpawn(x: Double, y: Double, z: Double) { spawn = doubleArrayOf(x, y, z); saveState() }
    fun spawnPos() = spawn
    fun lists() = mapOf("ops" to ops.toList(), "builders" to builders.toList(), "bans" to bans.toList(), "whitelist" to allowed.toList())

    private fun refreshBuild(p: Player) {
        p.canBuild = cfg.guestsBuild || p.op || builders.contains(p.name.lowercase())
        val gm = if (p.canBuild) 1 else 2
        if (gm != p.gamemode) {
            p.gamemode = gm
            p.send(Pk.new(Pk.SET_PLAYER_GAME_TYPE).varint(gm))
            if (gm == 1) {
                val cr = Pk.new(Pk.CONTAINER_SET_CONTENT, 8192).uvarint(Pk.WINDOW_CREATIVE).varlong(p.eid).uvarint(Blocks.creative.size)
                for (it in Blocks.creative) Item(it[0], it[1], 1).write(cr)
                cr.uvarint(0)
                p.send(cr)
            }
        }
        sendAdventure(p)
        p.send(Pk.new(Pk.AVAILABLE_COMMANDS, 4096).string(commands.json(p)).string(""))
    }

    // ---------- Сохранение ----------
    private fun loadState() {
        val f = File(dir, "world.json")
        if (f.exists()) try {
            val o = JSONObject(f.readText())
            if (o.has("seed")) cfg.seed = o.getInt("seed")
            time = o.optInt("time", 0)
            val s = o.optJSONArray("spawn")
            if (s != null && s.length() == 3) spawn = doubleArrayOf(s.getDouble(0), s.getDouble(1), s.getDouble(2))
            fun list(n: String, set: HashSet<String>) { val a = o.optJSONArray(n) ?: return; for (i in 0 until a.length()) set.add(a.getString(i)) }
            list("ops", ops); list("builders", builders); list("bans", bans); list("whitelist", allowed)
        } catch (e: Exception) {
            log("Не удалось прочитать world.json: $e")
        }
    }

    private fun saveState() {
        val o = JSONObject()
        o.put("seed", cfg.seed)
        o.put("time", time)
        o.put("spawn", JSONArray().put(spawn[0]).put(spawn[1]).put(spawn[2]))
        o.put("ops", JSONArray(ops.toList())); o.put("builders", JSONArray(builders.toList()))
        o.put("bans", JSONArray(bans.toList())); o.put("whitelist", JSONArray(allowed.toList()))
        dir.mkdirs()
        File(dir, "world.json").writeText(o.toString(2))
    }

    private fun savePlayer(p: Player) {
        if (!p.loggedIn) return
        val d = File(dir, "players").also { it.mkdirs() }
        try { File(d, p.name.lowercase() + ".json").writeText(p.toJson().toString()) } catch (e: Exception) { }
    }

    fun saveAll() {
        try {
            if (::world.isInitialized) world.save(true)
            saveState()
            for (p in players.values) savePlayer(p)
        } catch (e: Exception) {
            log("Ошибка сохранения: $e")
        }
    }

    fun status(): JSONObject {
        val o = JSONObject()
        o.put("running", running)
        o.put("name", cfg.name)
        o.put("port", cfg.port)
        o.put("max", cfg.maxPlayers)
        o.put("players", JSONArray(online))
        o.put("chunks", if (::world.isInitialized) world.loaded() else 0)
        o.put("tunnel", tunnelStatus)
        if (error != null) o.put("error", error)
        return o
    }
}
