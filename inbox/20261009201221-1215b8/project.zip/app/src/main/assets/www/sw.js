// Офлайн-кэш файлов игры (работает при открытии через http/https)
const CACHE = 'mcpe-html-v31';
const FILES = [
  './', 'index.html', 'manifest.webmanifest', 'css/style.css', 'icons/icon-192.png', 'icons/icon-512.png',
  'js/assets.js', 'js/net/binary.js', 'js/net/transport.js', 'js/net/zlib.js', 'js/net/raknet.js', 'js/net/mcpe.js', 'js/lang.js',
  'js/blocks.js', 'js/items.js', 'js/noise.js', 'js/world.js', 'js/mesher.js', 'js/skin.js', 'js/sound.js', 'js/sounds-data.js', 'js/packshaders.js', 'js/particles.js', 'js/renderer.js',
  'js/player.js', 'js/storage.js', 'js/input.js', 'js/ui.js', 'js/survival.js',
  'js/inventory.js', 'js/packs.js', 'js/gamefolder.js', 'js/mobs.js', 'js/redstone.js', 'js/scripts.js', 'js/building.js', 'js/blockstates.js', 'js/schematics.js', 'js/structures.js', 'js/pvp.js', 'js/game.js', 'js/main.js'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

// Сначала сеть (чтобы обновления подхватывались), при отсутствии сети — кэш
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET' || new URL(e.request.url).origin !== location.origin) return;
  e.respondWith(fetch(e.request).then((res) => {
    if (res.ok) {
      const copy = res.clone();
      caches.open(CACHE).then((c) => c.put(e.request, copy));
    }
    return res;
  }).catch(() => caches.match(e.request)));
});
