// Папка игры в хранилище устройства: паки (.mcpack/.zip), скрипты (.js), скины (.png) и схемы (.schematic).
// В APK — папка, выбранная через системный диалог (Storage Access Framework, мост AndroidStorage),
// в браузере на компьютере — File System Access API (Chrome/Edge). Новые файлы импортируются
// при запуске игры и по кнопке «Обновить»; открытый в проводнике .mcpack импортируется сразу.
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const IMPORTED_KEY = 'folder-imported';
  const HANDLE_KEY = 'folder-handle';

  const android = () => !!(window.AndroidStorage && typeof window.AndroidStorage.list === 'function');
  const fsApi = () => typeof window.showDirectoryPicker === 'function';

  let pickResolve = null;
  let skins = [];

  function kind(name) {
    const n = name.toLowerCase();
    if (n.endsWith('.mcpack') || n.endsWith('.zip')) return 'pack';
    if (n.endsWith('.js')) return 'script';
    if (n.endsWith('.png')) return 'skin';
    if (n.endsWith('.schematic')) return 'schematic';
    return null;
  }

  function b64ToBytes(b64) {
    const bin = atob(b64);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  // ---------- Доступ к папке ----------
  async function browserHandle(ask) {
    let h = null;
    try { h = await MC.Storage.kv.get(HANDLE_KEY); } catch (e) { h = null; }
    if (!h) return null;
    let perm = await h.queryPermission({ mode: 'read' });
    if (perm !== 'granted' && ask) perm = await h.requestPermission({ mode: 'read' });
    return perm === 'granted' ? h : null;
  }

  function available() { return android() || fsApi(); }

  async function name() {
    if (android()) return window.AndroidStorage.folderName() || '';
    if (fsApi()) { try { const h = await MC.Storage.kv.get(HANDLE_KEY); return h ? h.name : ''; } catch (e) { return ''; } }
    return '';
  }

  async function pick() {
    if (android()) {
      return new Promise((resolve) => { pickResolve = resolve; window.AndroidStorage.pickFolder(); });
    }
    if (!fsApi()) throw new Error('Этот браузер не умеет открывать папки; используйте APK или Chrome на компьютере');
    const h = await window.showDirectoryPicker({ id: 'minecraft-html', mode: 'read' });
    await MC.Storage.kv.put(HANDLE_KEY, h);
    return true;
  }

  // Вызывается из MainActivity после выбора папки
  function onPicked(ok) {
    if (pickResolve) { const r = pickResolve; pickResolve = null; r(!!ok); }
  }

  // Список файлов: корень папки и подпапки packs, scripts, skins
  async function listFiles(ask) {
    if (android()) {
      const raw = window.AndroidStorage.list();
      if (!raw) return [];
      return JSON.parse(raw).map((f) => ({ id: f.id, name: f.name, dir: f.dir || '', size: f.size, modified: f.modified }));
    }
    const h = fsApi() ? await browserHandle(ask) : null;
    if (!h) return [];
    const out = [];
    const walk = async (dir, prefix, depth) => {
      for await (const [n, entry] of dir.entries()) {
        if (entry.kind === 'directory') { if (depth === 0) await walk(entry, n, 1); continue; }
        if (!kind(n)) continue;
        const f = await entry.getFile();
        out.push({ handle: entry, name: n, dir: prefix, size: f.size, modified: f.lastModified });
      }
    };
    await walk(h, '', 0);
    return out;
  }

  async function readFile(entry) {
    if (entry.handle) return entry.handle.getFile();
    const b64 = window.AndroidStorage.read(entry.id);
    if (!b64) throw new Error('Не удалось прочитать ' + entry.name);
    return new File([b64ToBytes(b64)], entry.name);
  }

  // ---------- Импорт ----------
  // Импортирует новые и изменённые файлы. Возвращает сводку для показа игроку
  async function sync(ask) {
    const res = { packs: 0, scripts: 0, skins: 0, schematics: 0, errors: [], found: 0 };
    if (!available()) return res;
    let files;
    try { files = await listFiles(ask); } catch (e) { res.errors.push(e.message); return res; }
    res.found = files.length;
    let done = {};
    try { done = (await MC.Storage.kv.get(IMPORTED_KEY)) || {}; } catch (e) { done = {}; }
    skins = [];
    for (const f of files) {
      const k = kind(f.name);
      if (!k) continue;
      if (k === 'skin') { skins.push(f); continue; }
      const key = f.dir + '/' + f.name + ':' + f.size + ':' + f.modified;
      if (done[key]) continue;
      try {
        const file = await readFile(f);
        if (k === 'pack') { await MC.Packs.addFile(file); res.packs++; }
        else if (k === 'schematic') { await MC.Schematics.addFile(file); res.schematics++; }
        else { await MC.Scripts.addFile(file); res.scripts++; }
        done[key] = Date.now();
      } catch (e) {
        res.errors.push(f.name + ': ' + e.message);
        done[key] = Date.now();
      }
    }
    res.skins = skins.length;
    try { await MC.Storage.kv.put(IMPORTED_KEY, done); } catch (e) { console.warn('Список импортированных файлов не сохранён', e); }
    return res;
  }

  function summary(r) {
    const parts = [];
    if (r.packs) parts.push('паков: ' + r.packs);
    if (r.scripts) parts.push('скриптов: ' + r.scripts);
    if (r.schematics) parts.push('схем: ' + r.schematics);
    let s = parts.length ? 'Добавлено ' + parts.join(', ') : 'Новых паков, скриптов и схем нет';
    s += '. Скинов в папке: ' + r.skins + '.';
    if (r.errors.length) s += ' Ошибки: ' + r.errors.join('; ');
    return s;
  }

  // Файл, открытый в проводнике через «Открыть с помощью» / «Поделиться» (только APK)
  async function takePending() {
    if (!window.AndroidStorage || typeof window.AndroidStorage.takePending !== 'function') return null;
    const raw = window.AndroidStorage.takePending();
    if (!raw) return null;
    const p = JSON.parse(raw);
    const file = new File([b64ToBytes(p.data)], p.name || 'pack.mcpack');
    const k = kind(file.name) || 'pack';
    if (k === 'script') { await MC.Scripts.addFile(file); return { kind: 'script', name: file.name }; }
    if (k === 'schematic') { const sc = await MC.Schematics.addFile(file); return { kind: 'schematic', name: sc.name }; }
    const rec = await MC.Packs.addFile(file);
    return { kind: 'pack', name: rec.name, shaders: rec.shaders };
  }

  // Вызывается из MainActivity, когда файл открыт при уже запущенной игре
  async function onIncoming() {
    try {
      const r = await takePending();
      if (!r || !MC.App || !MC.App.ui) return;
      if (r.kind === 'pack' && r.shaders) { MC.App.settings.shaders = 'pack'; MC.Storage.saveSettings(MC.App.settings); }
      const msg = r.kind === 'schematic' ? 'Схема «' + r.name + '» добавлена: Строительство (⚒ / V) → Схемы'
        : (r.kind === 'pack' ? 'Пак «' + r.name + '» добавлен' : 'Скрипт ' + r.name + ' добавлен') + '. Перезапустите игру, чтобы применить.';
      if (MC.App.game && MC.App.ui.addChat) MC.App.ui.addChat('§a' + msg); else alert(msg);
    } catch (e) {
      alert('Файл не импортирован: ' + e.message);
    }
  }

  MC.GameFolder = { available, android, name, pick, onPicked, sync, summary, readFile, takePending, onIncoming, get skins() { return skins; } };
})();
