// Игровая сессия: одиночный мир (выживание или творческий режим, сохранение в IndexedDB) или сервер MCPE 1.1.x
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const Blocks = MC.Blocks;
  const ACT = MC.PLAYER_ACTION;
  const EYE = MC.PLAYER_EYE;

  // Блоки, по которым клик открывает интерфейс или меняет состояние: их обрабатывает сервер
  const INTERACTIVE = new Set([23, 25, 26, 54, 58, 61, 62, 64, 69, 71, 77, 84, 92, 93, 94, 96, 107, 116, 117, 118, 125, 130, 138, 143, 145, 146,
    149, 150, 151, 154, 167, 178, 183, 184, 185, 186, 187, 193, 194, 195, 196, 197, 205, 218]);
  const DOORS = new Set([64, 193, 194, 195, 196, 197]);
  const GATES = new Set([107, 183, 184, 185, 186, 187]);
  const FACE_DIR = [[0, -1, 0], [0, 1, 0], [0, 0, -1], [0, 0, 1], [-1, 0, 0], [1, 0, 0]];

  function daylightAt(time) {
    const f = (((time % 24000) + 24000) % 24000) / 24000;
    let a = f - 0.25;
    if (a < 0) a += 1;
    const dark = Math.max(0, Math.min(1, 1 - (Math.cos(a * Math.PI * 2) * 2 + 0.5)));
    return 0.2 + 0.8 * (1 - dark);
  }

  // Направление взгляда по горизонтали: 0 юг (+z), 1 запад (-x), 2 север (-z), 3 восток (+x)
  function yawDir(yaw) { return Math.floor((((yaw % 360) + 360) % 360) / 90 + 0.5) & 3; }

  class Game {
    constructor(app, mode, opts) {
      this.app = app;
      this.mode = mode;
      this.opts = opts;
      this.world = new MC.World();
      this.player = new MC.Player(this.world);
      this.dirty = new Set();
      this.world.onSectionDirty((cx, sy, cz) => this.dirty.add(cx + ',' + sy + ',' + cz));
      this.time = 6000;
      this.selected = 0;
      this.gamemode = 1;
      this.health = 20;
      this.food = 20;
      this.dead = false;
      this.ready = false;
      this.stopped = false;
      this.immutable = false;
      this.entities = new Map();
      this.playerInfo = new Map();
      this.inv = [];
      this.hotbarMap = [0, 1, 2, 3, 4, 5, 6, 7, 8];
      this.creativeItems = null;
      this.breaking = null;
      this.useCooldown = 0;
      this.attackCooldown = 0;
      this.lastMoveSent = 0;
      this.lastSent = null;
      this.lastJumpTap = 0;
      this.flyShown = null;
      this.lastItemKey = '';
      this.fps = 0;
      this.frames = 0;
      this.fpsTime = 0;
      this.serverRadius = app.settings.renderDistance;
      this.loading = new Set();
      this.lastSave = performance.now();
      // Одиночная игра: инвентарь, существа и состояние выживания
      this.sinv = new MC.Survival.Inventory();
      this.ents = null;
      this.invuln = 0;
      this.exhaustion = 0;
      this.saturation = 5;
      this.air = 15;
      this.lavaT = 0;
      this.regenT = 0;
      this.fx = { regen: 0, regenT: 0, absorb: 0, absorbT: 0, fireRes: 0 };
      this.tickTimer = 0;
      this.hitCooldown = 0;
      this.eating = null;
      this.armor = [null, null, null, null];
      this.invScreen = null;
      // Сетевая игра: рецепты сервера и открытые им окна (сундук, печь)
      this.recipes = [];
      this.windows = new Map();
    }

    get renderer() { return this.app.renderer; }
    get ui() { return this.app.ui; }
    get input() { return this.app.input; }

    // ---------- Запуск ----------
    async start() {
      if (this.mode === 'sp') return this.startSingle();
      return this.startMulti();
    }

    async startSingle() {
      const w = this.opts.world;
      this.record = w;
      this.generator = new MC.Generator(w.seed);
      this.ents = new MC.Entities(this);
      // Механика одиночной игры: поршни, редстоун, падающие блоки — реагирует на изменения блоков
      this.mechanics = new MC.Mechanics(this);
      this.building = new MC.Building(this);
      this.schematic = new MC.Schematics.View(this);
      this.world.onBlockSet((x, y, z) => this.mechanics.mark(x, y, z));
      // Миры, созданные до появления выживания, остаются творческими
      this.gamemode = typeof w.gamemode === 'number' ? w.gamemode : 1;
      this.player.canFly = this.gamemode === 1;
      this.time = typeof w.time === 'number' ? w.time : 6000;
      this.health = typeof w.health === 'number' ? w.health : 20;
      this.food = typeof w.food === 'number' ? w.food : 20;
      this.saturation = typeof w.saturation === 'number' ? w.saturation : 5;
      this.armor = [0, 1, 2, 3].map((i) => (w.armor && w.armor[i] && w.armor[i].id ? { id: w.armor[i].id, data: w.armor[i].data || 0, count: 1 } : null));
      const p = w.player || this.generator.findSpawn();
      this.player.x = p.x; this.player.y = p.y; this.player.z = p.z;
      this.player.yaw = p.yaw || 0; this.player.pitch = p.pitch || 0;
      this.player.flying = this.gamemode === 1 && !!p.flying;
      if (w.inventory) this.sinv = new MC.Survival.Inventory(w.inventory);
      else if (w.hotbar) this.sinv = new MC.Survival.Inventory(w.hotbar);
      else if (this.gamemode === 1) this.sinv = new MC.Survival.Inventory([[1, 0], [3, 0], [2, 0], [4, 0], [5, 0], [17, 0], [20, 0], [50, 0], [89, 0]].map(([id, data]) => ({ id, data, count: 64 })));
      // Чанк под игроком загружается до входа, чтобы не провалиться
      await this.loadChunkSP(Math.floor(this.player.x) >> 4, Math.floor(this.player.z) >> 4);
      this.ready = true;
    }

    startMulti() {
      const st = this.app.settings;
      const srv = this.opts.server;
      return new Promise((resolve, reject) => {
        this.onReady = resolve;
        this.onFail = reject;
        const skin = st.skin ? MC.Skin.fromBase64(st.skin) : MC.Skin.defaultSkin();
        this.client = new MC.McpeClient({
          relayUrl: st.relay,
          host: srv.host,
          port: srv.port,
          username: st.nickname,
          uuid: st.uuid,
          skin,
          chunkRadius: st.renderDistance,
          touch: this.input.touchMode
        }, this.handlers());
        this.client.connect().catch((e) => this.disconnected(e.message));
      });
    }

    // ---------- Сетевые события ----------
    handlers() {
      const g = this;
      return {
        onStatus(text) { if (!g.ready) g.app.connectStatus(text); },
        onSpawn() {
          g.spawned = true;
          g.app.connectStatus('Загрузка чанков...');
          g.checkReady();
          // Если сервер не прислал чанк под игроком, всё равно входим в игру
          setTimeout(() => g.becomeReady(), 5000);
        },
        onDisconnect(reason) { g.disconnected(reason); },
        onStartGame(s) {
          g.eid = s.eid;
          g.gamemode = s.gamemode;
          g.player.x = s.pos.x; g.player.y = s.pos.y; g.player.z = s.pos.z;
          g.player.yaw = s.yaw; g.player.pitch = s.pitch;
          g.player.canFly = s.gamemode === 1;
          g.respawnPos = { x: s.spawn.x + 0.5, y: s.spawn.y, z: s.spawn.z + 0.5 };
        },
        onText(t) { g.text(t); },
        onTime(t) { g.time = t; },
        onAddPlayer(p) {
          const info = g.playerInfo.get(p.uuid);
          g.entities.set(p.eid, {
            kind: 'player', eid: p.eid, uuid: p.uuid, name: p.name,
            x: p.pos.x, y: p.pos.y - EYE, z: p.pos.z, tx: p.pos.x, ty: p.pos.y - EYE, tz: p.pos.z,
            yaw: p.yaw, pitch: p.pitch, walk: 0, walkAmount: 0, swingTime: 0, hurt: 0,
            skinKey: 'p:' + p.uuid, skin: info ? info.skin : null, armor: [null, null, null, null]
          });
        },
        onMobArmor(eid, items) {
          const e = g.entities.get(eid);
          if (e) e.armor = items.map((it) => (it && it.id ? it : null));
        },
        onAddEntity(e) {
          g.entities.set(e.eid, { kind: 'mob', eid: e.eid, type: e.type, x: e.pos.x, y: e.pos.y, z: e.pos.z, tx: e.pos.x, ty: e.pos.y, tz: e.pos.z, yaw: e.yaw, pitch: e.pitch, hurt: 0 });
        },
        onAddItemEntity(e) {
          g.entities.set(e.eid, { kind: 'item', eid: e.eid, item: e.item, x: e.pos.x, y: e.pos.y, z: e.pos.z, tx: e.pos.x, ty: e.pos.y, tz: e.pos.z });
        },
        onRemoveEntity(eid) {
          const e = g.entities.get(eid);
          if (e && e.kind === 'player') g.renderer.dropSkin(e.skinKey);
          g.entities.delete(eid);
        },
        onMoveEntity(m) {
          const e = g.entities.get(m.eid);
          if (!e) return;
          e.tx = m.pos.x;
          e.ty = e.kind === 'player' ? m.pos.y - EYE : m.pos.y;
          e.tz = m.pos.z;
          e.yaw = e.kind === 'player' ? m.headYaw : m.yaw;
          e.pitch = m.pitch;
        },
        onTeleport(m) {
          g.player.x = m.pos.x; g.player.y = m.pos.y - EYE; g.player.z = m.pos.z;
          g.player.vx = g.player.vy = g.player.vz = 0;
          g.player.yaw = m.yaw; g.player.pitch = m.pitch;
          g.player.fallStart = null;
          g.lastSent = null;
        },
        onBlock(x, y, z, id, data) {
          g.world.setBlock(x, y, z, id, data);
          if (g.breaking && g.breaking.x === x && g.breaking.y === y && g.breaking.z === z) g.breaking = null;
        },
        onEntityEvent(eid, ev) {
          if (ev === 2 && eid === g.eid) { g.ui.flashHurt(); MC.Sound.play('game.player.hurt', null, 1, 0.8 + Math.random() * 0.4); return; }
          if (ev === 3 && eid === g.eid) { MC.Sound.play('game.player.die', null, 1, 1); return; }
          // 65 — сработал тотем бессмертия
          if (ev === 65) {
            if (eid === g.eid) { g.ui.totemPop(); MC.Sound.play('random.levelup', null, 1, 1.2); return; }
            const t = g.entities.get(eid);
            if (t) MC.Sound.play('random.levelup', { x: t.x, y: t.y + 1, z: t.z }, 1, 1.2);
            return;
          }
          const e = g.entities.get(eid);
          if (ev === 2 && e) e.hurt = 0.35;
          if ((ev === 2 || ev === 3) && e && e.kind !== 'item') MC.Sound.entity(e.kind === 'player' ? 'player' : e.type, ev === 2 ? 'hurt' : 'death', e.x, e.y + 1, e.z);
        },
        onTakeItem(item, picker) {
          if (picker === g.eid) MC.Sound.event('pop');
          this.onRemoveEntity(item);
        },
        onLevelSound(s) { MC.Sound.network(s.sound, s.x, s.y, s.z, s.extra); },
        onLevelEvent(ev) {
          if (ev.id === 2001) {
            // Частицы разрушения блока: звук ломания (свой блок уже озвучен локально)
            const o = g.lastOwnBreak;
            if (o && performance.now() - o.t < 1500 && Math.floor(ev.x) === o.x && Math.floor(ev.y) === o.y && Math.floor(ev.z) === o.z) return;
            MC.Sound.block(ev.data & 0xff, 'break', ev.x, ev.y, ev.z);
          } else if (ev.id === 1003) MC.Sound.play(Math.random() < 0.5 ? 'random.door_open' : 'random.door_close', ev, 1, 1);
          else if (ev.id === 1000 || ev.id === 3500) MC.Sound.play('random.click', ev, 0.6, 1);
          else if (ev.id === 1005) MC.Sound.play('random.fuse', ev, 1, 1);
          else if (ev.id === 1004) MC.Sound.event('fizz', ev.x, ev.y, ev.z);
          else if (ev.id === 1051) MC.Sound.play('random.orb', ev, 0.3, 1);
        },
        onAttributes(a) {
          if (a['minecraft:health']) g.setHealth(a['minecraft:health'].value);
          if (a['minecraft:player.hunger']) g.food = a['minecraft:player.hunger'].value;
        },
        onMotion(m) {
          g.player.vx = m.x * 20; g.player.vy = m.y * 20; g.player.vz = m.z * 20;
        },
        onHealth(h) { g.setHealth(h); },
        onSpawnPosition(p) { g.respawnPos = { x: p.x + 0.5, y: p.y, z: p.z + 0.5 }; },
        onSwing(eid) {
          const e = g.entities.get(eid);
          if (e) e.swingTime = 1;
        },
        onRespawn(pos) { g.respawnPos = { x: pos.x, y: pos.y, z: pos.z }; },
        onSlot(windowId, slot, hotbarSlot, item) {
          const it = item && item.id ? item : null;
          if (windowId === 0) g.inv[slot] = it;
          else if (windowId === 0x78) { if (slot < 4) g.armor[slot] = it; }
          else if (g.windows.has(windowId)) g.windows.get(windowId).slots[slot] = it;
          if (g.invScreen) g.invScreen.onServerUpdate();
        },
        onContent(windowId, slots, hotbar) {
          const items = slots.map((it) => (it && it.id ? it : null));
          if (windowId === 0) {
            g.inv = items;
            if (hotbar.length) g.hotbarMap = hotbar.slice(0, 9).map((h) => (h < 0 ? -1 : h - 9));
          } else if (windowId === 0x78) {
            g.armor = [0, 1, 2, 3].map((i) => items[i] || null);
          } else if (windowId === 121) {
            g.creativeItems = slots.filter((it) => it && it.id);
          } else if (g.windows.has(windowId)) {
            const w = g.windows.get(windowId);
            for (let i = 0; i < items.length; i++) w.slots[i] = items[i];
          }
          if (g.invScreen) g.invScreen.onServerUpdate();
        },
        onCraftingData(recipes) { g.recipes = recipes; },
        // Сервер открыл сундук (0) или печь (2); верстак (1) открывает сам клиент
        onContainerOpen(windowId, type, pos) {
          if (type !== 0 && type !== 2) return;
          const w = { id: windowId, type, pos, slots: new Array(type === 2 ? 3 : 27).fill(null), cook: 0, burn: 0, burnMax: 0 };
          g.windows.set(windowId, w);
          if (type === 0) MC.Sound.event('chest.open', pos.x + 0.5, pos.y + 0.5, pos.z + 0.5);
          g.openContainer(type === 2 ? 'furnace' : 'chest', { window: w });
        },
        onContainerClose(windowId) {
          if (!g.windows.has(windowId)) return;
          g.windows.delete(windowId);
          if (g.invScreen && g.invScreen.window && g.invScreen.window.id === windowId) { g.invScreen.window = null; g.app.resume(); }
        },
        onContainerData(windowId, property, value) {
          const w = g.windows.get(windowId);
          if (!w) return;
          // 0 — ход готовки (тики из 200), 1 — остаток горения в тиках
          if (property === 0) w.cook = value / 20;
          else if (property === 1) { w.burn = value / 20; w.burnMax = Math.max(w.burnMax, w.burn); }
          if (g.invScreen) g.invScreen.onServerUpdate();
        },
        onAdventure(a) {
          g.immutable = a.worldImmutable;
          g.player.canFly = a.allowFlight || g.gamemode === 1;
          if (!g.player.canFly) g.player.flying = false;
          else if (a.flying) g.player.flying = true;
        },
        onChunk(c) {
          g.world.setChunk(new MC.Chunk(c.cx, c.cz, c.sections));
          g.unloadFar(g.serverRadius + 2);
          g.checkReady();
        },
        onGamemode(m) {
          g.gamemode = m;
          g.player.canFly = m === 1;
          if (!g.player.canFly) g.player.flying = false;
        },
        onPlayerList(p) {
          if (p.add) {
            const skin = p.skin && (p.skin.length === 8192 || p.skin.length === 16384) ? p.skin : null;
            g.playerInfo.set(p.uuid, { name: p.name, skin });
            for (const e of g.entities.values()) {
              if (e.kind === 'player' && e.uuid === p.uuid && skin) { g.renderer.dropSkin(e.skinKey); e.skin = skin; }
            }
          } else {
            g.playerInfo.delete(p.uuid);
          }
        },
        onChunkRadius(r) {
          g.serverRadius = r;
          g.renderer.renderDistance = Math.min(g.app.settings.renderDistance, r);
        },
        onTransfer(address, port) {
          g.ui.addChat('§eПереход на сервер ' + address + ':' + port);
          g.app.transfer({ name: address, host: address, port });
        },
        onTitle(type, text) {
          if (type === 0 || type === 1) g.ui.setTitle('', '', 1);
          else if (type === 2) g.ui.setTitle(text, null);
          else if (type === 3) g.ui.setTitle(null, text);
          else if (type === 4) g.ui.setPopup(text);
        }
      };
    }

    checkReady() {
      if (this.ready || !this.spawned) return;
      if (this.world.isLoaded(Math.floor(this.player.x), Math.floor(this.player.z))) this.becomeReady();
    }

    becomeReady() {
      if (this.ready || this.stopped || !this.spawned) return;
      this.ready = true;
      if (this.onReady) this.onReady();
    }

    disconnected(reason) {
      if (this.stopped) return;
      this.stopped = true;
      if (!this.ready && this.onFail) this.onFail(new Error(reason));
      else this.app.lostConnection(reason);
    }

    text(t) {
      let msg;
      switch (t.type) {
        case 1: msg = MC.translate('chat.type.text', [t.source, t.message]); break;
        case 3: case 4: this.ui.setPopup(t.message); return;
        case 6: msg = '§7' + t.source + ' шепчет: ' + t.message; break;
        case 7: msg = MC.translate('chat.type.announcement', [t.source, t.message]); break;
        default: msg = t.message;
      }
      if (this.scripts) this.scripts.emit('message', { type: t.type, source: t.source || '', text: t.message, line: msg });
      this.ui.addChat(msg);
    }

    setHealth(h) {
      if (h < this.health && h > 0) this.ui.flashHurt();
      this.health = h;
      if (h <= 0 && !this.dead) {
        this.dead = true;
        this.cancelBreak();
        this.app.showDeath();
      } else if (h > 0 && this.dead) {
        this.dead = false;
      }
    }

    respawn() {
      const p = this.player;
      if (this.mode === 'sp') {
        const s = this.spawnPoint();
        p.x = s.x; p.y = s.y; p.z = s.z;
        p.vx = p.vy = p.vz = 0;
        p.fallStart = null;
        this.health = 20;
        this.food = 20;
        this.saturation = 5;
        this.air = 15;
        this.exhaustion = 0;
        this.dead = false;
        return;
      }
      this.client.sendAction(ACT.RESPAWN, Math.floor(p.x), Math.floor(p.y), Math.floor(p.z), 0);
      if (this.respawnPos) {
        p.x = this.respawnPos.x; p.y = this.respawnPos.y; p.z = this.respawnPos.z;
        p.vx = p.vy = p.vz = 0;
      }
      this.dead = false;
      this.lastSent = null;
    }

    // ---------- Чанки ----------
    removeChunkMeshes(cx, cz) {
      for (let sy = 0; sy < 16; sy++) {
        this.renderer.removeSection(cx, sy, cz);
        this.dirty.delete(cx + ',' + sy + ',' + cz);
      }
    }

    unloadFar(radius) {
      const pcx = Math.floor(this.player.x) >> 4, pcz = Math.floor(this.player.z) >> 4;
      for (const c of Array.from(this.world.chunks.values())) {
        if (Math.max(Math.abs(c.cx - pcx), Math.abs(c.cz - pcz)) <= radius) continue;
        if (this.mode === 'sp' && c.modified) MC.Storage.Worlds.saveChunk(this.record.id, c).catch((e) => console.warn('Сохранение чанка', e));
        this.world.removeChunk(c.cx, c.cz);
        this.removeChunkMeshes(c.cx, c.cz);
      }
    }

    async loadChunkSP(cx, cz) {
      const k = MC.chunkKey(cx, cz);
      if (this.world.chunks.has(k) || this.loading.has(k)) return;
      this.loading.add(k);
      let chunk = null;
      try {
        const saved = await MC.Storage.Worlds.loadChunk(this.record.id, cx, cz);
        if (saved && saved.sections) {
          chunk = new MC.Chunk(cx, cz, saved.sections.map((s) => (s ? { ids: new Uint8Array(s.ids), meta: new Uint8Array(s.meta) } : null)));
        }
      } catch (e) {
        console.warn('Чтение чанка', e);
      }
      if (!chunk) chunk = this.generator.generate(cx, cz);
      this.loading.delete(k);
      if (this.stopped) return;
      this.world.setChunk(chunk);
    }

    updateChunksSP() {
      const r = this.app.settings.renderDistance;
      const pcx = Math.floor(this.player.x) >> 4, pcz = Math.floor(this.player.z) >> 4;
      if (this.loading.size < 3) {
        let best = null, bestD = Infinity;
        for (let dx = -r; dx <= r; dx++) {
          for (let dz = -r; dz <= r; dz++) {
            const d = dx * dx + dz * dz;
            if (d >= bestD || d > r * r + 1) continue;
            const k = MC.chunkKey(pcx + dx, pcz + dz);
            if (this.world.chunks.has(k) || this.loading.has(k)) continue;
            best = [pcx + dx, pcz + dz];
            bestD = d;
          }
        }
        if (best) this.loadChunkSP(best[0], best[1]);
      }
      if (this.frames % 30 === 0) this.unloadFar(r + 2);
    }

    // Пересборка изменённых секций, начиная с ближайших к игроку, в пределах бюджета времени кадра
    rebuildMeshes(budgetMs) {
      if (!this.dirty.size) return;
      const t0 = performance.now();
      const px = this.player.x / 16, py = this.player.y / 16, pz = this.player.z / 16;
      const list = [];
      for (const k of this.dirty) {
        const p = k.split(',');
        const cx = +p[0], sy = +p[1], cz = +p[2];
        const d = (cx + 0.5 - px) ** 2 + (sy + 0.5 - py) ** 2 * 0.5 + (cz + 0.5 - pz) ** 2;
        list.push([d, k, cx, sy, cz]);
      }
      list.sort((a, b) => a[0] - b[0]);
      for (const [, k, cx, sy, cz] of list) {
        this.dirty.delete(k);
        const chunk = this.world.getChunk(cx, cz);
        if (!chunk || !chunk.sections[sy]) {
          this.renderer.removeSection(cx, sy, cz);
          continue;
        }
        this.renderer.setSection(cx, sy, cz, MC.Mesher.buildSection(this.world, cx, sy, cz));
        if (performance.now() - t0 > budgetMs) break;
      }
    }

    // ---------- Инвентарь ----------
    hotbarItem(i) {
      if (this.mode === 'sp') return this.sinv.slots[i];
      const slot = this.hotbarMap[i];
      if (slot === undefined || slot < 0) return null;
      const it = this.inv[slot];
      return it && it.id ? it : null;
    }

    heldItem() { return this.hotbarItem(this.selected) || { id: 0, data: 0, count: 0 }; }

    hotbarItems() {
      const out = [];
      for (let i = 0; i < 9; i++) out.push(this.hotbarItem(i));
      return out;
    }

    selectHotbar(i) {
      this.selected = ((i % 9) + 9) % 9;
      this.cancelBreak();
      this.eating = null;
      if (this.mode === 'mp') {
        const slot = this.hotbarMap[this.selected];
        const item = this.heldItem();
        this.client.sendEquipment(item, slot >= 0 ? slot + 9 : 255, this.selected);
      }
    }

    openInventory() {
      this.closeInventory();
      if (this.mode === 'mp') this.linkHotbar();
      this.invScreen = new MC.InvScreen(this, this.gamemode === 1 ? 'creative' : 'survival');
    }

    // На сервере панель — это ячейки 0..8 инвентаря (как в Java); связь выбранной ячейки сообщаем серверу
    linkHotbar() {
      this.hotbarMap = [0, 1, 2, 3, 4, 5, 6, 7, 8];
      const it = this.inv[this.selected];
      this.client.sendEquipment(it && it.id ? it : { id: 0, data: 0, count: 0 }, this.selected + 9, this.selected);
    }

    // Изменение ячейки на сервере: сервер складывает пары таких пакетов в транзакцию и проверяет баланс
    mpSetSlot(windowId, slot, item) {
      if (this.mode !== 'mp') return;
      this.client.sendSetSlot(windowId, slot, item && item.id ? item : { id: 0, data: 0, count: 0 }, this.selected);
    }

    // Крафт на сервере: ищем рецепт сервера, подходящий к сетке, и отправляем CraftingEvent
    mpCraft(grid, size) {
      const r = MC.Survival.matchServerRecipe(this.recipes, grid, size);
      if (!r) return null;
      // Nukkit 1.1 ждёт всегда 9 ячеек (3x3) в раскладке самого рецепта, начиная с левого верхнего угла
      const air = { id: 0, data: 0, count: 0 };
      const input = [];
      for (let y = 0; y < 3; y++) for (let x = 0; x < 3; x++) {
        let it = null;
        if (r.type === 'shaped') { if (x < r.w && y < r.h) it = r.input[y * r.w + x]; } else { const k = y * 3 + x; if (k < r.input.length) it = r.input[k]; }
        input.push(it && it.id ? { id: it.id, data: it.data, count: 1, nbt: it.nbt } : air);
      }
      this.client.sendCraftingEvent(0, size === 3, r.uuid, input, [r.out]);
      return r.out;
    }

    openContainer(kind, opts) {
      this.closeInventory();
      this.app.openMenu(() => { this.invScreen = new MC.InvScreen(this, kind, opts); });
    }

    // Возвращает в инвентарь предмет из руки и содержимое сетки крафта при закрытии экрана
    closeInventory() {
      if (!this.invScreen) return;
      const s = this.invScreen;
      this.invScreen = null;
      s.close();
    }

    setCreativeSlot(item) {
      if (this.mode === 'sp') {
        this.sinv.slots[this.selected] = { id: item.id, data: item.data, count: item.count };
        return;
      }
      this.inv[this.selected] = item;
      this.hotbarMap[this.selected] = this.selected;
      this.client.sendEquipment(item, this.selected + 9, this.selected);
    }

    pickBlock() {
      if (this.gamemode !== 1) return;
      const hit = this.player.raycast(6);
      if (!hit) return;
      const b = Blocks.list[hit.id];
      const data = b.variants > 1 ? hit.data : 0;
      if (this.mode === 'sp') this.setCreativeSlot({ id: hit.id, data, count: 64 });
      else {
        const it = this.creativeItems && this.creativeItems.find((c) => c.id === hit.id && (c.data === data || c.data < 0));
        if (it) this.setCreativeSlot({ id: it.id, data: it.data < 0 ? 0 : it.data, count: 64, nbt: it.nbt });
      }
    }

    // Выбросить предмет из руки: один (Q) или всю стопку
    dropSelected(all) {
      const p = this.player;
      if (this.mode === 'mp') {
        const slot = this.hotbarMap[this.selected];
        const it = this.inv[slot];
        if (!it || !it.id) return;
        const drop = { id: it.id, data: it.data, count: all ? it.count : 1, nbt: it.nbt };
        this.client.sendDropItem(drop);
        return;
      }
      const it = this.sinv.takeFromSlot(this.selected, all ? 64 : 1);
      if (!it) return;
      const d = p.lookDir();
      this.ents.spawnItem(it, p.x + d[0] * 0.3, p.eyeY - 0.3, p.z + d[2] * 0.3, d[0] * 5, d[1] * 5 + 2, d[2] * 5, 1.5);
    }

    onPickup(item) {
      MC.Sound.event('pop');
      this.ui.setPopup('+' + item.count + ' ' + MC.Items.itemName(item.id, MC.Survival.isTool(item.id) ? 0 : item.data));
    }

    // ---------- Сундук и печь (хранятся в записи мира по координатам) ----------
    chestAt(x, y, z) {
      const key = x + ',' + y + ',' + z;
      if (!this.record.containers) this.record.containers = {};
      const c = this.record.containers[key];
      if (!c || !Array.isArray(c)) this.record.containers[key] = new Array(27).fill(null);
      return this.record.containers[key];
    }

    furnaceAt(x, y, z) {
      const key = x + ',' + y + ',' + z;
      if (!this.record.containers) this.record.containers = {};
      const c = this.record.containers[key];
      if (!c || c.type !== 'furnace') this.record.containers[key] = { type: 'furnace', input: null, fuel: null, output: null, burn: 0, burnMax: 0, cook: 0 };
      return this.record.containers[key];
    }

    // Печи работают по времени, пока мир открыт: горящая печь меняет блок на 62
    tickFurnaces(dt) {
      const c = this.record.containers;
      if (!c) return;
      for (const key in c) {
        const f = c[key];
        if (!f || f.type !== 'furnace') continue;
        const wasLit = f.burn > 0;
        const lit = MC.Survival.tickFurnace(f, dt);
        if (lit === wasLit && !f.output) continue;
        const [x, y, z] = key.split(',').map(Number);
        if (!this.world.isLoaded(x, z)) continue;
        const id = this.world.getId(x, y, z);
        if (id === 61 && lit) this.world.setBlock(x, y, z, 62, this.world.getData(x, y, z));
        else if (id === 62 && !lit) this.world.setBlock(x, y, z, 61, this.world.getData(x, y, z));
        else if (id !== 61 && id !== 62) delete c[key];
      }
    }

    // ---------- Чат ----------
    chat(text) {
      if (this.scripts && this.scripts.handleChat(text)) return;
      if (this.mode === 'mp') {
        this.client.sendChat(text);
        return;
      }
      if (text.startsWith('/')) this.command(text.slice(1).trim().split(/\s+/));
      else this.ui.addChat(MC.translate('chat.type.text', [this.app.settings.nickname, text]));
    }

    // Команды одиночной игры
    command(args) {
      const name = (args[0] || '').toLowerCase();
      const p = this.player;
      if (name === 'time' && args[1] === 'set') {
        const v = { day: 1000, noon: 6000, night: 13000, midnight: 18000 }[args[2]];
        const t = v !== undefined ? v : parseInt(args[2], 10);
        if (isNaN(t)) { this.ui.addChat('§cИспользование: /time set <day|night|noon|midnight|число>'); return; }
        this.time = t;
        this.ui.addChat('Время установлено: ' + t);
      } else if (name === 'tp' && args.length >= 4) {
        const c = (s, cur) => (s.startsWith('~') ? cur + (parseFloat(s.slice(1)) || 0) : parseFloat(s));
        const x = c(args[1], p.x), y = c(args[2], p.y), z = c(args[3], p.z);
        if ([x, y, z].some(isNaN)) { this.ui.addChat('§cИспользование: /tp <x> <y> <z>'); return; }
        p.x = x; p.y = y; p.z = z; p.vx = p.vy = p.vz = 0; p.fallStart = null;
        this.ui.addChat('Телепортация на ' + x.toFixed(1) + ' ' + y.toFixed(1) + ' ' + z.toFixed(1));
      } else if (name === 'seed') {
        this.ui.addChat('Зерно мира: ' + this.record.seed);
      } else if (name === 'spawn') {
        const s = this.spawnPoint();
        p.x = s.x; p.y = s.y; p.z = s.z; p.vx = p.vy = p.vz = 0; p.fallStart = null;
      } else if (name === 'gamemode' && args[1] !== undefined) {
        const m = { 0: 0, s: 0, survival: 0, 1: 1, c: 1, creative: 1 }[args[1].toLowerCase()];
        if (m === undefined) { this.ui.addChat('§cИспользование: /gamemode <0|1>'); return; }
        this.setGamemodeSP(m);
        this.ui.addChat(MC.translate('commands.gamemode.success.self', [m ? 'gameMode.creative' : 'gameMode.survival']));
      } else if (name === 'give' && args[1]) {
        const id = parseInt(args[1], 10), count = parseInt(args[2], 10) || 1, data = parseInt(args[3], 10) || 0;
        if (!(id > 0 && id < 512)) { this.ui.addChat('§cИспользование: /give <id> [количество] [данные]'); return; }
        const left = this.sinv.add({ id, data, count });
        if (left) this.ents.spawnItem({ id, data, count: left }, p.x, p.y + 1, p.z);
        this.ui.addChat('Выдано: ' + MC.Items.itemName(id, data) + ' x' + count);
      } else if (name === 'summon' && args[1]) {
        const type = MC.Entities.TYPES[args[1].toLowerCase()];
        if (!type) { this.ui.addChat('§cСущества: ' + Object.keys(MC.Entities.TYPES).join(', ')); return; }
        const d = p.lookDir();
        this.ents.spawnMob(type, p.x + d[0] * 3, p.y + 0.5, p.z + d[2] * 3);
      } else if (name === 'kill') {
        this.damagePlayer(1000, p.x, p.z, 'Вы погибли');
      } else {
        this.ui.addChat('§7Команды: /gamemode 0|1, /give <id> [кол-во] [данные], /summon <zombie|creeper|spider|pig|cow|sheep|chicken>, /time set <day|night>, /tp x y z, /spawn, /seed, /kill');
      }
    }

    // ---------- Выживание (одиночная игра) ----------
    survival() { return this.gamemode === 0 || (this.mode === 'mp' && this.gamemode === 2); }

    daylight() { return daylightAt(this.time); }

    spawnPoint() {
      const s = this.record.spawn;
      if (s && Blocks.list[this.world.getId(Math.floor(s.x), Math.floor(s.y), Math.floor(s.z))].solid === false) return { x: s.x, y: s.y, z: s.z };
      return this.generator.findSpawn();
    }

    setGamemodeSP(m) {
      this.gamemode = m;
      this.player.canFly = m === 1;
      if (m !== 1) this.player.flying = false;
      this.health = 20;
      this.food = 20;
    }

    // Быстрое переключение выживание ↔ творческий (кнопка в игре, только одиночная)
    toggleCreativeSP() {
      if (this.mode !== 'sp') return;
      const m = this.gamemode === 1 ? 0 : 1;
      this.setGamemodeSP(m);
      this.ui.setPopup(m === 1 ? 'Творческий режим' : 'Выживание');
    }

    damagePlayer(amount, srcX, srcZ, cause) {
      if (this.mode !== 'sp' || this.gamemode !== 0 || this.dead || this.invuln > 0) return;
      const p = this.player;
      // Броня не спасает от падения, утопления, голода и пустоты (как в Minecraft)
      if (!/падении|Утонул|голода|Выпал из мира/.test(cause || '')) {
        const pts = MC.Survival.armorPoints(this.armor);
        if (pts > 0) {
          amount = Math.round(amount * (1 - pts / 25) * 2) / 2;
          this.wearArmor(Math.max(1, Math.floor(amount / 4)));
        }
      }
      if (this.fx.fireRes > 0 && /лаве/.test(cause || '')) return;
      // Поглощение (от тотема) принимает урон первым
      if (this.fx.absorb > 0) {
        const a = Math.min(this.fx.absorb, amount);
        this.fx.absorb -= a;
        amount -= a;
      }
      this.health = Math.max(0, this.health - amount);
      this.invuln = 0.5;
      this.exhaustion += 0.1;
      if (srcX !== null && srcX !== undefined) {
        const dx = p.x - srcX, dz = p.z - srcZ, l = Math.hypot(dx, dz) || 1;
        p.vx += dx / l * 8;
        p.vz += dz / l * 8;
        p.vy = Math.max(p.vy, 5);
      }
      this.ui.flashHurt();
      if (this.health > 0) MC.Sound.play('game.player.hurt', null, 1, 0.8 + Math.random() * 0.4);
      if (this.health <= 0 && this.useTotem()) return;
      if (this.health <= 0) this.dieSP(typeof cause === 'string' ? cause : 'Вы погибли');
    }

    // Тотем бессмертия (450): в руке, а если в руке нет — в любой ячейке хотбара (левой руки в игре нет).
    // Спасает от смерти: 1 здоровье, Регенерация II 40 с, Поглощение II 5 с, Огнестойкость 40 с
    useTotem() {
      const slots = this.sinv.slots;
      let i = -1;
      if (slots[this.selected] && slots[this.selected].id === 450) i = this.selected;
      else for (let k = 0; k < 9; k++) if (slots[k] && slots[k].id === 450) { i = k; break; }
      if (i < 0) return false;
      this.sinv.takeFromSlot(i, 1);
      this.health = 1;
      this.invuln = 1;
      this.fx.regen = 40; this.fx.regenT = 0;
      this.fx.absorb = 8; this.fx.absorbT = 5;
      this.fx.fireRes = 40;
      this.ui.totemPop();
      MC.Sound.play('random.levelup', null, 1, 1.2);
      this.ui.setPopup('§eТотем бессмертия спас вас');
      return true;
    }

    // Износ брони: каждая надетая вещь теряет прочность при уроне
    wearArmor(n) {
      for (let i = 0; i < 4; i++) {
        const a = this.armor[i];
        if (!a) continue;
        a.data += n;
        if (a.data >= MC.Survival.durabilityOf(a.id)) {
          this.armor[i] = null;
          this.ui.setPopup('§cБроня сломалась: ' + MC.Items.itemName(a.id, 0));
        }
      }
    }

    // Надеть броню из руки (нажатие «использовать»); снятая вещь возвращается в руку
    equipArmor(held) {
      const inf = MC.Survival.armorInfo(held.id);
      if (!inf) return false;
      const cur = this.armor[inf[0]];
      this.armor[inf[0]] = { id: held.id, data: held.data, count: 1 };
      this.sinv.slots[this.selected] = cur;
      MC.Sound.click();
      this.ui.setPopup('Надето: ' + MC.Items.itemName(held.id, 0));
      return true;
    }

    dieSP(cause) {
      const p = this.player;
      this.dead = true;
      this.fx = { regen: 0, regenT: 0, absorb: 0, absorbT: 0, fireRes: 0 };
      this.closeInventory();
      MC.Sound.play('game.player.die', null, 1, 1);
      this.breaking = null;
      this.eating = null;
      // Всё содержимое инвентаря и броня выпадают на месте смерти
      for (const it of this.sinv.clear()) this.ents.spawnItem(it, p.x, p.y + 1, p.z, (Math.random() - 0.5) * 6, 4, (Math.random() - 0.5) * 6, 1);
      for (let i = 0; i < 4; i++) if (this.armor[i]) { this.ents.spawnItem(this.armor[i], p.x, p.y + 1, p.z, (Math.random() - 0.5) * 6, 4, (Math.random() - 0.5) * 6, 1); this.armor[i] = null; }
      this.ui.addChat(this.app.settings.nickname + ': ' + cause);
      this.app.showDeath(cause);
    }

    eat(item) {
      const f = MC.Survival.FOOD[item.id];
      if (!f) return;
      this.food = Math.min(20, this.food + f[0]);
      this.saturation = Math.min(this.food, this.saturation + f[1]);
      if (item.id === 322 || item.id === 466) this.health = Math.min(20, this.health + 4);
      if (item.id === 367 && Math.random() < 0.8) this.exhaustion += 15;
      const left = this.sinv.slots[this.selected];
      if (left && left.id === item.id) {
        this.sinv.takeFromSlot(this.selected, 1);
        if (f[2]) {
          if (!this.sinv.slots[this.selected]) this.sinv.slots[this.selected] = { id: f[2], data: 0, count: 1 };
          else if (this.sinv.add({ id: f[2], data: 0, count: 1 })) this.ents.spawnItem({ id: f[2], data: 0, count: 1 }, this.player.x, this.player.y + 1, this.player.z);
        }
      }
    }

    // Здоровье, голод, воздух, урон от падения, лавы и пустоты
    updateSurvival(dt, fall, moved, jumped) {
      const p = this.player;
      this.invuln = Math.max(0, this.invuln - dt);
      if (this.gamemode !== 0 || this.dead) { this.air = 15; return; }
      const fx = this.fx;
      if (fx.regen > 0) {
        fx.regen -= dt;
        fx.regenT += dt;
        if (fx.regenT >= 1.25) { fx.regenT = 0; this.health = Math.min(20, this.health + 1); }
      }
      if (fx.absorbT > 0) { fx.absorbT -= dt; if (fx.absorbT <= 0) fx.absorb = 0; }
      if (fx.fireRes > 0) fx.fireRes -= dt;
      if (fall > 3.4 && !p.inWater) this.damagePlayer(Math.floor(fall - 3), null, null, 'Разбился при падении');
      if (p.headInWater) {
        this.air -= dt;
        if (this.air < 0) { this.air += 1; this.damagePlayer(2, null, null, 'Утонул'); }
      } else {
        this.air = Math.min(15, this.air + dt * 5);
      }
      if (p.inLava) {
        this.lavaT -= dt;
        if (this.lavaT <= 0) { this.lavaT = 0.5; this.invuln = 0; this.damagePlayer(4, null, null, 'Сгорел в лаве'); }
      }
      if (p.y < -64) { this.invuln = 0; this.damagePlayer(4, null, null, 'Выпал из мира'); }
      // Голод: бег и прыжки расходуют насыщение, потом еду
      this.exhaustion += moved * (p.sprinting ? 0.1 : 0.01) + (jumped ? (p.sprinting ? 0.2 : 0.05) : 0);
      while (this.exhaustion >= 4) {
        this.exhaustion -= 4;
        if (this.saturation > 0) this.saturation = Math.max(0, this.saturation - 1);
        else this.food = Math.max(0, this.food - 1);
      }
      this.regenT += dt;
      if (this.regenT >= 4) {
        this.regenT = 0;
        if (this.food >= 18 && this.health < 20) { this.health = Math.min(20, this.health + 1); this.exhaustion += 3; }
        else if (this.food <= 0 && this.health > 1) this.damagePlayer(1, null, null, 'Умер от голода');
      }
    }

    // Рост растений и саженцев (случайные такты блоков рядом с игроком)
    randomTicks() {
      const w = this.world, p = this.player;
      const pcx = Math.floor(p.x) >> 4, pcz = Math.floor(p.z) >> 4;
      for (let dx = -4; dx <= 4; dx++) for (let dz = -4; dz <= 4; dz++) {
        const c = w.getChunk(pcx + dx, pcz + dz);
        if (!c) continue;
        for (let sy = 0; sy < 16; sy++) {
          const sec = c.sections[sy];
          if (!sec) continue;
          for (let n = 0; n < 3; n++) {
            const i = Math.floor(Math.random() * 4096);
            const id = sec.ids[i];
            if (id === 2 || id === 78 || id === 79) {
              this.surfaceTick(c.cx * 16 + (i >> 8), sy * 16 + (i & 15), c.cz * 16 + ((i >> 4) & 15), id);
              continue;
            }
            if (id !== 59 && id !== 141 && id !== 142 && id !== 244 && id !== 6 && id !== 104 && id !== 105 && id !== 83 && id !== 81) continue;
            const x = c.cx * 16 + (i >> 8), z = c.cz * 16 + ((i >> 4) & 15), y = sy * 16 + (i & 15);
            this.growAt(x, y, z, id, sec.meta[i], 1);
          }
        }
      }
    }

    // Трава зарастает на землю и гибнет под непрозрачным блоком; снег и лёд тают у источников света
    surfaceTick(x, y, z, id) {
      const w = this.world, L = Blocks.LIGHT;
      if (id === 2) {
        if (Blocks.list[w.getId(x, y + 1, z)].opaque) { w.setBlock(x, y, z, 3, 0); return; }
        const tx = x + Math.floor(Math.random() * 3) - 1, ty = y + Math.floor(Math.random() * 5) - 3, tz = z + Math.floor(Math.random() * 3) - 1;
        if (w.getId(tx, ty, tz) === 3 && w.getData(tx, ty, tz) === 0 && !Blocks.list[w.getId(tx, ty + 1, tz)].opaque && !Blocks.list[w.getId(tx, ty + 1, tz)].liquid) w.setBlock(tx, ty, tz, 2, 0);
        return;
      }
      let lit = 0;
      for (let dx = -2; dx <= 2; dx++) for (let dy = -2; dy <= 2; dy++) for (let dz = -2; dz <= 2; dz++) {
        const v = L[w.getId(x + dx, y + dy, z + dz)] - Math.abs(dx) - Math.abs(dy) - Math.abs(dz);
        if (v > lit) lit = v;
      }
      if (lit > 11) w.setBlock(x, y, z, id === 79 ? 9 : 0, 0);
    }

    growAt(x, y, z, id, data, steps) {
      const w = this.world;
      if (id === 59 || id === 141 || id === 142 || id === 244) {
        if (data < 7) w.setBlock(x, y, z, id, Math.min(7, data + steps));
        return data < 7;
      }
      if (id === 6) {
        if (steps === 1 && Math.random() > 0.15) return false;
        this.growTree(x, y, z, data & 7);
        return true;
      }
      if ((id === 83 || id === 81) && steps === 1) {
        let h = 1;
        while (w.getId(x, y - h, z) === id) h++;
        if (h < 3 && w.getId(x, y + 1, z) === 0) w.setBlock(x, y + 1, z, id, 0);
        return true;
      }
      if ((id === 104 || id === 105) && steps === 1) {
        if (data < 7) { w.setBlock(x, y, z, id, data + 1); return true; }
        for (const [ax, az] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          if (w.getId(x + ax, y, z + az) === 0 && Blocks.list[w.getId(x + ax, y - 1, z + az)].opaque) {
            w.setBlock(x + ax, y, z + az, id === 104 ? 86 : 103, 0);
            return true;
          }
        }
      }
      return false;
    }

    growTree(x, y, z, kind) {
      const w = this.world;
      const log = kind >= 4 ? 162 : 17, leaves = kind >= 4 ? 161 : 18, d = kind >= 4 ? kind - 4 : kind;
      const h = 4 + Math.floor(Math.random() * 3);
      for (let i = 1; i <= h + 1; i++) if (w.getId(x, y + i, z) !== 0 && w.getId(x, y + i, z) !== leaves) return;
      for (let yy = h - 2; yy <= h + 1; yy++) {
        const r = yy >= h ? 1 : 2;
        for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) {
          if (r === 2 && Math.abs(dx) === 2 && Math.abs(dz) === 2 && Math.random() < 0.5) continue;
          if (yy === h + 1 && Math.abs(dx) + Math.abs(dz) > 1) continue;
          if (w.getId(x + dx, y + yy, z + dz) === 0) w.setBlock(x + dx, y + yy, z + dz, leaves, d);
        }
      }
      for (let i = 0; i < h; i++) w.setBlock(x, y + i, z, log, d);
    }

    // ---------- Разрушение и установка блоков ----------
    canEdit() {
      if (this.mode === 'sp') return true;
      return !this.immutable && this.gamemode !== 2 && this.gamemode !== 3;
    }

    cancelBreak() {
      if (this.breaking && this.mode === 'mp') {
        const b = this.breaking;
        this.client.sendAction(ACT.ABORT_BREAK, b.x, b.y, b.z, b.face);
      }
      this.breaking = null;
    }

    breakTimeFor(hit) {
      if (this.gamemode === 1) return this.mode === 'sp' ? 0 : 0.2;
      const held = this.heldItem();
      const t = Blocks.breakTime(hit.id, held.id, this.player.onGround, this.player.headInWater);
      return this.mode === 'mp' ? t + 0.1 : t;
    }

    // Портит инструмент; возвращает false, если он сломался
    wearTool(amount) {
      if (this.mode !== 'sp' || this.gamemode !== 0) return;
      const it = this.sinv.slots[this.selected];
      if (!it) return;
      const t = MC.Survival.toolInfo(it.id);
      if (!t) return;
      it.data += amount;
      if (it.data >= t[2]) {
        this.sinv.slots[this.selected] = null;
        this.ui.setPopup('§cИнструмент сломался: ' + MC.Items.itemName(it.id, 0));
      }
    }

    // Убирает блок в одиночной игре вместе со второй половиной двери/кровати и тем, что на нём стояло
    removeBlockSP(x, y, z, drops) {
      const w = this.world;
      const id = w.getId(x, y, z), data = w.getData(x, y, z);
      const held = this.heldItem();
      const survival = this.gamemode === 0;
      if (drops && survival) for (const it of MC.Survival.blockDrops(id, data, held.id)) this.ents.spawnItem(it, x + 0.5, y + 0.3, z + 0.5);
      if ((id === 54 || id === 61 || id === 62) && this.record.containers) {
        const key = x + ',' + y + ',' + z;
        const c = this.record.containers[key];
        const items = Array.isArray(c) ? c : c ? [c.input, c.fuel, c.output] : [];
        for (const it of items) if (it) this.ents.spawnItem(it, x + 0.5, y + 0.5, z + 0.5);
        delete this.record.containers[key];
      }
      w.setBlock(x, y, z, 0, 0);
      if (DOORS.has(id) || id === 71) {
        const oy = data & 8 ? y - 1 : y + 1;
        if (w.getId(x, oy, z) === id) w.setBlock(x, oy, z, 0, 0);
      }
      if (id === 26) {
        const dir = [[0, 1], [-1, 0], [0, -1], [1, 0]][data & 3];
        const s = data & 8 ? -1 : 1;
        if (w.getId(x + dir[0] * s, y, z + dir[1] * s) === 26) w.setBlock(x + dir[0] * s, y, z + dir[1] * s, 0, 0);
      }
      // Растения, факелы, двери и снег не висят в воздухе
      for (let yy = y + 1; yy < 256; yy++) {
        const above = w.getId(x, yy, z);
        const b = Blocks.list[above];
        const attached = above && (b.shape === 'cross' || b.shape === 'crop' || b.shape === 'torch' || b.shape === 'flat' || above === 78 || above === 81 || above === 83 || DOORS.has(above) || above === 71);
        if (!attached) break;
        if (drops && survival && !DOORS.has(above) && above !== 71) for (const it of MC.Survival.blockDrops(above, w.getData(x, yy, z), 0)) this.ents.spawnItem(it, x + 0.5, yy + 0.3, z + 0.5);
        w.setBlock(x, yy, z, 0, 0);
      }
      if (id === 46 && !drops) this.ents.primeTnt(x, y, z, 0.5 + Math.random());
    }

    updateBreaking(dt, hit) {
      const p = this.player;
      if (!this.input.attackHeld || !hit || !this.canEdit() || this.eating) {
        if (this.breaking) this.cancelBreak();
        return;
      }
      const b = this.breaking;
      if (b && (b.x !== hit.x || b.y !== hit.y || b.z !== hit.z)) {
        // Прицел на грани блока на пару кадров перескакивает на соседний: даём 0,25 с, прежде чем начать заново
        b.miss = (b.miss || 0) + dt;
        if (b.miss < 0.25) { hit = b; } 
      } else if (b) b.miss = 0;
      if (!b || b.x !== hit.x || b.y !== hit.y || b.z !== hit.z) {
        if (b) this.cancelBreak();
        if (this.attackCooldown > 0) return;
        const time = this.breakTimeFor(hit);
        if (!isFinite(time)) return;
        this.breaking = { x: hit.x, y: hit.y, z: hit.z, face: hit.face, id: hit.id, time, start: performance.now(), elapsed: 0, swing: 0 };
        if (this.mode === 'mp') {
          this.client.sendAction(ACT.ABORT_BREAK, hit.x, hit.y, hit.z, hit.face);
          this.client.sendAction(ACT.START_BREAK, hit.x, hit.y, hit.z, hit.face);
          this.client.sendSwing();
        }
      }
      const br = this.breaking;
      // Сервер сверяет время разрушения по своим часам, поэтому считаем по реальному времени, а не по кадрам
      br.elapsed = (performance.now() - br.start) / 1000;
      br.swing -= dt;
      if (br.swing <= 0) {
        if (br.time > 0) MC.Sound.block(br.id, 'hit', br.x + 0.5, br.y + 0.5, br.z + 0.5);
        if (this.mode === 'mp') this.client.sendSwing();
        p.swingTime = 1;
        br.swing = 0.25;
      }
      if (br.elapsed >= br.time) {
        if (this.scripts && this.scripts.emit('blockBreak', { x: br.x, y: br.y, z: br.z, id: br.id, data: this.world.getData(br.x, br.y, br.z) }) === false) {
          this.cancelBreak();
          this.attackCooldown = 0.25;
          return;
        }
        MC.Sound.block(br.id, 'break', br.x + 0.5, br.y + 0.5, br.z + 0.5);
        if (this.mode === 'mp') {
          this.lastOwnBreak = { x: br.x, y: br.y, z: br.z, t: performance.now() };
          this.client.sendSoundEvent(4, br.x + 0.5, br.y + 0.5, br.z + 0.5, br.id);
          this.client.sendAction(ACT.STOP_BREAK, br.x, br.y, br.z, br.face);
          this.client.sendRemoveBlock(br.x, br.y, br.z);
          // Показываем результат сразу; сервер вернёт блок пакетом UpdateBlock, если отказал
          this.world.setBlock(br.x, br.y, br.z, 0, 0);
        } else {
          if (br.id === 46 && this.gamemode === 0) {
            this.world.setBlock(br.x, br.y, br.z, 0, 0);
            this.ents.spawnItem({ id: 46, data: 0, count: 1 }, br.x + 0.5, br.y + 0.3, br.z + 0.5);
          } else {
            this.removeBlockSP(br.x, br.y, br.z, true);
          }
          const t = MC.Survival.toolInfo(this.heldItem().id);
          if (Blocks.list[br.id].hardness > 0) this.wearTool(t && t[0] === 'sword' ? 2 : 1);
          this.exhaustion += 0.005;
        }
        this.breaking = null;
        this.attackCooldown = this.gamemode === 1 ? 0.25 : 0.05;
        p.swingTime = 1;
      }
    }

    // Данные (ориентация) блока при установке в одиночной игре
    placeData(id, data, hit, face) {
      const p = this.player;
      const dir = yawDir(p.yaw);
      const fy = hit.hit[1] - hit.y;
      const upper = face === 0 || (face > 1 && fy > 0.5);
      if (id === 17 || id === 162 || id === 170) return (data & 3) | (face <= 1 ? 0 : face <= 3 ? 8 : 4);
      if (id === 50 || id === 75 || id === 76) return [5, 5, 4, 3, 2, 1][face];
      if (id === 93 || id === 94) return dir;
      // Поршень смотрит в сторону игрока (туда и выдвигается)
      if (id === 33 || id === 29) {
        const d = p.lookDir();
        const ax = Math.abs(d[0]), ay = Math.abs(d[1]), az = Math.abs(d[2]);
        if (ay >= ax && ay >= az) return d[1] < 0 ? 1 : 0;
        if (az >= ax) return d[2] < 0 ? 3 : 2;
        return d[0] < 0 ? 5 : 4;
      }
      if (id === 65) return face >= 2 ? face : 2;
      if (id === 44 || id === 158 || id === 182) return (data & 7) | (upper ? 8 : 0);
      if ([53, 67, 108, 109, 114, 128, 134, 135, 136, 156, 163, 164, 180, 203].indexOf(id) >= 0) {
        return [2, 1, 3, 0][dir] | (upper ? 4 : 0);
      }
      if ([54, 61, 62, 130, 146, 23, 125, 86, 91].indexOf(id) >= 0) {
        if (id === 86 || id === 91) return [2, 3, 0, 1][dir];
        return [2, 5, 3, 4][dir];
      }
      if (GATES.has(id)) return [0, 1, 2, 3][dir];
      if (id === 96 || id === 167) return [2, 1, 3, 0][dir] | (upper ? 4 : 0);
      return data;
    }

    // Луч до ближайшей жидкости (для ведра)
    liquidRay(maxDist) {
      const p = this.player, d = p.lookDir();
      for (let t = 0.2; t < maxDist; t += 0.1) {
        const x = Math.floor(p.x + d[0] * t), y = Math.floor(p.eyeY + d[1] * t), z = Math.floor(p.z + d[2] * t);
        const id = this.world.getId(x, y, z);
        if (Blocks.list[id].liquid) return { x, y, z, id, data: this.world.getData(x, y, z) };
        if (id && Blocks.list[id].solid) return null;
      }
      return null;
    }

    consumeHeld() {
      if (this.mode === 'sp' && this.gamemode === 0) this.sinv.takeFromSlot(this.selected, 1);
    }

    setHeld(item) {
      if (this.mode !== 'sp' || this.gamemode !== 0) return;
      const cur = this.sinv.slots[this.selected];
      if (cur && cur.count > 1) {
        cur.count--;
        if (this.sinv.add(item)) this.ents.spawnItem(item, this.player.x, this.player.y + 1, this.player.z);
      } else {
        this.sinv.slots[this.selected] = item;
      }
    }

    useItem(hit, fresh) {
      const p = this.player;
      const held = this.heldItem();
      if (this.mode === 'mp') {
        const px = p.x, py = p.eyeY, pz = p.z;
        if (!hit) {
          if (held.id) this.client.sendUseItem(0, 0, 0, -1, 0, 0, 0, px, py, pz, this.selected, held, 0);
          return;
        }
        const fx = hit.hit[0] - hit.x, fy = hit.hit[1] - hit.y, fz = hit.hit[2] - hit.z;
        this.client.sendUseItem(hit.x, hit.y, hit.z, hit.face, fx, fy, fz, px, py, pz, this.selected, held, hit.id);
        this.client.sendSwing();
        p.swingTime = 1;
        if (hit.id === 58 && !p.sneaking) { this.linkHotbar(); this.openContainer('table'); return; }
        if (!this.canEdit()) return;
        if (INTERACTIVE.has(hit.id) && !p.sneaking) return;
        // Обычный блок показываем сразу; двери, кровати и прочее рисуем только после ответа сервера
        if (held.id > 0 && held.id < 256 && Blocks.list[held.id].shape === 'cube' && !INTERACTIVE.has(held.id)) this.placeLocal(hit, held.id, held.data, false);
        return;
      }
      // Вёдра работают и без блока под прицелом
      if (held.id === 325) {
        const l = this.liquidRay(5);
        if (l && l.data === 0) {
          this.world.setBlock(l.x, l.y, l.z, 0, 0);
          MC.Sound.event(l.id <= 9 ? 'bucket.fill.water' : 'bucket.fill.lava', l.x + 0.5, l.y + 0.5, l.z + 0.5);
          this.setHeld({ id: l.id <= 9 ? 326 : 327, data: 0, count: 1 });
        }
        return;
      }
      if (fresh && this.gamemode === 0 && MC.Survival.armorInfo(held.id) && this.equipArmor(held)) return;
      if (fresh && (held.id === 368 || held.id === 332 || held.id === 344)) { this.throwItem(held); return; }
      if (!hit) return;
      if (!p.sneaking && this.interactSP(hit)) return;
      let id = held.id, data = held.data;
      if (!id) return;
      const w = this.world;
      const fd = FACE_DIR[hit.face];
      if (held.id === 326 || held.id === 327) {
        const x = hit.x + fd[0], y = hit.y + fd[1], z = hit.z + fd[2];
        if (!Blocks.list[w.getId(x, y, z)].replaceable) return;
        w.setBlock(x, y, z, held.id === 326 ? 9 : 11, 0);
        MC.Sound.event(held.id === 326 ? 'bucket.empty.water' : 'bucket.empty.lava', x + 0.5, y + 0.5, z + 0.5);
        if (this.gamemode === 0) this.sinv.slots[this.selected] = { id: 325, data: 0, count: 1 };
        return;
      }
      if (held.id >= 290 && held.id <= 294) {
        if ((hit.id === 2 || hit.id === 3) && hit.face === 1 && w.getId(hit.x, hit.y + 1, hit.z) === 0) {
          w.setBlock(hit.x, hit.y, hit.z, 60, 0);
          this.wearTool(1);
          p.swingTime = 1;
        }
        return;
      }
      if (held.id === 351 && held.data === 15) {
        const steps = 2 + Math.floor(Math.random() * 4);
        if (this.growAt(hit.x, hit.y, hit.z, hit.id, hit.data, steps)) this.consumeHeld();
        p.swingTime = 1;
        return;
      }
      if (held.id === 259) {
        MC.Sound.event('ignite', hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
        if (hit.id === 46) { this.world.setBlock(hit.x, hit.y, hit.z, 0, 0); this.ents.primeTnt(hit.x, hit.y, hit.z, 4); this.wearTool(1); }
        return;
      }
      if (id >= 256) {
        const pl = MC.Items.PLACES[id];
        if (!pl) return;
        id = pl[0];
        data = pl[1];
        // Семена и овощи сажаются только на грядку
        if ([59, 141, 142, 244, 104, 105].indexOf(id) >= 0 && (hit.id !== 60 || hit.face !== 1)) return;
        if (id === 115 && (hit.id !== 88 || hit.face !== 1)) return;
      }
      if (id === 6 || id === 31 || id === 37 || id === 38 || id === 83) {
        const ground = Blocks.list[hit.id].replaceable ? w.getId(hit.x, hit.y - 1, hit.z) : hit.face === 1 ? hit.id : -1;
        if ([2, 3, 60, 12].indexOf(ground) < 0 || (id !== 83 && ground === 12)) return;
      }
      if (this.placeLocal(hit, id, data, true)) this.consumeHeld();
    }

    // Двери, люки, калитки, верстак, печь, сундук и кровать в одиночной игре
    interactSP(hit) {
      const w = this.world;
      // Редстоун: рычаг переключается, кнопка нажимается
      if (hit.id === 69 && this.mechanics) { this.mechanics.toggleLever(hit.x, hit.y, hit.z); this.player.swingTime = 1; return true; }
      if ((hit.id === 77 || hit.id === 143) && this.mechanics) {
        if (!(hit.data & 8)) this.mechanics.pressButton(hit.x, hit.y, hit.z, hit.id);
        this.player.swingTime = 1;
        return true;
      }
      // Повторитель: правый клик меняет задержку 1..4 такта
      if ((hit.id === 93 || hit.id === 94) && this.mechanics) {
        w.setBlock(hit.x, hit.y, hit.z, hit.id, (hit.data & 3) | ((((hit.data >> 2) + 1) & 3) << 2));
        MC.Sound.play('random.click', { x: hit.x + 0.5, y: hit.y + 0.5, z: hit.z + 0.5 }, 0.3, 0.6);
        this.player.swingTime = 1;
        return true;
      }
      if (DOORS.has(hit.id)) {
        const y = hit.data & 8 ? hit.y - 1 : hit.y;
        const nd = w.getData(hit.x, y, hit.z) ^ 4;
        w.setBlock(hit.x, y, hit.z, hit.id, nd);
        w.setBlock(hit.x, y + 1, hit.z, hit.id, w.getData(hit.x, y + 1, hit.z));
        MC.Sound.play(nd & 4 ? 'random.door_open' : 'random.door_close', { x: hit.x + 0.5, y: y + 1, z: hit.z + 0.5 }, 1, 0.9 + Math.random() * 0.1);
        return true;
      }
      if (hit.id === 96 || GATES.has(hit.id)) {
        const nd = hit.data ^ (hit.id === 96 ? 8 : 4);
        w.setBlock(hit.x, hit.y, hit.z, hit.id, nd);
        MC.Sound.play(nd & (hit.id === 96 ? 8 : 4) ? 'random.door_open' : 'random.door_close', { x: hit.x + 0.5, y: hit.y + 0.5, z: hit.z + 0.5 }, 1, 0.9 + Math.random() * 0.1);
        return true;
      }
      if (hit.id === 54) MC.Sound.event('chest.open', hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
      if (hit.id === 58) { this.openContainer('table'); return true; }
      if (hit.id === 54) { this.openContainer('chest', { chest: this.chestAt(hit.x, hit.y, hit.z) }); return true; }
      if (hit.id === 61 || hit.id === 62) { this.openContainer('furnace', { furnace: this.furnaceAt(hit.x, hit.y, hit.z) }); return true; }
      if (hit.id === 26) {
        const p = this.player;
        this.record.spawn = { x: p.x, y: p.y, z: p.z };
        if (this.daylight() > 0.5) { this.ui.setPopup('Точка возрождения установлена. Спать можно только ночью'); return true; }
        if (this.ents.nearHostile(p.x, p.y, p.z, 8)) { this.ui.setPopup('§cНельзя спать: рядом монстры'); return true; }
        this.time = Math.ceil(this.time / 24000) * 24000;
        this.ui.setPopup('Доброе утро! Точка возрождения установлена');
        return true;
      }
      return false;
    }

    // Ставит блок; возвращает true, если блок поставлен
    placeLocal(hit, id, data, orient) {
      const w = this.world;
      let x = hit.x, y = hit.y, z = hit.z;
      if (!Blocks.list[hit.id].replaceable) {
        const d = FACE_DIR[hit.face];
        x += d[0]; y += d[1]; z += d[2];
      }
      if (y < 0 || y > 255) return false;
      if (!Blocks.list[w.getId(x, y, z)].replaceable) return false;
      const b = Blocks.list[id];
      if (b.solid) {
        const boxes = Blocks.collisionBoxes(id, data, w, x, y, z) || [];
        const bb = this.player.aabb(this.player.x, this.player.y, this.player.z);
        for (const c of boxes) {
          if (bb[3] > x + c[0] && bb[0] < x + c[3] && bb[4] > y + c[1] && bb[1] < y + c[4] && bb[5] > z + c[2] && bb[2] < z + c[5]) return false;
        }
      }
      const d = orient ? this.placeData(id, data, hit, hit.face) : data;
      if (this.scripts && this.scripts.emit('blockPlace', { x, y, z, id, data: d }) === false) return false;
      if (DOORS.has(id) || id === 71) {
        if (y > 254 || !Blocks.list[w.getId(x, y + 1, z)].replaceable) return false;
        w.setBlock(x, y, z, id, (yawDir(this.player.yaw) + 1) & 3);
        w.setBlock(x, y + 1, z, id, 8);
      } else if (id === 26) {
        const dir = yawDir(this.player.yaw);
        const off = [[0, 1], [-1, 0], [0, -1], [1, 0]][dir];
        if (!Blocks.list[w.getId(x + off[0], y, z + off[1])].replaceable) return false;
        w.setBlock(x, y, z, 26, dir);
        w.setBlock(x + off[0], y, z + off[1], 26, dir | 8);
      } else {
        w.setBlock(x, y, z, id, d);
      }
      MC.Sound.block(id, 'place', x + 0.5, y + 0.5, z + 0.5);
      if (this.mode === 'mp') this.client.sendSoundEvent(5, x + 0.5, y + 0.5, z + 0.5, id);
      this.player.swingTime = 1;
      return true;
    }

    setGliding(v) {
      const p = this.player;
      p.gliding = v;
      if (this.mode === 'mp' && this.glidingSent !== v) {
        this.client.sendAction(v ? ACT.START_GLIDE : ACT.STOP_GLIDE, Math.floor(p.x), Math.floor(p.y), Math.floor(p.z), 0);
      }
      this.glidingSent = v;
      if (v) MC.Sound.play('random.bow', null, 0.6, 1.2);
    }

    // Бросок жемчуга Края, снежка или яйца (одиночная игра)
    throwItem(held) {
      const p = this.player;
      const dir = p.lookDir();
      this.ents.throwProjectile(held, p.x + dir[0] * 0.3, p.eyeY - 0.1, p.z + dir[2] * 0.3, dir, 30);
      MC.Sound.play('random.bow', null, 0.5, 0.4 + Math.random() * 0.4);
      p.swingTime = 1;
      if (this.gamemode !== 1) {
        held.count--;
        if (held.count <= 0) this.sinv.slots[this.selected] = null;
      }
    }

    attackEntity(eid) {
      const p = this.player;
      if (this.scripts && this.scripts.emit('attack', { eid }) === false) return;
      p.swingTime = 1;
      if (this.mode === 'mp') {
        this.client.sendInteract(2, eid);
        this.client.sendSwing();
        return;
      }
      const m = this.ents.list.get(eid);
      if (!m || m.kind !== 'mob') return;
      const held = this.heldItem();
      let dmg = MC.Survival.attackDamage(held.id);
      // Критический удар в падении
      if (!p.onGround && p.vy < 0 && !p.inWater) dmg = Math.floor(dmg * 1.5);
      if (this.gamemode === 1) dmg = Math.max(dmg, 20);
      if (this.ents.hurtMob(m, dmg, p.x, p.z, true)) {
        if (p.sprinting) { m.body.vx *= 1.6; m.body.vz *= 1.6; }
        const t = MC.Survival.toolInfo(held.id);
        if (t) this.wearTool(t[0] === 'sword' ? 1 : 2);
        this.exhaustion += 0.1;
      }
    }

    // ---------- Кадр ----------
    frame(dt, active) {
      const p = this.player;
      const input = this.input;
      const now = performance.now();
      this.frames++;
      if (now - this.fpsTime > 1000) { this.fps = Math.round(this.frames * 1000 / (now - this.fpsTime)); this.frames = 0; this.fpsTime = now; }

      if (this.mode === 'sp') this.updateChunksSP();
      this.time += dt * 20;
      if (this.scripts) this.scripts.emit('tick', dt);

      // Обзор
      const look = input.consumeLook();
      if (active) {
        p.yaw = (p.yaw + look.dx) % 360;
        p.pitch = Math.max(-90, Math.min(90, p.pitch + look.dy));
      }

      // Движение
      const mv = active && !this.dead ? input.move() : { forward: 0, strafe: 0, jump: false, sneak: false, sprint: false, autoJump: false };
      if (this.mode === 'sp' && this.gamemode === 0 && this.food <= 6) mv.sprint = false;
      if (this.eating) { mv.forward *= 0.3; mv.strafe *= 0.3; mv.sprint = false; }
      const wasGround = p.onGround, wasSprint = p.sprinting, wasSneak = p.sneaking;
      const ox = p.x, oz = p.z;
      // Элитры: прыжок в падении начинает планирование, земля или вода заканчивают
      const jumpEdge = mv.jump && !this.prevJump;
      this.prevJump = mv.jump;
      const hasElytra = !!(this.armor[1] && this.armor[1].id === 444);
      if (jumpEdge && hasElytra && !p.onGround && !p.flying && !p.inWater && !p.gliding && p.vy < -1) this.setGliding(true);
      if (p.gliding && (!hasElytra || p.onGround || p.inWater || p.flying)) this.setGliding(false);
      const fall = p.update(dt, mv);
      if (this.glidingSent && !p.gliding) this.setGliding(false);
      const jumped = wasGround && !p.onGround && p.vy > 0;
      this.footstepSounds(wasGround, jumped, fall, Math.hypot(p.x - ox, p.z - oz));
      if (this.mode === 'mp') {
        if (jumped) this.client.sendAction(ACT.JUMP, Math.floor(p.x), Math.floor(p.y), Math.floor(p.z), 0);
        if (wasSprint !== p.sprinting) this.client.sendAction(p.sprinting ? ACT.START_SPRINT : ACT.STOP_SPRINT, 0, 0, 0, 0);
        if (wasSneak !== p.sneaking) this.client.sendAction(p.sneaking ? ACT.START_SNEAK : ACT.STOP_SNEAK, 0, 0, 0, 0);
        this.sendMovement(now);
      } else {
        this.updateSurvival(dt, fall, Math.hypot(p.x - ox, p.z - oz), jumped);
        if (p.y < -64 && this.gamemode === 1) { const s = this.spawnPoint(); p.x = s.x; p.y = s.y; p.z = s.z; p.vy = 0; }
        if (this.mechanics) this.mechanics.update(dt);
        this.ents.update(dt);
        this.tickFurnaces(dt);
        if (this.invScreen) this.invScreen.tick();
        this.tickTimer += dt;
        if (this.tickTimer >= 1) { this.tickTimer = 0; this.randomTicks(); }
      }
      if (this.flyShown !== p.flying) { this.flyShown = p.flying; input.setFlyingButtons(p.flying); }
      if (p.swingTime > 0) p.swingTime = Math.max(0, p.swingTime - dt * 4);

      // Цель взгляда: блок и ближайшее существо
      const reach = this.gamemode === 1 ? 5.5 : 4.5;
      const hit = active && !this.dead ? p.raycast(reach) : null;
      let ent = null;
      if (active && !this.dead) {
        let list;
        if (this.mode === 'mp') {
          list = [];
          for (const e of this.entities.values()) {
            if (e.kind === 'item') continue;
            const look2 = e.kind === 'player' ? [0, 0, [0.6, 1.8, 0.6]] : MC.ENTITY_LOOK[e.type] || [0, 0, [0.6, 1, 0.6]];
            list.push({ eid: e.eid, x: e.x, y: e.y, z: e.z, w: look2[2][0], h: look2[2][1] });
          }
        } else {
          list = this.ents.targets();
        }
        const aim = this.app.settings.aimAssist === false ? 0 : (input.touchMode ? 0.955 : 0.985);
        ent = p.raycastEntities(list, 3.5, aim);
        if (ent && hit && hit.t < ent.t) ent = null;
      }

      this.attackCooldown = Math.max(0, this.attackCooldown - dt);
      this.useCooldown = Math.max(0, this.useCooldown - dt);
      this.hitCooldown = Math.max(0, this.hitCooldown - dt);
      if (active && !this.dead) {
        const tap = input.consumeTap();
        const attack = input.consumeAttack();
        let use = input.consumeUse();
        this.updateEating(dt, hit);
        if (ent && (attack || tap || (input.attackHeld && this.hitCooldown <= 0))) {
          if (this.hitCooldown <= 0) {
            this.attackEntity(ent.eid);
            this.hitCooldown = 0.2;
          }
          use = false;
          if (this.breaking) this.cancelBreak();
        } else if (!ent) {
          // Строительство фигурами: первое нажатие «ломать» задаёт фигуру, удержание после него не ломает блок
          const eb = this.building;
          const atkEdge = input.attackHeld && !this.prevAttackHeld;
          if (eb && atkEdge && eb.onAttack(hit)) this.ebHold = true;
          if (this.ebHold && !input.attackHeld) this.ebHold = false;
          if (this.ebHold) { if (this.breaking) this.cancelBreak(); } else this.updateBreaking(dt, hit);
        }
        this.prevAttackHeld = input.attackHeld;
        const eb = this.building && this.building.active() && (this.building.cfg.mode === 'copy' || this.building.buildable(this.heldItem())) ? this.building : null;
        if (eb && !this.eating) {
          // В режиме строительства блок ставится только отдельным нажатием, без повтора при удержании
          if (use && !eb.onUse(hit)) this.useItem(hit, use);
        } else if (!this.eating && (use || (input.useHeld && this.useCooldown <= 0))) {
          if (use || hit) {
            this.useItem(hit, use);
            // В творческом режиме блоки ставятся быстрее при удержании — удобнее строить
            this.useCooldown = this.gamemode === 1 && input.useHeld ? 0.14 : 0.25;
          }
        }
      } else {
        if (this.breaking) this.cancelBreak();
        this.eating = null;
      }

      // Сетевые сущности: плавное движение к последней позиции с сервера
      const k = 1 - Math.exp(-dt * 12);
      for (const e of this.entities.values()) {
        const ex = e.x, ez = e.z;
        e.x += (e.tx - e.x) * k; e.y += (e.ty - e.y) * k; e.z += (e.tz - e.z) * k;
        const dist = Math.hypot(e.x - ex, e.z - ez);
        if (e.kind === 'player') {
          e.walk += dist * 4;
          e.walkAmount += ((dt > 0 ? Math.min(1, dist / dt / 4) : 0) - e.walkAmount) * Math.min(1, dt * 10);
          if (e.swingTime > 0) e.swingTime = Math.max(0, e.swingTime - dt * 4);
        } else if (e.kind === 'mob') {
          e.walk = (e.walk || 0) + dist;
        }
        if (e.hurt > 0) e.hurt = Math.max(0, e.hurt - dt);
      }

      if (this.building) this.building.update(active && !this.dead ? hit : null);
      if (this.schematic) this.schematic.update(dt);
      if (this.building) this.ui.setBuildHint(this.building.active() ? this.building.hint : this.schematic.s ? this.schematic.hint() : '');
      this.rebuildMeshes(this.ready ? 6 : 20);
      this.draw(hit);
      this.updateHud();

      if (this.mode === 'sp' && now - this.lastSave > 30000) {
        this.lastSave = now;
        this.save().catch((e) => console.warn('Автосохранение', e));
      }
    }

    // Шаги, прыжок и приземление звучат по материалу блока под ногами
    footstepSounds(wasGround, jumped, fall, moved) {
      const p = this.player;
      MC.Sound.setListener(p.x, p.eyeY, p.z, p.yaw);
      if (p.flying || p.inWater) { this.stepDist = 0; return; }
      const under = this.world.getId(Math.floor(p.x), Math.floor(p.y - 0.2), Math.floor(p.z));
      if (jumped && under) MC.Sound.step(under, 'jump', p.x, p.y, p.z, 0.2);
      if (!wasGround && p.onGround && under) {
        if (fall > 3.4 && (this.mode === 'mp' || this.gamemode === 0)) MC.Sound.play(fall > 6 ? 'damage.fallbig' : 'damage.fallsmall', null, 0.75, 1);
        else if (fall > 0.6) MC.Sound.step(under, 'fall', p.x, p.y, p.z, 0.4);
      }
      if (!p.onGround || p.sneaking || !under) return;
      this.stepDist = (this.stepDist || 0) + moved;
      if (this.stepDist >= 1.67) {
        this.stepDist = 0;
        MC.Sound.step(under, 'step', p.x, p.y, p.z, 0.25);
      }
    }

    // Еда: удерживать палец/правую кнопку с едой в руке 1,6 секунды
    updateEating(dt, hit) {
      const held = this.heldItem();
      const food = MC.Survival.FOOD[held.id];
      const plant = (held.id === 391 || held.id === 392 || held.id === 457) && hit && hit.id === 60;
      const hungry = this.mode === 'mp' ? this.food < 20 || held.id === 322 : this.gamemode === 0 && (this.food < 20 || held.id === 322 || held.id === 466);
      const holding = this.input.useHeld || (this.input.touchMode && this.input.attackHeld);
      if (!food || !hungry || !holding || plant) {
        this.eating = null;
        return;
      }
      if (!this.eating || this.eating.id !== held.id) {
        this.eating = { id: held.id, t: 0 };
        if (this.mode === 'mp') {
          const p = this.player;
          this.client.sendUseItem(0, 0, 0, -1, 0, 0, 0, p.x, p.eyeY, p.z, this.selected, held, 0);
        }
      }
      const before = this.eating.t;
      this.eating.t += dt;
      if (Math.floor(before / 0.25) !== Math.floor(this.eating.t / 0.25) && this.eating.t > 0.4) {
        MC.Sound.play(held.id === 373 ? 'random.drink' : 'random.eat', null, 0.5 + Math.random() * 0.5, 0.8 + Math.random() * 0.4);
      }
      if (this.eating.t >= 1.6) {
        MC.Sound.event('burp');
        if (this.mode === 'mp') this.client.sendEntityEvent(9, 0);
        else this.eat(held);
        this.eating = null;
        this.useCooldown = 0.4;
      }
    }

    sendMovement(now) {
      if (!this.ready || now - this.lastMoveSent < 50) return;
      const p = this.player;
      const s = this.lastSent;
      if (s && Math.abs(s.x - p.x) < 0.001 && Math.abs(s.y - p.y) < 0.001 && Math.abs(s.z - p.z) < 0.001 && s.yaw === p.yaw && s.pitch === p.pitch && now - this.lastMoveSent < 1000) return;
      this.lastMoveSent = now;
      this.lastSent = { x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch };
      const yaw = ((p.yaw % 360) + 360) % 360;
      this.client.sendMove(p.x, p.eyeY, p.z, yaw, p.pitch, p.onGround);
    }

    draw(hit) {
      const p = this.player;
      const daylight = daylightAt(this.time);
      const players = [], mobs = [], items = [];
      if (this.mode === 'sp') {
        const l = this.ents.sceneLists();
        mobs.push(...l.mobs);
        items.push(...l.items);
      }
      for (const e of this.entities.values()) {
        if (e.kind === 'player') players.push(e);
        else if (e.kind === 'mob') mobs.push(e);
        else items.push(e);
      }
      const eye = p.eyeY - (p.sneaking ? 0.08 : 0);
      if (!this.ownSkin) this.ownSkin = this.app.settings.skin ? MC.Skin.fromBase64(this.app.settings.skin) : MC.Skin.defaultSkin();
      // Вид от третьего лица (как в Minecraft PE): сзади или спереди, камера не проходит сквозь блоки
      const view = this.app.settings.camera || 'first';
      let cam = { x: p.x, y: eye, z: p.z, yaw: p.yaw, pitch: p.pitch };
      if (view !== 'first' && !this.dead) {
        const d = p.lookDir();
        const sign = view === 'front' ? 1 : -1;
        let dist = 4;
        for (let t = 0.3; t <= 4; t += 0.1) {
          const id = this.world.getId(Math.floor(p.x + d[0] * t * sign), Math.floor(eye + d[1] * t * sign), Math.floor(p.z + d[2] * t * sign));
          if (id && Blocks.list[id].solid) { dist = Math.max(0.3, t - 0.3); break; }
        }
        cam = { x: p.x + d[0] * dist * sign, y: eye + d[1] * dist * sign, z: p.z + d[2] * dist * sign, yaw: view === 'front' ? p.yaw + 180 : p.yaw, pitch: view === 'front' ? -p.pitch : p.pitch };
        const hs = Math.hypot(p.vx, p.vz);
        this.selfWalkAmount = (this.selfWalkAmount || 0) + ((p.onGround ? Math.min(1, hs / 4) : 0) - (this.selfWalkAmount || 0)) * 0.2;
        players.push({ eid: -1, x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch, walk: p.walkDist * 4, walkAmount: this.selfWalkAmount,
          swingTime: p.swingTime, hurt: this.invuln > 0.25 ? 0.2 : 0, skinKey: 'self', skin: this.ownSkin, armor: this.armor });
      }
      const scene = {
        daylight,
        time: this.time,
        underwater: p.headInWater,
        inLava: p.headInLava,
        players,
        entities: mobs,
        items,
        selection: hit ? { x: hit.x, y: hit.y, z: hit.z, boxes: hit.boxes } : null,
        build: this.building && this.building.active() ? this.building.preview : null,
        breakProgress: this.breaking && this.breaking.time > 0 ? Math.min(1, this.breaking.elapsed / this.breaking.time) : 0,
        hand: this.dead || view !== 'first' ? null : {
          item: this.heldItem(), swing: p.swingTime, walk: p.onGround ? p.walkDist * 0.6 : this.lastWalk || 0,
          skinKey: 'self', skin: this.ownSkin, daylight, eating: this.eating ? this.eating.t : 0, armor: this.armor
        }
      };
      if (p.onGround) this.lastWalk = p.walkDist * 0.6;
      this.renderer.render(cam, scene);
      const tags = [];
      for (const e of players) {
        if (e.eid === -1) continue;
        if (Math.hypot(e.x - p.x, e.y - p.y, e.z - p.z) > 48) continue;
        const s = this.renderer.project(e.x, e.y + 2.15, e.z);
        if (s) tags.push({ key: String(e.eid), name: e.name, x: s.x, y: s.y });
      }
      this.ui.setNametags(tags);
    }

    updateHud() {
      const items = this.hotbarItems();
      this.ui.setHotbar(items, this.selected);
      const held = items[this.selected];
      const key = this.selected + ':' + (held ? held.id + ':' + (MC.Survival.isTool(held.id) ? 0 : held.data) : '');
      if (key !== this.lastItemKey) {
        this.lastItemKey = key;
        if (held && held.id) this.ui.showItemName(MC.Items.itemName(held.id, MC.Survival.isTool(held.id) || held.data < 0 ? 0 : held.data));
      }
      const survival = this.survival();
      this.ui.setStats(survival, this.health, survival ? this.food : null, this.mode === 'sp' ? MC.Survival.armorPoints(this.armor) : 0);
      const p = this.player;
      this.ui.setAir(survival && this.mode === 'sp' && (p.headInWater || this.air < 15) ? Math.ceil(Math.max(0, this.air) / 1.5) : null);
      const t = (((Math.floor(this.time) % 24000) + 24000) % 24000);
      this.ui.setDebug(this.fps + ' FPS · XYZ ' + p.x.toFixed(1) + ' ' + p.y.toFixed(1) + ' ' + p.z.toFixed(1) +
        (this.mode === 'mp' ? ' · ' + this.opts.server.host : '') + ' · время ' + t + (p.flying ? ' · полёт' : ''));
      this.ui.tick();
    }

    toggleFly() {
      if (this.player.canFly) {
        this.player.flying = !this.player.flying;
        this.player.vy = 0;
      }
    }

    touchButton(name) {
      if (name === 'jump' || name === 'flyup') {
        const now = performance.now();
        if (now - this.lastJumpTap < 300) this.toggleFly();
        this.lastJumpTap = now;
      } else if (name === 'sneak') {
        this.input.sneakToggle = !this.input.sneakToggle;
      } else if (name === 'gm') {
        this.toggleCreativeSP();
      }
    }

    // ---------- Сохранение и выход ----------
    async save() {
      if (this.mode !== 'sp') return;
      const p = this.player;
      const id = this.record.id;
      const jobs = [];
      for (const c of this.world.chunks.values()) {
        if (!c.modified) continue;
        c.modified = false;
        jobs.push(MC.Storage.Worlds.saveChunk(id, c));
      }
      const r = this.record;
      r.player = { x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch, flying: p.flying };
      r.inventory = this.sinv.toJSON();
      delete r.hotbar;
      r.gamemode = this.gamemode;
      r.health = this.dead ? 20 : this.health;
      r.food = this.dead ? 20 : this.food;
      r.saturation = this.saturation;
      r.armor = this.armor.map((a) => (a ? { id: a.id, data: a.data, count: 1 } : null));
      delete r.fuel;
      r.time = Math.floor(this.time) % 24000;
      r.lastPlayed = Date.now();
      jobs.push(MC.Storage.Worlds.put(r));
      await Promise.all(jobs);
    }

    async stop() {
      if (this.scripts) { this.scripts.stop(); this.scripts = null; }
      this.closeInventory();
      if (this.mode === 'sp') {
        try { await this.save(); } catch (e) { console.warn('Сохранение мира', e); }
        this.ents.clear();
      }
      this.stopped = true;
      if (this.client) this.client.disconnect();
      for (const e of this.entities.values()) if (e.kind === 'player') this.renderer.dropSkin(e.skinKey);
      this.renderer.dropSkin('self');
      this.entities.clear();
      this.renderer.clearSections();
    }
  }

  MC.Game = Game;
})();
