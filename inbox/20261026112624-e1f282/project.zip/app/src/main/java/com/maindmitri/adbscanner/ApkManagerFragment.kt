package com.maindmitri.adbscanner

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ApkManagerFragment : Fragment() {

    private lateinit var rvPackages: RecyclerView
    private lateinit var pkgAdapter: PackageAdapter
    private lateinit var etSearch: TextInputEditText
    private var allPackages = listOf<PackageEntry>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.fragment_packages, container, false)

        rvPackages = view.findViewById(R.id.rvPackages)
        etSearch   = view.findViewById(R.id.etSearch)

        pkgAdapter = PackageAdapter { pkg ->
            showPackageMenu(pkg)
        }
        rvPackages.layoutManager = LinearLayoutManager(context)
        rvPackages.adapter = pkgAdapter

        etSearch.addTextChangedListener {
            val q = it.toString().lowercase()
            pkgAdapter.submitList(if (q.isEmpty()) allPackages else allPackages.filter { p -> p.name.contains(q) })
        }

        view.findViewById<MaterialButton>(R.id.btnLoadPackages).setOnClickListener { loadPackages() }

        view.findViewById<MaterialButton>(R.id.btnInstallApk).setOnClickListener {
            Toast.makeText(context, "Введите путь в Shell:\npm install /sdcard/app.apk", Toast.LENGTH_LONG).show()
        }

        return view
    }

    private fun loadPackages() {
        if (!AdbManager.isConnected) { Toast.makeText(context, "Нет подключения", Toast.LENGTH_SHORT).show(); return }
        CoroutineScope(Dispatchers.IO).launch {
            val result = AdbManager.shell("pm list packages -f")
            withContext(Dispatchers.Main) {
                result.onSuccess { output ->
                    allPackages = output.lines()
                        .filter { it.startsWith("package:") }
                        .map { line ->
                            val parts = line.removePrefix("package:").split("=")
                            PackageEntry(parts.getOrElse(1) { "" }, parts.getOrElse(0) { "" })
                        }
                        .sortedBy { it.name }
                    pkgAdapter.submitList(allPackages)
                }.onFailure {
                    Toast.makeText(context, "Ошибка: ${it.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun showPackageMenu(pkg: PackageEntry) {
        val options = arrayOf("Force stop", "Uninstall", "Show info", "Clear data")
        val commands = mapOf(
            "Force stop" to "am force-stop ${pkg.name}",
            "Uninstall"  to "pm uninstall ${pkg.name}",
            "Show info"  to "dumpsys package ${pkg.name} | head -30",
            "Clear data" to "pm clear ${pkg.name}"
        )
        android.app.AlertDialog.Builder(context)
            .setTitle(pkg.name)
            .setItems(options) { _, idx ->
                val cmd = commands[options[idx]] ?: return@setItems
                CoroutineScope(Dispatchers.IO).launch {
                    val result = AdbManager.shell(cmd)
                    withContext(Dispatchers.Main) {
                        result.onSuccess { Toast.makeText(context, it.take(120), Toast.LENGTH_LONG).show() }
                        result.onFailure { Toast.makeText(context, "Ошибка: ${it.message}", Toast.LENGTH_SHORT).show() }
                    }
                }
            }
            .show()
    }
}

data class PackageEntry(val name: String, val apkPath: String)

class PackageAdapter(private val onClick: (PackageEntry) -> Unit) :
    RecyclerView.Adapter<PackageAdapter.VH>() {

    private var items = listOf<PackageEntry>()
    fun submitList(list: List<PackageEntry>) { items = list; notifyDataSetChanged() }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvName: TextView = v.findViewById(R.id.tvPkgName)
        val tvPath: TextView = v.findViewById(R.id.tvPkgPath)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_package, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.tvName.text = item.name
        holder.tvPath.text = item.apkPath
        holder.itemView.setOnClickListener { onClick(item) }
    }
}
