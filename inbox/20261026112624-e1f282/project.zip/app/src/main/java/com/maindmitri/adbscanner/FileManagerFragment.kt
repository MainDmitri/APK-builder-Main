package com.maindmitri.adbscanner

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FileManagerFragment : Fragment() {

    private lateinit var tvPath: TextView
    private lateinit var rvFiles: RecyclerView
    private lateinit var filesAdapter: FilesAdapter
    private var currentPath = "/sdcard"
    private var selectedFile: String? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.fragment_files, container, false)

        tvPath = view.findViewById(R.id.tvPath)
        rvFiles = view.findViewById(R.id.rvFiles)

        filesAdapter = FilesAdapter { name, isDir ->
            if (isDir) {
                currentPath = if (name.startsWith("/")) name else "$currentPath/$name"
                loadFiles()
            } else {
                selectedFile = "$currentPath/$name"
                Toast.makeText(context, "Выбрано: $name", Toast.LENGTH_SHORT).show()
            }
        }
        rvFiles.layoutManager = LinearLayoutManager(context)
        rvFiles.adapter = filesAdapter

        view.findViewById<MaterialButton>(R.id.btnUp).setOnClickListener {
            if (currentPath != "/") {
                currentPath = currentPath.substringBeforeLast("/").ifEmpty { "/" }
                loadFiles()
            }
        }
        view.findViewById<MaterialButton>(R.id.btnRefreshFiles).setOnClickListener { loadFiles() }

        view.findViewById<MaterialButton>(R.id.btnDownload).setOnClickListener {
            val f = selectedFile ?: run { toast("Выберите файл"); return@setOnClickListener }
            runShell("pull $f /sdcard/Download/") { toast("PULL: $it") }
        }
        view.findViewById<MaterialButton>(R.id.btnPush).setOnClickListener {
            toast("Выберите файл через проводник и используйте Shell для push")
        }
        view.findViewById<MaterialButton>(R.id.btnDelete).setOnClickListener {
            val f = selectedFile ?: run { toast("Выберите файл"); return@setOnClickListener }
            runShell("rm -rf \"$f\"") { toast("Удалено: $f"); selectedFile = null; loadFiles() }
        }

        if (AdbManager.isConnected) loadFiles()

        return view
    }

    private fun loadFiles() {
        tvPath.text = currentPath
        runShell("ls -la \"$currentPath\"") { output ->
            val items = output.lines()
                .filter { it.isNotBlank() && !it.startsWith("total") }
                .map { line ->
                    val parts = line.trim().split("\\s+".toRegex())
                    val name = parts.lastOrNull() ?: line
                    val isDir = line.startsWith("d")
                    FileEntry(name, isDir, line)
                }
                .filter { it.name != "." }
            filesAdapter.submitList(items)
        }
    }

    private fun runShell(cmd: String, onResult: (String) -> Unit) {
        if (!AdbManager.isConnected) { toast("Нет подключения"); return }
        CoroutineScope(Dispatchers.IO).launch {
            val result = AdbManager.shell(cmd)
            withContext(Dispatchers.Main) {
                result.onSuccess { onResult(it) }.onFailure { toast("Ошибка: ${it.message}") }
            }
        }
    }

    private fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
}

data class FileEntry(val name: String, val isDir: Boolean, val raw: String)

class FilesAdapter(private val onClick: (String, Boolean) -> Unit) :
    RecyclerView.Adapter<FilesAdapter.VH>() {

    private var items = listOf<FileEntry>()

    fun submitList(list: List<FileEntry>) { items = list; notifyDataSetChanged() }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvName: TextView = v.findViewById(R.id.tvFileName)
        val tvInfo: TextView = v.findViewById(R.id.tvFileInfo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.tvName.text = (if (item.isDir) "📁 " else "📄 ") + item.name
        holder.tvInfo.text = item.raw
        holder.itemView.setOnClickListener { onClick(item.name, item.isDir) }
    }
}
