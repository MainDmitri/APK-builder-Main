package com.maindmitri.adbscanner

import dadb.AdbKeyPair
import dadb.Dadb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Wraps dadb connections. One active connection at a time.
 */
object AdbManager {

    private var currentDadb: Dadb? = null
    private var currentAddress: String? = null

    /**
     * Returns the key pair stored in the app's private files dir.
     * Creates a new pair on first run.
     */
    fun getOrCreateKeyPair(filesDir: File): AdbKeyPair {
        val privateKeyFile = File(filesDir, "adb_private_key")
        val publicKeyFile  = File(filesDir, "adb_public_key")
        return if (privateKeyFile.exists() && publicKeyFile.exists()) {
            AdbKeyPair.read(privateKeyFile, publicKeyFile)
        } else {
            val kp = AdbKeyPair.generate()
            kp.writeTo(privateKeyFile, publicKeyFile)
            kp
        }
    }

    suspend fun connect(host: String, port: Int, keyPair: AdbKeyPair): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                disconnect()
                val dadb = Dadb.create(host, port, keyPair)
                // Quick smoke-test
                val result = dadb.shell("echo ADBSCAN_OK")
                currentDadb = dadb
                currentAddress = "$host:$port"
                result.allOutput.trim()
            }
        }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        runCatching { currentDadb?.close() }
        currentDadb = null
        currentAddress = null
    }

    suspend fun shell(command: String): Result<String> = withContext(Dispatchers.IO) {
        val dadb = currentDadb ?: return@withContext Result.failure(IllegalStateException("Not connected"))
        runCatching {
            dadb.shell(command).allOutput
        }
    }

    val connectedAddress: String? get() = currentAddress
    val isConnected: Boolean get() = currentDadb != null

    /** Returns raw bytes from stdout (for screencap -p PNG output) */
    suspend fun shellBytes(command: String): Result<ByteArray> = withContext(Dispatchers.IO) {
        val dadb = currentDadb ?: return@withContext Result.failure(IllegalStateException("Not connected"))
        runCatching {
            dadb.shell(command).allOutput.toByteArray(Charsets.ISO_8859_1)
        }
    }

    suspend fun push(localFile: File, remotePath: String): Result<Unit> = withContext(Dispatchers.IO) {
        val dadb = currentDadb ?: return@withContext Result.failure(IllegalStateException("Not connected"))
        runCatching { dadb.push(localFile, remotePath, 0x1A4, System.currentTimeMillis() / 1000) }
    }

    suspend fun pull(remotePath: String, localFile: File): Result<Unit> = withContext(Dispatchers.IO) {
        val dadb = currentDadb ?: return@withContext Result.failure(IllegalStateException("Not connected"))
        runCatching { dadb.pull(remotePath, localFile) }
    }
}
