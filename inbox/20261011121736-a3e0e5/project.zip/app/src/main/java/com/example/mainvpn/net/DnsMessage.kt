package com.example.mainvpn.net

import java.io.ByteArrayOutputStream

/** Разбор и построение DNS-сообщений (RFC 1035): диагностика утечек и локальный кэш туннеля. */
object DnsMessage {

    const val TYPE_A = 1
    const val TYPE_AAAA = 28

    fun buildQuery(id: Int, name: String, type: Int = TYPE_A): ByteArray {
        val out = ByteArrayOutputStream()
        out.write((id ushr 8) and 0xFF)
        out.write(id and 0xFF)
        out.write(0x01) // RD
        out.write(0x00)
        out.write(0); out.write(1) // QDCOUNT
        out.write(0); out.write(0) // ANCOUNT
        out.write(0); out.write(0) // NSCOUNT
        out.write(0); out.write(0) // ARCOUNT
        for (label in name.trimEnd('.').split('.')) {
            val bytes = label.toByteArray(Charsets.US_ASCII)
            require(bytes.size in 1..63) { "Неверная метка DNS: $label" }
            out.write(bytes.size)
            out.write(bytes)
        }
        out.write(0)
        out.write((type ushr 8) and 0xFF)
        out.write(type and 0xFF)
        out.write(0); out.write(1) // QCLASS IN
        return out.toByteArray()
    }

    /** Код ответа (RCODE) или -1, если пакет не является ответом на запрос с [id]. */
    fun responseCode(packet: ByteArray, length: Int, id: Int): Int {
        if (length < 12) return -1
        val rid = ((packet[0].toInt() and 0xFF) shl 8) or (packet[1].toInt() and 0xFF)
        if (rid != id) return -1
        if ((packet[2].toInt() and 0x80) == 0) return -1
        return packet[3].toInt() and 0x0F
    }

    /** Конец секции вопросов (единственный вопрос) или -1 для некорректного/необычного запроса. */
    fun questionEnd(packet: ByteArray, length: Int): Int {
        if (length < 12) return -1
        if (u16(packet, 4) != 1) return -1
        val nameEnd = skipName(packet, length, 12)
        if (nameEnd < 0 || nameEnd + 4 > length) return -1
        return nameEnd + 4
    }

    /** QTYPE единственного вопроса. */
    fun questionType(packet: ByteArray, questionEnd: Int): Int = u16(packet, questionEnd - 4)

    /** Ключ кэша: вопрос без учёта регистра имени. */
    fun cacheKey(packet: ByteArray, questionEnd: Int): String =
        String(packet, 12, questionEnd - 12, Charsets.ISO_8859_1).lowercase()

    /**
     * Ответ «записей нет» (NOERROR, ANCOUNT = 0) на запрос: заголовок и вопрос из запроса,
     * флаги QR и RA, тот же RD.
     */
    fun emptyResponse(query: ByteArray, questionEnd: Int): ByteArray {
        val r = query.copyOf(questionEnd)
        r[2] = ((query[2].toInt() and 0x01) or 0x80).toByte()
        r[3] = 0x80.toByte()
        for (i in 6 until 12) r[i] = 0
        return r
    }

    /** Минимальный TTL среди записей ответа или -1, если ответ неуспешный или пустой. */
    fun minAnswerTtl(packet: ByteArray, length: Int): Int {
        if (length < 12 || (packet[2].toInt() and 0x80) == 0) return -1
        if ((packet[3].toInt() and 0x0F) != 0) return -1
        val qd = u16(packet, 4)
        val an = u16(packet, 6)
        if (an == 0) return -1
        var pos = 12
        repeat(qd) {
            pos = skipName(packet, length, pos)
            if (pos < 0 || pos + 4 > length) return -1
            pos += 4
        }
        var min = Int.MAX_VALUE
        repeat(an) {
            pos = skipName(packet, length, pos)
            if (pos < 0 || pos + 10 > length) return -1
            val ttl = ((packet[pos + 4].toInt() and 0xFF) shl 24) or ((packet[pos + 5].toInt() and 0xFF) shl 16) or
                ((packet[pos + 6].toInt() and 0xFF) shl 8) or (packet[pos + 7].toInt() and 0xFF)
            val rdLen = u16(packet, pos + 8)
            pos += 10 + rdLen
            if (pos > length) return -1
            if (ttl in 0 until min) min = ttl
        }
        return if (min == Int.MAX_VALUE) -1 else min
    }

    private fun skipName(packet: ByteArray, length: Int, start: Int): Int {
        var pos = start
        while (pos < length) {
            val len = packet[pos].toInt() and 0xFF
            when {
                len == 0 -> return pos + 1
                len and 0xC0 == 0xC0 -> return if (pos + 2 <= length) pos + 2 else -1
                len and 0xC0 != 0 -> return -1
                else -> pos += len + 1
            }
        }
        return -1
    }

    private fun u16(b: ByteArray, i: Int): Int = ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
}
