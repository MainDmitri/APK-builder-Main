package com.maindmitri.botpanel

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class TgCloudException(
    message: String,
    val type: String? = null,
    val parameters: JSONObject? = null,
    val status: Int? = null,
) : Exception(message) {
    val isRevisionMismatch: Boolean
        get() = type == "REVISION_MISMATCH" || status == 409 || parameters?.opt("current_revision") is Number
}

data class CloudState(val revision: Long?, val modules: Map<String, String>)

data class WebhookInfo(
    val url: String,
    val allowedUpdates: List<String>,
    val pendingUpdates: Int,
    val lastError: String?,
    val inSync: Boolean,
)

data class DeployResult(val revision: Long?, val modules: List<String>)

data class RunResult(val logs: List<String>, val result: String, val timeMs: Long?)

/** Клиент API управления tgcloud (тот же, что использует `npx tgcloud`). */
class TgCloudApi(private val token: String) {
    private val appId: String = token.substringBefore(':')

    private suspend fun request(method: String, path: String, body: JSONObject? = null): Any? =
        withContext(Dispatchers.IO) {
            val conn = URL("$BASE_URL/$appId/manage$path").openConnection() as HttpURLConnection
            try {
                conn.requestMethod = method
                conn.connectTimeout = 15_000
                conn.readTimeout = 60_000
                conn.setRequestProperty("Authorization", "Bearer $token")
                conn.setRequestProperty("Content-Type", "application/json")
                if (body != null) {
                    conn.doOutput = true
                    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                }
                val status = conn.responseCode
                val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                val json = try {
                    JSONObject(text)
                } catch (e: Exception) {
                    throw TgCloudException("Сервер вернул не JSON (HTTP $status)")
                }
                if (!json.optBoolean("ok", false)) {
                    val description = json.optString("description").ifEmpty { "Ошибка сервера (HTTP $status)" }
                    val parameters = json.optJSONObject("parameters")
                    val message = if (status == 401 || status == 403) {
                        "Токен отклонён: $description. Возьмите новый в BotFather → Serverless → CLI Access."
                    } else description + describeParameters(parameters)
                    throw TgCloudException(
                        message,
                        json.optString("error_type").ifEmpty { null },
                        parameters,
                        status,
                    )
                }
                json.opt("result")
            } catch (e: IOException) {
                throw TgCloudException("Нет связи с $BASE_URL: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                conn.disconnect()
            }
        }

    suspend fun getState(): CloudState {
        val r = request("GET", "/get") as? JSONObject ?: JSONObject()
        val modules = linkedMapOf<String, String>()
        r.optJSONObject("canonical_modules")?.let { m ->
            for (key in m.keys()) modules[key] = m.optString(key)
        }
        val revision = if (r.has("revision") && !r.isNull("revision")) r.optLong("revision") else null
        return CloudState(revision, modules)
    }

    /**
     * Деплой (POST /deploy). `modules` — полный набор модулей бота: всё, чего в нём нет,
     * сервер удалит. `expectedRevision` защищает от перезаписи чужого деплоя.
     */
    suspend fun deploy(modules: Map<String, String>, expectedRevision: Long?): DeployResult {
        val changed = JSONObject()
        for ((name, code) in modules) changed.put(name, code)
        val body = JSONObject()
            .put("manifest", JSONArray(modules.keys.toList()))
            .put("changed_sources", changed)
        if (expectedRevision != null) body.put("expected_revision", expectedRevision)

        val r = request("POST", "/deploy", body) as? JSONObject ?: JSONObject()
        val revision = if (r.has("revision") && !r.isNull("revision")) r.optLong("revision") else null
        val deployed = r.optJSONObject("canonical_modules")?.keys()?.asSequence()?.toList() ?: modules.keys.toList()
        return DeployResult(revision, deployed.sorted())
    }

    suspend fun getWebhook(): WebhookInfo = parseWebhook(request("GET", "/webhook") as? JSONObject ?: JSONObject())

    suspend fun syncWebhook(): WebhookInfo =
        parseWebhook(request("POST", "/webhook/sync", JSONObject()) as? JSONObject ?: JSONObject())

    /** Выполняет модуль в облаке без деплоя (как `npx tgcloud run`). */
    suspend fun run(module: String, sources: Map<String, String>, args: JSONObject): RunResult {
        val src = JSONObject()
        for ((name, code) in sources) src.put(name, code)
        val body = JSONObject()
            .put("module", module)
            .put("sources", src)
            .put("args", args)
            .put("ctx", JSONObject())
        return try {
            val r = request("POST", "/run", body) as? JSONObject ?: JSONObject()
            RunResult(formatLogs(r.optJSONArray("log")), formatValue(r.opt("result")), timeMs(r))
        } catch (e: TgCloudException) {
            val p = e.parameters
            if (p == null) throw e
            RunResult(formatLogs(p.optJSONArray("log")), "Ошибка: ${e.message}", timeMs(p))
        }
    }

    /** Подробности ошибки из `parameters` (модуль, строка, текст компилятора и т.п.), без логов. */
    private fun describeParameters(p: JSONObject?): String {
        if (p == null) return ""
        val lines = mutableListOf<String>()
        for (key in p.keys()) {
            if (key == "log") continue
            val value = p.opt(key)
            val text = when (value) {
                is JSONArray -> (0 until value.length()).joinToString(", ") { value.opt(it).toString() }
                else -> value.toString()
            }
            lines.add("$key: $text")
        }
        return if (lines.isEmpty()) "" else "\n" + lines.joinToString("\n")
    }

    private fun timeMs(o: JSONObject): Long? =
        if (o.has("time") && !o.isNull("time")) Math.round(o.optDouble("time") * 1000) else null

    private fun parseWebhook(r: JSONObject): WebhookInfo {
        val updates = mutableListOf<String>()
        r.optJSONArray("allowed_updates")?.let { a -> for (i in 0 until a.length()) updates.add(a.optString(i)) }
        return WebhookInfo(
            url = r.optString("url"),
            allowedUpdates = updates,
            pendingUpdates = r.optInt("pending_update_count", 0),
            lastError = r.optString("last_error_message").ifEmpty { null },
            inSync = r.optBoolean("in_sync", false),
        )
    }

    private fun formatLogs(logs: JSONArray?): List<String> {
        if (logs == null) return emptyList()
        val out = mutableListOf<String>()
        for (i in 0 until logs.length()) {
            val e = logs.optJSONObject(i) ?: continue
            val prefix = when (e.optString("_")) {
                "inf" -> "i"
                "wrn" -> "!"
                "err" -> "x"
                else -> "·"
            }
            val msg = if (e.has("M")) e.optString("M") + " …" else e.optString("m")
            val origin = when (val o = e.opt("o")) {
                is String -> o
                is JSONObject -> listOf(o.opt("m") ?: o.opt("module"), o.opt("l") ?: o.opt("line"))
                    .filterNotNull().joinToString(":")
                else -> ""
            }
            out.add(if (origin.isEmpty()) "$prefix $msg" else "$prefix $msg  [$origin]")
        }
        return out
    }

    private fun formatValue(v: Any?): String = when {
        v == null || v == JSONObject.NULL -> "undefined"
        v is JSONObject && v.has("__error") -> "Ошибка: ${v.optString("message")}"
        else -> v.toString()
    }

    companion object {
        const val BASE_URL = "https://cloud.telegram.org"
    }
}
