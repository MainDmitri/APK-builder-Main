package com.maindmitri.botpanel

import android.content.Context
import java.io.File

/** Токен и ID для теста — в SharedPreferences, код бота — в файле во внутренней памяти. */
class Storage(private val context: Context) {
    private val prefs = context.getSharedPreferences("bot_panel", Context.MODE_PRIVATE)
    private val botFile = File(context.filesDir, "bot.js")

    var token: String
        get() = prefs.getString(KEY_TOKEN, "") ?: ""
        set(value) = prefs.edit().putString(KEY_TOKEN, value).apply()

    var testUserId: String
        get() = prefs.getString(KEY_TEST_USER, "") ?: ""
        set(value) = prefs.edit().putString(KEY_TEST_USER, value).apply()

    var testText: String
        get() = prefs.getString(KEY_TEST_TEXT, "/start") ?: "/start"
        set(value) = prefs.edit().putString(KEY_TEST_TEXT, value).apply()

    fun loadCode(): String = if (botFile.exists()) botFile.readText() else ""

    fun saveCode(code: String) = botFile.writeText(code)

    fun asset(name: String): String = context.assets.open(name).bufferedReader(Charsets.UTF_8).use { it.readText() }

    private companion object {
        const val KEY_TOKEN = "cli_token"
        const val KEY_TEST_USER = "test_user_id"
        const val KEY_TEST_TEXT = "test_text"
    }
}

private val TOKEN_FORMAT = Regex("^app\\d+:[A-Za-z0-9_-]+$")

fun validateToken(token: String): String? =
    if (TOKEN_FORMAT.matches(token.trim())) null
    else "Укажите CLI-токен вида app<id>:<secret> (BotFather → бот → Serverless → CLI Access → Access token)"
