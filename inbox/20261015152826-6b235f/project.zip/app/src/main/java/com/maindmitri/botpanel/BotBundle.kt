package com.maindmitri.botpanel

/**
 * Превращает один файл bot.js в модули tgcloud:
 *   lib/bot            — сам файл;
 *   handlers/<тип>     — по одному на каждую экспортируемую функцию с именем типа апдейта;
 *   schema             — пустая схема БД (если в облаке её ещё нет).
 */
object BotBundle {
    const val BOT_MODULE = "lib/bot"
    const val SCHEMA_MODULE = "schema"

    val SCHEMA_SOURCE = """
        |import { table, integer, text } from 'sdk/db';
        |
        |// Однофайловый режим Bot Panel: таблицы базы данных не используются.
        |""".trimMargin()

    /** Типы апдейтов Telegram Bot API. */
    val UPDATE_TYPES = setOf(
        "message", "edited_message", "channel_post", "edited_channel_post",
        "business_connection", "business_message", "edited_business_message", "deleted_business_messages",
        "message_reaction", "message_reaction_count", "inline_query", "chosen_inline_result",
        "callback_query", "shipping_query", "pre_checkout_query", "purchased_paid_media",
        "poll", "poll_answer", "my_chat_member", "chat_member", "chat_join_request",
        "chat_boost", "removed_chat_boost",
    )

    data class Analysis(val handlers: List<String>, val otherExports: List<String>)

    private val EXPORT_FUNCTION = Regex("""(?m)^\s*export\s+(?:async\s+)?function\s*\*?\s*([A-Za-z_$][\w$]*)""")
    private val EXPORT_VARIABLE = Regex("""(?m)^\s*export\s+(?:const|let|var)\s+([A-Za-z_$][\w$]*)""")
    private val EXPORT_LIST = Regex("""(?m)^\s*export\s*\{([^}]*)\}""")
    private val EXPORT_DEFAULT = Regex("""(?m)^\s*export\s+default\b""")
    private val IDENTIFIER = Regex("""^[A-Za-z_$][\w$]*$""")

    fun analyze(source: String): Result<Analysis> {
        val code = stripComments(source)
        if (code.isBlank()) return Result.failure(IllegalArgumentException("Файл бота пустой"))
        if (EXPORT_DEFAULT.containsMatchIn(code)) {
            return Result.failure(
                IllegalArgumentException("Не используйте export default — экспортируйте функции с именами типов апдейтов (export async function message…)")
            )
        }
        val names = LinkedHashSet<String>()
        EXPORT_FUNCTION.findAll(code).forEach { names.add(it.groupValues[1]) }
        EXPORT_VARIABLE.findAll(code).forEach { names.add(it.groupValues[1]) }
        EXPORT_LIST.findAll(code).forEach { m ->
            m.groupValues[1].split(',').map { it.trim() }.filter { it.isNotEmpty() }.forEach { part ->
                val exported = part.split(Regex("\\s+as\\s+")).last().trim()
                if (IDENTIFIER.matches(exported)) names.add(exported)
            }
        }
        val handlers = names.filter { it in UPDATE_TYPES }
        if (handlers.isEmpty()) {
            return Result.failure(
                IllegalArgumentException("В файле нет обработчиков. Нужна хотя бы одна функция вида: export async function message(msg, ctx) { … }")
            )
        }
        return Result.success(Analysis(handlers, names.filter { it !in UPDATE_TYPES }))
    }

    fun handlerSource(updateType: String): String = """
        |// Сгенерировано Bot Panel: обработчик "$updateType" из lib/bot.js
        |import { $updateType as handler } from '../lib/bot.js';
        |
        |export default async function (payload, ctx) {
        |  return await handler(payload, ctx);
        |}
        |""".trimMargin()

    /** Все модули бота (без схемы). */
    fun modules(source: String, analysis: Analysis): Map<String, String> {
        val result = linkedMapOf(BOT_MODULE to source)
        for (h in analysis.handlers) result["handlers/$h"] = handlerSource(h)
        return result
    }

    /** Удаляет комментарии, не трогая строки и шаблонные строки (для поиска export). */
    private fun stripComments(src: String): String {
        val out = StringBuilder(src.length)
        var i = 0
        var quote: Char? = null
        while (i < src.length) {
            val c = src[i]
            if (quote != null) {
                out.append(c)
                if (c == '\\' && i + 1 < src.length) {
                    out.append(src[i + 1]); i += 2; continue
                }
                if (c == quote) quote = null
                i++
                continue
            }
            if (c == '"' || c == '\'' || c == '`') {
                quote = c; out.append(c); i++; continue
            }
            if (c == '/' && i + 1 < src.length && src[i + 1] == '/') {
                while (i < src.length && src[i] != '\n') i++
                continue
            }
            if (c == '/' && i + 1 < src.length && src[i + 1] == '*') {
                val end = src.indexOf("*/", i + 2)
                i = if (end < 0) src.length else end + 2
                out.append(' ')
                continue
            }
            out.append(c)
            i++
        }
        return out.toString()
    }
}
