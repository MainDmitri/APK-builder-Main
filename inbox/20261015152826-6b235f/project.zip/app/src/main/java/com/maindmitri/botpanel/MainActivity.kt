package com.maindmitri.botpanel

import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    PanelScreen(viewModel())
                }
            }
        }
    }
}

@Composable
private fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val context = LocalContext.current
    val colors = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = colors, content = content)
}

@Composable
private fun PanelScreen(vm: PanelViewModel) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var showToken by rememberSaveable { mutableStateOf(false) }
    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.openFile(uri)
    }

    vm.pendingDeploy?.let { plan ->
        AlertDialog(
            onDismissRequest = vm::cancelDeploy,
            title = { Text("Удалить модули в облаке?") },
            text = {
                Text(
                    "Бот из этого файла заменит всё, что сейчас в облаке. Будут удалены:\n\n" +
                        plan.deletions.joinToString("\n")
                )
            },
            confirmButton = { TextButton(onClick = vm::confirmDeploy) { Text("Задеплоить") } },
            dismissButton = { TextButton(onClick = vm::cancelDeploy) { Text("Отмена") } },
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Bot Panel", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Telegram-бот из одного файла bot.js → деплой в Telegram Serverless (tgcloud).",
            style = MaterialTheme.typography.bodyMedium,
        )

        SectionTitle("1. Доступ")
        OutlinedTextField(
            value = vm.token,
            onValueChange = vm::updateToken,
            label = { Text("CLI-токен (app…:…)") },
            supportingText = { Text("BotFather → ваш бот → Serverless → CLI Access → Access token") },
            singleLine = true,
            visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            trailingIcon = {
                TextButton(onClick = { showToken = !showToken }) { Text(if (showToken) "Скрыть" else "Показать") }
            },
            modifier = Modifier.fillMaxWidth(),
        )

        SectionTitle("2. Файл бота")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { openFile.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) {
                Text("Открыть .js")
            }
            OutlinedButton(
                onClick = {
                    val text = clipboard.getText()?.text
                    if (text.isNullOrBlank()) {
                        Toast.makeText(context, "Буфер обмена пуст", Toast.LENGTH_SHORT).show()
                    } else {
                        vm.updateCode(text)
                    }
                },
                modifier = Modifier.weight(1f),
            ) { Text("Вставить") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = {
                    clipboard.setText(AnnotatedString(vm.aiPrompt))
                    Toast.makeText(context, "Промт скопирован — допишите задачу бота", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(1f),
            ) { Text("Промт для ИИ") }
            OutlinedButton(onClick = vm::loadExample, modifier = Modifier.weight(1f)) {
                Text("Пример")
            }
        }
        OutlinedTextField(
            value = vm.code,
            onValueChange = vm::updateCode,
            label = { Text("bot.js") },
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
            minLines = 8,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 420.dp),
        )
        Text(vm.handlersInfo, style = MaterialTheme.typography.bodySmall)

        SectionTitle("3. Запуск")
        Button(onClick = vm::deploy, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) {
            Text("🚀 Задеплоить бота")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = vm::status, enabled = !vm.busy, modifier = Modifier.weight(1f)) {
                Text("Статус")
            }
            OutlinedButton(onClick = vm::syncWebhook, enabled = !vm.busy, modifier = Modifier.weight(1f)) {
                Text("Синхр. вебхук")
            }
        }

        SectionTitle("4. Тест без деплоя")
        OutlinedTextField(
            value = vm.testUserId,
            onValueChange = vm::updateTestUserId,
            label = { Text("Ваш Telegram ID") },
            supportingText = { Text("Сначала напишите боту что-нибудь, иначе он не сможет вам ответить") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = vm.testText,
            onValueChange = vm::updateTestText,
            label = { Text("Текст сообщения") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedButton(onClick = vm::test, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) {
            Text("Выполнить в облаке")
        }

        if (vm.busy) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Text(vm.output)
            }
        } else if (vm.output.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (vm.outputIsError) MaterialTheme.colorScheme.errorContainer
                    else MaterialTheme.colorScheme.surfaceVariant,
                ),
                modifier = Modifier.fillMaxWidth(),
            ) {
                SelectionContainer {
                    Text(
                        vm.output,
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
}
