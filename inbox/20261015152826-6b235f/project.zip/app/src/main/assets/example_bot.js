// bot.js — платный вход в приватный чат за Telegram Stars.
// Один файл = весь бот. Экспортируемые функции = обработчики апдейтов.

import { api } from 'sdk';

// ID приватного канала/группы (бот должен быть там админом с правом приглашать)
const PRIVATE_CHAT_ID = -1004316181064;

// Стоимость входа в Telegram Stars
const ACCESS_PRICE = 140;

async function isUserInChannel(userId) {
  try {
    const member = await api.getChatMember({ chat_id: PRIVATE_CHAT_ID, user_id: userId });
    if (member.status === 'restricted') return member.is_member === true;
    return ['member', 'administrator', 'creator'].includes(member.status);
  } catch (e) {
    console.warn(`[Check Member] ${userId}: ${e.description ?? e.message}`);
    return false;
  }
}

async function onStart(msg) {
  const userName = msg.from.first_name || 'Друг';
  const userId = msg.from.id;

  if (await isUserInChannel(userId)) {
    await api.sendMessage({
      chat_id: msg.chat.id,
      text: `👋 Привет, ${userName}!\n\n✅ У тебя уже есть доступ к приватному каналу — оплата не требуется.`,
    });
    return;
  }

  await api.sendMessage({
    chat_id: msg.chat.id,
    text: `👋 Привет, ${userName}!\n\n🔒 Для получения доступа в приватный канал оплатите ${ACCESS_PRICE} звёзд ниже:`,
  });

  try {
    await api.sendInvoice({
      chat_id: msg.chat.id,
      title: 'Доступ в закрытое сообщество',
      description: `Разовый входной билет в приватную группу (${ACCESS_PRICE} звёзд).`,
      payload: `access_${userId}_${Math.floor(Date.now() / 1000)}`,
      provider_token: '',
      currency: 'XTR',
      prices: [{ label: 'Входной билет', amount: ACCESS_PRICE }],
    });
  } catch (e) {
    console.error('[Stars Pay] Ошибка выставления счёта:', e);
    await api.sendMessage({ chat_id: msg.chat.id, text: `⚠️ Ошибка счёта: ${e.description ?? e.message}` });
  }
}

async function onSuccessfulPayment(msg) {
  const payment = msg.successful_payment;
  console.log(`[Stars Pay] Оплата от ${msg.from.id}: ${payment.total_amount} ${payment.currency}`);
  try {
    const invite = await api.createChatInviteLink({
      chat_id: PRIVATE_CHAT_ID,
      name: `Оплата_${msg.from.id}`,
      member_limit: 1,
    });
    await api.sendMessage({
      chat_id: msg.chat.id,
      text: `🎉 Оплата в ${ACCESS_PRICE} звёзд подтверждена!\n\nВаша персональная ссылка для входа:\n${invite.invite_link}\n\n⏳ Ссылка одноразовая — действует до первого входа.`,
    });
  } catch (e) {
    console.error('[Stars Pay] Ошибка создания ссылки:', e);
    await api.sendMessage({
      chat_id: msg.chat.id,
      text: '⚠️ Оплата прошла, но не удалось создать ссылку. Обратитесь к администратору.',
    });
  }
}

// Апдейт типа message
export async function message(msg, ctx) {
  if (msg.successful_payment) {
    await onSuccessfulPayment(msg);
    return;
  }
  const text = msg.text;
  if (typeof text !== 'string' || !msg.from) return;
  if (/^\/start(@\w+)?(\s|$)/.test(text)) {
    await onStart(msg);
    return;
  }
  if (!text.startsWith('/')) {
    await api.sendMessage({ chat_id: msg.chat.id, text: 'ℹ️ Доступна только команда /start.' });
  }
}

// Апдейт типа pre_checkout_query — обязательное подтверждение оплаты
export async function pre_checkout_query(query, ctx) {
  try {
    await api.answerPreCheckoutQuery({ pre_checkout_query_id: query.id, ok: true });
  } catch (e) {
    console.error('[Stars] Ошибка ответа:', e);
  }
}
