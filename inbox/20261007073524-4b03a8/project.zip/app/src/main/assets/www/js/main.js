// Точка входа: связывает рендер, управление, интерфейс и игровую сессию
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  const App = {
    settings: null,
    renderer: null,
    input: null,
    ui: null,
    game: null,
    active: false,
    connectAttempt: 0,

    async init() {
      this.settings = MC.Storage.loadSettings();
      // Текстур-паки накладываются до загрузки атласов в рендер и интерфейс
      try { await MC.Packs.apply(); } catch (e) { console.warn('Текстур-паки не применены', e); }
      MC.Sound.load();
      const canvas = document.getElementById('game');
      this.renderer = new MC.Renderer(canvas);
      await this.renderer.init();
      await MC.Items.loadImages();
      this.ui = new MC.UI(this);
      await this.ui.init();
      this.input = new MC.Input(canvas, document.getElementById('touch'), this.settings);
      this.bindInput();
      this.applySettings();
      window.addEventListener('resize', () => this.resize());
      // При закрытии страницы сообщаем серверу об отключении, чтобы игрок не «висел» до тайм-аута
      window.addEventListener('pagehide', () => {
        if (this.game && this.game.client) this.game.client.disconnect();
      });
      document.addEventListener('visibilitychange', () => {
        if (document.hidden && this.game && this.game.mode === 'sp') this.game.save().catch((e) => console.warn('Сохранение', e));
      });
      this.ui.showHud(false);
      this.ui.showMain();
      let last = performance.now();
      const loop = (t) => {
        const dt = Math.min(0.1, (t - last) / 1000);
        last = t;
        if (this.game && this.game.ready && !this.game.stopped) this.game.frame(dt, this.active);
        requestAnimationFrame(loop);
      };
      requestAnimationFrame(loop);
    },

    bindInput() {
      const inp = this.input;
      inp.on('pause', () => this.pause());
      inp.on('unlocked', () => this.pause());
      inp.on('escape', () => {
        if (this.game && this.game.ready && (this.ui.current === 'pause' || this.ui.current === 'inventory')) this.resume();
      });
      inp.on('chat', (prefix) => this.openChat(prefix));
      inp.on('inventory', () => this.openInventory());
      inp.on('hotbar', (i) => this.selectHotbar(i));
      inp.on('scroll', (d) => this.game && this.selectHotbar(this.game.selected + d));
      inp.on('pick', () => this.game && this.game.pickBlock());
      inp.on('drop', () => this.game && this.game.ready && this.game.dropSelected(false));
      inp.on('toggleFly', () => this.game && this.game.toggleFly());
      inp.on('tbtn', (name) => {
        if (!this.game) return;
        if (name === 'chat') this.openChat('');
        else if (name === 'pause') this.pause();
        else if (name === 'view') {
          // Переключение вида: от первого лица → сзади → спереди
          const order = ['first', 'back', 'front'];
          const s = this.settings;
          s.camera = order[(order.indexOf(s.camera || 'first') + 1) % 3];
          MC.Storage.saveSettings(s);
          this.ui.setPopup(s.camera === 'first' ? 'Вид от первого лица' : s.camera === 'back' ? 'Вид от третьего лица (сзади)' : 'Вид от третьего лица (спереди)');
        }
        else if (name === 'inv') this.openInventory();
        else this.game.touchButton(name);
      });
    },

    resize() {
      const w = window.innerWidth, h = window.innerHeight;
      this.renderer.resize(w, h, Math.min(window.devicePixelRatio || 1, 2) * (this.settings.renderScale || 1));
      // Единица интерфейса: панель предметов (182 пикселя текстуры) занимает около половины ширины экрана
      const u = Math.max(1.5, Math.min(4, Math.min(w * 0.42, h * 1.1) / 182));
      document.documentElement.style.setProperty('--u', u.toFixed(2) + 'px');
    },

    applySettings() {
      const s = this.settings;
      this.renderer.fov = s.fov;
      this.renderer.clouds = s.clouds !== false;
      this.renderer.fancy = s.shaders !== 'fast';
      this.renderer.brightness = typeof s.brightness === 'number' ? s.brightness : 1;
      this.resize();
      MC.Sound.setVolume(s.volume);
      this.renderer.renderDistance = this.game && this.game.mode === 'mp' ? Math.min(s.renderDistance, this.game.serverRadius) : s.renderDistance;
      this.input.refreshTouchMode();
      document.body.classList.toggle('touch', this.input.touchMode);
    },

    // ---------- Переходы между экранами ----------
    enterGame() {
      this.ui.showPanorama(false);
      this.ui.clear();
      this.ui.showHud(true);
      // Кнопка смены режима — только в одиночной игре
      document.body.classList.toggle('sp', !!this.game && this.game.mode === 'sp');
      this.applySettings();
      this.active = true;
      this.input.setEnabled(true);
      this.input.lockPointer();
    },

    pause() {
      if (!this.game || !this.game.ready || !this.active) return;
      if (this.ui.chatOpen) return;
      this.active = false;
      this.input.setEnabled(false);
      this.ui.showPause(this.game);
    },

    resume() {
      if (!this.game || !this.game.ready) return;
      this.game.closeInventory();
      if (this.game.dead) { this.showDeath(); return; }
      this.ui.clear();
      this.active = true;
      this.input.setEnabled(true);
      this.input.lockPointer();
    },

    openChat(prefix) {
      if (!this.game || !this.game.ready) return;
      this.active = false;
      this.input.setEnabled(false);
      this.ui.openChat(prefix);
    },

    openInventory() {
      if (!this.game || !this.game.ready || this.game.dead) return;
      this.active = false;
      this.input.setEnabled(false);
      this.game.openInventory();
    },

    showDeath(cause) {
      this.active = false;
      this.input.setEnabled(false);
      if (this.ui.chatOpen) this.ui.closeChat();
      this.ui.showDeath(cause);
    },

    // Меню блока (верстак, печь, сундук) поверх игры
    openMenu(show) {
      this.active = false;
      this.input.setEnabled(false);
      show();
    },

    respawn() {
      if (!this.game) return;
      this.game.respawn();
      this.resume();
    },

    sendChat(text) { if (this.game) this.game.chat(text); },

    // Кнопка «Назад» на Android (вызывается из MainActivity.kt): true — обработано, false — закрыть приложение
    androidBack() {
      if (this.game && this.game.ready) {
        if (this.ui.chatOpen) { this.ui.closeChat(); return true; }
        if (this.game.invScreen) { this.resume(); return true; }
        if (this.active) { this.pause(); return true; }
        if (this.ui.current === 'pause') { this.resume(); return true; }
        return true;
      }
      if (this.ui.current && this.ui.current !== 'main') { this.ui.showMain(); return true; }
      return false;
    },

    selectHotbar(i) { if (this.game && this.game.ready) this.game.selectHotbar(i); },

    async stopGame() {
      const g = this.game;
      this.game = null;
      this.active = false;
      this.input.setEnabled(false);
      this.ui.showHud(false);
      this.ui.setNametags([]);
      if (g) await g.stop();
    },

    async quitToTitle() {
      const wasSp = this.game && this.game.mode === 'sp';
      await this.stopGame();
      if (wasSp) this.ui.showWorlds(); else this.ui.showMain();
    },

    async playWorld(w) {
      await this.stopGame();
      this.ui.showConnecting('Загрузка мира «' + w.name + '»...', () => this.quitToTitle());
      const g = new MC.Game(this, 'sp', { world: w });
      this.game = g;
      try {
        await g.start();
      } catch (e) {
        await this.stopGame();
        this.ui.showMessage('Ошибка', 'Не удалось загрузить мир: ' + e.message, () => this.ui.showWorlds());
        return;
      }
      if (this.game === g) this.enterGame();
    },

    async connect(srv) {
      await this.stopGame();
      const attempt = ++this.connectAttempt;
      const cancel = () => {
        this.connectAttempt++;
        this.stopGame().then(() => this.ui.showServers());
      };
      this.ui.showConnecting('Подключение к ' + srv.host + ':' + srv.port + '...', cancel);
      this.cancelConnect = cancel;
      const g = new MC.Game(this, 'mp', { server: srv });
      this.game = g;
      try {
        await g.start();
      } catch (e) {
        if (attempt !== this.connectAttempt) return;
        await this.stopGame();
        this.ui.showMessage('Не удалось подключиться', e.message, () => this.ui.showServers());
        return;
      }
      if (attempt === this.connectAttempt && this.game === g) this.enterGame();
    },

    connectStatus(text) {
      if (this.ui.current === 'connecting') this.ui.showConnecting(text, this.cancelConnect);
    },

    transfer(srv) {
      this.connect(srv);
    },

    async lostConnection(reason) {
      if (!this.game) return;
      await this.stopGame();
      this.ui.showMessage('Соединение потеряно', reason || 'Отключено', () => this.ui.showServers());
    }
  };

  MC.App = App;

  window.addEventListener('load', () => {
    App.init().catch((e) => {
      console.error(e);
      const box = document.getElementById('fatal');
      box.textContent = 'Ошибка запуска: ' + e.message;
      box.style.display = 'block';
    });
    if ('serviceWorker' in navigator && !window.AndroidRelay && (location.protocol === 'https:' || location.protocol === 'http:')) {
      navigator.serviceWorker.register('sw.js').catch((e) => console.warn('Service worker не зарегистрирован', e));
    }
  });
})();
