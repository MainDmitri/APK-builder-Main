// Шум Перлина с зерном мира (2D и 3D) для генератора ландшафта
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  function mulberry32(a) {
    return function () {
      a |= 0;
      a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  class Perlin {
    constructor(seed) {
      const rnd = mulberry32(seed);
      const p = new Uint8Array(256);
      for (let i = 0; i < 256; i++) p[i] = i;
      for (let i = 255; i > 0; i--) {
        const j = Math.floor(rnd() * (i + 1));
        const t = p[i]; p[i] = p[j]; p[j] = t;
      }
      this.perm = new Uint8Array(512);
      for (let i = 0; i < 512; i++) this.perm[i] = p[i & 255];
    }

    static fade(t) { return t * t * t * (t * (t * 6 - 15) + 10); }
    static lerp(a, b, t) { return a + t * (b - a); }
    static grad2(h, x, y) {
      switch (h & 7) {
        case 0: return x + y; case 1: return -x + y; case 2: return x - y; case 3: return -x - y;
        case 4: return x; case 5: return -x; case 6: return y; default: return -y;
      }
    }
    static grad3(h, x, y, z) {
      const g = h & 15;
      const u = g < 8 ? x : y;
      const v = g < 4 ? y : g === 12 || g === 14 ? x : z;
      return ((g & 1) === 0 ? u : -u) + ((g & 2) === 0 ? v : -v);
    }

    noise2(x, y) {
      const P = this.perm;
      const X = Math.floor(x) & 255, Y = Math.floor(y) & 255;
      x -= Math.floor(x); y -= Math.floor(y);
      const u = Perlin.fade(x), v = Perlin.fade(y);
      const a = P[X] + Y, b = P[X + 1] + Y;
      return Perlin.lerp(
        Perlin.lerp(Perlin.grad2(P[a], x, y), Perlin.grad2(P[b], x - 1, y), u),
        Perlin.lerp(Perlin.grad2(P[a + 1], x, y - 1), Perlin.grad2(P[b + 1], x - 1, y - 1), u), v) * 0.7071;
    }

    noise3(x, y, z) {
      const P = this.perm;
      const X = Math.floor(x) & 255, Y = Math.floor(y) & 255, Z = Math.floor(z) & 255;
      x -= Math.floor(x); y -= Math.floor(y); z -= Math.floor(z);
      const u = Perlin.fade(x), v = Perlin.fade(y), w = Perlin.fade(z);
      const A = P[X] + Y, AA = P[A] + Z, AB = P[A + 1] + Z;
      const B = P[X + 1] + Y, BA = P[B] + Z, BB = P[B + 1] + Z;
      const L = Perlin.lerp, G = Perlin.grad3;
      return L(
        L(L(G(P[AA], x, y, z), G(P[BA], x - 1, y, z), u), L(G(P[AB], x, y - 1, z), G(P[BB], x - 1, y - 1, z), u), v),
        L(L(G(P[AA + 1], x, y, z - 1), G(P[BA + 1], x - 1, y, z - 1), u), L(G(P[AB + 1], x, y - 1, z - 1), G(P[BB + 1], x - 1, y - 1, z - 1), u), v), w);
    }

    fbm2(x, y, octaves) {
      let sum = 0, amp = 1, freq = 1, norm = 0;
      for (let i = 0; i < octaves; i++) {
        sum += this.noise2(x * freq, y * freq) * amp;
        norm += amp;
        amp *= 0.5;
        freq *= 2;
      }
      return sum / norm;
    }
  }

  // Детерминированный хеш координат -> [0, 1)
  function hash3(seed, x, y, z) {
    let h = seed ^ Math.imul(x, 374761393) ^ Math.imul(y, 668265263) ^ Math.imul(z, 2147483647);
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  }

  MC.Perlin = Perlin;
  MC.hash3 = hash3;
  MC.mulberry32 = mulberry32;
})();
