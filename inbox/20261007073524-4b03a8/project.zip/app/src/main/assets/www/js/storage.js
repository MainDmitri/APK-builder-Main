// Настройки и список серверов (localStorage), миры одиночной игры (IndexedDB)
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  const SETTINGS_KEY = 'mcpehtml.settings';
  const SERVERS_KEY = 'mcpehtml.servers';

  function uuidv4() {
    if (crypto.randomUUID) return crypto.randomUUID();
    const b = new Uint8Array(16);
    crypto.getRandomValues(b);
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    const h = Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
    return h.slice(0, 8) + '-' + h.slice(8, 12) + '-' + h.slice(12, 16) + '-' + h.slice(16, 20) + '-' + h.slice(20);
  }

  function defaultRelay() {
    // В APK ретранслятор встроен в приложение (RelayServer.kt) и сообщает свой адрес через AndroidRelay
    if (window.AndroidRelay && typeof AndroidRelay.getUrl === 'function') return AndroidRelay.getUrl();
    if (location.protocol === 'http:' || location.protocol === 'https:') {
      return (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host;
    }
    return 'ws://127.0.0.1:8080';
  }

  const DEFAULTS = {
    nickname: 'Steve' + Math.floor(Math.random() * 1000),
    relay: defaultRelay(),
    renderDistance: 6,
    sensitivity: 1,
    fov: 70,
    touch: 'auto',
    autoJump: true,
    controls: 'dpad',
    buttonScale: 1,
    buttonOpacity: 0.75,
    invertY: false,
    clouds: true,
    volume: 1,
    swapJumpSneak: false,
    autoSprint: false,
    camera: 'first',
    shaders: 'fancy',
    renderScale: 1,
    aimAssist: true,
    brightness: 1,
    skin: null,
    uuid: null
  };

  function loadSettings() {
    let s = {};
    try { s = JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') || {}; } catch (e) { s = {}; }
    const out = Object.assign({}, DEFAULTS, s);
    if (!out.uuid) {
      // Первый запуск: на слабом устройстве (мало памяти или ядер) сразу включаем лёгкие настройки
      const weak = (navigator.deviceMemory && navigator.deviceMemory <= 3) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4);
      if (weak) { out.renderScale = 0.65; out.renderDistance = 4; }
      out.uuid = uuidv4();
      saveSettings(out);
    }
    return out;
  }

  function saveSettings(s) {
    try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); } catch (e) { console.warn('Не удалось сохранить настройки', e); }
  }

  function loadServers() {
    try {
      const list = JSON.parse(localStorage.getItem(SERVERS_KEY) || '[]');
      return Array.isArray(list) ? list : [];
    } catch (e) {
      return [];
    }
  }

  function saveServers(list) {
    try { localStorage.setItem(SERVERS_KEY, JSON.stringify(list)); } catch (e) { console.warn('Не удалось сохранить серверы', e); }
  }

  // ---------- IndexedDB ----------
  let dbPromise = null;
  function db() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open('mcpe-html', 2);
      req.onupgradeneeded = () => {
        const d = req.result;
        if (!d.objectStoreNames.contains('worlds')) d.createObjectStore('worlds', { keyPath: 'id' });
        if (!d.objectStoreNames.contains('chunks')) d.createObjectStore('chunks');
        if (!d.objectStoreNames.contains('packs')) d.createObjectStore('packs', { keyPath: 'id' });
        if (!d.objectStoreNames.contains('kv')) d.createObjectStore('kv');
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error('IndexedDB недоступна'));
    });
    return dbPromise;
  }

  function tx(store, mode, fn) {
    return db().then((d) => new Promise((resolve, reject) => {
      const t = d.transaction(store, mode);
      const s = t.objectStore(store);
      let result;
      const r = fn(s);
      if (r && 'onsuccess' in r) r.onsuccess = () => { result = r.result; };
      t.oncomplete = () => resolve(result);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error || new Error('Транзакция отменена'));
    }));
  }

  const Worlds = {
    list() { return tx('worlds', 'readonly', (s) => s.getAll()).then((l) => (l || []).sort((a, b) => b.lastPlayed - a.lastPlayed)); },
    get(id) { return tx('worlds', 'readonly', (s) => s.get(id)); },
    put(w) { return tx('worlds', 'readwrite', (s) => s.put(w)); },
    async remove(id) {
      await tx('worlds', 'readwrite', (s) => s.delete(id));
      await tx('chunks', 'readwrite', (s) => s.delete(IDBKeyRange.bound(id + ':', id + ':￿')));
    },
    loadChunk(id, cx, cz) { return tx('chunks', 'readonly', (s) => s.get(id + ':' + cx + ':' + cz)); },
    saveChunk(id, chunk) {
      const sections = chunk.sections.map((s) => (s ? { ids: s.ids, meta: s.meta } : null));
      return tx('chunks', 'readwrite', (s) => s.put({ sections }, id + ':' + chunk.cx + ':' + chunk.cz));
    }
  };

  // Текстур-паки (.mcpack как Blob) и кэш собранных атласов
  const Packs = {
    list() { return tx('packs', 'readonly', (s) => s.getAll()).then((l) => (l || []).sort((a, b) => (a.order || 0) - (b.order || 0))); },
    put(p) { return tx('packs', 'readwrite', (s) => s.put(p)); },
    remove(id) { return tx('packs', 'readwrite', (s) => s.delete(id)); }
  };
  const kv = {
    get(key) { return tx('kv', 'readonly', (s) => s.get(key)); },
    put(key, value) { return tx('kv', 'readwrite', (s) => s.put(value, key)); }
  };

  MC.Storage = { loadSettings, saveSettings, loadServers, saveServers, Worlds, Packs, kv, uuidv4 };
})();
