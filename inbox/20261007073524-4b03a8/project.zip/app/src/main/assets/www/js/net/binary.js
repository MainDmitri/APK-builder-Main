// Чтение и запись бинарных данных протокола MCPE / RakNet
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const enc = new TextEncoder();
  const dec = new TextDecoder();

  class BinaryWriter {
    constructor(size) {
      this.buf = new Uint8Array(size || 256);
      this.view = new DataView(this.buf.buffer);
      this.pos = 0;
    }
    ensure(n) {
      if (this.pos + n <= this.buf.length) return;
      let len = this.buf.length * 2;
      while (len < this.pos + n) len *= 2;
      const nb = new Uint8Array(len);
      nb.set(this.buf.subarray(0, this.pos));
      this.buf = nb;
      this.view = new DataView(nb.buffer);
    }
    bytes() { return this.buf.slice(0, this.pos); }
    byte(v) { this.ensure(1); this.buf[this.pos++] = v & 0xff; return this; }
    bool(v) { return this.byte(v ? 1 : 0); }
    raw(arr) { this.ensure(arr.length); this.buf.set(arr, this.pos); this.pos += arr.length; return this; }
    short(v) { this.ensure(2); this.view.setUint16(this.pos, v & 0xffff, false); this.pos += 2; return this; }
    lshort(v) { this.ensure(2); this.view.setUint16(this.pos, v & 0xffff, true); this.pos += 2; return this; }
    int(v) { this.ensure(4); this.view.setInt32(this.pos, v | 0, false); this.pos += 4; return this; }
    lint(v) { this.ensure(4); this.view.setInt32(this.pos, v | 0, true); this.pos += 4; return this; }
    ltriad(v) { this.ensure(3); this.buf[this.pos++] = v & 0xff; this.buf[this.pos++] = (v >>> 8) & 0xff; this.buf[this.pos++] = (v >>> 16) & 0xff; return this; }
    long(v) { this.ensure(8); this.view.setBigInt64(this.pos, BigInt.asIntN(64, BigInt(v)), false); this.pos += 8; return this; }
    llong(v) { this.ensure(8); this.view.setBigInt64(this.pos, BigInt.asIntN(64, BigInt(v)), true); this.pos += 8; return this; }
    lfloat(v) { this.ensure(4); this.view.setFloat32(this.pos, v, true); this.pos += 4; return this; }
    uvarint(v) {
      v = Math.floor(v);
      if (v < 0) v += 4294967296;
      do {
        let b = v % 128;
        v = Math.floor(v / 128);
        if (v > 0) b |= 128;
        this.byte(b);
      } while (v > 0);
      return this;
    }
    varint(v) { v = v | 0; return this.uvarint(((v << 1) ^ (v >> 31)) >>> 0); }
    uvarlong(v) {
      let b = BigInt.asUintN(64, BigInt(v));
      do {
        let x = Number(b & 127n);
        b >>= 7n;
        if (b > 0n) x |= 128;
        this.byte(x);
      } while (b > 0n);
      return this;
    }
    varlong(v) {
      const b = BigInt.asIntN(64, BigInt(v));
      return this.uvarlong((b << 1n) ^ (b >> 63n));
    }
    bytearray(arr) { this.uvarint(arr.length); return this.raw(arr); }
    string(s) { return this.bytearray(enc.encode(s)); }
    vec3(x, y, z) { return this.lfloat(x).lfloat(y).lfloat(z); }
    blockcoords(x, y, z) { return this.varint(x).uvarint(y).varint(z); }
  }

  class BinaryReader {
    constructor(buf, pos) {
      this.buf = buf;
      this.view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
      this.pos = pos || 0;
    }
    eof() { return this.pos >= this.buf.length; }
    remaining() { return this.buf.length - this.pos; }
    check(n) { if (this.pos + n > this.buf.length) throw new Error('Неожиданный конец пакета'); }
    byte() { this.check(1); return this.buf[this.pos++]; }
    sbyte() { const v = this.byte(); return v > 127 ? v - 256 : v; }
    bool() { return this.byte() !== 0; }
    raw(n) { this.check(n); const r = this.buf.subarray(this.pos, this.pos + n); this.pos += n; return r; }
    rest() { const r = this.buf.subarray(this.pos); this.pos = this.buf.length; return r; }
    short() { this.check(2); const v = this.view.getUint16(this.pos, false); this.pos += 2; return v; }
    lshort() { this.check(2); const v = this.view.getUint16(this.pos, true); this.pos += 2; return v; }
    slshort() { this.check(2); const v = this.view.getInt16(this.pos, true); this.pos += 2; return v; }
    int() { this.check(4); const v = this.view.getInt32(this.pos, false); this.pos += 4; return v; }
    lint() { this.check(4); const v = this.view.getInt32(this.pos, true); this.pos += 4; return v; }
    ltriad() { this.check(3); const v = this.buf[this.pos] | (this.buf[this.pos + 1] << 8) | (this.buf[this.pos + 2] << 16); this.pos += 3; return v; }
    long() { this.check(8); const v = this.view.getBigInt64(this.pos, false); this.pos += 8; return v; }
    llong() { this.check(8); const v = this.view.getBigInt64(this.pos, true); this.pos += 8; return v; }
    lfloat() { this.check(4); const v = this.view.getFloat32(this.pos, true); this.pos += 4; return v; }
    uvarint() {
      let v = 0, mul = 1;
      for (let i = 0; i < 5; i++) {
        const b = this.byte();
        v += (b & 127) * mul;
        if (!(b & 128)) return v;
        mul *= 128;
      }
      throw new Error('VarInt слишком длинный');
    }
    varint() {
      const u = this.uvarint();
      return u % 2 === 0 ? u / 2 : -(u + 1) / 2;
    }
    uvarlong() {
      let v = 0n, shift = 0n;
      for (let i = 0; i < 10; i++) {
        const b = this.byte();
        v |= BigInt(b & 127) << shift;
        if (!(b & 128)) return v;
        shift += 7n;
      }
      throw new Error('VarLong слишком длинный');
    }
    varlong() {
      const u = this.uvarlong();
      const v = (u >> 1n) ^ -(u & 1n);
      return Number(v);
    }
    bytearray() { return this.raw(this.uvarint()); }
    string() { return dec.decode(this.bytearray()); }
    vec3() { return { x: this.lfloat(), y: this.lfloat(), z: this.lfloat() }; }
    blockcoords() { return { x: this.varint(), y: this.uvarint(), z: this.varint() }; }
  }

  MC.BinaryWriter = BinaryWriter;
  MC.BinaryReader = BinaryReader;
  MC.utf8 = { encode: (s) => enc.encode(s), decode: (b) => dec.decode(b) };
})();
