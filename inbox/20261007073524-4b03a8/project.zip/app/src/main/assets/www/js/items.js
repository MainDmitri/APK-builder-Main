// Предметы Minecraft PE 1.1: названия, иконки из атласа предметов APK и рисование иконок блоков
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const A = window.MC_ASSETS;
  const Blocks = MC.Blocks;

  const DYES = ['black', 'red', 'green', 'brown', 'blue', 'purple', 'cyan', 'silver', 'gray', 'pink', 'lime', 'yellow', 'light_blue', 'magenta', 'orange', 'white'];
  const DYES_RU = ['Чёрный', 'Красный', 'Зелёный', 'Коричневый', 'Синий', 'Фиолетовый', 'Бирюзовый', 'Светло-серый', 'Серый', 'Розовый', 'Лаймовый', 'Жёлтый', 'Голубой', 'Пурпурный', 'Оранжевый', 'Белый'];

  // id: [название, текстура | функция(data) -> текстура]
  const ITEMS = {
    256: ['Железная лопата', 'iron_shovel'], 257: ['Железная кирка', 'iron_pickaxe'], 258: ['Железный топор', 'iron_axe'],
    259: ['Огниво', 'flint_and_steel'], 260: ['Яблоко', 'apple'], 261: ['Лук', 'bow_standby'], 262: ['Стрела', 'arrow'],
    263: ['Уголь', (d) => (d === 1 ? 'charcoal' : 'coal')], 264: ['Алмаз', 'diamond'], 265: ['Железный слиток', 'iron_ingot'],
    266: ['Золотой слиток', 'gold_ingot'], 267: ['Железный меч', 'iron_sword'], 268: ['Деревянный меч', 'wood_sword'],
    269: ['Деревянная лопата', 'wood_shovel'], 270: ['Деревянная кирка', 'wood_pickaxe'], 271: ['Деревянный топор', 'wood_axe'],
    272: ['Каменный меч', 'stone_sword'], 273: ['Каменная лопата', 'stone_shovel'], 274: ['Каменная кирка', 'stone_pickaxe'],
    275: ['Каменный топор', 'stone_axe'], 276: ['Алмазный меч', 'diamond_sword'], 277: ['Алмазная лопата', 'diamond_shovel'],
    278: ['Алмазная кирка', 'diamond_pickaxe'], 279: ['Алмазный топор', 'diamond_axe'], 280: ['Палка', 'stick'], 281: ['Миска', 'bowl'],
    282: ['Грибной суп', 'mushroom_stew'], 283: ['Золотой меч', 'gold_sword'], 284: ['Золотая лопата', 'gold_shovel'],
    285: ['Золотая кирка', 'gold_pickaxe'], 286: ['Золотой топор', 'gold_axe'], 287: ['Нить', 'string'], 288: ['Перо', 'feather'],
    289: ['Порох', 'gunpowder'], 290: ['Деревянная мотыга', 'wood_hoe'], 291: ['Каменная мотыга', 'stone_hoe'], 292: ['Железная мотыга', 'iron_hoe'],
    293: ['Алмазная мотыга', 'diamond_hoe'], 294: ['Золотая мотыга', 'gold_hoe'], 295: ['Семена пшеницы', 'seeds_wheat'], 296: ['Пшеница', 'wheat'],
    297: ['Хлеб', 'bread'], 298: ['Кожаный шлем', 'leather_helmet'], 299: ['Кожаная куртка', 'leather_chestplate'], 300: ['Кожаные штаны', 'leather_leggings'],
    301: ['Кожаные ботинки', 'leather_boots'], 302: ['Кольчужный шлем', 'chainmail_helmet'], 303: ['Кольчужная кираса', 'chainmail_chestplate'],
    304: ['Кольчужные поножи', 'chainmail_leggings'], 305: ['Кольчужные ботинки', 'chainmail_boots'], 306: ['Железный шлем', 'iron_helmet'],
    307: ['Железная кираса', 'iron_chestplate'], 308: ['Железные поножи', 'iron_leggings'], 309: ['Железные ботинки', 'iron_boots'],
    310: ['Алмазный шлем', 'diamond_helmet'], 311: ['Алмазная кираса', 'diamond_chestplate'], 312: ['Алмазные поножи', 'diamond_leggings'],
    313: ['Алмазные ботинки', 'diamond_boots'], 314: ['Золотой шлем', 'gold_helmet'], 315: ['Золотая кираса', 'gold_chestplate'],
    316: ['Золотые поножи', 'gold_leggings'], 317: ['Золотые ботинки', 'gold_boots'], 318: ['Кремень', 'flint'], 319: ['Сырая свинина', 'porkchop_raw'],
    320: ['Жареная свинина', 'porkchop_cooked'], 321: ['Картина', 'painting'], 322: ['Золотое яблоко', 'apple_golden'], 323: ['Табличка', 'sign'],
    324: ['Дубовая дверь', 'door_wood'], 325: ['Ведро', (d) => (d === 1 ? 'bucket_milk' : d === 8 ? 'bucket_water' : d === 10 ? 'bucket_lava' : 'bucket_empty')],
    328: ['Вагонетка', 'minecart_normal'], 329: ['Седло', 'saddle'], 330: ['Железная дверь', 'door_iron'], 331: ['Редстоун', 'redstone_dust'],
    332: ['Снежок', 'snowball'], 333: ['Лодка', (d) => ['boat_oak', 'boat_spruce', 'boat_birch', 'boat_jungle', 'boat_acacia', 'boat_darkoak'][d] || 'boat_oak'],
    334: ['Кожа', 'leather'], 336: ['Кирпич', 'brick'], 337: ['Комок глины', 'clay_ball'], 338: ['Сахарный тростник', 'reeds'], 339: ['Бумага', 'paper'],
    340: ['Книга', 'book_normal'], 341: ['Слизь', 'slimeball'], 342: ['Вагонетка с сундуком', 'minecart_chest'], 344: ['Яйцо', 'egg'],
    345: ['Компас', 'compass_item'], 346: ['Удочка', 'fishing_rod_uncast'], 347: ['Часы', 'clock_item'], 348: ['Светопыль', 'glowstone_dust'],
    349: ['Сырая рыба', (d) => ['fish_raw', 'fish_salmon_raw', 'fish_clownfish_raw', 'fish_pufferfish_raw'][d] || 'fish_raw'],
    350: ['Жареная рыба', (d) => (d === 1 ? 'fish_salmon_cooked' : 'fish_cooked')], 351: ['Краситель', (d) => 'dye_powder_' + (DYES[d] || 'black')],
    352: ['Кость', 'bone'], 353: ['Сахар', 'sugar'], 354: ['Торт', 'cake'], 355: ['Кровать', (d) => 'bed_' + (Blocks.COLORS[d] || 'red')],
    356: ['Повторитель', 'repeater'], 357: ['Печенье', 'cookie'], 358: ['Карта', 'map_filled'], 359: ['Ножницы', 'shears'], 360: ['Ломтик арбуза', 'melon'],
    361: ['Семена тыквы', 'seeds_pumpkin'], 362: ['Семена арбуза', 'seeds_melon'], 363: ['Сырая говядина', 'beef_raw'], 364: ['Стейк', 'beef_cooked'],
    365: ['Сырая курица', 'chicken_raw'], 366: ['Жареная курица', 'chicken_cooked'], 367: ['Гнилая плоть', 'rotten_flesh'], 368: ['Жемчуг Края', 'ender_pearl'],
    369: ['Огненный стержень', 'blaze_rod'], 370: ['Слеза гаста', 'ghast_tear'], 371: ['Золотой самородок', 'gold_nugget'], 372: ['Адский нарост', 'nether_wart'],
    373: ['Зелье', 'potion_bottle_drinkable'], 374: ['Пузырёк', 'potion_bottle_empty'], 375: ['Паучий глаз', 'spider_eye'],
    376: ['Маринованный паучий глаз', 'spider_eye_fermented'], 377: ['Огненный порошок', 'blaze_powder'], 378: ['Сгусток магмы', 'magma_cream'],
    379: ['Варочная стойка', 'brewing_stand'], 380: ['Котёл', 'cauldron'], 381: ['Око Края', 'ender_eye'], 382: ['Сверкающий ломтик арбуза', 'melon_speckled'],
    383: ['Яйцо призыва', 'spawn_egg'], 384: ['Пузырёк опыта', 'experience_bottle'], 385: ['Огненный шар', 'fireball'], 386: ['Книга и перо', 'book_writable'],
    387: ['Написанная книга', 'book_written'], 388: ['Изумруд', 'emerald'], 389: ['Рамка', 'item_frame'], 390: ['Цветочный горшок', 'flower_pot'],
    391: ['Морковь', 'carrot'], 392: ['Картофель', 'potato'], 393: ['Печёный картофель', 'potato_baked'], 394: ['Ядовитый картофель', 'potato_poisonous'],
    395: ['Пустая карта', 'map_empty'], 396: ['Золотая морковь', 'carrot_golden'],
    397: ['Голова', (d) => ['skull_skeleton', 'skull_wither', 'skull_zombie', 'skull_steve', 'skull_creeper', 'skull_dragon'][d] || 'skull_skeleton'],
    398: ['Удочка с морковкой', 'carrot_on_a_stick'], 399: ['Звезда Нижнего мира', 'nether_star'], 400: ['Тыквенный пирог', 'pumpkin_pie'],
    403: ['Зачарованная книга', 'book_enchanted'], 404: ['Компаратор', 'comparator'], 405: ['Адский кирпич', 'netherbrick'], 406: ['Кварц', 'quartz'],
    407: ['Вагонетка с динамитом', 'minecart_tnt'], 408: ['Вагонетка с воронкой', 'minecart_hopper'], 409: ['Осколок призмарина', 'prismarine_shard'],
    410: ['Воронка', 'hopper'], 411: ['Сырая крольчатина', 'rabbit_raw'], 412: ['Жареная крольчатина', 'rabbit_cooked'], 413: ['Тушёный кролик', 'rabbit_stew'],
    414: ['Кроличья лапка', 'rabbit_foot'], 415: ['Кроличья шкурка', 'rabbit_hide'], 416: ['Кожаная конская броня', 'leather_horse_armor'],
    417: ['Железная конская броня', 'iron_horse_armor'], 418: ['Золотая конская броня', 'gold_horse_armor'], 419: ['Алмазная конская броня', 'diamond_horse_armor'],
    420: ['Поводок', 'lead'], 421: ['Бирка', 'name_tag'], 422: ['Кристаллы призмарина', 'prismarine_crystals'], 423: ['Сырая баранина', 'mutton_raw'],
    424: ['Жареная баранина', 'mutton_cooked'], 426: ['Кристалл Края', 'end_crystal'], 427: ['Еловая дверь', 'door_spruce'], 428: ['Берёзовая дверь', 'door_birch'],
    429: ['Тропическая дверь', 'door_jungle'], 430: ['Дверь из акации', 'door_acacia'], 431: ['Дверь из тёмного дуба', 'door_dark_oak'],
    432: ['Плод хоруса', 'chorus_fruit'], 433: ['Приготовленный плод хоруса', 'chorus_fruit_popped'], 437: ['Драконье дыхание', 'dragons_breath'],
    438: ['Взрывное зелье', 'potion_bottle_splash'], 441: ['Оседающее зелье', 'potion_bottle_lingering'], 444: ['Элитры', 'elytra'],
    445: ['Панцирь шалкера', 'shulker_shell'], 450: ['Тотем бессмертия', 'totem'], 452: ['Железный самородок', 'iron_nugget'], 457: ['Свёкла', 'beetroot'],
    458: ['Семена свёклы', 'seeds_beetroot'], 459: ['Свекольный суп', 'beetroot_soup'], 460: ['Сырой лосось', 'fish_salmon_raw'],
    461: ['Тропическая рыба', 'fish_clownfish_raw'], 462: ['Иглобрюх', 'fish_pufferfish_raw'], 463: ['Жареный лосось', 'fish_salmon_cooked'],
    466: ['Зачарованное золотое яблоко', 'apple_golden'],
    500: ['Пластинка', 'record_13'], 501: ['Пластинка', 'record_cat'], 502: ['Пластинка', 'record_blocks'], 503: ['Пластинка', 'record_chirp'],
    504: ['Пластинка', 'record_far'], 505: ['Пластинка', 'record_mall'], 506: ['Пластинка', 'record_mellohi'], 507: ['Пластинка', 'record_stal'],
    508: ['Пластинка', 'record_strad'], 509: ['Пластинка', 'record_ward'], 510: ['Пластинка', 'record_11'], 511: ['Пластинка', 'record_wait']
  };

  // Какие предметы ставят блок (для мгновенного отображения установки)
  const PLACES = { 324: [64, 0], 330: [71, 0], 427: [193, 0], 428: [194, 0], 429: [195, 0], 430: [196, 0], 431: [197, 0], 338: [83, 0],
    354: [92, 0], 331: [55, 0], 356: [93, 0], 404: [149, 0], 379: [117, 0], 380: [118, 0], 390: [140, 0], 295: [59, 0], 361: [104, 0],
    362: [105, 0], 391: [141, 0], 392: [142, 0], 458: [244, 0], 372: [115, 0], 410: [154, 0] };

  function itemName(id, data) {
    if (id < 256) {
      if (id === 0) return '';
      if (id === 51 && data === 1) return 'Огонь';
      return Blocks.displayName(id, data);
    }
    const it = ITEMS[id];
    if (!it) return 'Предмет #' + id;
    if (id === 351) return DYES_RU[data] ? DYES_RU[data] + ' краситель' : it[0];
    return it[0];
  }

  function itemTexture(id, data) {
    const it = ITEMS[id];
    if (!it) return null;
    const name = typeof it[1] === 'function' ? it[1](data) : it[1];
    return A.itemTiles[name] !== undefined ? A.itemTiles[name] : null;
  }

  // ---------- Иконки: изометрический куб для блоков, плоская картинка для остальных ----------
  const iconCache = new Map();
  let blockImg = null, itemImg = null;

  function loadImages() {
    return Promise.all([A.blockAtlas, A.itemAtlas].map((src) => new Promise((res, rej) => {
      const im = new Image();
      im.onload = () => res(im);
      im.onerror = () => rej(new Error('Не удалось загрузить атлас текстур'));
      im.src = src;
    }))).then(([b, i]) => { blockImg = b; itemImg = i; });
  }

  function tileXY(index, grid) { return [(index % grid) * 16, Math.floor(index / grid) * 16]; }

  function drawFace(ctx, img, grid, tile, transform, shade) {
    const [sx, sy] = tileXY(tile, grid);
    ctx.save();
    ctx.setTransform(transform[0], transform[1], transform[2], transform[3], transform[4], transform[5]);
    ctx.drawImage(img, sx, sy, 16, 16, 0, 0, 16, 16);
    if (shade < 1) {
      ctx.globalCompositeOperation = 'source-atop';
      ctx.fillStyle = 'rgba(0,0,0,' + (1 - shade) + ')';
      ctx.fillRect(0, 0, 16, 16);
    }
    ctx.restore();
  }

  function icon(id, data) {
    const key = id + ':' + data;
    if (iconCache.has(key)) return iconCache.get(key);
    const c = document.createElement('canvas');
    c.width = 32;
    c.height = 32;
    const ctx = c.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    let url = '';
    if (id > 0 && id < 256 && blockImg) {
      const b = Blocks.list[id];
      const flat = b.shape === 'cross' || b.shape === 'crop' || b.shape === 'torch' || b.shape === 'flat' || id === 65 || id === 106 || id === 101 || id === 102 || id === 160;
      const d = b.variants > 1 ? data : data & 0;
      if (flat) {
        const [sx, sy] = tileXY(b.tex(d, 2), A.blockGrid);
        ctx.drawImage(blockImg, sx, sy, 16, 16, 0, 0, 32, 32);
      } else {
        const tmp = document.createElement('canvas');
        tmp.width = 32;
        tmp.height = 32;
        const t = tmp.getContext('2d');
        t.imageSmoothingEnabled = false;
        // Верх, левая (юг) и правая (восток) грани в изометрии
        drawFace(t, blockImg, A.blockGrid, b.tex(d, 1), [1, 0.5, -1, 0.5, 16, 0], 1);
        drawFace(t, blockImg, A.blockGrid, b.tex(d, 3), [1, 0.5, 0, 1, 0, 8], 0.8);
        drawFace(t, blockImg, A.blockGrid, b.tex(d, 5), [1, -0.5, 0, 1, 16, 16], 0.6);
        ctx.drawImage(tmp, 0, 0);
      }
      url = c.toDataURL();
    } else if (id >= 256 && itemImg) {
      const tile = itemTexture(id, data);
      if (tile !== null) {
        const [sx, sy] = tileXY(tile, A.itemGrid);
        ctx.drawImage(itemImg, sx, sy, 16, 16, 0, 0, 32, 32);
      } else {
        const [sx, sy] = tileXY(Blocks.MISSING, A.blockGrid);
        ctx.drawImage(blockImg, sx, sy, 16, 16, 0, 0, 32, 32);
      }
      url = c.toDataURL();
    }
    iconCache.set(key, url);
    return url;
  }

  // Набор предметов для одиночной игры (творческий режим)
  function creativeList() {
    const list = [];
    // Пропускаем только технические блоки, жидкости, активные дубли (горящая печь, лампа вкл и т. п.)
    // и блоки, которые ставятся предметом (двери, грядки, проводка и т. д.) — они уже есть как предметы
    const skip = new Set([0, 8, 9, 10, 11, 26, 34, 36, 51, 55, 59, 62, 63, 64, 68, 71, 74, 75, 83, 90, 92, 93, 94, 95, 104, 105, 115, 117, 118, 120, 124, 127, 132, 140, 141, 142, 144, 149, 150, 154, 193, 194, 195, 196, 197, 199, 210, 211, 212, 244, 247, 252]);
    for (let id = 1; id < 256; id++) {
      if (skip.has(id)) continue;
      const b = Blocks.list[id];
      if (b.name.startsWith('Блок #')) continue;
      const n = b.variants || 1;
      for (let d = 0; d < n; d++) list.push({ id, data: d, count: 64 });
    }
    // Предметы: инструменты, еда, броня, элитры, жемчуг Края и прочее; красители — все 16 цветов
    for (const key of Object.keys(ITEMS)) {
      const id = +key;
      if (id < 256) continue;
      const it = ITEMS[id];
      if (typeof it[1] === 'function') {
        if (id === 351) { for (let d = 0; d < 16; d++) list.push({ id, data: d, count: 64 }); } else if (A.itemTiles[it[1](0)] !== undefined) list.push({ id, data: 0, count: 64 });
      } else if (A.itemTiles[it[1]] !== undefined) {
        list.push({ id, data: 0, count: 64 });
      }
    }
    return list;
  }

  MC.Items = { itemName, itemTexture, icon, loadImages, creativeList, PLACES };
})();
