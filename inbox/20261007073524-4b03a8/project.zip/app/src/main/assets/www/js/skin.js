// Скин игрока: стандартный — Стив из ресурсов APK, свой загружается из PNG 64x32 / 64x64
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  let cached = null;

  // Стандартный скин — steve.png из ресурсов игры (64x64)
  function defaultSkin() {
    if (!cached) cached = fromBase64(window.MC_ASSETS.steveSkin);
    return cached;
  }

  function loadSkinFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('Не удалось прочитать файл'));
      reader.onload = () => {
        const im = new Image();
        im.onerror = () => reject(new Error('Файл не является изображением PNG'));
        im.onload = () => {
          if (im.width !== 64 || (im.height !== 32 && im.height !== 64)) {
            reject(new Error('Скин должен быть 64x32 или 64x64 пикселя, а этот ' + im.width + 'x' + im.height));
            return;
          }
          const c = document.createElement('canvas');
          c.width = 64;
          c.height = im.height;
          const g = c.getContext('2d');
          g.drawImage(im, 0, 0);
          resolve(new Uint8Array(g.getImageData(0, 0, 64, im.height).data.buffer.slice(0)));
        };
        im.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  function toBase64(bytes) {
    let s = '';
    for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(s);
  }

  function fromBase64(str) {
    const s = atob(str);
    const out = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
    return out;
  }

  // Превью лица скина для меню настроек
  function facePreview(rgba) {
    const h = rgba.length === 16384 ? 64 : 32;
    const c = document.createElement('canvas');
    c.width = 64;
    c.height = h;
    c.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(rgba), 64, h), 0, 0);
    const out = document.createElement('canvas');
    out.width = 64;
    out.height = 64;
    const g = out.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.drawImage(c, 8, 8, 8, 8, 0, 0, 64, 64);
    g.drawImage(c, 40, 8, 8, 8, 0, 0, 64, 64);
    return out.toDataURL();
  }

  MC.Skin = { defaultSkin, loadSkinFile, toBase64, fromBase64, facePreview };
})();
