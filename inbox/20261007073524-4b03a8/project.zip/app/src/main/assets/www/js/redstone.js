// Механика одиночной игры: падающие блоки (песок/гравий), поршни и простой редстоун (рычаг, кнопка,
// редстоуновый блок/факел, провод), лампы. Реагирует на изменения блоков в мире через очередь.
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const Blocks = MC.Blocks;

  const DIR = [[0, -1, 0], [0, 1, 0], [0, 0, -1], [0, 0, 1], [-1, 0, 0], [1, 0, 0]];

  // Блоки, которые падают, если под ними нет опоры
  const FALLING = new Set([12, 13, 145, 237]);
  // Блок-энтити и прочее, что поршень не может сдвинуть
  const TILE = new Set([23, 25, 52, 54, 58, 61, 62, 63, 68, 84, 116, 117, 118, 125, 130, 138, 145, 146, 154, 84, 26, 116]);
  const PISTONS = new Set([29, 33]);

  function isEmpty(id) {
    if (id === 0) return true;
    return !!Blocks.list[id].replaceable;
  }

  function immovable(id, data) {
    if (id === 0) return false;
    const b = Blocks.list[id];
    if (b.hardness < 0 || b.hardness >= 50) return true; // коренная порода, обсидиан, портал и т. п.
    if (TILE.has(id)) return true;
    if (id === 34) return true;                 // головка поршня
    if (PISTONS.has(id) && (data & 8)) return true; // выдвинутый поршень
    return false;
  }

  // Прочная опора снизу: блок падает, если под ним пусто или неполный блок
  function supported(w, x, y, z) {
    const id = w.getId(x, y - 1, z);
    if (id === 0) return false;
    const b = Blocks.list[id];
    if (b.liquid || b.replaceable) return false;
    if (b.shape === 'cross' || b.shape === 'crop' || b.shape === 'flat' || b.shape === 'torch' || b.shape === 'none') return false;
    return true;
  }

  class Mechanics {
    constructor(game) {
      this.game = game;
      this.world = game.world;
      this.pending = new Set();
      this.buttons = []; // {x,y,z,id,t}
    }

    key(x, y, z) { return x + ',' + y + ',' + z; }

    // Поставить блок в очередь вместе с соседями (изменение блока влияет на них)
    mark(x, y, z) {
      this.pending.add(this.key(x, y, z));
      for (const d of DIR) this.pending.add(this.key(x + d[0], y + d[1], z + d[2]));
      this.pending.add(this.key(x, y + 1, z)); // падение блока сверху
      this.pending.add(this.key(x, y - 1, z));
    }

    // Нажатие кнопки: выдаёт сигнал и возвращается через время
    pressButton(x, y, z, id) {
      this.world.setBlock(x, y, z, id, this.world.getData(x, y, z) | 8);
      this.buttons.push({ x, y, z, id, t: id === 143 ? 1.5 : 1.0 });
      MC.Sound.play('random.click', { x: x + 0.5, y: y + 0.5, z: z + 0.5 }, 0.3, 0.6);
      this.mark(x, y, z);
    }

    // Переключатель рычага
    toggleLever(x, y, z) {
      const nd = this.world.getData(x, y, z) ^ 8;
      this.world.setBlock(x, y, z, 69, nd);
      MC.Sound.play('random.click', { x: x + 0.5, y: y + 0.5, z: z + 0.5 }, 0.3, nd & 8 ? 0.6 : 0.5);
      this.mark(x, y, z);
    }

    hardSource(id, data) {
      if (id === 152 || id === 76) return true;        // редстоуновый блок, факел (включён)
      if (id === 69 && (data & 8)) return true;         // рычаг включён
      if ((id === 77 || id === 143) && (data & 8)) return true; // кнопка нажата
      return false;
    }

    // Уровень сигнала в проводе: разлив от источников по сети провода, затухание 1 на блок (макс 15)
    wireNetwork(sx, sy, sz) {
      const w = this.world, seen = new Map(), order = [];
      const stack = [[sx, sy, sz]];
      seen.set(this.key(sx, sy, sz), 0);
      while (stack.length && seen.size < 2000) {
        const [x, y, z] = stack.pop();
        order.push([x, y, z]);
        // соседи-провода: по горизонтали и по диагонали вверх/вниз (как в Minecraft)
        const hor = [[1, 0], [-1, 0], [0, 1], [0, -1]];
        for (const [dx, dz] of hor) {
          const cand = [[x + dx, y, z + dz], [x + dx, y + 1, z + dz], [x + dx, y - 1, z + dz]];
          for (const [nx, ny, nz] of cand) {
            if (w.getId(nx, ny, nz) !== 55) continue;
            const k = this.key(nx, ny, nz);
            if (seen.has(k)) continue;
            seen.set(k, 0);
            stack.push([nx, ny, nz]);
          }
        }
      }
      // источники: провод рядом с источником получает 15
      const power = new Map();
      const q = [];
      for (const [x, y, z] of order) {
        let p = 0;
        for (const d of DIR) {
          const id = w.getId(x + d[0], y + d[1], z + d[2]);
          if (this.hardSource(id, w.getData(x + d[0], y + d[1], z + d[2]))) { p = 15; break; }
        }
        if (p > 0) { power.set(this.key(x, y, z), 15); q.push([x, y, z, 15]); }
      }
      // затухание по сети
      while (q.length) {
        const [x, y, z, lv] = q.shift();
        if (lv <= 1) continue;
        const hor = [[1, 0], [-1, 0], [0, 1], [0, -1]];
        for (const [dx, dz] of hor) {
          const cand = [[x + dx, y, z + dz], [x + dx, y + 1, z + dz], [x + dx, y - 1, z + dz]];
          for (const [nx, ny, nz] of cand) {
            const k = this.key(nx, ny, nz);
            if (!seen.has(k)) continue;
            if ((power.get(k) || 0) >= lv - 1) continue;
            power.set(k, lv - 1);
            q.push([nx, ny, nz, lv - 1]);
          }
        }
      }
      return { cells: order, power };
    }

    wirePowerAt(x, y, z) {
      const net = this.wireNetwork(x, y, z);
      return net.power.get(this.key(x, y, z)) || 0;
    }

    // Блок (непрозрачный) запитан, если рядом источник или провод с сигналом
    blockPowered(x, y, z) {
      const w = this.world;
      for (const d of DIR) {
        const nx = x + d[0], ny = y + d[1], nz = z + d[2];
        const id = w.getId(nx, ny, nz);
        if (this.hardSource(id, w.getData(nx, ny, nz))) return true;
        if (id === 76 && d[1] === -1) return true; // факел снизу запитывает блок
        if (id === 55 && this.wirePowerAt(nx, ny, nz) > 0) return true;
      }
      return false;
    }

    pistonPowered(x, y, z) {
      const w = this.world;
      for (const d of DIR) {
        const nx = x + d[0], ny = y + d[1], nz = z + d[2];
        const id = w.getId(nx, ny, nz);
        if (this.hardSource(id, w.getData(nx, ny, nz))) return true;
        if (id === 55 && this.wirePowerAt(nx, ny, nz) > 0) return true;
        const b = Blocks.list[id];
        if (b.opaque && this.blockPowered(nx, ny, nz)) return true; // косвенное питание через блок
      }
      return false;
    }

    extendPiston(x, y, z, id, facing) {
      const w = this.world, d = DIR[facing];
      const chain = [];
      let cx = x + d[0], cy = y + d[1], cz = z + d[2];
      for (let i = 0; i <= 12; i++) {
        const bid = w.getId(cx, cy, cz);
        if (isEmpty(bid)) break;
        if (immovable(bid, w.getData(cx, cy, cz)) || i >= 12) return false;
        chain.push({ x: cx, y: cy, z: cz, id: bid, data: w.getData(cx, cy, cz) });
        cx += d[0]; cy += d[1]; cz += d[2];
      }
      if (cy < 0 || cy > 255) return false;
      for (let k = chain.length - 1; k >= 0; k--) {
        const c = chain[k];
        w.setBlock(c.x + d[0], c.y + d[1], c.z + d[2], c.id, c.data);
        w.setBlock(c.x, c.y, c.z, 0, 0);
      }
      w.setBlock(x + d[0], y + d[1], z + d[2], 34, facing);
      w.setBlock(x, y, z, id, facing | 8);
      MC.Sound.play('tile.piston.out', { x: x + 0.5, y: y + 0.5, z: z + 0.5 }, 0.5, 0.75);
      return true;
    }

    retractPiston(x, y, z, id, facing) {
      const w = this.world, d = DIR[facing];
      const hx = x + d[0], hy = y + d[1], hz = z + d[2];
      if (w.getId(hx, hy, hz) === 34) w.setBlock(hx, hy, hz, 0, 0);
      w.setBlock(x, y, z, id, facing);
      if (id === 29) { // липкий поршень тянет блок за собой
        const px = hx + d[0], py = hy + d[1], pz = hz + d[2];
        const pid = w.getId(px, py, pz);
        if (!isEmpty(pid) && !immovable(pid, w.getData(px, py, pz))) {
          w.setBlock(hx, hy, hz, pid, w.getData(px, py, pz));
          w.setBlock(px, py, pz, 0, 0);
        }
      }
      MC.Sound.play('tile.piston.in', { x: x + 0.5, y: y + 0.5, z: z + 0.5 }, 0.5, 0.7);
    }

    evaluate(x, y, z) {
      const w = this.world;
      const id = w.getId(x, y, z), data = w.getData(x, y, z);
      if (id === 0) return;
      // Падающие блоки
      if (FALLING.has(id) && !supported(w, x, y, z) && y > 0) {
        w.setBlock(x, y, z, 0, 0);
        this.game.ents.spawnFalling(x, y, z, id, data);
        return;
      }
      // Поршни
      if (PISTONS.has(id)) {
        const facing = data & 7;
        const ext = (data & 8) !== 0;
        const on = this.pistonPowered(x, y, z);
        if (on && !ext) this.extendPiston(x, y, z, id, facing);
        else if (!on && ext) this.retractPiston(x, y, z, id, facing);
        return;
      }
      // Лампа: включается при питании
      if (id === 123 && this.blockPowered(x, y, z)) w.setBlock(x, y, z, 124, data);
      else if (id === 124 && !this.blockPowered(x, y, z)) w.setBlock(x, y, z, 123, data);
    }

    // Источник или провод изменился — обновить поршни/лампы у всей сети провода
    spreadFrom(x, y, z) {
      const w = this.world;
      const id = w.getId(x, y, z);
      let wires = [[x, y, z]];
      if (id === 55) wires = this.wireNetwork(x, y, z).cells;
      for (const [wx, wy, wz] of wires) {
        for (const d of DIR) {
          const nx = wx + d[0], ny = wy + d[1], nz = wz + d[2];
          const nid = w.getId(nx, ny, nz);
          if (PISTONS.has(nid) || nid === 123 || nid === 124) this.pending.add(this.key(nx, ny, nz));
          // косвенно запитанный блок рядом с поршнем
          if (Blocks.list[nid] && Blocks.list[nid].opaque) {
            for (const d2 of DIR) {
              const mx = nx + d2[0], my = ny + d2[1], mz = nz + d2[2];
              const mid = w.getId(mx, my, mz);
              if (PISTONS.has(mid) || mid === 123 || mid === 124) this.pending.add(this.key(mx, my, mz));
            }
          }
        }
      }
    }

    update(dt) {
      // кнопки возвращаются обратно
      for (let i = this.buttons.length - 1; i >= 0; i--) {
        const b = this.buttons[i];
        b.t -= dt;
        if (b.t <= 0) {
          if (this.world.getId(b.x, b.y, b.z) === b.id) {
            this.world.setBlock(b.x, b.y, b.z, b.id, this.world.getData(b.x, b.y, b.z) & ~8);
            MC.Sound.play('random.click', { x: b.x + 0.5, y: b.y + 0.5, z: b.z + 0.5 }, 0.3, 0.5);
            this.mark(b.x, b.y, b.z);
          }
          this.buttons.splice(i, 1);
        }
      }
      if (!this.pending.size) return;
      // источники/провода распространяют сигнал по сети
      const w = this.world;
      for (const k of Array.from(this.pending)) {
        const [x, y, z] = k.split(',').map(Number);
        const id = w.getId(x, y, z);
        if (id === 55 || this.hardSource(id, w.getData(x, y, z))) this.spreadFrom(x, y, z);
      }
      let ops = 0;
      while (this.pending.size && ops < 8192) {
        const k = this.pending.values().next().value;
        this.pending.delete(k);
        ops++;
        const [x, y, z] = k.split(',').map(Number);
        this.evaluate(x, y, z);
      }
    }
  }

  MC.Mechanics = Mechanics;
})();
