// Перевод сообщений сервера (ключи языка Minecraft PE) и разбор цветовых кодов §
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  const STRINGS = {
    'multiplayer.player.joined': '%s присоединился к игре',
    'multiplayer.player.left': '%s покинул игру',
    'chat.type.text': '<%s> %s',
    'chat.type.emote': '* %s %s',
    'chat.type.announcement': '[%s] %s',
    'commands.generic.permission': 'У вас нет прав на эту команду',
    'commands.generic.notFound': 'Неизвестная команда. Введите /help для списка команд',
    'commands.generic.unknown': 'Неизвестная команда: %s',
    'commands.generic.usage': 'Использование: %s',
    'commands.generic.player.notFound': 'Игрок не найден',
    'commands.players.list': 'Сейчас на сервере %s/%s игроков:',
    'disconnectionScreen.serverFull': 'Сервер переполнен',
    'disconnectionScreen.outdatedClient': 'Клиент устарел',
    'disconnectionScreen.outdatedServer': 'Сервер устарел',
    'disconnectionScreen.invalidName': 'Недопустимый ник (3-16 символов: латиница, цифры, _ и пробел)',
    'disconnectionScreen.invalidSkin': 'Недопустимый скин',
    'disconnectionScreen.noReason': 'Отключено сервером',
    'disconnectionScreen.notAuthenticated': 'Нужен вход через Xbox Live',
    'disconnectionScreen.loggedinOtherLocation': 'Вы вошли с другого устройства',
    'disconnectionScreen.resourcePack': 'Ошибка набора ресурсов',
    'disconnectionScreen.timeout': 'Превышено время ожидания',
    'disconnectionScreen.kicked': 'Вас выгнали с сервера',
    'disconnectionScreen.serverIdConflict': 'Конфликт идентификатора сервера',
    'death.attack.generic': '%s умер',
    'death.attack.fall': '%s разбился',
    'death.attack.player': '%s убит игроком %s',
    'death.attack.mob': '%s убит мобом %s',
    'death.attack.lava': '%s решил поплавать в лаве',
    'death.attack.drown': '%s утонул',
    'death.attack.outOfWorld': '%s выпал из мира',
    'death.attack.inFire': '%s сгорел',
    'death.attack.onFire': '%s сгорел заживо',
    'death.attack.explosion': '%s взорвался',
    'death.attack.explosion.player': '%s взорван игроком %s',
    'death.attack.cactus': '%s исколот кактусом',
    'death.attack.starve': '%s умер от голода',
    'death.attack.inWall': '%s задохнулся в стене',
    'death.attack.magic': '%s убит магией',
    'death.fell.accident.generic': '%s разбился',
    'tile.bed.noSleep': 'Спать можно только ночью',
    'gameMode.survival': 'Выживание',
    'gameMode.creative': 'Творческий',
    'gameMode.adventure': 'Приключение',
    'gameMode.spectator': 'Наблюдатель',
    'gameMode.changed': 'Режим игры изменён',
    'commands.gamemode.success.self': 'Ваш режим игры: %s',
    'commands.gamemode.success.other': 'Режим игры игрока %2$s: %1$s',
    'commands.time.set': 'Время установлено: %s',
    'commands.time.added': 'Ко времени добавлено %s',
    'commands.tp.success': '%s телепортирован к %s',
    'commands.tp.success.coordinates': '%s телепортирован на %s, %s, %s',
    'commands.give.success': 'Выдано %s x %s игроку %s',
    'commands.kill.successful': '%s убит',
    'commands.op.success': '%s теперь оператор',
    'commands.deop.success': '%s больше не оператор',
    'commands.weather.clear': 'Погода: ясно',
    'commands.weather.rain': 'Погода: дождь',
    'commands.weather.thunder': 'Погода: гроза',
    'commands.spawnpoint.success': 'Точка возрождения %s: %s, %s, %s',
    'commands.difficulty.success': 'Сложность: %s',
    'commands.generic.exception': 'Ошибка при выполнении команды',
    'commands.generic.num.invalid': 'Неверное число: %s',
    'commands.generic.syntax': 'Ошибка синтаксиса команды',
    'commands.help.header': 'Справка (страница %s из %s):',
    'commands.effect.success': 'Эффект %s (ID %s) уровня %s выдан игроку %s на %s сек.',
    'commands.effect.success.removed': 'Эффект %s снят с игрока %s',
    'potion.hunger': 'Голод',
    'potion.moveSpeed': 'Скорость',
    'potion.regeneration': 'Регенерация',
    'potion.damageBoost': 'Сила',
    'potion.heal': 'Исцеление',
    'potion.jump': 'Прыгучесть',
    'potion.fireResistance': 'Огнестойкость',
    'potion.waterBreathing': 'Подводное дыхание',
    'potion.invisibility': 'Невидимость',
    'potion.nightVision': 'Ночное зрение',
    'potion.poison': 'Отравление',
    'kick.reason.cheat': 'Обнаружен чит: %s'
  };

  function translate(msg, params) {
    params = params || [];
    msg = String(msg);
    const m = msg.match(/^((?:§.)*)%?([a-zA-Z0-9_]+\.[a-zA-Z0-9_.]+)$/);
    if (m) {
      if (STRINGS[m[2]]) return m[1] + fill(STRINGS[m[2]], params);
      return m[1] + m[2] + (params.length ? ': ' + params.map((p) => translate(p)).join(', ') : '');
    }
    // Ключи внутри строки вида "§e%multiplayer.player.joined" и шаблоны с %s
    const replaced = msg.replace(/%([a-zA-Z0-9_]+\.[a-zA-Z0-9_.]+)/g, (all, k) => (STRINGS[k] ? fill(STRINGS[k], params) : k));
    return /%(\d\$)?s/.test(replaced) ? fill(replaced, params) : replaced;
  }

  function fill(tpl, params) {
    let i = 0;
    return tpl.replace(/%(\d\$)?s/g, (all, idx) => {
      if (idx) return params[parseInt(idx, 10) - 1] !== undefined ? MC.translate(params[parseInt(idx, 10) - 1]) : '';
      const p = params[i++];
      return p !== undefined ? MC.translate(String(p)) : '';
    });
  }

  const COLORS = { 0: '#000000', 1: '#0000aa', 2: '#00aa00', 3: '#00aaaa', 4: '#aa0000', 5: '#aa00aa', 6: '#ffaa00', 7: '#aaaaaa', 8: '#555555', 9: '#5555ff', a: '#55ff55', b: '#55ffff', c: '#ff5555', d: '#ff55ff', e: '#ffff55', f: '#ffffff' };

  // Текст с кодами § -> DOM-фрагмент
  function formatted(text) {
    const frag = document.createDocumentFragment();
    let color = null, bold = false, italic = false;
    const parts = String(text).split('§');
    parts.forEach((part, i) => {
      let t = part;
      if (i > 0 && part.length) {
        const code = part[0].toLowerCase();
        t = part.slice(1);
        if (COLORS[code]) { color = COLORS[code]; bold = false; italic = false; }
        else if (code === 'l') bold = true;
        else if (code === 'o') italic = true;
        else if (code === 'r') { color = null; bold = false; italic = false; }
      }
      if (!t) return;
      const span = document.createElement('span');
      span.textContent = t;
      if (color) span.style.color = color;
      if (bold) span.style.fontWeight = 'bold';
      if (italic) span.style.fontStyle = 'italic';
      frag.appendChild(span);
    });
    return frag;
  }

  const strip = (text) => String(text).replace(/§./g, '');

  MC.translate = translate;
  MC.formatted = formatted;
  MC.stripColors = strip;
})();
