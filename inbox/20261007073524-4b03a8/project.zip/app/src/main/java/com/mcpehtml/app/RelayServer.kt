package com.mcpehtml.app

import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

/**
 * Встроенный ретранслятор WebSocket <-> UDP, точная копия relay/relay.js.
 * Слушает только 127.0.0.1, поэтому снаружи телефона недоступен.
 * Протокол: первое текстовое сообщение {"type":"connect","host":"...","port":19132},
 * ответ {"type":"ready",...} или {"type":"error","message":"..."}; дальше каждое бинарное
 * сообщение равно одной UDP-датаграмме в обе стороны.
 */
class RelayServer(port: Int) : WebSocketServer(InetSocketAddress("127.0.0.1", port)) {

    private class Session(val udp: DatagramSocket, val target: InetSocketAddress) {
        @Volatile var closed = false
        fun close() {
            closed = true
            try { udp.close() } catch (e: Exception) {}
        }
    }

    private val sessions = ConcurrentHashMap<WebSocket, Session>()
    private val pending = ConcurrentHashMap.newKeySet<WebSocket>()

    init {
        isReuseAddr = true
        connectionLostTimeout = 0
    }

    override fun onStart() {}

    override fun onOpen(conn: WebSocket, handshake: ClientHandshake) {}

    override fun onClose(conn: WebSocket, code: Int, reason: String, remote: Boolean) {
        pending.remove(conn)
        sessions.remove(conn)?.close()
    }

    override fun onError(conn: WebSocket?, ex: Exception) {
        if (conn != null) {
            sessions.remove(conn)?.close()
            try { conn.close() } catch (e: Exception) {}
        }
    }

    override fun onMessage(conn: WebSocket, message: String) {
        if (sessions.containsKey(conn) || !pending.add(conn)) return
        val msg = try { JSONObject(message) } catch (e: Exception) { conn.close(); return }
        if (msg.optString("type") != "connect" || !msg.has("host")) { conn.close(); return }
        val host = msg.optString("host").trim()
        val port = msg.optInt("port", 0)
        if (port <= 0 || port >= 65536) {
            sendJson(conn, "error", "Неверный порт")
            conn.close()
            return
        }
        thread(name = "relay-connect") {
            try {
                val address = InetAddress.getByName(host)
                if (!conn.isOpen) return@thread
                val udp = DatagramSocket()
                val session = Session(udp, InetSocketAddress(address, port))
                sessions[conn] = session
                thread(name = "relay-udp") { pump(conn, session) }
                val family = if (address.address.size == 16) 6 else 4
                val ready = JSONObject()
                ready.put("type", "ready")
                ready.put("address", address.hostAddress)
                ready.put("port", port)
                ready.put("family", family)
                conn.send(ready.toString())
            } catch (e: Exception) {
                if (conn.isOpen) {
                    sendJson(conn, "error", "Не удалось найти адрес $host")
                    conn.close()
                }
            }
        }
    }

    override fun onMessage(conn: WebSocket, message: ByteBuffer) {
        val session = sessions[conn] ?: return
        val bytes = ByteArray(message.remaining())
        message.get(bytes)
        try {
            session.udp.send(DatagramPacket(bytes, bytes.size, session.target))
        } catch (e: Exception) {
            if (!session.closed && conn.isOpen) {
                sendJson(conn, "error", e.message ?: "UDP")
                conn.close()
            }
        }
    }

    // Чтение UDP-датаграмм от сервера и пересылка их в WebSocket
    private fun pump(conn: WebSocket, session: Session) {
        val buf = ByteArray(65536)
        val packet = DatagramPacket(buf, buf.size)
        while (!session.closed) {
            try {
                session.udp.receive(packet)
            } catch (e: Exception) {
                if (!session.closed && conn.isOpen) {
                    sendJson(conn, "error", e.message ?: "UDP")
                    conn.close()
                }
                return
            }
            if (packet.port != session.target.port) continue
            if (!conn.isOpen) return
            conn.send(ByteBuffer.wrap(packet.data.copyOf(packet.length)))
        }
    }

    private fun sendJson(conn: WebSocket, type: String, message: String) {
        val o = JSONObject()
        o.put("type", type)
        o.put("message", message)
        try { conn.send(o.toString()) } catch (e: Exception) {}
    }

    fun shutdown() {
        for (s in sessions.values) s.close()
        sessions.clear()
        try { stop(500) } catch (e: Exception) {}
    }
}
