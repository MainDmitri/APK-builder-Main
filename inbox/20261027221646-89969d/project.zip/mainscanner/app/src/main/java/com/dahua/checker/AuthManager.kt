package com.dahua.checker

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class UserInfo(
    val nickname: String,
    val code: String,
    val activatedAt: Long,
    val deviceId: String = ""
)

object AuthManager {

    // ─── Один бот на всё — MainScanerCheckbot (serverless) ───────────────────
    private const val BOT_TOKEN = "9052071852:AAH1aDSEYJUpx2-pZGr4l432Hf3kXSDgXEY"
    private const val BOT_API   = "https://api.telegram.org/bot$BOT_TOKEN"
    private const val ADMIN_CHAT_ID = "6365916323"

    private const val SECRET_KEY = "MainDmitri_secret_2024_xK9m"

    private const val PREFS_NAME    = "ms_auth_x7k"
    private const val KEY_ACTIVATED = "ax_st"
    private const val KEY_NICKNAME  = "ax_nk"
    private const val KEY_DEVICE_ID = "ax_did"
    private const val KEY_USERS     = "ax_users"

    private val adminPasswordHash: String by lazy {
        sha256hex("MainC4yt552" + "slt_x9k")
    }

    private fun getPrefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getDeviceId(context: Context): String =
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            ?: "unknown"

    fun isActivated(context: Context): Boolean =
        getPrefs(context).getBoolean(KEY_ACTIVATED, false)

    fun getActiveNickname(context: Context): String =
        getPrefs(context).getString(KEY_NICKNAME, "") ?: ""

    private fun saveActivation(context: Context, nickname: String, deviceId: String) {
        getPrefs(context).edit()
            .putBoolean(KEY_ACTIVATED, true)
            .putString(KEY_NICKNAME, nickname)
            .putString(KEY_DEVICE_ID, deviceId)
            .apply()
    }

    fun deactivate(context: Context) {
        getPrefs(context).edit()
            .remove(KEY_ACTIVATED)
            .remove(KEY_NICKNAME)
            .remove(KEY_DEVICE_ID)
            .apply()
    }

    fun verifyAdminPassword(password: String): Boolean =
        sha256hex(password + "slt_x9k") == adminPasswordHash

    // ─── Генерация кода по никнейму (HMAC-SHA256) ────────────────────────────

    private fun generateCodeForNickname(nickname: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(SECRET_KEY.toByteArray(), "HmacSHA256"))
        val hash = mac.doFinal(nickname.trim().lowercase().toByteArray())
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val sb = StringBuilder()
        for (i in 0 until 12) {
            if (i > 0 && i % 4 == 0) sb.append('-')
            sb.append(chars[(hash[i].toInt() and 0xFF) % chars.length])
        }
        return sb.toString()
    }

    // ─── АКТИВАЦИЯ ───────────────────────────────────────────────────────────
    // 1. Локальная проверка HMAC кода
    // 2. Шлём CHECK боту (serverless) через sendMessage в admin chat
    //    бот обрабатывает через webhook (message.js), отвечает CHECKRESULT
    //    тем же ботом в тот же чат
    // 3. Читаем CHECKRESULT через getUpdates того же бота

    fun activate(context: Context, nickname: String, code: String): Result<Boolean> {
        return try {
            val trimmedNick   = nickname.trim()
            val inputClean    = code.trim().uppercase().replace("-", "").replace(" ", "")
            val expectedClean = generateCodeForNickname(trimmedNick).replace("-", "")

            if (inputClean != expectedClean) return Result.success(false)

            val deviceId    = getDeviceId(context)
            val checkResult = checkDeviceLockPolling(trimmedNick, deviceId, inputClean)

            when (checkResult) {
                "OK"      -> { saveActivation(context, trimmedNick, deviceId); Result.success(true) }
                "BLOCKED" -> Result.failure(Exception("Этот код уже используется на другом устройстве"))
                else      -> { saveActivation(context, trimmedNick, deviceId); Result.success(true) }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─── Device Lock через getUpdates ────────────────────────────────────────
    // Один бот: шлём CHECK → webhook обрабатывает → бот пишет CHECKRESULT
    // Мы читаем CHECKRESULT через getUpdates того же бота

    private const val POLL_TIMEOUT_SEC = 8
    private const val POLL_MAX_WAIT_MS = 12_000L

    private fun checkDeviceLockPolling(nickname: String, deviceId: String, code: String): String {
        return try {
            // Узнаём текущий offset чтобы не поймать старые сообщения
            val currentOffset = getLastUpdateOffset()

            // Шлём CHECK в admin chat — serverless бот получит через webhook
            sendMessage("CHECK:$nickname:$deviceId:$code")

            // Поллим getUpdates, ищем CHECKRESULT:nickname:OK/BLOCKED
            val startTime = System.currentTimeMillis()
            var offset    = currentOffset + 1

            while (System.currentTimeMillis() - startTime < POLL_MAX_WAIT_MS) {
                val updates = getUpdates(offset, POLL_TIMEOUT_SEC)

                for (update in updates) {
                    val updateId = update.optLong("update_id", 0L)
                    if (updateId >= offset) offset = updateId + 1

                    val msg     = update.optJSONObject("message") ?: continue
                    val msgText = msg.optString("text", "")
                    val chatId  = msg.optJSONObject("chat")?.optLong("id", 0L) ?: 0L

                    if (chatId.toString() != ADMIN_CHAT_ID) continue
                    if (msgText.startsWith("CHECKRESULT:$nickname:")) {
                        return msgText.substringAfterLast(":").trim()
                    }
                }

                if (updates.isEmpty()) Thread.sleep(300)
            }
            "TIMEOUT"
        } catch (_: java.net.UnknownHostException)   { "OFFLINE" }
          catch (_: java.net.SocketTimeoutException) { "OFFLINE" }
          catch (_: Exception)                       { "ERROR" }
    }

    private fun getLastUpdateOffset(): Long {
        return try {
            val conn = URL("$BOT_API/getUpdates?limit=1&offset=-1").openConnection() as HttpURLConnection
            conn.connectTimeout = 5000; conn.readTimeout = 5000
            val json = JSONObject(conn.inputStream.bufferedReader().readText())
            if (!json.optBoolean("ok", false)) return 0L
            val r = json.optJSONArray("result") ?: return 0L
            if (r.length() == 0) return 0L
            r.getJSONObject(r.length() - 1).optLong("update_id", 0L)
        } catch (_: Exception) { 0L }
    }

    private fun sendMessage(text: String) {
        val body = JSONObject().apply {
            put("chat_id", ADMIN_CHAT_ID)
            put("text", text)
        }.toString()
        val conn = URL("$BOT_API/sendMessage").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.connectTimeout = 5000; conn.readTimeout = 5000; conn.doOutput = true
        conn.outputStream.use { it.write(body.toByteArray()) }
        try { conn.inputStream.close() } catch (_: Exception) {}
    }

    private fun getUpdates(offset: Long, timeoutSec: Int): List<JSONObject> {
        return try {
            val conn = URL("$BOT_API/getUpdates?offset=$offset&timeout=$timeoutSec&limit=20")
                .openConnection() as HttpURLConnection
            conn.connectTimeout = (timeoutSec + 3) * 1000
            conn.readTimeout    = (timeoutSec + 3) * 1000
            val json = JSONObject(conn.inputStream.bufferedReader().readText())
            if (!json.optBoolean("ok", false)) return emptyList()
            val r = json.optJSONArray("result") ?: return emptyList()
            (0 until r.length()).map { r.getJSONObject(it) }
        } catch (_: Exception) { emptyList() }
    }

    // ─── Админ функции ────────────────────────────────────────────────────────

    fun generateCode(context: Context, nickname: String): Result<String> {
        return try {
            val trimmed  = nickname.trim()
            if (trimmed.isEmpty()) return Result.failure(Exception("Пустой никнейм"))
            val code     = generateCodeForNickname(trimmed)
            val users    = loadUsers(context).toMutableList()
            val existing = users.indexOfFirst { it.nickname.lowercase() == trimmed.lowercase() }
            if (existing >= 0) return Result.success(users[existing].code)
            users.add(UserInfo(trimmed, code, System.currentTimeMillis()))
            saveUsers(context, users)
            Result.success(code)
        } catch (e: Exception) { Result.failure(e) }
    }

    fun getUsers(context: Context): Result<List<UserInfo>> =
        try { Result.success(loadUsers(context)) } catch (e: Exception) { Result.failure(e) }

    fun deleteUser(context: Context, nickname: String): Result<Boolean> {
        return try {
            val users   = loadUsers(context).toMutableList()
            val removed = users.removeAll { it.nickname.lowercase() == nickname.trim().lowercase() }
            if (removed) saveUsers(context, users)
            Result.success(removed)
        } catch (e: Exception) { Result.failure(e) }
    }

    private fun loadUsers(context: Context): List<UserInfo> {
        val json = getPrefs(context).getString(KEY_USERS, "[]") ?: "[]"
        val arr  = org.json.JSONArray(json)
        return (0 until arr.length()).map {
            val obj = arr.getJSONObject(it)
            UserInfo(
                nickname    = obj.getString("nickname"),
                code        = obj.getString("code"),
                activatedAt = obj.optLong("createdAt", 0L),
                deviceId    = obj.optString("deviceId", "")
            )
        }
    }

    private fun saveUsers(context: Context, users: List<UserInfo>) {
        val arr = org.json.JSONArray()
        users.forEach { u ->
            arr.put(JSONObject().apply {
                put("nickname",  u.nickname)
                put("code",      u.code)
                put("createdAt", u.activatedAt)
                put("deviceId",  u.deviceId)
            })
        }
        getPrefs(context).edit().putString(KEY_USERS, arr.toString()).apply()
    }

    private fun sha256hex(text: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(text.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
