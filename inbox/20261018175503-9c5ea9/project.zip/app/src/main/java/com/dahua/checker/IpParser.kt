package com.dahua.checker

object IpParser {

    fun parse(input: String): List<String> {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return emptyList()

        return when {
            '-' in trimmed -> parseRange(trimmed)
            '/' in trimmed -> parseCidr(trimmed)
            else -> parseSingle(trimmed)
        }
    }

    fun parseMultiline(text: String): List<String> {
        val result = mutableListOf<String>()
        text.lines().forEach { line ->
            val l = line.trim()
            if (l.isNotEmpty() && !l.startsWith("#")) {
                result.addAll(parse(l))
            }
        }
        return result
    }

    private fun parseSingle(ip: String): List<String> {
        return try {
            val parts = ip.split(".")
            if (parts.size != 4) return emptyList()
            parts.forEach {
                val v = it.toIntOrNull() ?: return emptyList()
                if (v < 0 || v > 255) return emptyList()
            }
            listOf(ip)
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parseRange(range: String): List<String> {
        return try {
            val (startStr, endStr) = range.split("-", limit = 2).map { it.trim() }
            val startLong = ipToLong(startStr)
            val endLong = ipToLong(endStr)
            if (startLong < 0 || endLong < 0 || startLong > endLong) return emptyList()
            val count = endLong - startLong + 1
            if (count > 65536) return emptyList()
            (startLong..endLong).map { longToIp(it) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parseCidr(cidr: String): List<String> {
        return try {
            val (ipStr, prefixStr) = cidr.split("/", limit = 2).map { it.trim() }
            val prefix = prefixStr.toIntOrNull() ?: return emptyList()
            if (prefix < 0 || prefix > 32) return emptyList()
            val baseIp = ipToLong(ipStr)
            if (baseIp < 0) return emptyList()
            val mask = if (prefix == 0) 0L else (0xFFFFFFFFL shl (32 - prefix)) and 0xFFFFFFFFL
            val network = baseIp and mask
            val hostCount = 1L shl (32 - prefix)
            if (prefix < 16 || hostCount > 65534) return emptyList()
            if (prefix >= 31) {
                (0 until hostCount).map { longToIp(network + it) }
            } else {
                (1 until hostCount - 1).map { longToIp(network + it) }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun ipToLong(ip: String): Long {
        val parts = ip.split(".")
        if (parts.size != 4) return -1
        var result = 0L
        for (p in parts) {
            val v = p.toIntOrNull() ?: return -1
            if (v < 0 || v > 255) return -1
            result = (result shl 8) or v.toLong()
        }
        return result
    }

    private fun longToIp(value: Long): String {
        return "${(value shr 24) and 0xFF}.${(value shr 16) and 0xFF}.${(value shr 8) and 0xFF}.${value and 0xFF}"
    }
}
