// ═══════════════════════════════════════════════════════
//  Main Scanner — Device Lock Server (Google Apps Script)
//  Деплой: Extensions → Apps Script → Deploy → Web App
//  Execute as: Me | Who has access: Anyone
// ═══════════════════════════════════════════════════════

const SHEET_NAME = "activations";

function doGet(e) {
  const action = e.parameter.action;
  const nickname = (e.parameter.nickname || "").trim();
  const deviceId = (e.parameter.deviceId || "").trim();
  const code = (e.parameter.code || "").trim().toUpperCase().replace(/-/g, "");

  if (!action || !nickname || !deviceId || !code) {
    return ContentService.createTextOutput("error:missing_params");
  }

  if (action === "check") {
    return ContentService.createTextOutput(checkActivation(nickname, deviceId, code));
  }

  return ContentService.createTextOutput("error:unknown_action");
}

function checkActivation(nickname, deviceId, code) {
  const sheet = getOrCreateSheet();
  const data = sheet.getDataRange().getValues();

  // Ищем строку с таким же кодом
  for (let i = 1; i < data.length; i++) {
    const rowCode    = String(data[i][1]).trim().toUpperCase().replace(/-/g, "");
    const rowDevice  = String(data[i][2]).trim();
    const rowNick    = String(data[i][0]).trim().toLowerCase();

    if (rowCode === code) {
      if (rowDevice === deviceId) {
        // Тот же девайс — уже активирован ранее, ок
        return "ok";
      } else {
        // Код уже привязан к ДРУГОМУ девайсу — блок
        return "blocked";
      }
    }
  }

  // Новая активация — записываем
  sheet.appendRow([
    nickname,
    code,
    deviceId,
    new Date().toISOString(),
    "active"
  ]);

  return "ok";
}

function getOrCreateSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    sheet.appendRow(["nickname", "code", "deviceId", "activatedAt", "status"]);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

// ─── Ручная деактивация (запускаешь из редактора скрипта) ───
// Чтобы отвязать девайс от кода — меняешь deviceId в таблице на ""
// или удаляешь строку, и юзер может активироваться заново

function deactivateByNickname(nickname) {
  const sheet = getOrCreateSheet();
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]).toLowerCase() === nickname.toLowerCase()) {
      sheet.deleteRow(i + 1);
      Logger.log("Деактивирован: " + nickname);
      return;
    }
  }
  Logger.log("Не найден: " + nickname);
}
