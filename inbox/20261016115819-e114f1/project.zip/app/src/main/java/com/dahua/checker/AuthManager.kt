package com.dahua.checker

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

data class UserInfo(
    val nickname: String,
    val code: String,
    val activatedAt: Long
)

object AuthManager {

    private const val PREFS_NAME = "ms_auth_x7k"
    private const val KEY_ACTIVATED = "ax_st"
    private const val KEY_NICKNAME = "ax_nk"
    private const val KEY_CODE = "ax_cd"
    private const val KEY_ACTIVATED_AT = "ax_ts"
    private const val KEY_USERS = "ax_us"
    private const val KEY_ADMIN_HASH = "ax_ah"

    // Секрет разбит на части для обфускации
    private val s1 = "M4xSc"
    private val s2 = "aN7eR"
    private val s3 = "k9Zy2"
    private val s4 = "pL8wQ"
    private fun secretKey(): ByteArray {
        val combined = s3 + s1 + s4 + s2 + "xVb3n"
        return sha256(combined.toByteArray()).copyOf(32)
    }

    // Хэш админ-пароля (MainC4yt552)
    private val adminPasswordHash: String by lazy {
        sha256hex("MainC4yt552" + "slt_x9k")
    }

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun isActivated(context: Context): Boolean {
        val prefs = getPrefs(context)
        val enc = prefs.getString(KEY_ACTIVATED, null) ?: return false
        return try {
            val dec = decrypt(enc)
            dec == "activated_v1"
        } catch (_: Exception) {
            false
        }
    }

    fun getActiveNickname(context: Context): String {
        val prefs = getPrefs(context)
        val enc = prefs.getString(KEY_NICKNAME, null) ?: return ""
        return try { decrypt(enc) } catch (_: Exception) { "" }
    }

    fun activate(context: Context, nickname: String, code: String): Boolean {
        val validCode = generateCode(nickname)
        if (code.replace("-", "").uppercase() != validCode.replace("-", "").uppercase()) {
            return false
        }

        val prefs = getPrefs(context)
        val now = System.currentTimeMillis()
        prefs.edit()
            .putString(KEY_ACTIVATED, encrypt("activated_v1"))
            .putString(KEY_NICKNAME, encrypt(nickname))
            .putString(KEY_CODE, encrypt(code))
            .putLong(KEY_ACTIVATED_AT, now)
            .apply()

        // Сохраняем пользователя в список (на админ-устройстве)
        addUser(context, UserInfo(nickname, code, now))
        return true
    }

    fun deactivate(context: Context) {
        val prefs = getPrefs(context)
        prefs.edit()
            .remove(KEY_ACTIVATED)
            .remove(KEY_NICKNAME)
            .remove(KEY_CODE)
            .remove(KEY_ACTIVATED_AT)
            .apply()
    }

    fun verifyAdminPassword(password: String): Boolean {
        return sha256hex(password + "slt_x9k") == adminPasswordHash
    }

    fun generateCode(nickname: String): String {
        val key = secretKey()
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        val hash = mac.doFinal(nickname.trim().lowercase().toByteArray(Charsets.UTF_8))

        // Берём 6 байт, кодируем в 12 hex символов, форматируем XXXX-XXXX-XXXX
        val hex = hash.take(6).joinToString("") { "%02X".format(it) }
        return "${hex.substring(0, 4)}-${hex.substring(4, 8)}-${hex.substring(8, 12)}"
    }

    // ─── Хранение пользователей ───

    fun addUser(context: Context, user: UserInfo) {
        val prefs = getPrefs(context)
        val existing = getUsers(context).toMutableList()
        existing.removeAll { it.nickname.lowercase() == user.nickname.lowercase() }
        existing.add(user)
        val data = existing.joinToString("||") { "${it.nickname}::${it.code}::${it.activatedAt}" }
        prefs.edit().putString(KEY_USERS, encrypt(data)).apply()
    }

    fun getUsers(context: Context): List<UserInfo> {
        val prefs = getPrefs(context)
        val enc = prefs.getString(KEY_USERS, null) ?: return emptyList()
        return try {
            val data = decrypt(enc)
            if (data.isBlank()) return emptyList()
            data.split("||").mapNotNull { entry ->
                val parts = entry.split("::")
                if (parts.size >= 3) {
                    UserInfo(parts[0], parts[1], parts[2].toLongOrNull() ?: 0L)
                } else null
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun deleteUser(context: Context, nickname: String) {
        val prefs = getPrefs(context)
        val existing = getUsers(context).toMutableList()
        existing.removeAll { it.nickname.lowercase() == nickname.lowercase() }
        if (existing.isEmpty()) {
            prefs.edit().remove(KEY_USERS).apply()
        } else {
            val data = existing.joinToString("||") { "${it.nickname}::${it.code}::${it.activatedAt}" }
            prefs.edit().putString(KEY_USERS, encrypt(data)).apply()
        }
    }

    // ─── Шифрование ───

    private fun encryptionKey(): SecretKeySpec {
        val raw = sha256(("enc_" + s2 + s4 + "z3x").toByteArray())
        return SecretKeySpec(raw.copyOf(16), "AES")
    }

    private fun encrypt(plainText: String): String {
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        val iv = sha256(("iv_" + s1 + s3).toByteArray()).copyOf(16)
        cipher.init(Cipher.ENCRYPT_MODE, encryptionKey(), IvParameterSpec(iv))
        val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(encrypted, Base64.NO_WRAP)
    }

    private fun decrypt(encText: String): String {
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        val iv = sha256(("iv_" + s1 + s3).toByteArray()).copyOf(16)
        cipher.init(Cipher.DECRYPT_MODE, encryptionKey(), IvParameterSpec(iv))
        val decoded = Base64.decode(encText, Base64.NO_WRAP)
        return String(cipher.doFinal(decoded), Charsets.UTF_8)
    }

    private fun sha256(data: ByteArray): ByteArray {
        return MessageDigest.getInstance("SHA-256").digest(data)
    }

    private fun sha256hex(text: String): String {
        return sha256(text.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}
