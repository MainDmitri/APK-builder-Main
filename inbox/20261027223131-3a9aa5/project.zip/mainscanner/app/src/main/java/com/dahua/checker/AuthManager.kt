package com.dahua.checker

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class UserInfo(
    val nickname: String,
    val code: String,
    val activatedAt: Long,
    val deviceId: String = ""
)

object AuthManager {

    // ─── tgcloud endpoint (бот MainScanerCheckbot) ────────────────────────────
    // Формат: https://[bot_username].t.me/api/[EndpointName]
    // Замени mainscanercheckbot на реальный username бота (без @, lowercase)
    private const val TGCLOUD_CHECK_URL = "https://cloud.telegram.org/app9052071852/api/check"

    private const val SECRET_KEY = "MainDmitri_secret_2024_xK9m"

    private const val PREFS_NAME    = "ms_auth_x7k"
    private const val KEY_ACTIVATED = "ax_st"
    private const val KEY_NICKNAME  = "ax_nk"
    private const val KEY_DEVICE_ID = "ax_did"
    private const val KEY_USERS     = "ax_users"

    private val adminPasswordHash: String by lazy {
        sha256hex("MainC4yt552" + "slt_x9k")
    }

    private fun getPrefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getDeviceId(context: Context): String =
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            ?: "unknown"

    fun isActivated(context: Context): Boolean =
        getPrefs(context).getBoolean(KEY_ACTIVATED, false)

    fun getActiveNickname(context: Context): String =
        getPrefs(context).getString(KEY_NICKNAME, "") ?: ""

    private fun saveActivation(context: Context, nickname: String, deviceId: String) {
        getPrefs(context).edit()
            .putBoolean(KEY_ACTIVATED, true)
            .putString(KEY_NICKNAME, nickname)
            .putString(KEY_DEVICE_ID, deviceId)
            .apply()
    }

    fun deactivate(context: Context) {
        getPrefs(context).edit()
            .remove(KEY_ACTIVATED)
            .remove(KEY_NICKNAME)
            .remove(KEY_DEVICE_ID)
            .apply()
    }

    fun verifyAdminPassword(password: String): Boolean =
        sha256hex(password + "slt_x9k") == adminPasswordHash

    // ─── Генерация кода по никнейму (HMAC-SHA256) ────────────────────────────

    private fun generateCodeForNickname(nickname: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(SECRET_KEY.toByteArray(), "HmacSHA256"))
        val hash = mac.doFinal(nickname.trim().lowercase().toByteArray())
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val sb = StringBuilder()
        for (i in 0 until 12) {
            if (i > 0 && i % 4 == 0) sb.append('-')
            sb.append(chars[(hash[i].toInt() and 0xFF) % chars.length])
        }
        return sb.toString()
    }

    // ─── АКТИВАЦИЯ ───────────────────────────────────────────────────────────
    // 1. Локальная проверка HMAC кода
    // 2. POST на tgcloud endpoint /api/check
    //    → { result: "ok" | "blocked" | "error" }

    fun activate(context: Context, nickname: String, code: String): Result<Boolean> {
        return try {
            val trimmedNick   = nickname.trim()
            val inputClean    = code.trim().uppercase().replace("-", "").replace(" ", "")
            val expectedClean = generateCodeForNickname(trimmedNick).replace("-", "")

            if (inputClean != expectedClean) return Result.success(false)

            val deviceId    = getDeviceId(context)
            val checkResult = checkDeviceLock(trimmedNick, deviceId, inputClean)

            when (checkResult) {
                "ok"      -> { saveActivation(context, trimmedNick, deviceId); Result.success(true) }
                "blocked" -> Result.failure(Exception("Этот код уже используется на другом устройстве"))
                else      -> {
                    // error / offline — мягко пускаем локально
                    saveActivation(context, trimmedNick, deviceId)
                    Result.success(true)
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─── Прямой POST на tgcloud endpoint ─────────────────────────────────────

    private fun checkDeviceLock(nickname: String, deviceId: String, code: String): String {
        return try {
            val body = JSONObject().apply {
                put("nickname", nickname)
                put("deviceId", deviceId)
                put("code", code)
            }.toString()

            val conn = URL(TGCLOUD_CHECK_URL).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.connectTimeout = 8000
            conn.readTimeout    = 8000
            conn.doOutput       = true
            conn.outputStream.use { it.write(body.toByteArray()) }

            val responseCode = conn.responseCode
            if (responseCode == 401) {
                // initData требуется — мягко пускаем
                return "offline"
            }

            val response = conn.inputStream.bufferedReader().readText()
            val json     = JSONObject(response)
            json.optString("result", "error")

        } catch (_: java.net.UnknownHostException)   { "offline" }
          catch (_: java.net.SocketTimeoutException) { "offline" }
          catch (_: Exception)                       { "offline" }
    }

    // ─── Админ функции ────────────────────────────────────────────────────────

    fun generateCode(context: Context, nickname: String): Result<String> {
        return try {
            val trimmed  = nickname.trim()
            if (trimmed.isEmpty()) return Result.failure(Exception("Пустой никнейм"))
            val code     = generateCodeForNickname(trimmed)
            val users    = loadUsers(context).toMutableList()
            val existing = users.indexOfFirst { it.nickname.lowercase() == trimmed.lowercase() }
            if (existing >= 0) return Result.success(users[existing].code)
            users.add(UserInfo(trimmed, code, System.currentTimeMillis()))
            saveUsers(context, users)
            Result.success(code)
        } catch (e: Exception) { Result.failure(e) }
    }

    fun getUsers(context: Context): Result<List<UserInfo>> =
        try { Result.success(loadUsers(context)) } catch (e: Exception) { Result.failure(e) }

    fun deleteUser(context: Context, nickname: String): Result<Boolean> {
        return try {
            val users   = loadUsers(context).toMutableList()
            val removed = users.removeAll { it.nickname.lowercase() == nickname.trim().lowercase() }
            if (removed) saveUsers(context, users)
            Result.success(removed)
        } catch (e: Exception) { Result.failure(e) }
    }

    private fun loadUsers(context: Context): List<UserInfo> {
        val json = getPrefs(context).getString(KEY_USERS, "[]") ?: "[]"
        val arr  = org.json.JSONArray(json)
        return (0 until arr.length()).map {
            val obj = arr.getJSONObject(it)
            UserInfo(
                nickname    = obj.getString("nickname"),
                code        = obj.getString("code"),
                activatedAt = obj.optLong("createdAt", 0L),
                deviceId    = obj.optString("deviceId", "")
            )
        }
    }

    private fun saveUsers(context: Context, users: List<UserInfo>) {
        val arr = org.json.JSONArray()
        users.forEach { u ->
            arr.put(JSONObject().apply {
                put("nickname",  u.nickname)
                put("code",      u.code)
                put("createdAt", u.activatedAt)
                put("deviceId",  u.deviceId)
            })
        }
        getPrefs(context).edit().putString(KEY_USERS, arr.toString()).apply()
    }

    private fun sha256hex(text: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(text.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
