package com.maindmitri.adbscanner

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.google.android.material.textfield.TextInputEditText
import dadb.AdbKeyPair
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var etSubnet: TextInputEditText
    private lateinit var btnScan: MaterialButton
    private lateinit var progressBar: LinearProgressIndicator
    private lateinit var rvDevices: RecyclerView
    private lateinit var tabLayout: TabLayout
    private lateinit var viewPager: ViewPager2
    private lateinit var tvConnBarIcon: TextView
    private lateinit var tvConnBarText: TextView
    private lateinit var tvDevicesHeader: TextView

    private lateinit var deviceAdapter: DeviceAdapter
    private lateinit var keyPair: AdbKeyPair

    private val foundDevices = mutableListOf<DeviceItem>()

    private val tabs = listOf(
        "SHELL"    to { ShellFragment()      as Fragment },
        "FILES"    to { FileManagerFragment() as Fragment },
        "APKs"     to { ApkManagerFragment() as Fragment },
        "PROCS"    to { ProcessFragment()     as Fragment },
        "SCREEN"   to { ScreenshotFragment()  as Fragment },
        "АЛИСА"    to { AliceFragment()        as Fragment }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        showLastCrashIfAny()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content)) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        // Bind views
        tvStatus    = findViewById(R.id.tvStatus)
        etSubnet    = findViewById(R.id.etSubnet)
        btnScan     = findViewById(R.id.btnScan)
        progressBar = findViewById(R.id.progressBar)
        rvDevices   = findViewById(R.id.rvDevices)
        tabLayout   = findViewById(R.id.tabLayout)
        viewPager   = findViewById(R.id.viewPager)
        tvConnBarIcon = findViewById(R.id.tvConnBarIcon)
        tvConnBarText = findViewById(R.id.tvConnBarText)
        tvDevicesHeader = findViewById(R.id.tvDevicesHeader)

        // Auto-detect subnet
        val detected = try { NetworkScanner.detectSubnet(this) } catch (_: Exception) { null }
        if (detected != null) etSubnet.setText(detected)

        // Device list adapter
        deviceAdapter = DeviceAdapter(foundDevices) { device -> onConnectClick(device) }
        rvDevices.layoutManager = LinearLayoutManager(this)
        rvDevices.adapter = deviceAdapter

        // Scan button — disabled until the ADB key pair is ready
        btnScan.isEnabled = false
        btnScan.setOnClickListener { startScan() }

        // Key pair — generated once, stored in app's private files dir.
        // Done off the main thread: RSA-2048 generation + file I/O must never
        // block onCreate(), and any failure here must not crash the app.
        setStatus("// генерация ключа ADB...")
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val kp = AdbManager.getOrCreateKeyPair(filesDir)
                runOnUiThread {
                    keyPair = kp
                    btnScan.isEnabled = true
                    setStatus("// READY — tap SCAN")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setStatus("! ошибка ключа ADB: ${e.message}")
                }
            }
        }

        // ViewPager + Tabs
        viewPager.adapter = object : FragmentStateAdapter(this) {
            override fun getItemCount() = tabs.size
            override fun createFragment(position: Int) = tabs[position].second()
        }
        viewPager.offscreenPageLimit = tabs.size  // keep all fragments alive

        TabLayoutMediator(tabLayout, viewPager) { tab, pos ->
            tab.text = tabs[pos].first
        }.attach()
    }

    // ─── Crash diagnostics ───────────────────────────────────────────────────
    // The logger itself is installed in App.onCreate() (runs before any
    // Activity). Here we just show whatever it caught on the previous run.

    private fun showLastCrashIfAny() {
        val crashFile = File(filesDir, "last_crash.txt")
        if (!crashFile.exists()) return
        val text = try { crashFile.readText() } catch (_: Exception) { "" }
        crashFile.delete()
        if (text.isBlank()) return
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Предыдущий сбой")
            .setMessage(text)
            .setPositiveButton("ОК", null)
            .setNeutralButton("Копировать") { _, _ ->
                val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("crash", text))
            }
            .show()
    }

    // ─── Scan ────────────────────────────────────────────────────────────────

    private fun startScan() {
        val subnet = etSubnet.text?.toString()?.trim()
        if (subnet.isNullOrBlank()) { setStatus("! укажите подсеть"); return }

        btnScan.isEnabled = false
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0
        foundDevices.clear()
        deviceAdapter.notifyDataSetChanged()
        setStatus("SCANNING $subnet.0/24 …")

        lifecycleScope.launch {
            val results = NetworkScanner.scan(subnet) { done, total ->
                val pct = (done * 100) / total
                runOnUiThread { progressBar.progress = pct }
            }

            foundDevices.addAll(results)
            deviceAdapter.notifyDataSetChanged()

            val msg = if (results.isEmpty()) "Устройств не найдено — проверьте подсеть и Wi-Fi ADB" else "Найдено: ${results.size}"
            setStatus(msg)
            tvDevicesHeader.text = if (results.isEmpty())
                "── УСТРОЙСТВА ───────────────────────"
            else
                "── УСТРОЙСТВА (${results.size}) ──────────────────"
            progressBar.visibility = View.GONE
            btnScan.isEnabled = true
        }
    }

    // ─── Connect / Disconnect ────────────────────────────────────────────────

    private fun onConnectClick(device: DeviceItem) {
        if (device.isConnected) disconnectDevice(device) else connectDevice(device)
    }

    private fun connectDevice(device: DeviceItem) {
        setStatus("Подключение к ${device.address} …")
        device.info = "подключение…"
        deviceAdapter.updateItem(device)
        lifecycleScope.launch {
            val result = AdbManager.connect(device.ip, device.port, keyPair)
            result.onSuccess {
                device.isConnected = true
                device.info = "определение устройства…"
                deviceAdapter.updateItem(device)
                setStatus("Подключено — определяю тип устройства…")

                // Auto-detect what's on the other end: phone, TV box, Yandex Station, etc.
                val profile = runCatching { DeviceDetector.detect() }.getOrNull()
                if (profile != null) {
                    device.icon = profile.icon
                    device.typeLabel = profile.typeLabel
                    device.model = profile.displayModel
                    device.androidVersion = profile.androidVersion
                    device.info = "${profile.displayModel} · Android ${profile.androidVersion}"
                    setStatus("${profile.icon} ${profile.typeLabel}: ${profile.displayModel}")
                    setConnectionBar(profile.icon, "${profile.typeLabel} — ${profile.displayModel} · Android ${profile.androidVersion} · ${device.address}")
                } else {
                    device.info = "подключено"
                    setStatus("Подключено: ${device.address}")
                    setConnectionBar("🟢", "Подключено: ${device.address}")
                }
                deviceAdapter.updateItem(device)
            }.onFailure { err ->
                device.info = "ошибка: ${err.message?.take(50)}"
                deviceAdapter.updateItem(device)
                setStatus("! не удалось подключиться к ${device.address}")
            }
        }
    }

    private fun disconnectDevice(device: DeviceItem) {
        lifecycleScope.launch {
            AdbManager.disconnect()
            device.isConnected = false
            device.info = "нажмите, чтобы подключиться"
            device.icon = "📟"
            device.typeLabel = ""
            device.model = ""
            device.androidVersion = ""
            deviceAdapter.updateItem(device)
            setStatus("Отключено")
            setConnectionBar("⚪", "Нет подключения — выберите устройство ниже")
        }
    }

    private fun setConnectionBar(icon: String, text: String) {
        tvConnBarIcon.text = icon
        tvConnBarText.text = text
    }

    private fun setStatus(msg: String) { tvStatus.text = msg }
}
