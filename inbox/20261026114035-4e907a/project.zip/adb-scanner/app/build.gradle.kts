// Extra packaging rules to resolve META-INF conflicts from dadb's transitive JUnit deps.
// AppBuilder engine merges this with its generated build file.
android {
    packaging {
        resources {
            excludes += setOf(
                "META-INF/LICENSE.md",
                "META-INF/LICENSE-notice.md",
                "META-INF/NOTICE.md",
                "META-INF/AL2.0",
                "META-INF/LGPL2.1",
                "META-INF/*.kotlin_module"
            )
        }
    }
}
