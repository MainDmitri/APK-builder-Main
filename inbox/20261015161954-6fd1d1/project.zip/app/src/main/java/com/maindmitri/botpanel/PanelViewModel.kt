package com.maindmitri.botpanel

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class DeployPlan(
    val modules: Map<String, String>,
    val expectedRevision: Long?,
    val deletions: List<String>,
)

class PanelViewModel(app: Application) : AndroidViewModel(app) {
    private val storage = Storage(app)

    val aiPrompt: String = storage.asset("ai_prompt.md")

    var token by mutableStateOf(storage.token)
        private set
    var code by mutableStateOf(storage.loadCode())
        private set
    var testUserId by mutableStateOf(storage.testUserId)
        private set
    var testText by mutableStateOf(storage.testText)
        private set
    var busy by mutableStateOf(false)
        private set
    var output by mutableStateOf("")
        private set
    var outputIsError by mutableStateOf(false)
        private set
    var pendingDeploy by mutableStateOf<DeployPlan?>(null)
        private set

    val handlersInfo: String
        get() = if (code.isBlank()) "Файл бота не загружен"
        else BotBundle.analyze(code).fold(
            onSuccess = { a ->
                "Обработчики: " + a.handlers.joinToString() +
                    if (a.otherExports.isEmpty()) "" else "\nНе обработчики (будут проигнорированы): " + a.otherExports.joinToString()
            },
            onFailure = { it.message ?: "Ошибка в файле" },
        )

    fun updateToken(v: String) { token = v; storage.token = v.trim() }
    fun updateTestUserId(v: String) { testUserId = v; storage.testUserId = v.trim() }
    fun updateTestText(v: String) { testText = v; storage.testText = v }
    fun updateCode(v: String) { code = v; storage.saveCode(v) }

    fun loadExample() = updateCode(storage.asset("example_bot.js"))

    fun openFile(uri: Uri) {
        viewModelScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    val resolver = getApplication<Application>().contentResolver
                    val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: throw IllegalStateException("Не удалось открыть файл")
                    if (bytes.size > MAX_FILE_BYTES) throw IllegalStateException("Файл больше 1 МБ")
                    String(bytes, Charsets.UTF_8)
                }
                updateCode(text)
                show("Файл загружен (${text.length} символов)", false)
            } catch (e: Exception) {
                show("Открытие файла: ${e.message ?: e.javaClass.simpleName}", true)
            }
        }
    }

    private fun show(text: String, error: Boolean) {
        output = text
        outputIsError = error
    }

    private fun apiOrNull(): TgCloudApi? {
        val t = token.trim()
        validateToken(t)?.let { show(it, true); return null }
        return TgCloudApi(t)
    }

    private fun analysisOrNull(): BotBundle.Analysis? =
        BotBundle.analyze(code).getOrElse { show(it.message ?: "Ошибка в файле", true); null }

    private fun lintText(): String {
        val issues = BotBundle.lint(code)
        return if (issues.isEmpty()) "" else issues.joinToString("\n") { "строка ${it.line}: ${it.message}" }
    }

    /** Проверка кода без сети: обработчики и частые причины ошибки компиляции. */
    fun check() {
        if (code.isBlank()) { show("Вставьте или откройте файл бота.", true); return }
        val lint = lintText()
        if (lint.isNotEmpty()) { show("Найдены проблемы:\n$lint", true); return }
        BotBundle.analyze(code).fold(
            onSuccess = { a -> show("✅ Проблем не найдено.\nОбработчики: ${a.handlers.joinToString()}", false) },
            onFailure = { show(it.message ?: "Ошибка в файле", true) },
        )
    }


    private fun launchAction(title: String, action: suspend () -> String) {
        if (busy) return
        busy = true
        show("$title…", false)
        viewModelScope.launch {
            try {
                show(action(), false)
            } catch (e: Exception) {
                show("$title: ${e.message ?: e.javaClass.simpleName}", true)
            } finally {
                busy = false
            }
        }
    }

    /** Модули для деплоя/теста: файл бота, обработчики и схема (облачная, если уже есть). */
    private fun fullModules(analysis: BotBundle.Analysis, cloud: CloudState): Map<String, String> {
        val modules = linkedMapOf<String, String>()
        modules.putAll(BotBundle.modules(code, analysis))
        modules[BotBundle.SCHEMA_MODULE] = cloud.modules[BotBundle.SCHEMA_MODULE] ?: BotBundle.SCHEMA_SOURCE
        return modules
    }

    fun status() {
        val api = apiOrNull() ?: return
        launchAction("Статус") {
            val state = api.getState()
            val wh = api.getWebhook()
            buildString {
                appendLine("✅ Токен принят (${token.trim().substringBefore(':')})")
                appendLine("Ревизия в облаке: ${state.revision ?: "—"}")
                appendLine("Модули: ${state.modules.keys.sorted().joinToString().ifEmpty { "нет" }}")
                append(formatWebhook(wh))
            }
        }
    }

    fun deploy() {
        val api = apiOrNull() ?: return
        val analysis = analysisOrNull() ?: return
        launchAction("Деплой") {
            val state = api.getState()
            val modules = fullModules(analysis, state)
            val deletions = state.modules.keys.filter { it !in modules }.sorted()
            val plan = DeployPlan(modules, state.revision, deletions)
            if (deletions.isNotEmpty()) {
                pendingDeploy = plan
                "Ожидает подтверждения: в облаке будут удалены модули ${deletions.joinToString()}"
            } else {
                runDeploy(api, plan)
            }
        }
    }

    fun confirmDeploy() {
        val plan = pendingDeploy ?: return
        pendingDeploy = null
        val api = apiOrNull() ?: return
        launchAction("Деплой") { runDeploy(api, plan) }
    }

    fun cancelDeploy() {
        pendingDeploy = null
        show("Деплой отменён", false)
    }

    private suspend fun runDeploy(api: TgCloudApi, plan: DeployPlan): String {
        val result = try {
            api.deploy(plan.modules, plan.expectedRevision)
        } catch (e: TgCloudException) {
            if (e.isRevisionMismatch) {
                throw TgCloudException("${e.message}\nБот изменили из другого места — нажмите «Задеплоить» ещё раз.")
            }
            val lint = lintText()
            if (lint.isNotEmpty()) throw TgCloudException("${e.message}\n\nВозможные причины (локальная проверка):\n$lint")
            throw e
        }
        var wh = api.getWebhook()
        val fixed = !wh.inSync
        if (fixed) wh = api.syncWebhook()
        return buildString {
            appendLine("✅ Бот задеплоен, ревизия ${result.revision ?: "—"}")
            appendLine("Модули: ${result.modules.joinToString()}")
            if (plan.deletions.isNotEmpty()) appendLine("Удалены: ${plan.deletions.joinToString()}")
            if (fixed) appendLine("Вебхук был не в синхронизации — исправлен.")
            append(formatWebhook(wh))
        }
    }

    fun syncWebhook() {
        val api = apiOrNull() ?: return
        launchAction("Вебхук") { "✅ Вебхук синхронизирован\n" + formatWebhook(api.syncWebhook()) }
    }

    /** Выполняет обработчик message в облаке на тестовом сообщении (как `npx tgcloud run`). */
    fun test() {
        val api = apiOrNull() ?: return
        val analysis = analysisOrNull() ?: return
        if ("message" !in analysis.handlers) {
            show("Тест работает с обработчиком message, а в файле его нет.", true)
            return
        }
        val userId = testUserId.trim().toLongOrNull()
        if (userId == null) {
            show("Укажите свой Telegram ID (узнать можно у @userinfobot).", true)
            return
        }
        val text = testText.ifEmpty { "/start" }
        launchAction("Тест") {
            val modules = fullModules(analysis, api.getState())
            val args = JSONObject()
                .put("message_id", 1)
                .put("date", System.currentTimeMillis() / 1000)
                .put("text", text)
                .put("chat", JSONObject().put("id", userId).put("type", "private"))
                .put("from", JSONObject().put("id", userId).put("is_bot", false).put("first_name", "Test"))
            val r = api.run("handlers/message", modules, args)
            buildString {
                appendLine("> message(\"$text\") от $userId")
                r.logs.forEach { appendLine(it) }
                append("< ${r.result}")
                r.timeMs?.let { append("  ${it}ms") }
                append("\n\nОтветы бота приходят вам в Telegram по-настоящему.")
            }
        }
    }

    private fun formatWebhook(wh: WebhookInfo): String = buildString {
        appendLine()
        appendLine("Вебхук: ${if (wh.inSync) "✅ в синхронизации" else "❌ НЕ в синхронизации"}")
        appendLine("url: ${wh.url.ifEmpty { "(не задан)" }}")
        appendLine("обновления: ${wh.allowedUpdates.joinToString().ifEmpty { "(нет)" }}")
        append("в очереди: ${wh.pendingUpdates}")
        wh.lastError?.let { append("\nпоследняя ошибка: $it") }
    }

    private companion object {
        const val MAX_FILE_BYTES = 1_048_576
    }
}
