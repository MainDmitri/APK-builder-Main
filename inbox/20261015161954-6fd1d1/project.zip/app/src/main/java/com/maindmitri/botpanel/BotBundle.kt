package com.maindmitri.botpanel

/**
 * Превращает один файл bot.js (с именованными экспортами обработчиков) в модули tgcloud.
 *
 * Платформа принимает только handlers/<тип>.js с `export default`. Поэтому для каждого
 * обработчика создаётся отдельный файл handlers/<тип>.js: это весь исходный код бота,
 * но с убранными ключевыми словами export, плюс строка `export default <тип>;` в конце.
 * Никаких импортов между модулями и никаких именованных экспортов к компилятору не попадает.
 */
object BotBundle {
    const val SCHEMA_MODULE = "schema"

    val SCHEMA_SOURCE = """
        |import { table, integer, text } from 'sdk/db';
        |
        |// Однофайловый режим Bot Panel: таблицы базы данных не используются.
        |""".trimMargin()

    /** Типы апдейтов Telegram Bot API. */
    val UPDATE_TYPES = setOf(
        "message", "edited_message", "channel_post", "edited_channel_post",
        "business_connection", "business_message", "edited_business_message", "deleted_business_messages",
        "message_reaction", "message_reaction_count", "inline_query", "chosen_inline_result",
        "callback_query", "shipping_query", "pre_checkout_query", "purchased_paid_media",
        "poll", "poll_answer", "my_chat_member", "chat_member", "chat_join_request",
        "chat_boost", "removed_chat_boost",
    )

    data class Analysis(val handlers: List<String>, val otherExports: List<String>)

    private val EXPORT_FUNCTION = Regex("""(?m)^\s*export\s+(?:async\s+)?function\s*\*?\s*([A-Za-z_$][\w$]*)""")
    private val EXPORT_VARIABLE = Regex("""(?m)^\s*export\s+(?:const|let|var)\s+([A-Za-z_$][\w$]*)""")
    private val EXPORT_LIST = Regex("""(?m)^\s*export\s*\{([^}]*)\}\s*;?""")
    private val EXPORT_DEFAULT = Regex("""(?m)^\s*export\s+default\b""")
    private val IDENTIFIER = Regex("""^[A-Za-z_$][\w$]*$""")

    // Убирает ключевое слово export перед объявлением функции/переменной, сохраняя отступ.
    private val EXPORT_PREFIX = Regex("""(?m)^(\s*)export\s+(?=(?:async\s+)?function\b|(?:const|let|var)\b)""")

    fun analyze(source: String): Result<Analysis> {
        val code = stripComments(source)
        if (code.isBlank()) return Result.failure(IllegalArgumentException("Файл бота пустой"))
        if (EXPORT_DEFAULT.containsMatchIn(code)) {
            return Result.failure(
                IllegalArgumentException("Не используйте export default — экспортируйте функции с именами типов апдейтов (export async function message…)")
            )
        }
        val names = LinkedHashSet<String>()
        EXPORT_FUNCTION.findAll(code).forEach { names.add(it.groupValues[1]) }
        EXPORT_VARIABLE.findAll(code).forEach { names.add(it.groupValues[1]) }
        EXPORT_LIST.findAll(code).forEach { m -> aliases(m.groupValues[1]).forEach { names.add(it.first) } }
        val handlers = names.filter { it in UPDATE_TYPES }
        if (handlers.isEmpty()) {
            return Result.failure(
                IllegalArgumentException("В файле нет обработчиков. Нужна хотя бы одна функция вида: export async function message(msg, ctx) { … }")
            )
        }
        return Result.success(Analysis(handlers, names.filter { it !in UPDATE_TYPES }))
    }

    data class LintIssue(val line: Int, val message: String)

    private val IMPORT_FROM = Regex("""\b(from|import)\s*['"]([^'"]+)['"]""")
    private val RE_REQUIRE = Regex("""\brequire\s*\(""")
    private val RE_INTERFACE = Regex("""\binterface\s+[A-Za-z_$]""")
    private val RE_ENUM = Regex("""(?<![.\w])enum\s+[A-Za-z_$]""")
    private val RE_PROCESS = Regex("""\bprocess\s*\.""")
    private val RE_MODULE_EXPORTS = Regex("""\bmodule\s*\.\s*exports""")

    /**
     * Локальная проверка кода до деплоя: ловит частые причины «Compilation failed»
     * с номерами строк. Строки и комментарии при поиске игнорируются.
     */
    fun lint(source: String): List<LintIssue> {
        val issues = mutableListOf<LintIssue>()
        val rawLines = source.split('\n')
        val blanked = blankStringsAndComments(source)
        blanked.split('\n').forEachIndexed { idx, line ->
            val ln = idx + 1
            // Имя модуля — это строка, поэтому ищем его в исходной строке; ключевое слово
            // from/import должно уцелеть в очищенной строке, то есть быть кодом, а не текстом.
            IMPORT_FROM.findAll(rawLines[idx]).filter { line.startsWith(it.groupValues[1], it.range.first) }.forEach { m ->
                val mod = m.groupValues[2]
                if (mod != "sdk" && !mod.startsWith("sdk/")) {
                    issues.add(LintIssue(ln, "импорт из '$mod' недоступен — бот пишется одним файлом, импортировать можно только из 'sdk' (api, fetch, InputFile)"))
                }
            }
            if (RE_REQUIRE.containsMatchIn(line)) issues.add(LintIssue(ln, "require() недоступен — используйте import из 'sdk'"))
            if (RE_INTERFACE.containsMatchIn(line)) issues.add(LintIssue(ln, "TypeScript (interface) не поддерживается — только обычный JavaScript"))
            if (RE_ENUM.containsMatchIn(line)) issues.add(LintIssue(ln, "TypeScript (enum) не поддерживается — только обычный JavaScript"))
            if (RE_PROCESS.containsMatchIn(line)) issues.add(LintIssue(ln, "process недоступен в облаке Telegram"))
            if (RE_MODULE_EXPORTS.containsMatchIn(line)) issues.add(LintIssue(ln, "module.exports недоступен — экспортируйте функции через export"))
            if (EXPORT_DEFAULT.containsMatchIn(line)) issues.add(LintIssue(ln, "export default не используйте — обработчики именуются по типу апдейта (export async function message)"))
        }
        return issues
    }

    // Заменяет содержимое строк и комментариев пробелами, сохраняя переводы строк и структуру.
    private fun blankStringsAndComments(src: String): String {
        val out = StringBuilder(src.length)
        var i = 0
        var quote: Char? = null
        while (i < src.length) {
            val c = src[i]
            if (quote != null) {
                if (c == '\n') { out.append('\n'); if (quote != '`') quote = null; i++; continue }
                if (c == '\\' && i + 1 < src.length) { out.append(' '); out.append(if (src[i + 1] == '\n') '\n' else ' '); i += 2; continue }
                out.append(' ')
                if (c == quote) quote = null
                i++
                continue
            }
            if (c == '"' || c == '\'' || c == '`') { quote = c; out.append(' '); i++; continue }
            if (c == '/' && i + 1 < src.length && src[i + 1] == '/') {
                while (i < src.length && src[i] != '\n') { out.append(' '); i++ }
                continue
            }
            if (c == '/' && i + 1 < src.length && src[i + 1] == '*') {
                out.append("  "); i += 2
                while (i < src.length && !(src[i] == '*' && i + 1 < src.length && src[i + 1] == '/')) {
                    out.append(if (src[i] == '\n') '\n' else ' '); i++
                }
                if (i < src.length) { out.append("  "); i += 2 }
                continue
            }
            out.append(c)
            i++
        }
        return out.toString()
    }

    /** Модули бота для деплоя: по одному handlers/<тип>.js на каждый обработчик. */
    fun modules(source: String, analysis: Analysis): Map<String, String> {
        val base = toLocalScope(source)
        val out = linkedMapOf<String, String>()
        for (h in analysis.handlers) {
            out["handlers/$h"] = "// Сгенерировано Bot Panel из bot.js\n$base\nexport default $h;\n"
        }
        return out
    }

    /** Разбирает содержимое `export { ... }` в пары (экспортируемое имя, локальное имя). */
    private fun aliases(body: String): List<Pair<String, String>> =
        body.split(',').map { it.trim() }.filter { it.isNotEmpty() }.mapNotNull { part ->
            val seg = part.split(Regex("\\s+as\\s+"))
            val local = seg.first().trim()
            val exported = seg.last().trim()
            if (IDENTIFIER.matches(local) && IDENTIFIER.matches(exported)) exported to local else null
        }

    /**
     * Делает все экспорты локальными: убирает `export` у объявлений, вырезает строки
     * `export { ... }` и добавляет мостики `const <экспорт> = <локальное>;` для псевдонимов.
     */
    private fun toLocalScope(source: String): String {
        val bridges = StringBuilder()
        val withoutLists = EXPORT_LIST.replace(source) { m ->
            for ((exported, local) in aliases(m.groupValues[1])) {
                if (exported != local) bridges.append("const ").append(exported).append(" = ").append(local).append(";\n")
            }
            ""
        }
        val stripped = EXPORT_PREFIX.replace(withoutLists) { it.groupValues[1] }
        return stripped.trimEnd() + "\n" + bridges
    }

    /** Удаляет комментарии, не трогая строки и шаблонные строки (для поиска export). */
    private fun stripComments(src: String): String {
        val out = StringBuilder(src.length)
        var i = 0
        var quote: Char? = null
        while (i < src.length) {
            val c = src[i]
            if (quote != null) {
                out.append(c)
                if (c == '\\' && i + 1 < src.length) {
                    out.append(src[i + 1]); i += 2; continue
                }
                if (c == quote) quote = null
                i++
                continue
            }
            if (c == '"' || c == '\'' || c == '`') {
                quote = c; out.append(c); i++; continue
            }
            if (c == '/' && i + 1 < src.length && src[i + 1] == '/') {
                while (i < src.length && src[i] != '\n') i++
                continue
            }
            if (c == '/' && i + 1 < src.length && src[i + 1] == '*') {
                val end = src.indexOf("*/", i + 2)
                i = if (end < 0) src.length else end + 2
                out.append(' ')
                continue
            }
            out.append(c)
            i++
        }
        return out.toString()
    }
}
