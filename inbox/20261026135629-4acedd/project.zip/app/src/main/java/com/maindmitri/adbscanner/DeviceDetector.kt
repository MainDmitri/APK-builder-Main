package com.maindmitri.adbscanner

/**
 * Auto-detects what kind of device is on the other end of the ADB connection:
 * phone, tablet, Android TV / set-top box, Wear OS watch, emulator, or
 * a Yandex Station (which runs a custom AOSP build identifiable by its
 * bundled Alice package).
 */
data class DeviceProfile(
    val icon: String,
    val typeLabel: String,
    val displayModel: String,
    val androidVersion: String
)

object DeviceDetector {

    /** One combined shell call — order of output lines matches the order of commands below. */
    private const val PROBE_CMD =
        "getprop ro.product.model; " +
        "getprop ro.product.manufacturer; " +
        "getprop ro.product.brand; " +
        "getprop ro.build.characteristics; " +
        "getprop ro.build.version.release; " +
        "pm list packages ru.yandex.quasar.app; " +
        "pm list features | grep -c leanback; " +
        "pm list features | grep -c watch"

    suspend fun detect(): DeviceProfile {
        val output = AdbManager.shell(PROBE_CMD).getOrElse { "" }
        val lines = output.lines()

        val model      = lines.getOrElse(0) { "" }.trim()
        val manuf      = lines.getOrElse(1) { "" }.trim()
        val brand      = lines.getOrElse(2) { "" }.trim()
        val chars      = lines.getOrElse(3) { "" }.trim().lowercase()
        val androidVer = lines.getOrElse(4) { "" }.trim()
        val hasYandex  = lines.getOrElse(5) { "" }.contains("ru.yandex.quasar.app")
        val leanback   = lines.getOrElse(6) { "0" }.trim().toIntOrNull() ?: 0
        val watch      = lines.getOrElse(7) { "0" }.trim().toIntOrNull() ?: 0

        val (icon, type) = when {
            hasYandex ->
                "🔊" to "Яндекс Станция"
            watch > 0 || chars.contains("watch") ->
                "⌚" to "Умные часы (Wear OS)"
            leanback > 0 || chars.contains("tv") ->
                "📺" to "Android TV / приставка"
            chars.contains("tablet") ->
                "📱" to "Планшет"
            model.lowercase().contains("sdk") || brand.equals("generic", ignoreCase = true) ||
                    manuf.contains("genymotion", ignoreCase = true) ->
                "🖥" to "Эмулятор"
            chars.isEmpty() || chars.contains("phone") || chars.contains("default") ->
                "📱" to "Телефон"
            else ->
                "📟" to "ADB-устройство"
        }

        val displayModel = when {
            model.isBlank() -> "неизвестная модель"
            manuf.isNotBlank() && !model.startsWith(manuf, ignoreCase = true) -> "$manuf $model"
            else -> model
        }

        return DeviceProfile(
            icon = icon,
            typeLabel = type,
            displayModel = displayModel,
            androidVersion = androidVer.ifBlank { "?" }
        )
    }
}
