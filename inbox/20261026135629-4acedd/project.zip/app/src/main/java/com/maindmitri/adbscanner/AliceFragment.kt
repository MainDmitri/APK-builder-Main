package com.maindmitri.adbscanner

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Яндекс Алиса — управление Яндекс Станцией.
 *
 * Два режима:
 *  1. Локальное HTTP API (порт 1961) — работает БЕЗ ADB, только Wi-Fi.
 *     Вводите IP Станции вручную и отправляете команды напрямую.
 *  2. ADB-режим — если ADB уже открыт и устройство подключено через основной
 *     сканер, дополнительные ADB-команды (запуск приложений, reboot) тоже доступны.
 */
class AliceFragment : Fragment() {

    private lateinit var tvAliceStatus: TextView
    private lateinit var tvAliceLog: TextView
    private lateinit var etStationIp: TextInputEditText
    private lateinit var btnConnect: MaterialButton
    private lateinit var cardControl: View
    private lateinit var cardAdb: View

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_alice, container, false)

        tvAliceStatus = view.findViewById(R.id.tvAliceStatus)
        tvAliceLog    = view.findViewById(R.id.tvAliceLog)
        etStationIp   = view.findViewById(R.id.etStationIp)
        btnConnect    = view.findViewById(R.id.btnAliceConnect)
        cardControl   = view.findViewById(R.id.cardAliceControl)
        cardAdb       = view.findViewById(R.id.cardAdbControl)

        // Если уже есть подключение через ADB — подставить IP автоматически
        AdbManager.connectedAddress?.let { addr ->
            val ip = addr.substringBefore(":")
            etStationIp.setText(ip)
            AliceApi.stationIp = ip
        }

        updateUi()

        // ── Подключение по IP ────────────────────────────────────────────────
        btnConnect.setOnClickListener {
            val ip = etStationIp.text?.toString()?.trim() ?: ""
            if (ip.isBlank()) { log("! введите IP Станции"); return@setOnClickListener }
            AliceApi.stationIp = ip
            btnConnect.isEnabled = false
            btnConnect.text = "ПРОВЕРКА..."
            viewLifecycleOwner.lifecycleScope.launch {
                val result = AliceApi.getStatus()
                withContext(Dispatchers.Main) {
                    btnConnect.isEnabled = true
                    result.onSuccess { json ->
                        val state = json.optString("state", "—")
                        tvAliceStatus.text = "✅ Подключено к $ip · состояние: $state"
                        btnConnect.text = "ОБНОВИТЬ СТАТУС"
                        cardControl.visibility = View.VISIBLE
                        log("Подключено к $ip (порт 1961)")
                        updateUi()
                    }.onFailure { err ->
                        tvAliceStatus.text = "❌ Ошибка: ${err.message?.take(60)}"
                        btnConnect.text = "ПОДКЛЮЧИТЬСЯ"
                        log("! ${err.message}")
                    }
                }
            }
        }

        // ── TTS / команда ────────────────────────────────────────────────────
        val etCmd = view.findViewById<TextInputEditText>(R.id.etAliceCmd)
        view.findViewById<MaterialButton>(R.id.btnAliceSend).setOnClickListener {
            val text = etCmd.text?.toString()?.trim() ?: return@setOnClickListener
            if (text.isEmpty()) return@setOnClickListener
            apiCall("Алиса: «$text»") { AliceApi.sendText(text) }
            etCmd.setText("")
        }

        // ── Громкость ────────────────────────────────────────────────────────
        view.findViewById<MaterialButton>(R.id.btnVol0).setOnClickListener {
            apiCall("Громкость → 0%")  { AliceApi.setVolume(0f) }
        }
        view.findViewById<MaterialButton>(R.id.btnVol25).setOnClickListener {
            apiCall("Громкость → 25%") { AliceApi.setVolume(0.25f) }
        }
        view.findViewById<MaterialButton>(R.id.btnVol50).setOnClickListener {
            apiCall("Громкость → 50%") { AliceApi.setVolume(0.5f) }
        }
        view.findViewById<MaterialButton>(R.id.btnVol75).setOnClickListener {
            apiCall("Громкость → 75%") { AliceApi.setVolume(0.75f) }
        }
        view.findViewById<MaterialButton>(R.id.btnVol100).setOnClickListener {
            apiCall("Громкость → 100%") { AliceApi.setVolume(1f) }
        }

        // ── Медиа ────────────────────────────────────────────────────────────
        view.findViewById<MaterialButton>(R.id.btnAlicePrev).setOnClickListener {
            apiCall("Предыдущий трек") { AliceApi.prev() }
        }
        view.findViewById<MaterialButton>(R.id.btnAliceStop).setOnClickListener {
            apiCall("Стоп") { AliceApi.stop() }
        }
        view.findViewById<MaterialButton>(R.id.btnAliceNext).setOnClickListener {
            apiCall("Следующий трек") { AliceApi.next() }
        }

        // ── Быстрые команды ──────────────────────────────────────────────────
        view.findViewById<MaterialButton>(R.id.btnQuickWeather).setOnClickListener {
            apiCall("Погода") { AliceApi.sendText("какая сегодня погода") }
        }
        view.findViewById<MaterialButton>(R.id.btnQuickTime).setOnClickListener {
            apiCall("Время") { AliceApi.sendText("который час") }
        }
        view.findViewById<MaterialButton>(R.id.btnQuickMusic).setOnClickListener {
            apiCall("Музыка") { AliceApi.sendText("включи музыку") }
        }
        view.findViewById<MaterialButton>(R.id.btnQuickRadio).setOnClickListener {
            apiCall("Радио") { AliceApi.sendText("включи радио") }
        }

        // ── ADB-раздел (только если ADB подключён) ──────────────────────────
        view.findViewById<MaterialButton>(R.id.btnLaunchAlice).setOnClickListener {
            adbShell("Запуск Алисы") { AdbManager.shell("monkey -p ru.yandex.quasar.app -c android.intent.category.LAUNCHER 1") }
        }
        view.findViewById<MaterialButton>(R.id.btnLaunchYoutube).setOnClickListener {
            adbShell("Запуск YouTube") { AdbManager.shell("monkey -p com.google.android.youtube.tv -c android.intent.category.LAUNCHER 1") }
        }
        view.findViewById<MaterialButton>(R.id.btnLaunchKinopoisk).setOnClickListener {
            adbShell("Запуск Кинопоиска") { AdbManager.shell("monkey -p ru.yandex.video -c android.intent.category.LAUNCHER 1") }
        }
        view.findViewById<MaterialButton>(R.id.btnAliceReboot).setOnClickListener {
            if (!AdbManager.isConnected) { log("! нет ADB-подключения"); return@setOnClickListener }
            AlertDialog.Builder(requireContext())
                .setTitle("Перезагрузка")
                .setMessage("Перезагрузить Яндекс Станцию через ADB?")
                .setPositiveButton("ДА") { _, _ ->
                    adbShell("Reboot") { AdbManager.shell("reboot") }
                }
                .setNegativeButton("Отмена", null)
                .show()
        }

        return view
    }

    override fun onResume() {
        super.onResume()
        // Если ADB подключился пока мы были на другой вкладке — обновить UI
        updateUi()
    }

    private fun updateUi() {
        val hasApi = AliceApi.isConfigured
        cardControl.visibility = if (hasApi) View.VISIBLE else View.GONE
        cardAdb.visibility = if (AdbManager.isConnected) View.VISIBLE else View.GONE
    }

    // ── HTTP API helper ───────────────────────────────────────────────────────

    private fun apiCall(label: String, block: suspend () -> Result<String>) {
        if (!AliceApi.isConfigured) { log("! IP Станции не задан"); return }
        viewLifecycleOwner.lifecycleScope.launch {
            val result = block()
            withContext(Dispatchers.Main) {
                result.onSuccess { log("✓ $label") }
                      .onFailure { log("! $label: ${it.message?.take(60)}") }
            }
        }
    }

    // ── ADB helper ────────────────────────────────────────────────────────────

    private fun adbShell(label: String, block: suspend () -> Result<String>) {
        if (!AdbManager.isConnected) { log("! нет ADB-подключения"); return }
        viewLifecycleOwner.lifecycleScope.launch {
            val result = block()
            withContext(Dispatchers.Main) {
                result.onSuccess { log("✓ $label") }
                      .onFailure { log("! $label: ${it.message?.take(60)}") }
            }
        }
    }

    private fun log(msg: String) {
        tvAliceLog.append("> $msg\n")
    }
}
