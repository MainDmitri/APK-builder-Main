package com.maindmitri.adbscanner

data class DeviceItem(
    val ip: String,
    val port: Int = 5555,
    var isConnected: Boolean = false,
    var info: String = "нажмите, чтобы подключиться",
    var icon: String = "📟",
    var typeLabel: String = "",
    var model: String = "",
    var androidVersion: String = ""
) {
    val address: String get() = "$ip:$port"
}
