package com.maindmitri.adbscanner

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Яндекс Станция — локальный HTTP API на порту 1961.
 * Работает без ADB: достаточно быть в одной Wi-Fi сети.
 *
 * Протокол: POST /alice/v1  { "sendText": "текст команды" }
 * Громкость: POST /alice/v1  { "setVolume": 0.5 }  (0.0 – 1.0)
 * Инфо:      GET  /local-music-info
 * Статус:    GET  /alice/v1
 */
object AliceApi {

    private const val PORT = 1961
    private const val TIMEOUT_MS = 5000

    var stationIp: String = ""

    val isConfigured: Boolean get() = stationIp.isNotBlank()

    /** Отправить текстовую команду Алисе (TTS / действие) */
    suspend fun sendText(text: String): Result<String> = post(
        "/alice/v1",
        JSONObject().put("sendText", text).toString()
    )

    /** Установить громкость 0.0–1.0 */
    suspend fun setVolume(level: Float): Result<String> = post(
        "/alice/v1",
        JSONObject().put("setVolume", level.coerceIn(0f, 1f).toDouble()).toString()
    )

    /** Получить статус / текущее воспроизведение */
    suspend fun getStatus(): Result<JSONObject> = withContext(Dispatchers.IO) {
        runCatching {
            val url = URL("http://$stationIp:$PORT/alice/v1")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
            }
            val body = conn.inputStream.bufferedReader().readText()
            conn.disconnect()
            JSONObject(body)
        }
    }

    /** Получить инфо о текущей музыке */
    suspend fun getMusicInfo(): Result<JSONObject> = withContext(Dispatchers.IO) {
        runCatching {
            val url = URL("http://$stationIp:$PORT/local-music-info")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
            }
            val body = conn.inputStream.bufferedReader().readText()
            conn.disconnect()
            JSONObject(body)
        }
    }

    /** Стоп / Пауза */
    suspend fun stop(): Result<String> = sendText("стоп")

    /** Следующий трек */
    suspend fun next(): Result<String> = sendText("следующий")

    /** Предыдущий трек */
    suspend fun prev(): Result<String> = sendText("предыдущий")

    // ── внутреннее ────────────────────────────────────────────────────────────

    private suspend fun post(path: String, body: String): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                if (stationIp.isBlank()) error("IP Станции не задан")
                val url = URL("http://$stationIp:$PORT$path")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    connectTimeout = TIMEOUT_MS
                    readTimeout = TIMEOUT_MS
                }
                OutputStreamWriter(conn.outputStream).use { it.write(body) }
                val code = conn.responseCode
                val response = runCatching { conn.inputStream.bufferedReader().readText() }
                    .getOrElse { conn.errorStream?.bufferedReader()?.readText() ?: "" }
                conn.disconnect()
                if (code in 200..299) response
                else error("HTTP $code: $response")
            }
        }
}
