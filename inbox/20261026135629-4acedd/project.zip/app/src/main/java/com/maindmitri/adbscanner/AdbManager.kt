package com.maindmitri.adbscanner

import dadb.AdbKeyPair
import dadb.Dadb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.File
import java.security.KeyPairGenerator
import java.security.interfaces.RSAPrivateCrtKey
import java.security.interfaces.RSAPublicKey

/**
 * Wraps dadb connections. One active connection at a time.
 *
 * dadb 1.2.7 AdbKeyPair API:
 *   - AdbKeyPair.read(privateKeyFile, publicKeyFile)  — load from PEM files
 *   - No AdbKeyPair.generate() in this version
 *   - We generate RSA-2048 via JCE and save/load manually
 *
 * dadb 1.2.7 file transfer API:
 *   - dadb.push(srcFile: File, remotePath: String, mode: Int, lastModifiedMs: Long)
 *   - dadb.pull(dstFile: File, remotePath: String)
 */
object AdbManager {

    private var currentDadb: Dadb? = null
    private var currentAddress: String? = null

    val connectedAddress: String? get() = currentAddress
    val isConnected: Boolean get() = currentDadb != null

    // ─── Key Pair ─────────────────────────────────────────────────────────────

    /**
     * Returns the ADB key pair stored in the app's private files dir.
     * Creates a new RSA-2048 pair on first run and saves as PEM.
     */
    fun getOrCreateKeyPair(filesDir: File): AdbKeyPair {
        val privateKeyFile = File(filesDir, "adb_private_key")
        val publicKeyFile  = File(filesDir, "adb_public_key")

        return if (privateKeyFile.exists() && publicKeyFile.exists()) {
            try {
                AdbKeyPair.read(privateKeyFile, publicKeyFile)
            } catch (_: Exception) {
                // Corrupted keys — regenerate
                generateAndSaveKeyPair(privateKeyFile, publicKeyFile)
            }
        } else {
            generateAndSaveKeyPair(privateKeyFile, publicKeyFile)
        }
    }

    private fun generateAndSaveKeyPair(privateKeyFile: File, publicKeyFile: File): AdbKeyPair {
        // Generate RSA-2048 key pair using standard JCE
        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048)
        val javaKeyPair = kpg.generateKeyPair()

        // Save private key as PKCS#8 DER (wrapped in PEM for dadb)
        val privateKey = javaKeyPair.private
        val publicKey  = javaKeyPair.public

        // Write private key in PEM format
        val privateEncoded = privateKey.encoded  // PKCS#8
        val privatePem = "-----BEGIN PRIVATE KEY-----\n" +
                android.util.Base64.encodeToString(privateEncoded, android.util.Base64.DEFAULT) +
                "-----END PRIVATE KEY-----\n"
        privateKeyFile.writeText(privatePem)

        // Write public key in PEM format
        val publicEncoded = publicKey.encoded  // X.509/SubjectPublicKeyInfo
        val publicPem = "-----BEGIN PUBLIC KEY-----\n" +
                android.util.Base64.encodeToString(publicEncoded, android.util.Base64.DEFAULT) +
                "-----END PUBLIC KEY-----\n"
        publicKeyFile.writeText(publicPem)

        return AdbKeyPair.read(privateKeyFile, publicKeyFile)
    }

    // ─── Connection ───────────────────────────────────────────────────────────

    /**
     * On the FIRST connection to a new device, the device itself shows an
     * "Allow USB/Wi-Fi debugging?" dialog with the key's fingerprint — the
     * handshake blocks until that's accepted on the device's own screen.
     * Without a timeout, a device that's locked / asleep / ignored makes this
     * hang forever with no feedback, so we bound it and fail with a message
     * that tells the user to check the target screen.
     */
    suspend fun connect(host: String, port: Int, keyPair: AdbKeyPair): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                withTimeout(20_000) {
                    disconnect()
                    val dadb = Dadb.create(host, port, keyPair)
                    // Smoke-test the connection
                    val result = dadb.shell("echo ADBSCAN_OK")
                    currentDadb = dadb
                    currentAddress = "$host:$port"
                    Result.success(result.allOutput.trim())
                }
            } catch (e: TimeoutCancellationException) {
                Result.failure(
                    IllegalStateException(
                        "Таймаут 20с — проверьте экран устройства: там должен быть запрос " +
                        "«Разрешить отладку по ADB?», нажмите «Разрешить» и подключитесь снова"
                    )
                )
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun disconnect(): Unit = withContext(Dispatchers.IO) {
        try { currentDadb?.close() } catch (_: Exception) {}
        currentDadb = null
        currentAddress = null
    }

    // ─── Shell ────────────────────────────────────────────────────────────────

    suspend fun shell(command: String): Result<String> = withContext(Dispatchers.IO) {
        val dadb = currentDadb ?: return@withContext Result.failure(IllegalStateException("Не подключено"))
        runCatching { dadb.shell(command).allOutput }
    }

    /**
     * Captures raw bytes from stdout (used for screencap -p PNG output).
     * dadb's shell() converts output to String; we convert back via ISO_8859_1
     * and strip spurious \r bytes inserted by the ADB shell protocol.
     */
    suspend fun shellBytes(command: String): Result<ByteArray> = withContext(Dispatchers.IO) {
        val dadb = currentDadb ?: return@withContext Result.failure(IllegalStateException("Не подключено"))
        runCatching {
            val raw = dadb.shell(command).allOutput.toByteArray(Charsets.ISO_8859_1)
            // ADB shell protocol inserts \r before \n — strip \r\n → \n to get clean binary
            val out = java.io.ByteArrayOutputStream(raw.size)
            var i = 0
            while (i < raw.size) {
                val b = raw[i]
                if (b == '\r'.code.toByte() && i + 1 < raw.size && raw[i + 1] == '\n'.code.toByte()) {
                    i++ // skip \r, keep \n
                } else {
                    out.write(b.toInt())
                }
                i++
            }
            out.toByteArray()
        }
    }

    // ─── File Transfer ────────────────────────────────────────────────────────

    /**
     * Push a local file to the remote device.
     * dadb 1.2.7: dadb.push(srcFile: File, remotePath: String, mode: Int, lastModifiedMs: Long)
     */
    suspend fun push(localFile: File, remotePath: String): Result<Unit> = withContext(Dispatchers.IO) {
        val dadb = currentDadb ?: return@withContext Result.failure(IllegalStateException("Не подключено"))
        runCatching {
            // mode 0x1A4 = 0644 (rw-r--r--)
            dadb.push(localFile, remotePath, 0x1A4, System.currentTimeMillis())
        }
    }

    /**
     * Pull a remote file to a local destination.
     * dadb 1.2.7: dadb.pull(dstFile: File, remotePath: String)
     */
    suspend fun pull(remotePath: String, localFile: File): Result<Unit> = withContext(Dispatchers.IO) {
        val dadb = currentDadb ?: return@withContext Result.failure(IllegalStateException("Не подключено"))
        runCatching {
            // dadb.pull(localDstFile, remoteSrcPath)
            dadb.pull(localFile, remotePath)
        }
    }
}
