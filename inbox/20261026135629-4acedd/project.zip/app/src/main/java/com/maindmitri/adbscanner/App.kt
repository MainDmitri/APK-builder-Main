package com.maindmitri.adbscanner

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Custom Application so the crash logger installs BEFORE any Activity,
 * including before MainActivity's class is even loaded. If a crash happens
 * during class-loading (NoClassDefFoundError, VerifyError, static init
 * failure) rather than inside onCreate(), a handler installed only inside
 * MainActivity.onCreate() would never run — this one always does.
 */
class App : Application() {

    override fun onCreate() {
        super.onCreate()
        installCrashLogger()
    }

    private fun installCrashLogger() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                File(filesDir, "last_crash.txt").writeText(sw.toString())
            } catch (_: Throwable) {
                // never let the crash logger itself throw
            }
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }
}
