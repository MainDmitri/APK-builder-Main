// Схемы построек (как мод Schematica): файлы .schematic (формат MCEdit/Schematica, Java Edition до 1.12),
// голограмма постройки в мире, перемещение и поворот, показ по слоям, принтер (сам ставит блоки рядом с игроком),
// постройка целиком, список материалов, замена недостающих блоков, сохранение области в .schematic. Работает и на серверах.
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const KEY = 'schematics';
  const MAX_VOLUME = 4000000;

  // ---------- NBT (big endian) ----------
  class NbtReader {
    constructor(bytes) { this.b = bytes; this.v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength); this.o = 0; }
    byte() { return this.v.getInt8(this.o++); }
    short() { const r = this.v.getInt16(this.o); this.o += 2; return r; }
    int() { const r = this.v.getInt32(this.o); this.o += 4; return r; }
    long() { const hi = this.v.getInt32(this.o), lo = this.v.getUint32(this.o + 4); this.o += 8; return hi * 4294967296 + lo; }
    float() { const r = this.v.getFloat32(this.o); this.o += 4; return r; }
    double() { const r = this.v.getFloat64(this.o); this.o += 8; return r; }
    string() { const n = this.v.getUint16(this.o); this.o += 2; const s = new TextDecoder().decode(this.b.subarray(this.o, this.o + n)); this.o += n; return s; }
    payload(t) {
      switch (t) {
        case 1: return this.byte();
        case 2: return this.short();
        case 3: return this.int();
        case 4: return this.long();
        case 5: return this.float();
        case 6: return this.double();
        case 7: { const n = this.int(); const r = this.b.slice(this.o, this.o + n); this.o += n; return r; }
        case 8: return this.string();
        case 9: { const et = this.byte(), n = this.int(); const r = []; for (let i = 0; i < n; i++) r.push(this.payload(et)); return r; }
        case 10: {
          const r = {};
          for (;;) {
            const tt = this.byte();
            if (tt === 0) break;
            const name = this.string();
            r[name] = this.payload(tt);
          }
          return r;
        }
        case 11: { const n = this.int(); const r = new Int32Array(n); for (let i = 0; i < n; i++) r[i] = this.int(); return r; }
        case 12: { const n = this.int(); const r = []; for (let i = 0; i < n; i++) r.push(this.long()); return r; }
        default: throw new Error('Неизвестный тег NBT ' + t);
      }
    }
    root() {
      const t = this.byte();
      if (t !== 10) throw new Error('Файл не похож на NBT');
      this.string();
      return this.payload(10);
    }
  }

  class NbtWriter {
    constructor() { this.parts = []; this.size = 0; }
    push(u8) { this.parts.push(u8); this.size += u8.length; }
    byte(v) { this.push(new Uint8Array([v & 255])); }
    short(v) { const b = new Uint8Array(2); new DataView(b.buffer).setInt16(0, v); this.push(b); }
    int(v) { const b = new Uint8Array(4); new DataView(b.buffer).setInt32(0, v); this.push(b); }
    string(s) { const e = new TextEncoder().encode(s); this.short(e.length); this.push(e); }
    tag(type, name) { this.byte(type); this.string(name); }
    result() { const out = new Uint8Array(this.size); let o = 0; for (const p of this.parts) { out.set(p, o); o += p.length; } return out; }
  }

  async function stream(bytes, ds) {
    const s = new Blob([bytes]).stream().pipeThrough(ds);
    return new Uint8Array(await new Response(s).arrayBuffer());
  }

  // ---------- Java Edition 1.12 ↔ MCPE 1.1 ----------
  // [java id] → [mcpe id, функция данных]
  const J2P = {
    95: [241], 125: [157], 126: [158], 157: [126], 158: [125], 166: [95],
    188: [85, () => 1], 189: [85, () => 2], 190: [85, () => 3], 191: [85, () => 4], 192: [85, () => 5],
    198: [208], 199: [240], 202: [201, () => 2], 204: [201], 205: [182, (d) => 1 | (d & 8)], 207: [244], 208: [198],
    212: [207], 218: [251], 251: [236], 252: [237],
    43: [43, (d) => swapSlab(d)], 44: [44, (d) => swapSlab(d)],
    77: [77, buttonData], 143: [143, buttonData],
    36: [0], 119: [0], 137: [0], 176: [0], 177: [0], 209: [0], 210: [0], 211: [0], 217: [0], 255: [0]
  };
  for (let i = 0; i < 16; i++) { J2P[219 + i] = [218, () => i]; J2P[235 + i] = [220 + i, (d) => d]; }
  // Каменные плиты: в Java 6 — кирпич Нижнего мира, 7 — кварц; в MCPE наоборот
  function swapSlab(d) { const t = d & 7; return (t === 6 ? 7 : t === 7 ? 6 : t) | (d & 8); }
  // Кнопки: Java 0 низ, 1 восток, 2 запад, 3 юг, 4 север, 5 верх → MCPE 0 низ, 1 верх, 2 север, 3 юг, 4 запад, 5 восток
  function buttonData(d) { return [0, 5, 4, 3, 2, 1, 0, 0][d & 7] | (d & 8); }
  function buttonBack(d) { return [0, 5, 4, 3, 2, 1, 0, 0][d & 7] | (d & 8); }

  function fromJava(id, data) {
    const m = J2P[id];
    let pid = id, pd = data;
    if (m) { pid = m[0]; pd = m[1] ? m[1](data) : data; }
    if (pid === 0) return null;
    const b = MC.Blocks.list[pid];
    if (!b || b.shape === 'none') return null;
    return [pid, pd & 15];
  }

  // MCPE → Java для сохранения
  function toJava(id, data) {
    if (id === 85 && data > 0) return [187 + data, 0];
    if (id === 44 || id === 43) return [id, swapSlab(data)];
    if (id === 77 || id === 143) return [id, buttonBack(data)];
    if (id === 218) return [219 + (data & 15), 0];
    if (id >= 220 && id <= 235) return [id + 15, data];
    if (id === 201) return [(data & 3) === 2 ? 202 : 201, 0];
    if (id === 182) return [205, data & 8];
    for (const k of Object.keys(J2P)) {
      const m = J2P[k];
      if (m[0] === id && !m[1] && +k !== 166 && m[0] !== 0) return [+k, data];
    }
    if (id === 95) return [166, 0];
    return [id, data];
  }

  // ---------- Разбор и запись файла ----------
  async function parse(bytes, name) {
    let raw = bytes;
    if (bytes[0] === 0x1f && bytes[1] === 0x8b) raw = await stream(bytes, new DecompressionStream('gzip'));
    const root = new NbtReader(raw).root();
    if (root.Palette || root.BlockData) throw new Error('Это схема формата Sponge (.schem, Java 1.13+); поддерживаются .schematic до 1.12');
    if (!root.Blocks || root.Width === undefined) throw new Error('В файле нет блоков .schematic (Width/Height/Length/Blocks)');
    const w = root.Width & 0xffff, h = root.Height & 0xffff, l = root.Length & 0xffff;
    if (w * h * l > MAX_VOLUME) throw new Error('Схема слишком большая: ' + w + '×' + h + '×' + l);
    if (h > 256) throw new Error('Схема выше 256 блоков');
    const blocks = root.Blocks, data = root.Data || new Uint8Array(blocks.length), add = root.AddBlocks;
    // Schematica сохраняет свою таблицу «имя → номер»: блоки модов превращаются в воздух
    let remap = null;
    if (root.SchematicaMapping) {
      remap = {};
      for (const [n, v] of Object.entries(root.SchematicaMapping)) remap[v] = n.startsWith('minecraft:') ? v : 0;
    }
    const ids = new Uint8Array(w * h * l), meta = new Uint8Array(w * h * l);
    let count = 0, skipped = 0;
    for (let i = 0; i < blocks.length && i < ids.length; i++) {
      let id = blocks[i] & 255;
      if (add) id |= ((i & 1 ? add[i >> 1] & 15 : (add[i >> 1] >> 4) & 15) << 8);
      if (remap) id = remap[id] === undefined ? id : remap[id];
      if (!id) continue;
      const r = id < 256 ? fromJava(id, data[i] & 15) : null;
      if (!r) { skipped++; continue; }
      ids[i] = r[0];
      meta[i] = r[1];
      count++;
    }
    return { name: name.replace(/\.schematic$/i, ''), w, h, l, ids, meta, count, skipped, added: Date.now() };
  }

  // Индекс в .schematic: (y * length + z) * width + x
  async function encode(s) {
    const n = s.w * s.h * s.l;
    const blocks = new Uint8Array(n), data = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
      if (!s.ids[i]) continue;
      const j = toJava(s.ids[i], s.meta[i]);
      blocks[i] = j[0];
      data[i] = j[1] & 15;
    }
    const wr = new NbtWriter();
    wr.tag(10, 'Schematic');
    wr.tag(2, 'Width'); wr.short(s.w);
    wr.tag(2, 'Height'); wr.short(s.h);
    wr.tag(2, 'Length'); wr.short(s.l);
    wr.tag(8, 'Materials'); wr.string('Alpha');
    wr.tag(7, 'Blocks'); wr.int(n); wr.push(blocks);
    wr.tag(7, 'Data'); wr.int(n); wr.push(data);
    wr.tag(9, 'Entities'); wr.byte(10); wr.int(0);
    wr.tag(9, 'TileEntities'); wr.byte(10); wr.int(0);
    wr.byte(0);
    return stream(wr.result(), new CompressionStream('gzip'));
  }

  // Буфер копирования Effortless Building → схема
  function fromClip(clip, name) {
    let w = 0, h = 0, l = 0;
    for (const b of clip.blocks) { w = Math.max(w, b.x + 1); h = Math.max(h, b.y + 1); l = Math.max(l, b.z + 1); }
    const ids = new Uint8Array(w * h * l), meta = new Uint8Array(w * h * l);
    for (const b of clip.blocks) { const i = (b.y * l + b.z) * w + b.x; ids[i] = b.id; meta[i] = b.d; }
    return { name, w, h, l, ids, meta, count: clip.blocks.length, skipped: 0, added: Date.now() };
  }

  // ---------- Хранилище (IndexedDB) ----------
  async function list() { try { return (await MC.Storage.kv.get(KEY)) || []; } catch (e) { return []; } }
  async function saveList(l) { await MC.Storage.kv.put(KEY, l); }

  async function addFile(file) {
    const bytes = new Uint8Array(await file.arrayBuffer());
    const s = await parse(bytes, file.name);
    if (!s.count) throw new Error('В схеме нет блоков, которые есть в MCPE 1.1');
    await store(s);
    return s;
  }

  async function store(s) {
    const l = (await list()).filter((x) => x.name !== s.name);
    l.unshift(s);
    await saveList(l);
  }

  async function remove(name) { await saveList((await list()).filter((x) => x.name !== name)); }

  // Сохранение файла: в папку игры (APK), иначе скачивание
  async function exportFile(s) {
    const gz = await encode(s);
    const fname = s.name.replace(/[\\/:*?"<>|]/g, '_') + '.schematic';
    if (window.AndroidStorage && typeof window.AndroidStorage.write === 'function' && window.AndroidStorage.folderName()) {
      let bin = '';
      for (let i = 0; i < gz.length; i += 0x8000) bin += String.fromCharCode.apply(null, gz.subarray(i, i + 0x8000));
      const err = window.AndroidStorage.write('schematics', fname, btoa(bin));
      if (err) throw new Error(err);
      return 'Сохранено в папку игры: schematics/' + fname;
    }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([gz], { type: 'application/octet-stream' }));
    a.download = fname;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
    return 'Файл ' + fname + ' скачан';
  }

  // ---------- Голограмма в мире ----------
  const key3 = (x, y, z) => x + ',' + y + ',' + z;
  const rot = (id, d) => MC.Building.rotateData(id, d);
  const flip = (id, d) => MC.Building.flipData(id, d, 'x');

  class View {
    constructor(game) {
      this.game = game;
      this.s = null;
      this.pos = { x: 0, y: 64, z: 0 };
      this.rot = 0;
      this.mirror = false;
      this.layer = -1;
      this.layerMode = 'single';
      this.printer = false;
      this.printT = 0;
      this.ghost = new MC.World();
      this.dirty = new Set();
      this.wrongs = new Set();
      // Замены: клетка → id поставленного вместо нужного блока (placed — уже стоит в мире)
      this.subs = new Map();
      this.stats = { ok: 0, left: 0, wrong: 0 };
      this.rebuildT = 0;
      this.ghost.onSectionDirty((cx, sy, cz) => this.dirty.add(cx + ',' + sy + ',' + cz));
      game.world.onBlockSet((x, y, z) => this.worldChanged(x, y, z));
      if (game.building) game.building.onSubst = (o) => this.markSub(o.x, o.y, o.z, o.nid);
      // На сервере чанки приходят позже: пересчитываем голограмму, когда загрузился чанк под схемой
      game.world.onChunkSet((cx, cz) => { if (this.s && this.coversChunk(cx, cz)) this.rebuildT = 0.4; });
    }

    size() {
      const s = this.s;
      return this.rot & 1 ? { w: s.l, h: s.h, l: s.w } : { w: s.w, h: s.h, l: s.l };
    }

    coversChunk(cx, cz) {
      const sz = this.size();
      return cx * 16 + 15 >= this.pos.x && cx * 16 <= this.pos.x + sz.w - 1 && cz * 16 + 15 >= this.pos.z && cz * 16 <= this.pos.z + sz.l - 1;
    }

    layerOk(ly) {
      if (this.layer < 0) return true;
      return this.layerMode === 'below' ? ly <= this.layer : ly === this.layer;
    }

    // Блок схемы в мировых координатах (с поворотом и отражением) или null
    targetAt(x, y, z) {
      const s = this.s;
      if (!s) return null;
      const sz = this.size();
      let lx = x - this.pos.x, ly = y - this.pos.y, lz = z - this.pos.z;
      if (lx < 0 || ly < 0 || lz < 0 || lx >= sz.w || ly >= sz.h || lz >= sz.l) return null;
      if (!this.layerOk(ly)) return null;
      // Обратный поворот: мировая клетка → клетка схемы
      // Один поворот по часовой: (x, z) в коробке W×L → (L-1-z, x); отменяем повороты в обратном порядке
      for (let j = this.rot - 1; j >= 0; j--) { const lj = j & 1 ? s.w : s.l; const ox = lx; lx = lz; lz = lj - 1 - ox; }
      if (this.mirror) lx = s.w - 1 - lx;
      const i = (ly * s.l + lz) * s.w + lx;
      const id = s.ids[i];
      if (!id) return null;
      let d = s.meta[i];
      if (this.mirror) d = flip(id, d);
      for (let r = 0; r < this.rot; r++) d = rot(id, d);
      return [id, d];
    }

    load(s) {
      this.s = s;
      this.rot = 0;
      this.mirror = false;
      this.layer = -1;
      this.subs.clear();
      // Перед игроком: схема начинается в 2 блоках по направлению взгляда
      const p = this.game.player;
      const yr = p.yaw * Math.PI / 180, fx = -Math.sin(yr), fz = Math.cos(yr);
      this.pos = { x: Math.floor(p.x + fx * 3) - (fx < -0.5 ? s.w - 1 : 0), y: Math.floor(p.y), z: Math.floor(p.z + fz * 3) - (fz < -0.5 ? s.l - 1 : 0) };
      this.rebuild();
    }

    unload() { this.s = null; this.printer = false; this.subs.clear(); this.rebuild(); }

    move(dx, dy, dz) { this.pos.x += dx; this.pos.y = Math.max(0, Math.min(255, this.pos.y + dy)); this.pos.z += dz; this.subs.clear(); this.rebuild(); }
    moveTo(p) { this.pos = { x: p.x, y: p.y, z: p.z }; this.subs.clear(); this.rebuild(); }
    rotate() { this.rot = (this.rot + 1) & 3; this.subs.clear(); this.rebuild(); }
    flipX() { this.mirror = !this.mirror; this.subs.clear(); this.rebuild(); }
    setLayer(v) { const h = this.s ? this.s.h : 1; this.layer = v < 0 ? -1 : Math.max(0, Math.min(h - 1, v)); this.rebuild(); }
    toggleLayerMode() { this.layerMode = this.layerMode === 'single' ? 'below' : 'single'; this.rebuild(); }

    // Состояние клетки: готово (тот же блок или поставленная замена), мешает чужой блок, или ещё не построено
    state(x, y, z, t, cur) {
      const sub = this.subs.get(key3(x, y, z));
      if (cur === t[0] || (sub && (cur === sub.id || !sub.placed))) return 'ok';
      if (cur && !MC.Blocks.list[cur].replaceable) return 'wrong';
      return 'left';
    }

    // Голограмма показывает только блоки, которых ещё нет в мире
    rebuild() {
      const R = this.game.renderer;
      for (const k of this.ghost.chunks.keys()) {
        const [cx, cz] = k.split(',').map(Number);
        for (let sy = 0; sy < 16; sy++) R.removeGhostSection(cx, sy, cz);
      }
      this.ghost.chunks.clear();
      this.dirty.clear();
      this.wrongs.clear();
      this.stats = { ok: 0, left: 0, wrong: 0 };
      if (!this.s) return;
      const sz = this.size(), w = this.game.world;
      for (let x = 0; x < sz.w; x++) for (let z = 0; z < sz.l; z++) {
        const wx = this.pos.x + x, wz = this.pos.z + z;
        for (let y = 0; y < sz.h; y++) {
          const wy = this.pos.y + y;
          if (wy > 255) break;
          const t = this.targetAt(wx, wy, wz);
          if (!t) continue;
          const st = this.state(wx, wy, wz, t, w.getId(wx, wy, wz));
          this.stats[st]++;
          if (st === 'ok') continue;
          if (st === 'wrong') this.wrongs.add(key3(wx, wy, wz));
          let c = this.ghost.getChunk(wx >> 4, wz >> 4);
          if (!c) { c = new MC.Chunk(wx >> 4, wz >> 4); this.ghost.chunks.set((wx >> 4) + ',' + (wz >> 4), c); }
          c.set(wx & 15, wy, wz & 15, t[0], t[1]);
        }
      }
      // Блоки записаны напрямую в чанки (без пересчёта света на каждый блок) — перестраиваем все секции
      for (const c of this.ghost.chunks.values()) {
        c.recalcHeight();
        for (let sy = 0; sy < 16; sy++) if (c.sections[sy]) this.dirty.add(c.cx + ',' + sy + ',' + c.cz);
      }
    }

    worldChanged(x, y, z) {
      if (!this.s) return;
      const t = this.targetAt(x, y, z);
      if (!t) return;
      const k = key3(x, y, z);
      const cur = this.game.world.getId(x, y, z);
      // Замена встала в мир; если её потом сломали — клетка снова ждёт блок
      const sub = this.subs.get(k);
      if (sub) { if (cur === sub.id) sub.placed = true; else if (sub.placed) this.subs.delete(k); }
      const had = this.ghost.getId(x, y, z);
      const prev = had ? (this.wrongs.has(k) ? 'wrong' : 'left') : 'ok';
      const now = this.state(x, y, z, t, cur);
      if (prev === now) return;
      this.stats[prev] = Math.max(0, this.stats[prev] - 1);
      this.stats[now]++;
      if (now === 'wrong') this.wrongs.add(k); else this.wrongs.delete(k);
      if (now === 'ok') this.ghost.setBlock(x, y, z, 0, 0);
      else if (!had) this.ghost.setBlock(x, y, z, t[0], t[1]);
    }

    // Поставлена замена (нужного блока не было): клетка считается готовой
    markSub(x, y, z, id) {
      if (!this.s || !this.targetAt(x, y, z)) return;
      this.subs.set(key3(x, y, z), { id, placed: this.game.world.getId(x, y, z) === id });
      this.worldChanged(x, y, z);
    }

    // Перестройка мешей голограммы понемногу каждый кадр
    update(dt) {
      if (!this.s) return;
      const g = this.game;
      if (this.rebuildT > 0) { this.rebuildT -= dt; if (this.rebuildT <= 0) this.rebuild(); }
      const R = g.renderer;
      let n = 0;
      for (const k of this.dirty) {
        this.dirty.delete(k);
        const [cx, sy, cz] = k.split(',').map(Number);
        if (!this.ghost.getChunk(cx, cz)) { R.removeGhostSection(cx, sy, cz); continue; }
        R.setGhostSection(cx, sy, cz, MC.Mesher.buildSection(this.ghost, cx, sy, cz));
        if (++n >= 4) break;
      }
      if (this.printer) {
        this.printT -= dt;
        if (this.printT <= 0) { this.printT = 0.12; this.print(); }
      }
    }

    // Все клетки голограммы (не построенные): [x, y, z, id, data]
    forGhost(fn) {
      for (const [k, c] of this.ghost.chunks) {
        const [cx, cz] = k.split(',').map(Number);
        for (let sy = 0; sy < 16; sy++) {
          const sec = c.sections[sy];
          if (!sec) continue;
          for (let i = 0; i < 4096; i++) {
            const id = sec.ids[i];
            if (id) fn(cx * 16 + (i >> 8), sy * 16 + (i & 15), cz * 16 + ((i >> 4) & 15), id, sec.meta[i]);
          }
        }
      }
    }

    // Материалы: сколько каких блоков ещё нужно и сколько есть в инвентаре
    materials() {
      const need = new Map();
      this.forGhost((x, y, z, id, d) => {
        if (this.wrongs.has(key3(x, y, z))) return;
        const b = MC.Blocks.list[id], v = b && b.variants > 1 ? b.variants : 1;
        const k = id + ':' + (v > 1 ? d % v : 0);
        need.set(k, (need.get(k) || 0) + 1);
      });
      const stock = this.game.building ? this.game.building.stock() : new Map();
      const out = [];
      for (const [k, n] of need) {
        const [id, data] = k.split(':').map(Number);
        out.push({ id, data, need: n, have: stock.get(k) || 0, name: MC.Items.itemName(id, data) });
      }
      out.sort((a, b) => (b.need - b.have) - (a.need - a.have) || b.need - a.need);
      return out;
    }

    // Принтер: ставит недостающие блоки в радиусе досягаемости (в выживании — из инвентаря, при нехватке — замена по настройке)
    print() {
      const g = this.game, p = g.player, w = g.world;
      if (g.dead) return;
      const reach = g.gamemode === 1 ? 5 : 4.5, per = g.gamemode === 1 ? 6 : 2;
      const ex = p.x, ey = p.eyeY, ez = p.z;
      const r = Math.ceil(reach);
      const cands = [];
      for (let x = Math.floor(ex) - r; x <= Math.floor(ex) + r; x++) for (let y = Math.floor(ey) - r; y <= Math.floor(ey) + r; y++) for (let z = Math.floor(ez) - r; z <= Math.floor(ez) + r; z++) {
        const id = this.ghost.getId(x, y, z);
        if (!id) continue;
        const d2 = (x + 0.5 - ex) ** 2 + (y + 0.5 - ey) ** 2 + (z + 0.5 - ez) ** 2;
        if (d2 > reach * reach) continue;
        cands.push([y * 1000 + d2, x, y, z, id, this.ghost.getData(x, y, z)]);
      }
      // Снизу вверх, затем ближние: у каждого блока появляется опора
      cands.sort((a, b) => a[0] - b[0]);
      const eb = g.building;
      // На сервере принтер отдаёт блоки в очередь строительства: она ставит их пакетами, как игрок
      if (g.mode === 'mp') {
        const ops = [];
        for (const [, x, y, z, id, d] of cands) {
          if (!MC.Blocks.list[w.getId(x, y, z)].replaceable || eb.netKeys.has(x + ',' + y + ',' + z)) continue;
          ops.push({ x, y, z, oid: w.getId(x, y, z), odata: w.getData(x, y, z), nid: id, ndata: d });
        }
        if (ops.length) eb.netEnqueue(ops);
        this.printMsg = '';
        return;
      }
      let placed = 0, missing = null;
      const stock = g.gamemode === 0 ? eb.stock() : null;
      for (const [, x, y, z, id, d] of cands) {
        if (placed >= per) break;
        if (!MC.Blocks.list[w.getId(x, y, z)].replaceable) continue;
        if (!eb.canPlaceAt(x, y, z, id)) continue;
        let pid = id, pd = d, sub = false;
        if (stock) {
          const b = MC.Blocks.list[id], v = b.variants > 1 ? b.variants : 1;
          let k = id + ':' + (v > 1 ? d % v : 0);
          if (!(stock.get(k) > 0)) {
            const s2 = eb.findSubstitute(id, d, stock);
            if (!s2) { missing = missing || MC.Items.itemName(id, v > 1 ? d % v : 0); continue; }
            pid = s2.id; pd = s2.data; k = s2.key; sub = true;
          }
          const [iid, idata] = k.split(':').map(Number);
          if (g.sinv.remove(iid, idata, 1) < 1) continue;
          stock.set(k, stock.get(k) - 1);
        }
        if (g.scripts && g.scripts.emit('blockPlace', { x, y, z, id: pid, data: pd }) === false) continue;
        if (sub) this.subs.set(key3(x, y, z), { id: pid, placed: false });
        w.setBlock(x, y, z, pid, pd);
        if (placed === 0) MC.Sound.block(pid, 'place', x + 0.5, y + 0.5, z + 0.5);
        placed++;
      }
      if (placed) p.swingTime = 1;
      this.printMsg = missing && !placed ? 'нет в инвентаре: ' + missing : '';
    }

    // Все недостающие блоки сразу (через историю строительства, можно отменить)
    buildAll() {
      const g = this.game, w = g.world, ops = [];
      this.forGhost((x, y, z, id, d) => {
        if (!g.building.canPlaceAt(x, y, z, id)) return;
        ops.push({ x, y, z, oid: w.getId(x, y, z), odata: w.getData(x, y, z), nid: id, ndata: d });
      });
      ops.sort((a, b) => a.y - b.y);
      g.building.applyNew(ops, 'Построено по схеме');
    }

    hint() {
      if (!this.s) return '';
      const st = this.stats;
      return 'Схема «' + this.s.name + '»: готово ' + st.ok + ', осталось ' + st.left + (st.wrong ? ', мешают ' + st.wrong : '') +
        (this.layer >= 0 ? ' · слой ' + (this.layer + 1) + '/' + this.s.h + (this.layerMode === 'below' ? ' и ниже' : '') : '') +
        (this.printer ? ' · принтер включён' + (this.printMsg ? ' (' + this.printMsg + ')' : '') : '');
    }
  }

  MC.Schematics = { parse, encode, fromClip, list, addFile, store, remove, exportFile, View };
})();
