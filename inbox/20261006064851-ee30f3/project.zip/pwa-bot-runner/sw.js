const CACHE = "bot-runner-v2";
const PRECACHE = [
  "./",
  "./index.html",
  "./css/styles.css",
  "./js/app.js",
  "./js/bot.js",
  "./js/files.js",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(PRECACHE)).catch(() => {}).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (url.hostname === "api.telegram.org") return;
  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});

self.addEventListener("message", (event) => {
  const data = event.data || {};
  if (data.type === "NOTIFY") {
    event.waitUntil(
      self.registration.showNotification(data.title || "Bot Runner", {
        body: data.body || "Бот работает",
        icon: "./icons/icon-192.png",
        tag: "bot-runner",
        requireInteraction: true
      })
    );
  }
  if (data.type === "CLEAR_NOTIFY") {
    event.waitUntil(
      self.registration.getNotifications({ tag: "bot-runner" }).then((list) => list.forEach((n) => n.close()))
    );
  }
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clients) => {
      for (const c of clients) if ("focus" in c) return c.focus();
      return self.clients.openWindow("./index.html");
    })
  );
});
