const TOKEN_KEY = "bot-runner-token";
const META_KEY = "bot-runner-meta";
const $ = (id) => document.getElementById(id);

const ui = {
  onboarding: $("screen-onboarding"),
  main: $("screen-main"),
  token: $("token-input"),
  toggle: $("toggle-token"),
  save: $("save-token"),
  error: $("onboard-error"),
  badge: $("run-badge"),
  start: $("btn-start"),
  stop: $("btn-stop"),
  change: $("btn-change"),
  username: $("stat-username"),
  uptime: $("stat-uptime"),
  lastError: $("stat-error"),
  files: $("files-list"),
  log: $("event-log"),
  tabFiles: $("tab-files"),
  tabLog: $("tab-log"),
  panelFiles: $("panel-files"),
  panelLog: $("panel-log"),
  addLocal: $("add-local")
};

let running = false;
let poll = null;
let startedAt = 0;
let wakeLock = null;
let uptimeTimer = 0;
let botName = "бот";

function token() {
  return localStorage.getItem(TOKEN_KEY) || "";
}
function setToken(value) {
  if (value) localStorage.setItem(TOKEN_KEY, value);
  else localStorage.removeItem(TOKEN_KEY);
}
function meta(next) {
  if (next) localStorage.setItem(META_KEY, JSON.stringify(next));
  try {
    return JSON.parse(localStorage.getItem(META_KEY) || "{}");
  } catch {
    return {};
  }
}
function show(main) {
  ui.onboarding.classList.toggle("active", !main);
  ui.main.classList.toggle("active", main);
}
function log(line) {
  const time = new Date().toLocaleTimeString("ru-RU");
  ui.log.textContent = `[${time}] ${line}\n` + (ui.log.textContent || "");
}
function escapeHtml(s) {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}
function formatSize(n) {
  if (!n) return "—";
  if (n < 1024) return n + " Б";
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + " КБ";
  return (n / 1024 / 1024).toFixed(1) + " МБ";
}

async function renderFiles() {
  const list = await Files.all();
  if (!list.length) {
    ui.files.innerHTML = `<div class="empty">Пока нет файлов. Пришлите документ боту в Telegram или добавьте файл с телефона.</div>`;
    return;
  }
  ui.files.innerHTML = list
    .map((f) => {
      const canDl = Boolean(f.blob || f.url);
      return `<article class="file">
        <h3>${escapeHtml(f.name)}</h3>
        <p>${escapeHtml(f.type || "file")} · ${formatSize(f.size)} · ${new Date(f.date).toLocaleString("ru-RU")}</p>
        <div class="ops">
          ${canDl ? `<button type="button" data-dl="${f.id}">Скачать</button>` : ""}
          <button type="button" data-del="${f.id}">Удалить</button>
        </div>
      </article>`;
    })
    .join("");
}

function setRunning(on) {
  running = on;
  ui.badge.textContent = on ? "Работает" : "Остановлен";
  ui.badge.className = "badge " + (on ? "on" : "off");
  ui.start.classList.toggle("hidden", on);
  ui.stop.classList.toggle("hidden", !on);
}

async function notify(title, body) {
  try {
    const reg = await navigator.serviceWorker.ready;
    reg.active && reg.active.postMessage({ type: "NOTIFY", title, body });
  } catch {}
}
async function clearNotify() {
  try {
    const reg = await navigator.serviceWorker.ready;
    reg.active && reg.active.postMessage({ type: "CLEAR_NOTIFY" });
  } catch {}
}
async function requestWake() {
  try {
    if ("wakeLock" in navigator) wakeLock = await navigator.wakeLock.request("screen");
  } catch {}
}
function releaseWake() {
  try { wakeLock && wakeLock.release(); } catch {}
  wakeLock = null;
}
function startUptime() {
  startedAt = Date.now();
  clearInterval(uptimeTimer);
  uptimeTimer = setInterval(() => {
    const sec = Math.floor((Date.now() - startedAt) / 1000);
    const h = String(Math.floor(sec / 3600)).padStart(2, "0");
    const m = String(Math.floor((sec % 3600) / 60)).padStart(2, "0");
    const s = String(sec % 60).padStart(2, "0");
    ui.uptime.textContent = h + ":" + m + ":" + s;
  }, 1000);
}

async function startBot() {
  const t = token();
  if (!t) return show(false);
  try {
    const me = await Bot.getMe(t);
    botName = me.username ? "@" + me.username : me.first_name || "бот";
    ui.username.textContent = botName;
    meta({ username: botName });
    ui.lastError.textContent = "нет";
    if (poll) poll.stop();
    poll = Bot.poller(t, {
      botName,
      fileCount: async () => (await Files.all()).length,
      onFile: async (entry) => {
        await Files.add(entry);
        await renderFiles();
      },
      onError: (err) => {
        ui.lastError.textContent = err.message;
        log(err.message);
        if (/unauthorized|401|token/i.test(err.message)) stopBot();
      },
      log
    });
    setRunning(true);
    startUptime();
    await requestWake();
    if (Notification.permission === "granted") await notify("Bot Runner", botName + " запущен");
    log("бот запущен");
  } catch (err) {
    ui.lastError.textContent = err.message;
    log(err.message);
    alert(err.message);
  }
}

function stopBot() {
  if (poll) poll.stop();
  poll = null;
  setRunning(false);
  releaseWake();
  clearNotify();
  log("бот остановлен");
}

async function saveToken() {
  const value = ui.token.value.trim();
  ui.error.textContent = "";
  if (!value) {
    ui.error.textContent = "Введите токен.";
    return;
  }
  if (!Bot.validateFormat(value)) {
    ui.error.textContent = "Неверный формат токена.";
    return;
  }
  try {
    ui.save.disabled = true;
    const me = await Bot.getMe(value);
    setToken(value);
    const name = me.username ? "@" + me.username : me.first_name || "бот";
    meta({ username: name });
    ui.username.textContent = name;
    show(true);
    log("токен принят: " + name);
  } catch (err) {
    ui.error.textContent = err.message === "Failed to fetch" ? "Нет сети или Telegram недоступен." : err.message;
  } finally {
    ui.save.disabled = false;
  }
}

function bind() {
  ui.save.addEventListener("click", saveToken);
  ui.toggle.addEventListener("click", () => {
    ui.token.type = ui.token.type === "password" ? "text" : "password";
  });
  ui.start.addEventListener("click", async () => {
    if (Notification.permission === "default") await Notification.requestPermission();
    startBot();
  });
  ui.stop.addEventListener("click", stopBot);
  ui.change.addEventListener("click", () => {
    if (!confirm("Сменить токен? Бот будет остановлен.")) return;
    stopBot();
    setToken("");
    ui.token.value = "";
    show(false);
  });
  ui.tabFiles.addEventListener("click", () => {
    ui.tabFiles.classList.add("active");
    ui.tabLog.classList.remove("active");
    ui.panelFiles.classList.remove("hidden");
    ui.panelLog.classList.add("hidden");
  });
  ui.tabLog.addEventListener("click", () => {
    ui.tabLog.classList.add("active");
    ui.tabFiles.classList.remove("active");
    ui.panelLog.classList.remove("hidden");
    ui.panelFiles.classList.add("hidden");
  });
  ui.files.addEventListener("click", async (e) => {
    const del = e.target.getAttribute("data-del");
    const dl = e.target.getAttribute("data-dl");
    if (del) {
      await Files.remove(del);
      await renderFiles();
    }
    if (dl) {
      try {
        await Files.download(dl);
      } catch (err) {
        alert(err.message);
        log(err.message);
      }
    }
  });
  ui.addLocal.addEventListener("change", async (e) => {
    const picked = Array.from(e.target.files || []);
    for (const file of picked) {
      await Files.add({ name: file.name, size: file.size, type: file.type, blob: file });
    }
    e.target.value = "";
    await renderFiles();
    log("добавлено локальных файлов: " + picked.length);
  });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && running) requestWake();
  });
}

function isFileOrigin() {
  return location.protocol === "file:";
}

async function registerSw() {
  if (isFileOrigin()) {
    log("открыто как файл. Service worker не нужен для запуска бота. Для APK выложи папку на HTTPS и собери в PWA Builder.");
    return;
  }
  if (!("serviceWorker" in navigator)) return;
  try {
    await navigator.serviceWorker.register("./sw.js");
    log("service worker готов");
  } catch (err) {
    log("уведомления недоступны: " + err.message);
  }
}

function boot() {
  ui.log.textContent = "";
  bind();
  registerSw();
  renderFiles();
  const saved = token();
  const m = meta();
  if (m.username) ui.username.textContent = m.username;
  setRunning(false);
  show(Boolean(saved));
  if (saved) log("токен на месте. Нажми «Запуск», затем напиши боту /start в Telegram.");
  if (new URLSearchParams(location.search).get("action") === "start" && saved) startBot();
}

boot();
