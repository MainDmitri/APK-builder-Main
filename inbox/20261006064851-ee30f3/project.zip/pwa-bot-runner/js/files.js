const Files = (() => {
  const DB_NAME = "bot-runner-db";
  const STORE = "files";

  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(STORE, { keyPath: "id" });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function all() {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).getAll();
      req.onsuccess = () => {
        const rows = (req.result || []).sort((a, b) => String(b.date).localeCompare(String(a.date)));
        resolve(rows);
      };
      req.onerror = () => reject(req.error);
    });
  }

  async function add(entry) {
    const db = await openDb();
    const row = {
      id: entry.id || (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())),
      name: entry.name || "file",
      size: entry.size || (entry.blob && entry.blob.size) || 0,
      type: entry.type || (entry.blob && entry.blob.type) || "application/octet-stream",
      date: entry.date || new Date().toISOString(),
      url: entry.url || "",
      fileId: entry.fileId || "",
      blob: entry.blob || null
    };
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(row);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    return all();
  }

  async function get(id) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const req = db.transaction(STORE, "readonly").objectStore(STORE).get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async function remove(id) {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    return all();
  }

  function triggerDownload(blob, name) {
    const href = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = href;
    a.download = name || "file";
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(href), 2000);
  }

  async function download(id) {
    const item = await get(id);
    if (!item) throw new Error("Файл не найден");
    if (item.blob instanceof Blob) {
      triggerDownload(item.blob, item.name);
      return;
    }
    if (item.url) {
      const res = await fetch(item.url);
      if (!res.ok) throw new Error("Не удалось скачать файл");
      const blob = await res.blob();
      await add({ ...item, blob, size: blob.size, type: blob.type || item.type });
      triggerDownload(blob, item.name);
      return;
    }
    throw new Error("У файла нет данных для скачивания");
  }

  return { all, add, get, remove, download };
})();
