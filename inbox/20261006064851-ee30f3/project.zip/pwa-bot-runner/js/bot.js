const Bot = (() => {
  const TOKEN_RE = /^\d+:[A-Za-z0-9_-]{30,}$/;

  function api(token, method, payload) {
    return fetch(`https://api.telegram.org/bot${token}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: payload ? JSON.stringify(payload) : "{}"
    }).then(async (res) => {
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.ok === false) {
        throw new Error(data.description || `HTTP ${res.status}`);
      }
      return data.result;
    });
  }

  function validateFormat(token) {
    return TOKEN_RE.test((token || "").trim());
  }

  function getMe(token) {
    return api(token, "getMe");
  }

  function sendMessage(token, chatId, text) {
    return api(token, "sendMessage", { chat_id: chatId, text });
  }

  function getFile(token, fileId) {
    return api(token, "getFile", { file_id: fileId });
  }

  function fileUrl(token, filePath) {
    return `https://api.telegram.org/file/bot${token}/${filePath}`;
  }

  async function fetchBlob(url) {
    try {
      const res = await fetch(url);
      if (!res.ok) return null;
      return await res.blob();
    } catch {
      return null;
    }
  }

  async function handleUpdate(token, update, hooks) {
    const msg = update.message;
    if (!msg) return;

    if (msg.text === "/start") {
      await sendMessage(token, msg.chat.id, `Привет. Я ${hooks.botName || "бот"}. Пришли файл — сохраню во вкладке «Файлы бота». /files — сколько файлов уже есть.`);
      hooks.log?.(`/start от ${msg.chat.id}`);
      return;
    }

    if (msg.text === "/files") {
      const n = await hooks.fileCount();
      await sendMessage(token, msg.chat.id, `Локально файлов: ${n}`);
      hooks.log?.(`/files → ${n}`);
      return;
    }

    const doc = msg.document || msg.video || msg.audio || msg.voice;
    const photo = Array.isArray(msg.photo) ? msg.photo[msg.photo.length - 1] : null;
    const media = doc || photo;
    if (!media || !media.file_id) return;

    const meta = await getFile(token, media.file_id);
    const url = meta.file_path ? fileUrl(token, meta.file_path) : "";
    const blob = url ? await fetchBlob(url) : null;
    const name = (doc && doc.file_name) || (photo ? `photo_${media.file_id}.jpg` : media.file_id);
    await hooks.onFile({
      name,
      size: media.file_size || meta.file_size || (blob && blob.size) || 0,
      type: (doc && doc.mime_type) || (photo ? "image/jpeg" : "application/octet-stream"),
      fileId: media.file_id,
      url,
      blob
    });
    await sendMessage(token, msg.chat.id, `Файл сохранён: ${name}`);
    hooks.log?.(`файл: ${name}`);
  }

  function poller(token, hooks) {
    let offset = 0;
    let stopped = false;
    let timer = 0;

    async function tick() {
      if (stopped) return;
      try {
        const updates = await api(token, "getUpdates", {
          offset,
          timeout: 25,
          allowed_updates: ["message"]
        });
        for (const u of updates) {
          offset = u.update_id + 1;
          await handleUpdate(token, u, hooks);
        }
        hooks.onAlive?.();
      } catch (err) {
        hooks.onError?.(err);
      }
      if (!stopped) timer = setTimeout(tick, 400);
    }

    tick();
    return {
      stop() {
        stopped = true;
        clearTimeout(timer);
      }
    };
  }

  return { validateFormat, getMe, poller };
})();
