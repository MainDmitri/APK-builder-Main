package com.dahua.checker

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var scanServiceState = mutableStateOf<ScanService?>(null)
    private var serviceBound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            scanServiceState.value = (binder as ScanService.ScanBinder).getService()
            serviceBound = true
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            scanServiceState.value = null
            serviceBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        PluginManager.init(this)
        requestBatteryOptimization()
        requestNotificationPermission()

        setContent {
            val dark = darkColorScheme(
                primary = Wine,
                secondary = WineLight,
                tertiary = Red400,
                background = BgDark,
                surface = SurfaceDark,
                surfaceVariant = SurfaceDark2,
                onBackground = Color(0xFFE6DDE0),
                onSurface = Color(0xFFE6DDE0),
                onSurfaceVariant = Gray500,
                outline = BorderDark
            )
            MaterialTheme(colorScheme = dark) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppRoot(
                        onStartScan = { ips, port, multiPort, selectedPorts, pluginId -> startScanService(ips, port, multiPort, selectedPorts, pluginId) },
                        onStopScan = { scanServiceState.value?.stopScan() },
                        scanService = scanServiceState.value
                    )
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Intent(this, ScanService::class.java).also { bindService(it, connection, Context.BIND_AUTO_CREATE) }
    }

    override fun onStop() {
        super.onStop()
        if (serviceBound) { unbindService(connection); serviceBound = false }
    }

    private fun startScanService(ips: List<String>, port: Int, multiPort: Boolean, selectedPorts: List<Int>?, pluginId: String? = null) {
        try {
            if (!serviceBound) {
                Intent(this, ScanService::class.java).also { bindService(it, connection, Context.BIND_AUTO_CREATE) }
            }
            ScanService.pendingIps = ips
            val intent = Intent(this, ScanService::class.java).apply {
                action = ScanService.ACTION_START
                putExtra(ScanService.EXTRA_PORT, port)
                putExtra(ScanService.EXTRA_MULTI_PORT, multiPort)
                if (selectedPorts != null) {
                    putExtra(ScanService.EXTRA_SELECTED_PORTS, selectedPorts.toIntArray())
                }
                if (pluginId != null) {
                    putExtra(ScanService.EXTRA_PLUGIN_ID, pluginId)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
            else startService(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка запуска: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestBatteryOptimization() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                })
            } catch (_: Exception) {}
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}

// ─── Винная палитра ───
val Wine = Color(0xFFB23A48)
val WineLight = Color(0xFFD4626E)
val WineDark = Color(0xFF8B1A2B)
val WineAccent = Color(0xFFE8899A)
val BgDark = Color(0xFF140A0E)
val SurfaceDark = Color(0xFF1E1215)
val SurfaceDark2 = Color(0xFF2A1A20)
val BorderDark = Color(0xFF3D2530)
val Gray500 = Color(0xFF9E8B91)
val Red400 = Color(0xFFFF5252)
val Orange400 = Color(0xFFFFB74D)
val Yellow400 = Color(0xFFFFEE58)
val Cyan400 = Color(0xFFD4A5A5)
val Purple400 = Color(0xFFCE93D8)

fun brandColor(brand: String): Color = when {
    "Hikvision" in brand -> Color(0xFFFF6B6B)
    "Dahua" in brand -> Wine
    "XMeye" in brand -> Purple400
    "SSH" in brand -> Color(0xFFFFA726)
    "Telnet" in brand -> Color(0xFFEF5350)
    else -> WineLight
}

fun isTerminal(brand: String): Boolean = brand in setOf("SSH", "Telnet")

data class PortOption(val port: Int, val label: String, val color: Color)

val ALL_PORT_OPTIONS = listOf(
    PortOption(37777, "Dahua", Wine),
    PortOption(80, "HTTP 80", WineLight),
    PortOption(8080, "HTTP 8080", WineLight),
    PortOption(8000, "HTTP 8000", WineLight),
    PortOption(8899, "HTTP 8899", WineLight),
    PortOption(34567, "XMeye", Purple400),
    PortOption(22, "SSH", Color(0xFFFFA726)),
    PortOption(23, "Telnet", Color(0xFFEF5350))
)

// ─── Корневой роутер: авторизация или приложение ───
@Composable
fun AppRoot(
    onStartScan: (List<String>, Int, Boolean, List<Int>?, String?) -> Unit,
    onStopScan: () -> Unit,
    scanService: ScanService?
) {
    val context = LocalContext.current
    var isActivated by remember { mutableStateOf(AuthManager.isActivated(context)) }
    var showAdminPanel by remember { mutableStateOf(false) }

    if (!isActivated) {
        ActivationScreen(
            onActivated = { isActivated = true },
            onAdminRequest = { showAdminPanel = true }
        )
    } else {
        DahuaApp(
            onStartScan = onStartScan,
            onStopScan = onStopScan,
            scanService = scanService,
            onAdminRequest = { showAdminPanel = true }
        )
    }

    if (showAdminPanel) {
        AdminPanelFlow(onDismiss = { showAdminPanel = false })
    }
}

// ─── Экран активации ───
@Composable
fun ActivationScreen(
    onActivated: () -> Unit,
    onAdminRequest: () -> Unit
) {
    val context = LocalContext.current
    var nickname by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var attempts by remember { mutableIntStateOf(0) }
    var blocked by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var adminTapCount by remember { mutableIntStateOf(0) }
    var lastTapTime by remember { mutableLongStateOf(0L) }
    val scope = rememberCoroutineScope()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgDark, SurfaceDark, BgDark)))
    ) {
        // Невидимая кнопка админ-панели — правый верхний угол
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 40.dp, end = 8.dp)
                .size(48.dp)
                .pointerInput(Unit) {
                    detectTapGestures {
                        val now = System.currentTimeMillis()
                        if (now - lastTapTime < 500) {
                            adminTapCount++
                        } else {
                            adminTapCount = 1
                        }
                        lastTapTime = now
                        if (adminTapCount >= 2) {
                            adminTapCount = 0
                            onAdminRequest()
                        }
                    }
                }
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.Center)
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Логотип
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.verticalGradient(listOf(Wine, WineDark))),
                contentAlignment = Alignment.Center
            ) {
                Text("🔍", fontSize = 40.sp)
            }

            Spacer(Modifier.height(20.dp))

            Text("Main Scanner", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Введите данные для активации", fontSize = 14.sp, color = Gray500)

            Spacer(Modifier.height(32.dp))

            // Поле ника
            OutlinedTextField(
                value = nickname,
                onValueChange = { nickname = it.take(20); error = null },
                label = { Text("Никнейм", color = Gray500) },
                placeholder = { Text("Ваш никнейм", color = Gray500.copy(alpha = 0.5f)) },
                singleLine = true,
                enabled = !blocked,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Wine,
                    unfocusedBorderColor = BorderDark,
                    cursorColor = Wine,
                    focusedContainerColor = SurfaceDark,
                    unfocusedContainerColor = SurfaceDark
                )
            )

            Spacer(Modifier.height(12.dp))

            // Поле кода
            OutlinedTextField(
                value = code,
                onValueChange = { code = it.uppercase().take(14); error = null },
                label = { Text("Код активации", color = Gray500) },
                placeholder = { Text("XXXX-XXXX-XXXX", color = Gray500.copy(alpha = 0.5f)) },
                singleLine = true,
                enabled = !blocked,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Wine,
                    unfocusedBorderColor = BorderDark,
                    cursorColor = Wine,
                    focusedContainerColor = SurfaceDark,
                    unfocusedContainerColor = SurfaceDark
                )
            )

            if (error != null) {
                Spacer(Modifier.height(8.dp))
                Text(error!!, color = Red400, fontSize = 13.sp)
            }

            if (blocked) {
                Spacer(Modifier.height(8.dp))
                Text("Слишком много попыток. Подождите.", color = Orange400, fontSize = 13.sp)
            }

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = {
                    if (blocked || loading) return@Button
                    if (nickname.isBlank()) { error = "Введите никнейм"; return@Button }
                    if (code.isBlank()) { error = "Введите код активации"; return@Button }
                    if (nickname.length < 2) { error = "Минимум 2 символа для никнейма"; return@Button }

                    loading = true
                    error = null
                    val result = AuthManager.activate(context, nickname.trim(), code.trim())
                    loading = false
                    result.onSuccess { success ->
                        if (success) {
                            Toast.makeText(context, "Активация успешна! Добро пожаловать, ${nickname.trim()}", Toast.LENGTH_LONG).show()
                            onActivated()
                        } else {
                            attempts++
                            if (attempts >= 5) {
                                blocked = true
                                error = "Неверный код"
                            } else {
                                error = "Неверный код активации (попытка $attempts/5)"
                            }
                        }
                    }.onFailure { e ->
                        error = "Ошибка: ${e.message}"
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                enabled = !blocked && !loading,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Wine,
                    contentColor = Color.White,
                    disabledContainerColor = Wine.copy(alpha = 0.3f)
                )
            ) {
                if (loading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text("Проверка...", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                } else {
                    Icon(Icons.Default.Lock, null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Активировать", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }

            Spacer(Modifier.height(16.dp))

            Text(
                "Код можно получить у администратора",
                fontSize = 12.sp,
                color = Gray500.copy(alpha = 0.6f),
                textAlign = TextAlign.Center
            )
        }
    }
}

// ─── Админ-панель: сначала пароль, потом панель ───
@Composable
fun AdminPanelFlow(onDismiss: () -> Unit) {
    var authenticated by remember { mutableStateOf(false) }

    if (!authenticated) {
        AdminLoginDialog(
            onAuthenticated = { authenticated = true },
            onDismiss = onDismiss
        )
    } else {
        AdminPanelDialog(onDismiss = {
            authenticated = false
            onDismiss()
        })
    }
}

@Composable
fun AdminLoginDialog(onAuthenticated: () -> Unit, onDismiss: () -> Unit) {
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var attempts by remember { mutableIntStateOf(0) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier.size(56.dp).clip(CircleShape).background(Wine.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Lock, null, tint = Wine, modifier = Modifier.size(28.dp))
                }

                Spacer(Modifier.height(16.dp))

                Text("Админ-панель", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Введите пароль администратора", fontSize = 13.sp, color = Gray500)

                Spacer(Modifier.height(16.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; error = null },
                    label = { Text("Пароль", color = Gray500) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Wine,
                        unfocusedBorderColor = BorderDark,
                        cursorColor = Wine,
                        focusedContainerColor = BgDark,
                        unfocusedContainerColor = BgDark
                    )
                )

                if (error != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(error!!, color = Red400, fontSize = 13.sp)
                }

                Spacer(Modifier.height(20.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text("Отмена", color = Gray500)
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (AuthManager.verifyAdminPassword(password)) {
                                onAuthenticated()
                            } else {
                                attempts++
                                error = if (attempts >= 3) "Доступ заблокирован" else "Неверный пароль ($attempts/3)"
                                if (attempts >= 3) {
                                    onDismiss()
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Wine)
                    ) {
                        Text("Войти", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminPanelDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    var selectedAdminTab by remember { mutableIntStateOf(0) }
    var genNickname by remember { mutableStateOf("") }
    var generatedCode by remember { mutableStateOf<String?>(null) }
    var genLoading by remember { mutableStateOf(false) }
    var genError by remember { mutableStateOf<String?>(null) }
    val users = remember { mutableStateListOf<UserInfo>() }
    var usersLoading by remember { mutableStateOf(true) }
    var usersError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        val result = AuthManager.getUsers(context)
        usersLoading = false
        result.onSuccess { list ->
            users.clear()
            users.addAll(list)
        }.onFailure { e ->
            usersError = "Ошибка загрузки: ${e.message}"
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(16.dp).fillMaxHeight(0.85f),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Заголовок
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(WineDark, SurfaceDark)))
                        .padding(20.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(40.dp).clip(CircleShape).background(Wine.copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Settings, null, tint = WineAccent, modifier = Modifier.size(22.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Админ-панель", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Управление кодами и пользователями", fontSize = 12.sp, color = Gray500)
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, null, tint = Gray500)
                        }
                    }
                }

                // Табы админки
                TabRow(
                    selectedTabIndex = selectedAdminTab,
                    containerColor = SurfaceDark,
                    contentColor = Wine,
                    divider = { HorizontalDivider(color = BorderDark, thickness = 1.dp) },
                    indicator = { }
                ) {
                    Tab(selected = selectedAdminTab == 0, onClick = { selectedAdminTab = 0 },
                        text = { Text("🔑 Генерация", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                        selectedContentColor = Wine, unselectedContentColor = Gray500)
                    Tab(selected = selectedAdminTab == 1, onClick = { selectedAdminTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("👥 Пользователи", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                if (users.isNotEmpty()) {
                                    Spacer(Modifier.width(4.dp))
                                    Box(modifier = Modifier.clip(CircleShape).background(Wine).padding(horizontal = 6.dp, vertical = 1.dp)) {
                                        Text("${users.size}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        },
                        selectedContentColor = Wine, unselectedContentColor = Gray500)
                }

                when (selectedAdminTab) {
                    0 -> {
                        // Генерация кодов
                        Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
                            Text("Генерация кода активации", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Введите никнейм пользователя для генерации уникального кода", fontSize = 13.sp, color = Gray500)

                            Spacer(Modifier.height(20.dp))

                            OutlinedTextField(
                                value = genNickname,
                                onValueChange = { genNickname = it.take(20); generatedCode = null },
                                label = { Text("Никнейм пользователя", color = Gray500) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Wine,
                                    unfocusedBorderColor = BorderDark,
                                    cursorColor = Wine,
                                    focusedContainerColor = BgDark,
                                    unfocusedContainerColor = BgDark
                                )
                            )

                            Spacer(Modifier.height(16.dp))

                            if (genError != null) {
                                Text(genError!!, color = Red400, fontSize = 13.sp)
                                Spacer(Modifier.height(8.dp))
                            }

                            Button(
                                onClick = {
                                    if (genNickname.isNotBlank() && genNickname.length >= 2 && !genLoading) {
                                        genLoading = true
                                        genError = null
                                        val result = AuthManager.generateCode(context, genNickname.trim())
                                        genLoading = false
                                        result.onSuccess { code ->
                                            generatedCode = code
                                            AuthManager.getUsers(context).onSuccess { list ->
                                                users.clear()
                                                users.addAll(list)
                                            }
                                        }.onFailure { e ->
                                            genError = "Ошибка: ${e.message}"
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                enabled = genNickname.length >= 2 && !genLoading,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Wine,
                                    disabledContainerColor = Wine.copy(alpha = 0.3f)
                                )
                            ) {
                                if (genLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                                    Spacer(Modifier.width(8.dp))
                                }
                                Text(if (genLoading) "Генерация..." else "Сгенерировать код", fontWeight = FontWeight.Bold)
                            }

                            if (generatedCode != null) {
                                Spacer(Modifier.height(24.dp))

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BgDark),
                                    shape = RoundedCornerShape(16.dp),
                                    border = BorderStroke(1.dp, Wine.copy(alpha = 0.3f))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(20.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("Код для: ${genNickname.trim()}", fontSize = 13.sp, color = Gray500)
                                        Spacer(Modifier.height(12.dp))
                                        Text(
                                            generatedCode!!,
                                            fontSize = 28.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            color = Wine,
                                            letterSpacing = 2.sp
                                        )
                                        Spacer(Modifier.height(16.dp))

                                        Button(
                                            onClick = {
                                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                cm.setPrimaryClip(ClipData.newPlainText("code", generatedCode))
                                                Toast.makeText(context, "Код скопирован", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Wine.copy(alpha = 0.2f), contentColor = Wine)
                                        ) {
                                            Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Копировать код", fontWeight = FontWeight.SemiBold)
                                        }

                                        Spacer(Modifier.height(8.dp))

                                        Button(
                                            onClick = {
                                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                val text = "Никнейм: ${genNickname.trim()}\nКод: $generatedCode"
                                                cm.setPrimaryClip(ClipData.newPlainText("code_full", text))
                                                Toast.makeText(context, "Скопировано с никнеймом", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark2, contentColor = WineLight)
                                        ) {
                                            Text("Копировать ник + код", fontSize = 13.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        // Список пользователей
                        if (users.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("👥", fontSize = 48.sp)
                                    Spacer(Modifier.height(12.dp))
                                    Text("Нет зарегистрированных пользователей", fontSize = 14.sp, color = Gray500)
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp)
                            ) {
                                item {
                                    Text(
                                        "Всего: ${users.size} пользователей",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = WineLight,
                                        modifier = Modifier.padding(bottom = 4.dp)
                                    )
                                }
                                items(users, key = { it.nickname }) { user ->
                                    val dateFmt = remember(user.activatedAt) {
                                        java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale.getDefault())
                                            .format(java.util.Date(user.activatedAt))
                                    }
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BgDark),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier.size(40.dp).clip(CircleShape).background(Wine.copy(alpha = 0.2f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    user.nickname.take(1).uppercase(),
                                                    fontSize = 18.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Wine
                                                )
                                            }
                                            Spacer(Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(user.nickname, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                                                Text(user.code, fontSize = 12.sp, color = Gray500, fontFamily = FontFamily.Monospace)
                                                Text(dateFmt, fontSize = 11.sp, color = Gray500.copy(alpha = 0.7f))
                                            }
                                            // Удалить пользователя
                                            IconButton(onClick = {
                                                AuthManager.deleteUser(context, user.nickname)
                                                users.removeAll { it.nickname == user.nickname }
                                                Toast.makeText(context, "Удалён: ${user.nickname}", Toast.LENGTH_SHORT).show()
                                            }) {
                                                Icon(Icons.Default.Delete, null, tint = Red400.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ─── Основное приложение ───
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DahuaApp(
    onStartScan: (List<String>, Int, Boolean, List<Int>?, String?) -> Unit,
    onStopScan: () -> Unit,
    scanService: ScanService?,
    onAdminRequest: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var ipInput by remember { mutableStateOf("") }
    var portInput by remember { mutableStateOf("37777") }
    var parseError by remember { mutableStateOf<String?>(null) }
    var selectedResult by remember { mutableStateOf<ScanResult?>(null) }
    var multiPortMode by remember { mutableStateOf(false) }
    var portSelectMode by remember { mutableStateOf(false) }
    val selectedPorts = remember { mutableStateListOf<Int>() }
    var showAbout by remember { mutableStateOf(false) }
    var activePluginId by remember { mutableStateOf<String?>(null) }

    var isScanning by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<ScanProgress?>(null) }
    val results = remember { mutableStateListOf<ScanResult>() }
    val savedResults = remember { mutableStateListOf<ScanResult>() }
    val storedResults = remember { mutableStateListOf<ScanResult>() }

    val context = LocalContext.current

    // Переменные для скрытой кнопки админ-панели в хедере
    var adminTapCount by remember { mutableIntStateOf(0) }
    var lastAdminTap by remember { mutableLongStateOf(0L) }

    LaunchedEffect(Unit) {
        val loaded = ResultStorage.load(context)
        storedResults.addAll(loaded)
    }

    LaunchedEffect(scanService) {
        scanService?.let { svc ->
            launch { svc.isScanning.collect { isScanning = it } }
            launch { svc.progress.collect { p -> if (p != null) progress = p } }
            launch { svc.results.collect { r ->
                results.add(0, r)
                if (!r.blocked) {
                    savedResults.add(0, r)
                    ResultStorage.addResult(context, r)
                    storedResults.removeAll { it.ip == r.ip && it.port == r.port }
                    storedResults.add(0, r)
                }
            }}
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // ─── Header ───
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(BgDark, SurfaceDark)))
                .padding(top = 48.dp, bottom = 12.dp, start = 16.dp, end = 16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Wine.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) { Text("🔍", fontSize = 22.sp) }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Main Scanner", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    val nickname = AuthManager.getActiveNickname(context)
                    Text(
                        when {
                            portSelectMode && selectedPorts.isNotEmpty() -> "Порты: ${selectedPorts.sorted().joinToString(",")}"
                            multiPortMode -> "Multi-port × ${DahuaScanner.MAX_CONCURRENT}"
                            nickname.isNotEmpty() -> "👤 $nickname"
                            else -> "Dahua × ${DahuaScanner.MAX_CONCURRENT}"
                        },
                        fontSize = 12.sp, color = Gray500
                    )
                }
                if (results.isNotEmpty()) {
                    Box(
                        modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(Wine.copy(alpha = 0.2f)).padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("${results.count { !it.blocked }}", color = Wine, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                }
                // Кнопка "О приложении"
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(SurfaceDark2)
                        .clickable { showAbout = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Info, contentDescription = "О приложении", tint = Gray500, modifier = Modifier.size(20.dp))
                }
                // Невидимая кнопка админки — за info кнопкой
                Spacer(Modifier.width(2.dp))
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .pointerInput(Unit) {
                            detectTapGestures {
                                val now = System.currentTimeMillis()
                                if (now - lastAdminTap < 500) {
                                    adminTapCount++
                                } else {
                                    adminTapCount = 1
                                }
                                lastAdminTap = now
                                if (adminTapCount >= 2) {
                                    adminTapCount = 0
                                    onAdminRequest()
                                }
                            }
                        }
                )
            }
        }

        // ─── Tabs ───
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = BgDark,
            contentColor = Wine,
            divider = { HorizontalDivider(color = BorderDark, thickness = 1.dp) },
            indicator = { }
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 },
                text = { Text("Сканер", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                selectedContentColor = Wine, unselectedContentColor = Gray500)
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Находки", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        if (savedResults.isNotEmpty()) {
                            Spacer(Modifier.width(6.dp))
                            Box(modifier = Modifier.clip(CircleShape).background(Wine).padding(horizontal = 6.dp, vertical = 1.dp)) {
                                Text("${savedResults.size}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                },
                selectedContentColor = Wine, unselectedContentColor = Gray500)
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("💾 Сохр.", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        if (storedResults.isNotEmpty()) {
                            Spacer(Modifier.width(6.dp))
                            Box(modifier = Modifier.clip(CircleShape).background(WineLight).padding(horizontal = 6.dp, vertical = 1.dp)) {
                                Text("${storedResults.size}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                },
                selectedContentColor = WineLight, unselectedContentColor = Gray500)
            Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🔌 Плагины", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        val cnt = PluginManager.getPlugins().size
                        if (cnt > 0) {
                            Spacer(Modifier.width(6.dp))
                            Box(modifier = Modifier.clip(CircleShape).background(Purple400).padding(horizontal = 6.dp, vertical = 1.dp)) {
                                Text("$cnt", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                },
                selectedContentColor = Purple400, unselectedContentColor = Gray500)
        }

        when (selectedTab) {
            0 -> ScannerTab(
                ipInput = ipInput, onIpChange = { ipInput = it; parseError = null },
                portInput = portInput, onPortChange = { portInput = it.filter { c -> c.isDigit() }.take(5) },
                parseError = parseError, isScanning = isScanning, progress = progress, results = results,
                multiPortMode = multiPortMode, onMultiPortChange = { multiPortMode = it; if (it) portSelectMode = false },
                portSelectMode = portSelectMode, onPortSelectChange = { portSelectMode = it; if (it) multiPortMode = false },
                selectedPorts = selectedPorts,
                onScan = {
                    val ips = IpParser.parseMultiline(ipInput)
                    if (ips.isEmpty()) { parseError = "Некорректный ввод IP"; return@ScannerTab }
                    if (ips.size > 65536) { parseError = "Максимум 65536 IP"; return@ScannerTab }
                    val port = portInput.toIntOrNull() ?: DahuaScanner.DEFAULT_PORT
                    parseError = null; results.clear()
                    progress = ScanProgress(ips.size, 0, 0, 0, 0)
                    val ports = if (portSelectMode && selectedPorts.isNotEmpty()) selectedPorts.toList() else null
                    onStartScan(ips, port, multiPortMode, ports, activePluginId)
                },
                onStop = onStopScan,
                onResultClick = { selectedResult = it },
                onMyNetwork = {
                    val net = NetworkUtils.getLocalNetwork(context)
                    if (net != null) {
                        ipInput = net.subnet
                        Toast.makeText(context, "Сеть: ${net.subnet} (${net.ip})", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Не удалось определить сеть WiFi", Toast.LENGTH_SHORT).show()
                    }
                },
                context = context
            )
            1 -> FindingsTab(results = savedResults, onResultClick = { selectedResult = it }, context = context)
            2 -> StoredTab(
                results = storedResults,
                onResultClick = { selectedResult = it },
                onDelete = { r ->
                    ResultStorage.delete(context, r.ip, r.port)
                    storedResults.removeAll { it.ip == r.ip && it.port == r.port }
                },
                onClearAll = {
                    ResultStorage.clear(context)
                    storedResults.clear()
                },
                context = context
            )
            3 -> PluginsTab(
                activePluginId = activePluginId,
                onPluginSelected = { id ->
                    activePluginId = if (activePluginId == id) null else id
                },
                context = context
            )
        }
    }

    selectedResult?.let { r -> SnapshotFullDialog(r, context) { selectedResult = null } }

    if (showAbout) { AboutDialog { showAbout = false } }
}

// ─── Вкладка "Плагины" ───
@Composable
fun PluginsTab(activePluginId: String?, onPluginSelected: (String) -> Unit, context: Context) {
    val plugins = remember { mutableStateListOf<ScanPlugin>() }
    var showInstallDialog by remember { mutableStateOf(false) }
    var showJsonInput by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        plugins.clear()
        plugins.addAll(PluginManager.getPlugins())
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Кнопки управления
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { showInstallDialog = true },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Wine, contentColor = Color.White)
            ) {
                Text("📥 Установить", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
                onClick = { showJsonInput = true },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Wine),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = WineLight)
            ) {
                Text("📋 Вставить JSON", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (activePluginId != null) {
            val active = plugins.find { it.id == activePluginId }
            if (active != null) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = Wine.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("⚡", fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Активный плагин", fontSize = 11.sp, color = Gray500)
                            Text(active.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Wine)
                        }
                        TextButton(onClick = { onPluginSelected(activePluginId) }) {
                            Text("Выкл", color = Red400, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        if (plugins.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🔌", fontSize = 56.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("Нет установленных плагинов", fontSize = 15.sp, color = Gray500)
                    Spacer(Modifier.height(8.dp))
                    Text("Плагины добавляют новые\nметоды сканирования", fontSize = 13.sp, color = Gray500.copy(alpha = 0.7f), textAlign = TextAlign.Center)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp)
            ) {
                items(plugins, key = { it.id }) { plugin ->
                    PluginCard(
                        plugin = plugin,
                        isActive = plugin.id == activePluginId,
                        onToggle = { onPluginSelected(plugin.id) },
                        onEnable = { enabled ->
                            PluginManager.setPluginEnabled(context, plugin.id, enabled)
                            val idx = plugins.indexOfFirst { it.id == plugin.id }
                            if (idx >= 0) plugins[idx] = plugins[idx].copy(enabled = enabled)
                        },
                        onDelete = {
                            PluginManager.removePlugin(context, plugin.id)
                            plugins.removeAll { it.id == plugin.id }
                            if (activePluginId == plugin.id) onPluginSelected(plugin.id)
                            Toast.makeText(context, "Удалён: ${plugin.name}", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }

    // Диалог установки по URL
    if (showInstallDialog) {
        var url by remember { mutableStateOf("") }
        var loading by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf<String?>(null) }

        Dialog(onDismissRequest = { if (!loading) showInstallDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("📥 Установить плагин", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(4.dp))
                    Text("Вставьте URL файла плагина (.json)", fontSize = 13.sp, color = Gray500)
                    Spacer(Modifier.height(16.dp))

                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it; error = null },
                        label = { Text("URL плагина", color = Gray500) },
                        placeholder = { Text("https://...", color = Gray500.copy(alpha = 0.5f)) },
                        singleLine = true,
                        enabled = !loading,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Wine,
                            unfocusedBorderColor = BorderDark,
                            cursorColor = Wine,
                            focusedContainerColor = BgDark,
                            unfocusedContainerColor = BgDark
                        )
                    )

                    if (error != null) {
                        Spacer(Modifier.height(8.dp))
                        Text(error!!, color = Red400, fontSize = 12.sp)
                    }

                    Spacer(Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showInstallDialog = false }, enabled = !loading) {
                            Text("Отмена", color = Gray500)
                        }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (url.isBlank()) { error = "Вставьте URL"; return@Button }
                                loading = true
                                error = null
                                scope.launch {
                                    PluginManager.installFromUrl(context, url.trim()).onSuccess { p ->
                                        plugins.clear()
                                        plugins.addAll(PluginManager.getPlugins())
                                        Toast.makeText(context, "Установлен: ${p.name}", Toast.LENGTH_SHORT).show()
                                        showInstallDialog = false
                                    }.onFailure { e ->
                                        error = "Ошибка: ${e.message}"
                                    }
                                    loading = false
                                }
                            },
                            enabled = !loading,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Wine)
                        ) {
                            if (loading) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                                Spacer(Modifier.width(6.dp))
                            }
                            Text("Установить")
                        }
                    }
                }
            }
        }
    }

    // Диалог вставки JSON
    if (showJsonInput) {
        var jsonText by remember { mutableStateOf("") }
        var error by remember { mutableStateOf<String?>(null) }

        Dialog(onDismissRequest = { showJsonInput = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("📋 Вставить плагин", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(4.dp))
                    Text("Вставьте JSON-код плагина", fontSize = 13.sp, color = Gray500)
                    Spacer(Modifier.height(16.dp))

                    OutlinedTextField(
                        value = jsonText,
                        onValueChange = { jsonText = it; error = null },
                        label = { Text("JSON", color = Gray500) },
                        placeholder = { Text("{\"id\": \"...\", ...}", color = Gray500.copy(alpha = 0.5f)) },
                        modifier = Modifier.fillMaxWidth().height(200.dp),
                        maxLines = 15,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Wine,
                            unfocusedBorderColor = BorderDark,
                            cursorColor = Wine,
                            focusedContainerColor = BgDark,
                            unfocusedContainerColor = BgDark
                        )
                    )

                    if (error != null) {
                        Spacer(Modifier.height(8.dp))
                        Text(error!!, color = Red400, fontSize = 12.sp)
                    }

                    Spacer(Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showJsonInput = false }) {
                            Text("Отмена", color = Gray500)
                        }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (jsonText.isBlank()) { error = "Вставьте JSON"; return@Button }
                                PluginManager.installPlugin(context, jsonText.trim()).onSuccess { p ->
                                    plugins.clear()
                                    plugins.addAll(PluginManager.getPlugins())
                                    Toast.makeText(context, "Установлен: ${p.name}", Toast.LENGTH_SHORT).show()
                                    showJsonInput = false
                                }.onFailure { e ->
                                    error = "Ошибка: ${e.message}"
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Wine)
                        ) {
                            Text("Установить")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PluginCard(
    plugin: ScanPlugin,
    isActive: Boolean,
    onToggle: () -> Unit,
    onEnable: (Boolean) -> Unit,
    onDelete: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) Wine.copy(alpha = 0.1f) else BgDark
        ),
        shape = RoundedCornerShape(14.dp),
        border = if (isActive) BorderStroke(1.dp, Wine) else null
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Иконка
                Box(
                    modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
                        .background(if (plugin.enabled) Wine.copy(alpha = 0.2f) else SurfaceDark2),
                    contentAlignment = Alignment.Center
                ) {
                    Text(plugin.icon, fontSize = 22.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(plugin.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = if (plugin.enabled) Color.White else Gray500)
                    Text("v${plugin.version} • ${plugin.author}", fontSize = 11.sp, color = Gray500)
                    if (plugin.description.isNotEmpty()) {
                        Text(plugin.description, fontSize = 12.sp, color = Gray500.copy(alpha = 0.8f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                // Кнопка активации для сканирования
                IconButton(onClick = onToggle) {
                    if (isActive) {
                        Icon(Icons.Default.PlayArrow, null, tint = Wine, modifier = Modifier.size(24.dp))
                    } else {
                        Icon(Icons.Default.PlayArrow, null, tint = Gray500, modifier = Modifier.size(24.dp))
                    }
                }
                // Развернуть
                IconButton(onClick = { expanded = !expanded }) {
                    Icon(
                        if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        null, tint = Gray500, modifier = Modifier.size(20.dp)
                    )
                }
            }

            if (expanded) {
                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = BorderDark, thickness = 1.dp)
                Spacer(Modifier.height(12.dp))

                // Инфо
                Text("Порты: ${plugin.ports.joinToString(", ")}", fontSize = 12.sp, color = Gray500)
                Text("Логины: ${plugin.credentials.size} пар", fontSize = 12.sp, color = Gray500)
                Text("Проверки: ${plugin.checks.size} методов", fontSize = 12.sp, color = Gray500)
                plugin.checks.forEach { check ->
                    Text("  • ${check.type}: ${check.path.ifEmpty { "port ${check.readBytes}b" }}", fontSize = 11.sp, color = Gray500.copy(alpha = 0.7f))
                }

                Spacer(Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Вкл/выкл
                    OutlinedButton(
                        onClick = { onEnable(!plugin.enabled) },
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (plugin.enabled) Wine else Gray500),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(
                            if (plugin.enabled) "Включён" else "Выключен",
                            fontSize = 12.sp,
                            color = if (plugin.enabled) Wine else Gray500
                        )
                    }
                    // Удалить
                    OutlinedButton(
                        onClick = onDelete,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Red400.copy(alpha = 0.5f)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text("Удалить", fontSize = 12.sp, color = Red400)
                    }
                }
            }
        }
    }
}

// ─── Диалог "О приложении" ───
@Composable
fun AboutDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier.size(72.dp).clip(RoundedCornerShape(20.dp))
                        .background(Brush.verticalGradient(listOf(Wine, WineDark))),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🔍", fontSize = 36.sp)
                }

                Spacer(Modifier.height(16.dp))

                Text("Main Scanner", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)

                Spacer(Modifier.height(4.dp))

                Text("v3.0.0", fontSize = 14.sp, color = Gray500)

                Spacer(Modifier.height(20.dp))

                HorizontalDivider(color = BorderDark, thickness = 1.dp)

                Spacer(Modifier.height(20.dp))

                Text("Разработчик", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Gray500, letterSpacing = 1.sp)

                Spacer(Modifier.height(6.dp))

                Text("MainDmitri", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Wine)

                Spacer(Modifier.height(20.dp))

                Button(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/+M8O1wJodXPo2Y2Jk"))
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            Toast.makeText(context, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2AABEE), contentColor = Color.White)
                ) {
                    Text("✈", fontSize = 18.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("Telegram канал", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                Spacer(Modifier.height(16.dp))

                Text(
                    "Многопортовый сканер сетевых устройств.\nПоддержка Dahua, Hikvision, XMeye, SSH, Telnet.",
                    fontSize = 13.sp, color = Gray500, textAlign = TextAlign.Center, lineHeight = 18.sp
                )

                Spacer(Modifier.height(20.dp))

                TextButton(onClick = onDismiss) {
                    Text("Закрыть", color = WineLight, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun ScannerTab(
    ipInput: String, onIpChange: (String) -> Unit,
    portInput: String, onPortChange: (String) -> Unit,
    parseError: String?, isScanning: Boolean, progress: ScanProgress?,
    results: List<ScanResult>,
    multiPortMode: Boolean, onMultiPortChange: (Boolean) -> Unit,
    portSelectMode: Boolean, onPortSelectChange: (Boolean) -> Unit,
    selectedPorts: MutableList<Int>,
    onScan: () -> Unit, onStop: () -> Unit,
    onResultClick: (ScanResult) -> Unit,
    onMyNetwork: () -> Unit,
    context: Context
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Цель", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Gray500)
                        OutlinedButton(
                            onClick = onMyNetwork,
                            enabled = !isScanning,
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(1.dp, WineLight.copy(alpha = 0.5f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = WineLight),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("📡", fontSize = 14.sp)
                            Spacer(Modifier.width(4.dp))
                            Text("Моя сеть", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = ipInput, onValueChange = onIpChange,
                        placeholder = { Text("192.168.1.1\n10.0.0.1-10.0.0.50\n172.16.0.0/24", color = Gray500.copy(alpha = 0.5f), fontSize = 13.sp, fontFamily = FontFamily.Monospace) },
                        modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 8,
                        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 14.sp),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                        isError = parseError != null, enabled = !isScanning, shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Wine, unfocusedBorderColor = BorderDark, cursorColor = Wine,
                            focusedContainerColor = BgDark, unfocusedContainerColor = BgDark
                        )
                    )

                    if (parseError != null) {
                        Text(parseError, color = Red400, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Multi-port сканирование", fontSize = 13.sp, color = Color.White)
                            Text(
                                if (multiPortMode) "Все порты: 37777, 80, 8080, 34567..." else "Только порт Dahua (37777)",
                                fontSize = 11.sp, color = Gray500
                            )
                        }
                        Switch(
                            checked = multiPortMode,
                            onCheckedChange = onMultiPortChange,
                            enabled = !isScanning,
                            colors = SwitchDefaults.colors(checkedTrackColor = Wine, checkedThumbColor = Color.White)
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Выбор портов", fontSize = 13.sp, color = Color.White)
                            Text(
                                if (portSelectMode && selectedPorts.isNotEmpty()) "Выбрано: ${selectedPorts.size} портов"
                                else "Выберите нужные порты вручную",
                                fontSize = 11.sp, color = Gray500
                            )
                        }
                        Switch(
                            checked = portSelectMode,
                            onCheckedChange = onPortSelectChange,
                            enabled = !isScanning,
                            colors = SwitchDefaults.colors(checkedTrackColor = WineLight, checkedThumbColor = Color.White)
                        )
                    }

                    if (portSelectMode) {
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val allSelected = selectedPorts.size == ALL_PORT_OPTIONS.size
                            FilterChip(
                                selected = allSelected,
                                onClick = {
                                    if (allSelected) selectedPorts.clear()
                                    else { selectedPorts.clear(); selectedPorts.addAll(ALL_PORT_OPTIONS.map { it.port }) }
                                },
                                label = { Text("Все", fontSize = 11.sp) },
                                enabled = !isScanning,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Wine.copy(alpha = 0.2f),
                                    selectedLabelColor = Wine
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true, selected = allSelected,
                                    borderColor = BorderDark, selectedBorderColor = Wine.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(20.dp)
                            )

                            ALL_PORT_OPTIONS.forEach { opt ->
                                val sel = opt.port in selectedPorts
                                FilterChip(
                                    selected = sel,
                                    onClick = {
                                        if (sel) selectedPorts.remove(opt.port)
                                        else selectedPorts.add(opt.port)
                                    },
                                    label = { Text(opt.label, fontSize = 11.sp) },
                                    enabled = !isScanning,
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = opt.color.copy(alpha = 0.2f),
                                        selectedLabelColor = opt.color
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true, selected = sel,
                                        borderColor = BorderDark, selectedBorderColor = opt.color.copy(alpha = 0.5f)
                                    ),
                                    shape = RoundedCornerShape(20.dp)
                                )
                            }
                        }
                    }

                    if (!multiPortMode && !portSelectMode) {
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Порт:", fontSize = 13.sp, color = Gray500)
                            Spacer(Modifier.width(8.dp))
                            OutlinedTextField(
                                value = portInput, onValueChange = onPortChange,
                                modifier = Modifier.width(100.dp),
                                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 14.sp),
                                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                enabled = !isScanning, shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Wine, unfocusedBorderColor = BorderDark,
                                    focusedContainerColor = BgDark, unfocusedContainerColor = BgDark)
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onScan, enabled = !isScanning && ipInput.isNotBlank(),
                            modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Wine, contentColor = Color.White, disabledContainerColor = Wine.copy(alpha = 0.3f))
                        ) {
                            Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Сканировать", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        if (isScanning) {
                            OutlinedButton(
                                onClick = onStop, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Red400), border = BorderStroke(1.dp, Red400)
                            ) {
                                Icon(Icons.Default.Close, null, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Стоп", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        progress?.let { p -> if (p.total > 0) { item { ProgressCard(p, isScanning) } } }
        if (results.isNotEmpty()) { item { StatsStrip(results) } }

        val successResults = results.filter { !it.blocked }
        val blockedResults = results.filter { it.blocked }

        if (successResults.isNotEmpty()) {
            item { Text("НАЙДЕНО", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Wine, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            items(successResults, key = { "${it.ip}:${it.port}:${it.timestampMs}" }) { result -> ResultCard(result, context) { onResultClick(result) } }
        }
        if (blockedResults.isNotEmpty()) {
            item { Text("ЗАБЛОКИРОВАНО", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Orange400, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            items(blockedResults, key = { "blocked_${it.ip}:${it.timestampMs}" }) { result ->
                Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(Orange400.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) { Text("🔒", fontSize = 16.sp) }
                        Spacer(Modifier.width(12.dp))
                        Text(result.ip, fontFamily = FontFamily.Monospace, fontSize = 14.sp, color = Orange400)
                    }
                }
            }
        }
    }
}

@Composable
fun FindingsTab(results: List<ScanResult>, onResultClick: (ScanResult) -> Unit, context: Context) {
    if (results.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("📷", fontSize = 48.sp)
                Spacer(Modifier.height(12.dp))
                Text("Пока ничего не найдено", fontSize = 16.sp, color = Gray500)
                Text("Запустите сканирование", fontSize = 13.sp, color = Gray500.copy(alpha = 0.6f))
            }
        }
        return
    }

    val cameras = results.filter { !isTerminal(it.brand) }
    val terminals = results.filter { isTerminal(it.brand) }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Всего найдено: ${results.size}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Wine)
                    Spacer(Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatChip("📷 ${cameras.size} камер", Wine, Modifier.weight(1f))
                        StatChip("💻 ${terminals.size} терм.", Color(0xFFFFA726), Modifier.weight(1f))
                    }

                    Spacer(Modifier.height(8.dp))

                    val brands = results.groupBy { it.brand }.mapValues { it.value.size }
                    if (brands.size > 1) {
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            brands.forEach { (brand, count) ->
                                StatChip("$brand: $count", brandColor(brand))
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }

                    OutlinedButton(
                        onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val text = results.joinToString("\n") { r -> "${r.ip}:${r.port} ${r.login}:${r.password} [${r.brand}] ${r.model} ${r.channels}ch" }
                            cm.setPrimaryClip(ClipData.newPlainText("camera_all", text))
                            Toast.makeText(context, "Скопировано (${results.size})", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = WineLight), border = BorderStroke(1.dp, WineLight.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Копировать все", fontSize = 13.sp)
                    }
                }
            }
        }

        if (cameras.isNotEmpty()) {
            item { Text("📷 КАМЕРЫ (${cameras.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Wine, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            val camWithPhoto = cameras.filter { it.snapshot != null && it.snapshot.size > 100 }
            val camWithoutPhoto = cameras.filter { it.snapshot == null || it.snapshot.size <= 100 }
            if (camWithPhoto.isNotEmpty()) {
                items(camWithPhoto, key = { "cf_${it.ip}:${it.port}:${it.timestampMs}" }) { result -> FindingCard(result, context) { onResultClick(result) } }
            }
            if (camWithoutPhoto.isNotEmpty()) {
                items(camWithoutPhoto, key = { "cn_${it.ip}:${it.port}:${it.timestampMs}" }) { result -> ResultCard(result, context) { onResultClick(result) } }
            }
        }

        if (terminals.isNotEmpty()) {
            item { Text("💻 ТЕРМИНАЛЫ (${terminals.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFA726), letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            items(terminals, key = { "t_${it.ip}:${it.port}:${it.timestampMs}" }) { result -> ResultCard(result, context) { onResultClick(result) } }
        }
    }
}

@Composable
fun FindingCard(result: ScanResult, context: Context, onClick: () -> Unit) {
    val timeFmt = remember(result.timestampMs) {
        java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(result.timestampMs))
    }
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(14.dp)) {
        Column {
            if (result.snapshot != null && result.snapshot.size > 100) {
                val bmp = remember(result.snapshot) { BitmapFactory.decodeByteArray(result.snapshot, 0, result.snapshot.size) }
                if (bmp != null) {
                    Image(bitmap = bmp.asImageBitmap(), contentDescription = null,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp).clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)),
                        contentScale = ContentScale.Crop)
                }
            }
            Column(modifier = Modifier.padding(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(result.ip, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 15.sp, color = Color.White)
                    Box(modifier = Modifier.size(28.dp).clip(CircleShape).background(SurfaceDark2).clickable {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("cam", "${result.ip}:${result.port} ${result.login}:${result.password}"))
                        Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                    }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Share, null, tint = Gray500, modifier = Modifier.size(14.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Wine.copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text("${result.login}:${result.password}", fontSize = 12.sp, color = WineAccent, fontFamily = FontFamily.Monospace)
                    }
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(brandColor(result.brand).copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text(result.brand, fontSize = 11.sp, color = brandColor(result.brand))
                    }
                    if (result.hasMic) {
                        Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Red400.copy(alpha = 0.15f)).padding(horizontal = 5.dp, vertical = 2.dp)) {
                            Text("🎤", fontSize = 10.sp)
                        }
                    }
                    if (result.model.isNotEmpty() && result.model != "unknown") {
                        Text(result.model, fontSize = 11.sp, color = WineLight, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(timeFmt, fontSize = 11.sp, color = Gray500)
                }
            }
        }
    }
}

@Composable
fun ProgressCard(p: ScanProgress, scanning: Boolean) {
    val pct = if (p.total > 0) (p.checked.toFloat() / p.total) else 0f
    val speed = if (p.elapsedMs > 200) (p.checked * 1000.0 / p.elapsedMs) else 0.0
    val eta = if (speed > 0.01 && p.checked < p.total) ((p.total - p.checked) / speed).toInt() else 0

    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (scanning) { CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Wine); Spacer(Modifier.width(8.dp)) }
                    Text(
                        if (p.finished) "Завершено" else if (p.cancelled) "Отменено" else "Сканирование",
                        fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        color = when { p.finished -> Wine; p.cancelled -> Orange400; else -> Color.White }
                    )
                }
                Text("${(pct * 100).toInt()}%", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Wine)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)), color = Wine, trackColor = BorderDark)
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                StatMini("Проверено", "${p.checked}/${p.total}", WineLight)
                StatMini("Найдено", "${p.successful}", Wine)
                StatMini("Блокировка", "${p.blocked}", Orange400)
                if (speed > 0.01) StatMini("Скорость", "${"%.1f".format(speed)}/с", Color.White)
                if (scanning && eta > 0) StatMini("ETA", "%d:%02d".format(eta / 60, eta % 60), Yellow400)
            }
        }
    }
}

@Composable
fun StatMini(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color)
        Text(label, fontSize = 10.sp, color = Gray500)
    }
}

@Composable
fun StatsStrip(results: List<ScanResult>) {
    val withPhoto = results.count { it.snapshot != null && it.snapshot.size > 100 }
    val withoutPhoto = results.count { !it.blocked && (it.snapshot == null || it.snapshot.size <= 100) }
    val blocked = results.count { it.blocked }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatChip("📸 $withPhoto фото", Wine, Modifier.weight(1f))
        StatChip("🔑 $withoutPhoto без фото", WineLight, Modifier.weight(1f))
        if (blocked > 0) StatChip("🔒 $blocked блок", Orange400, Modifier.weight(1f))
    }
}

@Composable
fun StatChip(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(modifier = modifier.clip(RoundedCornerShape(10.dp)).background(color.copy(alpha = 0.1f)).padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = color)
    }
}

@Composable
fun ResultCard(result: ScanResult, context: Context, onClick: () -> Unit) {
    val hasPhoto = result.snapshot != null && result.snapshot.size > 100
    val timeFmt = remember(result.timestampMs) {
        java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(result.timestampMs))
    }
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(14.dp)) {
        Row(modifier = Modifier.padding(12.dp)) {
            Box(modifier = Modifier.size(72.dp).clip(RoundedCornerShape(10.dp)).background(if (hasPhoto) Color.Transparent else SurfaceDark2), contentAlignment = Alignment.Center) {
                if (hasPhoto) {
                    val bmp = remember(result.snapshot) { BitmapFactory.decodeByteArray(result.snapshot!!, 0, result.snapshot.size) }
                    if (bmp != null) Image(bitmap = bmp.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Text(if (isTerminal(result.brand)) "💻" else "📷", fontSize = 28.sp)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(result.ip, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 15.sp, color = Color.White)
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Wine.copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text("${result.login}:${result.password}", fontSize = 12.sp, color = WineAccent, fontFamily = FontFamily.Monospace)
                    }
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(brandColor(result.brand).copy(alpha = 0.15f)).padding(horizontal = 5.dp, vertical = 2.dp)) {
                        Text(result.brand, fontSize = 10.sp, color = brandColor(result.brand))
                    }
                    if (result.hasMic) {
                        Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Red400.copy(alpha = 0.15f)).padding(horizontal = 5.dp, vertical = 2.dp)) {
                            Text("🎤", fontSize = 10.sp)
                        }
                    }
                    Box(modifier = Modifier.size(24.dp).clip(CircleShape).background(SurfaceDark2).clickable {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("cam", "${result.ip}:${result.port} ${result.login}:${result.password}"))
                        Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                    }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Share, null, tint = Gray500, modifier = Modifier.size(14.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    if (result.model.isNotEmpty() && result.model != "unknown") {
                        Text(result.model, fontSize = 11.sp, color = WineLight, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                        Spacer(Modifier.width(4.dp))
                    }
                    if (result.channels > 0) { Text("${result.channels}ch", fontSize = 11.sp, color = Gray500); Spacer(Modifier.width(4.dp)) }
                    Text(":${result.port}", fontSize = 11.sp, color = Gray500, fontFamily = FontFamily.Monospace)
                    Spacer(Modifier.width(4.dp))
                    Text(timeFmt, fontSize = 11.sp, color = Gray500)
                }
                if (!hasPhoto && !isTerminal(result.brand)) Text("без снапшота", fontSize = 11.sp, color = Gray500.copy(alpha = 0.7f))
            }
        }
    }
}

@Composable
fun SnapshotFullDialog(result: ScanResult, context: Context, onDismiss: () -> Unit) {
    val hasPhoto = result.snapshot != null && result.snapshot.size > 100
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(modifier = Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(20.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(brandColor(result.brand)))
                    Spacer(Modifier.width(8.dp))
                    Text(result.ip, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(brandColor(result.brand).copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text(result.brand, fontSize = 11.sp, color = brandColor(result.brand))
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (hasPhoto) {
                    val bmp = remember(result.snapshot) { BitmapFactory.decodeByteArray(result.snapshot!!, 0, result.snapshot.size) }
                    if (bmp != null) Image(bitmap = bmp.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.FillWidth)
                    Spacer(Modifier.height(12.dp))
                }
                InfoRow("Порт", "${result.port}")
                InfoRow("Логин", result.login)
                InfoRow("Пароль", result.password)
                InfoRow("Бренд", result.brand)
                InfoRow("Тип", if (isTerminal(result.brand)) "💻 Терминал" else "📷 Камера")
                if (result.model.isNotEmpty() && result.model != "unknown") InfoRow("Модель", result.model)
                InfoRow("Каналов", "${result.channels}")
                InfoRow("Микрофон", if (result.hasMic) "🎤 Да" else "Нет")
                if (result.metadata.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text("📋 Метаданные", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = WineLight)
                    for ((key, value) in result.metadata) {
                        InfoRow(key.replaceFirstChar { it.uppercase() }, value)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val info = buildString {
                            appendLine("IP: ${result.ip}:${result.port}")
                            appendLine("Login: ${result.login}")
                            appendLine("Password: ${result.password}")
                            appendLine("Brand: ${result.brand}")
                            if (result.model.isNotEmpty()) appendLine("Model: ${result.model}")
                            appendLine("Channels: ${result.channels}")
                            if (result.metadata.isNotEmpty()) {
                                for ((k, v) in result.metadata) appendLine("$k: $v")
                            }
                        }
                        cm.setPrimaryClip(ClipData.newPlainText("cam", info))
                        Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                    }) { Text("Копировать", color = WineLight) }
                    TextButton(onClick = onDismiss) { Text("Закрыть", color = Gray500) }
                }
            }
        }
    }
}

@Composable
fun StoredTab(
    results: List<ScanResult>,
    onResultClick: (ScanResult) -> Unit,
    onDelete: (ScanResult) -> Unit,
    onClearAll: () -> Unit,
    context: Context
) {
    if (results.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("💾", fontSize = 48.sp)
                Spacer(Modifier.height(12.dp))
                Text("Нет сохранённых результатов", fontSize = 16.sp, color = Gray500)
                Text("Найденные устройства сохраняются автоматически", fontSize = 13.sp, color = Gray500.copy(alpha = 0.6f))
            }
        }
        return
    }

    val cameras = results.filter { !isTerminal(it.brand) }
    val terminals = results.filter { isTerminal(it.brand) }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("💾 Сохранено: ${results.size}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = WineLight)
                    Text("Данные хранятся локально на устройстве", fontSize = 12.sp, color = Gray500)

                    Spacer(Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatChip("📷 ${cameras.size} камер", Wine, Modifier.weight(1f))
                        StatChip("💻 ${terminals.size} терм.", Color(0xFFFFA726), Modifier.weight(1f))
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val text = results.joinToString("\n") { r -> "${r.ip}:${r.port} ${r.login}:${r.password} [${r.brand}] ${r.model}" }
                                cm.setPrimaryClip(ClipData.newPlainText("stored_all", text))
                                Toast.makeText(context, "Скопировано (${results.size})", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = WineLight), border = BorderStroke(1.dp, WineLight.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Копировать", fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = onClearAll,
                            modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Red400), border = BorderStroke(1.dp, Red400.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.Delete, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Очистить всё", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        if (cameras.isNotEmpty()) {
            item { Text("📷 КАМЕРЫ (${cameras.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Wine, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            items(cameras, key = { "stored_cam_${it.ip}:${it.port}:${it.timestampMs}" }) { result ->
                StoredResultCard(result, context, onClick = { onResultClick(result) }, onDelete = { onDelete(result) })
            }
        }

        if (terminals.isNotEmpty()) {
            item { Text("💻 ТЕРМИНАЛЫ (${terminals.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFA726), letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            items(terminals, key = { "stored_term_${it.ip}:${it.port}:${it.timestampMs}" }) { result ->
                StoredResultCard(result, context, onClick = { onResultClick(result) }, onDelete = { onDelete(result) })
            }
        }
    }
}

@Composable
fun StoredResultCard(result: ScanResult, context: Context, onClick: () -> Unit, onDelete: () -> Unit) {
    val hasPhoto = result.snapshot != null && result.snapshot.size > 100
    val dateFmt = remember(result.timestampMs) {
        java.text.SimpleDateFormat("dd.MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(result.timestampMs))
    }
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(14.dp)) {
        Row(modifier = Modifier.padding(12.dp)) {
            Box(modifier = Modifier.size(72.dp).clip(RoundedCornerShape(10.dp)).background(if (hasPhoto) Color.Transparent else SurfaceDark2), contentAlignment = Alignment.Center) {
                if (hasPhoto) {
                    val bmp = remember(result.snapshot) { BitmapFactory.decodeByteArray(result.snapshot!!, 0, result.snapshot.size) }
                    if (bmp != null) Image(bitmap = bmp.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Text(if (isTerminal(result.brand)) "💻" else "📷", fontSize = 28.sp)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(result.ip, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 15.sp, color = Color.White)
                    Row {
                        Box(modifier = Modifier.size(24.dp).clip(CircleShape).background(SurfaceDark2).clickable {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("cam", "${result.ip}:${result.port} ${result.login}:${result.password}"))
                            Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                        }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Share, null, tint = Gray500, modifier = Modifier.size(14.dp)) }
                        Spacer(Modifier.width(4.dp))
                        Box(modifier = Modifier.size(24.dp).clip(CircleShape).background(Red400.copy(alpha = 0.15f)).clickable { onDelete() }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Delete, null, tint = Red400, modifier = Modifier.size(14.dp))
                        }
                    }
                }
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Wine.copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text("${result.login}:${result.password}", fontSize = 12.sp, color = WineAccent, fontFamily = FontFamily.Monospace)
                    }
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(brandColor(result.brand).copy(alpha = 0.15f)).padding(horizontal = 5.dp, vertical = 2.dp)) {
                        Text(result.brand, fontSize = 10.sp, color = brandColor(result.brand))
                    }
                    if (result.hasMic) {
                        Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Red400.copy(alpha = 0.15f)).padding(horizontal = 5.dp, vertical = 2.dp)) {
                            Text("🎤", fontSize = 10.sp)
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    if (result.model.isNotEmpty() && result.model != "unknown") Text(result.model, fontSize = 11.sp, color = WineLight, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    Text(":${result.port}", fontSize = 11.sp, color = Gray500, fontFamily = FontFamily.Monospace)
                    Spacer(Modifier.width(4.dp))
                    Text(dateFmt, fontSize = 11.sp, color = Gray500)
                }
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 13.sp, color = Gray500)
        Text(value, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, color = Color.White)
    }
}
