// Хранилище мира: чанки 16x256x16 из секций 16x16x16 (формат индексов как в сети MCPE 1.1: x<<8 | z<<4 | y)
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const Blocks = MC.Blocks;

  const key = (cx, cz) => cx + ',' + cz;

  class Chunk {
    constructor(cx, cz, sections) {
      this.cx = cx;
      this.cz = cz;
      this.sections = sections || new Array(16).fill(null);
      this.height = new Uint8Array(256);
      this.modified = false;
      this.recalcHeight();
    }

    getId(x, y, z) {
      const s = this.sections[y >> 4];
      return s ? s.ids[(x << 8) | (z << 4) | (y & 15)] : 0;
    }

    getData(x, y, z) {
      const s = this.sections[y >> 4];
      return s ? s.meta[(x << 8) | (z << 4) | (y & 15)] : 0;
    }

    set(x, y, z, id, data) {
      let s = this.sections[y >> 4];
      if (!s) {
        if (id === 0) return;
        s = this.sections[y >> 4] = { ids: new Uint8Array(4096), meta: new Uint8Array(4096) };
      }
      const i = (x << 8) | (z << 4) | (y & 15);
      s.ids[i] = id;
      s.meta[i] = data & 15;
      s.lit = undefined;
      const hi = (z << 4) | x;
      if (y >= this.height[hi] && blocksLight(id)) this.height[hi] = Math.min(255, y + 1);
      else if (y + 1 === this.height[hi] && !blocksLight(id)) this.recalcColumn(x, z);
    }

    recalcColumn(x, z) {
      let h = 0;
      for (let y = 255; y >= 0; y--) {
        if (blocksLight(this.getId(x, y, z))) { h = y + 1; break; }
      }
      this.height[(z << 4) | x] = h;
    }

    recalcHeight() {
      for (let x = 0; x < 16; x++) for (let z = 0; z < 16; z++) this.recalcColumn(x, z);
    }
  }

  function blocksLight(id) {
    if (id === 0) return false;
    const b = Blocks.list[id];
    return b.opaque || b.layer === 'cutout' && (id === 18 || id === 161) || b.liquid;
  }

  class World {
    constructor() {
      this.chunks = new Map();
      this.listeners = [];
      this.blockListeners = [];
      this.chunkListeners = [];
    }

    // Новый чанк (от сервера или из сохранения)
    onChunkSet(fn) { this.chunkListeners.push(fn); }

    onSectionDirty(fn) { this.listeners.push(fn); }
    dirty(cx, cy, cz) { for (const fn of this.listeners) fn(cx, cy, cz); }
    onBlockSet(fn) { this.blockListeners.push(fn); }

    getChunk(cx, cz) { return this.chunks.get(key(cx, cz)); }

    getId(x, y, z) {
      if (y < 0 || y > 255) return 0;
      const c = this.chunks.get(key(x >> 4, z >> 4));
      return c ? c.getId(x & 15, y, z & 15) : 0;
    }

    getData(x, y, z) {
      if (y < 0 || y > 255) return 0;
      const c = this.chunks.get(key(x >> 4, z >> 4));
      return c ? c.getData(x & 15, y, z & 15) : 0;
    }

    isLoaded(x, z) { return this.chunks.has(key(x >> 4, z >> 4)); }

    height(x, z) {
      const c = this.chunks.get(key(x >> 4, z >> 4));
      return c ? c.height[((z & 15) << 4) | (x & 15)] : 0;
    }

    setBlock(x, y, z, id, data) {
      if (y < 0 || y > 255) return;
      const cx = x >> 4, cz = z >> 4;
      const c = this.chunks.get(key(cx, cz));
      if (!c) return;
      const hi = ((z & 15) << 4) | (x & 15);
      const oldH = c.height[hi];
      const oldId = c.getId(x & 15, y, z & 15);
      c.set(x & 15, y, z & 15, id, data);
      c.modified = true;
      if (this.blockListeners.length) for (const fn of this.blockListeners) fn(x, y, z, id, data);
      const newH = c.height[hi];
      const sy = y >> 4, lx = x & 15, ly = y & 15, lz = z & 15;
      this.dirty(cx, sy, cz);
      if (lx === 0) this.dirty(cx - 1, sy, cz);
      if (lx === 15) this.dirty(cx + 1, sy, cz);
      if (lz === 0) this.dirty(cx, sy, cz - 1);
      if (lz === 15) this.dirty(cx, sy, cz + 1);
      if (ly === 0 && sy > 0) this.dirty(cx, sy - 1, cz);
      if (ly === 15 && sy < 15) this.dirty(cx, sy + 1, cz);
      // Свет от факела/лавы доходит до 15 блоков: при появлении или исчезновении источника,
      // а также если рядом со светом ставят/убирают непрозрачный блок, перестраиваем соседние секции
      const L = Blocks.LIGHT;
      if (L[id] !== L[oldId] || (Blocks.list[id].opaque !== Blocks.list[oldId].opaque && this.nearLight(x, y, z))) {
        for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) for (let ds = -1; ds <= 1; ds++) {
          if (sy + ds >= 0 && sy + ds <= 15) this.dirty(cx + dx, sy + ds, cz + dz);
        }
      }
      // Затенение под навесом зависит от карты высот столбца
      if (oldH !== newH) {
        const lo = Math.min(oldH, newH) >> 4, hiS = Math.max(0, Math.max(oldH, newH) - 1) >> 4;
        for (let s = lo; s <= hiS; s++) {
          if (s === sy) continue;
          this.dirty(cx, s, cz);
          if (lx === 0) this.dirty(cx - 1, s, cz);
          if (lx === 15) this.dirty(cx + 1, s, cz);
          if (lz === 0) this.dirty(cx, s, cz - 1);
          if (lz === 15) this.dirty(cx, s, cz + 1);
        }
      }
    }

    // Есть ли источник света в радиусе 14 блоков (по кэшу секций)
    nearLight(x, y, z) {
      const L = Blocks.LIGHT;
      for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
        const c = this.chunks.get(key((x >> 4) + dx, (z >> 4) + dz));
        if (!c) continue;
        for (let s = Math.max(0, (y - 14) >> 4); s <= Math.min(15, (y + 14) >> 4); s++) {
          const sec = c.sections[s];
          if (!sec) continue;
          if (sec.lit === undefined) { sec.lit = false; for (let i = 0; i < 4096; i++) if (L[sec.ids[i]]) { sec.lit = true; break; } }
          if (sec.lit) return true;
        }
      }
      return false;
    }

    setChunk(chunk) {
      this.chunks.set(key(chunk.cx, chunk.cz), chunk);
      for (const fn of this.chunkListeners) fn(chunk.cx, chunk.cz);
      for (let sy = 0; sy < 16; sy++) {
        this.dirty(chunk.cx, sy, chunk.cz);
        this.dirty(chunk.cx - 1, sy, chunk.cz);
        this.dirty(chunk.cx + 1, sy, chunk.cz);
        this.dirty(chunk.cx, sy, chunk.cz - 1);
        this.dirty(chunk.cx, sy, chunk.cz + 1);
      }
    }

    removeChunk(cx, cz) {
      this.chunks.delete(key(cx, cz));
    }
  }

  // ---------- Генератор мира для одиночной игры ----------
  // Биомы: климат (температура и влажность) + высота. Номер — как в MCPE (для цвета травы и листвы)
  const BIOME_ID = { ocean: 0, plains: 1, desert: 2, mountains: 3, forest: 4, taiga: 5, swamp: 6, river: 7, frozen_ocean: 10, snowy: 12,
    beach: 16, jungle: 21, birch: 27, snowy_taiga: 30, savanna: 35, mesa: 37, deep_ocean: 24 };
  // Жилы руд: [id, data, жил на чанк, размер, нижняя и верхняя высота]
  const ORES = [[13, 0, 6, 20, 5, 120], [3, 0, 8, 20, 5, 120], [1, 1, 6, 22, 5, 80], [1, 3, 6, 22, 5, 80], [1, 5, 6, 22, 5, 80],
    [16, 0, 18, 12, 5, 128], [15, 0, 16, 8, 5, 64], [14, 0, 2, 8, 5, 32], [73, 0, 7, 7, 5, 16], [56, 0, 1, 7, 5, 16], [21, 0, 1, 6, 5, 30]];
  // Полосы терракоты в столовых горах
  const MESA_BANDS = [1, 1, 0, 4, 172, 1, 14, 0, 0, 12, 172, 1, 8, 0, 4, 172];

  // Ширина плавного перехода между старым и новым рельефом
  const BLEND = 24;

  class Generator {
    constructor(seed, record) {
      this.seed = seed | 0;
      this.record = record || null;
      this.n1 = new MC.Perlin(seed);
      this.n2 = new MC.Perlin(seed + 1);
      this.n3 = new MC.Perlin(seed + 2);
      this.cave = new MC.Perlin(seed + 3);
      this.biome = new MC.Perlin(seed + 4);
      this.humid = new MC.Perlin(seed + 5);
      this.cont = new MC.Perlin(seed + 6);
      this.riverN = new MC.Perlin(seed + 7);
      this.tunA = new MC.Perlin(seed + 8);
      this.tunB = new MC.Perlin(seed + 9);
      this.SEA = 62;
      // Старый мир, переведённый на новую генерацию: чанки, которые игрок уже видел, строятся старым
      // генератором, а рельеф вокруг них плавно (на BLEND блоков) переходит в новый
      this.legacySet = null;
      if (record && Array.isArray(record.legacyChunks) && record.legacyChunks.length) {
        this.legacySet = new Set();
        const lc = record.legacyChunks;
        for (let i = 0; i + 1 < lc.length; i += 2) this.legacySet.add(lc[i] + ',' + lc[i + 1]);
        this.legacy = new LegacyGenerator(seed);
        this.nearCache = new Map();
      }
    }

    isLegacyChunk(cx, cz) { return !!this.legacySet && this.legacySet.has(cx + ',' + cz); }

    // 0 — внутри старого чанка, 1 — дальше BLEND блоков от всех старых чанков
    legacyK(x, z) {
      const cx = x >> 4, cz = z >> 4, ck = cx + ',' + cz;
      if (this.legacySet.has(ck)) return 0;
      let near = this.nearCache.get(ck);
      if (!near) {
        near = [];
        const R = Math.ceil(BLEND / 16);
        for (let dx = -R; dx <= R; dx++) for (let dz = -R; dz <= R; dz++) {
          if (this.legacySet.has((cx + dx) + ',' + (cz + dz))) near.push((cx + dx) * 16, (cz + dz) * 16);
        }
        if (this.nearCache.size > 4096) this.nearCache.clear();
        this.nearCache.set(ck, near);
      }
      let best = BLEND * BLEND;
      for (let i = 0; i < near.length; i += 2) {
        const ox = near[i], oz = near[i + 1];
        const dx = x < ox ? ox - x : x > ox + 15 ? x - ox - 15 : 0;
        const dz = z < oz ? oz - z : z > oz + 15 ? z - oz - 15 : 0;
        const d = dx * dx + dz * dz;
        if (d < best) best = d;
      }
      return Math.sqrt(best) / BLEND;
    }

    heightAt(x, z) {
      const h = this.heightNew(x, z);
      if (!this.legacySet) return h;
      const k = this.legacyK(x, z);
      if (k >= 1) return h;
      const hl = this.legacy.heightAt(x, z);
      const s = k * k * (3 - 2 * k);
      return Math.floor(hl + (h - hl) * s);
    }

    biomeAt(x, z, hh) {
      if (this.legacySet && this.legacyK(x, z) < 0.5) return this.legacy.biomeAt(x, z);
      return this.biomeNew(x, z, hh);
    }

    climate(x, z) {
      return [this.biome.fbm2(x / 520, z / 520, 2) * 2, this.humid.fbm2(x / 440 + 31.7, z / 440 - 12.3, 2) * 2];
    }

    // Высота поверхности: равнины и холмы, горы, океаны (континентальный шум), реки и плоские болота
    heightNew(x, z) {
      const base = this.n1.fbm2(x / 160, z / 160, 4);
      const hills = this.n2.fbm2(x / 60, z / 60, 3);
      const mount = Math.max(0, this.n3.fbm2(x / 300, z / 300, 2)) * 2.2;
      let h = 64 + base * 14 + hills * 6 + mount * mount * 40;
      const c = this.cont.fbm2(x / 700, z / 700, 2);
      if (c < -0.18) h -= Math.min(1, (-0.18 - c) / 0.2) * (h - 38);
      const [, w] = this.climate(x, z);
      if (w > 0.28 && h > this.SEA - 2 && h < 80) {
        const k = Math.min(1, (w - 0.28) / 0.08);
        h += (this.SEA + 0.5 - h) * k * 0.85;
      }
      const r = Math.abs(this.riverN.fbm2(x / 380, z / 380, 3));
      if (r < 0.025 && h > this.SEA - 4 && h < 100) {
        const k = 1 - r / 0.025;
        h += (this.SEA - 4 - h) * k * k * (3 - 2 * k);
      }
      return Math.floor(h);
    }

    isRiver(x, z) { return Math.abs(this.riverN.fbm2(x / 380, z / 380, 3)) < 0.018; }

    biomeNew(x, z, hh) {
      const h = hh === undefined ? this.heightAt(x, z) : hh;
      const [t, w] = this.climate(x, z);
      if (h < this.SEA - 1) {
        if (this.isRiver(x, z) && h >= this.SEA - 5) return t < -0.3 ? 'frozen_ocean' : 'river';
        return t < -0.3 ? 'frozen_ocean' : h < 46 ? 'deep_ocean' : 'ocean';
      }
      if (h > 100 && t < 0.3) return 'mountains';
      if (t > 0.22) {
        if (w < -0.22 && t > 0.36) return 'mesa';
        if (w < 0) return 'desert';
        if (w > 0.2) return 'jungle';
        return 'savanna';
      }
      if (t < -0.26) return w > 0 ? 'snowy_taiga' : 'snowy';
      if (t < -0.1) return 'taiga';
      if (w > 0.28) return 'swamp';
      if (w > 0.06) return this.n3.noise2(x / 90, z / 90) > 0.12 ? 'birch' : 'forest';
      return 'plains';
    }

    biomeId(x, z) { return BIOME_ID[this.biomeAt(x, z)] || 1; }

    // Пещеры: «сырные» полости и длинные извилистые тоннели (пересечение двух шумов около нуля)
    caveAt(x, y, z) {
      if (this.cave.noise3(x / 28, y / 18, z / 28) > 0.42) return true;
      return Math.abs(this.tunA.noise3(x / 42, y / 24, z / 42)) < 0.045 && Math.abs(this.tunB.noise3(x / 42, y / 24, z / 42)) < 0.045;
    }

    // Шум пещер по сетке 4×4×4 с интерполяцией — в ~20 раз быстрее, чем считать в каждом блоке
    caveGrid(cx, cz, maxY) {
      const ny = (maxY >> 2) + 2;
      const g = new Float32Array(5 * 5 * ny * 2);
      for (let i = 0; i < 5; i++) for (let k = 0; k < 5; k++) for (let j = 0; j < ny; j++) {
        const x = cx * 16 + i * 4, y = j * 4, z = cz * 16 + k * 4;
        const o = ((i * 5 + k) * ny + j) * 2;
        g[o] = this.cave.noise3(x / 28, y / 18, z / 28);
        g[o + 1] = Math.max(Math.abs(this.tunA.noise3(x / 42, y / 24, z / 42)), Math.abs(this.tunB.noise3(x / 42, y / 24, z / 42)));
      }
      return { g, ny };
    }

    caveSample(cg, x, y, z, ch) {
      const fx = x / 4, fy = y / 4, fz = z / 4;
      const i = Math.min(3, fx | 0), j = Math.min(cg.ny - 2, fy | 0), k = Math.min(3, fz | 0);
      const tx = fx - i, ty = fy - j, tz = fz - k;
      const g = cg.g, ny = cg.ny;
      const at = (a, b, c) => g[((a * 5 + c) * ny + b) * 2 + ch];
      const l = (a, b, t) => a + (b - a) * t;
      return l(l(l(at(i, j, k), at(i + 1, j, k), tx), l(at(i, j + 1, k), at(i + 1, j + 1, k), tx), ty),
        l(l(at(i, j, k + 1), at(i + 1, j, k + 1), tx), l(at(i, j + 1, k + 1), at(i + 1, j + 1, k + 1), tx), ty), tz);
    }

    generate(cx, cz) {
      if (this.isLegacyChunk(cx, cz)) return this.legacy.generate(cx, cz);
      const chunk = new Chunk(cx, cz);
      const set = (x, y, z, id, d) => chunk.set(x, y, z, id, d || 0);
      const H = this.seed, SEA = this.SEA;
      const hs = new Int16Array(256), bs = new Array(256);
      let maxH = 0;
      for (let x = 0; x < 16; x++) for (let z = 0; z < 16; z++) {
        const wx = cx * 16 + x, wz = cz * 16 + z;
        const h = Math.min(250, this.heightAt(wx, wz));
        hs[x * 16 + z] = h;
        bs[x * 16 + z] = this.biomeAt(wx, wz, h);
        if (h > maxH) maxH = h;
      }
      const cg = this.caveGrid(cx, cz, Math.max(maxH, SEA) + 4);
      for (let x = 0; x < 16; x++) {
        for (let z = 0; z < 16; z++) {
          const wx = cx * 16 + x, wz = cz * 16 + z;
          const h = hs[x * 16 + z], biome = bs[x * 16 + z];
          const cold = biome === 'snowy' || biome === 'snowy_taiga' || biome === 'frozen_ocean';
          const beach = h <= SEA + 1 && h >= SEA - 1 && biome !== 'swamp' && biome !== 'river';
          const water = h < SEA;
          let top = 2, fill = 3, deep = 3;
          if (biome === 'desert') { top = 12; fill = 12; deep = 24; }
          else if (biome === 'mesa') { top = 12; fill = 172; deep = 172; }
          else if (beach) { top = cold ? 13 : 12; fill = cold ? 13 : 12; deep = cold ? 1 : 24; }
          else if (water) {
            const r = MC.hash3(H + 41, wx >> 2, 0, wz >> 2);
            top = biome === 'river' && r < 0.35 ? 82 : r < 0.25 ? 13 : 12; fill = top === 82 ? 82 : 12; deep = 24;
            if (biome === 'deep_ocean') { top = 13; fill = 13; deep = 1; }
          } else if (biome === 'mountains' && h > 108) { top = 1; fill = 1; deep = 1; }
          else if (biome === 'taiga' && this.n2.noise2(wx / 12, wz / 12) > 0.45) top = 243;
          set(x, 0, z, 7);
          for (let y = 1; y <= 3; y++) if (MC.hash3(H, wx, y, wz) < 0.5) set(x, y, z, 7);
          const sandRed = biome === 'mesa' ? 1 : 0;
          for (let y = 1; y <= h; y++) {
            if (chunk.getId(x, y, z) === 7) continue;
            let id, d = 0;
            if (y === h) { id = top; if (id === 12) d = sandRed; }
            else if (y > h - 4) { id = y > h - 3 ? fill : deep; if (id === 12) d = sandRed; }
            else id = 1;
            if (biome === 'mesa' && y > h - 18 && y < h && y > SEA - 2) {
              const band = MESA_BANDS[(y + Math.floor(this.n2.noise2(wx / 40, wz / 40) * 3) + 64) % MESA_BANDS.length];
              if (band === 172) { id = 172; d = 0; } else { id = 159; d = band; }
            }
            // Пещеры не прорезают дно водоёмов и пляжи — иначе вода льётся под землю
            if (y > 4 && y < h - (water ? 6 : 3)) {
              if (this.caveSample(cg, x, y, z, 0) > 0.42 || this.caveSample(cg, x, y, z, 1) < 0.045) { id = y < 11 ? 11 : 0; d = 0; }
            }
            if (id) set(x, y, z, id, d);
          }
          for (let y = h + 1; y <= SEA; y++) set(x, y, z, 9);
          if (water && cold) set(x, SEA, z, 79);
          if (h >= SEA) {
            const tid = chunk.getId(x, h, z);
            if (tid === 2 && (cold || (biome === 'mountains' && h > 118))) set(x, h + 1, z, 78);
            else if (tid === 1 && h > 125) set(x, h + 1, z, 78);
          }
          this.decorate(chunk, x, z, wx, wz, h, biome);
        }
      }
      this.ores(chunk, cx, cz);
      this.caneAndLilies(chunk, cx, cz, hs, bs);
      // Деревья, в том числе из соседних чанков, чьи кроны заходят в этот
      for (let tx = cx * 16 - 3; tx < cx * 16 + 19; tx++) {
        for (let tz = cz * 16 - 3; tz < cz * 16 + 19; tz++) {
          const r = MC.hash3(H + 21, tx, 0, tz);
          if (r >= 0.09) continue;
          // Деревья старых чанков строит старый генератор
          if (this.legacySet && this.isLegacyChunk(tx >> 4, tz >> 4)) continue;
          const lx = tx - cx * 16, lz = tz - cz * 16;
          const inside = lx >= 0 && lx < 16 && lz >= 0 && lz < 16;
          const h = inside ? hs[lx * 16 + lz] : this.heightAt(tx, tz);
          if (h <= SEA || h > 125) continue;
          const biome = inside ? bs[lx * 16 + lz] : this.biomeAt(tx, tz, h);
          const t = this.treeFor(biome, r, tx, tz);
          if (t < 0) continue;
          if (this.caveAt(tx, h, tz)) continue;
          this.placeTree(chunk, cx, cz, tx, h + 1, tz, t, MC.hash3(H + 23, tx, 0, tz));
        }
      }
      this.wells(chunk, cx, cz, hs, bs);
      this.dungeon(chunk, cx, cz);
      // Подземные крепости с порталом в Край (js/dimensions.js)
      MC.Dimensions.carveStronghold(this.seed, chunk, cx, cz);
      chunk.recalcHeight();
      return chunk;
    }

    // Вид дерева по биому: 0 дуб, 1 ель, 2 берёза, 3 тропическое, 4 акация, 5 болотный дуб; -1 — нет
    treeFor(biome, r, x, z) {
      const kind = MC.hash3(this.seed + 22, x, 0, z);
      switch (biome) {
        case 'forest': return r < 0.045 ? (kind < 0.25 ? 2 : 0) : -1;
        case 'birch': return r < 0.045 ? (kind < 0.85 ? 2 : 0) : -1;
        case 'plains': return r < 0.003 ? 0 : -1;
        case 'taiga': case 'snowy_taiga': return r < 0.035 ? 1 : -1;
        case 'snowy': return r < 0.004 ? 1 : -1;
        case 'jungle': return r < 0.09 ? (kind < 0.55 ? 3 : 0) : -1;
        case 'savanna': return r < 0.005 ? 4 : -1;
        case 'swamp': return r < 0.012 ? 5 : -1;
        case 'mountains': return r < 0.006 ? 1 : -1;
        default: return -1;
      }
    }

    // Трава, цветы, кусты, кактусы, грибы, тыквы и арбузы
    decorate(chunk, x, z, wx, wz, h, biome) {
      if (h < this.SEA || h > 250 || chunk.getId(x, h + 1, z) !== 0) return;
      const H = this.seed, top = chunk.getId(x, h, z);
      const r = MC.hash3(H + 11, wx, 0, wz), r2 = MC.hash3(H + 12, wx, 1, wz);
      const set = (y, id, d) => chunk.set(x, y, z, id, d || 0);
      if (top === 12 || top === 172 || top === 159) {
        if ((biome === 'desert' || biome === 'mesa') && r < 0.004 && top === 12) {
          const tall = 1 + Math.floor(MC.hash3(H + 14, wx, 0, wz) * 3);
          for (let y = 1; y <= tall; y++) set(h + y, 81);
        } else if ((biome === 'desert' || biome === 'mesa') && r > 0.993) set(h + 1, 32);
        return;
      }
      if (top !== 2 && top !== 243) return;
      let grass = 0.1, flowers = 0.024;
      if (biome === 'plains') { grass = 0.28; flowers = 0.04; }
      else if (biome === 'jungle') { grass = 0.3; flowers = 0.006; }
      else if (biome === 'savanna') { grass = 0.35; flowers = 0.004; }
      else if (biome === 'taiga' || biome === 'snowy_taiga' || biome === 'snowy') { grass = 0.14; flowers = 0.004; }
      else if (biome === 'swamp') { grass = 0.12; flowers = 0.004; }
      if (r < grass) {
        // В тайге и джунглях — папоротник, иначе трава
        set(h + 1, 31, (biome === 'taiga' || biome === 'snowy_taiga' || biome === 'jungle') && r2 < 0.4 ? 2 : 1);
      } else if (r < grass + flowers) {
        if (r2 < 0.45) set(h + 1, 37);
        else set(h + 1, 38, biome === 'swamp' ? 1 : Math.floor(r2 * 9));
      } else if (r < grass + flowers + 0.003 && (biome === 'swamp' || biome === 'taiga' || biome === 'snowy_taiga')) set(h + 1, r2 < 0.5 ? 39 : 40);
      else if (r > 0.9993 && (biome === 'plains' || biome === 'forest' || biome === 'taiga')) set(h + 1, 86, Math.floor(r2 * 4));
      else if (r > 0.997 && biome === 'jungle') set(h + 1, 103);
    }

    // Руды и вкрапления жилами (как в Minecraft): из этого и соседних чанков, режутся по границе
    ores(chunk, cx, cz) {
      const H = this.seed + 300;
      for (let ax = cx - 1; ax <= cx + 1; ax++) for (let az = cz - 1; az <= cz + 1; az++) {
        ORES.forEach(([id, data, count, size, y0, y1], oi) => {
          for (let i = 0; i < count; i++) {
            const k = oi * 64 + i;
            let x = ax * 16 + MC.hash3(H + k, ax, 1, az) * 16, z = az * 16 + MC.hash3(H + k, ax, 2, az) * 16;
            let y = y0 + MC.hash3(H + k, ax, 3, az) * (y1 - y0);
            if (Math.abs(x - (cx * 16 + 8)) > 8 + size / 2 + 2 || Math.abs(z - (cz * 16 + 8)) > 8 + size / 2 + 2) continue;
            for (let n = 0; n < size; n++) {
              const lx = Math.floor(x) - cx * 16, lz = Math.floor(z) - cz * 16, yy = Math.floor(y);
              if (lx >= 0 && lx < 16 && lz >= 0 && lz < 16 && yy > 0 && yy < 256 && chunk.getId(lx, yy, lz) === 1 && chunk.getData(lx, yy, lz) === 0) chunk.set(lx, yy, lz, id, data);
              const a = MC.hash3(H + k, ax * 31 + n, 4, az), b = MC.hash3(H + k, ax, 5 + n, az * 17);
              x += Math.floor(a * 3) - 1; z += Math.floor(b * 3) - 1;
              y += Math.floor(MC.hash3(H + k + n, ax, 6, az) * 3) - 1;
            }
          }
        });
      }
      // Изумруды — одиночными блоками глубоко в горах
      for (let i = 0; i < 4; i++) {
        const lx = Math.floor(MC.hash3(H + 900 + i, cx, 0, cz) * 16), lz = Math.floor(MC.hash3(H + 901 + i, cx, 0, cz) * 16);
        const y = 5 + Math.floor(MC.hash3(H + 902 + i, cx, 0, cz) * 27);
        if (this.biomeAt(cx * 16 + lx, cz * 16 + lz) === 'mountains' && chunk.getId(lx, y, lz) === 1) chunk.set(lx, y, lz, 129, 0);
      }
    }

    // Сахарный тростник у воды, кувшинки в болотах
    caneAndLilies(chunk, cx, cz, hs, bs) {
      const H = this.seed, SEA = this.SEA;
      for (let x = 0; x < 16; x++) for (let z = 0; z < 16; z++) {
        const h = hs[x * 16 + z], b = bs[x * 16 + z], wx = cx * 16 + x, wz = cz * 16 + z;
        const r = MC.hash3(H + 51, wx, 0, wz);
        if (h < SEA && b === 'swamp' && h >= SEA - 2 && r < 0.08 && chunk.getId(x, SEA, z) === 9) chunk.set(x, SEA + 1, z, 111, 0);
        if (h !== SEA && h !== SEA + 1) continue;
        const top = chunk.getId(x, h, z);
        if ((top !== 2 && top !== 12 && top !== 3) || chunk.getId(x, h + 1, z) !== 0 || r > 0.12) continue;
        let wet = false;
        for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const nx = x + dx, nz = z + dz;
          if (nx < 0 || nx > 15 || nz < 0 || nz > 15) continue;
          const id = chunk.getId(nx, h, nz);
          if (id === 8 || id === 9) wet = true;
        }
        if (!wet) continue;
        const tall = 1 + Math.floor(MC.hash3(H + 52, wx, 0, wz) * 3);
        for (let y = 1; y <= tall; y++) chunk.set(x, h + y, z, 83, 0);
      }
    }

    // Колодец в пустыне
    wells(chunk, cx, cz, hs, bs) {
      if (MC.hash3(this.seed + 61, cx, 0, cz) > 0.006) return;
      const x = 5, z = 5, h = hs[x * 16 + z];
      if (bs[x * 16 + z] !== 'desert' || h <= this.SEA) return;
      for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) {
        chunk.set(x + dx, h, z + dz, 24, 0);
        for (let y = 1; y <= 4; y++) chunk.set(x + dx, h + y, z + dz, 0, 0);
        const edge = Math.abs(dx) === 2 || Math.abs(dz) === 2;
        if (!edge && Math.abs(dx) + Math.abs(dz) <= 1) chunk.set(x + dx, h, z + dz, 9, 0);
        if (Math.abs(dx) === 1 && Math.abs(dz) === 1) chunk.set(x + dx, h + 1, z + dz, 24, 0);
        if (edge && dx !== 0 && dz !== 0) continue;
        if (!edge) continue;
        chunk.set(x + dx, h + 1, z + dz, 44, 1);
      }
      chunk.set(x, h - 1, z, 9, 0);
      for (const [dx, dz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) for (let y = 1; y <= 2; y++) chunk.set(x + dx, h + y, z + dz, 24, 0);
      for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) chunk.set(x + dx, h + 3, z + dz, 44, 1);
    }

    // Подземелье: комната из булыжника и замшелого булыжника, рассадник и сундуки с добычей
    dungeon(chunk, cx, cz) {
      const H = this.seed + 70;
      if (MC.hash3(H, cx, 0, cz) > 0.09) return;
      const x = 4 + Math.floor(MC.hash3(H, cx, 1, cz) * 8), z = 4 + Math.floor(MC.hash3(H, cx, 2, cz) * 8);
      const y = 12 + Math.floor(MC.hash3(H, cx, 3, cz) * 36);
      if (chunk.getId(x, y + 6, z) === 0 || chunk.getId(x, y - 1, z) === 0) return;
      // Хотя бы одна стена касается пещеры — иначе в подземелье не попасть
      let open = 0;
      for (let dx = -4; dx <= 4; dx++) for (let dz = -4; dz <= 4; dz++) if (Math.abs(dx) === 4 || Math.abs(dz) === 4) {
        if (chunk.getId(x + dx, y + 1, z + dz) === 0) open++;
      }
      if (!open) return;
      for (let dx = -4; dx <= 4; dx++) for (let dz = -4; dz <= 4; dz++) for (let dy = 0; dy <= 5; dy++) {
        const wall = Math.abs(dx) === 4 || Math.abs(dz) === 4 || dy === 0 || dy === 5;
        const lx = x + dx, lz = z + dz;
        if (wall) {
          if (chunk.getId(lx, y + dy, lz) === 0 && dy > 0 && dy < 5) continue;
          const mossy = MC.hash3(H + 5, cx * 16 + lx, y + dy, cz * 16 + lz) < (dy === 0 ? 0.6 : 0.3);
          chunk.set(lx, y + dy, lz, mossy ? 48 : 4, 0);
        } else chunk.set(lx, y + dy, lz, 0, 0);
      }
      const kind = 1 + Math.floor(MC.hash3(H, cx, 4, cz) * 3);
      chunk.set(x, y + 1, z, 52, kind);
      const spots = [[x - 3, z, 5], [x + 3, z, 4], [x, z - 3, 3], [x, z + 3, 2]];
      const n = 1 + (MC.hash3(H, cx, 5, cz) < 0.5 ? 1 : 0);
      for (let i = 0; i < n; i++) {
        const [lx, lz, face] = spots[(Math.floor(MC.hash3(H, cx, 6, cz) * 4) + i * 2) % 4];
        chunk.set(lx, y + 1, lz, 54, face);
        const wx = cx * 16 + lx, wz = cz * 16 + lz;
        if (MC.Dimensions && MC.Dimensions.fillLoot) MC.Dimensions.fillLoot(this.record, wx + ',' + (y + 1) + ',' + wz, MC.Dimensions.LOOT.dungeon, this.seed + 71, wx, y + 1, wz);
      }
    }

    placeTree(chunk, cx, cz, tx, ty, tz, kind, r) {
      const put = (x, y, z, id, d, onlyAir) => {
        const lx = x - cx * 16, lz = z - cz * 16;
        if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 0 || y > 255) return;
        if (onlyAir) {
          const cur = chunk.getId(lx, y, lz);
          if (cur !== 0 && cur !== 31 && cur !== 78 && cur !== 106) return;
        }
        chunk.set(lx, y, lz, id, d);
      };
      const at = (x, y, z) => {
        const lx = x - cx * 16, lz = z - cz * 16;
        return lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 0 || y > 255 ? -1 : chunk.getId(lx, y, lz);
      };
      // Лоза свисает с листвы с внешней стороны (данные — сторона, к которой она крепится)
      const vines = (x, y, z, len) => {
        for (const [dx, dz, d] of [[1, 0, 2], [-1, 0, 8], [0, 1, 4], [0, -1, 1]]) {
          if (MC.hash3(this.seed + 37, x + dx * 3, y, z + dz * 5) > 0.3) continue;
          for (let k = 0; k < len && at(x + dx, y - k, z + dz) === 0; k++) put(x + dx, y - k, z + dz, 106, d, true);
        }
      };
      const trunk = 4 + Math.floor(r * 3);
      if (kind === 1) {
        for (let y = 0; y < trunk + 2; y++) put(tx, ty + y, tz, 17, 1);
        let rad = 0;
        for (let y = trunk + 2; y >= 2; y--) {
          for (let dx = -rad; dx <= rad; dx++) for (let dz = -rad; dz <= rad; dz++) {
            if (Math.abs(dx) + Math.abs(dz) > rad + 1 || (dx === 0 && dz === 0 && y < trunk + 2)) continue;
            put(tx + dx, ty + y, tz + dz, 18, 1, true);
          }
          rad = rad >= 2 ? 1 : rad + 1;
        }
        put(tx, ty + trunk + 2, tz, 18, 1, true);
        put(tx, ty + trunk + 3, tz, 18, 1, true);
        return;
      }
      if (kind === 3) {
        // Тропическое дерево: высокий ствол, широкая крона, лоза по стволу
        const t = 6 + Math.floor(r * 7);
        for (let y = 0; y < t; y++) put(tx, ty + y, tz, 17, 3);
        for (let y = t - 3; y <= t + 1; y++) {
          const rad = y >= t ? 2 - (y - t) : 3;
          for (let dx = -rad; dx <= rad; dx++) for (let dz = -rad; dz <= rad; dz++) {
            if (dx * dx + dz * dz > rad * rad + 1) continue;
            put(tx + dx, ty + y, tz + dz, 18, 3, true);
          }
        }
        for (const [dx, dz, d] of [[1, 0, 2], [-1, 0, 8], [0, 1, 4], [0, -1, 1]]) {
          if (MC.hash3(this.seed + 38, tx + dx, ty, tz + dz) < 0.5) for (let y = 1; y < t - 3; y++) put(tx + dx, ty + y, tz + dz, 106, d, true);
        }
        if (MC.hash3(this.seed + 39, tx, ty, tz) < 0.3) put(tx + 1, ty + t - 4, tz, 127, 3, true);
        return;
      }
      if (kind === 4) {
        // Акация: ствол уходит вбок, плоская крона
        const t = 4 + Math.floor(r * 2);
        const dir = [[1, 0], [-1, 0], [0, 1], [0, -1]][Math.floor(MC.hash3(this.seed + 40, tx, 0, tz) * 4)];
        let x = tx, z = tz;
        for (let y = 0; y < t; y++) {
          if (y >= t - 2) { x += dir[0]; z += dir[1]; }
          put(x, ty + y, z, 162, 0);
        }
        const top = ty + t;
        for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) {
          if (Math.abs(dx) === 2 && Math.abs(dz) === 2) continue;
          put(x + dx, top - 1, z + dz, 161, 0, true);
          if (Math.abs(dx) <= 1 && Math.abs(dz) <= 1) put(x + dx, top, z + dz, 161, 0, true);
        }
        return;
      }
      const leaf = kind === 2 ? 2 : 0;
      for (let y = 0; y < trunk; y++) put(tx, ty + y, tz, 17, leaf);
      for (let y = trunk - 3; y <= trunk; y++) {
        const rad = y >= trunk - 1 ? 1 : 2;
        for (let dx = -rad; dx <= rad; dx++) for (let dz = -rad; dz <= rad; dz++) {
          if (rad === 2 && Math.abs(dx) === 2 && Math.abs(dz) === 2 && MC.hash3(this.seed + 31, tx + dx, ty + y, tz + dz) < 0.5) continue;
          if (rad === 1 && y === trunk && Math.abs(dx) === 1 && Math.abs(dz) === 1) continue;
          put(tx + dx, ty + y, tz + dz, 18, leaf, true);
        }
      }
      // Болотный дуб: шире и с лозой
      if (kind === 5) {
        for (let dx = -3; dx <= 3; dx++) for (let dz = -3; dz <= 3; dz++) if (Math.abs(dx) === 3 || Math.abs(dz) === 3) {
          if (Math.abs(dx) + Math.abs(dz) > 4) continue;
          put(tx + dx, ty + trunk - 2, tz + dz, 18, 0, true);
        }
        for (let dx = -3; dx <= 3; dx++) for (let dz = -3; dz <= 3; dz++) {
          if (at(tx + dx, ty + trunk - 2, tz + dz) === 18) vines(tx + dx, ty + trunk - 3, tz + dz, 4);
        }
      }
    }

    findSpawn() {
      const ws = this.record && this.record.worldSpawn;
      if (ws) return { x: ws.x, y: ws.y, z: ws.z };
      for (let i = 0; i < 600; i++) {
        const x = Math.floor(Math.cos(i) * i * 2), z = Math.floor(Math.sin(i) * i * 2);
        const h = this.heightAt(x, z);
        const b = this.biomeAt(x, z, h);
        if (h > this.SEA + 1 && b !== 'desert' && b !== 'mesa' && b !== 'swamp' && b !== 'mountains' && !this.caveAt(x, h, z)) return { x: x + 0.5, y: h + 1, z: z + 0.5 };
      }
      return { x: 0.5, y: this.heightAt(0, 0) + 2, z: 0.5 };
    }
  }

  // Генератор версий до 1.15: им продолжают строиться миры, созданные раньше, чтобы на границе старых
  // и новых чанков не было обрывов
  class LegacyGenerator {
    constructor(seed) {
      this.seed = seed | 0;
      this.n1 = new MC.Perlin(seed);
      this.n2 = new MC.Perlin(seed + 1);
      this.n3 = new MC.Perlin(seed + 2);
      this.cave = new MC.Perlin(seed + 3);
      this.biome = new MC.Perlin(seed + 4);
      this.SEA = 62;
    }

    heightAt(x, z) {
      const base = this.n1.fbm2(x / 160, z / 160, 4);
      const hills = this.n2.fbm2(x / 60, z / 60, 3);
      const mount = Math.max(0, this.n3.fbm2(x / 300, z / 300, 2)) * 2.2;
      return Math.floor(64 + base * 14 + hills * 6 + mount * mount * 40);
    }

    biomeAt(x, z) {
      const v = this.biome.fbm2(x / 400, z / 400, 2);
      return v > 0.25 ? 'desert' : v < -0.3 ? 'taiga' : 'plains';
    }

    generate(cx, cz) {
      const chunk = new Chunk(cx, cz);
      const set = (x, y, z, id, d) => chunk.set(x, y, z, id, d || 0);
      const H = this.seed;
      for (let x = 0; x < 16; x++) {
        for (let z = 0; z < 16; z++) {
          const wx = cx * 16 + x, wz = cz * 16 + z;
          const h = this.heightAt(wx, wz);
          const biome = this.biomeAt(wx, wz);
          const beach = h <= this.SEA + 1;
          set(x, 0, z, 7);
          for (let y = 1; y <= 3; y++) if (MC.hash3(H, wx, y, wz) < 0.5) set(x, y, z, 7);
          for (let y = 1; y <= h; y++) {
            if (chunk.getId(x, y, z) === 7) continue;
            let id;
            if (y === h) {
              if (biome === 'desert' || beach) id = 12;
              else if (h > 110) id = 1;
              else id = 2;
            } else if (y > h - 4) {
              id = biome === 'desert' || beach ? (y > h - 3 ? 12 : 24) : 3;
            } else {
              id = 1;
              const r = MC.hash3(H + 7, wx, y, wz);
              if (y < 128 && r < 0.012) id = 16;
              else if (y < 64 && r < 0.019) id = 15;
              else if (y < 32 && r < 0.0215) id = 14;
              else if (y < 16 && r < 0.0245) id = 73;
              else if (y < 16 && r < 0.0258) id = 56;
              else if (y < 30 && r < 0.0268) id = 21;
              else if (r > 0.985) id = 13;
            }
            // Пещеры
            if (y > 4 && y < h - 3) {
              const c = this.cave.noise3(wx / 28, y / 18, wz / 28);
              if (c > 0.42) id = y < 11 ? 11 : 0;
            }
            if (id) set(x, y, z, id);
          }
          for (let y = h + 1; y <= this.SEA; y++) set(x, y, z, 9);
          if (h >= this.SEA && h > 105 && biome !== 'desert') set(x, h + 1, z, 78, 0);
          if (biome === 'taiga' && h > this.SEA && chunk.getId(x, h, z) === 2) set(x, h + 1, z, 78, 0);
          // Растительность
          if (h > this.SEA && chunk.getId(x, h, z) === 2 && chunk.getId(x, h + 1, z) === 0) {
            const r = MC.hash3(H + 11, wx, 0, wz);
            if (r < 0.10) set(x, h + 1, z, 31, 1);
            else if (r < 0.112) set(x, h + 1, z, 37);
            else if (r < 0.124) set(x, h + 1, z, 38, Math.floor(MC.hash3(H + 12, wx, 1, wz) * 9));
          }
          if (biome === 'desert' && h > this.SEA && MC.hash3(H + 13, wx, 0, wz) < 0.004) {
            const tall = 1 + Math.floor(MC.hash3(H + 14, wx, 0, wz) * 3);
            for (let y = 1; y <= tall; y++) set(x, h + y, z, 81);
          }
          if (biome === 'desert' && h > this.SEA && MC.hash3(H + 15, wx, 0, wz) > 0.994) set(x, h + 1, z, 32);
        }
      }
      // Деревья, в том числе из соседних чанков, чьи кроны заходят в этот
      for (let tx = cx * 16 - 3; tx < cx * 16 + 19; tx++) {
        for (let tz = cz * 16 - 3; tz < cz * 16 + 19; tz++) {
          const r = MC.hash3(H + 21, tx, 0, tz);
          const biome = this.biomeAt(tx, tz);
          const chance = biome === 'taiga' ? 0.02 : biome === 'plains' ? 0.012 : 0;
          if (r >= chance) continue;
          const h = this.heightAt(tx, tz);
          if (h <= this.SEA + 1 || h > 115) continue;
          if (this.cave.noise3(tx / 28, h / 18, tz / 28) > 0.42) continue;
          const kind = biome === 'taiga' ? 1 : MC.hash3(H + 22, tx, 0, tz) < 0.2 ? 2 : 0;
          this.placeTree(chunk, cx, cz, tx, h + 1, tz, kind, MC.hash3(H + 23, tx, 0, tz));
        }
      }
      // Подземные крепости с порталом в Край (js/dimensions.js)
      MC.Dimensions.carveStronghold(this.seed, chunk, cx, cz);
      chunk.recalcHeight();
      return chunk;
    }

    placeTree(chunk, cx, cz, tx, ty, tz, kind, r) {
      const put = (x, y, z, id, d, onlyAir) => {
        const lx = x - cx * 16, lz = z - cz * 16;
        if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 0 || y > 255) return;
        if (onlyAir) {
          const cur = chunk.getId(lx, y, lz);
          if (cur !== 0 && cur !== 31 && cur !== 78) return;
        }
        chunk.set(lx, y, lz, id, d);
      };
      const trunk = 4 + Math.floor(r * 3);
      if (kind === 1) {
        for (let y = 0; y < trunk + 2; y++) put(tx, ty + y, tz, 17, 1);
        let rad = 0;
        for (let y = trunk + 2; y >= 2; y--) {
          for (let dx = -rad; dx <= rad; dx++) for (let dz = -rad; dz <= rad; dz++) {
            if (Math.abs(dx) + Math.abs(dz) > rad + 1 || (dx === 0 && dz === 0 && y < trunk + 2)) continue;
            put(tx + dx, ty + y, tz + dz, 18, 1, true);
          }
          rad = rad >= 2 ? 1 : rad + 1;
        }
        put(tx, ty + trunk + 2, tz, 18, 1, true);
        put(tx, ty + trunk + 3, tz, 18, 1, true);
        return;
      }
      const leaf = kind === 2 ? 2 : 0;
      for (let y = 0; y < trunk; y++) put(tx, ty + y, tz, 17, leaf);
      for (let y = trunk - 3; y <= trunk; y++) {
        const rad = y >= trunk - 1 ? 1 : 2;
        for (let dx = -rad; dx <= rad; dx++) for (let dz = -rad; dz <= rad; dz++) {
          if (rad === 2 && Math.abs(dx) === 2 && Math.abs(dz) === 2 && MC.hash3(this.seed + 31, tx + dx, ty + y, tz + dz) < 0.5) continue;
          if (rad === 1 && y === trunk && Math.abs(dx) === 1 && Math.abs(dz) === 1) continue;
          put(tx + dx, ty + y, tz + dz, 18, leaf, true);
        }
      }
    }

    findSpawn() {
      for (let i = 0; i < 400; i++) {
        const x = Math.floor(Math.cos(i) * i * 2), z = Math.floor(Math.sin(i) * i * 2);
        const h = this.heightAt(x, z);
        if (h > this.SEA + 1 && this.biomeAt(x, z) !== 'desert') return { x: x + 0.5, y: h + 1, z: z + 0.5 };
      }
      return { x: 0.5, y: this.heightAt(0, 0) + 2, z: 0.5 };
    }
  }

  MC.Chunk = Chunk;
  MC.World = World;
  MC.Generator = Generator;
  MC.LegacyGenerator = LegacyGenerator;
  MC.chunkKey = key;
})();
