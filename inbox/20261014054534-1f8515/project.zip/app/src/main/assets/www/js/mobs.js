// Существа и выброшенные предметы одиночной игры: появление, поведение, бой, взрывы, подбор предметов
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const Blocks = MC.Blocks;

  // hp, скорость (доля от скорости игрока), враждебность, урон, добыча [id, data, min, max]
  const DEFS = {
    10: { hp: 4, speed: 0.4, drops: [[288, 0, 0, 2], [365, 0, 1, 1]], cooked: { 365: 366 } },
    11: { hp: 10, speed: 0.35, drops: [[334, 0, 0, 2], [363, 0, 1, 3]], cooked: { 363: 364 } },
    12: { hp: 10, speed: 0.4, drops: [[319, 0, 1, 3]], cooked: { 319: 320 } },
    13: { hp: 8, speed: 0.4, drops: [[35, 0, 1, 1], [423, 0, 1, 2]], cooked: { 423: 424 } },
    32: { hp: 20, speed: 0.55, hostile: true, damage: 3, burns: true, kill: 'Убит зомби', drops: [[367, 0, 0, 2]] },
    33: { hp: 20, speed: 0.5, hostile: true, creeper: true, drops: [[289, 0, 0, 2]] },
    35: { hp: 16, speed: 0.7, hostile: true, damage: 2, dayNeutral: true, kill: 'Убит пауком', drops: [[287, 0, 0, 2], [375, 0, 0, 1]] },
    // Существа, которые появляются только из яйца призыва. neutral — нападают, только если их ударить.
    // Летающие и плавающие (летучая мышь, гаст, ифрит, спрут, страж, вредина) и слизни в одиночной игре не поддерживаются
    14: { hp: 8, speed: 0.6, hostile: true, neutral: true, damage: 4, kill: 'Загрызен волком', drops: [] },
    15: { hp: 20, speed: 0.4, drops: [] },
    16: { hp: 10, speed: 0.35, drops: [[334, 0, 0, 2], [363, 0, 1, 3]], cooked: { 363: 364 } },
    18: { hp: 3, speed: 0.6, drops: [[415, 0, 0, 1], [411, 0, 0, 1]], cooked: { 411: 412 } },
    20: { hp: 100, speed: 0.4, hostile: true, neutral: true, damage: 7, kill: 'Убит железным големом', drops: [[265, 0, 3, 5], [38, 0, 0, 2]] },
    21: { hp: 4, speed: 0.4, drops: [[332, 0, 0, 15]] },
    22: { hp: 10, speed: 0.6, drops: [] },
    28: { hp: 30, speed: 0.45, hostile: true, neutral: true, damage: 6, kill: 'Убит белым медведем', drops: [[349, 0, 0, 2], [349, 1, 0, 2]] },
    34: { hp: 20, speed: 0.5, hostile: true, damage: 2, burns: true, ranged: 'arrow', kill: 'Застрелен скелетом', drops: [[352, 0, 0, 2], [262, 0, 0, 2]] },
    36: { hp: 20, speed: 0.55, hostile: true, neutral: true, damage: 5, fireproof: true, kill: 'Убит зомби-свиночеловеком', drops: [[367, 0, 0, 1], [371, 0, 0, 1], [266, 0, 0, 1]] },
    // Существа Нижнего мира: слизни и магмовые кубы прыгают, ифрит и гаст летают и стреляют огненными шарами
    37: { hp: 16, speed: 0.5, hostile: true, hop: true, damage: 4, kill: 'Убит слизнем', drops: [[341, 0, 0, 2]] },
    42: { hp: 16, speed: 0.55, hostile: true, hop: true, damage: 6, fireproof: true, kill: 'Убит магмовым кубом', drops: [[378, 0, 0, 1]] },
    43: { hp: 20, speed: 0.3, hostile: true, fly: true, fireproof: true, ranged: 'fireball', damage: 6, kill: 'Сожжён ифритом', drops: [[369, 0, 0, 1]] },
    41: { hp: 10, speed: 0.25, hostile: true, fly: true, fireproof: true, ranged: 'ghastball', kill: 'Убит огненным шаром гаста', drops: [[370, 0, 0, 1], [289, 0, 0, 2]] },
    38: { hp: 40, speed: 0.6, hostile: true, neutral: true, ender: true, damage: 7, kill: 'Убит эндерменом', drops: [[368, 0, 0, 1]] },
    39: { hp: 8, speed: 0.55, hostile: true, damage: 1, kill: 'Убит чешуйницей', drops: [] },
    40: { hp: 12, speed: 0.75, hostile: true, damage: 2, dayNeutral: true, kill: 'Убит пещерным пауком', drops: [[287, 0, 0, 2], [375, 0, 0, 1]] },
    44: { hp: 20, speed: 0.55, hostile: true, damage: 3, burns: true, kill: 'Убит зомби-жителем', drops: [[367, 0, 0, 2]] },
    45: { hp: 26, speed: 0.45, hostile: true, damage: 2, kill: 'Убит ведьмой', drops: [[348, 0, 0, 2], [331, 0, 0, 2], [353, 0, 0, 2], [374, 0, 0, 2], [289, 0, 0, 2]] },
    46: { hp: 20, speed: 0.5, hostile: true, damage: 2, burns: true, ranged: 'arrow', arrowPotion: 18, kill: 'Застрелен зимогором', drops: [[352, 0, 0, 2], [262, 0, 0, 2], [262, 19, 0, 1]] },
    47: { hp: 20, speed: 0.55, hostile: true, damage: 3, kill: 'Убит кадавром', drops: [[367, 0, 0, 2]] },
    48: { hp: 20, speed: 0.55, hostile: true, damage: 8, fireproof: true, wither: true, kill: 'Убит скелетом-иссушителем', drops: [[263, 0, 0, 1], [352, 0, 0, 2]], rare: [[397, 1, 0.025]] },
    57: { hp: 24, speed: 0.6, hostile: true, damage: 7, kill: 'Убит поборником', drops: [[388, 0, 0, 1]] },
    // Дракон Края: кружит над островом, пикирует на игрока и плюётся огненными шарами с драконьим дыханием
    53: { hp: 200, speed: 0.6, hostile: true, fly: true, dragon: true, fireproof: true, damage: 10, size: [8, 4], kill: 'Убит драконом Края', drops: [] },
    // Шалкер: сидит на месте в городах Края, стреляет самонаводящимися снарядами с левитацией
    // Иссушитель: призывается из песка душ и трёх черепов скелета-иссушителя, летает, стреляет черепами
    52: { hp: 300, speed: 0.6, hostile: true, fly: true, witherBoss: true, fireproof: true, size: [0.9, 3.5], damage: 8, xp: 50, kill: 'Убит иссушителем', drops: [[399, 0, 1, 1]] },
    54: { hp: 30, speed: 0, hostile: true, shulker: true, ranged: 'shulker', fireproof: true, size: [1, 1], kill: 'Убит шалкером', drops: [], rare: [[445, 0, 0.5]] }
  };
  // Рассадник: тип существа хранится в data блока 52
  const SPAWNER_TYPES = [32, 32, 34, 35, 43, 40, 42, 39];
  // Блоки, которые дракон не ломает
  const DRAGON_PROOF = new Set([7, 49, 101, 119, 120, 121, 122, 209, 51]);
  // Иссушитель не ломает бедрок, порталы, рамки портала Края, барьеры и командные блоки
  const WITHER_PROOF = new Set([7, 90, 119, 120, 209, 137, 188, 189, 95, 166]);
  // Пирамида маяка: железо, золото, алмаз, изумруд
  const BEACON_BASE = new Set([42, 41, 57, 133]);
  const PASSIVE = [12, 11, 13, 10];
  const HOSTILE = [32, 32, 33, 35, 34];
  // Нижний мир: свинозомби чаще всех; ифриты и иссушители — у адского кирпича (крепости)
  const NETHER = [36, 36, 36, 42, 41];
  const FORTRESS = [43, 43, 48];
  const E = () => MC.Effects.E;
  const MOB_CAP = 10, HOSTILE_CAP = 8;
  const ITEM_CAP = 1500;

  const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  const yawTo = (dx, dz) => Math.atan2(-dx, dz) * 180 / Math.PI;

  class Entities {
    constructor(game) {
      this.game = game;
      this.world = game.world;
      this.list = new Map();
      this.spawners = new Map();
      // Рассадники ищутся в каждом загруженном чанке
      game.world.onChunkSet((cx, cz) => this.scanSpawners(cx, cz));
      // Поставленный маяк сразу начинает работать
      game.world.onBlockSet((x, y, z) => { if (game.world.getId(x, y, z) === 138) this.trackBeacon(x, y, z); });
      this.nextId = 1;
      this.spawnTimer = 0;
    }

    // ---------- Предметы ----------
    spawnItem(item, x, y, z, vx, vy, vz, delay) {
      if (!item || !item.id || item.count <= 0) return;
      const eid = this.nextId++;
      this.list.set(eid, {
        kind: 'item', eid, item: { id: item.id, data: item.data, count: item.count },
        x, y, z, vx: vx === undefined ? (Math.random() - 0.5) * 2 : vx, vy: vy === undefined ? 3 : vy, vz: vz === undefined ? (Math.random() - 0.5) * 2 : vz,
        age: 0, delay: delay === undefined ? 0.5 : delay
      });
    }

    liquidAt(x, y, z) {
      const id = this.world.getId(Math.floor(x), Math.floor(y), Math.floor(z));
      return id >= 8 && id <= 11;
    }

    // Объединение одинаковых лежащих рядом предметов в стопки до 64 (как в Minecraft)
    mergeItems() {
      const cells = new Map();
      for (const e of this.list.values()) {
        if (e.kind !== 'item' || e.item.count >= 64) continue;
        const key = Math.floor(e.x) + ',' + Math.floor(e.y) + ',' + Math.floor(e.z) + ',' + e.item.id + ',' + (e.item.data | 0);
        const o = cells.get(key);
        if (!o || !this.list.has(o.eid)) { cells.set(key, e); continue; }
        if (e.item.nbt || o.item.nbt) continue;
        const max = MC.Survival.maxStack(e.item.id);
        const n = Math.min(e.item.count, max - o.item.count);
        if (n <= 0) { cells.set(key, e); continue; }
        o.item.count += n;
        o.age = Math.min(o.age, e.age);
        o.delay = Math.max(o.delay, e.delay);
        e.item.count -= n;
        if (e.item.count <= 0) this.list.delete(e.eid);
        if (o.item.count >= max) cells.delete(key);
      }
    }

    // Снаряды: жемчуг Края (телепорт), снежок и яйцо (толчок)
    throwProjectile(item, x, y, z, dir, speed) {
      const eid = this.nextId++;
      this.list.set(eid, { kind: 'proj', eid, item: { id: item.id, data: item.data, count: 1 }, x, y, z, vx: dir[0] * speed, vy: dir[1] * speed, vz: dir[2] * speed, age: 0 });
    }

    updateProj(e, dt) {
      e.age += dt;
      if (e.age > 20) { this.list.delete(e.eid); return; }
      const w = this.world;
      if (!w.isLoaded(Math.floor(e.x), Math.floor(e.z))) { this.list.delete(e.eid); return; }
      e.vy -= 12 * dt;
      const drag = Math.pow(0.99, dt * 20);
      e.vx *= drag; e.vy *= drag; e.vz *= drag;
      const steps = 4;
      for (let i = 0; i < steps; i++) {
        const px = e.x, py = e.y, pz = e.z;
        const nx = e.x + e.vx * dt / steps, ny = e.y + e.vy * dt / steps, nz = e.z + e.vz * dt / steps;
        const crystal = this.crystalAt(nx, ny, nz, 0.15);
        if (crystal) { this.list.delete(e.eid); this.destroyCrystal(crystal); return; }
        // Жемчуг, брошенный во врата Края, переносит через них
        if (e.item.id === 368 && w.getId(Math.floor(nx), Math.floor(ny), Math.floor(nz)) === 209 && this.game.portals) {
          this.list.delete(e.eid);
          this.game.portals.enterGateway(Math.floor(nx), Math.floor(ny), Math.floor(nz)).catch((err) => console.warn('Врата', err));
          return;
        }
        const target = this.mobAt(nx, ny, nz, 0.15, null);
        if (target || this.solidAt(nx, ny, nz)) { this.projectileHit(e, px, py, pz, target); return; }
        e.x = nx; e.y = ny; e.z = nz;
      }
    }

    // Размер существа [ширина, высота] по модели
    mobSize(m) {
      if (m.def && m.def.size) return m.def.size;
      const look = MC.ENTITY_LOOK && MC.ENTITY_LOOK[m.type];
      return look ? look[2] : [0.6, 1.8];
    }

    // Существо, в которое попадает точка (с запасом pad), кроме skip
    mobAt(x, y, z, pad, skip) {
      this.hitPart = null;
      for (const m of this.list.values()) {
        if (m.kind !== 'mob' || m.dead || m === skip) continue;
        if (m.def.dragon) {
          for (const pt of this.dragonParts(m)) {
            if (Math.abs(x - pt.x) < pt.w / 2 + pad && Math.abs(z - pt.z) < pt.w / 2 + pad && y > pt.y - pad && y < pt.y + pt.h + pad) { this.hitPart = pt.part; return m; }
          }
          continue;
        }
        const b = m.body, sz = this.mobSize(m);
        if (Math.abs(x - b.x) < sz[0] / 2 + pad && Math.abs(z - b.z) < sz[0] / 2 + pad && y > b.y - pad && y < b.y + sz[1] + pad) return m;
      }
      return null;
    }

    playerAt(x, y, z, pad) {
      const g = this.game, p = g.player;
      if (g.dead) return false;
      return Math.abs(x - p.x) < 0.3 + pad && Math.abs(z - p.z) < 0.3 + pad && y > p.y - pad && y < p.y + 1.8 + pad;
    }

    projectileHit(e, x, y, z, mob) {
      const g = this.game, p = g.player;
      this.list.delete(e.eid);
      if (e.item.id === 438 || e.item.id === 441) { this.splashPotion(e.item.data, x, y, z, e.item.id === 441); return; }
      if (mob) this.hurtMob(mob, 0, x, z, true);
      if (e.item.id === 368) {
        // Жемчуг Края: игрок переносится в точку падения и получает 5 урона (как в Minecraft)
        let ty = y;
        while (ty > 1 && !this.solidAt(x, ty - 0.05, z)) ty -= 0.05;
        p.x = x; p.y = ty + 0.01; p.z = z;
        p.vx = 0; p.vy = 0; p.vz = 0;
        p.fallStart = null;
        MC.Sound.play('mob.endermen.portal', [x, y, z], 1, 1);
        g.damagePlayer(5, null, null, 'Телепортация жемчугом Края');
      } else if (e.item.id === 344) {
        if (Math.random() < 0.125) this.spawnMob(10, x, y, z);
      }
    }

    // ---------- Зелья: взрывные и оседающие ----------
    splashPotion(data, x, y, z, lingering) {
      const g = this.game, p = g.player;
      const color = MC.Effects.potionColor(data);
      MC.Sound.play('random.glass', { x, y, z }, 1, 0.9 + Math.random() * 0.2);
      if (g.particles.potion) g.particles.potion(x, y, z, color, 4);
      if (lingering) {
        const eid = this.nextId++;
        this.list.set(eid, { kind: 'cloud', eid, x, y: Math.floor(y + 0.01), z, data, r: 3, age: 0, life: 30, timer: 0.5 });
        return;
      }
      // Сила зависит от расстояния до центра брызг (до 4 блоков)
      const dp = Math.hypot(p.x - x, p.y + 0.9 - y, p.z - z);
      if (dp < 4 && g.gamemode !== 3) g.applyPotion(data, Math.max(0.25, 1 - dp / 4));
      for (const m of Array.from(this.list.values())) {
        if (m.kind !== 'mob' || m.dead) continue;
        const d = Math.hypot(m.body.x - x, m.body.y + 0.5 - y, m.body.z - z);
        if (d < 4) this.potionMob(m, data, Math.max(0.25, 1 - d / 4));
      }
    }

    updateCloud(e, dt) {
      const g = this.game, p = g.player;
      e.age += dt;
      if (e.age >= e.life || e.r <= 0.5) { this.list.delete(e.eid); return; }
      const color = e.breath ? [0.8, 0.3, 0.8] : MC.Effects.potionColor(e.data);
      if (g.particles.swirl) for (let i = 0; i < 2; i++) { const a = Math.random() * Math.PI * 2, r = Math.random() * e.r; g.particles.swirl(e.x + Math.cos(a) * r, e.y + 0.1, e.z + Math.sin(a) * r, color, 0.1, 0.3); }
      e.timer -= dt;
      if (e.timer > 0) return;
      e.timer = 1;
      let used = false;
      // Облако действует четвертью силы и уменьшается с каждым задетым существом
      if (Math.hypot(p.x - e.x, p.z - e.z) < e.r && Math.abs(p.y - e.y) < 2 && !g.dead) { g.applyPotion(e.data, 0.25); used = true; }
      for (const m of Array.from(this.list.values())) {
        if (m.kind !== 'mob' || m.dead) continue;
        if (Math.hypot(m.body.x - e.x, m.body.z - e.z) < e.r && Math.abs(m.body.y - e.y) < 2) { this.potionMob(m, e.data, 0.25); used = true; }
      }
      e.r -= used ? 0.5 : 0.1;
    }

    // Зелье на существо: исцеление ранит нежить, вред — лечит её
    potionMob(m, data, k) {
      const pt = MC.Effects.POTION[data];
      if (!pt) return;
      const [id, sec, amp] = pt;
      this.effectMob(m, id, amp, Math.round(sec * k), k);
    }

    effectMob(m, id, amp, sec, k) {
      const ef = MC.Effects.E;
      const undead = MC.Effects.UNDEAD.has(m.type);
      if (id === ef.HEAL || id === ef.HARM) {
        const harm = (id === ef.HARM) !== undead;
        const n = Math.max(1, Math.round((harm ? 6 : 4) * (1 << amp) * (k || 1)));
        if (harm) { m.invuln = 0; this.hurtMob(m, n, m.body.x, m.body.z, true); } else m.hp = Math.min(m.def.hp, m.hp + n);
        return;
      }
      if (undead && (id === ef.POISON || id === ef.REGEN)) return;
      if (sec <= 0) return;
      if (!m.effects) m.effects = new MC.Effects.EffectSet();
      m.effects.add(id, amp, sec);
    }

    // ---------- Стрелы ----------
    // o: {shooter: 'player' | существо, dmg, crit, potion, pickup, fire, punch}
    shootArrow(x, y, z, vx, vy, vz, o) {
      const eid = this.nextId++;
      this.list.set(eid, Object.assign({ kind: 'arrow', eid, x, y, z, vx, vy, vz, age: 0, stuck: false, dmg: 2, potion: 0,
        item: { id: 262, data: o && o.potion ? o.potion + 1 : 0, count: 1 } }, o));
      MC.Sound.play('random.bow', { x, y, z }, 0.8, 0.9 + Math.random() * 0.3);
    }

    updateArrow(e, dt) {
      const g = this.game, p = g.player, w = this.world;
      e.age += dt;
      if (e.stuck) {
        if (e.age > 60) { this.list.delete(e.eid); return; }
        // Стрела в блоке падает, если блок сломали
        if (!this.solidAt(e.x + e.dx * 0.1, e.y + e.dy * 0.1, e.z + e.dz * 0.1)) { e.stuck = false; e.vx = e.vy = e.vz = 0; return; }
        if (e.pickup && !g.dead && Math.abs(e.x - p.x) < 1.2 && Math.abs(e.z - p.z) < 1.2 && e.y > p.y - 0.5 && e.y < p.y + 2.2) {
          const left = g.gamemode === 1 ? 0 : g.sinv.add({ id: 262, data: e.item.data, count: 1 });
          if (left <= 0) { this.list.delete(e.eid); MC.Sound.play('random.pop', null, 0.3, 1.6); }
        }
        return;
      }
      if (e.age > 30 || !w.isLoaded(Math.floor(e.x), Math.floor(e.z)) || e.y < -64) { this.list.delete(e.eid); return; }
      const inWater = this.liquidAt(e.x, e.y, e.z);
      // Гравитация 0,05 блока/тик², сопротивление воздуха 0,99 за тик (в воде 0,6)
      e.vy -= 20 * dt;
      const drag = Math.pow(inWater ? 0.6 : 0.99, dt * 20);
      e.vx *= drag; e.vy *= drag; e.vz *= drag;
      if (e.fire && g.particles.flame && Math.random() < 0.5) g.particles.flame(e.x, e.y, e.z);
      if (e.crit && g.particles.crit && Math.random() < 0.3) g.particles.add({ kind: 'color', color: 'crit', sprite: 1, x: e.x, y: e.y, z: e.z, vx: 0, vy: 0, vz: 0, life: 0.3, age: 0, size: 0.05, grav: 0, light: 1 });
      const steps = Math.max(2, Math.ceil(Math.hypot(e.vx, e.vy, e.vz) * dt / 0.3));
      for (let i = 0; i < steps; i++) {
        const nx = e.x + e.vx * dt / steps, ny = e.y + e.vy * dt / steps, nz = e.z + e.vz * dt / steps;
        const shooterMob = e.shooter && e.shooter !== 'player' ? e.shooter : null;
        const crystal = this.crystalAt(nx, ny, nz, 0.1);
        if (crystal) { this.list.delete(e.eid); this.destroyCrystal(crystal); return; }
        const mob = this.mobAt(nx, ny, nz, 0.1, shooterMob);
        const hitsPlayer = (e.shooter !== 'player' || e.age > 0.4) && this.playerAt(nx, ny, nz, 0.1);
        if (mob || hitsPlayer) { this.arrowHit(e, mob, hitsPlayer && !mob); return; }
        if (this.solidAt(nx, ny, nz)) {
          const l = Math.hypot(e.vx, e.vy, e.vz) || 1;
          e.stuck = true; e.age = 0; e.dx = e.vx / l; e.dy = e.vy / l; e.dz = e.vz / l;
          e.vx = e.vy = e.vz = 0;
          MC.Sound.play('random.click', { x: nx, y: ny, z: nz }, 0.3, 1.8);
          // Горящая стрела поджигает динамит
          if (e.fire && w.getId(Math.floor(nx), Math.floor(ny), Math.floor(nz)) === 46) {
            const X = Math.floor(nx), Y = Math.floor(ny), Z = Math.floor(nz);
            g.world.setBlock(X, Y, Z, 0, 0);
            this.primeTnt(X, Y, Z, 4);
          }
          return;
        }
        e.x = nx; e.y = ny; e.z = nz;
      }
    }

    // Урон стрелы как в Minecraft: ⌈скорость (блоков/тик) × урон⌉, полное натяжение — ещё до половины сверху
    arrowDamage(e) {
      const speed = Math.hypot(e.vx, e.vy, e.vz) / 20;
      let dmg = Math.ceil(speed * e.dmg);
      if (e.crit) dmg += Math.floor(Math.random() * (dmg / 2 + 2));
      return dmg;
    }

    arrowHit(e, mob, player) {
      const g = this.game;
      const dmg = this.arrowDamage(e);
      this.list.delete(e.eid);
      const pt = e.potion ? MC.Effects.POTION[e.potion] : null;
      if (mob && mob.def.ender) { this.teleportEnder(mob); return; }
      // Сидящий на портале дракон неуязвим для стрел (как в Minecraft): стрела отскакивает
      if (mob && mob.def.dragon && mob.phase === 'perch') { MC.Sound.play('random.click', { x: e.x, y: e.y, z: e.z }, 0.5, 2); return; }
      // Иссушитель с половиной здоровья и меньше закрыт бронёй: стрелы отскакивают
      if (mob && mob.def.witherBoss && (mob.hp <= mob.def.hp / 2 || mob.spawnT > 0)) { MC.Sound.play('random.click', { x: e.x, y: e.y, z: e.z }, 0.5, 2); return; }
      if (mob) {
        const partDmg = mob.def.dragon && this.hitPart !== 'head' ? dmg / 4 + Math.min(dmg, 1) : dmg;
        if (!this.hurtMob(mob, partDmg, e.x - e.vx, e.z - e.vz, e.shooter === 'player')) return;
        if (e.punch) { const l = Math.hypot(e.vx, e.vz) || 1; mob.body.vx += e.vx / l * 6 * e.punch; mob.body.vz += e.vz / l * 6 * e.punch; }
        if (e.fire && !mob.def.fireproof) mob.fire = 5;
        if (pt) this.effectMob(mob, pt[0], pt[2], Math.round(pt[1] / 8), 1);
        if (e.shooter === 'player') {
          if (mob.hp <= 0 && !mob.def.dragon) g.addXp(mob.def.xp || (mob.def.hostile ? 5 : 1 + Math.floor(Math.random() * 3)));
          if (g.pvp) g.pvp.onHitConfirmed(mob.eid, e.crit);
        }
        // Скелет, попавший в другое существо, злит его
        if (e.shooter && e.shooter !== 'player' && mob.def.neutral) mob.angry = 30;
      } else if (player) {
        const who = e.shooter && e.shooter !== 'player' ? e.shooter.def.kill : 'Застрелен';
        g.damagePlayer(dmg, e.x - e.vx, e.z - e.vz, who);
        if (e.fire) g.setOnFire(5);
        if (pt && g.gamemode === 0) g.addEffect(pt[0], pt[2], Math.round(pt[1] / 8));
      }
    }

    // ---------- Огненные шары ифрита и гаста ----------
    shootFireball(x, y, z, dx, dy, dz, big, shooter) {
      const eid = this.nextId++;
      const l = Math.hypot(dx, dy, dz) || 1, sp = big ? 16 : 22;
      const e = { kind: 'fireball', eid, x, y, z, vx: dx / l * sp, vy: dy / l * sp, vz: dz / l * sp, big, shooter, age: 0, item: { id: 385, data: 0, count: 1 } };
      this.list.set(eid, e);
      MC.Sound.event('ignite', x, y, z);
      return e;
    }

    updateFireball(e, dt) {
      const g = this.game;
      e.age += dt;
      if (e.age > 10 || !this.world.isLoaded(Math.floor(e.x), Math.floor(e.z))) { this.list.delete(e.eid); return; }
      if (g.particles.flame) g.particles.flame(e.x, e.y, e.z, e.skull || Math.random() < 0.3 ? 'smoke' : 'flame');
      const steps = 4;
      for (let i = 0; i < steps; i++) {
        const nx = e.x + e.vx * dt / steps, ny = e.y + e.vy * dt / steps, nz = e.z + e.vz * dt / steps;
        // Отбитый ударом шар гаста летит обратно и попадает в гаста
        const mob = this.mobAt(nx, ny, nz, e.big ? 0.5 : 0.2, e.reflected ? null : e.shooter);
        const hitP = !e.reflected && this.playerAt(nx, ny, nz, e.big ? 0.5 : 0.2);
        if (mob || hitP || this.solidAt(nx, ny, nz)) {
          this.list.delete(e.eid);
          if (e.breath) { this.breathCloud(e.x, Math.floor(e.y + 0.01), e.z); return; }
          // Череп иссушителя: 8 урона и иссушение на 10 секунд, небольшой взрыв
          if (e.skull) {
            if (hitP) { g.damagePlayer(8, e.x, e.z, 'Убит черепом иссушителя'); if (g.gamemode === 0) g.addEffect(MC.Effects.E.WITHER, 1, 10); }
            else if (mob && !MC.Effects.UNDEAD.has(mob.type)) { this.hurtMob(mob, 8, e.x, e.z, false); this.effectMob(mob, MC.Effects.E.WITHER, 1, 10, 1); }
            this.explode(e.x, e.y, e.z, e.blue ? 1.5 : 1, false, 'Взорван черепом иссушителя', e.shooter);
            return;
          }
          if (e.big) { this.explode(e.x, e.y, e.z, 1, true, e.shooter ? e.shooter.def.kill : 'Взорван'); if (mob && mob.type === 41 && e.reflected) { mob.invuln = 0; this.hurtMob(mob, 1000, e.x, e.z, true); g.addXp(5); } return; }
          if (hitP) { g.damagePlayer(5, e.x, e.z, e.shooter ? e.shooter.def.kill : 'Сгорел'); g.setOnFire(5); }
          else if (mob) { if (!mob.def.fireproof) { this.hurtMob(mob, 5, e.x, e.z, false); mob.fire = 5; } }
          else this.igniteAt(Math.floor(e.x), Math.floor(e.y), Math.floor(e.z));
          return;
        }
        e.x = nx; e.y = ny; e.z = nz;
      }
    }

    shootSkull(m, x, y, z, tx, ty, tz) {
      const e = this.shootFireball(x, y, z, tx - x, ty - y, tz - z, false, m);
      e.skull = true;
      e.blue = Math.random() < 0.08;
      e.item = { id: 397, data: 1, count: 1 };
      e.vx *= 0.7; e.vy *= 0.7; e.vz *= 0.7;
      MC.Sound.play('mob.wither.shoot', [x, y, z], 1, 1);
      return e;
    }

    // Огонь на месте попадания (в воздухе над твёрдым блоком)
    igniteAt(x, y, z) {
      for (const [dx, dy, dz] of [[0, 0, 0], [0, 1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]]) {
        const X = x + dx, Y = y + dy, Z = z + dz;
        if (this.game.portals.addFire(X, Y, Z)) return;
      }
    }

    // Удар по огненному шару отбивает его по направлению взгляда
    reflectFireball(eid) {
      const e = this.list.get(eid);
      if (!e || e.kind !== 'fireball') return false;
      const d = this.game.player.lookDir();
      const sp = Math.hypot(e.vx, e.vy, e.vz);
      e.vx = d[0] * sp; e.vy = d[1] * sp; e.vz = d[2] * sp;
      e.reflected = true;
      e.age = 0;
      return true;
    }

    // Прямая видимость между точками (через блоки не стреляют)
    sees(x0, y0, z0, x1, y1, z1) {
      const d = Math.hypot(x1 - x0, y1 - y0, z1 - z0);
      const n = Math.ceil(d / 0.5);
      for (let i = 1; i < n; i++) {
        const t = i / n;
        const id = this.world.getId(Math.floor(x0 + (x1 - x0) * t), Math.floor(y0 + (y1 - y0) * t), Math.floor(z0 + (z1 - z0) * t));
        if (id && Blocks.list[id].opaque) return false;
      }
      return true;
    }

    // ---------- Око Края: летит к ближайшей крепости, затем падает (80 %) или разбивается ----------
    throwEye(x, y, z, tx, tz, ty) {
      const eid = this.nextId++;
      this.list.set(eid, { kind: 'eye', eid, x, y, z, sx: x, sz: z, tx, tz, ty, age: 0, item: { id: 381, data: 0, count: 1 } });
      MC.Sound.play('random.bow', { x, y, z }, 0.5, 0.5);
    }

    updateEye(e, dt) {
      const g = this.game;
      e.age += dt;
      // Подъём и движение к цели (не дальше 12 блоков), как в Minecraft
      const k = Math.min(1, e.age / 2);
      e.x = e.sx + (e.tx - e.sx) * k;
      e.z = e.sz + (e.tz - e.sz) * k;
      e.y += (e.ty - e.y) * Math.min(1, dt * 1.5);
      if (g.particles.swirl && Math.random() < 0.6) g.particles.swirl(e.x, e.y, e.z, [0.6, 0.2, 0.8], 0.05, 0.2);
      if (e.age < 2.6) return;
      this.list.delete(e.eid);
      if (Math.random() < 0.8) this.spawnItem({ id: 381, data: 0, count: 1 }, e.x, e.y, e.z, 0, 1, 0, 0.5);
      else { MC.Sound.play('random.glass', { x: e.x, y: e.y, z: e.z }, 1, 1); if (g.particles.potion) g.particles.potion(e.x, e.y, e.z, [0.3, 0.6, 0.4], 1); }
    }

    // ---------- Кристаллы Края ----------
    spawnCrystal(x, y, z, o) {
      const eid = this.nextId++;
      const c = Object.assign({ kind: 'crystal', eid, x, y, z, age: Math.random() * 10 }, o || {});
      this.list.set(eid, c);
      return c;
    }

    crystalAt(x, y, z, pad) {
      for (const c of this.list.values()) {
        if (c.kind !== 'crystal') continue;
        if (Math.abs(x - c.x) < 1 + pad && Math.abs(z - c.z) < 1 + pad && y > c.y - pad && y < c.y + 2 + pad) return c;
      }
      return null;
    }

    // Кристалл взрывается от любого урона; если он лечил дракона, дракон получает 10 урона
    destroyCrystal(c) {
      if (!this.list.has(c.eid)) return;
      this.list.delete(c.eid);
      for (const d of this.list.values()) {
        if (d.kind === 'mob' && d.def.dragon && !d.dead && d.healing === c.eid) {
          d.healing = null;
          d.invuln = 0;
          this.hurtMob(d, 10, c.x, c.z, true);
        }
      }
      if (this.game.portals) this.game.portals.crystalDestroyed(c);
      this.explode(c.x, c.y + 1, c.z, 6, false, 'Взорван кристаллом Края');
    }

    // ---------- Эндермен: телепортация ----------
    teleportEnder(m) {
      const w = this.world, b = m.body;
      for (let t = 0; t < 16; t++) {
        const x = Math.floor(b.x + (Math.random() - 0.5) * 32), z = Math.floor(b.z + (Math.random() - 0.5) * 32);
        if (!w.isLoaded(x, z)) continue;
        let y = Math.floor(b.y + (Math.random() - 0.5) * 32);
        y = Math.max(1, Math.min(250, y));
        while (y > 1 && w.getId(x, y - 1, z) === 0) y--;
        const below = w.getId(x, y - 1, z);
        if (!below || !Blocks.list[below].solid || Blocks.list[below].liquid) continue;
        if (w.getId(x, y, z) || w.getId(x, y + 1, z) || w.getId(x, y + 2, z)) continue;
        if (this.game.particles.swirl) for (let i = 0; i < 12; i++) this.game.particles.swirl(b.x + (Math.random() - 0.5), b.y + Math.random() * 2.8, b.z + (Math.random() - 0.5), [0.6, 0.2, 0.8], 0.05, 0.5);
        MC.Sound.play('mob.endermen.portal', [b.x, b.y, b.z], 1, 1);
        b.x = x + 0.5; b.y = y; b.z = z + 0.5;
        b.vx = b.vy = b.vz = 0;
        MC.Sound.play('mob.endermen.portal', [b.x, b.y, b.z], 1, 1);
        return true;
      }
      return false;
    }

    // ---------- Снаряд шалкера: медленно летит за игроком, даёт левитацию ----------
    shootBullet(m) {
      const b = m.body, eid = this.nextId++;
      this.list.set(eid, { kind: 'bullet', eid, x: b.x, y: b.y + 0.6, z: b.z, vx: 0, vy: 3, vz: 0, age: 0, shooter: m });
      MC.Sound.play('mob.shulker.shoot', [b.x, b.y, b.z], 1, 1);
    }

    updateBullet(e, dt) {
      const g = this.game, p = g.player;
      e.age += dt;
      if (e.age > 10 || !this.world.isLoaded(Math.floor(e.x), Math.floor(e.z))) { this.list.delete(e.eid); return; }
      const tx = p.x - e.x, ty = p.y + 0.9 - e.y, tz = p.z - e.z;
      const l = Math.hypot(tx, ty, tz) || 1;
      const k = Math.min(1, dt * 2);
      e.vx += (tx / l * 5 - e.vx) * k; e.vy += (ty / l * 5 - e.vy) * k; e.vz += (tz / l * 5 - e.vz) * k;
      if (g.particles.swirl && Math.random() < 0.4) g.particles.swirl(e.x, e.y, e.z, [0.9, 0.9, 0.7], 0.02, 0.3);
      const nx = e.x + e.vx * dt, ny = e.y + e.vy * dt, nz = e.z + e.vz * dt;
      if (!g.dead && this.playerAt(nx, ny, nz, 0.25)) {
        this.list.delete(e.eid);
        g.damagePlayer(4, e.x, e.z, DEFS[54].kill);
        if (g.gamemode === 0) g.addEffect(MC.Effects.E.LEVITATION, 0, 10);
        return;
      }
      if (this.solidAt(nx, ny, nz)) { this.list.delete(e.eid); if (g.particles.explosion) g.particles.explosion(e.x, e.y, e.z, 0.3); return; }
      e.x = nx; e.y = ny; e.z = nz;
    }

    // ---------- Рассадники (блок 52): существо по data блока появляется рядом с игроком ----------
    scanSpawners(cx, cz) {
      const ch = this.world.getChunk(cx, cz);
      if (!ch) return;
      if (!this.spawners) this.spawners = new Map();
      for (let sy = 0; sy < 16; sy++) {
        const sec = ch.sections[sy];
        if (!sec) continue;
        let i = sec.ids.indexOf(52);
        while (i >= 0) {
          const x = cx * 16 + (i >> 8), z = cz * 16 + ((i >> 4) & 15), y = sy * 16 + (i & 15);
          const k = x + ',' + y + ',' + z;
          if (!this.spawners.has(k)) this.spawners.set(k, { x, y, z, t: 2 + Math.random() * 8 });
          i = sec.ids.indexOf(52, i + 1);
        }
        let j = sec.ids.indexOf(138);
        while (j >= 0) {
          this.trackBeacon(cx * 16 + (j >> 8), sy * 16 + (j & 15), cz * 16 + ((j >> 4) & 15));
          j = sec.ids.indexOf(138, j + 1);
        }
      }
    }

    trackBeacon(x, y, z) {
      if (!this.beacons) this.beacons = new Map();
      this.beacons.set(x + ',' + y + ',' + z, { x, y, z });
    }

    // Уровень пирамиды маяка: 0–4 полных слоя из железа, золота, алмазов или изумрудов
    beaconLevel(x, y, z) {
      const w = this.world;
      let lv = 0;
      for (let k = 1; k <= 4; k++) {
        for (let dx = -k; dx <= k; dx++) for (let dz = -k; dz <= k; dz++) if (!BEACON_BASE.has(w.getId(x + dx, y - k, z + dz))) return lv;
        lv = k;
      }
      return lv;
    }

    // Маяк: раз в 4 секунды даёт эффекты игроку в радиусе 10 + 10 × уровень, если над ним открытое небо.
    // Эффекты по уровню пирамиды (без меню выбора): 1 — скорость, 2 — + спешка, 3 — + сопротивление, 4 — + сила и регенерация
    tickBeacons() {
      if (!this.beacons || !this.beacons.size) return;
      const g = this.game, w = this.world, p = g.player, E = MC.Effects.E;
      for (const [k, b] of this.beacons) {
        if (!w.isLoaded(b.x, b.z) || w.getId(b.x, b.y, b.z) !== 138) { this.beacons.delete(k); continue; }
        b.level = this.beaconLevel(b.x, b.y, b.z);
        b.open = true;
        for (let y = b.y + 1; y < 256; y++) {
          const id = w.getId(b.x, y, b.z);
          if (id && Blocks.list[id] && Blocks.list[id].opaque !== false && id !== 20 && id !== 95 && id !== 102 && id !== 160) { b.open = false; break; }
        }
        if (!b.level || !b.open || g.dead) continue;
        const r = 10 + 10 * b.level;
        if (Math.abs(p.x - b.x - 0.5) > r || Math.abs(p.z - b.z - 0.5) > r) continue;
        g.addEffect(E.SPEED, 0, 11);
        if (b.level >= 2) g.addEffect(E.HASTE, 0, 11);
        if (b.level >= 3) g.addEffect(E.RESISTANCE, 0, 11);
        if (b.level >= 4) { g.addEffect(E.STRENGTH, 0, 11); g.addEffect(E.REGEN, 0, 11); }
      }
    }

    beaconBeams() {
      const out = [];
      if (this.beacons) for (const b of this.beacons.values()) if (b.level && b.open) out.push(b);
      return out;
    }

    tickSpawners() {
      if (!this.spawners || !this.spawners.size) return;
      const g = this.game, w = this.world, p = g.player;
      for (const [k, sp] of this.spawners) {
        if (!w.isLoaded(sp.x, sp.z) || w.getId(sp.x, sp.y, sp.z) !== 52) { this.spawners.delete(k); continue; }
        if (Math.hypot(sp.x + 0.5 - p.x, sp.y - p.y, sp.z + 0.5 - p.z) > 16) continue;
        if (g.particles.flame && Math.random() < 0.7) g.particles.flame(sp.x + Math.random(), sp.y + Math.random(), sp.z + Math.random(), 'smoke');
        sp.t -= 1;
        if (sp.t > 0) continue;
        // Как в Minecraft: раз в 10–40 секунд до 4 существ, если рядом их меньше 6
        sp.t = 10 + Math.random() * 30;
        const type = SPAWNER_TYPES[w.getData(sp.x, sp.y, sp.z) & 7] || 32;
        let near = 0;
        for (const m of this.list.values()) if (m.kind === 'mob' && m.type === type && Math.abs(m.body.x - sp.x) < 9 && Math.abs(m.body.z - sp.z) < 9 && Math.abs(m.body.y - sp.y) < 5) near++;
        if (near >= 6) continue;
        let made = 0;
        for (let t = 0; t < 12 && made < 4; t++) {
          const x = sp.x + rnd(-4, 4), y = sp.y + rnd(-1, 1), z = sp.z + rnd(-4, 4);
          if (w.getId(x, y, z) || w.getId(x, y + 1, z)) continue;
          const fly = DEFS[type] && DEFS[type].fly;
          if (!fly && !(Blocks.list[w.getId(x, y - 1, z)] || {}).solid) continue;
          const m = this.spawnMob(type, x + 0.5, y, z + 0.5);
          if (m) { m.angry = DEFS[type].neutral ? 0 : 0; made++; if (g.particles.flame) g.particles.flame(x + 0.5, y + 0.5, z + 0.5, 'flame'); }
        }
      }
    }

    // Существа, привязанные к месту (шалкеры в городах Края): появляются, когда игрок рядом, убитые не возвращаются
    tickFixedSpawns() {
      const g = this.game, rec = g.record;
      if (!rec || !rec.fixedSpawns || !rec.fixedSpawns.length) return;
      const p = g.player, killed = rec.killedSpawns || [];
      const alive = new Set();
      for (const m of this.list.values()) if (m.kind === 'mob' && m.spawnId) alive.add(m.spawnId);
      for (const f of rec.fixedSpawns) {
        if (f.d !== (g.dimension || 0) || alive.has(f.id) || killed.indexOf(f.id) >= 0) continue;
        if (Math.hypot(f.x - p.x, f.y - p.y, f.z - p.z) > 40 || !this.world.isLoaded(f.x, f.z)) continue;
        const m = this.spawnMob(f.type, f.x + 0.5, f.y, f.z + 0.5);
        if (m) { m.spawnId = f.id; m.egg = true; m.body.yaw = 0; }
      }
    }

    // ---------- Дракон Края ----------
    // Фазы как в Minecraft: кружит над столбами, обстреливает, таранит, садится на портал и дышит, взлетает.
    // Кристаллы на столбах лечат его, пока он рядом; ломает всё, кроме камня Края, обсидиана, бедрока и решёток
    updateDragon(m, dt) {
      const g = this.game, p = g.player, b = m.body, def = m.def;
      m.hurt = Math.max(0, m.hurt - dt);
      m.invuln = Math.max(0, m.invuln - dt);
      m.wingCd = Math.max(0, (m.wingCd || 0) - dt);
      if (m.dead) {
        // Смерть: 6 секунд поднимается и светится, затем взрыв
        m.dead -= dt;
        m.healing = null;
        b.y += dt * 1.5;
        b.yaw += dt * 30;
        if (g.particles.explosion && Math.random() < 0.35) g.particles.explosion(b.x + (Math.random() - 0.5) * 8, b.y + Math.random() * 4, b.z + (Math.random() - 0.5) * 8, 1);
        if (g.particles.swirl) for (let i = 0; i < 3; i++) g.particles.swirl(b.x + (Math.random() - 0.5) * 6, b.y + Math.random() * 3, b.z + (Math.random() - 0.5) * 6, [1, 0.85, 1], 0.4, 1);
        if (m.dead <= 0) {
          this.list.delete(m.eid);
          if (g.particles.explosion) g.particles.explosion(b.x, b.y + 2, b.z, 6);
          MC.Sound.event('explode', b.x, b.y, b.z);
          if (g.portals) g.portals.dragonKilled();
        }
        return;
      }
      if (!m.phase) { m.phase = 'hold'; m.ang = Math.atan2(b.z, b.x); m.timer = 8; m.dir = 1; }
      const active = !g.dead && g.survival() && g.dimension === 2 && Math.hypot(p.x, p.z) < 180;
      // Лечение от ближайшего кристалла в радиусе 32 блоков
      m.healT = (m.healT || 0) - dt;
      let healer = null, hd = 32;
      for (const c of this.list.values()) {
        if (c.kind !== 'crystal' || c.placed) continue;
        const d = Math.hypot(c.x - b.x, c.y - b.y, c.z - b.z);
        if (d < hd) { hd = d; healer = c; }
      }
      m.healing = healer ? healer.eid : null;
      if (healer && m.healT <= 0 && m.hp < def.hp) { m.healT = 0.5; m.hp = Math.min(def.hp, m.hp + 1); if (g.portals) g.portals.dragonHurt(m); }
      let crystals = 0;
      for (const c of this.list.values()) if (c.kind === 'crystal' && !c.placed) crystals++;
      let tx = b.x, ty = b.y, tz = b.z, sp = 14;
      const toP = Math.hypot(p.x - b.x, p.y - b.y, p.z - b.z);
      const choose = () => {
        m.timer = 6 + Math.random() * 8;
        if (!active) { m.phase = 'hold'; return; }
        const r = Math.random();
        // Чем меньше кристаллов, тем чаще садится (в Minecraft — шанс 1 из (3 + кристаллы))
        if (r < 1 / (3 + crystals)) { m.phase = 'land'; m.landStep = 0; }
        else if (r < 0.65) { m.phase = 'strafe'; m.shotDone = false; m.strafeT = 10; }
        else { m.phase = 'charge'; m.chargeT = 7; }
      };
      if (m.phase === 'hold') {
        m.ang += dt * 0.32 * m.dir;
        const R = 52 + Math.sin(m.ang * 3) * 10;
        tx = Math.cos(m.ang) * R; tz = Math.sin(m.ang) * R; ty = 80 + Math.sin(m.ang * 2) * 7;
        m.timer -= dt;
        if (m.timer <= 0) { if (Math.random() < 0.15) m.dir = -m.dir; choose(); }
      } else if (m.phase === 'strafe') {
        // Подлёт на расстояние выстрела и огненный шар с дыханием
        tx = p.x; ty = p.y + 12; tz = p.z; sp = 16;
        m.strafeT -= dt;
        if (!active || m.strafeT <= 0) { m.phase = 'hold'; m.timer = 6; }
        else if (!m.shotDone && toP < 48 && this.sees(b.x, b.y + 2, b.z, p.x, p.y + 1.5, p.z)) {
          m.shotDone = true;
          this.shootFireball(b.x, b.y, b.z, p.x - b.x, p.y + 0.5 - b.y, p.z - b.z, false, m).breath = true;
          m.phase = 'hold'; m.timer = 5 + Math.random() * 5;
        }
      } else if (m.phase === 'charge') {
        tx = p.x; ty = p.y + 1; tz = p.z; sp = 22;
        m.chargeT -= dt;
        if (!active || m.chargeT <= 0) { m.phase = 'hold'; m.timer = 6; }
      } else if (m.phase === 'land') {
        // Сначала над порталом, затем вниз на столб
        if (m.landStep === 0) { tx = 0; ty = 76; tz = 0; sp = 14; if (Math.hypot(b.x, b.y - 76, b.z) < 3) m.landStep = 1; }
        else { tx = 0; ty = 65; tz = 0; sp = 6; if (Math.hypot(b.x, b.y - 65, b.z) < 0.8) { m.phase = 'perch'; m.perchT = 9 + Math.random() * 4; m.breathT = 1.5; m.damageTaken = 0; } }
      } else if (m.phase === 'perch') {
        // Сидит на портале, поворачивается к игроку и дышит фиолетовым пламенем
        tx = 0; ty = 65; tz = 0; sp = 2;
        b.yaw = yawTo(p.x - b.x, p.z - b.z);
        m.perchT -= dt;
        m.breathT -= dt;
        if (m.breathT <= 0 && active) {
          m.breathT = 3.5;
          const yr = b.yaw * Math.PI / 180, fx = -Math.sin(yr), fz = Math.cos(yr);
          for (let i = 0; i < 3; i++) this.breathCloud(fx * (6 + i * 3), 64, fz * (6 + i * 3));
          MC.Sound.play('mob.enderdragon.growl', [b.x, b.y, b.z], 1, 1);
        }
        // Улетает через 9–13 секунд или после 25 урона
        if (m.perchT <= 0 || (m.damageTaken || 0) >= 25 || !active && m.perchT < 6) { m.phase = 'takeoff'; }
      } else if (m.phase === 'takeoff') {
        tx = b.x * 1.5 + 10; ty = 90; tz = b.z * 1.5 + 10; sp = 10;
        if (b.y > 85) { m.phase = 'hold'; m.ang = Math.atan2(b.z, b.x); m.timer = 8; }
      }
      const dx = tx - b.x, dy = ty - b.y, dz = tz - b.z;
      const l = Math.hypot(dx, dy, dz) || 1;
      // Плавный разворот: скорость меняется постепенно, а не мгновенно
      const want = Math.min(sp, l / Math.max(dt, 0.001));
      const k = Math.min(1, dt * (m.phase === 'perch' ? 6 : 1.6));
      m.vx = (m.vx || 0) + (dx / l * want - (m.vx || 0)) * k;
      m.vy = (m.vy || 0) + (dy / l * want - (m.vy || 0)) * k;
      m.vz = (m.vz || 0) + (dz / l * want - (m.vz || 0)) * k;
      b.x += m.vx * dt; b.y += m.vy * dt; b.z += m.vz * dt;
      if (m.phase !== 'perch' && Math.hypot(m.vx, m.vz) > 0.5) b.yaw = yawTo(m.vx, m.vz);
      b.walkDist += Math.hypot(m.vx, m.vy, m.vz) * dt;
      // Удар крыльями и головой: отбрасывает и ранит
      if (active && m.wingCd <= 0) {
        const yr = b.yaw * Math.PI / 180, hx = b.x - Math.sin(yr) * 6, hz = b.z + Math.cos(yr) * 6;
        const head = Math.hypot(p.x - hx, p.z - hz) < 2.5 && Math.abs(p.y - b.y) < 3;
        const body = Math.hypot(p.x - b.x, p.z - b.z) < 4.5 && p.y > b.y - 2 && p.y < b.y + 3;
        if (head || (body && m.phase !== 'perch')) {
          m.wingCd = 0.5;
          g.damagePlayer(head ? def.damage : 5, b.x, b.z, def.kill);
          const ox = p.x - b.x, oz = p.z - b.z, ol = Math.hypot(ox, oz) || 1;
          p.vx += ox / ol * 12; p.vz += oz / ol * 12; p.vy = Math.max(p.vy, 6);
          if (m.phase === 'charge') { m.phase = 'hold'; m.timer = 6; }
        }
      }
      // Блоки на пути дракона разрушаются
      if (m.phase !== 'perch' && m.phase !== 'land') this.dragonSmash(b);
    }

    // Части дракона как в Minecraft: голова получает полный урон, тело, крылья и хвост — четверть + 1
    dragonParts(m) {
      const b = m.body, yr = b.yaw * Math.PI / 180;
      const fx = -Math.sin(yr), fz = Math.cos(yr), sx = fz, sz = -fx;
      return [
        { part: 'head', x: b.x + fx * 6, y: b.y + 1, z: b.z + fz * 6, w: 2, h: 2 },
        { part: 'body', x: b.x, y: b.y, z: b.z, w: 5, h: 3 },
        { part: 'wing', x: b.x + sx * 4.5, y: b.y + 1.5, z: b.z + sz * 4.5, w: 4, h: 1.5 },
        { part: 'wing', x: b.x - sx * 4.5, y: b.y + 1.5, z: b.z - sz * 4.5, w: 4, h: 1.5 },
        { part: 'tail', x: b.x - fx * 4.5, y: b.y + 0.5, z: b.z - fz * 4.5, w: 2, h: 2 },
        { part: 'tail', x: b.x - fx * 7, y: b.y + 0.5, z: b.z - fz * 7, w: 2, h: 2 }
      ];
    }

    // ---------- Иссушитель ----------
    // Призыв: Т из 4 блоков песка душ и 3 черепа скелета-иссушителя сверху (последний ставится игроком)
    trySummonWither(x, y, z) {
      const w = this.world, g = this.game;
      const skull = (X, Y, Z) => w.getId(X, Y, Z) === 144 && g.skullType(X, Y, Z) === 1;
      for (const [ax, az] of [[1, 0], [0, 1]]) {
        for (let off = -1; off <= 1; off++) {
          const cx = x - ax * off, cz = z - az * off;
          const cy = y - 1;
          const row = [-1, 0, 1].map((k) => [cx + ax * k, cy, cz + az * k]);
          if (!row.every(([X, Y, Z]) => w.getId(X, Y, Z) === 88)) continue;
          if (w.getId(cx, cy - 1, cz) !== 88) continue;
          if (!row.every(([X, Y, Z]) => skull(X, Y + 1, Z))) continue;
          // Под руками Т должно быть пусто, как в Minecraft
          if (w.getId(cx + ax, cy - 1, cz + az) === 88 || w.getId(cx - ax, cy - 1, cz - az) === 88) continue;
          for (const [X, Y, Z] of row) { w.setBlock(X, Y, Z, 0, 0); w.setBlock(X, Y + 1, Z, 0, 0); g.forgetSkull(X, Y + 1, Z); }
          w.setBlock(cx, cy - 1, cz, 0, 0);
          const m = this.spawnMob(52, cx + 0.5, cy - 1, cz + 0.5);
          if (!m) return false;
          m.egg = true;
          m.spawnT = 10;
          m.hp = 1;
          this.bossBar(m);
          MC.Sound.play('mob.wither.spawn', null, 1, 1);
          return true;
        }
      }
      return false;
    }

    updateWither(m, dt) {
      const g = this.game, p = g.player, b = m.body, def = m.def, w = this.world;
      m.hurt = Math.max(0, m.hurt - dt);
      m.invuln = Math.max(0, m.invuln - dt);
      m.shootCd = (m.shootCd === undefined ? 2 : m.shootCd) - dt;
      m.breakCd = Math.max(0, (m.breakCd || 0) - dt);
      if (m.dead) {
        m.dead -= dt;
        b.y += dt * 0.5;
        if (g.particles.explosion && Math.random() < 0.3) g.particles.explosion(b.x, b.y + 2, b.z, 1);
        if (m.dead <= 0) { this.list.delete(m.eid); this.bossBar(m); }
        return;
      }
      // Появление: 10 секунд набирает здоровье и неуязвим, затем большой взрыв
      if (m.spawnT > 0) {
        m.spawnT -= dt;
        m.hp = Math.max(1, def.hp * (1 - m.spawnT / 10));
        b.yaw += dt * 60;
        if (g.particles.swirl && Math.random() < 0.6) g.particles.swirl(b.x + (Math.random() - 0.5) * 2, b.y + Math.random() * 3.5, b.z + (Math.random() - 0.5) * 2, [0.3, 0.3, 0.5], 0.2, 0.8);
        if (m.spawnT <= 0) {
          m.hp = def.hp;
          this.explode(b.x, b.y + 1.5, b.z, 7, false, 'Взорван иссушителем', m);
          MC.Sound.play('mob.wither.spawn', [b.x, b.y, b.z], 1, 0.8);
        }
        this.bossBar(m);
        return;
      }
      // Восстанавливает 1 здоровье в секунду
      m.regenT = (m.regenT || 0) - dt;
      if (m.regenT <= 0) { m.regenT = 1; if (m.hp < def.hp) { m.hp = Math.min(def.hp, m.hp + 1); this.bossBar(m); } }
      if (m.effects && m.effects.size) m.effects.tick(dt, { heal: (n) => { m.hp = Math.min(def.hp, m.hp + n); }, hurt: (n) => { m.invuln = 0; this.hurtMob(m, n, b.x, b.z, false); } });
      // Цель: игрок в выживании ближе 64 блоков, иначе ближайшее живое (не нежить) существо
      let tx = null, ty = 0, tz = 0, target = null;
      const pd = Math.hypot(p.x - b.x, p.y - b.y, p.z - b.z);
      if (!g.dead && g.survival() && pd < 64) { tx = p.x; ty = p.y + 1; tz = p.z; }
      else {
        let best = 32;
        for (const o of this.list.values()) {
          if (o.kind !== 'mob' || o === m || o.dead || MC.Effects.UNDEAD.has(o.type) || o.def.dragon) continue;
          const d = Math.hypot(o.body.x - b.x, o.body.y - b.y, o.body.z - b.z);
          if (d < best) { best = d; target = o; }
        }
        if (target) { tx = target.body.x; ty = target.body.y + 0.8; tz = target.body.z; }
      }
      const armored = m.hp <= def.hp / 2;
      let gx = b.x, gy = b.y, gz = b.z;
      if (tx !== null) {
        // Держится на расстоянии ~10 блоков, кружит вокруг цели; в броне опускается ниже
        m.orbit = (m.orbit || Math.random() * 6.28) + dt * 0.5;
        const R = armored ? 6 : 10;
        gx = tx + Math.cos(m.orbit) * R; gz = tz + Math.sin(m.orbit) * R;
        gy = ty + (armored ? 1 : 5);
        b.yaw = yawTo(tx - b.x, tz - b.z);
        if (m.shootCd <= 0 && this.sees(b.x, b.y + 3, b.z, tx, ty, tz)) {
          // Главная голова стреляет в цель, иногда залп из трёх голов
          const burst = Math.random() < 0.3;
          m.shootCd = armored ? 1.2 : 2;
          const yr = b.yaw * Math.PI / 180, sx = Math.cos(yr), sz = Math.sin(yr);
          this.shootSkull(m, b.x, b.y + 3.2, b.z, tx, ty, tz);
          if (burst) {
            this.shootSkull(m, b.x + sx * 1.3, b.y + 2.9, b.z + sz * 1.3, tx + (Math.random() - 0.5) * 3, ty, tz + (Math.random() - 0.5) * 3);
            this.shootSkull(m, b.x - sx * 1.3, b.y + 2.9, b.z - sz * 1.3, tx + (Math.random() - 0.5) * 3, ty, tz + (Math.random() - 0.5) * 3);
          }
        }
      } else {
        m.orbit = (m.orbit || 0) + dt * 0.3;
        gx = b.x + Math.cos(m.orbit) * 2; gz = b.z + Math.sin(m.orbit) * 2; gy = b.y;
      }
      const dx = gx - b.x, dy = gy - b.y, dz = gz - b.z, l = Math.hypot(dx, dy, dz) || 1;
      const sp = Math.min(8, l * 1.5);
      const k = Math.min(1, dt * 2);
      b.vx += (dx / l * sp - b.vx) * k; b.vy += (dy / l * sp - b.vy) * k; b.vz += (dz / l * sp - b.vz) * k;
      b.x += b.vx * dt; b.y += b.vy * dt; b.z += b.vz * dt;
      if (b.y < 2) b.y = 2;
      b.walkDist += Math.hypot(b.vx, b.vz) * dt;
      // Застрял в блоках или получил урон — ломает всё вокруг себя
      let stuck = false;
      for (let X = Math.floor(b.x - 0.5); X <= Math.floor(b.x + 0.5) && !stuck; X++) for (let Y = Math.floor(b.y); Y <= Math.floor(b.y + 3.4) && !stuck; Y++) for (let Z = Math.floor(b.z - 0.5); Z <= Math.floor(b.z + 0.5); Z++) {
        const id = w.getId(X, Y, Z);
        if (id && Blocks.list[id] && Blocks.list[id].solid) { stuck = true; break; }
      }
      if (stuck && m.breakCd <= 0) {
        m.breakCd = 1;
        let n = 0;
        for (let X = Math.floor(b.x) - 1; X <= Math.floor(b.x) + 1; X++) for (let Y = Math.floor(b.y); Y <= Math.floor(b.y) + 3; Y++) for (let Z = Math.floor(b.z) - 1; Z <= Math.floor(b.z) + 1; Z++) {
          const id = w.getId(X, Y, Z);
          if (!id || WITHER_PROOF.has(id) || (id >= 8 && id <= 11)) continue;
          g.removeBlockSP(X, Y, Z, true);
          n++;
        }
        if (n) MC.Sound.event('explode', b.x, b.y, b.z);
      }
      // Ближний бой: касание ранит и иссушает
      if (!g.dead && g.survival() && Math.hypot(p.x - b.x, p.z - b.z) < 1.2 && p.y > b.y - 1.8 && p.y < b.y + 3.5) {
        m.attackCd = Math.max(0, (m.attackCd || 0) - dt);
        if (m.attackCd <= 0) { m.attackCd = 1; g.damagePlayer(def.damage, b.x, b.z, def.kill); g.addEffect(MC.Effects.E.WITHER, 1, 10); }
      }
    }

    // Полоса здоровья босса сверху экрана (иссушитель; у дракона своя в js/dimensions.js)
    bossBar(m) {
      const g = this.game;
      if (!this.witherBars) this.witherBars = new Map();
      let bar = this.witherBars.get(m.eid);
      const alive = this.list.has(m.eid) && !m.dead;
      if (!alive) { if (bar) { bar.remove(); this.witherBars.delete(m.eid); } return; }
      if (!bar || !bar.isConnected) {
        bar = document.createElement('div');
        bar.className = 'bossbar wither';
        bar.innerHTML = '<div class="bossbar-name">Иссушитель</div><div class="bossbar-track"><div class="bossbar-fill"></div></div>';
        g.ui.hud.appendChild(bar);
        this.witherBars.set(m.eid, bar);
      }
      bar.querySelector('.bossbar-fill').style.width = (Math.max(0, m.hp) / m.def.hp * 100).toFixed(1) + '%';
      bar.classList.toggle('armored', m.hp <= m.def.hp / 2);
    }

    dragonSmash(b) {
      const w = this.world;
      let n = 0;
      for (let x = Math.floor(b.x - 3); x <= Math.floor(b.x + 3) && n < 24; x++) {
        for (let z = Math.floor(b.z - 3); z <= Math.floor(b.z + 3) && n < 24; z++) {
          for (let y = Math.floor(b.y); y <= Math.floor(b.y + 3) && n < 24; y++) {
            const id = w.getId(x, y, z);
            if (!id || DRAGON_PROOF.has(id)) continue;
            this.game.removeBlockSP(x, y, z, false);
            n++;
          }
        }
      }
    }

    // Облако драконьего дыхания: ранит, его можно набрать в пустую бутылку
    breathCloud(x, y, z) {
      const g = this.game;
      while (y > 1 && !this.solidAt(x, y - 0.5, z)) y--;
      const eid = this.nextId++;
      this.list.set(eid, { kind: 'cloud', eid, x, y, z, data: 23, r: 3, age: 0, life: 20, timer: 0.5, breath: true });
      if (g.particles.potion) g.particles.potion(x, y, z, [0.8, 0.3, 0.8], 3);
    }

    // Облако дыхания в пределах досягаемости по взгляду игрока
    breathAt(x, y, z, d, reach) {
      for (const e of this.list.values()) {
        if (e.kind !== 'cloud' || !e.breath) continue;
        for (let t = 0.5; t <= reach; t += 0.5) {
          const px = x + d[0] * t, py = y + d[1] * t, pz = z + d[2] * t;
          if (Math.hypot(px - e.x, pz - e.z) < e.r && py > e.y - 0.5 && py < e.y + 2) return e;
        }
      }
      return null;
    }

    solidAt(x, y, z) {
      const bx = Math.floor(x), by = Math.floor(y), bz = Math.floor(z);
      const id = this.world.getId(bx, by, bz);
      if (!id) return false;
      const boxes = Blocks.collisionBoxes(id, this.world.getData(bx, by, bz), this.world, bx, by, bz);
      if (!boxes) return false;
      return boxes.some((b) => y - by >= b[1] - 1e-4 && y - by < b[4] && x - bx >= b[0] && x - bx <= b[3] && z - bz >= b[2] && z - bz <= b[5]);
    }

    updateItem(e, dt) {
      e.age += dt;
      e.delay -= dt;
      if (e.age > 300) { this.list.delete(e.eid); return; }
      const w = this.world;
      if (!w.isLoaded(Math.floor(e.x), Math.floor(e.z))) return;
      const p0 = this.game.player;
      const near = Math.abs(e.x - p0.x) < 3 && Math.abs(e.z - p0.z) < 3 && Math.abs(e.y - p0.y) < 4;
      // Лежащий предмет «спит»: физика не считается, раз в секунду проверяется опора
      if (e.rest) {
        e.restCheck -= dt;
        if (e.restCheck > 0 && !near) return;
        e.restCheck = 1 + Math.random() * 0.5;
        if (this.solidAt(e.x, e.y - 0.05, e.z) && !this.solidAt(e.x, e.y + 0.1, e.z) && !this.liquidAt(e.x, e.y, e.z)) {
          if (!near) return;
        } else e.rest = false;
      }
      const inWater = (() => { const id = w.getId(Math.floor(e.x), Math.floor(e.y), Math.floor(e.z)); return id === 8 || id === 9; })();
      e.vy -= (inWater ? 4 : 20) * dt;
      if (inWater) e.vy = Math.max(e.vy, 1);
      const nx = e.x + e.vx * dt, nz = e.z + e.vz * dt, ny = e.y + e.vy * dt;
      if (!this.solidAt(nx, e.y + 0.05, e.z)) e.x = nx; else e.vx = 0;
      if (!this.solidAt(e.x, e.y + 0.05, nz)) e.z = nz; else e.vz = 0;
      if (e.vy < 0 && this.solidAt(e.x, ny, e.z)) {
        const by = Math.floor(ny);
        const id = w.getId(Math.floor(e.x), by, Math.floor(e.z));
        const boxes = Blocks.collisionBoxes(id, w.getData(Math.floor(e.x), by, Math.floor(e.z)), w, Math.floor(e.x), by, Math.floor(e.z)) || [[0, 0, 0, 1, 1, 1]];
        e.y = by + Math.max(...boxes.map((b) => b[4]));
        e.vy = 0;
        e.vx *= Math.pow(0.02, dt);
        e.vz *= Math.pow(0.02, dt);
        if (Math.abs(e.vx) < 0.05 && Math.abs(e.vz) < 0.05 && !inWater) { e.vx = 0; e.vz = 0; e.rest = true; e.restCheck = 1; }
      } else if (e.vy > 0 && this.solidAt(e.x, ny + 0.25, e.z)) {
        e.vy = 0;
      } else {
        e.y = ny;
      }
      if (this.solidAt(e.x, e.y + 0.1, e.z)) e.y = Math.floor(e.y + 0.1) + 1;
      // Подбор игроком
      const p = this.game.player;
      if (e.delay <= 0 && !this.game.dead && Math.abs(e.x - p.x) < 1.4 && Math.abs(e.z - p.z) < 1.4 && e.y > p.y - 0.8 && e.y < p.y + 2.2) {
        const left = this.game.sinv.add(e.item);
        if (left < e.item.count) this.game.onPickup(e.item);
        if (left <= 0) this.list.delete(e.eid); else e.item.count = left;
      }
    }

    // ---------- Существа ----------
    spawnMob(type, x, y, z) {
      const def = DEFS[type];
      if (!def) return null;
      const body = new MC.Player(this.world);
      body.canFly = false;
      body.x = x; body.y = y; body.z = z;
      body.yaw = Math.random() * 360;
      const eid = this.nextId++;
      const m = { kind: 'mob', eid, type, def, body, hp: def.hp, hurt: 0, invuln: 0, wander: 0, walking: false, flee: 0, angry: 0, attackCd: 0, fuse: 0, burn: 0, lava: 0, dead: 0 };
      this.list.set(eid, m);
      return m;
    }

    hurtMob(m, dmg, fromX, fromZ, byPlayer) {
      if (m.dead || m.invuln > 0) return false;
      if (m.def.witherBoss && m.spawnT > 0) return false;
      m.hp -= dmg;
      m.hurt = 0.4;
      m.invuln = 0.25;
      const dx = m.body.x - fromX, dz = m.body.z - fromZ;
      const l = Math.hypot(dx, dz) || 1;
      m.body.vx += dx / l * 7;
      m.body.vz += dz / l * 7;
      m.body.vy = 5;
      if (byPlayer) { m.flee = 4; m.angry = 30; }
      MC.Sound.entity(m.type, m.hp <= 0 ? 'death' : 'hurt', m.body.x, m.body.y + 1, m.body.z);
      if (m.def.dragon) { m.body.vx = m.body.vz = m.body.vy = 0; m.damageTaken = (m.damageTaken || 0) + dmg; }
      if (m.def.dragon && this.game.portals) this.game.portals.dragonHurt(m);
      if (m.def.witherBoss) { m.body.vx *= 0.2; m.body.vz *= 0.2; m.body.vy = 0; m.breakCd = 0; this.bossBar(m); }
      if (m.hp <= 0) {
        m.dead = m.def.dragon ? 6 : m.def.witherBoss ? 1.2 : 0.6;
        if (m.spawnId && this.game.record) { const k = this.game.record.killedSpawns || (this.game.record.killedSpawns = []); if (k.indexOf(m.spawnId) < 0) k.push(m.spawnId); }
        if (byPlayer) {
          for (const [id, data, a, b] of m.def.drops) {
            const n = rnd(a, b);
            if (n > 0) this.spawnItem({ id: m.burn > 0 && m.def.cooked && m.def.cooked[id] ? m.def.cooked[id] : id, data, count: n }, m.body.x, m.body.y + 0.5, m.body.z);
          }
          for (const [id, data, chance] of m.def.rare || []) if (Math.random() < chance) this.spawnItem({ id, data, count: 1 }, m.body.x, m.body.y + 0.5, m.body.z);
        }
      } else if (m.def.ender && Math.random() < 0.7) this.teleportEnder(m);
      return true;
    }

    // Яйцо призыва: существо появляется на блоке и не исчезает вдали от игрока
    spawnFromEgg(type, x, y, z) {
      const m = this.spawnMob(type, x, y, z);
      if (m) m.egg = true;
      return m;
    }

    canSpawnFromEgg(type) { return !!DEFS[type]; }

    hostileCount() {
      let h = 0, a = 0;
      for (const e of this.list.values()) if (e.kind === 'mob') { if (e.def.hostile && !e.def.neutral) h++; else a++; }
      return [a, h];
    }

    // Нижний мир: свинозомби, магмовые кубы и гасты на адском камне; ифриты и скелеты-иссушители — у крепостей.
    // Край: эндермены на камне Края
    trySpawnDim(dim) {
      const g = this.game, w = this.world, p = g.player;
      const hostile = this.hostileCount()[1] + this.neutralCount();
      if (hostile >= HOSTILE_CAP) return;
      const ang = Math.random() * Math.PI * 2, dist = 20 + Math.random() * 24;
      const x = Math.floor(p.x + Math.cos(ang) * dist), z = Math.floor(p.z + Math.sin(ang) * dist);
      if (!w.isLoaded(x, z)) return;
      if (dim === 2) {
        const top = w.height(x, z);
        if (top < 2 || w.getId(x, top - 1, z) !== 121 || w.getId(x, top, z) || w.getId(x, top + 1, z) || w.getId(x, top + 2, z)) return;
        this.spawnMob(38, x + 0.5, top, z + 0.5);
        return;
      }
      for (let t = 0; t < 8; t++) {
        const y = rnd(32, 118);
        if (w.getId(x, y, z) || w.getId(x, y + 1, z) || !Blocks.list[w.getId(x, y - 1, z)].opaque) continue;
        const ground = w.getId(x, y - 1, z);
        let fort = ground === 112;
        for (let d = 2; d < 7 && !fort; d++) fort = w.getId(x, y - d, z) === 112;
        const list = fort ? FORTRESS : NETHER;
        const type = list[rnd(0, list.length - 1)];
        // Гасту нужен простор 5×5×5
        if (type === 41) {
          let free = true;
          for (let dy = 0; dy < 5 && free; dy++) for (let dx = -2; dx <= 2 && free; dx += 2) for (let dz = -2; dz <= 2 && free; dz += 2) if (w.getId(x + dx, y + dy, z + dz)) free = false;
          if (!free) continue;
        }
        this.spawnMob(type, x + 0.5, y, z + 0.5);
        return;
      }
    }

    neutralCount() {
      let n = 0;
      for (const e of this.list.values()) if (e.kind === 'mob' && e.def.neutral && !e.egg) n++;
      return n;
    }

    trySpawn() {
      const g = this.game, w = this.world, p = g.player;
      if (g.dimension) { this.trySpawnDim(g.dimension); return; }
      const [passive, hostile] = this.hostileCount();
      const night = g.daylight() < 0.45;
      const ang = Math.random() * Math.PI * 2, dist = 24 + Math.random() * 20;
      const x = Math.floor(p.x + Math.cos(ang) * dist), z = Math.floor(p.z + Math.sin(ang) * dist);
      if (!w.isLoaded(x, z) || !w.isLoaded(x + 1, z + 1) || !w.isLoaded(x - 1, z - 1)) return;
      const top = w.height(x, z);
      if (Math.random() < 0.5 && passive < MOB_CAP) {
        if (w.getId(x, top - 1, z) !== 2 || w.getId(x, top, z) !== 0 || w.getId(x, top + 1, z) !== 0) return;
        const type = PASSIVE[rnd(0, PASSIVE.length - 1)];
        const n = rnd(1, 3);
        for (let i = 0; i < n; i++) this.spawnMob(type, x + 0.5 + i * 0.3, top, z + 0.5);
        return;
      }
      if (hostile >= HOSTILE_CAP) return;
      // Ночью — на поверхности, в любое время — в пещерах под землёй
      let y = -1;
      if (night && w.getId(x, top, z) === 0 && w.getId(x, top + 1, z) === 0 && Blocks.list[w.getId(x, top - 1, z)].solid && !Blocks.list[w.getId(x, top - 1, z)].liquid) y = top;
      else {
        for (let t = 0; t < 6 && y < 0; t++) {
          const yy = rnd(6, Math.max(7, top - 8));
          if (w.getId(x, yy, z) === 0 && w.getId(x, yy + 1, z) === 0 && Blocks.list[w.getId(x, yy - 1, z)].opaque) y = yy;
        }
      }
      if (y < 0 || this.litAt(x, y, z) > 7) return;
      // Эндермены редкие (как в Minecraft: примерно 1 из 40) и им нужно три блока высоты
      if (Math.random() < 0.025 + (night ? 0.02 : 0) && w.getId(x, y + 2, z) === 0) { this.spawnMob(38, x + 0.5, y, z + 0.5); return; }
      this.spawnMob(HOSTILE[rnd(0, HOSTILE.length - 1)], x + 0.5, y, z + 0.5);
    }

    // Уровень блочного света в точке (источник минус манхэттенское расстояние)
    litAt(x, y, z) {
      const w = this.world, L = Blocks.LIGHT;
      let best = 0;
      for (let dx = -14; dx <= 14; dx++) for (let dz = -14; dz <= 14; dz++) {
        const ax = Math.abs(dx) + Math.abs(dz);
        if (ax > 14) continue;
        for (let dy = -(14 - ax); dy <= 14 - ax; dy++) {
          const l = L[w.getId(x + dx, y + dy, z + dz)];
          if (l) { const v = l - ax - Math.abs(dy); if (v > best) best = v; }
        }
      }
      return best;
    }

    updateMob(m, dt) {
      const g = this.game, p = g.player, b = m.body, w = this.world;
      if (m.def.dragon) { this.updateDragon(m, dt); return; }
      if (m.def.witherBoss) { this.updateWither(m, dt); return; }
      if (!w.isLoaded(Math.floor(b.x), Math.floor(b.z))) { this.list.delete(m.eid); return; }
      m.hurt = Math.max(0, m.hurt - dt);
      m.invuln = Math.max(0, m.invuln - dt);
      m.attackCd = Math.max(0, m.attackCd - dt);
      m.flee = Math.max(0, m.flee - dt);
      m.angry = Math.max(0, m.angry - dt);
      if (m.dead) {
        m.dead -= dt;
        if (m.dead <= 0) this.list.delete(m.eid);
        return;
      }
      const def = m.def;
      // Эффекты зелий на существе: яд не убивает, иссушение и вред — убивают
      if (m.effects && m.effects.size) {
        m.effects.tick(dt, {
          heal: (n) => { m.hp = Math.min(def.hp, m.hp + n); },
          hurt: (n, why) => { if (why === 'poison' && m.hp <= 1) return; m.invuln = 0; this.hurtMob(m, n, b.x, b.z, false); m.body.vx = m.body.vz = 0; m.body.vy = 0; }
        });
        if (m.dead) return;
      }
      // Горение: 1 урон в секунду, вода тушит, огнестойкие не горят
      if (b.inLava && !def.fireproof) m.fire = Math.max(m.fire || 0, 15);
      if (m.fire > 0) {
        if (b.inWater || def.fireproof) m.fire = 0;
        else {
          m.fire -= dt;
          m.fireT = (m.fireT || 0) + dt;
          if (m.fireT >= 1) { m.fireT = 0; m.invuln = 0; this.hurtMob(m, 1, b.x, b.z, false); b.vx = b.vz = 0; b.vy = 0; m.burn = 1; }
          if (g.particles.flame && Math.random() < 0.3) g.particles.flame(b.x + (Math.random() - 0.5) * 0.6, b.y + Math.random() * 1.6, b.z + (Math.random() - 0.5) * 0.6);
          if (m.dead) return;
        }
      }
      const dx = p.x - b.x, dz = p.z - b.z, dy = p.y - b.y;
      const dist = Math.hypot(dx, dz, dy);
      if (def.hostile && !m.egg && dist > 72) { this.list.delete(m.eid); return; }
      const input = { forward: 0, strafe: 0, jump: b.inWater || b.inLava, sneak: false, sprint: false, autoJump: true };
      // Невидимого игрока замечают только вблизи
      const seeR = g.effects && g.effects.has(MC.Effects.E.INVISIBILITY) ? 4 : (def.ranged === 'ghastball' ? 40 : def.ender && m.angry > 0 ? 32 : 16);
      const target = !g.dead && g.survival() && dist < seeR;
      const night = g.daylight() < 0.6;
      const aggressive = def.hostile && target && (def.neutral ? m.angry > 0 : !def.dayNeutral || night || m.angry > 0);
      // Шалкер сидит на месте: открывает панцирь и стреляет, когда видит игрока
      if (def.shulker) {
        m.shootCd = (m.shootCd === undefined ? 1 + Math.random() * 2 : m.shootCd) - dt;
        if (target && this.sees(b.x, b.y + 0.5, b.z, p.x, p.y + 1.5, p.z)) {
          if (m.shootCd <= 0) { m.shootCd = 1 + Math.random() * 4.5; this.shootBullet(m); }
        }
        return;
      }
      // Эндермен: злится, если смотреть ему в глаза (тыква на голове спасает), боится воды, догоняет телепортацией
      if (def.ender) {
        if (b.inWater) { m.invuln = 0; this.hurtMob(m, 1, b.x, b.z, false); this.teleportEnder(m); return; }
        const pumpkin = g.armor && g.armor[0] && g.armor[0].id === 86;
        if (m.angry <= 0 && !pumpkin && !g.dead && g.survival() && dist < 64) {
          const d = p.lookDir();
          const vx = b.x - p.x, vy = b.y + 2.6 - p.eyeY, vz = b.z - p.z, l = Math.hypot(vx, vy, vz) || 1;
          if ((vx * d[0] + vy * d[1] + vz * d[2]) / l > 1 - 0.025 / l && this.sees(p.x, p.eyeY, p.z, b.x, b.y + 2.6, b.z)) {
            m.stare = (m.stare || 0) + dt;
            if (m.stare > 0.25) { m.angry = 30; MC.Sound.entity(m.type, 'hurt', b.x, b.y + 2, b.z); }
          } else m.stare = 0;
        }
        if (m.angry > 0 && dist > 10 && Math.random() < dt * 0.4) {
          // Телепорт к игроку
          const ob = { x: b.x, y: b.y, z: b.z };
          b.x = p.x; b.y = p.y; b.z = p.z;
          if (!this.teleportEnder(m)) { b.x = ob.x; b.y = ob.y; b.z = ob.z; }
        }
      }
      // Голоса существ время от времени
      m.ambient = (m.ambient === undefined ? Math.random() * 8 : m.ambient) - dt;
      if (m.ambient <= 0) {
        m.ambient = 6 + Math.random() * 10;
        if (dist < 16) MC.Sound.entity(m.type, 'ambient', b.x, b.y + 1, b.z);
      }
      if (def.fly) { b.canFly = true; b.flying = true; }
      const hd = Math.hypot(dx, dz);
      if (def.creeper && target && dist < 3.2) {
        if (m.fuse === 0) MC.Sound.entity(m.type, 'fuse', b.x, b.y + 1, b.z);
        m.fuse += dt;
        b.yaw = yawTo(dx, dz);
        if (m.fuse >= 1.5) { this.explode(b.x, b.y + 0.5, b.z, 3); this.list.delete(m.eid); return; }
      } else {
        m.fuse = Math.max(0, m.fuse - dt);
        if (aggressive && def.ranged) {
          // Стрелки держат дистанцию 6–12 блоков и стреляют, когда видят игрока
          b.yaw = yawTo(dx, dz);
          const ey = b.y + this.mobSize(m)[1] * 0.85;
          const see = this.sees(b.x, ey, b.z, p.x, p.y + 1.5, p.z);
          if (!see || hd > 12) input.forward = def.speed;
          else if (hd < 6 && !def.fly) input.forward = -def.speed * 0.8;
          if (def.fly) {
            // Летуны держатся выше игрока: ифрит на 2 блока, гаст на 6
            const want = p.y + (def.ranged === 'ghastball' ? 6 : 2);
            if (b.y < want - 0.5) input.jump = true; else if (b.y > want + 1) input.sneak = true;
          } else {
            m.strafeT = (m.strafeT || 0) - dt;
            if (m.strafeT <= 0) { m.strafeT = 1 + Math.random() * 2; m.strafeDir = Math.random() < 0.5 ? -0.5 : 0.5; }
            if (see && hd < 12) input.strafe = m.strafeDir * def.speed;
          }
          m.shootCd = (m.shootCd === undefined ? 1 : m.shootCd) - dt;
          if (see && hd < 16 && m.shootCd <= 0) this.mobShoot(m, ey);
        } else if (aggressive) {
          b.yaw = yawTo(dx, dz);
          if (def.hop) {
            // Слизни и магмовые кубы прыгают к игроку
            m.hopT = (m.hopT || 0) - dt;
            if (b.onGround && m.hopT <= 0) { m.hopT = 1 + Math.random(); b.vy = def.fireproof ? 10 : 8; const l = hd || 1; b.vx = dx / l * 5; b.vz = dz / l * 5; }
          } else input.forward = def.speed;
          if (def.fly) { if (b.y < p.y) input.jump = true; else if (b.y > p.y + 1) input.sneak = true; }
          if (def.damage && m.attackCd <= 0 && hd < 1.5 + this.mobSize(m)[0] / 2 - 0.3 && Math.abs(dy) < 1.6) {
            m.attackCd = 1;
            g.damagePlayer(def.damage, b.x, b.z, def.kill);
            if (def.wither && g.gamemode === 0) g.addEffect(MC.Effects.E.WITHER, 0, 10);
            if (m.fire > 0 && Math.random() < 0.3) g.setOnFire(3);
          }
        } else if (m.flee > 0) {
          // Направление бегства меняется раз в полсекунды, иначе модель дёргается каждый кадр
          m.fleeT = (m.fleeT || 0) - dt;
          if (m.fleeT <= 0) { m.fleeT = 0.5; m.fleeYaw = (Math.random() - 0.5) * 40; }
          b.yaw = yawTo(-dx, -dz) + m.fleeYaw;
          input.forward = Math.min(1, def.speed * 1.8);
        } else {
          m.wander -= dt;
          if (m.wander <= 0) {
            m.walking = Math.random() < 0.6;
            b.yaw = Math.random() * 360;
            m.wander = 1 + Math.random() * 4;
            m.flyDir = Math.random() < 0.5 ? (Math.random() < 0.5 ? 1 : -1) : 0;
          }
          if (m.walking) {
            if (def.hop) {
              m.hopT = (m.hopT || 0) - dt;
              if (b.onGround && m.hopT <= 0) { m.hopT = 1.5 + Math.random() * 2; b.vy = 7; const y = b.yaw * Math.PI / 180; b.vx = -Math.sin(y) * 3; b.vz = Math.cos(y) * 3; }
            } else input.forward = def.speed * 0.6;
          }
          if (def.fly) { if (m.flyDir > 0) input.jump = true; else if (m.flyDir < 0 && !b.onGround) input.sneak = true; }
        }
      }
      if (m.effects) b.speedMul = m.effects.speedMul();
      const fall = b.update(dt, input);
      if (fall > 3 && !def.fly) this.hurtMob(m, Math.floor(fall - 3), b.x, b.z, false);
      if (b.inLava && !def.fireproof) {
        m.lava -= dt;
        if (m.lava <= 0) { m.lava = 0.5; this.hurtMob(m, 4, b.x, b.z, false); }
      }
      // Зомби и скелеты горят на солнце
      if (def.burns && g.daylight() > 0.75 && !b.inWater && b.y + 1.6 >= w.height(Math.floor(b.x), Math.floor(b.z))) m.fire = Math.max(m.fire || 0, 2);
      if (b.y < -64) this.list.delete(m.eid);
    }

    // Выстрел существа: скелет — стрела по дуге, ифрит — очередь из трёх шаров, гаст — большой шар
    mobShoot(m, ey) {
      const g = this.game, p = g.player, b = m.body, def = m.def;
      // Прицел как в Minecraft: на треть роста игрока, стрела с запасом по высоте на падение
      const tx = p.x - b.x, ty = p.y + (def.ranged === 'arrow' ? 0.6 : 1.2) - ey, tz = p.z - b.z;
      const hd = Math.hypot(tx, tz) || 1;
      const yaw = Math.atan2(tz, tx);
      const sx = b.x + Math.cos(yaw) * 0.6, sz = b.z + Math.sin(yaw) * 0.6;
      if (def.ranged === 'arrow') {
        m.shootCd = 2 + Math.random();
        const sp = 32, sc = (Math.random() - 0.5) * 0.08;
        const vy = ty + hd * 0.2;
        const l = Math.hypot(tx, vy, tz) || 1;
        this.shootArrow(sx, ey, sz, (tx / l + sc) * sp, vy / l * sp, (tz / l - sc) * sp,
          { shooter: m, dmg: 2, potion: def.arrowPotion || 0, pickup: false, fire: m.fire > 0 });
      } else if (def.ranged === 'fireball') {
        m.burst = (m.burst || 0) + 1;
        if (m.burst >= 3) { m.burst = 0; m.shootCd = 3; } else m.shootCd = 0.3;
        this.shootFireball(sx, ey, sz, tx + (Math.random() - 0.5) * 1.5, ty, tz + (Math.random() - 0.5) * 1.5, false, m);
      } else {
        m.shootCd = 3;
        MC.Sound.play('fire.ignite', { x: b.x, y: b.y, z: b.z }, 2, 0.6);
        this.shootFireball(b.x + Math.cos(yaw) * 2.5, ey - 1, b.z + Math.sin(yaw) * 2.5, tx, ty + 1, tz, true, m);
      }
    }

    // ---------- Динамит ----------
    primeTnt(x, y, z, fuse) {
      const eid = this.nextId++;
      const a = Math.random() * Math.PI * 2, s = 0.9 + Math.random() * 0.6;
      this.list.set(eid, { kind: 'tnt', eid, x: x + 0.5, y, z: z + 0.5, vx: Math.cos(a) * s, vy: 2.2, vz: Math.sin(a) * s, fuse });
      MC.Sound.play('random.fuse', { x: x + 0.5, y: y + 0.5, z: z + 0.5 }, 1, 1);
    }

    updateTnt(e, dt) {
      e.fuse -= dt;
      e.vy -= 20 * dt;
      const ny = e.y + e.vy * dt;
      if (e.vy < 0 && this.solidAt(e.x, ny, e.z)) { e.y = Math.floor(ny) + 1; e.vy = 0; } else e.y = ny;
      const nx = e.x + (e.vx || 0) * dt, nz = e.z + (e.vz || 0) * dt;
      if (!this.solidAt(nx, e.y + 0.1, e.z)) e.x = nx; else e.vx = 0;
      if (!this.solidAt(e.x, e.y + 0.1, nz)) e.z = nz; else e.vz = 0;
      const drag = Math.pow(0.6, dt);
      e.vx = (e.vx || 0) * drag; e.vz = (e.vz || 0) * drag;
      if (e.fuse <= 0) {
        this.list.delete(e.eid);
        this.explode(e.x, e.y + 0.5, e.z, 4);
      }
    }

    // ---------- Падающие блоки (песок, гравий, бетонная пудра, наковальня) ----------
    spawnFalling(x, y, z, id, data) {
      const eid = this.nextId++;
      this.list.set(eid, { kind: 'fall', eid, x: x + 0.5, y, z: z + 0.5, vx: 0, vy: 0, vz: 0, bid: id, bdata: data });
    }

    updateFalling(e, dt) {
      const w = this.world;
      if (!w.isLoaded(Math.floor(e.x), Math.floor(e.z))) { this.list.delete(e.eid); return; }
      e.vy = Math.max(e.vy - 24 * dt, -40);
      const nx = e.x + (e.vx || 0) * dt, nz = e.z + (e.vz || 0) * dt;
      if (!this.solidAt(nx, e.y + 0.1, e.z)) e.x = nx; else e.vx = 0;
      if (!this.solidAt(e.x, e.y + 0.1, nz)) e.z = nz; else e.vz = 0;
      const drag = Math.pow(0.5, dt);
      e.vx = (e.vx || 0) * drag; e.vz = (e.vz || 0) * drag;
      const ny = e.y + e.vy * dt;
      if (e.vy < 0 && this.solidAt(e.x, ny, e.z)) {
        this.list.delete(e.eid);
        this.landFalling(Math.floor(e.x), Math.floor(ny) + 1, Math.floor(e.z), e.bid, e.bdata);
      } else {
        e.y = ny;
        if (e.y < -8) this.list.delete(e.eid);
      }
    }

    landFalling(x, y, z, id, data) {
      const w = this.world, g = this.game;
      const free = (yy) => yy >= 0 && yy <= 255 && Blocks.list[w.getId(x, yy, z)].replaceable;
      const ty = free(y) ? y : free(y + 1) ? y + 1 : -1;
      if (ty >= 0) {
        w.setBlock(x, ty, z, id, data);
        MC.Sound.block(id, 'place', x + 0.5, ty + 0.5, z + 0.5);
      } else if (g.gamemode === 0) {
        this.spawnItem({ id, data, count: 1 }, x + 0.5, y + 0.5, z + 0.5);
      }
    }

    // ---------- Взрыв ----------
    // fire — поджигает землю вокруг (огненный шар гаста), why — причина смерти игрока
    explode(x, y, z, power, fire, why, src) {
      const w = this.world, g = this.game;
      const r = Math.ceil(power);
      MC.Sound.event('explode', x, y, z);
      if (g.particles) g.particles.explosion(x, y, z, power);
      for (let bx = -r; bx <= r; bx++) for (let by = -r; by <= r; by++) for (let bz = -r; bz <= r; bz++) {
        const d = Math.hypot(bx, by, bz);
        if (d > power * (0.7 + Math.random() * 0.45)) continue;
        const X = Math.floor(x) + bx, Y = Math.floor(y) + by, Z = Math.floor(z) + bz;
        const id = w.getId(X, Y, Z);
        if (!id) continue;
        const blk = Blocks.list[id];
        if (blk.hardness < 0 || blk.hardness >= 50 || blk.liquid) continue;
        const data = w.getData(X, Y, Z);
        if (id !== 46 && Math.random() < 0.3) for (const it of MC.Survival.blockDrops(id, data, 278)) this.spawnItem(it, X + 0.5, Y + 0.5, Z + 0.5);
        g.removeBlockSP(X, Y, Z, false);
      }
      const p = g.player;
      const pd = Math.hypot(p.x - x, p.y + 0.9 - y, p.z - z);
      if (pd < power * 2) {
        const impact = 1 - pd / (power * 2);
        g.damagePlayer(Math.floor((impact * impact + impact) * 3.5 * power + 1), x, z, why || 'Взорван');
      }
      for (const e of this.list.values()) {
        if (e.kind !== 'mob' || e === src) continue;
        const ed = Math.hypot(e.body.x - x, e.body.y - y, e.body.z - z);
        if (ed < power * 2) {
          const impact = 1 - ed / (power * 2);
          e.invuln = 0;
          this.hurtMob(e, Math.floor((impact * impact + impact) * 3.5 * power + 1), x, z, false);
        }
      }
      // Кристаллы Края взрываются от взрыва рядом (цепная реакция)
      const boom = [];
      for (const c of this.list.values()) if (c.kind === 'crystal' && Math.hypot(c.x - x, c.y + 1 - y, c.z - z) < power * 1.5) boom.push(c);
      // Разлёт сущностей (динамит, предметы, падающие блоки) от взрыва
      for (const o of this.list.values()) {
        if (o.kind !== 'tnt' && o.kind !== 'item' && o.kind !== 'fall') continue;
        const ox = o.x - x, oy = o.y - y, oz = o.z - z;
        const od = Math.hypot(ox, oy, oz);
        if (od > 0.1 && od < power * 2) {
          const impact = (1 - od / (power * 2)) * 9;
          o.vx = (o.vx || 0) + ox / od * impact;
          o.vy = (o.vy || 0) + oy / od * impact + 2.5;
          o.rest = false;
          o.vz = (o.vz || 0) + oz / od * impact;
        }
      }
      if (fire) for (let i = 0; i < 6; i++) this.igniteAt(Math.floor(x) + rnd(-2, 2), Math.floor(y) + rnd(-1, 1), Math.floor(z) + rnd(-2, 2));
      for (const c of boom) if (this.list.has(c.eid)) this.destroyCrystal(c);
    }

    // ---------- Кадр ----------
    update(dt) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        this.spawnTimer = 1.5;
        if (this.game.survival() || this.hostileCount()[0] < MOB_CAP) this.trySpawn();
      }
      this.mergeTimer = (this.mergeTimer || 0) - dt;
      if (this.mergeTimer <= 0) { this.mergeTimer = 0.5; this.mergeItems(); }
      // Предметов не больше ITEM_CAP: самые старые исчезают
      if (this.list.size > ITEM_CAP) {
        this.mergeItems();
        const old = [];
        for (const e of this.list.values()) if (e.kind === 'item') old.push(e);
        if (old.length > ITEM_CAP) {
          old.sort((a, b) => b.age - a.age);
          for (let i = 0; i < old.length - ITEM_CAP; i++) this.list.delete(old[i].eid);
        }
      }
      for (const e of Array.from(this.list.values())) {
        if (e.kind === 'item') this.updateItem(e, dt);
        else if (e.kind === 'proj') this.updateProj(e, dt);
        else if (e.kind === 'tnt') this.updateTnt(e, dt);
        else if (e.kind === 'fall') this.updateFalling(e, dt);
        else if (e.kind === 'arrow') this.updateArrow(e, dt);
        else if (e.kind === 'fireball') this.updateFireball(e, dt);
        else if (e.kind === 'cloud') this.updateCloud(e, dt);
        else if (e.kind === 'eye') this.updateEye(e, dt);
        else if (e.kind === 'crystal') e.age += dt;
        else if (e.kind === 'bullet') this.updateBullet(e, dt);
        else this.updateMob(e, dt);
      }
      this.spawnerT = (this.spawnerT || 0) - dt;
      if (this.spawnerT <= 0) { this.spawnerT = 1; this.tickSpawners(); this.tickFixedSpawns(); }
      this.beaconT = (this.beaconT || 0) - dt;
      if (this.beaconT <= 0) { this.beaconT = 4; this.tickBeacons(); }
    }

    sceneLists() {
      const mobs = [], items = [], crystals = [];
      for (const e of this.list.values()) {
        if (e.kind === 'arrow') {
          const l = Math.hypot(e.vx, e.vy, e.vz);
          const dir = e.stuck ? [e.dx, e.dy, e.dz] : l > 0.01 ? [e.vx / l, e.vy / l, e.vz / l] : [0, -1, 0];
          items.push({ eid: e.eid, x: e.x, y: e.y, z: e.z, item: e.item, dir });
        } else if (e.kind === 'item' || e.kind === 'proj' || e.kind === 'fireball' || e.kind === 'eye') items.push(e);
        else if (e.kind === 'cloud') continue;
        else if (e.kind === 'crystal') {
          // Луч лечения: от кристалла к дракону, которого он лечит
          let beam = null;
          for (const d of this.list.values()) if (d.kind === 'mob' && d.def.dragon && !d.dead && d.healing === e.eid) beam = [d.body.x, d.body.y + 1.5, d.body.z];
          crystals.push({ eid: e.eid, x: e.x, y: e.y, z: e.z, age: e.age, base: !e.placed, beam });
        } else if (e.kind === 'bullet') items.push({ eid: e.eid, x: e.x, y: e.y - 0.15, z: e.z, item: { id: 433, data: 0, count: 1 } });
        else if (e.kind === 'tnt') mobs.push({ eid: e.eid, type: 65, x: e.x, y: e.y, z: e.z, yaw: 0, fuse: 4 - e.fuse, hurt: 0 });
        else if (e.kind === 'fall') mobs.push({ eid: e.eid, type: 66, x: e.x, y: e.y, z: e.z, yaw: 0, blockId: e.bid, blockData: e.bdata, hurt: 0 });
        else {
          const b = e.body;
          mobs.push({ eid: e.eid, type: e.type, x: b.x, y: b.y, z: b.z, yaw: b.yaw, walk: b.walkDist, hurt: e.hurt || (e.fire > 0 ? 0.05 : 0), fuse: e.fuse, dead: e.dead > 0, deathP: e.dead > 0 && !e.def.dragon ? Math.max(0.01, (0.6 - e.dead) / 0.6 * 0.6) : 0 });
        }
      }
      return { mobs, items, crystals };
    }

    targets() {
      const out = [];
      for (const e of this.list.values()) {
        // Огненный шар можно отбить ударом
        if (e.kind === 'fireball') { out.push({ eid: e.eid, x: e.x, y: e.y - 0.5, z: e.z, w: 1, h: 1 }); continue; }
        if (e.kind === 'bullet') { out.push({ eid: e.eid, x: e.x, y: e.y - 0.3, z: e.z, w: 0.6, h: 0.6 }); continue; }
        if (e.kind === 'crystal') { out.push({ eid: e.eid, x: e.x, y: e.y, z: e.z, w: 2, h: 2 }); continue; }
        if (e.kind !== 'mob' || e.dead) continue;
        if (e.def.dragon) { for (const pt of this.dragonParts(e)) out.push({ eid: e.eid, x: pt.x, y: pt.y, z: pt.z, w: pt.w, h: pt.h, part: pt.part }); continue; }
        const sz = this.mobSize(e);
        out.push({ eid: e.eid, x: e.body.x, y: e.body.y, z: e.body.z, w: sz[0], h: sz[1] });
      }
      return out;
    }

    nearHostile(x, y, z, r) {
      for (const e of this.list.values()) {
        if (e.kind === 'mob' && e.def.hostile && !e.def.neutral && !e.dead && Math.hypot(e.body.x - x, e.body.y - y, e.body.z - z) < r) return true;
      }
      return false;
    }

    clear() {
      this.list.clear();
      this.spawners.clear();
      if (this.beacons) this.beacons.clear();
      if (this.witherBars) { for (const bar of this.witherBars.values()) bar.remove(); this.witherBars.clear(); }
    }
  }

  Entities.TYPES = { zombie: 32, creeper: 33, spider: 35, pig: 12, cow: 11, sheep: 13, chicken: 10 };
  MC.Entities = Entities;
})();
