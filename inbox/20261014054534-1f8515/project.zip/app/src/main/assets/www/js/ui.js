// Интерфейс: меню, список миров и серверов, настройки, HUD, чат, инвентарь
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const A = window.MC_ASSETS;

  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined && text !== null) e.textContent = text;
    return e;
  }

  function loadImg(src) {
    return new Promise((res, rej) => {
      const im = new Image();
      im.onload = () => res(im);
      im.onerror = () => rej(new Error('Не удалось загрузить изображение интерфейса'));
      im.src = src;
    });
  }

  function crop(img, x, y, w, h) {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    c.getContext('2d').drawImage(img, x, y, w, h, 0, 0, w, h);
    return c.toDataURL();
  }

  class UI {
    constructor(app) {
      this.app = app;
      this.root = document.getElementById('screens');
      this.hud = document.getElementById('hud');
      this.sprites = {};
      this.chatLines = [];
      this.chatOpen = false;
      this.current = null;
    }

    async init() {
      const [gui, icons] = await Promise.all([loadImg(A.gui.gui), loadImg(A.gui.icons)]);
      const s = this.sprites;
      s.hotbar = crop(gui, 0, 0, 182, 22);
      s.selector = crop(gui, 0, 22, 24, 24);
      s.btn = crop(gui, 0, 66, 200, 20);
      s.btnHover = crop(gui, 0, 86, 200, 20);
      s.btnOff = crop(gui, 0, 46, 200, 20);
      s.up = crop(gui, 0, 107, 26, 26);
      s.left = crop(gui, 26, 107, 26, 26);
      s.down = crop(gui, 52, 107, 26, 26);
      s.right = crop(gui, 78, 107, 26, 26);
      s.jump = crop(gui, 104, 107, 26, 26);
      s.flyUp = crop(gui, 52, 133, 26, 26);
      s.flyDown = crop(gui, 78, 133, 26, 26);
      s.sneak = crop(gui, 218, 64, 18, 18);
      s.pause = crop(gui, 200, 64, 18, 18);
      s.chat = crop(gui, 200, 82, 18, 18);
      s.cross = crop(icons, 0, 0, 15, 15);
      s.heartEmpty = crop(icons, 16, 0, 9, 9);
      s.heartFull = crop(icons, 52, 0, 9, 9);
      s.heartHalf = crop(icons, 61, 0, 9, 9);
      s.foodEmpty = crop(icons, 16, 27, 9, 9);
      s.foodFull = crop(icons, 52, 27, 9, 9);
      s.foodHalf = crop(icons, 61, 27, 9, 9);
      s.bubble = crop(icons, 16, 18, 9, 9);
      s.armorEmpty = crop(icons, 16, 9, 9, 9);
      s.armorHalf = crop(icons, 25, 9, 9, 9);
      s.armorFull = crop(icons, 34, 9, 9, 9);
      s.xpEmpty = crop(icons, 0, 64, 182, 5);
      s.xpFull = crop(icons, 0, 69, 182, 5);
      const css = document.documentElement.style;
      css.setProperty('--btn', 'url(' + s.btn + ')');
      css.setProperty('--btn-hover', 'url(' + s.btnHover + ')');
      css.setProperty('--btn-off', 'url(' + s.btnOff + ')');
      css.setProperty('--dirt', 'url(' + A.gui.background + ')');
      css.setProperty('--hotbar', 'url(' + s.hotbar + ')');
      css.setProperty('--xp-empty', 'url(' + s.xpEmpty + ')');
      css.setProperty('--xp-full', 'url(' + s.xpFull + ')');
      css.setProperty('--selector', 'url(' + s.selector + ')');
      css.setProperty('--cross', 'url(' + s.cross + ')');
      css.setProperty('--t-up', 'url(' + s.up + ')');
      css.setProperty('--t-down', 'url(' + s.down + ')');
      css.setProperty('--t-jump', 'url(' + s.jump + ')');
      css.setProperty('--t-left', 'url(' + s.left + ')');
      css.setProperty('--t-right', 'url(' + s.right + ')');
      css.setProperty('--t-flyup', 'url(' + s.flyUp + ')');
      css.setProperty('--t-flydown', 'url(' + s.flyDown + ')');
      css.setProperty('--t-sneak', 'url(' + s.sneak + ')');
      css.setProperty('--t-pause', 'url(' + s.pause + ')');
      css.setProperty('--t-chat', 'url(' + s.chat + ')');
      this.buildPanorama();
      this.buildHud();
    }

    buildPanorama() {
      const pano = document.getElementById('panorama');
      const cube = el('div', 'pano-cube');
      // panorama_0..5: перед, право, зад, лево, верх, низ
      const tf = ['translateZ(-50vmax)', 'rotateY(-90deg) translateZ(-50vmax)', 'rotateY(180deg) translateZ(-50vmax)',
        'rotateY(90deg) translateZ(-50vmax)', 'rotateX(-90deg) translateZ(-50vmax)', 'rotateX(90deg) translateZ(-50vmax)'];
      A.gui.panorama.forEach((src, i) => {
        const f = el('div', 'pano-face');
        f.style.backgroundImage = 'url(' + src + ')';
        f.style.transform = tf[i];
        cube.appendChild(f);
      });
      pano.appendChild(cube);
    }

    showPanorama(v) { document.getElementById('panorama').style.display = v ? 'block' : 'none'; }

    // ---------- Общие элементы меню ----------
    clear() {
      this.root.innerHTML = '';
      this.root.style.display = 'none';
      this.root.className = '';
      this.current = null;
    }

    screen(name, opts) {
      this.root.innerHTML = '';
      this.root.style.display = 'flex';
      this.root.className = (opts && opts.dirt ? 'dirt ' : '') + (opts && opts.overlay ? 'overlay ' : '');
      this.current = name;
      const box = el('div', 'screen screen-' + name);
      this.root.appendChild(box);
      return box;
    }

    button(parent, label, onClick, opts) {
      const b = el('button', 'mc-btn' + (opts && opts.small ? ' small' : ''), label);
      if (opts && opts.disabled) b.disabled = true;
      b.addEventListener('click', (e) => { e.preventDefault(); if (!b.disabled) { MC.Sound.click(); onClick(); } });
      parent.appendChild(b);
      return b;
    }

    field(parent, label, value, opts) {
      const wrap = el('label', 'mc-field');
      wrap.appendChild(el('span', 'mc-label', label));
      const i = el('input', 'mc-input');
      i.type = (opts && opts.type) || 'text';
      i.value = value === undefined || value === null ? '' : value;
      if (opts && opts.placeholder) i.placeholder = opts.placeholder;
      if (opts && opts.maxLength) i.maxLength = opts.maxLength;
      i.autocomplete = 'off';
      i.spellcheck = false;
      wrap.appendChild(i);
      parent.appendChild(wrap);
      return i;
    }

    slider(parent, label, min, max, step, value, fmt, onChange) {
      const wrap = el('label', 'mc-field');
      const lab = el('span', 'mc-label', label + ': ' + fmt(value));
      wrap.appendChild(lab);
      const i = el('input', 'mc-range');
      i.type = 'range';
      i.min = min; i.max = max; i.step = step; i.value = value;
      i.addEventListener('input', () => { lab.textContent = label + ': ' + fmt(parseFloat(i.value)); onChange(parseFloat(i.value)); });
      wrap.appendChild(i);
      parent.appendChild(wrap);
      return i;
    }

    // ---------- Экраны ----------
    showMain() {
      this.showPanorama(true);
      const box = this.screen('main');
      const logo = el('div', 'logo');
      const img = el('img');
      img.src = A.gui.title;
      img.alt = 'Minecraft';
      logo.appendChild(img);
      if (A.splashes && A.splashes.length) logo.appendChild(el('div', 'splash', A.splashes[Math.floor(Math.random() * A.splashes.length)]));
      box.appendChild(logo);
      const col = el('div', 'menu-col');
      box.appendChild(col);
      this.button(col, 'Одиночная игра', () => this.showWorlds());
      this.button(col, 'Сетевая игра', () => this.showServers());
      this.button(col, 'Мой сервер', () => this.showMyServer());
      this.button(col, 'Настройки', () => this.showSettings(() => this.showMain()));
      if (this.app.startupNotes && this.app.startupNotes.length) {
        box.appendChild(el('div', 'hint startup-note', this.app.startupNotes.join(' · ')));
        this.app.startupNotes = [];
      }
      box.appendChild(el('div', 'footer-left', 'HTML5-клиент · протокол ' + MC.McpeClient.PROTOCOL + ' (MCPE 1.1.x)'));
      box.appendChild(el('div', 'footer-right', 'Неофициальная игра. Текстуры: Minecraft PE 1.1.5 © Mojang'));
    }

    async showWorlds() {
      this.showPanorama(false);
      const box = this.screen('worlds', { dirt: true });
      box.appendChild(el('h2', 'title', 'Одиночная игра'));
      const list = el('div', 'list');
      box.appendChild(list);
      const row = el('div', 'btn-row');
      box.appendChild(row);
      let selected = null;
      const playBtn = this.button(row, 'Играть', () => selected && this.app.playWorld(selected), { disabled: true });
      const delBtn = this.button(row, 'Удалить', async () => {
        if (!selected) return;
        if (!confirm('Удалить мир «' + selected.name + '»? Это нельзя отменить.')) return;
        await MC.Storage.Worlds.remove(selected.id);
        this.showWorlds();
      }, { disabled: true });
      const genBtn = this.button(row, 'Новая генерация', async () => {
        if (!selected || selected.gen === 2) return;
        if (!confirm('Перевести мир «' + selected.name + '» на новую генерацию (15 биомов, реки, данжи)?\n' +
          'Уже изученная часть мира останется как была, новые биомы начнутся за её границей с плавным переходом. Отменить нельзя.')) return;
        genBtn.disabled = true;
        try {
          await this.convertWorldGen(selected);
        } catch (e) {
          alert('Не удалось перевести мир: ' + e.message);
        }
        this.showWorlds();
      }, { disabled: true });
      const row2 = el('div', 'btn-row');
      box.appendChild(row2);
      this.button(row2, 'Создать новый мир', () => this.showCreateWorld());
      this.button(row2, 'Назад', () => this.showMain());
      let worlds = [];
      try {
        worlds = await MC.Storage.Worlds.list();
      } catch (e) {
        list.appendChild(el('div', 'empty', 'Хранилище недоступно: ' + e.message));
        return;
      }
      if (!worlds.length) list.appendChild(el('div', 'empty', 'Миров пока нет. Создайте первый.'));
      for (const w of worlds) {
        const item = el('div', 'list-item');
        item.appendChild(el('div', 'li-title', w.name));
        item.appendChild(el('div', 'li-sub', (w.gamemode === 0 ? 'Выживание' : 'Творческий') + ' · зерно ' + w.seed + (w.gen === 2 ? '' : ' · старая генерация') + ' · ' + new Date(w.lastPlayed).toLocaleString('ru-RU')));
        item.addEventListener('click', () => {
          for (const c of list.children) c.classList.remove('sel');
          item.classList.add('sel');
          selected = w;
          playBtn.disabled = false;
          delBtn.disabled = false;
          genBtn.disabled = w.gen === 2;
        });
        item.addEventListener('dblclick', () => this.app.playWorld(w));
        list.appendChild(item);
      }
    }

    // Старый мир на новый генератор: изученная часть (сохранённые чанки с запасом, места игрока и точки
    // возрождения) запоминается и дальше строится старым генератором, остальное — новым
    async convertWorldGen(w) {
      const saved = await MC.Storage.Worlds.chunkCoords(w.id);
      const set = new Set();
      const area = (cx, cz, r) => {
        for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) set.add((cx + dx) + ',' + (cz + dz));
      };
      for (let i = 0; i < saved.length; i += 2) area(saved[i], saved[i + 1], 2);
      const view = Math.min(12, this.app.settings.renderDistance || 6) + 1;
      if (w.player && !w.dimension) area(Math.floor(w.player.x) >> 4, Math.floor(w.player.z) >> 4, view);
      if (w.spawn) area(Math.floor(w.spawn.x) >> 4, Math.floor(w.spawn.z) >> 4, view);
      // Точка появления остаётся там же, где была у старого генератора
      const ws = new MC.LegacyGenerator(w.seed).findSpawn();
      area(Math.floor(ws.x) >> 4, Math.floor(ws.z) >> 4, view);
      const legacyChunks = [];
      for (const k of set) {
        const [cx, cz] = k.split(',').map(Number);
        legacyChunks.push(cx, cz);
      }
      const fresh = (await MC.Storage.Worlds.get(w.id)) || w;
      fresh.gen = 2;
      fresh.legacyChunks = legacyChunks;
      fresh.worldSpawn = ws;
      await MC.Storage.Worlds.put(fresh);
      Object.assign(w, fresh);
    }

    showCreateWorld() {
      const box = this.screen('create', { dirt: true });
      box.appendChild(el('h2', 'title', 'Новый мир'));
      const name = this.field(box, 'Название мира', 'Новый мир', { maxLength: 32 });
      const seed = this.field(box, 'Зерно (необязательно)', '', { placeholder: 'случайное' });
      const modeWrap = el('label', 'mc-field');
      modeWrap.appendChild(el('span', 'mc-label', 'Режим игры'));
      const mode = el('select', 'mc-input');
      for (const [v, t] of [['0', 'Выживание'], ['1', 'Творческий']]) {
        const o = el('option', null, t);
        o.value = v;
        mode.appendChild(o);
      }
      modeWrap.appendChild(mode);
      box.appendChild(modeWrap);
      const row = el('div', 'btn-row');
      box.appendChild(row);
      this.button(row, 'Создать', async () => {
        let s = seed.value.trim();
        let num;
        if (!s) num = Math.floor(Math.random() * 2147483647);
        else if (/^-?\d+$/.test(s)) num = parseInt(s, 10) | 0;
        else { num = 0; for (const ch of s) num = (Math.imul(num, 31) + ch.charCodeAt(0)) | 0; }
        const w = { id: MC.Storage.uuidv4(), name: name.value.trim() || 'Новый мир', seed: num, gen: 2, gamemode: parseInt(mode.value, 10), created: Date.now(), lastPlayed: Date.now(), player: null };
        await MC.Storage.Worlds.put(w);
        this.app.playWorld(w);
      });
      this.button(row, 'Отмена', () => this.showWorlds());
    }

    showServers() {
      this.showPanorama(false);
      const st = this.app.settings;
      const box = this.screen('servers', { dirt: true });
      box.appendChild(el('h2', 'title', 'Сетевая игра'));
      st.relay = MC.Storage.relayUrl(st);
      const relay = this.field(box, 'Адрес ретранслятора (relay.js)', st.relay, { placeholder: 'ws://192.168.1.10:8080' });
      relay.addEventListener('change', () => { st.relay = relay.value.trim(); st.relay = MC.Storage.relayUrl(st); MC.Storage.saveSettings(st); this.showServers(); });
      box.appendChild(el('div', 'hint', window.AndroidRelay
        ? 'Ретранслятор встроен в приложение и запускается сам (адрес выше). Вход через Xbox Live не поддерживается: нужны серверы без него (xbox-auth=false).'
        : 'Серверы MCPE работают по UDP, а браузер умеет только WebSocket, поэтому подключение идёт через ретранслятор. Вход через Xbox Live не поддерживается: нужны серверы без него (xbox-auth=false).'));
      const list = el('div', 'list');
      box.appendChild(list);
      const servers = MC.Storage.loadServers();
      let selected = -1;
      const row = el('div', 'btn-row');
      box.appendChild(row);
      const join = this.button(row, 'Подключиться', () => selected >= 0 && this.app.connect(servers[selected]), { disabled: true });
      const edit = this.button(row, 'Изменить', () => selected >= 0 && this.showEditServer(selected), { disabled: true });
      const del = this.button(row, 'Удалить', () => {
        if (selected < 0) return;
        servers.splice(selected, 1);
        MC.Storage.saveServers(servers);
        this.showServers();
      }, { disabled: true });
      const row2 = el('div', 'btn-row');
      box.appendChild(row2);
      this.button(row2, 'Добавить сервер', () => this.showEditServer(-1));
      this.button(row2, 'Обновить', () => this.showServers());
      this.button(row2, 'Назад', () => this.showMain());
      if (!servers.length) list.appendChild(el('div', 'empty', 'Добавьте сервер Minecraft PE 1.1.x (адрес и порт, обычно 19132).'));
      servers.forEach((srv, i) => {
        const item = el('div', 'list-item');
        const top = el('div', 'li-title', srv.name || srv.host);
        const status = el('span', 'li-status', 'опрос...');
        top.appendChild(status);
        item.appendChild(top);
        const sub = el('div', 'li-sub', srv.host + ':' + srv.port);
        if (srv.device || srv.input) item.appendChild(el('div', 'li-sub', 'Вход как: ' + MC.Storage.deviceInfo(st, srv, false).label));
        item.appendChild(sub);
        item.addEventListener('click', () => {
          for (const c of list.children) c.classList.remove('sel');
          item.classList.add('sel');
          selected = i;
          join.disabled = edit.disabled = del.disabled = false;
        });
        item.addEventListener('dblclick', () => this.app.connect(srv));
        list.appendChild(item);
        MC.pingServer(MC.Storage.relayUrl(st), srv.host, srv.port).then((info) => {
          status.textContent = info.online + '/' + info.max + ' · ' + info.ping + ' мс';
          sub.textContent = '';
          sub.appendChild(MC.formatted(info.name));
          sub.appendChild(document.createTextNode(' · v' + info.version));
          if (info.protocol !== MC.McpeClient.PROTOCOL) {
            status.textContent += ' · несовместим (протокол ' + info.protocol + ')';
            status.classList.add('bad');
          }
        }).catch((e) => {
          status.textContent = e.message;
          status.classList.add('bad');
        });
      });
    }

    showEditServer(index) {
      const servers = MC.Storage.loadServers();
      const srv = index >= 0 ? servers[index] : { name: 'Сервер Minecraft', host: '', port: 19132 };
      const box = this.screen('edit', { dirt: true });
      box.appendChild(el('h2', 'title', index >= 0 ? 'Изменить сервер' : 'Добавить сервер'));
      const name = this.field(box, 'Название', srv.name, { maxLength: 40 });
      const host = this.field(box, 'Адрес сервера', srv.host, { placeholder: 'play.example.com или 192.168.1.5' });
      const port = this.field(box, 'Порт', srv.port, { type: 'number' });
      const mkSel = (label, opts, value) => {
        const w = el('label', 'mc-field');
        w.appendChild(el('span', 'mc-label', label));
        const sel = el('select', 'mc-input');
        for (const [v, t] of opts) { const o = el('option', null, t); o.value = v; if (v === value) o.selected = true; sel.appendChild(o); }
        w.appendChild(sel);
        box.appendChild(w);
        return sel;
      };
      const dev = mkSel('Устройство для этого сервера', [['', 'Как в настройках']].concat(Object.entries(MC.Storage.DEVICES).filter(([k]) => k !== 'auto').map(([k, d]) => [k, d.name])), srv.device || '');
      const inp = mkSel('Управление для этого сервера', [['', 'Как в настройках']].concat(Object.entries(MC.Storage.INPUTS).filter(([k]) => k !== 'auto').map(([k, d]) => [k, d.name])), srv.input || '');
      const err = el('div', 'hint bad');
      box.appendChild(err);
      const row = el('div', 'btn-row');
      box.appendChild(row);
      this.button(row, 'Сохранить', () => {
        let h = host.value.trim();
        let p = parseInt(port.value, 10) || 19132;
        const m = h.match(/^(.*):(\d+)$/);
        if (m && h.indexOf(']') < 0 && h.split(':').length === 2) { h = m[1]; p = parseInt(m[2], 10); }
        if (!h) { err.textContent = 'Укажите адрес сервера'; return; }
        if (p < 1 || p > 65535) { err.textContent = 'Порт должен быть от 1 до 65535'; return; }
        const entry = { name: name.value.trim() || h, host: h, port: p };
        if (dev.value) entry.device = dev.value;
        if (inp.value) entry.input = inp.value;
        if (index >= 0) servers[index] = entry; else servers.push(entry);
        MC.Storage.saveServers(servers);
        this.showServers();
      });
      this.button(row, 'Отмена', () => this.showServers());
    }

    // Свой сервер прямо в приложении (MineServerService): работает в фоне, даже когда игра закрыта
    showMyServer() {
      this.showPanorama(false);
      const box = this.screen('myserver', { dirt: true });
      box.appendChild(el('h2', 'title', 'Мой сервер'));
      const S = window.AndroidServer;
      if (!S) {
        box.appendChild(el('div', 'status', 'Свой сервер работает только в приложении для Android (APK). В браузере его запустить нельзя.'));
        const row = el('div', 'btn-row');
        box.appendChild(row);
        this.button(row, 'Назад', () => this.showMain());
        return;
      }
      let cfg = {};
      try { cfg = JSON.parse(S.config() || '{}'); } catch (e) { cfg = {}; }
      if (!cfg.tunnelKey) {
        const a = new Uint8Array(18);
        crypto.getRandomValues(a);
        cfg.tunnelKey = Array.from(a, (b) => 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'[b % 56]).join('');
      }
      const head = el('div', 'status');
      box.appendChild(head);
      const body = el('div', 'settings-body');
      box.appendChild(body);
      const row = el('div', 'btn-row');
      box.appendChild(row);
      const playBtn = this.button(row, 'Играть на своём сервере', () => {
        const c = readCfg();
        this.app.connect({ name: c.name, host: '127.0.0.1', port: c.port });
      }, { disabled: true });
      const runBtn = this.button(row, 'Запустить', () => {
        if (st && (st.running || st.starting)) { S.stop(); setTimeout(refresh, 800); return; }
        const c = readCfg();
        if (c.tunnelUrl && c.tunnelKey.length < 8) { err.textContent = 'Ключ туннеля — не короче 8 символов'; return; }
        err.textContent = '';
        const e = S.start(JSON.stringify(c));
        if (e) err.textContent = e;
        setTimeout(refresh, 600);
      });
      this.button(row, 'Назад', () => { clearInterval(timer); this.showMain(); });

      const sec = (t) => body.appendChild(el('div', 'li-title', t));
      const check = (label, value) => {
        const w = el('label', 'mc-check');
        const i = el('input');
        i.type = 'checkbox';
        i.checked = !!value;
        w.appendChild(i);
        w.appendChild(document.createTextNode(' ' + label));
        body.appendChild(w);
        return i;
      };
      const err = el('div', 'hint bad');
      body.appendChild(err);
      const addr = el('div', 'hint');
      body.appendChild(addr);
      const batt = el('div');
      body.appendChild(batt);

      sec('Игроки');
      const plist = el('div', 'hint', '—');
      body.appendChild(plist);

      sec('Настройки');
      const lockable = [];
      const f = (label, value, opts) => { const i = this.field(body, label, value, opts); lockable.push(i); return i; };
      const name = f('Название сервера', cfg.name || 'Мой сервер', { maxLength: 40 });
      const port = f('Порт (UDP)', cfg.port || 19132, { type: 'number' });
      const max = f('Максимум игроков', cfg.maxPlayers || 10, { type: 'number' });
      const seed = f('Зерно мира (только для нового мира)', cfg.seed || '', { placeholder: 'случайное' });
      const view = f('Дальность прорисовки, чанков (3–10)', cfg.viewDistance || 6, { type: 'number' });
      const select = (label, options, value) => {
        const w = el('label', 'mc-field');
        w.appendChild(el('span', 'mc-label', label));
        const sel = el('select', 'mc-input');
        for (const [v, t] of options) {
          const o = el('option', null, t);
          o.value = String(v);
          if (String(value) === String(v)) o.selected = true;
          sel.appendChild(o);
        }
        w.appendChild(sel);
        body.appendChild(w);
        lockable.push(sel);
        return sel;
      };
      const gm = select('Режим игры для новых игроков', [[0, 'Выживание'], [1, 'Творческий'], [2, 'Приключение']], cfg.gamemode === undefined ? 0 : cfg.gamemode);
      const diff = select('Сложность', [[0, 'Мирная (без голода)'], [1, 'Лёгкая'], [2, 'Нормальная'], [3, 'Сложная']], cfg.difficulty === undefined ? 1 : cfg.difficulty);
      const devs = select('Кого пускать по устройству', [['all', 'Все устройства'], ['mobile', 'Только телефоны и планшеты (Android, iOS, Fire OS)'], ['win10', 'Только Windows 10'], ['touch', 'Только сенсорное управление'], ['keyboard', 'Только клавиатура и мышь'], ['gamepad', 'Только геймпад']], cfg.devices || 'all');
      const guests = check('Гости могут строить и ломать', cfg.guestsBuild !== false);
      const wl = check('Белый список (заходят только разрешённые)', !!cfg.whitelist);
      const pvp = check('PvP: игроки могут бить друг друга', cfg.pvp !== false);
      const plug = check('Плагины включены', cfg.plugins !== false);
      lockable.push(guests, wl, pvp, plug);
      body.appendChild(el('div', 'hint', 'Владелец — тот, кто играет на этом телефоне: он оператор. Режим меняется командой /gamemode 0|1|2|3 [ник] (0 — выживание). Все команды: /help в чате или в консоли ниже.'));

      sec('Консоль');
      const conRow = el('div', 'btn-row');
      body.appendChild(conRow);
      const conIn = el('input', 'mc-input');
      conIn.placeholder = 'gamemode 0 Steve';
      conIn.style.flex = '1';
      conRow.appendChild(conIn);
      const conErr = el('div', 'hint bad');
      const runCmd = () => {
        const line = conIn.value.trim();
        if (!line) return;
        const e = S.command(line);
        conErr.textContent = e || '';
        if (!e) { conIn.value = ''; setTimeout(refresh, 300); }
      };
      conIn.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') runCmd(); });
      this.button(conRow, 'Выполнить', runCmd, { small: true });
      body.appendChild(conErr);
      body.appendChild(el('div', 'hint', 'Команды выполняются от имени сервера, с правами оператора: gamemode 0 Ник, give Ник diamond 5, op Ник, time set day, gamerule keepInventory true, kick Ник.'));

      sec('Плагины');
      body.appendChild(el('div', 'hint', 'Плагины на JavaScript (.js) — в архиве есть папка server-plugins с примерами и описание API в README. Плагины PocketMine (PHP) и Nukkit (Java .jar) здесь не работают: это другие движки.'));
      const plugRow = el('div', 'btn-row');
      body.appendChild(plugRow);
      const plugFile = el('input');
      plugFile.type = 'file';
      plugFile.accept = '.js,text/javascript,application/javascript';
      plugFile.multiple = true;
      plugFile.style.display = 'none';
      plugRow.appendChild(plugFile);
      const plugMsg = el('div', 'hint');
      const plugList = el('div', 'plugin-list');
      let plugSig = '';
      const changed = (msg) => {
        plugMsg.textContent = msg + (st && st.running ? ' Нажмите «Перезагрузить плагины».' : '');
        plugSig = '';
        showPlugins();
      };
      plugFile.addEventListener('change', async () => {
        const out = [];
        for (const file of plugFile.files) {
          const e = S.pluginAdd(file.name, await file.text());
          out.push(file.name + (e ? ': ' + e : ': добавлен'));
        }
        plugFile.value = '';
        changed(out.join('; ') + '.');
      });
      this.button(plugRow, 'Загрузить плагин (.js)', () => plugFile.click(), { small: true });
      this.button(plugRow, 'Перезагрузить плагины', () => {
        plugMsg.textContent = S.reloadPlugins() ? 'Плагины перезагружаются…' : 'Сервер не запущен: плагины загрузятся при запуске.';
        setTimeout(() => { plugSig = ''; showPlugins(); }, 1200);
      }, { small: true });
      this.button(plugRow, 'Вернуть встроенные', () => { S.pluginRestore(); changed('Встроенные плагины возвращены.'); }, { small: true });
      body.appendChild(plugMsg);
      body.appendChild(plugList);
      const showPlugins = () => {
        let list = [];
        try { list = JSON.parse(S.pluginList()); } catch (e) { return; }
        const sig = JSON.stringify(list) + (st && st.running);
        if (sig === plugSig) return;
        plugSig = sig;
        plugList.innerHTML = '';
        if (!list.length) plugList.appendChild(el('div', 'hint', 'Плагинов нет'));
        for (const p of list) {
          const item = el('div', 'plugin-item');
          item.appendChild(el('div', 'mc-label', p.name + (p.version ? ' ' + p.version : '') + ' · ' + p.file));
          if (p.description) item.appendChild(el('div', 'hint', p.description));
          let state;
          if (!p.enabled) state = 'Выключен';
          else if (!(st && st.running)) state = 'Загрузится при запуске сервера';
          else if (p.error) state = 'Ошибка: ' + p.error;
          else if (p.loaded) state = 'Работает' + (p.commands && p.commands.length ? ' · команды: /' + p.commands.join(', /') : '');
          else state = 'Не загружен: нажмите «Перезагрузить плагины»';
          item.appendChild(el('div', 'hint' + (p.error && p.enabled ? ' bad' : ''), state));
          const r = el('div', 'btn-row');
          item.appendChild(r);
          this.button(r, p.enabled ? 'Выключить' : 'Включить', () => {
            S.pluginToggle(p.file, !p.enabled);
            changed(p.name + (p.enabled ? ' выключен.' : ' включён.'));
          }, { small: true });
          this.button(r, 'Удалить', () => {
            if (!confirm('Удалить плагин ' + p.name + '? Его данные (дома, баланс и т. п.) останутся в папке data.')) return;
            S.pluginDelete(p.file);
            changed(p.name + ' удалён.');
          }, { small: true });
          plugList.appendChild(item);
        }
      };

      sec('Вход по домену через интернет (туннель)');
      body.appendChild(el('div', 'hint', 'Мобильный интернет не принимает входящие подключения, поэтому для адреса вида main-mine.ru нужен VPS с белым IP: на нём запускается tunnel-server.js (папка tunnel в архиве), а домен указывает на IP этого VPS. Телефон сам подключается к VPS, игроки заходят по домену на порт 19132.'));
      const turl = f('Адрес туннеля на VPS', cfg.tunnelUrl || '', { placeholder: 'main-mine.ru:8090' });
      const tkey = f('Ключ туннеля (такой же, как --key на VPS)', cfg.tunnelKey, { maxLength: 64 });
      const domain = f('Адрес для игроков (домен)', cfg.domain || '', { placeholder: 'main-mine.ru' });

      sec('Журнал');
      const logs = el('div', 'hint server-log');
      body.appendChild(logs);

      const readCfg = () => {
        let p = parseInt(port.value, 10) || 19132;
        if (p < 1024 || p > 65535) p = 19132;
        return {
          name: name.value.trim() || 'Мой сервер',
          port: p,
          maxPlayers: Math.max(1, Math.min(40, parseInt(max.value, 10) || 10)),
          seed: seed.value.trim(),
          viewDistance: Math.max(3, Math.min(10, parseInt(view.value, 10) || 6)),
          guestsBuild: guests.checked,
          whitelist: wl.checked,
          gamemode: parseInt(gm.value, 10) || 0,
          difficulty: parseInt(diff.value, 10),
          pvp: pvp.checked,
          devices: devs.value,
          plugins: plug.checked,
          owner: this.app.settings.nickname || '',
          tunnelUrl: turl.value.trim(),
          tunnelKey: tkey.value.trim(),
          domain: domain.value.trim()
        };
      };

      let st = null;
      const refresh = () => {
        if (this.current !== 'myserver') { clearInterval(timer); return; }
        try { st = JSON.parse(S.status()); } catch (e) { return; }
        const on = st.running || st.starting;
        runBtn.textContent = on ? 'Остановить' : 'Запустить';
        playBtn.disabled = !st.running;
        for (const i of lockable) i.disabled = on;
        head.textContent = st.starting ? 'Запуск…' : st.running
          ? 'Сервер работает · игроков ' + (st.players || []).length + ' из ' + st.max
          : 'Сервер выключен';
        head.className = 'status' + (st.running ? ' good' : '');
        if (st.error && !st.running) err.textContent = st.error;
        const c = readCfg();
        const lines = [];
        if (st.running) {
          lines.push('На этом телефоне: 127.0.0.1:' + st.port);
          if (st.lan && st.lan.length) lines.push('В той же Wi-Fi сети: ' + st.lan.map((a) => a + ':' + st.port).join(', ') + ' (сервер виден и во вкладке LAN-игр)');
          if (c.tunnelUrl) lines.push('Через интернет: ' + (c.domain || c.tunnelUrl.replace(/:\d+$/, '')) + ':19132 · ' + (st.tunnel || 'туннель не подключён'));
          lines.push('Сервер продолжит работать, если закрыть игру. Остановить — здесь или в уведомлении.');
        }
        addr.textContent = lines.join('\n');
        batt.innerHTML = '';
        if (!st.battery) {
          batt.appendChild(el('div', 'hint', 'Чтобы система не усыпляла сервер в фоне, разрешите игре работать без ограничений батареи.'));
          this.button(batt, 'Снять ограничения батареи', () => S.requestBattery(), { small: true });
        }
        plist.textContent = st.running ? ((st.players || []).join(', ') || 'Никого нет') : '—';
        try { logs.textContent = JSON.parse(S.logs()).slice(-40).join('\n'); } catch (e) { /* журнал недоступен */ }
        showPlugins();
      };
      const timer = setInterval(refresh, 2000);
      refresh();
    }

    // Настройки по вкладкам, как в Minecraft PE: список прокручивается, «Готово» всегда на экране
    showSettings(back, tab) {
      const st = this.app.settings;
      const box = this.screen('settings', { dirt: true, overlay: !!this.app.game });
      box.appendChild(el('h2', 'title', 'Настройки'));
      const save = () => MC.Storage.saveSettings(st);
      const tabs = el('div', 'btn-row tabs');
      box.appendChild(tabs);
      const body = el('div', 'settings-body');
      box.appendChild(body);
      const current = tab || 'game';
      for (const [id, label] of [['game', 'Игра'], ['controls', 'Управление'], ['video', 'Графика'], ['skin', 'Скин'], ['scripts', 'Скрипты'], ['pvp', 'PvP']]) {
        const b = this.button(tabs, label, () => this.showSettings(back, id), { small: true });
        if (id === current) b.classList.add('sel');
      }
      const check = (label, value, onChange) => {
        const w = el('label', 'mc-check');
        const i = el('input');
        i.type = 'checkbox';
        i.checked = !!value;
        i.addEventListener('change', () => onChange(i.checked));
        w.appendChild(i);
        w.appendChild(document.createTextNode(' ' + label));
        body.appendChild(w);
        return i;
      };
      const select = (label, options, value, onChange) => {
        const w = el('label', 'mc-field');
        w.appendChild(el('span', 'mc-label', label));
        const sel = el('select', 'mc-input');
        for (const [v, t] of options) {
          const o = el('option', null, t);
          o.value = v;
          if (value === v) o.selected = true;
          sel.appendChild(o);
        }
        sel.addEventListener('change', () => onChange(sel.value));
        w.appendChild(sel);
        body.appendChild(w);
        return sel;
      };

      if (current === 'game') {
        const nick = this.field(body, 'Ник (3-16 символов: латиница, цифры, _)', st.nickname, { maxLength: 16 });
        const nickErr = el('div', 'hint bad');
        body.appendChild(nickErr);
        nick.addEventListener('input', () => {
          const v = nick.value;
          if (/^[A-Za-z0-9_ ]{3,16}$/.test(v)) { st.nickname = v; save(); nickErr.textContent = ''; }
          else nickErr.textContent = 'Серверы MCPE принимают только латиницу, цифры, пробел и _ (3-16 символов)';
        });
        if (this.app.game && this.app.game.mode === 'mp') body.appendChild(el('div', 'hint', 'Новый ник и скин сервер увидит после переподключения.'));
        body.appendChild(el('div', 'mc-label', 'Устройство для серверов'));
        const devOpts = Object.entries(MC.Storage.DEVICES).map(([k, d]) => [k, d.name]);
        const inOpts = Object.entries(MC.Storage.INPUTS).map(([k, d]) => [k, d.name]);
        const devInfo = el('div', 'hint');
        const showDev = () => { devInfo.textContent = 'Сервер увидит: ' + MC.Storage.deviceInfo(st, null, this.app.input ? this.app.input.touchMode : false).label + '. У каждого сервера можно выбрать своё (кнопка «Изменить» в списке серверов).'; };
        select('Платформа', devOpts, st.device || 'auto', (v) => { st.device = v; save(); showDev(); });
        select('Управление', inOpts, st.inputMode || 'auto', (v) => { st.inputMode = v; save(); showDev(); });
        const model = this.field(body, 'Модель устройства (необязательно)', st.deviceModel || '', { maxLength: 40, placeholder: 'по умолчанию — как у платформы' });
        model.addEventListener('input', () => { st.deviceModel = model.value.trim(); save(); });
        body.appendChild(devInfo);
        showDev();
        body.appendChild(el('div', 'hint', 'Некоторые серверы пускают только определённые устройства (например, только Windows 10 или только телефоны) или подбирают соперников по управлению. Это то, что игра сообщает серверу при входе; само управление при этом не меняется. Новые настройки действуют со следующего подключения.'));
        this.slider(body, 'Громкость звука', 0, 1, 0.05, st.volume, (v) => Math.round(v * 100) + '%', (v) => { st.volume = v; save(); this.app.applySettings(); });
        this.folderBlock(body);
      } else if (current === 'controls') {
        select('Сенсорное управление', [['auto', 'Автоматически'], ['on', 'Включено'], ['off', 'Выключено (мышь и клавиатура)']], st.touch,
          (v) => { st.touch = v; save(); this.app.applySettings(); });
        select('Схема кнопок', [['dpad', 'Крестовина (как в Minecraft PE)'], ['joystick', 'Джойстик']], st.controls,
          (v) => { st.controls = v; save(); this.app.applySettings(); });
        this.slider(body, 'Размер кнопок', 0.6, 1.6, 0.05, st.buttonScale, (v) => Math.round(v * 100) + '%', (v) => { st.buttonScale = v; save(); this.app.applySettings(); });
        this.slider(body, 'Непрозрачность кнопок', 0.2, 1, 0.05, st.buttonOpacity, (v) => Math.round(v * 100) + '%', (v) => { st.buttonOpacity = v; save(); this.app.applySettings(); });
        this.slider(body, 'Чувствительность', 0.2, 3, 0.1, st.sensitivity, (v) => Math.round(v * 100) + '%', (v) => { st.sensitivity = v; save(); });
        check('Инвертировать обзор по вертикали', st.invertY, (v) => { st.invertY = v; save(); });
        check('Автопрыжок (сенсорное управление)', st.autoJump, (v) => { st.autoJump = v; save(); });
        check('Поменять прыжок и присед местами (для PvP)', st.swapJumpSneak, (v) => { st.swapJumpSneak = v; save(); this.app.applySettings(); });
        select('Бег', [['keep', 'Не сбрасывать: начатый бег продолжается, пока идёте вперёд'], ['auto', 'Авто-спринт: движение вперёд — всегда бег'], ['hold', 'Только пока зажат (Ctrl или двойное «вперёд»)']],
          st.sprintMode || (st.autoSprint ? 'auto' : 'keep'), (v) => { st.sprintMode = v; st.autoSprint = v === 'auto'; save(); });
        select('Помощь в прицеливании', [['off', 'Выключена'], ['weak', 'Слабая'], ['normal', 'Обычная'], ['strong', 'Сильная']],
          st.aimAssist === false ? 'off' : st.aimLevel || 'normal', (v) => { st.aimAssist = v !== 'off'; if (v !== 'off') st.aimLevel = v; save(); });
        check('Подсвечивать цель рамкой (жёлтая — выбрана помощью)', st.aimHighlight !== false, (v) => { st.aimHighlight = v; save(); });
        body.appendChild(el('div', 'hint', 'Помощь в прицеливании расширяет рамку цели: удар засчитывается, даже если прицел чуть мимо (сильнее — шире). Когда вы сами поворачиваете камеру или бьёте, прицел мягко подтягивается к цели (на сенсоре и геймпаде сильнее, с мышью слабее), над целью обзор замедляется. Цель под прицелом обведена рамкой. Сквозь блоки помощь не работает, дальность удара не меняется.'));
        body.appendChild(el('div', 'hint', 'Геймпад (Xbox, PlayStation, Bluetooth): левый стик — ходьба, правый — обзор, A — прыжок, B — выбросить, X — инвентарь, Y — вид камеры, RT — удар, LT — использовать (лук, еда, блоки), LB/RB — панель предметов, нажатие левого стика — бег, правого — присесть, Start — пауза.'));
        body.appendChild(el('div', 'hint', 'Крестовина: двойное касание «вверх» — бег, центр — присесть (или прыжок, если поменять местами: тогда палец можно вести с «вперёд» на центр, движение продолжится и будет прыжок). Прыжок справа, двойной прыжок в творческом режиме — полёт. Касание экрана — поставить блок или ударить, удержание — ломать. Лук: держите палец на экране (можно водить им и целиться) — тетива натягивается, отпустите — выстрел. Еда и зелья: удерживайте палец.'));
      } else if (current === 'video') {
        this.slider(body, 'Дальность прорисовки', 2, 16, 1, st.renderDistance, (v) => v + ' чанков', (v) => { st.renderDistance = v; save(); this.app.applySettings(); });
        this.slider(body, 'Поле зрения', 50, 110, 1, st.fov, (v) => v + '°', (v) => { st.fov = v; save(); this.app.applySettings(); });
        select('Вид камеры', [['first', 'От первого лица'], ['back', 'От третьего лица (сзади)'], ['front', 'От третьего лица (спереди)']], st.camera || 'first',
          (v) => { st.camera = v; save(); });
        select('Шейдеры', [['fast', 'Быстро (для слабых устройств)'], ['fancy', 'Красиво: небо, туман, качание листвы и воды'], ['pack', 'Из шейдер-пака (.mcpack)']], st.shaders,
          (v) => { st.shaders = v; save(); this.app.applySettings(); });
        const r = this.app.renderer;
        body.appendChild(el('div', 'hint', r && r.packStatus ? r.packStatus : 'Шейдер-пак не загружен: добавьте .mcpack с папками materials и shaders в «Текстур-паки» и перезапустите игру.'));
        this.slider(body, 'Разрешение рендера', 0.4, 1, 0.05, st.renderScale, (v) => Math.round(v * 100) + '%', (v) => { st.renderScale = v; save(); this.app.applySettings(); });
        check('Авто-разрешение: снижать разрешение, когда FPS падает ниже 28', st.autoRes !== false, (v) => { st.autoRes = v; save(); this.app.applySettings(); });
        this.slider(body, 'Яркость', 0.6, 1.6, 0.05, typeof st.brightness === 'number' ? st.brightness : 1, (v) => Math.round(v * 100) + '%', (v) => { st.brightness = v; save(); this.app.applySettings(); });
        check('Покачивание камеры при ходьбе', st.viewBob !== false, (v) => { st.viewBob = v; save(); });
        check('Облака', st.clouds, (v) => { st.clouds = v; save(); this.app.applySettings(); });
        select('Частицы', [['all', 'Все'], ['less', 'Меньше (для слабых устройств)'], ['off', 'Выключены']], st.particles || 'all',
          (v) => { st.particles = v; save(); this.app.applySettings(); });
        check('FPS и координаты в углу', st.showInfo !== false, (v) => { st.showInfo = v; save(); });
        check('Показывать пинг на сервере', st.showPing !== false, (v) => { st.showPing = v; save(); });
        check('Переподключаться при обрыве связи', st.autoReconnect !== false, (v) => { st.autoReconnect = v; save(); });
        body.appendChild(el('div', 'hint', 'На слабом телефоне: шейдеры «Быстро», разрешение 50-70%, дальность 4 чанка.'));
        const packRow = el('div', 'btn-row');
        body.appendChild(packRow);
        this.button(packRow, 'Текстур-паки (.mcpack)', () => this.showPacks(() => this.showSettings(back, 'video')));
      } else if (current === 'scripts') {
        this.scriptsTab(body);
      } else if (current === 'pvp') {
        this.pvpTab(body, check, select, () => this.showSettings(back, 'pvp'));
      } else {
        const skinRow = el('div', 'skin-row');
        const prev = el('img', 'skin-prev');
        const skinBytes = st.skin ? MC.Skin.fromBase64(st.skin) : MC.Skin.defaultSkin();
        prev.src = MC.Skin.facePreview(skinBytes);
        skinRow.appendChild(prev);
        const skinInfo = el('div', 'hint', st.skin ? 'Свой скин' : 'Стандартный скин (Стив)');
        skinRow.appendChild(skinInfo);
        const file = el('input');
        file.type = 'file';
        file.accept = 'image/png';
        file.style.display = 'none';
        const applySkin = () => {
          const g = this.app.game;
          if (g) { g.ownSkin = null; this.app.renderer.dropSkin('self'); }
        };
        file.addEventListener('change', async () => {
          if (!file.files[0]) return;
          try {
            const bytes = await MC.Skin.loadSkinFile(file.files[0]);
            st.skin = MC.Skin.toBase64(bytes);
            save();
            applySkin();
            prev.src = MC.Skin.facePreview(bytes);
            skinInfo.textContent = 'Свой скин загружен';
          } catch (e) {
            skinInfo.textContent = e.message;
          }
        });
        skinRow.appendChild(file);
        body.appendChild(skinRow);
        const row = el('div', 'btn-row');
        body.appendChild(row);
        this.button(row, 'Загрузить скин (PNG)', () => file.click());
        this.button(row, 'Стандартный скин', () => { st.skin = null; save(); applySkin(); prev.src = MC.Skin.facePreview(MC.Skin.defaultSkin()); skinInfo.textContent = 'Стандартный скин (Стив)'; });
        body.appendChild(el('div', 'hint', 'Скин 64x32 или 64x64 пикселя в формате PNG.'));
        // Скины из папки игры (подпапка skins или корень)
        const folderSkins = el('div', 'btn-row');
        body.appendChild(folderSkins);
        const showFolderSkins = () => {
          folderSkins.innerHTML = '';
          for (const f of MC.GameFolder.skins) {
            this.button(folderSkins, f.name.replace(/\.png$/i, ''), async () => {
              try {
                const bytes = await MC.Skin.loadSkinFile(await MC.GameFolder.readFile(f));
                st.skin = MC.Skin.toBase64(bytes);
                save();
                applySkin();
                prev.src = MC.Skin.facePreview(bytes);
                skinInfo.textContent = 'Скин из папки: ' + f.name;
              } catch (e) { skinInfo.textContent = e.message; }
            }, { small: true });
          }
        };
        if (MC.GameFolder.available()) {
          MC.GameFolder.name().then(async (n) => {
            if (!n) return;
            if (!MC.GameFolder.skins.length) { try { await MC.GameFolder.sync(false); } catch (e) { /* папка недоступна */ } }
            showFolderSkins();
          });
        }
      }
      this.button(box, 'Готово', back);
    }

    // Папка игры в хранилище: выбор и импорт новых паков, скриптов и скинов
    folderBlock(body) {
      body.appendChild(el('div', 'mc-label', 'Папка игры'));
      const info = el('div', 'hint');
      body.appendChild(info);
      if (!MC.GameFolder.available()) {
        info.textContent = 'В этом браузере папку выбрать нельзя: она работает в APK и в Chrome/Edge на компьютере.';
        return;
      }
      const showName = async () => {
        const n = await MC.GameFolder.name();
        info.textContent = n ? 'Выбрана папка «' + n + '». Кладите туда .mcpack/.zip (в packs), .js (в scripts), скины .png (в skins) и схемы .schematic/.schem/.litematic/.nbt (в schematics) — новые файлы добавятся при запуске игры или по кнопке «Обновить».'
          : 'Папка не выбрана. Создайте в хранилище папку, например MinecraftHTML, и выберите её: игра создаст в ней packs, scripts и skins.';
      };
      showName();
      const row = el('div', 'btn-row');
      body.appendChild(row);
      const status = el('div', 'hint');
      this.button(row, 'Выбрать папку', async () => {
        try {
          const ok = await MC.GameFolder.pick();
          if (!ok) { status.textContent = 'Папка не выбрана'; return; }
          await showName();
          const r = await MC.GameFolder.sync(true);
          status.textContent = MC.GameFolder.summary(r) + (r.packs ? ' Перезапустите игру, чтобы применить паки.' : '');
          if (r.scripts && this.app.game) await MC.Scripts.reload(this.app.game);
        } catch (e) { if (e.name !== 'AbortError') status.textContent = 'Ошибка: ' + e.message; }
      });
      this.button(row, 'Обновить', async () => {
        status.textContent = 'Проверяю папку...';
        try {
          const r = await MC.GameFolder.sync(true);
          status.textContent = MC.GameFolder.summary(r) + (r.packs ? ' Перезапустите игру, чтобы применить паки.' : '');
          if (r.scripts && this.app.game) await MC.Scripts.reload(this.app.game);
        } catch (e) { status.textContent = 'Ошибка: ' + e.message; }
      });
      body.appendChild(status);
    }

    // Вкладка «Скрипты»: загрузка .js из файлов, включение и удаление; в запущенной игре перезапускаются сразу
    // Better PvP: интерфейс боя, миникарта и точки маршрута
    pvpTab(body, check, select, reopen) {
      const st = this.app.settings;
      const c = MC.PvP.settings(st);
      const save = () => MC.Storage.saveSettings(st);
      const sub = (t) => body.appendChild(el('div', 'mc-label eb-name', t));
      sub('Бой');
      check('Панель цели: имя, расстояние, здоровье (здоровье — в одиночной игре)', c.targetHud, (v) => { c.targetHud = v; save(); });
      check('Счётчик комбо', c.combo, (v) => { c.combo = v; save(); });
      check('Жёлтый прицел, когда удар будет критическим (в падении)', c.crit, (v) => { c.crit = v; save(); });
      check('Помощь в прицеливании: замедлять обзор над целью', c.aimSlow, (v) => { c.aimSlow = v; save(); });
      check('Красная рамка при здоровье ≤ 3 сердец', c.lowHp, (v) => { c.lowHp = v; save(); });
      check('Броня и прочность предметов', c.armorHud, (v) => { c.armorHud = v; save(); });
      check('Эффекты с таймерами', c.effects, (v) => { c.effects = v; save(); });
      sub('Клиент (как Lunar / Badlion)');
      select('Клавиши на экране (WASD, ЛКМ/ПКМ с CPS)', [['auto', 'На компьютере'], ['on', 'Всегда'], ['off', 'Выключены']], c.keystrokes, (v) => { c.keystrokes = v; save(); });
      check('Счётчик CPS (кликов в секунду)', c.cps, (v) => { c.cps = v; save(); });
      select('Зум (C или кнопка 🔍, колесо мыши меняет)', [['2', '×2'], ['4', '×4'], ['8', '×8']], String(c.zoom), (v) => { c.zoom = Number(v); save(); });
      check('Плавный зум', c.smoothZoom, (v) => { c.smoothZoom = v; save(); });
      check('Динамический FOV при беге', c.dynamicFov, (v) => { c.dynamicFov = v; save(); });
      check('Наклон камеры при ударе', c.hurtCam, (v) => { c.hurtCam = v; save(); });
      select('Анимация руки', [['modern', 'Обычная (как в Minecraft PE)'], ['old', 'Старая 1.7 (PvP): рука ниже, взмах шире']], c.handStyle || 'modern', (v) => { c.handStyle = v; save(); });
      check('Частицы при ударе (криты и зачарования)', c.hitParticles !== false, (v) => { c.hitParticles = v; save(); });
      sub('Моды с ПК');
      body.appendChild(el('div', 'hint', 'Как в Lunar, Badlion и Feather. Всё работает только у вас на экране, поэтому разрешено и на серверах: сервер видит обычного игрока.'));
      check('Fullbright: всё светло, даже в пещерах и ночью', !!c.fullbright, (v) => { c.fullbright = v; save(); });
      select('Присед на клавиатуре (Toggle Sneak)', [['hold', 'Держать Shift'], ['toggle', 'Нажать Shift один раз']], c.sneakMode || 'hold', (v) => { c.sneakMode = v; save(); });
      check('Дистанция удара (Reach Display)', c.reach !== false, (v) => { c.reach = v; save(); });
      check('Компас сверху (стороны света и градусы)', c.compass !== false, (v) => { c.compass = v; save(); });
      check('Счётчик предметов: стрелы, тотемы, золотые яблоки, жемчуг', c.packDisplay !== false, (v) => { c.packDisplay = v; save(); });
      check('Насыщение и истощение (AppleSkin)', c.saturation !== false, (v) => { c.saturation = v; save(); });
      check('Таймер над динамитом (TNT Timer)', c.tntTimer !== false, (v) => { c.tntTimer = v; save(); });
      check('Сила натяжения лука под прицелом', c.bowCharge !== false, (v) => { c.bowCharge = v; save(); });
      check('Блокирование мечом при удержании (анимация 1.7)', c.blockHit !== false, (v) => { c.blockHit = v; save(); });
      check('Предупреждать, когда броня или оружие почти сломаны', c.durAlert !== false, (v) => { c.durAlert = v; save(); });
      select('Время суток на экране (Time Changer)', [['off', 'Как в мире'], ['day', 'Всегда день'], ['sunset', 'Закат'], ['night', 'Ночь']], c.timeChanger || 'off', (v) => { c.timeChanger = v; save(); });
      check('Прозрачная вода (Clear Water)', !!c.clearWater, (v) => { c.clearWater = v; save(); });
      check('Складывать одинаковые сообщения в чате', c.compactChat !== false, (v) => { c.compactChat = v; save(); });
      check('Время у сообщений чата', !!c.chatTime, (v) => { c.chatTime = v; save(); });
      check('Auto GG: писать в чат после победы в мини-игре', !!c.autoGG, (v) => { c.autoGG = v; save(); });
      const gg = this.field(body, 'Текст Auto GG', c.ggText || 'gg', { maxLength: 60 });
      gg.addEventListener('change', () => { c.ggText = gg.value.trim() || 'gg'; save(); });
      sub('Прицел и обводка');
      select('Прицел', [['circle', 'Круг'], ['cross', 'Крест'], ['dot', 'Точка'], ['square', 'Квадрат']], c.crosshair, (v) => { c.crosshair = v; save(); });
      select('Цвет прицела', [['white', 'Белый'], ['green', 'Зелёный'], ['red', 'Красный'], ['cyan', 'Голубой'], ['yellow', 'Жёлтый'], ['pink', 'Розовый']], c.crossColor, (v) => { c.crossColor = v; save(); });
      select('Обводка блока', [['black', 'Чёрная'], ['white', 'Белая'], ['red', 'Красная'], ['cyan', 'Голубая'], ['green', 'Зелёная'], ['rainbow', 'Радуга']], c.outline, (v) => { c.outline = v; save(); });
      body.appendChild(el('div', 'hint', 'Свободный обзор: зажмите левый Alt или кнопку 👁 — камера крутится вокруг игрока, а сам он смотрит туда же, куда и раньше.'));
      sub('Миникарта');
      check('Миникарта', c.minimap, (v) => { c.minimap = v; save(); });
      check('Поворачивать по взгляду (иначе север сверху)', c.mapRotate, (v) => { c.mapRotate = v; save(); });
      check('Существа и игроки на карте', c.mapEntities, (v) => { c.mapEntities = v; save(); });
      this.slider(body, 'Размер миникарты', 80, 220, 4, c.mapSize, (v) => v + ' px', (v) => { c.mapSize = v; save(); });
      select('Масштаб (касание карты тоже меняет)', [['1', '1 блок = 1 px'], ['2', '1 блок = 2 px'], ['4', '1 блок = 4 px']], String(c.mapZoom), (v) => { c.mapZoom = Number(v); save(); });
      sub('Точки маршрута');
      check('Показывать точки на карте и в мире', c.waypoints, (v) => { c.waypoints = v; save(); });
      check('Ставить точку на месте смерти', c.deathPoint, (v) => { c.deathPoint = v; save(); });
      const g = this.app.game;
      if (!g || !g.pvp) { body.appendChild(el('div', 'hint', 'Точки маршрута хранятся отдельно для каждого мира и сервера: добавить их можно из игры (пауза → Настройки → PvP или клавиша N).')); return; }
      const pv = g.pvp;
      const nameF = this.field(body, 'Название новой точки', '', { maxLength: 24 });
      this.button(body, 'Добавить точку здесь (' + Math.floor(g.player.x) + ' ' + Math.floor(g.player.y) + ' ' + Math.floor(g.player.z) + ')', () => { pv.addWaypoint(nameF.value.trim()); reopen(); }, { small: true });
      if (!pv.waypoints.length) body.appendChild(el('div', 'hint', 'Точек пока нет.'));
      pv.waypoints.forEach((w, i) => {
        const r = el('div', 'eb-row');
        const n = el('span', 'eb-name', w.name + ' — ' + w.x + ' ' + w.y + ' ' + w.z);
        n.style.color = w.color;
        r.appendChild(n);
        const t = this.button(r, w.on ? 'Видна' : 'Скрыта', () => { w.on = !w.on; pv.saveWaypoints(); reopen(); }, { small: true });
        if (w.on) t.classList.add('on');
        this.button(r, 'Удалить', () => { pv.removeWaypoint(i); reopen(); }, { small: true });
        body.appendChild(r);
      });
    }

    scriptsTab(body) {
      const list = el('div', 'list');
      body.appendChild(list);
      const status = el('div', 'hint');
      const file = el('input');
      file.type = 'file';
      // Без фильтра типов: в Android WebView фильтр «.js» превращается в неверный MIME и файлы не видны
      file.accept = '';
      file.style.display = 'none';
      body.appendChild(file);
      const applyNow = async () => {
        const g = this.app.game;
        if (g && g.ready && !g.stopped) { await MC.Scripts.reload(g); status.textContent = 'Скрипты перезапущены в текущей игре'; }
      };
      const render = async () => {
        list.innerHTML = '';
        let scripts = [];
        try { scripts = await MC.Scripts.list(); } catch (e) { status.textContent = 'Хранилище недоступно: ' + e.message; return; }
        if (!scripts.length) list.appendChild(el('div', 'empty', 'Скриптов нет. Загрузите файл .js — он получит объект mc с API игры.'));
        for (const s of scripts) {
          const row = el('div', 'list-item pack-row');
          const info = el('div', 'craft-info');
          info.appendChild(el('div', 'li-title', s.name));
          info.appendChild(el('div', 'li-sub', (s.size / 1024).toFixed(1) + ' КБ · ' + new Date(s.updated).toLocaleString()));
          const on = el('label', 'mc-check');
          const cb = el('input');
          cb.type = 'checkbox';
          cb.checked = !!s.enabled;
          cb.addEventListener('change', async () => { await MC.Scripts.setEnabled(s.id, cb.checked); await applyNow(); });
          on.appendChild(cb);
          on.appendChild(document.createTextNode(' Включён'));
          info.appendChild(on);
          row.appendChild(info);
          const btns = el('div', 'btn-row');
          this.button(btns, 'Удалить', async () => { await MC.Scripts.remove(s.id); await applyNow(); render(); }, { small: true });
          row.appendChild(btns);
          list.appendChild(row);
        }
      };
      file.addEventListener('change', async () => {
        const files = [...file.files];
        file.value = '';
        const msgs = [];
        for (const f of files) {
          try { msgs.push(await MC.Scripts.addFile(f)); } catch (e) { msgs.push(f.name + ': ' + e.message); }
        }
        status.textContent = msgs.join('; ');
        await applyNow();
        render();
      });
      const row = el('div', 'btn-row');
      body.appendChild(row);
      this.button(row, 'Загрузить скрипт (.js)', () => file.click());
      body.appendChild(status);
      body.appendChild(el('div', 'hint', 'Скрипт работает с полным доступом к игре: загружайте только свои или проверенные файлы. ' +
        'API: mc.on(\'tick\'|\'chat\'|\'message\'|\'blockBreak\'|\'blockPlace\'|\'attack\'|\'stop\', fn), mc.command(имя, fn), mc.print, mc.say, mc.popup, ' +
        'mc.player, mc.world, mc.inventory, mc.entities, mc.setTimeout/setInterval, mc.storage. Подробно — в README.'));
      render();
    }

    // Текстур-паки: список, включение, порядок, добавление .mcpack; применяются после перезапуска
    showPacks(back) {
      const box = this.screen('packs', { dirt: true, overlay: !!this.app.game });
      box.appendChild(el('h2', 'title', 'Текстур-паки'));
      const list = el('div', 'list');
      box.appendChild(list);
      const status = el('div', 'hint');
      box.appendChild(status);
      const file = el('input');
      file.type = 'file';
      // Без фильтра: в Android WebView фильтр «.mcpack» превращается в неверный MIME и файлы не видны
      file.accept = '';
      file.style.display = 'none';
      box.appendChild(file);
      let changed = false;
      const render = async () => {
        list.innerHTML = '';
        let packs = [];
        try { packs = await MC.Packs.list(); } catch (e) { status.textContent = 'Хранилище недоступно: ' + e.message; return; }
        if (!packs.length) list.appendChild(el('div', 'empty', 'Паков нет. Добавьте файл .mcpack (архив с manifest.json и папкой textures).'));
        packs.forEach((p, i) => {
          const row = el('div', 'list-item pack-row');
          const info = el('div', 'craft-info');
          info.appendChild(el('div', 'li-title', p.name + (p.version ? ' ' + p.version : '')));
          info.appendChild(el('div', 'li-sub', (p.description ? p.description + ' · ' : '') + p.textures + ' текстур' + (p.shaders ? ' · шейдеры' : '') + ' · ' + (p.size / 1024 / 1024).toFixed(1) + ' МБ'));
          const on = el('label', 'mc-check');
          const cb = el('input');
          cb.type = 'checkbox';
          cb.checked = !!p.enabled;
          cb.addEventListener('change', async () => { p.enabled = cb.checked; await MC.Packs.update(p); changed = true; status.textContent = 'Изменения применятся после перезапуска'; });
          on.appendChild(cb);
          on.appendChild(document.createTextNode(' Включён'));
          info.appendChild(on);
          row.appendChild(info);
          const btns = el('div', 'btn-row');
          const swap = async (j) => {
            const o = packs[j];
            const t = o.order; o.order = p.order; p.order = t;
            await MC.Packs.update(o); await MC.Packs.update(p);
            changed = true;
            render();
          };
          this.button(btns, '▲', () => swap(i - 1), { small: true, disabled: i === 0 });
          this.button(btns, '▼', () => swap(i + 1), { small: true, disabled: i === packs.length - 1 });
          this.button(btns, 'Удалить', async () => { await MC.Packs.remove(p.id); changed = true; status.textContent = 'Изменения применятся после перезапуска'; render(); }, { small: true });
          row.appendChild(btns);
          list.appendChild(row);
        });
      };
      file.addEventListener('change', async () => {
        if (!file.files[0]) return;
        status.textContent = 'Читаю ' + file.files[0].name + '...';
        try {
          const p = await MC.Packs.addFile(file.files[0]);
          changed = true;
          if (p.shaders) { this.app.settings.shaders = 'pack'; MC.Storage.saveSettings(this.app.settings); }
          status.textContent = 'Добавлен: ' + p.name + ' (' + p.textures + ' текстур' + (p.shaders ? ', шейдеры: ' + p.shaders + ' файлов' : '') + '). Нажмите «Перезапустить»';
        } catch (e) {
          status.textContent = 'Ошибка: ' + e.message;
        }
        file.value = '';
        render();
      });
      box.appendChild(el('div', 'hint', 'Верхний пак в списке накладывается первым, нижние перекрывают его. Поддерживаются блоки, предметы, существа, интерфейс, небо и скин Стива из папки textures, а также GLSL-шейдеры MCPE 1.x (materials + shaders/glsl).'));
      const row = el('div', 'btn-row');
      box.appendChild(row);
      this.button(row, 'Добавить .mcpack', () => file.click());
      this.button(row, 'Перезапустить', () => { if (this.app.game && this.app.game.mode === 'sp') this.app.game.save().finally(() => location.reload()); else location.reload(); });
      this.button(box, 'Готово', () => { if (changed) status.textContent = 'Не забудьте перезапустить игру'; back(); });
      render();
    }

    showConnecting(text, onCancel) {
      this.showPanorama(false);
      let box = this.root.querySelector('.screen-connecting');
      if (!box || this.current !== 'connecting') {
        box = this.screen('connecting', { dirt: true });
        box.appendChild(el('h2', 'title', 'Подключение'));
        box.appendChild(el('div', 'status'));
        this.button(box, 'Отмена', onCancel);
      }
      box.querySelector('.status').textContent = text;
    }

    // extra — дополнительные кнопки [[надпись, действие]], они идут перед «OK»
    showMessage(title, text, onOk, extra, okLabel) {
      this.showPanorama(false);
      const box = this.screen('message', { dirt: true });
      box.appendChild(el('h2', 'title', title));
      const t = el('div', 'status');
      t.appendChild(MC.formatted(text));
      box.appendChild(t);
      for (const [label, fn] of extra || []) this.button(box, label, fn);
      this.button(box, okLabel || 'OK', onOk);
      return box;
    }

    showPause(game) {
      const box = this.screen('pause', { overlay: true });
      box.appendChild(el('h2', 'title', 'Пауза'));
      this.button(box, 'Продолжить', () => this.app.resume());
      if (game.mode === 'mp') this.button(box, 'Игроки', () => this.showPlayers(game, () => this.showPause(game)));
      this.button(box, 'Настройки', () => this.showSettings(() => this.showPause(game)));
      this.button(box, game.mode === 'mp' ? 'Отключиться' : 'Сохранить и выйти', () => this.app.quitToTitle());
    }

    // Список игроков: голова из скина, ник с цветами сервера, пинг и адрес сервера
    showPlayers(game, back) {
      const box = this.screen('players', { overlay: true });
      const me = this.app.settings.nickname;
      const list = Array.from(game.playerInfo.values());
      // Nukkit не присылает игроку его самого: добавляем себя со своим скином
      if (!list.some((p) => MC.stripFormat(p.name) === me)) list.push({ name: me, skin: game.ownSkin || null });
      list.sort((a, b) => MC.stripFormat(a.name).localeCompare(MC.stripFormat(b.name)));
      box.appendChild(el('h2', 'title', 'Игроки на сервере: ' + list.length));
      const ping = game.client && game.client.rak ? Math.round(game.client.rak.latency || 0) : 0;
      box.appendChild(el('div', 'hint', game.opts.server.host + ':' + game.opts.server.port + ' · ваш пинг ' + ping + ' мс'));
      const grid = el('div', 'plist');
      for (const p of list) {
        const row = el('div', 'plist-row' + (MC.stripFormat(p.name) === me ? ' me' : ''));
        const head = el('img', 'plist-head');
        head.src = MC.Skin.facePreview(p.skin || MC.Skin.defaultSkin());
        row.appendChild(head);
        const n = el('span', 'plist-name');
        n.appendChild(MC.formatted(p.name));
        row.appendChild(n);
        grid.appendChild(row);
      }
      box.appendChild(grid);
      this.button(box, 'Назад', back);
    }

    // Титры после первого выхода из Края с побеждённым драконом. Текст свой: поэма Края из Minecraft
    // защищена авторским правом и сюда не копируется
    showCredits(game) {
      const app = this.app;
      app.active = false;
      app.input.setEnabled(false);
      const box = this.screen('credits', { overlay: true });
      const view = el('div', 'credits-view');
      const roll = el('div', 'credits-roll');
      const rec = game.record || {};
      const kills = rec.dragonKills || 1;
      const lines = [
        ['h', 'Игра пройдена!'],
        ['p', 'Дракон Края повержен' + (kills > 1 ? ' (побед: ' + kills + ')' : '') + '.'],
        ['p', 'Мир «' + (rec.name || 'Мир') + '» помнит ваш путь: из обычного мира в Нижний, через крепость к стержням ифрита, к глазам Края и порталу в крепости.'],
        ['g', ''],
        ['h', 'Что дальше'],
        ['p', 'В центре острова стоят новые врата Края. Бросьте в них жемчуг или пройдите — они ведут к внешним островам.'],
        ['p', 'Там стоят города Края с шалкерами и сундуками, а у некоторых городов причален корабль с элитрами.'],
        ['p', 'Поставьте четыре кристалла Края по сторонам портала выхода, и дракон вернётся.'],
        ['g', ''],
        ['h', 'Minecraft HTML'],
        ['p', 'Свободная реализация игры в стиле Minecraft на JavaScript и WebGL для браузера и Android.'],
        ['p', 'Текстуры и звуки взяты из ресурсов Minecraft Pocket Edition. Minecraft — товарный знак Mojang Studios и Microsoft; этот проект с ними не связан.'],
        ['g', ''],
        ['h', 'Спасибо за игру'],
        ['p', 'Нажмите «Продолжить», чтобы вернуться в мир.']
      ];
      for (const [k, t] of lines) roll.appendChild(el(k === 'h' ? 'h3' : 'div', k === 'h' ? 'credits-h' : k === 'g' ? 'credits-gap' : 'credits-p', t));
      view.appendChild(roll);
      box.appendChild(view);
      const done = () => { if (this.current === 'credits') app.resume(); };
      roll.addEventListener('animationend', done);
      this.button(box, 'Продолжить', done, { small: true });
      MC.Sound.play('random.levelup', null, 1, 0.8);
    }

    showDeath(cause) {
      const box = this.screen('death', { overlay: true });
      box.classList.add('red');
      box.appendChild(el('h2', 'title', 'Вы погибли!'));
      if (cause) box.appendChild(el('div', 'status', cause));
      this.button(box, 'Возродиться', () => this.app.respawn());
      this.button(box, 'Выйти в меню', () => this.app.quitToTitle());
    }

    // Полоска прочности инструмента или брони (data — износ)
    durability(cell, it) {
      const max = MC.Survival.durabilityOf(it.id);
      if (!max || !it.data) return;
      const left = Math.max(0, 1 - it.data / max);
      const bar = el('div', 'dur');
      const fill = el('div', 'dur-fill');
      fill.style.width = Math.round(left * 100) + '%';
      fill.style.background = 'hsl(' + Math.round(left * 120) + ', 90%, 45%)';
      bar.appendChild(fill);
      cell.appendChild(bar);
    }

    // Анимация тотема бессмертия: иконка вылетает в центр экрана, вращается и исчезает
    totemPop() {
      const img = el('img', 'totem-pop');
      img.src = MC.Items.icon(450, 0);
      img.addEventListener('animationend', () => img.remove());
      this.hHurt.parentNode.appendChild(img);
    }

    flashHurt() {
      this.hHurt.classList.remove('on');
      void this.hHurt.offsetWidth;
      this.hHurt.classList.add('on');
    }

    setAir(value) {
      const key = value === null ? 'n' : String(value);
      if (this.airKey === key) return;
      this.airKey = key;
      this.hAir.innerHTML = '';
      if (value === null) return;
      for (let i = 0; i < 10; i++) {
        if (i >= value) break;
        const img = el('img');
        img.src = this.sprites.bubble;
        img.alt = '';
        this.hAir.insertBefore(img, this.hAir.firstChild);
      }
    }

    // ---------- HUD ----------
    buildHud() {
      const h = this.hud;
      h.innerHTML = '';
      this.hCross = el('div', 'crosshair');
      h.appendChild(this.hCross);
      this.hDebug = el('div', 'debug');
      h.appendChild(this.hDebug);
      this.hChat = el('div', 'chat');
      h.appendChild(this.hChat);
      this.hTitle = el('div', 'htitle');
      h.appendChild(this.hTitle);
      this.hSub = el('div', 'hsub');
      h.appendChild(this.hSub);
      this.hPopup = el('div', 'popup');
      h.appendChild(this.hPopup);
      this.hBuild = el('div', 'buildhint');
      h.appendChild(this.hBuild);
      this.buildHintText = '';
      const bottom = el('div', 'bottom');
      h.appendChild(bottom);
      const stats = el('div', 'stats');
      this.hArmor = el('div', 'armor');
      bottom.appendChild(this.hArmor);
      this.hHearts = el('div', 'hearts');
      this.hFood = el('div', 'food');
      stats.appendChild(this.hHearts);
      stats.appendChild(this.hFood);
      this.hAir = el('div', 'air');
      bottom.appendChild(this.hAir);
      bottom.appendChild(stats);
      // Полоса опыта с уровнем, как в Minecraft
      this.hXp = el('div', 'xpbar');
      this.hXpFill = el('div', 'xpfill');
      this.hXp.appendChild(this.hXpFill);
      this.hXpLevel = el('div', 'xplevel');
      this.hXp.appendChild(this.hXpLevel);
      bottom.appendChild(this.hXp);
      this.hHurt = el('div', 'hurt');
      h.insertBefore(this.hHurt, h.firstChild);
      this.hBar = el('div', 'hotbar');
      this.hSel = el('div', 'hb-sel');
      this.hBar.appendChild(this.hSel);
      this.hSlots = [];
      for (let i = 0; i < 9; i++) {
        const s = el('div', 'hb-slot');
        s.addEventListener('click', () => this.app.selectHotbar(i));
        s.addEventListener('touchstart', (e) => { e.preventDefault(); this.app.selectHotbar(i); }, { passive: false });
        this.hBar.appendChild(s);
        this.hSlots.push(s);
      }
      bottom.appendChild(this.hBar);
      this.hItemName = el('div', 'itemname');
      h.appendChild(this.hItemName);
      this.hTags = el('div', 'tags');
      this.tagEls = new Map();
      h.appendChild(this.hTags);
      this.chatInputWrap = el('form', 'chat-input');
      this.chatInput = el('input');
      this.chatInput.maxLength = 255;
      this.chatInput.autocomplete = 'off';
      this.chatInputWrap.appendChild(this.chatInput);
      const send = el('button', 'mc-btn small', 'Отправить');
      send.type = 'submit';
      this.chatInputWrap.appendChild(send);
      this.chatInputWrap.addEventListener('submit', (e) => {
        e.preventDefault();
        const v = this.chatInput.value.trim();
        this.closeChat();
        if (v) { this.rememberChat(v); this.app.sendChat(v); }
      });
      // История сообщений: стрелки вверх/вниз, как в игре
      this.chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') { e.preventDefault(); this.closeChat(); return; }
        if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
        e.preventDefault();
        const hist = this.chatHistory();
        if (!hist.length) return;
        this.chatHistPos = Math.max(-1, Math.min(hist.length - 1, this.chatHistPos + (e.key === 'ArrowUp' ? 1 : -1)));
        this.chatInput.value = this.chatHistPos < 0 ? '' : hist[hist.length - 1 - this.chatHistPos];
      });
      h.appendChild(this.chatInputWrap);
      // Последние команды кнопками над полем ввода: на телефоне не нужно набирать /spawn каждый раз
      this.chatRecent = el('div', 'chat-recent');
      h.appendChild(this.chatRecent);
    }

    showHud(v) { this.hud.style.display = v ? 'block' : 'none'; }

    setHotbar(items, selected) {
      for (let i = 0; i < 9; i++) {
        const s = this.hSlots[i];
        const it = items[i];
        const key = it && it.id ? it.id + ':' + it.data + ':' + it.count + ':' + (it.nbt ? it.nbt.length : 0) : '';
        const tool = it && it.id && MC.Survival.isTool(it.id);
        if (s.dataset.key === key) continue;
        s.dataset.key = key;
        s.innerHTML = '';
        if (it && it.id) {
          const img = el('img');
          img.src = MC.Items.icon(it.id, tool || it.data < 0 ? 0 : it.data);
          img.alt = '';
          s.appendChild(img);
          MC.Items.addGlint(s, it, img.src);
          if (it.count > 1) s.appendChild(el('span', 'cnt', String(it.count)));
          this.durability(s, it);
        }
      }
      this.hSel.style.left = 'calc(var(--u) * (' + (selected * 20 - 1) + '))';
    }

    showItemName(text) {
      this.hItemName.textContent = '';
      this.hItemName.appendChild(MC.formatted(text));
      this.hItemName.classList.remove('fade');
      void this.hItemName.offsetWidth;
      this.hItemName.classList.add('fade');
    }

    setStats(show, health, food, armor, xp) {
      this.hXp.style.display = show && xp ? 'block' : 'none';
      if (show && xp) {
        const w = Math.round(xp.progress * 1000) / 10 + '%';
        if (this.hXpFill.style.width !== w) this.hXpFill.style.width = w;
        const lt = xp.level > 0 ? String(xp.level) : '';
        if (this.hXpLevel.textContent !== lt) this.hXpLevel.textContent = lt;
      }
      this.hHearts.style.display = show ? 'flex' : 'none';
      this.hFood.style.display = show && food !== null ? 'flex' : 'none';
      this.hArmor.style.display = show && armor > 0 ? 'flex' : 'none';
      if (!show) return;
      const key = health + ':' + food + ':' + armor;
      if (this.statsKey === key) return;
      this.statsKey = key;
      const fill = (root, value, full, half, empty, rtl) => {
        root.innerHTML = '';
        for (let i = 0; i < 10; i++) {
          const v = value - i * 2;
          const img = el('img');
          img.src = v >= 2 ? full : v === 1 ? half : empty;
          img.alt = '';
          if (rtl) root.insertBefore(img, root.firstChild); else root.appendChild(img);
        }
      };
      fill(this.hHearts, Math.max(0, Math.ceil(health)), this.sprites.heartFull, this.sprites.heartHalf, this.sprites.heartEmpty, false);
      if (food !== null) fill(this.hFood, Math.max(0, Math.ceil(food)), this.sprites.foodFull, this.sprites.foodHalf, this.sprites.foodEmpty, true);
      if (armor > 0) fill(this.hArmor, armor, this.sprites.armorFull, this.sprites.armorHalf, this.sprites.armorEmpty, false);
    }

    addChat(text) {
      const pc = this.app.settings.pvp || {};
      // Compact Chat (мод): одинаковые строки подряд складываются в одну с счётчиком
      const last = this.hChat.lastElementChild;
      if (pc.compactChat !== false && last && last.dataset.raw === text) {
        const n = (Number(last.dataset.n) || 1) + 1;
        last.dataset.n = String(n);
        let cnt = last.querySelector('.chat-count');
        if (!cnt) { cnt = el('span', 'chat-count'); last.appendChild(cnt); }
        cnt.textContent = ' (×' + n + ')';
        last.dataset.t = String(performance.now());
        return;
      }
      const line = el('div', 'chat-line');
      line.dataset.raw = text;
      // Время у сообщений (мод Chat Timestamps)
      if (pc.chatTime) {
        const d = new Date();
        line.appendChild(el('span', 'chat-time', '[' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0') + '] '));
      }
      line.appendChild(MC.formatted(text));
      line.dataset.t = String(performance.now());
      this.hChat.appendChild(line);
      while (this.hChat.children.length > 60) this.hChat.removeChild(this.hChat.firstChild);
      this.hChat.scrollTop = this.hChat.scrollHeight;
    }

    updateChatFade() {
      const now = performance.now();
      for (const l of this.hChat.children) {
        const age = now - parseFloat(l.dataset.t);
        l.style.opacity = this.chatOpen ? '1' : age > 10000 ? '0' : age > 9000 ? String((10000 - age) / 1000) : '1';
      }
      this.hChat.classList.toggle('open', this.chatOpen);
    }

    openChat(prefix) {
      this.chatOpen = true;
      this.chatHistPos = -1;
      this.chatInputWrap.style.display = 'flex';
      this.chatInput.value = prefix || '';
      this.chatRecent.textContent = '';
      const seen = new Set();
      const hist = this.chatHistory();
      for (let i = hist.length - 1; i >= 0 && seen.size < 6; i--) {
        const v = hist[i];
        if (v[0] !== '/' || seen.has(v)) continue;
        seen.add(v);
        const b = el('button', 'chat-chip', v.length > 28 ? v.slice(0, 27) + '…' : v);
        b.type = 'button';
        b.addEventListener('pointerdown', (e) => e.preventDefault());
        b.addEventListener('click', () => { this.chatInput.value = v; this.chatInput.focus(); });
        this.chatRecent.appendChild(b);
      }
      this.chatRecent.style.display = seen.size ? 'flex' : 'none';
      setTimeout(() => this.chatInput.focus(), 0);
    }

    chatHistory() {
      if (!this.chatHist) {
        try { this.chatHist = JSON.parse(localStorage.getItem('mcpehtml.chatHistory') || '[]'); } catch (e) { this.chatHist = []; }
        if (!Array.isArray(this.chatHist)) this.chatHist = [];
      }
      return this.chatHist;
    }

    rememberChat(v) {
      const hist = this.chatHistory();
      if (hist[hist.length - 1] !== v) hist.push(v);
      if (hist.length > 50) hist.splice(0, hist.length - 50);
      try { localStorage.setItem('mcpehtml.chatHistory', JSON.stringify(hist)); } catch (e) { /* приватный режим: история только до перезапуска */ }
    }

    closeChat() {
      this.chatOpen = false;
      this.chatInputWrap.style.display = 'none';
      this.chatRecent.style.display = 'none';
      this.chatInput.blur();
      this.app.resume();
    }

    setTitle(title, sub, ms) {
      if (title !== null) { this.hTitle.textContent = ''; this.hTitle.appendChild(MC.formatted(title)); }
      if (sub !== null) { this.hSub.textContent = ''; this.hSub.appendChild(MC.formatted(sub)); }
      this.titleUntil = performance.now() + (ms || 3500);
    }

    setBuildHint(text) {
      if (text === this.buildHintText) return;
      this.buildHintText = text;
      this.hBuild.textContent = '';
      this.hBuild.appendChild(MC.formatted(text));
    }

    // ---------- Строительство (Effortless Building) и схемы (Schematica) ----------
    showBuild(game, tab) {
      const eb = game.building, sv = game.schematic;
      const box = this.screen('build', { overlay: true });
      box.classList.add('screen-settings');
      box.appendChild(el('h2', 'title', 'Строительство'));
      const tabs = el('div', 'btn-row tabs');
      box.appendChild(tabs);
      const body = el('div', 'settings-body');
      box.appendChild(body);
      const current = tab || this.buildTab || 'shapes';
      this.buildTab = current;
      for (const [id, label] of [['shapes', 'Фигуры'], ['mods', 'Модификаторы'], ['schem', 'Схемы']]) {
        const b = this.button(tabs, label, () => this.showBuild(game, id), { small: true });
        if (id === current) b.classList.add('sel');
      }
      const redraw = () => { const top = body.scrollTop; this.showBuild(game, current); const nb = this.root.querySelector('.settings-body'); if (nb) nb.scrollTop = top; };
      const row = () => { const r = el('div', 'btn-row eb-row'); body.appendChild(r); return r; };
      const label = (t) => body.appendChild(el('div', 'mc-label', t));
      const toggle = (parent, text, on, fn) => { const b = this.button(parent, text + (on ? ': вкл' : ': выкл'), () => { fn(!on); redraw(); }, { small: true }); if (on) b.classList.add('on'); return b; };
      const num = (parent, text, value, min, max, fn) => {
        const w = el('div', 'eb-num');
        w.appendChild(el('span', null, text));
        this.button(w, '−', () => { fn(Math.max(min, value - 1)); redraw(); }, { small: true });
        w.appendChild(el('span', 'eb-val', String(value)));
        this.button(w, '+', () => { fn(Math.min(max, value + 1)); redraw(); }, { small: true });
        parent.appendChild(w);
      };

      if (current === 'shapes') {
        label('Режим (ставить — «использовать», ломать фигурой — «ломать», другая кнопка отменяет)');
        const grid = el('div', 'eb-grid');
        body.appendChild(grid);
        for (const m of MC.Building.MODES) {
          const b = this.button(grid, m.name, () => { eb.setMode(m.id); redraw(); }, { small: true });
          if (eb.cfg.mode === m.id) b.classList.add('on');
        }
        const mode = eb.mode;
        if (mode.opts) {
          const r = row();
          for (const o of mode.opts) this.button(r, eb.optLabel(o), () => { eb.cycleOpt(o); redraw(); }, { small: true });
        }
        if (eb.cfg.mode === 'copy') {
          const r = row();
          this.button(r, 'Повернуть вставку 90°', () => { eb.rotateClip(); redraw(); }, { small: true, disabled: !eb.clip });
          this.button(r, 'Выделить заново', () => { eb.clip = null; eb.cancel(); redraw(); }, { small: true, disabled: !eb.clip });
          this.button(r, 'Сохранить как схему', async () => {
            const name = 'copy-' + new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');
            try {
              const s = MC.Schematics.fromClip(eb.clip, name);
              await MC.Schematics.store(s);
              const msg = await MC.Schematics.exportFile(s);
              this.setPopup(msg);
            } catch (e) { this.setPopup('§cНе сохранено: ' + e.message); }
            this.buildTab = 'schem';
            redraw();
          }, { small: true, disabled: !eb.clip });
          body.appendChild(el('div', 'hint', eb.clip ? 'В буфере ' + eb.clip.blocks.length + ' блоков' : 'Нажмите «использовать» на двух углах области'));
        }
        const r2 = row();
        toggle(r2, 'Заменять блоки', eb.cfg.replace, (v) => { eb.cfg.replace = v; eb.changed(); });
        if (game.gamemode !== 1) this.button(r2, eb.substLabel(), () => { eb.cycleSubst(); redraw(); }, { small: true });
        this.button(r2, '↶ Отменить', () => eb.undo(), { small: true });
        this.button(r2, '↷ Повторить', () => eb.redo(), { small: true });
        if (game.gamemode === 1) this.slider(body, 'Предел блоков за раз', 100, 50000, 100, eb.cfg.max, (v) => String(v), (v) => { eb.cfg.max = v; eb.changed(); });
        else if (game.mode === 'sp') body.appendChild(el('div', 'hint', 'Выживание: блоки берутся из инвентаря, при ломании выпадают как обычно. Если нужного блока нет, он заменяется похожим (доски другого дерева, другой камень) или любым обычным блоком — по кнопке «Нет нужных блоков».'));
        if (game.mode === 'mp') {
          this.slider(body, 'Скорость установки на сервере', 2, 40, 1, eb.cfg.netRate, (v) => v + ' бл/с', (v) => { eb.cfg.netRate = v; eb.changed(); });
          body.appendChild(el('div', 'hint', 'Сервер: блоки ставятся обычными пакетами по одному, только в радиусе досягаемости (подходите ближе к фигуре) и только к соседнему блоку. ' +
            (game.gamemode === 1 ? 'Нужный блок кладётся в выбранную ячейку панели.' : 'Выживание: нужные блоки берутся из инвентаря; ломать фигурами и отменять можно только в творческом.') +
            ' Ориентацию ступеней и брёвен задаёт сервер по взгляду. Высокая скорость может не понравиться античиту сервера.'));
          if (eb.net.length) this.button(body, 'Очистить очередь (' + eb.net.length + ' бл.)', () => { eb.clearNet(); this.showBuild(game, current); }, { small: true });
        }
      } else if (current === 'mods') {
        const m = eb.cfg.mirror, a = eb.cfg.array, rd = eb.cfg.radial;
        label('Отражение (центр — ' + m.cx + ' ' + m.cy + ' ' + m.cz + ')');
        let r = row();
        toggle(r, 'Отражение', m.on, (v) => { m.on = v; eb.changed(); });
        for (const ax of ['x', 'y', 'z']) toggle(r, ax.toUpperCase(), m[ax], (v) => { m[ax] = v; eb.changed(); });
        r = row();
        this.button(r, 'Центр — под игроком', () => { this.setPopup('Центр отражения: ' + eb.centerHere('mirror')); redraw(); }, { small: true });
        toggle(r, 'Между блоками', m.half, (v) => { m.half = v; eb.changed(); });
        label('Массив (повторить фигуру со сдвигом)');
        r = row();
        toggle(r, 'Массив', a.on, (v) => { a.on = v; eb.changed(); });
        num(r, 'Копий', a.count, 1, 64, (v) => { a.count = v; eb.changed(); });
        r = row();
        num(r, 'X', a.ox, -64, 64, (v) => { a.ox = v; eb.changed(); });
        num(r, 'Y', a.oy, -64, 64, (v) => { a.oy = v; eb.changed(); });
        num(r, 'Z', a.oz, -64, 64, (v) => { a.oz = v; eb.changed(); });
        label('Радиальное отражение (центр — ' + rd.cx + ' ' + rd.cz + ')');
        r = row();
        toggle(r, 'Радиальное', rd.on, (v) => { rd.on = v; eb.changed(); });
        num(r, 'Частей', rd.slices, 2, 32, (v) => { rd.slices = v; eb.changed(); });
        r = row();
        this.button(r, 'Центр — под игроком', () => { this.setPopup('Центр радиального отражения: ' + eb.centerHere('radial')); redraw(); }, { small: true });
        toggle(r, 'Чередовать', rd.alt, (v) => { rd.alt = v; eb.changed(); });
      } else {
        label('Схемы: .schematic (MCEdit, Schematica), .schem (WorldEdit), .litematic (Litematica), .nbt (структурный блок)');
        const r = row();
        const file = el('input');
        file.type = 'file';
        file.multiple = true;
        file.style.display = 'none';
        file.addEventListener('change', async () => {
          const msgs = [];
          for (const f of file.files) {
            try {
              const s = await MC.Schematics.addFile(f);
              msgs.push('«' + s.name + '» ' + s.w + '×' + s.h + '×' + s.l + ', ' + s.count + ' бл.' + (s.approx ? ', похожими заменено ' + s.approx : '') + (s.skipped ? ', без аналога в MCPE: ' + s.skipped : ''));
            } catch (e) { msgs.push(f.name + ': ' + e.message); }
          }
          this.setPopup(msgs.join('; '));
          redraw();
        });
        body.appendChild(file);
        this.button(r, 'Загрузить схему', () => file.click(), { small: true });
        if (sv.s) {
          label('Загружена «' + sv.s.name + '» ' + sv.s.w + '×' + sv.s.h + '×' + sv.s.l + ' в ' + sv.pos.x + ' ' + sv.pos.y + ' ' + sv.pos.z);
          let rr = row();
          this.button(rr, 'Сюда (под прицел)', () => {
            const hit = game.player.raycast(64);
            const p = game.player;
            // Без блока под прицелом — в 3 блоках перед игроком на уровне ног
            const yr = p.yaw * Math.PI / 180;
            sv.moveTo(hit ? eb.placePos(hit) : { x: Math.floor(p.x - Math.sin(yr) * 3), y: Math.floor(p.y), z: Math.floor(p.z + Math.cos(yr) * 3) });
            redraw();
          }, { small: true });
          this.button(rr, 'Повернуть 90°', () => { sv.rotate(); redraw(); }, { small: true });
          toggle(rr, 'Зеркало', sv.mirror, () => sv.flipX());
          this.button(rr, 'Убрать', () => { sv.unload(); redraw(); }, { small: true });
          rr = row();
          for (const [t, d] of [['X−', [-1, 0, 0]], ['X+', [1, 0, 0]], ['Y−', [0, -1, 0]], ['Y+', [0, 1, 0]], ['Z−', [0, 0, -1]], ['Z+', [0, 0, 1]]]) this.button(rr, t, () => { sv.move(d[0], d[1], d[2]); redraw(); }, { small: true });
          rr = row();
          this.button(rr, sv.layer < 0 ? 'Слои: все' : 'Слой ' + (sv.layer + 1) + '/' + sv.s.h, () => { sv.setLayer(sv.layer < 0 ? 0 : -1); redraw(); }, { small: true });
          this.button(rr, 'Слой −', () => { sv.setLayer(Math.max(0, sv.layer - 1)); redraw(); }, { small: true, disabled: sv.layer < 0 || sv.layerMode === 'auto' });
          this.button(rr, 'Слой +', () => { sv.setLayer(sv.layer + 1); redraw(); }, { small: true, disabled: sv.layer < 0 || sv.layerMode === 'auto' });
          this.button(rr, sv.layerModeLabel(), () => { sv.cycleLayerMode(); redraw(); }, { small: true, disabled: sv.layer < 0 });
          rr = row();
          toggle(rr, 'Easy Place', sv.easyPlace, (v) => sv.setEasyPlace(v));
          toggle(rr, 'Принтер', sv.printer || !!sv.gather, (v) => { if (v) sv.start('print'); else { sv.printer = false; sv.gather = null; } });
          this.button(rr, 'Построить всё сразу', () => { sv.buildAll(); this.app.resume(); }, { small: true });
          if (game.gamemode !== 1) toggle(rr, 'Замены', !!eb.cfg.schemSubst, (v) => { eb.cfg.schemSubst = v; eb.changed(); redraw(); });
          if (game.gamemode !== 1 && eb.cfg.schemSubst) this.button(rr, eb.substLabel(), () => { eb.cycleSubst(); redraw(); }, { small: true });
          this.button(rr, 'Взять блоки', () => { sv.start(null); if (game.mode === 'mp' && game.gamemode === 0) this.app.resume(); else redraw(); }, { small: true });
          this.slider(body, 'Дальность принтера', 0, Math.round(MC.Building.reachOf(game) * 2), 1, Math.round((+eb.cfg.printRange || 0) * 2), (v) => (v ? Math.min(v / 2, MC.Building.reachOf(game)) + ' бл.' : 'вся досягаемость (' + MC.Building.reachOf(game) + ' бл.)'),
            (v) => { eb.cfg.printRange = v / 2; eb.changed(); });
          const errs = sv.stats.wrong + sv.stats.rot;
          if (errs && game.gamemode === 1) {
            this.button(rr, (game.mode === 'mp' ? 'Сломать ошибки (' : 'Исправить ошибки (') + errs + ')', () => {
              const n = sv.fixErrors();
              this.setPopup(n ? (game.mode === 'mp' ? 'Ломаю ' + n + ' бл.; затем принтер или Easy Place поставят верные' : 'Исправлено блоков: ' + n) : 'Нечего исправлять');
              redraw();
            }, { small: true });
          }
          const prog = el('div', 'schem-progress');
          const bar = el('div', 'schem-bar');
          bar.style.width = sv.progress() + '%';
          prog.appendChild(bar);
          body.appendChild(prog);
          body.appendChild(el('div', 'hint', MC.stripFormat(sv.hint()) + '. Easy Place: нажмите «использовать», глядя на блок голограммы, — встанет именно он и с нужным поворотом' +
            (game.mode === 'mp' ? ' (на сервере поворот ступеней и брёвен задаёт сервер по взгляду)' : '') + '. Принтер сам ставит недостающие блоки рядом с вами' + (game.gamemode === 0 ? ' из инвентаря' : '') +
            '. Перед стройкой все нужные блоки сначала кладутся в инвентарь' + (game.gamemode === 1 ? ' (творческий: по 64 каждого вида)' : game.mode === 'mp' ? ' из сундуков рядом (игра открывает их сама — стойте лицом к ним)' : ' из сундуков в 8 блоках') +
            (eb.cfg.schemSubst && game.gamemode !== 1 ? '; при нехватке блок заменяется по настройке «Нет нужных блоков»' : '; ставятся только точные блоки схемы, без замен (включаются кнопкой «Замены»)') +
            '. Красная рамка — стоит не тот блок, оранжевая — не тот поворот' + (game.gamemode === 1 ? '' : ' (сломайте и поставьте заново)') + '.'));
          // Материалы: что ещё нужно для постройки и сколько есть
          const mats = sv.materials();
          if (mats.length) {
            label('Материалы (нужно / есть)');
            const box2 = el('div', 'eb-mats');
            for (const m of mats.slice(0, 40)) {
              const line = el('div', 'eb-mat' + (game.gamemode !== 1 && m.have < m.need ? ' short' : ''));
              const img = el('img');
              img.src = MC.Items.icon(m.id, m.data);
              img.alt = '';
              line.appendChild(img);
              line.appendChild(el('span', null, m.name + ' — ' + MC.Schematics.stacks(m.need) + (game.gamemode !== 1 ? ' / ' + m.have : '')));
              box2.appendChild(line);
            }
            if (mats.length > 40) box2.appendChild(el('div', 'hint', 'и ещё ' + (mats.length - 40) + ' видов'));
            body.appendChild(box2);
          }
        }
        label('Готовые постройки (ставьте на ровное место; «Показать» — голограмма, потом принтер или «Построить всё сразу»)');
        for (const st of MC.Structures.LIST) {
          const line = el('div', 'btn-row eb-row');
          line.appendChild(el('span', 'eb-name', (st.kind === 'trap' ? '⚠ ' : '⌂ ') + MC.Structures.get(st.id).name + ' — ' + st.desc));
          this.button(line, 'Показать', () => { sv.load(MC.Structures.get(st.id)); this.setPopup('«' + MC.Structures.get(st.id).name + '» показана перед вами'); redraw(); }, { small: true });
          this.button(line, 'Построить', () => { sv.load(MC.Structures.get(st.id)); sv.buildAll(); this.app.resume(); }, { small: true });
          body.appendChild(line);
        }
        label('Загруженные схемы');
        MC.Schematics.list().then((list) => {
          if (this.current !== 'build' || this.buildTab !== 'schem') return;
          if (!list.length) { body.appendChild(el('div', 'hint', 'Схем нет. Загрузите файл или положите схему в папку игры (schematics) и нажмите «Обновить» в настройках.')); return; }
          for (const s of list) {
            const line = el('div', 'btn-row eb-row');
            line.appendChild(el('span', 'eb-name', s.name + ' · ' + s.w + '×' + s.h + '×' + s.l));
            this.button(line, 'Показать', () => { sv.load(s); this.setPopup('Схема «' + s.name + '» показана перед вами'); redraw(); }, { small: true });
            this.button(line, 'Файл', async () => { try { this.setPopup(await MC.Schematics.exportFile(s)); } catch (e) { this.setPopup('§c' + e.message); } }, { small: true });
            this.button(line, '✕', async () => { await MC.Schematics.remove(s.name); redraw(); }, { small: true });
            body.appendChild(line);
          }
        });
      }
      this.button(box, 'Готово', () => this.app.resume());
    }

    setPopup(text) {
      this.hPopup.textContent = '';
      this.hPopup.appendChild(MC.formatted(text));
      this.popupUntil = performance.now() + 3000;
    }

    tick() {
      const now = performance.now();
      if (this.titleUntil && now > this.titleUntil) { this.hTitle.textContent = ''; this.hSub.textContent = ''; this.titleUntil = 0; }
      if (this.popupUntil && now > this.popupUntil) { this.hPopup.textContent = ''; this.popupUntil = 0; }
      this.updateChatFade();
    }

    setDebug(text) {
      if (this.hDebugText === text) return;
      this.hDebugText = text;
      this.hDebug.textContent = '';
      this.hDebug.style.display = text ? '' : 'none';
      if (text) this.hDebug.appendChild(MC.formatted(text));
    }

    // list: [{key, name, x, y}] в пикселях экрана
    setNametags(list) {
      // Ники хранятся в Map: поиск по DOM на каждый кадр в толпе игроков заметно тормозит
      if (!this.tagEls) this.tagEls = new Map();
      if (list.length > 40) list = list.slice(0, 40);
      const seen = new Set();
      for (const t of list) {
        seen.add(t.key);
        let e = this.tagEls.get(t.key);
        if (!e) {
          e = el('div', 'tag');
          this.tagEls.set(t.key, e);
          this.hTags.appendChild(e);
        }
        // Ник может меняться (сервер пишет в него здоровье, ранг, таймер)
        if (e.dataset.n !== t.name) { e.dataset.n = t.name; e.textContent = ''; e.appendChild(MC.formatted(t.name)); }
        const tr = 'translate(' + Math.round(t.x) + 'px,' + Math.round(t.y) + 'px) translate(-50%, -100%)';
        if (e.style.transform !== tr) e.style.transform = tr;
      }
      for (const [k, e] of this.tagEls) if (!seen.has(k)) { e.remove(); this.tagEls.delete(k); }
    }
  }

  MC.UI = UI;
})();
