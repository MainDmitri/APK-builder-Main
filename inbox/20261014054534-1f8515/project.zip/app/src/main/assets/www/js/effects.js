// Эффекты зелий (как в Minecraft PE 1.1): таблица зелий по data, набор эффектов игрока или существа,
// рецепты варочной стойки
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  // ID эффектов MCPE
  const E = {
    SPEED: 1, SLOWNESS: 2, HASTE: 3, FATIGUE: 4, STRENGTH: 5, HEAL: 6, HARM: 7, JUMP: 8, NAUSEA: 9, REGEN: 10, RESISTANCE: 11,
    FIRE_RES: 12, WATER_BREATHING: 13, INVISIBILITY: 14, BLINDNESS: 15, NIGHT_VISION: 16, HUNGER: 17, WEAKNESS: 18, POISON: 19,
    WITHER: 20, HEALTH_BOOST: 21, ABSORPTION: 22, SATURATION: 23, LEVITATION: 24
  };
  const INSTANT = new Set([E.HEAL, E.HARM]);

  // Цвета частиц и брызг (как у зелий в игре)
  const COLOR = {
    1: [0.49, 0.69, 0.78], 2: [0.35, 0.42, 0.51], 3: [0.85, 0.75, 0.26], 4: [0.29, 0.26, 0.09], 5: [0.58, 0.14, 0.14], 6: [0.97, 0.14, 0.14],
    7: [0.26, 0.04, 0.04], 8: [0.13, 1, 0.3], 9: [0.33, 0.11, 0.29], 10: [0.8, 0.36, 0.63], 11: [0.6, 0.27, 0.23], 12: [0.89, 0.6, 0.23],
    13: [0.18, 0.32, 0.6], 14: [0.5, 0.51, 0.57], 15: [0.12, 0.12, 0.14], 16: [0.12, 0.12, 0.63], 17: [0.35, 0.46, 0.33], 18: [0.28, 0.3, 0.28],
    19: [0.31, 0.58, 0.19], 20: [0.21, 0.16, 0.16], 21: [0.97, 0.49, 0.14], 22: [0.15, 0.36, 0.65], 23: [0.97, 0.14, 0.14], 24: [0.81, 1, 1]
  };

  // Зелья по data (MCPE 1.1): [эффект, длительность в секундах, уровень (0 = I)]; null — без эффекта
  const POTION = [
    null, null, null, null, null,
    [E.NIGHT_VISION, 180, 0], [E.NIGHT_VISION, 480, 0],
    [E.INVISIBILITY, 180, 0], [E.INVISIBILITY, 480, 0],
    [E.JUMP, 180, 0], [E.JUMP, 480, 0], [E.JUMP, 90, 1],
    [E.FIRE_RES, 180, 0], [E.FIRE_RES, 480, 0],
    [E.SPEED, 180, 0], [E.SPEED, 480, 0], [E.SPEED, 90, 1],
    [E.SLOWNESS, 90, 0], [E.SLOWNESS, 240, 0],
    [E.WATER_BREATHING, 180, 0], [E.WATER_BREATHING, 480, 0],
    [E.HEAL, 0, 0], [E.HEAL, 0, 1],
    [E.HARM, 0, 0], [E.HARM, 0, 1],
    [E.POISON, 45, 0], [E.POISON, 90, 0], [E.POISON, 22, 1],
    [E.REGEN, 45, 0], [E.REGEN, 90, 0], [E.REGEN, 22, 1],
    [E.STRENGTH, 180, 0], [E.STRENGTH, 480, 0], [E.STRENGTH, 90, 1],
    [E.WEAKNESS, 90, 0], [E.WEAKNESS, 240, 0],
    [E.WITHER, 40, 1]
  ];

  function potionColor(data) {
    const p = POTION[data];
    return p ? COLOR[p[0]] : [0.22, 0.36, 0.96];
  }

  // Нежить: исцеление ранит, вред лечит
  const UNDEAD = new Set([32, 34, 36, 44, 46, 47, 48, 52, 53]);

  class EffectSet {
    constructor(list) {
      this.map = new Map();
      if (Array.isArray(list)) for (const e of list) if (e && e.id) this.map.set(e.id, { amp: e.amp | 0, t: +e.t || 0, timer: 0 });
    }

    // Новый эффект не заменяет более сильный; одинаковый по силе продлевается
    add(id, amp, sec) {
      const cur = this.map.get(id);
      if (cur && (cur.amp > amp || (cur.amp === amp && cur.t >= sec))) return false;
      this.map.set(id, { amp, t: sec, timer: cur ? cur.timer : 0 });
      return true;
    }

    has(id) { return this.map.has(id); }
    level(id) { const e = this.map.get(id); return e ? e.amp + 1 : 0; }
    remove(id) { this.map.delete(id); }
    clear() { this.map.clear(); }
    get size() { return this.map.size; }

    // Множитель скорости ходьбы: скорость +20 % за уровень, замедление −15 % за уровень
    speedMul() {
      return Math.max(0.1, 1 + 0.2 * this.level(E.SPEED) - 0.15 * this.level(E.SLOWNESS));
    }

    // Урон в ближнем бою: сила +3 за уровень, слабость −4
    meleeBonus() { return 3 * this.level(E.STRENGTH) - 4 * this.level(E.WEAKNESS); }

    // Скорость добычи: спешка +20 % за уровень, усталость ×0,3 за уровень
    digMul() {
      const f = this.level(E.FATIGUE);
      return (1 + 0.2 * this.level(E.HASTE)) * (f ? Math.pow(0.3, Math.min(f, 4)) : 1);
    }

    // Такт: длительности уменьшаются, периодические эффекты срабатывают через h.heal(n) / h.hurt(n, причина) / h.hunger(n)
    tick(dt, h) {
      for (const [id, e] of Array.from(this.map)) {
        e.t -= dt;
        e.timer += dt;
        // Периоды как в Minecraft (в тиках): регенерация 50 >> ур., яд 25 >> ур., иссушение 40 >> ур.
        if (id === E.REGEN) { const per = Math.max(1, 50 >> e.amp) / 20; while (e.timer >= per) { e.timer -= per; h.heal(1); } }
        else if (id === E.POISON) { const per = Math.max(1, 25 >> e.amp) / 20; while (e.timer >= per) { e.timer -= per; h.hurt(1, 'poison'); } }
        else if (id === E.WITHER) { const per = Math.max(1, 40 >> e.amp) / 20; while (e.timer >= per) { e.timer -= per; h.hurt(1, 'wither'); } }
        else if (id === E.HUNGER) { if (h.hunger) h.hunger(0.1 * (e.amp + 1) * dt * 20); e.timer = 0; }
        else if (id === E.SATURATION) { if (h.saturate) h.saturate(e.amp + 1); e.timer = 0; }
        else e.timer = 0;
        if (e.t <= 0) { this.map.delete(id); if (h.expired) h.expired(id); }
      }
    }

    list() { return Array.from(this.map, ([id, e]) => [id, e.amp, e.t]); }
    toJSON() { return Array.from(this.map, ([id, e]) => ({ id, amp: e.amp, t: Math.round(e.t * 10) / 10 })); }
  }

  // ---------- Варка ----------
  // Ингредиент -> {исходное зелье data: новое data}
  const BREW = {
    372: { 0: 4 },                                                     // адский нарост: вода -> грубое
    348: { 0: 3, 9: 11, 14: 16, 21: 22, 23: 24, 25: 27, 28: 30, 31: 33 }, // светопыль: усиление
    331: { 0: 2, 5: 6, 7: 8, 9: 10, 12: 13, 14: 15, 17: 18, 19: 20, 25: 26, 28: 29, 31: 32, 34: 35 }, // редстоун: продление
    353: { 0: 1, 4: 14 },                                              // сахар: стремительность
    414: { 0: 1, 4: 9 },                                               // кроличья лапка: прыгучесть
    377: { 0: 1, 4: 31 },                                              // огненный порошок: сила
    382: { 0: 1, 4: 21 },                                              // сверкающий ломтик арбуза: исцеление
    375: { 0: 1, 4: 25 },                                              // паучий глаз: отравление
    370: { 0: 1, 4: 28 },                                              // слеза гаста: регенерация
    378: { 0: 1, 4: 12 },                                              // сгусток магмы: огнестойкость
    462: { 0: 1, 4: 19 },                                              // иглобрюх: подводное дыхание
    396: { 0: 1, 4: 5 },                                               // золотая морковь: ночное зрение
    // Приготовленный паучий глаз портит зелья
    376: { 0: 34, 1: 34, 3: 34, 4: 34, 14: 17, 15: 18, 16: 17, 9: 17, 10: 18, 11: 17, 21: 23, 22: 24, 25: 23, 26: 23, 27: 24, 5: 7, 6: 8, 12: 17, 13: 18, 31: 34, 32: 35, 33: 34, 28: 34, 29: 35, 30: 34 }
  };

  // Результат варки одной бутылки или null. Порох делает взрывное, драконье дыхание — оседающее
  function brewResult(bottle, ingredient) {
    if (!bottle || !ingredient) return null;
    const ing = ingredient.id;
    if (ing === 289) return bottle.id === 373 ? { id: 438, data: bottle.data, count: 1 } : null;
    if (ing === 437) return bottle.id === 438 ? { id: 441, data: bottle.data, count: 1 } : null;
    const map = BREW[ing];
    if (!map || bottle.id !== 373 && bottle.id !== 438 && bottle.id !== 441) return null;
    const to = map[bottle.data];
    if (to === undefined) return null;
    return { id: bottle.id, data: to, count: 1 };
  }

  function isIngredient(id) { return id === 289 || id === 437 || !!BREW[id]; }

  // Варка 20 секунд, один огненный порошок даёт 20 варок
  const BREW_TIME = 20, FUEL_USES = 20;

  // Одна секунда варки для стойки {slots: [ингредиент, бутылка, бутылка, бутылка, топливо], fuel, time}; true — что-то изменилось
  function tickBrewing(st, dt) {
    const s = st.slots;
    const ing = s[0];
    const can = !!ing && [1, 2, 3].some((i) => brewResult(s[i], ing));
    let changed = false;
    if (can && (st.fuel || 0) <= 0 && s[4] && s[4].id === 377) {
      st.fuel = FUEL_USES;
      s[4].count--;
      if (s[4].count <= 0) s[4] = null;
      changed = true;
    }
    if (!can || (st.fuel || 0) <= 0) {
      if (st.time) { st.time = 0; changed = true; }
      return changed;
    }
    st.time = (st.time || 0) + dt;
    if (st.time >= BREW_TIME) {
      st.time = 0;
      for (let i = 1; i <= 3; i++) { const r = brewResult(s[i], ing); if (r) s[i] = r; }
      ing.count--;
      if (ing.count <= 0) s[0] = null;
      st.fuel--;
      changed = true;
      if (st.onDone) st.onDone();
    }
    return changed;
  }

  MC.Effects = { E, INSTANT, COLOR, POTION, UNDEAD, EffectSet, potionColor, brewResult, isIngredient, tickBrewing, BREW_TIME, FUEL_USES };
})();
