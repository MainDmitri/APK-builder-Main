// Настройки и список серверов (localStorage), миры одиночной игры (IndexedDB)
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  const SETTINGS_KEY = 'mcpehtml.settings';
  const SERVERS_KEY = 'mcpehtml.servers';

  function uuidv4() {
    if (crypto.randomUUID) return crypto.randomUUID();
    const b = new Uint8Array(16);
    crypto.getRandomValues(b);
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    const h = Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
    return h.slice(0, 8) + '-' + h.slice(8, 12) + '-' + h.slice(12, 16) + '-' + h.slice(16, 20) + '-' + h.slice(20);
  }

  function defaultRelay() {
    // В APK ретранслятор встроен в приложение (RelayServer.kt) и сообщает свой адрес через AndroidRelay
    if (window.AndroidRelay && typeof AndroidRelay.getUrl === 'function') return AndroidRelay.getUrl();
    if (location.protocol === 'http:' || location.protocol === 'https:') {
      return (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host;
    }
    return 'ws://127.0.0.1:8080';
  }

  // В APK адрес 127.0.0.1/localhost означает встроенный ретранслятор: его порт берём у приложения при каждом подключении,
  // поэтому старый сохранённый порт не мешает
  function isLocalRelay(url) {
    return /^wss?:\/\/(127\.0\.0\.1|localhost)(:\d+)?\/?$/i.test(String(url || '').trim());
  }

  function relayUrl(st) {
    const url = String((st && st.relay) || '').trim();
    if (window.AndroidRelay && typeof AndroidRelay.getUrl === 'function' && (!url || isLocalRelay(url))) return AndroidRelay.getUrl();
    return url || defaultRelay();
  }

  const DEFAULTS = {
    nickname: 'Steve' + Math.floor(Math.random() * 1000),
    relay: defaultRelay(),
    renderDistance: 6,
    sensitivity: 1,
    fov: 70,
    touch: 'auto',
    autoJump: true,
    controls: 'dpad',
    buttonScale: 1,
    buttonOpacity: 0.75,
    invertY: false,
    clouds: true,
    particles: 'all',
    showPing: true,
    autoReconnect: true,
    showInfo: true,
    volume: 1,
    swapJumpSneak: false,
    autoSprint: false,
    camera: 'first',
    shaders: 'fancy',
    renderScale: 1,
    aimAssist: true,
    brightness: 1,
    skin: null,
    uuid: null,
    device: 'auto',
    inputMode: 'auto',
    deviceModel: ''
  };

  function loadSettings() {
    let s = {};
    try { s = JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') || {}; } catch (e) { s = {}; }
    const out = Object.assign({}, DEFAULTS, s);
    out.relay = relayUrl(out);
    if (!out.uuid) {
      // Первый запуск: на слабом устройстве (мало памяти или ядер) сразу включаем лёгкие настройки
      const weak = (navigator.deviceMemory && navigator.deviceMemory <= 3) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4);
      if (weak) { out.renderScale = 0.65; out.renderDistance = 4; out.particles = 'less'; }
      out.uuid = uuidv4();
      saveSettings(out);
    }
    if (!out.deviceId) { out.deviceId = uuidv4().replace(/-/g, ''); saveSettings(out); }
    return out;
  }

  function saveSettings(s) {
    try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); } catch (e) { console.warn('Не удалось сохранить настройки', e); }
  }

  function loadServers() {
    try {
      const list = JSON.parse(localStorage.getItem(SERVERS_KEY) || '[]');
      return Array.isArray(list) ? list : [];
    } catch (e) {
      return [];
    }
  }

  function saveServers(list) {
    try { localStorage.setItem(SERVERS_KEY, JSON.stringify(list)); } catch (e) { console.warn('Не удалось сохранить серверы', e); }
  }

  // ---------- Устройство для входа на серверы ----------
  // Сервер MCPE узнаёт платформу и способ управления из данных входа (DeviceOS, DeviceModel, CurrentInputMode, UIProfile).
  // Некоторые серверы пускают только определённые устройства или подбирают игроков по управлению — здесь это выбирается.
  // Номера платформ как в MCPE 1.1: 1 Android, 2 iOS, 3 macOS, 4 Fire OS, 5 Gear VR, 6 HoloLens, 7 Windows 10, 8 Windows (Win32), 10 tvOS
  const DEVICES = {
    auto: { name: 'Автоматически (по этому устройству)' },
    android: { name: 'Телефон Android', os: 1, model: 'samsung SM-A515F', ui: 1, input: 2 },
    ios: { name: 'iPhone (iOS)', os: 2, model: 'iPhone12,1', ui: 1, input: 2 },
    ipad: { name: 'iPad (iOS)', os: 2, model: 'iPad7,5', ui: 1, input: 2 },
    win10: { name: 'Windows 10 Edition', os: 7, model: 'Windows 10', ui: 0, input: 1 },
    fireos: { name: 'Планшет Amazon Fire (Fire OS)', os: 4, model: 'KFMUWI', ui: 1, input: 2 },
    gearvr: { name: 'Samsung Gear VR', os: 5, model: 'SM-G950F', ui: 1, input: 4 },
    macos: { name: 'macOS', os: 3, model: 'MacBookPro15,1', ui: 0, input: 1 },
    tvos: { name: 'Apple TV (tvOS)', os: 10, model: 'AppleTV6,2', ui: 0, input: 3 }
  };
  const INPUTS = {
    auto: { name: 'Как у выбранного устройства' },
    touch: { name: 'Сенсорный экран (телефон)', mode: 2 },
    mouse: { name: 'Клавиатура и мышь', mode: 1 },
    gamepad: { name: 'Геймпад', mode: 3 }
  };

  function gamepadConnected() {
    try { return Array.from(navigator.getGamepads ? navigator.getGamepads() : []).some((g) => g && g.connected); } catch (e) { return false; }
  }

  // Данные устройства для пакета входа. st — настройки, srv — сервер (его выбор важнее общего), touch — сенсорный режим сейчас
  function deviceInfo(st, srv, touch) {
    const devKey = (srv && srv.device && DEVICES[srv.device]) ? srv.device : (DEVICES[st.device] ? st.device : 'auto');
    const inKey = (srv && srv.input && INPUTS[srv.input]) ? srv.input : (INPUTS[st.inputMode] ? st.inputMode : 'auto');
    let dev = DEVICES[devKey];
    if (devKey === 'auto') dev = (window.AndroidRelay || touch) ? DEVICES.android : DEVICES.win10;
    let input;
    if (inKey !== 'auto') input = INPUTS[inKey].mode;
    else if (devKey === 'auto') input = gamepadConnected() ? 3 : touch ? 2 : 1;
    else input = dev.input;
    return {
      DeviceOS: dev.os,
      DeviceModel: (st.deviceModel && String(st.deviceModel).trim()) || dev.model,
      DeviceId: st.deviceId,
      CurrentInputMode: input,
      DefaultInputMode: dev.input === 4 ? 4 : input,
      UIProfile: input === 2 ? 1 : dev.ui,
      GuiScale: input === 2 ? 0 : -1,
      label: dev.name + ', ' + (input === 1 ? 'клавиатура и мышь' : input === 2 ? 'сенсорный экран' : input === 3 ? 'геймпад' : 'VR-контроллер')
    };
  }

  // ---------- IndexedDB ----------
  let dbPromise = null;
  function db() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open('mcpe-html', 2);
      req.onupgradeneeded = () => {
        const d = req.result;
        if (!d.objectStoreNames.contains('worlds')) d.createObjectStore('worlds', { keyPath: 'id' });
        if (!d.objectStoreNames.contains('chunks')) d.createObjectStore('chunks');
        if (!d.objectStoreNames.contains('packs')) d.createObjectStore('packs', { keyPath: 'id' });
        if (!d.objectStoreNames.contains('kv')) d.createObjectStore('kv');
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error('IndexedDB недоступна'));
    });
    return dbPromise;
  }

  function tx(store, mode, fn) {
    return db().then((d) => new Promise((resolve, reject) => {
      const t = d.transaction(store, mode);
      const s = t.objectStore(store);
      let result;
      const r = fn(s);
      if (r && 'onsuccess' in r) r.onsuccess = () => { result = r.result; };
      t.oncomplete = () => resolve(result);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error || new Error('Транзакция отменена'));
    }));
  }

  const Worlds = {
    list() { return tx('worlds', 'readonly', (s) => s.getAll()).then((l) => (l || []).sort((a, b) => b.lastPlayed - a.lastPlayed)); },
    get(id) { return tx('worlds', 'readonly', (s) => s.get(id)); },
    put(w) { return tx('worlds', 'readwrite', (s) => s.put(w)); },
    async remove(id) {
      await tx('worlds', 'readwrite', (s) => s.delete(id));
      await tx('chunks', 'readwrite', (s) => s.delete(IDBKeyRange.bound(id + ':', id + ':￿')));
    },
    // Координаты сохранённых чанков обычного мира (без Ада и Края): [cx, cz, cx, cz, ...]
    async chunkCoords(id) {
      const keys = await tx('chunks', 'readonly', (s) => s.getAllKeys(IDBKeyRange.bound(id + ':', id + ':\uffff'))) || [];
      const out = [];
      for (const k of keys) {
        const parts = String(k).slice(id.length + 1).split(':');
        if (parts.length !== 2) continue;
        const cx = Number(parts[0]), cz = Number(parts[1]);
        if (Number.isInteger(cx) && Number.isInteger(cz)) out.push(cx, cz);
      }
      return out;
    },
    loadChunk(id, cx, cz) { return tx('chunks', 'readonly', (s) => s.get(id + ':' + cx + ':' + cz)); },
    saveChunk(id, chunk) {
      const sections = chunk.sections.map((s) => (s ? { ids: s.ids, meta: s.meta } : null));
      return tx('chunks', 'readwrite', (s) => s.put({ sections }, id + ':' + chunk.cx + ':' + chunk.cz));
    }
  };

  // Текстур-паки (.mcpack как Blob) и кэш собранных атласов
  const Packs = {
    list() { return tx('packs', 'readonly', (s) => s.getAll()).then((l) => (l || []).sort((a, b) => (a.order || 0) - (b.order || 0))); },
    put(p) { return tx('packs', 'readwrite', (s) => s.put(p)); },
    remove(id) { return tx('packs', 'readwrite', (s) => s.delete(id)); }
  };
  const kv = {
    get(key) { return tx('kv', 'readonly', (s) => s.get(key)); },
    put(key, value) { return tx('kv', 'readwrite', (s) => s.put(value, key)); }
  };

  MC.Storage = { DEVICES, INPUTS, deviceInfo, gamepadConnected, relayUrl, isLocalRelay, loadSettings, saveSettings, loadServers, saveServers, Worlds, Packs, kv, uuidv4 };
})();
