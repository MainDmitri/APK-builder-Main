// Отрисовка мира, игроков, сущностей и рамки выделения через WebGL
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const A = window.MC_ASSETS;

  // ---------- Матрицы 4x4 (столбцами, как в WebGL) ----------
  const M4 = {
    perspective(fovy, aspect, near, far) {
      const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
      return new Float32Array([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0]);
    },
    lookAt(eye, target, up) {
      let zx = eye[0] - target[0], zy = eye[1] - target[1], zz = eye[2] - target[2];
      let l = Math.hypot(zx, zy, zz); zx /= l; zy /= l; zz /= l;
      let xx = up[1] * zz - up[2] * zy, xy = up[2] * zx - up[0] * zz, xz = up[0] * zy - up[1] * zx;
      l = Math.hypot(xx, xy, xz) || 1; xx /= l; xy /= l; xz /= l;
      const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
      return new Float32Array([xx, yx, zx, 0, xy, yy, zy, 0, xz, yz, zz, 0,
        -(xx * eye[0] + xy * eye[1] + xz * eye[2]), -(yx * eye[0] + yy * eye[1] + yz * eye[2]), -(zx * eye[0] + zy * eye[1] + zz * eye[2]), 1]);
    },
    mul(a, b) {
      const o = new Float32Array(16);
      for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
        o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
      }
      return o;
    }
  };

  // a_light = освещение (0..1) + 2 * флаг: 1 — качается как листва, 2 — поверхность воды
  const VS = `
attribute vec3 a_pos;
attribute vec2 a_uv;
attribute float a_light;
uniform mat4 u_mvp;
uniform vec3 u_offset;
uniform vec3 u_cam;
uniform float u_time;
uniform float u_fancy;
varying vec2 v_uv;
varying float v_light;
varying float v_block;
varying float v_dist;
void main() {
  vec3 p = a_pos + u_offset;
  // a_light = свет неба + 2*флаг + 8*блочный свет (0..15)
  float al = a_light - 64.0 * step(63.5, a_light);
  float bl = floor(al / 8.0 + 0.001);
  float rest = al - bl * 8.0;
  float flag = floor(rest / 2.0);
  float light = rest - flag * 2.0;
  if (u_fancy > 0.5 && flag > 0.5) {
    vec3 w = p + u_cam;
    if (flag < 1.5) {
      float s = sin(u_time * 1.4 + w.x * 0.9 + w.z * 0.7 + w.y * 0.4);
      p.x += s * 0.03;
      p.z += cos(u_time * 1.1 + w.z * 0.8 + w.x * 0.5) * 0.03;
    } else if (flag < 2.5) {
      p.y += (sin(u_time * 1.8 + w.x * 1.3 + w.z * 0.9) * 0.5 + sin(u_time * 2.6 + w.z * 1.7) * 0.5) * 0.045 - 0.02;
    }
  }
  gl_Position = u_mvp * vec4(p, 1.0);
  v_uv = a_uv;
  v_light = light;
  v_block = bl / 15.0;
  v_dist = length(p);
}`;

  const FS = `
precision mediump float;
uniform sampler2D u_tex;
uniform vec4 u_tint;
uniform float u_daylight;
uniform float u_alphaTest;
uniform vec3 u_fog;
uniform vec2 u_fogRange;
uniform float u_bright;
uniform float u_minLight;
varying vec2 v_uv;
varying float v_light;
varying float v_block;
varying float v_dist;
uniform highp float u_fancy;
void main() {
  vec4 c = texture2D(u_tex, v_uv) * u_tint;
  if (c.a < u_alphaTest) discard;
  // Тёплый свет факелов/лавы складывается со светом неба (берётся больший), как в Minecraft
  float b = v_block * v_block * (3.0 - 2.0 * v_block);
  vec3 lit = max(vec3(max(v_light * u_daylight, u_minLight)), vec3(1.0, 0.88, 0.72) * b);
  c.rgb *= lit * u_bright;
  float f = clamp((v_dist - u_fogRange.x) / (u_fogRange.y - u_fogRange.x), 0.0, 1.0);
  if (u_fancy > 0.5) {
    // Плавный туман и чуть более сочные цвета
    f = f * f * (3.0 - 2.0 * f);
    float g = dot(c.rgb, vec3(0.299, 0.587, 0.114));
    c.rgb = mix(vec3(g), c.rgb, 1.12);
  }
  c.rgb = mix(c.rgb, u_fog, f);
  gl_FragColor = c;
}`;

  // Небо: градиент от горизонта к зениту, заря у солнца, звёзды ночью (рисуется одним треугольником на весь экран)
  const SKY_VS = `
attribute vec2 a_pos;
varying vec2 v_ndc;
void main() { v_ndc = a_pos; gl_Position = vec4(a_pos, 0.999, 1.0); }`;
  const SKY_FS = `
precision mediump float;
uniform vec3 u_fwd;
uniform vec3 u_right;
uniform vec3 u_up;
uniform vec2 u_tan;
uniform vec3 u_horizon;
uniform vec3 u_zenith;
uniform vec3 u_sun;
uniform float u_daylight;
varying vec2 v_ndc;
float hash(vec3 q) { return fract(sin(dot(q, vec3(12.9898, 78.233, 37.719))) * 43758.5453); }
void main() {
  vec3 dir = normalize(u_fwd + u_right * (v_ndc.x * u_tan.x) + u_up * (v_ndc.y * u_tan.y));
  float t = clamp(dir.y, 0.0, 1.0);
  vec3 c = mix(u_horizon, u_zenith, pow(t, 0.55));
  if (dir.y < 0.0) c = mix(u_horizon, u_zenith * 0.5, clamp(-dir.y * 3.0, 0.0, 1.0));
  float sunH = u_sun.y;
  float dawn = 1.0 - clamp(abs(sunH) / 0.32, 0.0, 1.0);
  if (dawn > 0.0) {
    float toSun = max(0.0, dot(normalize(vec3(dir.x, 0.0, dir.z)), normalize(vec3(u_sun.x, 0.0, u_sun.z))));
    float band = pow(1.0 - clamp(abs(dir.y) * 2.2, 0.0, 1.0), 2.0);
    c = mix(c, vec3(1.0, 0.45, 0.12), dawn * band * pow(toSun, 3.0) * 0.85);
  }
  if (u_daylight < 0.6 && dir.y > 0.02) {
    vec3 cell = floor(dir * 140.0);
    float h = hash(cell);
    vec3 f = fract(dir * 140.0) - 0.5;
    float star = step(0.994, h) * smoothstep(0.22, 0.0, length(f)) * (0.6 + 0.4 * sin(h * 40.0));
    c += vec3(star) * (1.0 - u_daylight / 0.6);
  }
  gl_FragColor = vec4(c, 1.0);
}`;

  function compile(gl, type, src) {
    const s = gl.createShader(type);
    gl.shaderSource(s, src);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('Ошибка шейдера: ' + gl.getShaderInfoLog(s));
    return s;
  }

  function loadImage(src) {
    return new Promise((res, rej) => {
      const im = new Image();
      im.onload = () => res(im);
      im.onerror = () => rej(new Error('Не удалось загрузить текстуру'));
      im.src = src;
    });
  }

  // Модель игрока (раскладка скина 64x32 / 64x64)
  const PX = 1.8 / 32;
  const PARTS = [
    { name: 'head', size: [8, 8, 8], uv: [0, 0], pivot: [0, 24, 0], origin: [-4, 0, -4] },
    { name: 'body', size: [8, 12, 4], uv: [16, 16], pivot: [0, 12, 0], origin: [-4, 0, -2] },
    { name: 'rarm', size: [4, 12, 4], uv: [40, 16], pivot: [-6, 24, 0], origin: [-2, -12, -2] },
    { name: 'larm', size: [4, 12, 4], uv: [40, 16], uv64: [32, 48], pivot: [6, 24, 0], origin: [-2, -12, -2] },
    { name: 'rleg', size: [4, 12, 4], uv: [0, 16], pivot: [-2, 12, 0], origin: [-2, -12, -2] },
    { name: 'lleg', size: [4, 12, 4], uv: [0, 16], uv64: [16, 48], pivot: [2, 12, 0], origin: [-2, -12, -2] },
    { name: 'hat', size: [8, 8, 8], uv: [32, 0], pivot: [0, 24, 0], origin: [-4, 0, -4], inflate: 0.5 }
  ];

  // Броня на модели: материал по id предмета, слои текстуры (1 — шлем, кираса, рукава, ботинки; 2 — поножи)
  const ARMOR_MAT = {};
  for (const [base, mat] of [[298, 'leather'], [302, 'chain'], [306, 'iron'], [310, 'diamond'], [314, 'gold']]) for (let i = 0; i < 4; i++) ARMOR_MAT[base + i] = mat;
  const LEATHER_TINT = [0.627, 0.396, 0.251];
  const withInflate = (name, inflate, uv) => { const p = PARTS.find((x) => x.name === name); return Object.assign({}, p, { inflate, uv, uv64: undefined }); };
  const ARMOR_PARTS = [
    [withInflate('head', 1, [0, 0])],
    [withInflate('body', 1.01, [16, 16]), withInflate('rarm', 1, [40, 16]), withInflate('larm', 1, [40, 16])],
    [withInflate('body', 0.51, [16, 16]), withInflate('rleg', 0.5, [0, 16]), withInflate('lleg', 0.5, [0, 16])],
    [withInflate('rleg', 1, [0, 16]), withInflate('lleg', 1, [0, 16])]
  ];
  // Элитры: два крыла за спиной (текстура elytra.png, 64x32)
  const ELYTRA_PARTS = [
    { name: 'lwing', size: [10, 20, 2], uv: [22, 0], pivot: [5, 24, -2], origin: [-10, -20, -2], rotX: 0.26, rotZ: 0.26 },
    { name: 'rwing', size: [10, 20, 2], uv: [22, 0], pivot: [-5, 24, -2], origin: [0, -20, -2], rotX: 0.26, rotZ: -0.26, mirror: true }
  ];

  const ENTITY_LOOK = {
    10: ['Курица', [0.95, 0.95, 0.95], [0.4, 0.7, 0.4]], 11: ['Корова', [0.35, 0.25, 0.18], [0.9, 1.4, 1.4]], 12: ['Свинья', [0.95, 0.65, 0.65], [0.9, 0.9, 1.2]],
    13: ['Овца', [0.92, 0.92, 0.92], [0.9, 1.3, 1.2]], 14: ['Волк', [0.8, 0.8, 0.8], [0.6, 0.85, 1.0]], 15: ['Житель', [0.55, 0.4, 0.3], [0.6, 1.9, 0.6]],
    16: ['Грибная корова', [0.7, 0.2, 0.2], [0.9, 1.4, 1.4]], 17: ['Спрут', [0.2, 0.3, 0.45], [0.8, 0.8, 0.8]], 18: ['Кролик', [0.6, 0.5, 0.4], [0.4, 0.5, 0.4]],
    19: ['Летучая мышь', [0.25, 0.2, 0.15], [0.5, 0.9, 0.5]], 20: ['Железный голем', [0.8, 0.78, 0.72], [1.4, 2.7, 1.4]], 21: ['Снежный голем', [0.95, 0.95, 1], [0.7, 1.9, 0.7]],
    22: ['Оцелот', [0.85, 0.7, 0.3], [0.6, 0.7, 0.9]], 23: ['Лошадь', [0.5, 0.33, 0.2], [1.4, 1.6, 1.8]], 32: ['Зомби', [0.25, 0.5, 0.3], [0.6, 1.95, 0.6]],
    33: ['Крипер', [0.3, 0.7, 0.3], [0.6, 1.7, 0.6]], 34: ['Скелет', [0.8, 0.8, 0.8], [0.6, 1.99, 0.6]], 35: ['Паук', [0.2, 0.17, 0.15], [1.4, 0.9, 1.4]],
    36: ['Зомби-свиночеловек', [0.85, 0.6, 0.55], [0.6, 1.95, 0.6]], 37: ['Слизень', [0.4, 0.8, 0.35], [1.0, 1.0, 1.0]], 38: ['Эндермен', [0.1, 0.1, 0.12], [0.6, 2.9, 0.6]],
    39: ['Чешуйница', [0.55, 0.55, 0.55], [0.4, 0.3, 0.4]], 40: ['Пещерный паук', [0.1, 0.2, 0.25], [0.7, 0.5, 0.7]], 41: ['Гаст', [0.95, 0.95, 0.95], [4, 4, 4]],
    42: ['Магмовый куб', [0.5, 0.15, 0.05], [1.0, 1.0, 1.0]], 43: ['Ифрит', [0.95, 0.75, 0.2], [0.6, 1.8, 0.6]], 44: ['Зомби-житель', [0.3, 0.5, 0.3], [0.6, 1.95, 0.6]],
    45: ['Ведьма', [0.3, 0.2, 0.3], [0.6, 1.95, 0.6]], 46: ['Зимогор', [0.6, 0.7, 0.75], [0.6, 1.99, 0.6]], 47: ['Кадавр', [0.6, 0.55, 0.4], [0.6, 1.95, 0.6]],
    48: ['Скелет-иссушитель', [0.15, 0.15, 0.15], [0.7, 2.4, 0.7]], 49: ['Страж', [0.35, 0.6, 0.55], [0.85, 0.85, 0.85]],
    24: ['Осёл', [0.5, 0.45, 0.4], [1.4, 1.5, 1.8]], 25: ['Мул', [0.35, 0.25, 0.15], [1.4, 1.6, 1.8]], 26: ['Лошадь-скелет', [0.85, 0.85, 0.8], [1.4, 1.6, 1.8]],
    27: ['Лошадь-зомби', [0.3, 0.5, 0.3], [1.4, 1.6, 1.8]], 29: ['Лама', [0.85, 0.75, 0.6], [0.9, 1.87, 0.9]], 50: ['Древний страж', [0.6, 0.6, 0.55], [2, 2, 2]],
    51: ['NPC', [0.5, 0.4, 0.3], [0.6, 1.95, 0.6]], 52: ['Иссушитель', [0.15, 0.15, 0.15], [0.9, 3.5, 0.9]], 53: ['Дракон Края', [0.1, 0.1, 0.1], [16, 8, 16]],
    54: ['Шалкер', [0.6, 0.45, 0.6], [1, 1, 1]], 55: ['Эндермит', [0.25, 0.15, 0.3], [0.4, 0.3, 0.4]],
    65: ['Динамит', [0.85, 0.2, 0.15], [0.98, 0.98, 0.98]], 66: ['Падающий блок', [0.8, 0.75, 0.55], [0.98, 0.98, 0.98]], 69: ['Опыт', [0.6, 0.95, 0.2], [0.25, 0.25, 0.25]],
    80: ['Стрела', [0.6, 0.5, 0.4], [0.15, 0.15, 0.5]], 81: ['Снежок', [1, 1, 1], [0.25, 0.25, 0.25]], 82: ['Яйцо', [0.95, 0.9, 0.75], [0.25, 0.25, 0.25]],
    84: ['Вагонетка', [0.45, 0.45, 0.5], [0.98, 0.7, 0.98]], 90: ['Лодка', [0.6, 0.45, 0.25], [1.4, 0.45, 1.4]]
  };

  const HORSE_COLORS = ['white', 'creamy', 'chestnut', 'brown', 'black', 'gray', 'darkbrown'];
  const SADDLE = ['Bag1', 'Bag2', 'Saddle', 'SaddleB', 'SaddleC', 'SaddleL2', 'SaddleL', 'SaddleR2', 'SaddleR', 'SaddleMouthL', 'SaddleMouthR', 'SaddleMouthLine', 'SaddleMouthLineR', 'HeadSaddle'];
  const HORSE_HIDE = SADDLE.concat(['MuleEarL', 'MuleEarR']);
  const MULE_HIDE = SADDLE.concat(['Ear1', 'Ear2']);
  // Существа: тип сущности -> [геометрии из mobs.json, текстура, масштаб, анимация]
  const MOBS = {
    10: [['chicken'], 'chicken', 1, 'chicken'], 11: [['cow'], 'cow', 1, 'quad'], 12: [['pig'], 'pig', 1, 'quad'],
    13: [['sheep.sheared', 'sheep'], 'sheep', 1, 'quad'], 14: [['wolf'], 'wolf', 1, 'wolf'], 15: [['villager'], 'villager', 1, 'villager'],
    16: [['mooshroom'], 'mooshroom', 1, 'quad'], 17: [['squid'], 'squid', 1, 'none'], 18: [['rabbit'], 'rabbit', 1, 'none'],
    19: [['bat'], 'bat', 1, 'none'], 20: [['irongolem'], 'iron_golem', 1, 'golem'], 21: [['snowgolem'], 'snow_golem', 1, 'none'],
    22: [['ocelot'], 'ocelot', 1, 'ocelot'], 28: [['polarbear'], 'polarbear', 1, 'quad'], 32: [['zombie'], 'zombie', 1, 'zombie'],
    33: [['creeper'], 'creeper', 1, 'creeper'], 34: [['skeleton'], 'skeleton', 1, 'humanoid'], 35: [['spider'], 'spider', 1, 'spider'],
    36: [['pigzombie'], 'pigzombie', 1, 'zombie'], 37: [['slime'], 'slime', 1, 'none'], 38: [['enderman'], 'enderman', 1, 'humanoid'],
    39: [['silverfish'], 'silverfish', 1, 'none'], 40: [['spider'], 'cave_spider', 0.7, 'spider'], 41: [['ghast'], 'ghast', 4.5, 'none'],
    42: [['lavaslime'], 'magmacube', 1, 'none'], 43: [['blaze'], 'blaze', 1, 'none'], 44: [['zombie.villager'], 'zombie_villager', 1, 'zombie'],
    45: [['villager.witch'], 'witch', 1, 'villager'], 46: [['skeleton.stray'], 'stray', 1, 'humanoid'], 47: [['zombie.husk'], 'husk', 1, 'zombie'],
    48: [['skeleton.wither'], 'wither_skeleton', 1.2, 'humanoid'], 49: [['guardian'], 'guardian', 1, 'none'], 57: [['vindicator'], 'vindicator', 1, 'none'],
    104: [['evoker'], 'evoker', 1, 'none'], 105: [['vex'], 'vex', 0.5, 'none'],
    // [4] — текстура по варианту существа (окрас лошади, ламы, шалкера, облик NPC), [5] — скрытые кости модели
    23: [['horse'], 'horse_brown', 1, 'none', (e) => 'horse_' + (HORSE_COLORS[(e.variant || 0) & 255] || 'brown'), HORSE_HIDE],
    24: [['horse'], 'donkey', 0.87, 'none', null, MULE_HIDE], 25: [['horse'], 'mule', 0.92, 'none', null, MULE_HIDE],
    26: [['horse'], 'horse_skeleton', 1, 'none', null, HORSE_HIDE], 27: [['horse'], 'horse_zombie', 1, 'none', null, HORSE_HIDE],
    29: [['llama'], 'llama_creamy', 1, 'quad', (e) => 'llama_' + (['creamy', 'white', 'brown', 'gray'][e.variant || 0] || 'creamy'), ['chest1', 'chest2']],
    50: [['guardian'], 'guardian_elder', 2.35, 'none'], 51: [['npc'], 'npc_1', 1, 'villager', (e) => 'npc_' + (((e.variant || 0) % 10) + 1)],
    52: [['witherBoss'], 'wither', 2, 'none'], 53: [['dragon'], 'dragon', 1, 'none'],
    54: [['shulker'], 'shulker_purple', 1, 'none', (e) => 'shulker_' + (e.variant >= 0 && e.variant < 16 ? MC.Blocks.COLORS[e.variant] : 'purple')]
  };
  // Модель без скрытых костей (они остаются родителями для остальных)
  const geoCache = new Map();
  function geometryOf(name, hide) {
    const geo = A.geometry[name];
    if (!hide || !geo) return geo;
    const key = name + '|' + hide.join(',');
    let g = geoCache.get(key);
    if (!g) {
      const set = new Set(hide);
      g = Object.assign({}, geo, { bones: geo.bones.filter((b) => !set.has(b.name)), hidden: geo.hidden.concat(geo.bones.filter((b) => set.has(b.name))) });
      geoCache.set(key, g);
    }
    return g;
  }

  const PI = Math.PI;
  const DEG = 180 / PI;
  // Поза костей (углы как в Java-моделях Minecraft, радианы): ls — фаза шага, amt — сила шага, pitch — наклон головы
  function animate(family, ls, amt, pitch) {
    const r = {};
    const c = Math.cos(ls * 0.6662) * 1.4 * amt;
    r.head = [pitch, 0, 0];
    if (family === 'quad' || family === 'wolf' || family === 'creeper') {
      r.leg0 = [c, 0, 0]; r.leg3 = [c, 0, 0]; r.leg1 = [-c, 0, 0]; r.leg2 = [-c, 0, 0];
      if (family === 'wolf') { r.body = [PI / 2, 0, 0]; r.upperBody = [PI / 2, 0, 0]; r.tail = [PI / 5, 0, 0]; }
    }
    if (family === 'quad') r.body = [PI / 2, 0, 0];
    if (family === 'chicken') {
      r.body = [PI / 2, 0, 0]; r.beak = r.head; r.comb = r.head;
      r.leg0 = [c, 0, 0]; r.leg1 = [-c, 0, 0];
    }
    if (family === 'humanoid' || family === 'zombie') {
      r.rightLeg = [c, 0, 0]; r.leftLeg = [-c, 0, 0]; r.hat = r.head;
      const arm = Math.cos(ls * 0.6662) * amt;
      if (family === 'zombie') { r.rightArm = [-PI / 2 + arm * 0.1, 0, 0]; r.leftArm = [-PI / 2 - arm * 0.1, 0, 0]; }
      else { r.rightArm = [-arm, 0, 0]; r.leftArm = [arm, 0, 0]; }
    }
    if (family === 'villager') {
      r.leg0 = [c * 0.5, 0, 0]; r.leg1 = [-c * 0.5, 0, 0]; r.arms = [-0.75, 0, 0];
    }
    if (family === 'golem') {
      r.leg0 = [c * 0.7, 0, 0]; r.leg1 = [-c * 0.7, 0, 0]; r.arm0 = [-c * 0.6, 0, 0]; r.arm1 = [c * 0.6, 0, 0];
    }
    if (family === 'ocelot') {
      const o = Math.cos(ls * 0.6662) * amt;
      r.body = [PI / 2, 0, 0]; r.frontLegL = [o, 0, 0]; r.frontLegR = [-o, 0, 0]; r.backLegL = [-o, 0, 0]; r.backLegR = [o, 0, 0];
    }
    if (family === 'spider') {
      const zr = [-PI / 4, PI / 4, -0.58119464, 0.58119464, -0.58119464, 0.58119464, -PI / 4, PI / 4];
      const yr = [PI / 4, -PI / 4, PI / 8, -PI / 8, -PI / 8, PI / 8, -PI / 4, PI / 4];
      const w = ls * 0.6662 * 2;
      const fy = [0, PI, PI / 2, PI * 1.5].map((ph) => -Math.cos(w + ph) * 0.4 * amt);
      const fz = [0, PI, PI / 2, PI * 1.5].map((ph) => Math.abs(Math.sin(ls * 0.6662 + ph) * 0.4) * amt);
      for (let i = 0; i < 8; i++) {
        const sign = i % 2 ? -1 : 1, k = i >> 1;
        r['leg' + i] = [0, yr[i] + fy[k] * sign, zr[i] + fz[k] * sign];
      }
    }
    return r;
  }

  // Грань куба: углы (верх-лево, верх-право, низ-право, низ-лево текстуры) и затенение.
  // Координаты Bedrock: y вверх, морда смотрит в -z, правая сторона существа в -x.
  function cubeFaces(c) {
    const inf = c.i || 0;
    const x0 = c.o[0] - inf, y0 = c.o[1] - inf, z0 = c.o[2] - inf;
    const x1 = c.o[0] + c.s[0] + inf, y1 = c.o[1] + c.s[1] + inf, z1 = c.o[2] + c.s[2] + inf;
    const w = c.s[0], h = c.s[1], d = c.s[2], u = c.uv[0], v = c.uv[1];
    let right = [u, v + d, d, h], left = [u + d + w, v + d, d, h];
    if (c.m) { const t = right; right = left; left = t; }
    return [
      { r: [u + d, v + d, w, h], p: [[x0, y1, z0], [x1, y1, z0], [x1, y0, z0], [x0, y0, z0]], l: 0.85 },          // морда
      { r: [u + d + d + w, v + d, w, h], p: [[x1, y1, z1], [x0, y1, z1], [x0, y0, z1], [x1, y0, z1]], l: 0.85 },  // спина
      { r: right, p: [[x0, y1, z1], [x0, y1, z0], [x0, y0, z0], [x0, y0, z1]], l: 0.65 },                       // правый бок
      { r: left, p: [[x1, y1, z0], [x1, y1, z1], [x1, y0, z1], [x1, y0, z0]], l: 0.65 },                        // левый бок
      { r: [u + d, v, w, d], p: [[x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0]], l: 1 },                // верх
      { r: [u + d + w, v, w, d], p: [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]], l: 0.5 }           // низ
    ];
  }

  // Поворот точки вокруг шарнира кости: углы Java переводятся в систему Bedrock (ось y развёрнута)
  function rotateAround(v, pivot, rot) {
    let x = v[0] - pivot[0], y = v[1] - pivot[1], z = v[2] - pivot[2];
    const ax = -rot[0], ay = rot[1], az = -rot[2];
    if (ax) { const c = Math.cos(ax), s = Math.sin(ax); const t = y * c - z * s; z = y * s + z * c; y = t; }
    if (ay) { const c = Math.cos(ay), s = Math.sin(ay); const t = x * c + z * s; z = -x * s + z * c; x = t; }
    if (az) { const c = Math.cos(az), s = Math.sin(az); const t = x * c - y * s; y = x * s + y * c; x = t; }
    return [x + pivot[0], y + pivot[1], z + pivot[2]];
  }

  // Вершины модели существа в координатах Bedrock (пиксели) для заданной позы
  function poseModel(geo, pose, out) {
    const all = new Map();
    for (const b of geo.hidden) all.set(b.name, b);
    for (const b of geo.bones) all.set(b.name, b);
    for (const b of geo.bones) {
      const chain = [];
      for (let n = b; n; n = n.parent ? all.get(n.parent) : null) {
        const st = n.rotation, an = pose[n.name];
        const rot = [st[0] / DEG + (an ? an[0] : 0), st[1] / DEG + (an ? an[1] : 0), st[2] / DEG + (an ? an[2] : 0)];
        chain.push([n.pivot, rot]);
        if (chain.length > 8) break;
      }
      for (const c of b.cubes) {
        for (const f of cubeFaces(c)) {
          const pts = f.p.map((p0) => {
            let p = p0;
            for (const [pv, rot] of chain) if (rot[0] || rot[1] || rot[2]) p = rotateAround(p, pv, rot);
            return p;
          });
          out.push({ pts, r: f.r, l: f.l });
        }
      }
    }
    return out;
  }

  class Renderer {
    constructor(canvas) {
      this.canvas = canvas;
      const opts = { antialias: false, alpha: false, preserveDrawingBuffer: false };
      const gl = canvas.getContext('webgl2', opts) || canvas.getContext('webgl', opts) || canvas.getContext('experimental-webgl', opts);
      if (!gl) throw new Error('WebGL не поддерживается этим устройством');
      this.gl = gl;
      this.sections = new Map();
      this.ghostSections = new Map();
      this.skins = new Map();
      this.renderDistance = 8;
      this.fov = 70;
      this.clouds = true;
      this.width = 1;
      this.height = 1;
    }

    async init() {
      const gl = this.gl;
      const prog = gl.createProgram();
      gl.attachShader(prog, compile(gl, gl.VERTEX_SHADER, VS));
      gl.attachShader(prog, compile(gl, gl.FRAGMENT_SHADER, FS));
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error('Ошибка шейдерной программы: ' + gl.getProgramInfoLog(prog));
      this.prog = prog;
      this.a = { pos: gl.getAttribLocation(prog, 'a_pos'), uv: gl.getAttribLocation(prog, 'a_uv'), light: gl.getAttribLocation(prog, 'a_light') };
      this.u = {};
      for (const n of ['u_mvp', 'u_offset', 'u_tex', 'u_tint', 'u_daylight', 'u_alphaTest', 'u_fog', 'u_fogRange', 'u_cam', 'u_time', 'u_fancy', 'u_bright', 'u_minLight']) this.u[n] = gl.getUniformLocation(prog, n);
      const sky = gl.createProgram();
      gl.attachShader(sky, compile(gl, gl.VERTEX_SHADER, SKY_VS));
      gl.attachShader(sky, compile(gl, gl.FRAGMENT_SHADER, SKY_FS));
      gl.linkProgram(sky);
      if (!gl.getProgramParameter(sky, gl.LINK_STATUS)) throw new Error('Ошибка шейдера неба: ' + gl.getProgramInfoLog(sky));
      this.skyProg = sky;
      this.skyA = gl.getAttribLocation(sky, 'a_pos');
      this.skyU = {};
      for (const n of ['u_fwd', 'u_right', 'u_up', 'u_tan', 'u_horizon', 'u_zenith', 'u_sun', 'u_daylight']) this.skyU[n] = gl.getUniformLocation(sky, n);
      this.skyBuf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, this.skyBuf);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
      this.scratch = new Float32Array(6 * 4096);
      this.fancy = true;
      this.startTime = performance.now();
      const [bi, ii] = await Promise.all([loadImage(A.blockAtlas), loadImage(A.itemAtlas)]);
      this.blockTex = this.texture(bi);
      this.itemTex = this.texture(ii);
      this.white = this.texture(null);
      this.mobTex = {};
      const names = Object.keys(A.entityTextures);
      const imgs = await Promise.all(names.map((n) => loadImage(A.entityTextures[n].uri)));
      names.forEach((n, i) => { this.mobTex[n] = { tex: this.texture(imgs[i]), w: A.entityTextures[n].w, h: A.entityTextures[n].h }; });
      this.mobAnim = new Map();
      this.mobLift = new Map();
      const [di, si, mi, ci] = await Promise.all([loadImage(A.destroyStages), loadImage(A.sky.sun), loadImage(A.sky.moon), loadImage(A.sky.clouds)]);
      this.destroyTex = this.texture(di);
      this.sunTex = this.texture(si);
      this.moonTex = this.texture(mi);
      this.cloudTex = this.texture(ci, true);
      this.dyn = gl.createBuffer();
      this.lineBuf = gl.createBuffer();
      gl.enable(gl.DEPTH_TEST);
      gl.enable(gl.CULL_FACE);
      gl.cullFace(gl.BACK);
      this.initPackShaders(bi);
    }

    // Шейдеры из ресурс-пака MCPE (если включён пак с materials и shaders/glsl)
    initPackShaders(atlasImg) {
      const gl = this.gl;
      this.pack = null;
      this.packStatus = '';
      if (!A.packShaders || !MC.PackShaders) return;
      try {
        this.pack = MC.PackShaders.compile(gl, A.packShaders);
        this.packStatus = 'Шейдеры пака «' + A.packShaders.name + '» работают' + (this.pack.sky ? '' : ' (небо — встроенное)');
      } catch (e) {
        console.warn('Шейдеры пака', e);
        this.packStatus = 'Шейдеры пака «' + A.packShaders.name + '» не запустились: ' + e.message;
        return;
      }
      this.atlasSize = [atlasImg.width, atlasImg.height];
      this.lightmap = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, this.lightmap);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      this.lightmapDay = -1;
      this.updateLightmap(1);
      // Купол неба: центр, кольцо у горизонта и юбка ниже горизонта
      const v = [];
      const N = 48;
      const ring = (i, r, y) => [Math.cos(i / N * Math.PI * 2) * r, y, Math.sin(i / N * Math.PI * 2) * r];
      for (let i = 0; i < N; i++) {
        const a0 = ring(i, 1, 0), a1 = ring(i + 1, 1, 0), b0 = ring(i, 1.6, -0.5), b1 = ring(i + 1, 1.6, -0.5);
        v.push(0, 0.16, 0, ...a1, ...a0);
        v.push(...a0, ...a1, ...b1, ...a0, ...b1, ...b0);
      }
      this.packSkyN = v.length / 3;
      this.packSkyBuf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, this.packSkyBuf);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(v), gl.STATIC_DRAW);
    }

    // Карта освещения MCPE 16x16: по x — блочный свет, по y — свет неба с учётом времени суток
    updateLightmap(daylight) {
      if (this.fullbright) daylight = Math.max(daylight, 1.5);
      if (Math.abs(daylight - this.lightmapDay) < 0.003) return;
      this.lightmapDay = daylight;
      const gl = this.gl;
      const d = new Uint8Array(16 * 16 * 4);
      const curve = (l) => { const f = l / 15; return f / (4 - 3 * f); };
      for (let s = 0; s < 16; s++) for (let b = 0; b < 16; b++) {
        const sky = Math.min(1, daylight > 1 ? Math.max(0.9, curve(s)) : curve(s) * daylight), blk = curve(b);
        const i = (s * 16 + b) * 4;
        d[i] = Math.min(255, Math.max(sky, blk) * 255 + 10);
        d[i + 1] = Math.min(255, Math.max(sky, blk * 0.9) * 255 + 10);
        d[i + 2] = Math.min(255, Math.max(sky, blk * 0.75) * 255 + 10);
        d[i + 3] = 255;
      }
      gl.bindTexture(gl.TEXTURE_2D, this.lightmap);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 16, 16, 0, gl.RGBA, gl.UNSIGNED_BYTE, d);
    }

    // Цвет тумана в стиле MCPE: шейдер-паки определяют по нему день, закат, ночь и подводный мир
    static packFog(daylight, time) {
      const a = (((time % 24000) + 24000) % 24000) / 24000 * Math.PI * 2;
      const dawn = 1 - Math.min(1, Math.abs(Math.sin(a)) / 0.3);
      const day = [0.72, 0.83, 1.0], dusk = [0.95, 0.52, 0.28];
      const k = Math.max(0.06, daylight * daylight);
      return day.map((v, i) => (v + (dusk[i] - v) * dawn * 0.85) * k);
    }

    packFrame(P, view, proj, vp, cam, fog, fogControl) {
      const gl = this.gl, u = P.u;
      gl.useProgram(P.prog);
      const id = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
      if (u.WORLDVIEWPROJ) gl.uniformMatrix4fv(u.WORLDVIEWPROJ, false, vp);
      if (u.WORLDVIEW) gl.uniformMatrix4fv(u.WORLDVIEW, false, view);
      if (u.PROJ) gl.uniformMatrix4fv(u.PROJ, false, proj);
      if (u.WORLD) gl.uniformMatrix4fv(u.WORLD, false, id);
      if (u.UV_TRANSFORM) gl.uniformMatrix4fv(u.UV_TRANSFORM, false, id);
      if (u.VIEW_POS) gl.uniform3f(u.VIEW_POS, cam.x, cam.y, cam.z);
      if (u.TIME) gl.uniform1f(u.TIME, (performance.now() - this.startTime) / 1000 % 3600);
      if (u.FOG_COLOR) gl.uniform4f(u.FOG_COLOR, fog[0], fog[1], fog[2], 1);
      if (u.FOG_CONTROL) gl.uniform2f(u.FOG_CONTROL, fogControl[0], fogControl[1]);
      if (u.RENDER_DISTANCE) gl.uniform1f(u.RENDER_DISTANCE, this.renderDistance * 16);
      if (u.FAR_CHUNKS_DISTANCE) gl.uniform1f(u.FAR_CHUNKS_DISTANCE, this.renderDistance * 16);
      if (u.CURRENT_COLOR) gl.uniform4f(u.CURRENT_COLOR, 1, 1, 1, 1);
      if (u.DARKEN) gl.uniform4f(u.DARKEN, 0, 0, 0, 0);
      if (u.HUD_OPACITY) gl.uniform1f(u.HUD_OPACITY, 1);
      if (u.TILE_LIGHT_COLOR) gl.uniform4f(u.TILE_LIGHT_COLOR, 1, 1, 1, 1);
      if (u.OVERLAY_COLOR) gl.uniform4f(u.OVERLAY_COLOR, 0, 0, 0, 0);
      if (u.TEXTURE_DIMENSIONS) gl.uniform3f(u.TEXTURE_DIMENSIONS, this.atlasSize[0], this.atlasSize[1], 1);
      if (u.TEXTURE_0) gl.uniform1i(u.TEXTURE_0, 0);
      if (u.TEXTURE_1) gl.uniform1i(u.TEXTURE_1, 1);
      if (u.TEXTURE_2) gl.uniform1i(u.TEXTURE_2, 2);
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, this.lightmap);
      gl.activeTexture(gl.TEXTURE2);
      gl.bindTexture(gl.TEXTURE_2D, this.white);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
    }

    bindPackAttribs(P, buf) {
      const gl = this.gl, a = P.a;
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      if (a.pos >= 0) { gl.enableVertexAttribArray(a.pos); gl.vertexAttribPointer(a.pos, 3, gl.FLOAT, false, 24, 0); }
      if (a.uv >= 0) { gl.enableVertexAttribArray(a.uv); gl.vertexAttribPointer(a.uv, 2, gl.FLOAT, false, 24, 12); }
      if (a.light >= 0) { gl.enableVertexAttribArray(a.light); gl.vertexAttribPointer(a.light, 1, gl.FLOAT, false, 24, 20); }
    }

    drawPackSections(P, list, trans, ctx) {
      const gl = this.gl;
      this.packFrame(P, ctx.view, ctx.proj, ctx.vp, ctx.cam, ctx.fog, ctx.fogControl);
      const u = P.u.CHUNK_ORIGIN_AND_SCALE;
      const order = trans ? list.slice().reverse() : list;
      for (const v of order) {
        const n = trans ? v.s.tn : v.s.n;
        if (!n) continue;
        if (u) gl.uniform4f(u, v.ox, v.oy, v.oz, 1);
        this.bindPackAttribs(P, trans ? v.s.tbo : v.s.vbo);
        gl.drawArrays(gl.TRIANGLES, 0, n);
      }
      gl.useProgram(this.prog);
    }

    renderPackSky(ctx) {
      const gl = this.gl, P = this.pack.sky;
      const S = Math.min(96, (this.renderDistance * 16 + 48) * 0.7);
      const model = [S, 0, 0, 0, 0, S, 0, 0, 0, 0, S, 0, 0, 0, 0, 1];
      const wvp = M4.mul(ctx.vp, model);
      this.packFrame(P, M4.mul(ctx.view, model), ctx.proj, wvp, ctx.cam, ctx.fog, ctx.fogControl);
      gl.disable(gl.DEPTH_TEST);
      gl.disable(gl.CULL_FACE);
      gl.depthMask(false);
      for (let i = 0; i < 8; i++) gl.disableVertexAttribArray(i);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.packSkyBuf);
      if (P.a.pos >= 0) { gl.enableVertexAttribArray(P.a.pos); gl.vertexAttribPointer(P.a.pos, 3, gl.FLOAT, false, 12, 0); }
      gl.drawArrays(gl.TRIANGLES, 0, this.packSkyN);
      if (P.a.pos >= 0) gl.disableVertexAttribArray(P.a.pos);
      gl.depthMask(true);
      gl.enable(gl.DEPTH_TEST);
      gl.enable(gl.CULL_FACE);
      gl.useProgram(this.prog);
    }

    texture(img, repeat) {
      const gl = this.gl;
      const t = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, t);
      if (img) gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);
      else gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([255, 255, 255, 255]));
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, repeat ? gl.REPEAT : gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, repeat ? gl.REPEAT : gl.CLAMP_TO_EDGE);
      return t;
    }

    // Скин игрока из сырых RGBA-данных (64x32 или 64x64)
    skinTexture(key, rgba) {
      if (this.skins.has(key)) return this.skins.get(key);
      const gl = this.gl;
      const h = rgba && rgba.length === 64 * 64 * 4 ? 64 : 32;
      const t = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, t);
      const data = rgba && (rgba.length === 8192 || rgba.length === 16384) ? rgba : MC.Skin.defaultSkin();
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 64, data.length === 16384 ? 64 : 32, 0, gl.RGBA, gl.UNSIGNED_BYTE, data);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      const s = { tex: t, h: data.length === 16384 ? 64 : h };
      this.skins.set(key, s);
      return s;
    }

    dropSkin(key) {
      const s = this.skins.get(key);
      if (s) { this.gl.deleteTexture(s.tex); this.skins.delete(key); }
    }

    resize(w, h, ratio) {
      const cw = Math.floor(w * ratio), ch = Math.floor(h * ratio);
      if (this.canvas.width !== cw || this.canvas.height !== ch) {
        this.canvas.width = cw;
        this.canvas.height = ch;
      }
      this.width = w;
      this.height = h;
    }

    setSection(cx, sy, cz, mesh) {
      const gl = this.gl;
      const k = cx + ',' + sy + ',' + cz;
      let s = this.sections.get(k);
      if (!s) {
        if (!mesh.solid.length && !mesh.trans.length) return;
        s = { cx, sy, cz, vbo: gl.createBuffer(), tbo: gl.createBuffer(), n: 0, tn: 0 };
        this.sections.set(k, s);
      }
      s.n = mesh.solid.length / 6;
      s.tn = mesh.trans.length / 6;
      gl.bindBuffer(gl.ARRAY_BUFFER, s.vbo);
      gl.bufferData(gl.ARRAY_BUFFER, mesh.solid, gl.STATIC_DRAW);
      gl.bindBuffer(gl.ARRAY_BUFFER, s.tbo);
      gl.bufferData(gl.ARRAY_BUFFER, mesh.trans, gl.STATIC_DRAW);
    }

    // Голограмма схемы: отдельные секции, рисуются полупрозрачно поверх мира
    setGhostSection(cx, sy, cz, mesh) {
      const gl = this.gl;
      const k = cx + ',' + sy + ',' + cz;
      let s = this.ghostSections.get(k);
      if (!mesh.solid.length && !mesh.trans.length) { this.removeGhostSection(cx, sy, cz); return; }
      if (!s) { s = { cx, sy, cz, vbo: gl.createBuffer(), n: 0 }; this.ghostSections.set(k, s); }
      const all = new Float32Array(mesh.solid.length + mesh.trans.length);
      all.set(mesh.solid, 0);
      all.set(mesh.trans, mesh.solid.length);
      s.n = all.length / 6;
      gl.bindBuffer(gl.ARRAY_BUFFER, s.vbo);
      gl.bufferData(gl.ARRAY_BUFFER, all, gl.STATIC_DRAW);
    }

    removeGhostSection(cx, sy, cz) {
      const k = cx + ',' + sy + ',' + cz;
      const s = this.ghostSections.get(k);
      if (!s) return;
      this.gl.deleteBuffer(s.vbo);
      this.ghostSections.delete(k);
    }

    renderGhost(cam, planes, fogNear, fogFar, daylight) {
      const gl = this.gl;
      if (!this.ghostSections.size) return;
      gl.useProgram(this.prog);
      gl.uniform1f(this.u.u_daylight, Math.max(0.6, daylight));
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
      gl.uniform2f(this.u.u_fogRange, fogNear, fogFar);
      gl.uniform1f(this.u.u_alphaTest, 0.1);
      gl.uniform4f(this.u.u_tint, 0.7, 0.85, 1.0, 0.5);
      gl.disable(gl.CULL_FACE);
      gl.depthMask(false);
      for (const s of this.ghostSections.values()) {
        if (!s.n) continue;
        const ox = s.cx * 16 - cam.x, oy = s.sy * 16 - cam.y, oz = s.cz * 16 - cam.z;
        if (!boxInFrustum(planes, ox, oy, oz, ox + 16, oy + 16, oz + 16)) continue;
        gl.uniform3f(this.u.u_offset, ox, oy, oz);
        this.bindAttribs(s.vbo);
        gl.drawArrays(gl.TRIANGLES, 0, s.n);
      }
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      gl.depthMask(true);
      gl.enable(gl.CULL_FACE);
    }

    // Предпросмотр фигуры строительства: видимые грани полупрозрачные, рамка вокруг всей фигуры
    renderBuild(pv, cam) {
      const gl = this.gl;
      if (this.buildV !== pv.v) {
        this.buildV = pv.v;
        const list = pv.list;
        const set = new Set();
        let x0 = Infinity, y0 = Infinity, z0 = Infinity, x1 = -Infinity, y1 = -Infinity, z1 = -Infinity;
        for (const p of list) {
          set.add(p.x + ',' + p.y + ',' + p.z);
          if (p.x < x0) x0 = p.x; if (p.y < y0) y0 = p.y; if (p.z < z0) z0 = p.z;
          if (p.x > x1) x1 = p.x; if (p.y > y1) y1 = p.y; if (p.z > z1) z1 = p.z;
        }
        const o = list.length ? list[0] : { x: 0, y: 0, z: 0 };
        const F = MC.Mesher.FACES, e = 0.004, MAXF = 40000;
        const out = new Float32Array(Math.min(list.length * 6, MAXF) * 36);
        let n = 0, faces = 0;
        for (const p of list) {
          for (let f = 0; f < 6 && faces < MAXF; f++) {
            const d = F[f].n;
            if (set.has((p.x + d[0]) + ',' + (p.y + d[1]) + ',' + (p.z + d[2]))) continue;
            faces++;
            const c = F[f].c;
            for (const k of [0, 1, 2, 0, 2, 3]) {
              out[n++] = p.x - o.x + (c[k][0] ? 1 + e : -e);
              out[n++] = p.y - o.y + (c[k][1] ? 1 + e : -e);
              out[n++] = p.z - o.z + (c[k][2] ? 1 + e : -e);
              out[n++] = 0; out[n++] = 0; out[n++] = 1;
            }
          }
        }
        if (!this.buildBuf) this.buildBuf = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.buildBuf);
        gl.bufferData(gl.ARRAY_BUFFER, out.subarray(0, n), gl.STATIC_DRAW);
        this.buildN = n / 6;
        this.buildOrigin = o;
        this.buildBox = list.length ? [x0 - o.x - e, y0 - o.y - e, z0 - o.z - e, x1 + 1 - o.x + e, y1 + 1 - o.y + e, z1 + 1 - o.z + e] : null;
      }
      if (!this.buildN) return;
      const o = this.buildOrigin;
      gl.useProgram(this.prog);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.white);
      gl.uniform1f(this.u.u_daylight, 1);
      gl.uniform2f(this.u.u_fogRange, 1000, 2000);
      gl.uniform1f(this.u.u_alphaTest, 0);
      gl.uniform3f(this.u.u_offset, o.x - cam.x, o.y - cam.y, o.z - cam.z);
      gl.disable(gl.CULL_FACE);
      gl.depthMask(false);
      const c = pv.kind === 'break' ? [1, 0.25, 0.2] : pv.kind === 'copy' ? [1, 0.85, 0.2] : [0.35, 0.75, 1];
      gl.uniform4f(this.u.u_tint, c[0], c[1], c[2], 0.3);
      this.bindAttribs(this.buildBuf);
      gl.drawArrays(gl.TRIANGLES, 0, this.buildN);
      if (this.buildBox) {
        const b = this.buildBox;
        const p = [[b[0], b[1], b[2]], [b[3], b[1], b[2]], [b[3], b[1], b[5]], [b[0], b[1], b[5]], [b[0], b[4], b[2]], [b[3], b[4], b[2]], [b[3], b[4], b[5]], [b[0], b[4], b[5]]];
        const lines = [];
        for (const [a, q] of [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]]) lines.push(...p[a], 0, 0, 1, ...p[q], 0, 0, 1);
        gl.uniform4f(this.u.u_tint, c[0], c[1], c[2], 0.9);
        this.drawDynamic(lines, gl.LINES);
      }
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      gl.depthMask(true);
      gl.enable(gl.CULL_FACE);
    }

    removeSection(cx, sy, cz) {
      const k = cx + ',' + sy + ',' + cz;
      const s = this.sections.get(k);
      if (!s) return;
      this.gl.deleteBuffer(s.vbo);
      this.gl.deleteBuffer(s.tbo);
      this.sections.delete(k);
    }

    clearSections() {
      for (const s of this.sections.values()) { this.gl.deleteBuffer(s.vbo); this.gl.deleteBuffer(s.tbo); }
      this.sections.clear();
      for (const s of this.ghostSections.values()) this.gl.deleteBuffer(s.vbo);
      this.ghostSections.clear();
    }

    bindAttribs(buf) {
      const gl = this.gl;
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.enableVertexAttribArray(this.a.pos);
      gl.enableVertexAttribArray(this.a.uv);
      gl.enableVertexAttribArray(this.a.light);
      gl.vertexAttribPointer(this.a.pos, 3, gl.FLOAT, false, 24, 0);
      gl.vertexAttribPointer(this.a.uv, 2, gl.FLOAT, false, 24, 12);
      gl.vertexAttribPointer(this.a.light, 1, gl.FLOAT, false, 24, 20);
    }

    // data: Float32Array или обычный массив; массив копируется в общий буфер без новых выделений памяти
    drawDynamic(data, mode) {
      const gl = this.gl;
      let buf = data;
      if (!(data instanceof Float32Array)) {
        if (this.scratch.length < data.length) this.scratch = new Float32Array(Math.max(data.length, this.scratch.length * 2));
        this.scratch.set(data);
        buf = this.scratch.subarray(0, data.length);
      }
      if (!buf.length) return;
      gl.bindBuffer(gl.ARRAY_BUFFER, this.dyn);
      gl.bufferData(gl.ARRAY_BUFFER, buf, gl.STREAM_DRAW);
      this.bindAttribs(this.dyn);
      gl.drawArrays(mode === undefined ? gl.TRIANGLES : mode, 0, buf.length / 6);
    }

    static skyColor(daylight) {
      const day = [0.49, 0.67, 1.0], night = [0.02, 0.03, 0.08];
      const t = Math.max(0, Math.min(1, (daylight - 0.25) / 0.75));
      return [night[0] + (day[0] - night[0]) * t, night[1] + (day[1] - night[1]) * t, night[2] + (day[2] - night[2]) * t];
    }

    // cam: {x, y, z, yaw, pitch}; scene: {daylight, underwater, entities, players, items, selection}
    render(cam, scene) {
      const gl = this.gl;
      gl.viewport(0, 0, this.canvas.width, this.canvas.height);
      const daylight = scene.daylight;
      // Нижний мир и Край: без неба, солнца и облаков, свой цвет тумана; ночное зрение — полный свет
      const dim = scene.dimension || 0;
      const light = scene.light === undefined ? daylight : scene.light;
      this.sceneLight = light;
      const usePack = !!(this.pack && this.usePack) && !dim;
      let fog = usePack ? Renderer.packFog(daylight, scene.time || 0) : Renderer.skyColor(daylight);
      let fogNear = this.renderDistance * 16 * 0.6, fogFar = this.renderDistance * 16 - 2;
      if (dim === 1) { fog = [0.24, 0.05, 0.04]; fogNear = this.renderDistance * 16 * 0.25; }
      else if (dim === 2) fog = [0.06, 0.04, 0.08];
      let fogControl = [0.6, 1.0];
      if (usePack && scene.underwater) { fog = [0.1, 0.1, 0.32].map((v) => v * Math.max(0.35, daylight)); fogControl = [0, 24 / (this.renderDistance * 16)]; }
      if (scene.underwater) {
        fog = [0.05, 0.12, 0.35].map((v) => v * daylight);
        // Clear Water (мод): под водой видно далеко
        if (this.clearWater) { fogNear = this.renderDistance * 16 * 0.3; fogFar = this.renderDistance * 16 * 0.8; }
        else { fogNear = 2; fogFar = 24; }
      }
      if (scene.inLava) { fog = [0.6, 0.15, 0.0]; fogNear = 0.2; fogFar = 3; }
      gl.clearColor(fog[0], fog[1], fog[2], 1);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

      const yaw = cam.yaw * Math.PI / 180, pitch = cam.pitch * Math.PI / 180;
      const fwd = [-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch)];
      const proj = M4.perspective(this.fov * Math.PI / 180, this.width / this.height, 0.05, this.renderDistance * 16 + 48);
      // Наклон камеры (удар): вектор «вверх» поворачивается вокруг направления взгляда
      let up = [0, 1, 0];
      if (cam.roll) {
        const a = cam.roll * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
        // Формула Родрига для (0, 1, 0) вокруг оси взгляда k
        const k = fwd;
        up = [-k[2] * s + k[0] * k[1] * (1 - c), c + k[1] * k[1] * (1 - c), k[0] * s + k[2] * k[1] * (1 - c)];
      }
      const view = M4.lookAt([0, 0, 0], fwd, up);
      const vp = M4.mul(proj, view);
      this.vp = vp;
      this.cam = cam;
      const planes = frustumPlanes(vp);
      const packCtx = usePack ? { view, proj, vp, cam, fog, fogControl } : null;
      if (usePack) this.updateLightmap(light);
      if (usePack && this.pack.sky && !scene.underwater && !scene.inLava) this.renderPackSky(packCtx);
      else if (this.fancy && !scene.underwater && !scene.inLava && !dim) this.renderSkyGradient(scene, fwd, fog, daylight);

      gl.useProgram(this.prog);
      gl.uniformMatrix4fv(this.u.u_mvp, false, vp);
      gl.uniform1i(this.u.u_tex, 0);
      gl.uniform3f(this.u.u_cam, cam.x, cam.y, cam.z);
      gl.uniform1f(this.u.u_time, (performance.now() - this.startTime) / 1000 % 10000);
      gl.uniform1f(this.u.u_fancy, this.fancy ? 1 : 0);
      gl.uniform1f(this.u.u_bright, this.brightness || 1);
      // Fullbright (мод) и ночное зрение: всё видно даже в пещерах
      gl.uniform1f(this.u.u_minLight, this.fullbright ? 0.92 : 0);
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      gl.uniform1f(this.u.u_daylight, light);
      gl.uniform3f(this.u.u_fog, fog[0], fog[1], fog[2]);
      gl.uniform2f(this.u.u_fogRange, fogNear, fogFar);
      gl.uniform1f(this.u.u_alphaTest, 0.5);
      gl.activeTexture(gl.TEXTURE0);
      if (!scene.underwater && !scene.inLava && !dim) this.renderSky(scene);
      gl.bindTexture(gl.TEXTURE_2D, this.blockTex);

      const maxDist = this.renderDistance * 16 + 24;
      const visible = [];
      for (const s of this.sections.values()) {
        const ox = s.cx * 16 - cam.x, oy = s.sy * 16 - cam.y, oz = s.cz * 16 - cam.z;
        const dx = ox + 8, dy = oy + 8, dz = oz + 8;
        const d2 = dx * dx + dz * dz;
        if (d2 > maxDist * maxDist) continue;
        if (!boxInFrustum(planes, ox, oy, oz, ox + 16, oy + 16, oz + 16)) continue;
        visible.push({ s, ox, oy, oz, d: d2 + dy * dy });
      }
      visible.sort((a, b) => a.d - b.d);

      gl.disable(gl.BLEND);
      gl.depthMask(true);
      if (usePack) this.drawPackSections(this.pack.solid, visible, false, packCtx);
      else {
        for (const v of visible) {
          if (!v.s.n) continue;
          gl.uniform3f(this.u.u_offset, v.ox, v.oy, v.oz);
          this.bindAttribs(v.s.vbo);
          gl.drawArrays(gl.TRIANGLES, 0, v.s.n);
        }
      }

      this.renderEntities(scene, cam);
      if (scene.particles) this.renderParticles(scene.particles, cam);
      if (this.showHitboxes) this.renderHitboxes(scene, cam);

      // Полупрозрачные блоки (вода, лёд) — от дальних к ближним
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      gl.depthMask(false);
      gl.disable(gl.CULL_FACE);
      gl.uniform1f(this.u.u_alphaTest, 0.01);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 0.75);
      if (usePack && this.pack.trans) this.drawPackSections(this.pack.trans, visible, true, packCtx);
      else {
        for (let i = visible.length - 1; i >= 0; i--) {
          const v = visible[i];
          if (!v.s.tn) continue;
          gl.uniform3f(this.u.u_offset, v.ox, v.oy, v.oz);
          this.bindAttribs(v.s.tbo);
          gl.drawArrays(gl.TRIANGLES, 0, v.s.tn);
        }
      }
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      if (scene.beacons && scene.beacons.length) this.renderBeacons(scene.beacons, cam);
      // Облака шейдер-пак рисует сам в небе
      if (this.clouds && !scene.underwater && !scene.inLava && !dim && !(usePack && this.pack.sky)) this.renderClouds(scene, cam, fogFar);
      gl.depthMask(true);
      gl.enable(gl.CULL_FACE);

      if (this.ghostSections.size) this.renderGhost(cam, planes, fogNear, fogFar, light);
      if (scene.build) this.renderBuild(scene.build, cam);
      if (scene.schemMarks) this.renderSchemMarks(scene.schemMarks, cam);
      if (scene.selection) this.renderSelection(scene.selection, cam, scene.breakProgress || 0);
      if (scene.aimTarget) this.renderAimTarget(scene.aimTarget, cam);
      gl.disable(gl.BLEND);
      if (scene.hand) this.renderHand(scene.hand);
    }

    renderSkyGradient(scene, fwd, horizon, daylight) {
      const gl = this.gl;
      const time = scene.time || 0;
      const a = (((time % 24000) + 24000) % 24000) / 24000 * Math.PI * 2;
      const right = [fwd[2], 0, -fwd[0]];
      const rl = Math.hypot(right[0], right[2]) || 1;
      right[0] /= rl; right[2] /= rl;
      const up = [right[1] * fwd[2] - right[2] * fwd[1], right[2] * fwd[0] - right[0] * fwd[2], right[0] * fwd[1] - right[1] * fwd[0]];
      const tanY = Math.tan(this.fov * Math.PI / 360), tanX = tanY * this.width / this.height;
      const zenith = Renderer.skyColor(daylight).map((v, i) => v * [0.62, 0.72, 1.0][i]);
      gl.useProgram(this.skyProg);
      gl.disable(gl.DEPTH_TEST);
      gl.depthMask(false);
      gl.uniform3f(this.skyU.u_fwd, fwd[0], fwd[1], fwd[2]);
      gl.uniform3f(this.skyU.u_right, right[0], right[1], right[2]);
      gl.uniform3f(this.skyU.u_up, up[0], up[1], up[2]);
      gl.uniform2f(this.skyU.u_tan, tanX, tanY);
      gl.uniform3f(this.skyU.u_horizon, horizon[0], horizon[1], horizon[2]);
      gl.uniform3f(this.skyU.u_zenith, zenith[0], zenith[1], zenith[2]);
      gl.uniform3f(this.skyU.u_sun, Math.cos(a), Math.sin(a), 0);
      gl.uniform1f(this.skyU.u_daylight, daylight);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.skyBuf);
      gl.enableVertexAttribArray(this.skyA);
      gl.vertexAttribPointer(this.skyA, 2, gl.FLOAT, false, 8, 0);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      gl.disableVertexAttribArray(this.skyA);
      gl.depthMask(true);
      gl.enable(gl.DEPTH_TEST);
    }

    // Солнце и луна (фаза по номеру дня), как в Minecraft: восходят на востоке (+x), заходят на западе
    renderSky(scene) {
      const gl = this.gl;
      const time = scene.time || 0;
      const a = (((time % 24000) + 24000) % 24000) / 24000 * Math.PI * 2;
      const dir = [Math.cos(a), Math.sin(a), 0];
      const side = [-Math.sin(a), Math.cos(a), 0];
      const dist = 60, size = 18;
      const quad = (d, sz, u0, v0, u1, v1) => {
        const cx = d[0] * dist, cy = d[1] * dist;
        const sx = side[0] * sz, sy = side[1] * sz;
        const p = [[cx - sx, cy - sy, -sz, u0, v1], [cx + sx, cy + sy, -sz, u1, v1], [cx + sx, cy + sy, sz, u1, v0], [cx - sx, cy - sy, sz, u0, v0]];
        const out = [];
        for (const k of [0, 1, 2, 0, 2, 3]) out.push(p[k][0], p[k][1], p[k][2], p[k][3], p[k][4], 1);
        return new Float32Array(out);
      };
      gl.disable(gl.DEPTH_TEST);
      gl.disable(gl.CULL_FACE);
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.ONE, gl.ONE);
      gl.uniform3f(this.u.u_offset, 0, 0, 0);
      gl.uniform1f(this.u.u_daylight, 1);
      gl.uniform2f(this.u.u_fogRange, 10000, 20000);
      gl.uniform1f(this.u.u_alphaTest, 0);
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      gl.bindTexture(gl.TEXTURE_2D, this.sunTex);
      this.drawDynamic(quad(dir, size, 0, 0, 1, 1));
      const phase = Math.floor(time / 24000) % 8;
      const mu = (phase % 4) / 4, mv = Math.floor(phase / 4) / 2;
      gl.bindTexture(gl.TEXTURE_2D, this.moonTex);
      this.drawDynamic(quad([-dir[0], -dir[1], 0], size * 0.8, mu, mv, mu + 0.25, mv + 0.5));
      gl.disable(gl.BLEND);
      gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      gl.enable(gl.DEPTH_TEST);
      gl.enable(gl.CULL_FACE);
      gl.uniform1f(this.u.u_daylight, this.sceneLight);
      gl.uniform2f(this.u.u_fogRange, this.renderDistance * 16 * 0.6, this.renderDistance * 16 - 2);
      gl.uniform1f(this.u.u_alphaTest, 0.5);
    }

    // Облака clouds.png на высоте 128: один пиксель текстуры — 12 блоков, медленно плывут на запад
    renderClouds(scene, cam, fogFar) {
      const gl = this.gl;
      const y = 128.33 - cam.y;
      const r = this.renderDistance * 16 + 32;
      const span = 256 * 12;
      const drift = (scene.time || 0) * 0.03;
      const u = (wx) => (wx + drift) / span, v = (wz) => wz / span;
      // Сетка из клеток, чтобы туман считался по расстоянию до каждой части слоя
      const n = 24, step = (r * 2) / n;
      // Один буфер на все кадры: без мусора для сборщика памяти
      const out = this.cloudVerts && this.cloudVerts.length === n * n * 36 ? this.cloudVerts : (this.cloudVerts = new Float32Array(n * n * 36));
      const QX = [0, 1, 1, 0, 1, 0], QZ = [0, 0, 1, 0, 1, 1];
      let o = 0;
      for (let i = 0; i < n; i++) {
        for (let j = 0; j < n; j++) {
          const ax = -r + i * step, az = -r + j * step;
          for (let k = 0; k < 6; k++) {
            const px = ax + QX[k] * step, pz = az + QZ[k] * step;
            out[o++] = px; out[o++] = y; out[o++] = pz; out[o++] = u(cam.x + px); out[o++] = v(cam.z + pz); out[o++] = 1;
          }
        }
      }
      gl.disable(gl.CULL_FACE);
      gl.uniform3f(this.u.u_offset, 0, 0, 0);
      gl.uniform1f(this.u.u_alphaTest, 0.5);
      gl.uniform2f(this.u.u_fogRange, fogFar * 0.5, r);
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 0.8);
      gl.bindTexture(gl.TEXTURE_2D, this.cloudTex);
      this.drawDynamic(out);
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      gl.uniform2f(this.u.u_fogRange, this.renderDistance * 16 * 0.6, fogFar);
    }

    // Хитбоксы (как F3+B в Minecraft): белая рамка тела, красная — уровень глаз, синяя линия — направление взгляда
    renderHitboxes(scene, cam) {
      const gl = this.gl;
      const white = [], red = [], blue = [];
      const box = (out, x0, y0, z0, x1, y1, z1) => {
        const c = [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], [x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]];
        for (const [a, b] of [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]]) {
          out.push(c[a][0], c[a][1], c[a][2], 0, 0, 1, c[b][0], c[b][1], c[b][2], 0, 0, 1);
        }
      };
      const living = (e, w, h, d, eye) => {
        const x = e.x - cam.x, y = e.y - cam.y, z = e.z - cam.z;
        if (x * x + z * z > 64 * 64) return;
        box(white, x - w / 2, y, z - d / 2, x + w / 2, y + h, z + d / 2);
        const ey = y + eye;
        red.push(x - w / 2, ey, z - d / 2, 0, 0, 1, x + w / 2, ey, z - d / 2, 0, 0, 1, x + w / 2, ey, z - d / 2, 0, 0, 1, x + w / 2, ey, z + d / 2, 0, 0, 1,
          x + w / 2, ey, z + d / 2, 0, 0, 1, x - w / 2, ey, z + d / 2, 0, 0, 1, x - w / 2, ey, z + d / 2, 0, 0, 1, x - w / 2, ey, z - d / 2, 0, 0, 1);
        const yaw = (e.yaw || 0) * Math.PI / 180, pitch = (e.pitch || 0) * Math.PI / 180;
        const dx = -Math.sin(yaw) * Math.cos(pitch), dy = -Math.sin(pitch), dz = Math.cos(yaw) * Math.cos(pitch);
        blue.push(x, ey, z, 0, 0, 1, x + dx * 2, ey + dy * 2, z + dz * 2, 0, 0, 1);
      };
      for (const p of scene.players) living(p, 0.6, 1.8, 0.6, 1.62);
      for (const m of scene.entities) {
        if (m.dead) continue;
        if (m.type === 65 || m.type === 66) {
          const x = m.x - cam.x, y = m.y - cam.y, z = m.z - cam.z;
          box(white, x - 0.49, y, z - 0.49, x + 0.49, y + 0.98, z + 0.49);
          continue;
        }
        const look = ENTITY_LOOK[m.type];
        const s = look ? look[2] : [0.6, 1.8, 0.6];
        living(m, s[0], s[1], s[2], s[1] * 0.85);
      }
      for (const it of scene.items) {
        const x = it.x - cam.x, y = it.y - cam.y, z = it.z - cam.z;
        if (x * x + y * y + z * z > 40 * 40) continue;
        box(white, x - 0.125, y, z - 0.125, x + 0.125, y + 0.25, z + 0.125);
      }
      gl.uniform3f(this.u.u_offset, 0, 0, 0);
      gl.bindTexture(gl.TEXTURE_2D, this.white);
      gl.uniform1f(this.u.u_daylight, 1);
      gl.uniform2f(this.u.u_fogRange, 1000, 2000);
      gl.uniform1f(this.u.u_alphaTest, 0);
      for (const [list, c] of [[white, [1, 1, 1]], [red, [1, 0.15, 0.15]], [blue, [0.2, 0.4, 1]]]) {
        if (!list.length) continue;
        gl.uniform4f(this.u.u_tint, c[0], c[1], c[2], 1);
        this.drawDynamic(list, gl.LINES);
      }
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
    }

    // Рамки схемы: красные — не тот блок, оранжевые — не тот поворот, белая — клетка Easy Place
    renderSchemMarks(m, cam) {
      const gl = this.gl;
      if (this.marksV !== m) {
        this.marksV = m;
        const L = m.list, o = L.length ? [L[0], L[1], L[2]] : [0, 0, 0];
        const e = 0.01;
        const edges = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]];
        const byKind = [[], []];
        for (let i = 0; i < L.length; i += 4) {
          const x0 = L[i] - o[0] - e, y0 = L[i + 1] - o[1] - e, z0 = L[i + 2] - o[2] - e, x1 = x0 + 1 + 2 * e, y1 = y0 + 1 + 2 * e, z1 = z0 + 1 + 2 * e;
          const c = [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], [x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]];
          const out = byKind[L[i + 3]];
          for (const [a, b] of edges) out.push(c[a][0], c[a][1], c[a][2], 0, 0, 1, c[b][0], c[b][1], c[b][2], 0, 0, 1);
        }
        this.marksLines = byKind.map((a) => new Float32Array(a));
        this.marksOrigin = o;
      }
      gl.useProgram(this.prog);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.white);
      gl.uniform1f(this.u.u_daylight, 1);
      gl.uniform2f(this.u.u_fogRange, 1000, 2000);
      gl.uniform1f(this.u.u_alphaTest, 0);
      const o = this.marksOrigin;
      gl.uniform3f(this.u.u_offset, o[0] - cam.x, o[1] - cam.y, o[2] - cam.z);
      const colors = [[1, 0.15, 0.1, 0.95], [1, 0.6, 0.05, 0.95]];
      for (let k = 0; k < 2; k++) {
        if (!this.marksLines[k].length) continue;
        gl.uniform4f(this.u.u_tint, colors[k][0], colors[k][1], colors[k][2], colors[k][3]);
        this.drawDynamic(this.marksLines[k], gl.LINES);
      }
      if (m.easy) {
        const [x, y, z] = m.easy, e = 0.02;
        const x0 = x - e - cam.x, y0 = y - e - cam.y, z0 = z - e - cam.z, x1 = x + 1 + e - cam.x, y1 = y + 1 + e - cam.y, z1 = z + 1 + e - cam.z;
        const c = [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], [x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]];
        const lines = [];
        for (const [a, b] of [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]]) lines.push(c[a][0], c[a][1], c[a][2], 0, 0, 1, c[b][0], c[b][1], c[b][2], 0, 0, 1);
        gl.uniform3f(this.u.u_offset, 0, 0, 0);
        gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
        this.drawDynamic(lines, gl.LINES);
      }
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
    }

    renderSelection(sel, cam, progress) {
      const gl = this.gl;
      const out = [];
      const e = 0.002;
      for (const b of sel.boxes) {
        const x0 = sel.x + b[0] - e - cam.x, y0 = sel.y + b[1] - e - cam.y, z0 = sel.z + b[2] - e - cam.z;
        const x1 = sel.x + b[3] + e - cam.x, y1 = sel.y + b[4] + e - cam.y, z1 = sel.z + b[5] + e - cam.z;
        const c = [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], [x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]];
        const edges = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]];
        for (const [a, b2] of edges) {
          out.push(c[a][0], c[a][1], c[a][2], 0, 0, 1, c[b2][0], c[b2][1], c[b2][2], 0, 0, 1);
        }
      }
      gl.uniform3f(this.u.u_offset, 0, 0, 0);
      gl.bindTexture(gl.TEXTURE_2D, this.white);
      gl.uniform1f(this.u.u_daylight, 1);
      gl.uniform2f(this.u.u_fogRange, 1000, 2000);
      gl.uniform1f(this.u.u_alphaTest, 0);
      const oc = this.outline || [0, 0, 0, 0.6];
      gl.uniform4f(this.u.u_tint, oc[0], oc[1], oc[2], oc[3]);
      this.drawDynamic(out, gl.LINES);
      // Трещины на блоке по мере разрушения (destroy_stage_0..9)
      if (progress > 0) {
        const stage = Math.min(9, Math.floor(progress * 10));
        const F = MC.Mesher.FACES;
        const tri = [];
        for (const b of sel.boxes) {
          const bx = [sel.x + b[0] - 0.003 - cam.x, sel.y + b[1] - 0.003 - cam.y, sel.z + b[2] - 0.003 - cam.z,
            sel.x + b[3] + 0.003 - cam.x, sel.y + b[4] + 0.003 - cam.y, sel.z + b[5] + 0.003 - cam.z];
          for (let f = 0; f < 6; f++) {
            const q = [];
            for (let k = 0; k < 4; k++) {
              const c = F[f].c[k];
              const uv = MC.Mesher.faceUV(f, c[0], c[1], c[2]);
              q.push([c[0] ? bx[3] : bx[0], c[1] ? bx[4] : bx[1], c[2] ? bx[5] : bx[2], (stage + uv[0]) / 10, uv[1]]);
            }
            for (const k of [0, 1, 2, 0, 2, 3]) tri.push(q[k][0], q[k][1], q[k][2], q[k][3], q[k][4], 1);
          }
        }
        gl.disable(gl.CULL_FACE);
        gl.bindTexture(gl.TEXTURE_2D, this.destroyTex);
        gl.blendFunc(gl.DST_COLOR, gl.SRC_COLOR);
        gl.uniform1f(this.u.u_alphaTest, 0.05);
        gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
        this.drawDynamic(tri);
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
        gl.enable(gl.CULL_FACE);
      }
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
    }

    // Рамка цели под прицелом: белая — точное попадание, жёлтая — цель выбрана помощью в прицеливании
    renderAimTarget(t, cam) {
      const gl = this.gl;
      const hw = t.w / 2 + 0.05;
      const x0 = t.x - hw - cam.x, x1 = t.x + hw - cam.x, y0 = t.y - cam.y, y1 = t.y + t.h + 0.05 - cam.y, z0 = t.z - hw - cam.z, z1 = t.z + hw - cam.z;
      const c = [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], [x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]];
      const out = [];
      for (const [a, b] of [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]]) {
        out.push(c[a][0], c[a][1], c[a][2], 0, 0, 1, c[b][0], c[b][1], c[b][2], 0, 0, 1);
      }
      gl.uniform3f(this.u.u_offset, 0, 0, 0);
      gl.bindTexture(gl.TEXTURE_2D, this.white);
      gl.uniform1f(this.u.u_daylight, 1);
      gl.uniform2f(this.u.u_fogRange, 1000, 2000);
      gl.uniform1f(this.u.u_alphaTest, 0);
      if (t.assisted) gl.uniform4f(this.u.u_tint, 1, 0.85, 0.2, 0.9);
      else gl.uniform4f(this.u.u_tint, 1, 1, 1, 0.7);
      this.drawDynamic(out, gl.LINES);
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
    }

    renderEntities(scene, cam) {
      const gl = this.gl;
      gl.uniform3f(this.u.u_offset, 0, 0, 0);
      gl.uniform1f(this.u.u_alphaTest, 0.1);
      // Игроки со своими скинами. Дальние и оставшиеся за спиной не рисуются — в толпе на сервере это основная нагрузка
      const pfx = -Math.sin(cam.yaw * Math.PI / 180) * Math.cos(cam.pitch * Math.PI / 180);
      const pfy = -Math.sin(cam.pitch * Math.PI / 180);
      const pfz = Math.cos(cam.yaw * Math.PI / 180) * Math.cos(cam.pitch * Math.PI / 180);
      const pcull = (this.renderDistance * 16 + 16) ** 2;
      const tnow = performance.now();
      const pdt = Math.min(0.1, Math.max(0.001, (tnow - (this.lastPlayerT || tnow)) / 1000));
      this.lastPlayerT = tnow;
      if (!this.bodyYaws) this.bodyYaws = new Map();
      const seen = new Set();
      for (const p of scene.players) {
        const dx = p.x - cam.x, dy = p.y + 0.9 - cam.y, dz = p.z - cam.z;
        const d2 = dx * dx + dy * dy + dz * dz;
        if (p.eid !== -1 && (d2 > pcull || (d2 > 9 && dx * pfx + dy * pfy + dz * pfz < -0.25 * Math.sqrt(d2)))) continue;
        // Тело поворачивается за головой с запаздыванием (голова — не больше 50° от тела), при ходьбе — быстро
        seen.add(p.eid);
        let body = this.bodyYaws.get(p.eid);
        if (body === undefined) body = p.yaw;
        const diff = ((p.yaw - body) % 360 + 540) % 360 - 180;
        if ((p.walkAmount || 0) > 0.1 || p.swingTime > 0) body += diff * Math.min(1, pdt * 10);
        else if (Math.abs(diff) > 50) body = p.yaw - Math.sign(diff) * 50;
        else body += diff * Math.min(1, pdt * 0.7);
        this.bodyYaws.set(p.eid, body);
        p.bodyYaw = body;
        p.deathP = p.deathT && tnow - p.deathT < 3000 ? (tnow - p.deathT) / 1000 : p.deathP && p.eid === -1 ? p.deathP : 0;
        p.pose = playerPose(p);
        const skin = this.skinTexture(p.skinKey, p.skin);
        const verts = [];
        buildPlayer(verts, p, cam, skin.h);
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, skin.tex);
        gl.disable(gl.CULL_FACE);
        if (p.hurt > 0) gl.uniform4f(this.u.u_tint, 1, 0.45, 0.45, 1);
        this.drawDynamic(verts);
        if (p.armor) this.drawArmor(p, cam);
        const held = d2 < 1024 ? buildHeld(p, cam) : null;
        if (held) {
          gl.bindTexture(gl.TEXTURE_2D, held.block ? this.blockTex : this.itemTex);
          gl.uniform4f(this.u.u_tint, 1, p.hurt > 0 ? 0.45 : 1, p.hurt > 0 ? 0.45 : 1, 1);
          this.drawDynamic(held.verts);
        }
        gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
        gl.enable(gl.CULL_FACE);
      }
      if (this.bodyYaws.size > seen.size + 32) for (const k of Array.from(this.bodyYaws.keys())) if (!seen.has(k)) this.bodyYaws.delete(k);
      // Существа: модели и текстуры из ресурсов игры
      if (scene.entities.length) {
        const now = performance.now();
        const anim = new Map();
        const cull = (this.renderDistance * 16 + 16) ** 2;
        for (const e of scene.entities) {
          if ((e.x - cam.x) ** 2 + (e.z - cam.z) ** 2 > cull) continue;
          let flash = null;
          if (e.hurt > 0 || e.dead) flash = [1, 0.45, 0.45];
          else if (e.fuse > 0 && Math.sin(e.fuse * 25) > 0) flash = [1.6, 1.6, 1.6];
          const def = MOBS[e.type];
          const texName = def ? (def[4] && this.mobTex[def[4](e)] ? def[4](e) : def[1]) : null;
          if (!def || !this.mobTex[texName]) {
            const look = ENTITY_LOOK[e.type] || ['Существо #' + e.type, [0.7, 0.3, 0.7], [0.6, 1.0, 0.6]];
            const verts = [];
            if (e.type === 65 || (e.type === 66 && e.blockId)) {
              const id = e.type === 65 ? 46 : e.blockId;
              const b = MC.Blocks.list[id];
              const x = e.x - cam.x, y = e.y - cam.y, z = e.z - cam.z;
              pushBox(verts, [x - 0.49, y, z - 0.49, x + 0.49, y + 0.98, z + 0.49], (f) => b.tex(e.blockData || 0, f, null), 1, A.blockGrid);
              gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
              const c = flash || [1, 1, 1];
              gl.uniform4f(this.u.u_tint, c[0], c[1], c[2], 1);
            } else {
              pushRotatedBox(verts, e.x - cam.x, e.y - cam.y, e.z - cam.z, look[2][0], look[2][1], look[2][2], -e.yaw * Math.PI / 180);
              gl.bindTexture(gl.TEXTURE_2D, this.white);
              const c = flash || look[1];
              gl.uniform4f(this.u.u_tint, c[0], c[1], c[2], 1);
            }
            this.drawDynamic(verts);
            continue;
          }
          // Сила шага по скорости движения (как limbSwingAmount в Minecraft)
          const prev = this.mobAnim.get(e.eid);
          const walk = e.walk || 0;
          let amt = 0;
          if (prev) {
            const dt = Math.max(0.001, (now - prev.t) / 1000);
            const target = Math.min(1, Math.max(0, walk - prev.walk) / dt / 5);
            amt = prev.amt + (target - prev.amt) * Math.min(1, dt * 8);
          }
          anim.set(e.eid, { walk, amt, t: now });
          const pose = animate(def[3], walk * 4, amt, (e.pitch || 0) * Math.PI / 180);
          const tex = this.mobTex[texName];
          const verts = [];
          const scale = def[2] * (e.scale > 0 ? e.scale : 1) / 16;
          const yawR = -e.yaw * Math.PI / 180;
          const cy = Math.cos(yawR), sy = Math.sin(yawR);
          // Смерть как в Minecraft: существо заваливается на бок за полсекунды
          const dp = e.deathP > 0 ? e.deathP : e.deathT && now - e.deathT < 3000 ? (now - e.deathT) / 1000 : 0;
          const da = dp > 0 ? Math.min(1, Math.sqrt(dp * 1.6)) * Math.PI / 2 : 0;
          const cda = Math.cos(da), sda = Math.sin(da);
          for (const gname of def[0]) {
            const geo = geometryOf(gname, def[5]);
            const faces = poseModel(geo, pose, []);
            let lift = this.mobLift.get(gname + def[3]);
            if (lift === undefined) {
              lift = 0;
              for (const f of poseModel(geo, animate(def[3], 0, 0, 0), [])) for (const pt of f.pts) lift = Math.min(lift, pt[1]);
              lift = -lift;
              this.mobLift.set(gname + def[3], lift);
            }
            const ox = e.x - cam.x, oy = e.y - cam.y, oz = e.z - cam.z;
            for (const f of faces) {
              const r = f.r;
              const uv = [[r[0], r[1]], [r[0] + r[2], r[1]], [r[0] + r[2], r[1] + r[3]], [r[0], r[1] + r[3]]];
              const v = f.pts.map((pt, k) => {
                let mx = pt[0] * scale, my = (pt[1] + lift) * scale;
                const mz = -pt[2] * scale;
                if (da) { const t = mx * cda - my * sda; my = mx * sda + my * cda; mx = t; }
                return [ox + mx * cy + mz * sy, oy + my, oz - mx * sy + mz * cy, uv[k][0] / tex.w, uv[k][1] / tex.h];
              });
              for (const k of [0, 1, 2, 0, 2, 3]) verts.push(v[k][0], v[k][1], v[k][2], v[k][3], v[k][4], f.l);
            }
          }
          gl.bindTexture(gl.TEXTURE_2D, tex.tex);
          const c = flash || [1, 1, 1];
          gl.uniform4f(this.u.u_tint, c[0], c[1], c[2], 1);
          gl.disable(gl.CULL_FACE);
          this.drawDynamic(verts);
          gl.enable(gl.CULL_FACE);
        }
        this.mobAnim = anim;
        gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      }
      // Выброшенные предметы: отсечение по дальности и направлению взгляда,
      // ближайшие ITEM_MAX рисуются двумя вызовами (блоки и плоские предметы)
      if (scene.items.length) {
        const fx = -Math.sin(cam.yaw * Math.PI / 180) * Math.cos(cam.pitch * Math.PI / 180);
        const fy = -Math.sin(cam.pitch * Math.PI / 180);
        const fz = Math.cos(cam.yaw * Math.PI / 180) * Math.cos(cam.pitch * Math.PI / 180);
        const vis = [];
        for (const it of scene.items) {
          const dx = it.x - cam.x, dy = it.y - cam.y, dz = it.z - cam.z;
          const d2 = dx * dx + dy * dy + dz * dz;
          if (d2 > ITEM_DIST * ITEM_DIST) continue;
          if (d2 > 4 && dx * fx + dy * fy + dz * fz < -0.2 * Math.sqrt(d2)) continue;
          vis.push([d2, it]);
        }
        if (vis.length > ITEM_MAX) { vis.sort((a, b) => a[0] - b[0]); vis.length = ITEM_MAX; }
        const blockVerts = this.itemBlockVerts || (this.itemBlockVerts = []);
        const flatVerts = this.itemFlatVerts || (this.itemFlatVerts = []);
        blockVerts.length = 0; flatVerts.length = 0;
        const now = performance.now();
        const s = 0.25;
        for (const [d2, it] of vis) {
          if (it.dir) {
            // Летящая или воткнутая стрела: две скрещённые плоскости вдоль направления полёта
            const tile = MC.Items.itemTexture(it.item.id, it.item.data);
            if (tile === null) continue;
            const x = it.x - cam.x, y = it.y - cam.y, z = it.z - cam.z;
            const [ax, ay, az] = it.dir;
            let p1 = Math.abs(ay) < 0.9 ? [az, 0, -ax] : [1, 0, 0];
            const l1 = Math.hypot(p1[0], p1[1], p1[2]) || 1;
            p1 = [p1[0] / l1, p1[1] / l1, p1[2] / l1];
            const p2 = [ay * p1[2] - az * p1[1], az * p1[0] - ax * p1[2], ax * p1[1] - ay * p1[0]];
            const L = 0.35;
            const u0 = (tile % A.itemGrid) / A.itemGrid, v0 = Math.floor(tile / A.itemGrid) / A.itemGrid, t = 1 / A.itemGrid;
            // Остриё на текстуре стрелы — в правом верхнем углу, оперение — в левом нижнем
            const tip = [x + ax * L - ax * 0.35, y + ay * L - ay * 0.35, z + az * L - az * 0.35];
            const tail = [x - ax * L - ax * 0.35, y - ay * L - ay * 0.35, z - az * L - az * 0.35];
            const mid = [(tip[0] + tail[0]) / 2, (tip[1] + tail[1]) / 2, (tip[2] + tail[2]) / 2];
            for (const pp of [p1, p2]) {
              const q = [[tail[0], tail[1], tail[2], u0, v0 + t], [mid[0] - pp[0] * L, mid[1] - pp[1] * L, mid[2] - pp[2] * L, u0 + t, v0 + t],
                [tip[0], tip[1], tip[2], u0 + t, v0], [mid[0] + pp[0] * L, mid[1] + pp[1] * L, mid[2] + pp[2] * L, u0, v0]];
              for (const k of [0, 1, 2, 0, 2, 3]) flatVerts.push(q[k][0], q[k][1], q[k][2], q[k][3], q[k][4], 1);
            }
            continue;
          }
          const far = d2 > 256;
          const bob = far ? 0 : Math.sin(now / 400 + it.eid) * 0.05;
          const x = it.x - cam.x, y = it.y - cam.y + 0.15 + bob, z = it.z - cam.z;
          if (it.item.id > 0 && it.item.id < 256) {
            const b = MC.Blocks.list[it.item.id];
            const d = b.variants > 1 ? it.item.data : 0;
            pushBox(blockVerts, [x - s / 2, y, z - s / 2, x + s / 2, y + s, z + s / 2], (f) => b.tex(d, f, null), 1, A.blockGrid);
          } else {
            const tile = MC.Items.itemTexture(it.item.id, it.item.data);
            if (tile === null) continue;
            // предмет повёрнут к камере, вдали без вращения
            const a = far ? Math.atan2(z, x) + Math.PI / 2 : now / 1000 + it.eid;
            const dx = Math.cos(a) * s, dz = Math.sin(a) * s;
            const u0 = (tile % A.itemGrid) / A.itemGrid, v0 = Math.floor(tile / A.itemGrid) / A.itemGrid;
            const t = 1 / A.itemGrid;
            const q = [[x - dx, y, z - dz, u0, v0 + t], [x + dx, y, z + dz, u0 + t, v0 + t], [x + dx, y + 2 * s, z + dz, u0 + t, v0], [x - dx, y + 2 * s, z - dz, u0, v0]];
            for (const k of [0, 1, 2, 0, 2, 3]) flatVerts.push(q[k][0], q[k][1], q[k][2], q[k][3], q[k][4], 1);
          }
        }
        if (blockVerts.length) { gl.bindTexture(gl.TEXTURE_2D, this.blockTex); this.drawDynamic(blockVerts); }
        if (flatVerts.length) {
          gl.bindTexture(gl.TEXTURE_2D, this.itemTex);
          gl.disable(gl.CULL_FACE);
          this.drawDynamic(flatVerts);
          gl.enable(gl.CULL_FACE);
        }
      }
      if (scene.crystals && scene.crystals.length) this.renderCrystals(scene.crystals, cam);
      gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
      gl.uniform1f(this.u.u_alphaTest, 0.5);
    }

    // Луч маяка: светлый столб от маяка до верха мира
    renderBeacons(list, cam) {
      const gl = this.gl, v = [];
      const t = performance.now() / 1000;
      for (const b of list) {
        const x = b.x + 0.5 - cam.x, z = b.z + 0.5 - cam.z, y0 = b.y + 1 - cam.y, y1 = 256 - cam.y;
        for (let k = 0; k < 2; k++) {
          const a = t * 0.8 + k * Math.PI / 2, r = 0.2;
          const dx = Math.cos(a) * r, dz = Math.sin(a) * r;
          const q = [[x - dx, y0, z - dz], [x + dx, y0, z + dz], [x + dx, y1, z + dz], [x - dx, y1, z - dz]];
          for (const j of [0, 1, 2, 0, 2, 3]) v.push(q[j][0], q[j][1], q[j][2], 0.5, 0.5, 1);
        }
      }
      gl.bindTexture(gl.TEXTURE_2D, this.white);
      gl.uniform3f(this.u.u_offset, 0, 0, 0);
      gl.uniform4f(this.u.u_tint, 0.75, 0.9, 1, 0.45);
      gl.uniform1f(this.u.u_minLight, 1);
      this.drawDynamic(v);
      gl.uniform1f(this.u.u_minLight, this.fullbright ? 0.92 : 0);
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
    }

    // Кристаллы Края как в Minecraft: два стеклянных куба и ядро вращаются и парят над бедроковой подставкой,
    // к дракону тянется луч лечения
    renderCrystals(list, cam) {
      const gl = this.gl, tex = this.mobTex.endercrystal, beamTex = this.mobTex.endercrystal_beam;
      if (!tex) return;
      const k = tex.w / 64;
      const verts = [], beams = [];
      const tilt = Math.PI / 3, ct = Math.cos(tilt), st = Math.sin(tilt);
      for (const c of list) {
        const ox = c.x - cam.x, oy = c.y - cam.y, oz = c.z - cam.z;
        if (ox * ox + oy * oy + oz * oz > 160 * 160) continue;
        const t = c.age || 0;
        const cy = oy + 1.25 + Math.sin(t * 3) * 0.25;
        // Вращение вокруг вертикали, затем наклон на 60° вокруг диагонали — каждый слой со своей скоростью
        const spin = (a, w) => (x, y, z) => {
          const ca = Math.cos(a), sa = Math.sin(a);
          let px = x * ca + z * sa, pz = -x * sa + z * ca, py = y;
          // наклон вокруг оси (1,0,1)/√2
          const u = (px - pz) / Math.SQRT2;
          const v = (px + pz) / Math.SQRT2;
          const u2 = u * ct - py * st, y2 = u * st + py * ct;
          px = (u2 + v) / Math.SQRT2; pz = (v - u2) / Math.SQRT2;
          return [ox + px * w, cy + y2 * w, oz + pz * w];
        };
        const a = t * 3.2;
        pushUvBox(verts, spin(a, 0.95), 0, 0, 8, 8, 8, k);
        pushUvBox(verts, spin(-a * 1.3 + 0.7, 0.78), 0, 0, 8, 8, 8, k);
        pushUvBox(verts, spin(a * 1.7 + 1.4, 0.55), 32, 0, 8, 8, 8, k);
        if (c.base) pushUvBox(verts, (x, y, z) => [ox + x * 1.5, oy + 0.25 + y * 0.5, oz + z * 1.5], 0, 16, 12, 4, 12, k);
        if (c.beam) beams.push([ox, cy, oz, c.beam[0] - cam.x, c.beam[1] - cam.y, c.beam[2] - cam.z, t]);
      }
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      gl.disable(gl.CULL_FACE);
      if (verts.length) { gl.bindTexture(gl.TEXTURE_2D, tex.tex); this.drawDynamic(verts); }
      if (beams.length && beamTex) {
        const bv = [];
        for (const [x1, y1, z1, x2, y2, z2, t] of beams) {
          const dx = x2 - x1, dy = y2 - y1, dz = z2 - z1, len = Math.hypot(dx, dy, dz) || 1;
          const ax = dx / len, ay = dy / len, az = dz / len;
          let p1 = Math.abs(ay) < 0.9 ? [az, 0, -ax] : [1, 0, 0];
          const l1 = Math.hypot(p1[0], p1[1], p1[2]) || 1;
          p1 = [p1[0] / l1 * 0.2, p1[1] / l1 * 0.2, p1[2] / l1 * 0.2];
          const p2 = [(ay * p1[2] - az * p1[1]), (az * p1[0] - ax * p1[2]), (ax * p1[1] - ay * p1[0])];
          // Луч из кусков по 4 блока, текстура бежит к дракону
          const seg = 4, n = Math.ceil(len / seg), shift = (t * 0.6) % 1;
          for (let i = 0; i < n; i++) {
            const s0 = i * seg, s1 = Math.min(len, s0 + seg);
            const A = [x1 + ax * s0, y1 + ay * s0, z1 + az * s0], B = [x1 + ax * s1, y1 + ay * s1, z1 + az * s1];
            const v0 = shift * 0.5, v1 = v0 + 0.5 * (s1 - s0) / seg;
            for (const pp of [p1, p2]) {
              const q = [[A[0] - pp[0], A[1] - pp[1], A[2] - pp[2], 0, v0], [A[0] + pp[0], A[1] + pp[1], A[2] + pp[2], 1, v0],
                [B[0] + pp[0], B[1] + pp[1], B[2] + pp[2], 1, v1], [B[0] - pp[0], B[1] - pp[1], B[2] - pp[2], 0, v1]];
              for (const j of [0, 1, 2, 0, 2, 3]) bv.push(q[j][0], q[j][1], q[j][2], q[j][3], q[j][4], 1);
            }
          }
        }
        gl.bindTexture(gl.TEXTURE_2D, beamTex.tex);
        this.drawDynamic(bv);
      }
      gl.enable(gl.CULL_FACE);
    }

    // Частицы (js/particles.js): осколки блоков, крошки еды, криты, дым
    renderParticles(ps, cam) {
      const out = ps.build(cam);
      const gl = this.gl;
      gl.uniform3f(this.u.u_offset, 0, 0, 0);
      gl.uniform1f(this.u.u_alphaTest, 0.1);
      gl.disable(gl.CULL_FACE);
      gl.activeTexture(gl.TEXTURE0);
      if (out.block.length) { gl.bindTexture(gl.TEXTURE_2D, this.blockTex); this.drawDynamic(out.block); }
      if (out.item.length) { gl.bindTexture(gl.TEXTURE_2D, this.itemTex); this.drawDynamic(out.item); }
      let bound = false;
      for (const k in out.color) {
        const v = out.color[k];
        if (!v.length) continue;
        if (!bound) {
          if (!this.particleTex) this.particleTex = this.texture(MC.Particles.spriteCanvas());
          gl.bindTexture(gl.TEXTURE_2D, this.particleTex);
          bound = true;
        }
        const c = MC.Particles.COLORS[k] || [1, 1, 1];
        gl.uniform4f(this.u.u_tint, c[0], c[1], c[2], 1);
        this.drawDynamic(v);
      }
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
      gl.uniform1f(this.u.u_alphaTest, 0.5);
      gl.enable(gl.CULL_FACE);
    }

    // Надетая броня и элитры поверх модели игрока (текстуры из textures/models/armor)
    drawArmor(p, cam) {
      const gl = this.gl;
      for (let a = 0; a < 4; a++) {
        const it = p.armor[a];
        if (!it || !it.id) continue;
        let parts, texName, tint = null;
        if (it.id === 444) { parts = ELYTRA_PARTS; texName = 'armor.elytra'; } else {
          const mat = ARMOR_MAT[it.id];
          if (!mat) continue;
          parts = ARMOR_PARTS[a];
          texName = 'armor.' + mat + (a === 2 ? '_2' : '_1');
          if (mat === 'leather') tint = LEATHER_TINT;
        }
        const tex = this.mobTex[texName];
        if (!tex) continue;
        const verts = [];
        buildPlayer(verts, p, cam, 32, parts);
        gl.bindTexture(gl.TEXTURE_2D, tex.tex);
        const hurt = p.hurt > 0;
        if (tint) gl.uniform4f(this.u.u_tint, tint[0], hurt ? tint[1] * 0.45 : tint[1], hurt ? tint[2] * 0.45 : tint[2], 1);
        else gl.uniform4f(this.u.u_tint, 1, hurt ? 0.45 : 1, hurt ? 0.45 : 1, 1);
        this.drawDynamic(verts);
      }
    }

    // Рука или предмет в руке от первого лица.
    // hand: {item, swing (1 → 0 во время взмаха), walk, skinKey, skin, daylight, eating}
    renderHand(hand) {
      const gl = this.gl;
      gl.clear(gl.DEPTH_BUFFER_BIT);
      const proj = M4.perspective(70 * Math.PI / 180, this.width / this.height, 0.02, 10);
      gl.uniformMatrix4fv(this.u.u_mvp, false, proj);
      gl.uniform3f(this.u.u_offset, 0, 0, 0);
      gl.uniform1f(this.u.u_daylight, Math.max(0.35, hand.daylight));
      gl.uniform2f(this.u.u_fogRange, 1000, 2000);
      gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      gl.uniform1f(this.u.u_alphaTest, 0.1);
      gl.disable(gl.CULL_FACE);
      // Взмах и покачивание при ходьбе, как в Minecraft
      const f = hand.swing > 0 ? 1 - hand.swing : 0;
      const sf = Math.sin(Math.sqrt(f) * Math.PI);
      const bk = 0.4 + Math.min(1, hand.bob || 0) * 0.6;
      const bobX = Math.sin(hand.walk * Math.PI) * 0.025 * bk, bobY = -Math.abs(Math.cos(hand.walk * Math.PI)) * 0.04 * bk;
      // Стиль 1.7 (старые PvP-анимации): рука ниже и ближе, взмах шире, предмет сильнее наклонён
      const old = hand.style === 'old';
      let tx = (old ? 0.5 : 0.56) + bobX - sf * (old ? 0.42 : 0.35), ty = (old ? -0.6 : -0.52) + bobY + Math.sin(Math.sqrt(f) * Math.PI * 2) * 0.18, tz = (old ? -0.66 : -0.72) - Math.sin(f * Math.PI) * 0.2;
      let rx = -sf * (old ? 80 : 60), ry = -Math.sin(f * f * Math.PI) * (old ? 30 : 20);
      // Смена предмета: рука уходит вниз и возвращается
      if (hand.equip > 0) ty -= Math.sin(hand.equip * Math.PI / 2) * 0.6;
      // Блокирование мечом в стиле 1.7: меч поворачивается поперёк экрана к центру
      if (hand.block) {
        tx -= 0.18; ty += 0.1; tz += 0.08;
        rx += 15; ry -= 5;
        hand.blockRot = true;
      }
      if (hand.eating > 0) {
        tx -= 0.35; ty += 0.12 + Math.abs(Math.sin(hand.eating * 25)) * 0.05; rx += 25;
      }
      // Лук: натяжение уводит лук к центру и назад, на полной силе он подрагивает
      if (hand.bow > 0) {
        const pull = Math.min(1, (hand.bow * hand.bow + 2 * hand.bow) / 3);
        tx -= 0.32; ty += 0.08; tz += pull * 0.18;
        ry -= 8; rx += 6;
        if (pull >= 1) { tx += Math.sin(performance.now() / 18) * 0.006; ty += Math.cos(performance.now() / 23) * 0.006; }
      }
      const verts = [];
      const it = hand.item;
      let sleeve = null, sleeveTint = null;
      if (!it || !it.id) {
        const skin = this.skinTexture(hand.skinKey, hand.skin);
        buildArm(verts, skin.h, 0);
        transform(verts, 1, [100 + rx * 0.6, 15 + ry, 0], [tx + 0.1, ty - 0.02, tz + 0.75]);
        gl.bindTexture(gl.TEXTURE_2D, skin.tex);
        const chest = hand.armor && hand.armor[1];
        const mat = chest && chest.id !== 444 ? ARMOR_MAT[chest.id] : null;
        if (mat && this.mobTex['armor.' + mat + '_1']) {
          sleeve = [];
          buildArm(sleeve, 32, 1);
          transform(sleeve, 1, [100 + rx * 0.6, 15 + ry, 0], [tx + 0.1, ty - 0.02, tz + 0.75]);
          sleeveTint = mat === 'leather' ? LEATHER_TINT : null;
          sleeve.tex = this.mobTex['armor.' + mat + '_1'].tex;
        }
      } else if (it.id < 256 && MC.Blocks.list[it.id].shape !== 'cross' && MC.Blocks.list[it.id].shape !== 'torch' && MC.Blocks.list[it.id].shape !== 'crop') {
        const b = MC.Blocks.list[it.id];
        const d = b.variants > 1 ? it.data : 0;
        pushBox(verts, [-0.5, -0.5, -0.5, 0.5, 0.5, 0.5], (fc) => b.tex(d, fc, null), 1, A.blockGrid);
        transform(verts, 0.26, [rx + 10, ry + 45, 0], [tx - 0.02, ty + 0.14, tz - 0.05]);
        gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
      } else {
        let tile, grid, tex;
        if (it.id < 256) { tile = MC.Blocks.list[it.id].tex(it.data, 2, null); grid = A.blockGrid; tex = this.blockTex; }
        else { tile = MC.Items.itemTexture(it.id, it.data); grid = A.itemGrid; tex = this.itemTex; }
        if (tile === null || tile === undefined) { tile = MC.Blocks.MISSING; grid = A.blockGrid; tex = this.blockTex; }
        const u0 = (tile % grid) / grid, v0 = Math.floor(tile / grid) / grid, t = 1 / grid;
        const q = [[-0.5, -0.5, 0, u0, v0 + t], [0.5, -0.5, 0, u0 + t, v0 + t], [0.5, 0.5, 0, u0 + t, v0], [-0.5, 0.5, 0, u0, v0]];
        for (const k of [0, 1, 2, 0, 2, 3]) verts.push(q[k][0], q[k][1], q[k][2], q[k][3], q[k][4], 0.95);
        transform(verts, 0.45, hand.blockRot ? [rx - 10, ry - 80, 70] : [rx, ry - 70, 25], [tx, ty + 0.12, tz]);
        gl.bindTexture(gl.TEXTURE_2D, tex);
      }
      this.drawDynamic(verts);
      if (sleeve) {
        gl.bindTexture(gl.TEXTURE_2D, sleeve.tex);
        if (sleeveTint) gl.uniform4f(this.u.u_tint, sleeveTint[0], sleeveTint[1], sleeveTint[2], 1);
        this.drawDynamic(sleeve);
        gl.uniform4f(this.u.u_tint, 1, 1, 1, 1);
      }
      gl.enable(gl.CULL_FACE);
      gl.bindTexture(gl.TEXTURE_2D, this.blockTex);
      gl.uniform1f(this.u.u_alphaTest, 0.5);
    }

    // Мировая точка -> экранные координаты CSS (для ников над головами)
    project(x, y, z) {
      if (!this.vp || !this.cam) return null;
      const m = this.vp;
      const px = x - this.cam.x, py = y - this.cam.y, pz = z - this.cam.z;
      const cx = m[0] * px + m[4] * py + m[8] * pz + m[12];
      const cy = m[1] * px + m[5] * py + m[9] * pz + m[13];
      const cw = m[3] * px + m[7] * py + m[11] * pz + m[15];
      if (cw <= 0.1) return null;
      return { x: (cx / cw * 0.5 + 0.5) * this.width, y: (1 - (cy / cw * 0.5 + 0.5)) * this.height, d: cw };
    }
  }

  // ---------- Геометрия ----------
  const ITEM_DIST = 40, ITEM_MAX = 400;

  function pushBox(out, b, texFn, light, grid) {
    const F = MC.Mesher.FACES;
    for (let f = 0; f < 6; f++) {
      let tu = 0, tv = 0, ts = 1;
      if (texFn) { const tile = texFn(f); ts = 1 / grid; tu = (tile % grid) * ts; tv = Math.floor(tile / grid) * ts; }
      const verts = [];
      for (let k = 0; k < 4; k++) {
        const c = F[f].c[k];
        const uv = MC.Mesher.faceUV(f, c[0], c[1], c[2]);
        verts.push([c[0] ? b[3] : b[0], c[1] ? b[4] : b[1], c[2] ? b[5] : b[2], tu + uv[0] * ts, tv + uv[1] * ts]);
      }
      const l = light * F[f].shade;
      for (const k of [0, 1, 2, 0, 2, 3]) out.push(verts[k][0], verts[k][1], verts[k][2], verts[k][3], verts[k][4], l);
    }
  }

  // Куб с развёрткой текстуры как у моделей Minecraft (u, v — угол развёртки в пикселях, w×h×d — размер, k — масштаб текстуры).
  // place(x, y, z) переводит точку куба (-0.5…0.5) в мир
  function pushUvBox(out, place, u, v, w, h, d, k) {
    const W = 64 * k, H = 32 * k;
    const faces = [
      // верх, низ, -x, -z, +x, +z: четыре угла и прямоугольник развёртки
      [[[-1, 1, -1], [1, 1, -1], [1, 1, 1], [-1, 1, 1]], [u + d, v, w, d]],
      [[[-1, -1, 1], [1, -1, 1], [1, -1, -1], [-1, -1, -1]], [u + d + w, v, w, d]],
      [[[-1, 1, 1], [-1, 1, -1], [-1, -1, -1], [-1, -1, 1]], [u, v + d, d, h]],
      [[[-1, 1, -1], [1, 1, -1], [1, -1, -1], [-1, -1, -1]], [u + d, v + d, w, h]],
      [[[1, 1, -1], [1, 1, 1], [1, -1, 1], [1, -1, -1]], [u + d + w, v + d, d, h]],
      [[[1, 1, 1], [-1, 1, 1], [-1, -1, 1], [1, -1, 1]], [u + 2 * d + w, v + d, w, h]]
    ];
    const shade = [1, 0.5, 0.75, 0.85, 0.75, 0.85];
    faces.forEach(([pts, r], fi) => {
      const uv = [[r[0], r[1]], [r[0] + r[2], r[1]], [r[0] + r[2], r[1] + r[3]], [r[0], r[1] + r[3]]];
      const q = pts.map((p, i) => { const wp = place(p[0] / 2, p[1] / 2, p[2] / 2); return [wp[0], wp[1], wp[2], uv[i][0] * k / W, uv[i][1] * k / H]; });
      for (const j of [0, 1, 2, 0, 2, 3]) out.push(q[j][0], q[j][1], q[j][2], q[j][3], q[j][4], shade[fi]);
    });
  }

  function pushRotatedBox(out, x, y, z, w, h, d, yaw) {
    const cos = Math.cos(yaw), sin = Math.sin(yaw);
    const F = MC.Mesher.FACES;
    for (let f = 0; f < 6; f++) {
      const verts = [];
      for (let k = 0; k < 4; k++) {
        const c = F[f].c[k];
        const lx = (c[0] - 0.5) * w, lz = (c[2] - 0.5) * d;
        verts.push([x + lx * cos + lz * sin, y + c[1] * h, z - lx * sin + lz * cos]);
      }
      const l = F[f].shade;
      for (const k of [0, 1, 2, 0, 2, 3]) out.push(verts[k][0], verts[k][1], verts[k][2], 0.5, 0.5, l);
    }
  }

  // Масштаб, поворот (градусы X, Y, Z) и перенос вершин (шаг 6 чисел)
  function transform(v, scale, rot, pos) {
    const [ax, ay, az] = rot.map((r) => r * Math.PI / 180);
    const cx = Math.cos(ax), sx = Math.sin(ax), cy = Math.cos(ay), sy = Math.sin(ay), cz = Math.cos(az), sz = Math.sin(az);
    for (let i = 0; i < v.length; i += 6) {
      let x = v[i] * scale, y = v[i + 1] * scale, z = v[i + 2] * scale;
      let t = x * cz - y * sz; y = x * sz + y * cz; x = t;
      t = y * cx - z * sx; z = y * sx + z * cx; y = t;
      t = x * cy + z * sy; z = -x * sy + z * cy; x = t;
      v[i] = x + pos[0]; v[i + 1] = y + pos[1]; v[i + 2] = z + pos[2];
    }
  }

  // Правая рука игрока из скина, единицы — блоки, плечо в начале координат
  function buildArm(out, skinH, inflate) {
    const F = MC.Mesher.FACES;
    const rects = skinRects(40, 16, 4, 12, 4);
    const s = 1 / 16;
    const inf = inflate || 0;
    for (let f = 0; f < 6; f++) {
      const r = rects[f];
      const verts = [];
      for (let k = 0; k < 4; k++) {
        const c = F[f].c[k];
        const uv = MC.Mesher.faceUV(f, c[0], c[1], c[2]);
        verts.push([(-2 - inf + c[0] * (4 + inf * 2)) * s, (-12 - inf + c[1] * (12 + inf * 2)) * s, (-2 - inf + c[2] * (4 + inf * 2)) * s, (r[0] + uv[0] * r[2]) / 64, (r[1] + uv[1] * r[3]) / skinH]);
      }
      for (const k of [0, 1, 2, 0, 2, 3]) out.push(verts[k][0], verts[k][1], verts[k][2], verts[k][3], verts[k][4], F[f].shade);
    }
  }

  // Развёртка грани параллелепипеда по скину: [u, v, w, h] в пикселях скина для каждой грани
  function skinRects(u, v, w, h, d) {
    return [
      [u + d + w, v, w, d],       // низ
      [u + d, v, w, d],           // верх
      [u + d + w + d, v + d, w, h], // север (спина)
      [u + d, v + d, w, h],       // юг (лицо)
      [u, v + d, d, h],           // запад (правый бок модели)
      [u + d + w, v + d, d, h]    // восток (левый бок модели)
    ];
  }

  // Поза игрока по правилам ModelBiped из Minecraft: шаг, взмах при ударе (с поворотом корпуса), присед, лук, еда,
  // дыхание рук, голова поворачивается отдельно от тела, падение при смерти, полёт на элитрах.
  // p: {walk, walkAmount, swingTime (1 → 0), pitch, yaw, bodyYaw, sneaking, usingBow, eating, gliding, deathP, held}
  function playerPose(p) {
    const now = performance.now() / 1000;
    const amt = Math.min(1, p.walkAmount || 0);
    const ls = (p.walk || 0) * 0.6;
    const pose = {};
    const set = (n, x, y, z) => { pose[n] = [x || 0, y || 0, z || 0]; };
    const headYaw = p.bodyYaw !== undefined ? wrapRad((p.bodyYaw - p.yaw) * Math.PI / 180) : 0;
    const pitch = (p.pitch || 0) * Math.PI / 180;
    set('head', pitch, headYaw, 0);
    set('hat', pitch, headYaw, 0);
    set('body', 0, 0, 0);
    const legSwing = Math.cos(ls * 1.1) * 1.4 * amt * 0.5;
    set('rarm', Math.cos(ls * 1.1 + Math.PI) * amt * 0.8, 0, 0);
    set('larm', Math.cos(ls * 1.1) * amt * 0.8, 0, 0);
    set('rleg', legSwing, 0, 0);
    set('lleg', -legSwing, 0, 0);
    // С предметом в руке рука чуть вынесена вперёд и качается вполовину
    if (p.held && p.held.id) pose.rarm[0] = pose.rarm[0] * 0.5 - Math.PI / 10;
    // Взмах (атака, установка блока): кривая и поворот корпуса как в Minecraft 1.8
    const sw = p.swingTime > 0 ? 1 - p.swingTime : 0;
    if (sw > 0) {
      const bodyY = Math.sin(Math.sqrt(sw) * Math.PI * 2) * 0.2;
      pose.body[1] = bodyY;
      pose.rarm[1] += bodyY * 2;
      pose.larm[1] += bodyY;
      pose.larm[0] += bodyY;
      let f1 = 1 - sw; f1 = 1 - f1 * f1 * f1 * f1;
      const f2 = Math.sin(f1 * Math.PI);
      const f3 = Math.sin(sw * Math.PI) * -(pitch - 0.7) * 0.75;
      pose.rarm[0] -= f2 * 1.2 + f3;
      pose.rarm[2] += Math.sin(sw * Math.PI) * 0.4;
      pose.armShift = bodyY;
    }
    // Еда и зелья: рука у рта с покачиванием
    if (p.eating) { pose.rarm = [-1.25 + Math.abs(Math.sin(now * 14)) * 0.18, 0.35, 0]; }
    // Лук: обе руки вперёд по взгляду, левая чуть внутрь
    if (p.usingBow) {
      pose.rarm = [-Math.PI / 2 + pitch, -0.1 + headYaw, 0];
      pose.larm = [-Math.PI / 2 + pitch, 0.5 + headYaw, 0];
    }
    // Дыхание рук в покое
    pose.rarm[2] -= Math.cos(now * 1.8) * 0.05 + 0.05;
    pose.larm[2] += Math.cos(now * 1.8) * 0.05 + 0.05;
    pose.rarm[0] += Math.sin(now * 1.34) * 0.05;
    pose.larm[0] -= Math.sin(now * 1.34) * 0.05;
    pose.pivots = {};
    // Присед: корпус наклонён вперёд от шеи, руки за ним, ноги смещены назад, вся модель ниже
    if (p.sneaking && !p.gliding) {
      pose.body[0] = 0.5;
      pose.rarm[0] += 0.4;
      pose.larm[0] += 0.4;
      pose.pivots.rleg = [-2, 15, -4];
      pose.pivots.lleg = [2, 15, -4];
      pose.pivots.head = pose.pivots.hat = [0, 23, 0];
      pose.lower = 3.5;
    }
    if (p.gliding) {
      pose.glide = -Math.PI / 2 - pitch;
      pose.rarm[2] = -0.3; pose.larm[2] = 0.3;
      pose.rleg[0] = 0.1; pose.lleg[0] = 0.1;
    }
    pose.death = p.deathP > 0 ? Math.min(1, Math.sqrt(p.deathP * 1.6)) * Math.PI / 2 : 0;
    return pose;
  }

  function wrapRad(a) {
    while (a > Math.PI) a -= Math.PI * 2;
    while (a < -Math.PI) a += Math.PI * 2;
    return a;
  }

  // Точка модели игрока: lx, ly, lz — пиксели относительно шарнира части; возвращает координаты мира относительно камеры
  function posePoint(p, pose, part, lx, ly, lz, cam) {
    const r = pose[part.name] || [part.rotX || 0, 0, part.rotZ || 0];
    const rx = part.rotX && part.name.endsWith('wing') ? part.rotX : r[0];
    const rz = part.rotZ && part.name.endsWith('wing') ? part.rotZ : r[2];
    let x = lx, y = ly, z = lz, t;
    // Порядок как у ModelRenderer: сначала X, потом Y, потом Z
    if (rx) { const c = Math.cos(rx), s = Math.sin(rx); t = y * c - z * s; z = y * s + z * c; y = t; }
    if (r[1]) { const c = Math.cos(r[1]), s = Math.sin(r[1]); t = x * c + z * s; z = -x * s + z * c; x = t; }
    if (rz) { const c = Math.cos(rz), s = Math.sin(rz); t = x * c - y * s; y = x * s + y * c; x = t; }
    let pv = pose.pivots[part.name] || part.pivot;
    // Корпус наклоняется от шеи: шарнир переносится наверх, точки части — относительно него
    if (part.name === 'body') { pv = [0, 24, 0]; }
    // При взмахе плечи поворачиваются вместе с корпусом
    if (pose.armShift && (part.name === 'rarm' || part.name === 'larm')) {
      const sx = part.name === 'rarm' ? -1 : 1;
      pv = [sx * Math.cos(pose.armShift) * 6, pv[1], -sx * Math.sin(pose.armShift) * 6];
    }
    let mx = pv[0] + x, my = pv[1] + y - (pose.lower || 0), mz = pv[2] + z;
    // Элитры: модель ложится вдоль полёта (поворот вокруг центра тела)
    if (pose.glide) { const c = Math.cos(pose.glide), s = Math.sin(pose.glide); const yy = my - 16; t = yy * c - mz * s; mz = yy * s + mz * c; my = t + 16; }
    // Смерть: модель заваливается на бок
    if (pose.death) { const c = Math.cos(pose.death), s = Math.sin(pose.death); t = mx * c - my * s; my = mx * s + my * c; mx = t; }
    const ps = p.scale > 0 ? p.scale : 1;
    mx *= PX * ps; my *= PX * ps; mz *= PX * ps;
    const yaw = -(p.bodyYaw !== undefined ? p.bodyYaw : p.yaw) * Math.PI / 180;
    const cy = Math.cos(yaw), sy = Math.sin(yaw);
    return [p.x - cam.x + mx * cy + mz * sy, p.y - cam.y + my, p.z - cam.z - mx * sy + mz * cy];
  }

  function buildPlayer(out, p, cam, skinH, partList) {
    const pose = p.pose || playerPose(p);
    const F = MC.Mesher.FACES;
    for (const part of partList || PARTS) {
      const uvBase = skinH === 64 && part.uv64 ? part.uv64 : part.uv;
      const rects = skinRects(uvBase[0], uvBase[1], part.size[0], part.size[1], part.size[2]);
      const mirror = part.mirror || (skinH !== 64 && (part.name === 'larm' || part.name === 'lleg'));
      const inf = part.inflate || 0;
      // Корпус в позе считается от шеи: его точки сдвинуты на 12 пикселей вниз относительно шарнира
      const oy = part.name === 'body' ? -12 : 0;
      for (let f = 0; f < 6; f++) {
        const r = rects[f];
        const verts = [];
        for (let k = 0; k < 4; k++) {
          const c = F[f].c[k];
          const lx = part.origin[0] - inf + c[0] * (part.size[0] + inf * 2);
          const ly = part.origin[1] - inf + c[1] * (part.size[1] + inf * 2) + oy;
          const lz = part.origin[2] - inf + c[2] * (part.size[2] + inf * 2);
          const w = posePoint(p, pose, part, lx, ly, lz, cam);
          const uv = MC.Mesher.faceUV(f, c[0], c[1], c[2]);
          let uu = uv[0];
          if (mirror) uu = 1 - uu;
          verts.push([w[0], w[1], w[2], (r[0] + uu * r[2]) / 64, (r[1] + uv[1] * r[3]) / skinH]);
        }
        const l = F[f].shade * (p.hurt > 0 ? 0.6 : 1);
        for (const k of [0, 1, 2, 0, 2, 3]) out.push(verts[k][0], verts[k][1], verts[k][2], verts[k][3], verts[k][4], l);
      }
    }
  }

  const RARM = PARTS[2];

  // Предмет в правой руке игрока (вид со стороны): плоский — квадрат вдоль руки, блок — маленький куб.
  // Возвращает {verts, block} или null; точки считаются в позе руки из playerPose
  function buildHeld(p, cam) {
    const it = p.held;
    if (!it || !it.id) return null;
    const pose = p.pose || playerPose(p);
    const place = (lx, ly, lz) => posePoint(p, pose, RARM, lx, ly - 24, lz, cam);
    const verts = [];
    const b = it.id < 256 ? MC.Blocks.list[it.id] : null;
    if (b && b.shape !== 'cross' && b.shape !== 'torch' && b.shape !== 'crop' && b.shape !== 'flat') {
      const d = b.variants > 1 ? it.data : 0;
      const F = MC.Mesher.FACES, g = A.blockGrid, t = 1 / g, size = 5;
      for (let f = 0; f < 6; f++) {
        const tile = b.tex(d, f, null);
        const u0 = (tile % g) / g, v0 = Math.floor(tile / g) / g;
        const q = F[f].c.map((c) => {
          const pt = place(-size / 2 + c[0] * size, 24 - 12 - size / 2 + c[1] * size, 1 + c[2] * size);
          const uv = MC.Mesher.faceUV(f, c[0], c[1], c[2]);
          return [pt[0], pt[1], pt[2], u0 + uv[0] * t, v0 + uv[1] * t];
        });
        for (const k of [0, 1, 2, 0, 2, 3]) verts.push(q[k][0], q[k][1], q[k][2], q[k][3], q[k][4], F[f].shade);
      }
      return { verts, block: true };
    }
    let tile, grid, block = false;
    if (it.id < 256) { tile = b ? b.tex(it.data, 2, null) : null; grid = A.blockGrid; block = true; } else { tile = MC.Items.itemTexture(it.id, it.data); grid = A.itemGrid; }
    if (tile === null || tile === undefined) return null;
    const u0 = (tile % grid) / grid, v0 = Math.floor(tile / grid) / grid, t = 1 / grid;
    // Рукоять в кулаке, остриё вперёд и вверх
    // Плоскость предмета развёрнута наружу на 40°, чтобы его было видно и спереди, и сбоку
    const S = 10, ox = -Math.sin(0.7), oz = Math.cos(0.7);
    const corner = (u, v) => { const pt = place(ox * u * S, 24 - 13 + v * S - u * 2, -2 + oz * u * S); return [pt[0], pt[1], pt[2], u0 + u * t, v0 + (1 - v) * t]; };
    const q = [corner(0, 0), corner(1, 0), corner(1, 1), corner(0, 1)];
    for (const k of [0, 1, 2, 0, 2, 3]) verts.push(q[k][0], q[k][1], q[k][2], q[k][3], q[k][4], 0.9);
    return { verts, block };
  }

  function frustumPlanes(m) {
    const p = [];
    const rows = (i) => [m[i], m[4 + i], m[8 + i], m[12 + i]];
    const r0 = rows(0), r1 = rows(1), r2 = rows(2), r3 = rows(3);
    const add = (a, s) => [r3[0] + s * a[0], r3[1] + s * a[1], r3[2] + s * a[2], r3[3] + s * a[3]];
    p.push(add(r0, 1), add(r0, -1), add(r1, 1), add(r1, -1), add(r2, 1), add(r2, -1));
    return p;
  }

  function boxInFrustum(planes, x0, y0, z0, x1, y1, z1) {
    for (const pl of planes) {
      const x = pl[0] >= 0 ? x1 : x0, y = pl[1] >= 0 ? y1 : y0, z = pl[2] >= 0 ? z1 : z0;
      if (pl[0] * x + pl[1] * y + pl[2] * z + pl[3] < 0) return false;
    }
    return true;
  }

  MC.Renderer = Renderer;
  MC.ENTITY_LOOK = ENTITY_LOOK;
})();
