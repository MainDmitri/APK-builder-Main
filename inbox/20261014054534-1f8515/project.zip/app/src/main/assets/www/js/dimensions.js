// Измерения одиночной игры: Нижний мир (Ад) и Край, крепости с порталом Края, порталы и переходы между мирами
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const Blocks = MC.Blocks;

  // ---------- Крепости (stronghold) в обычном мире ----------
  // Три крепости на кольце 320–640 блоков от центра мира, как в Minecraft (там кольцо дальше)
  const STRONG_Y = 28;
  const strongCache = new Map();

  function strongholds(seed) {
    if (strongCache.has(seed)) return strongCache.get(seed);
    const a0 = MC.hash3(seed, 11, 22, 33) * Math.PI * 2;
    const list = [];
    for (let i = 0; i < 3; i++) {
      const a = a0 + i * Math.PI * 2 / 3;
      const r = 320 + MC.hash3(seed, i, 5, 7) * 320;
      list.push({ x: Math.floor(Math.cos(a) * r), y: STRONG_Y, z: Math.floor(Math.sin(a) * r) });
    }
    strongCache.set(seed, list);
    return list;
  }

  function nearestStronghold(seed, x, z) {
    let best = null, bd = Infinity;
    for (const s of strongholds(seed)) {
      const d = Math.hypot(s.x - x, s.z - z);
      if (d < bd) { bd = d; best = s; }
    }
    return best;
  }

  // Комната с порталом и три коридора; блоки ставятся только в пределах генерируемого чанка
  function carveStronghold(seed, chunk, cx, cz) {
    const x0 = cx * 16, z0 = cz * 16;
    for (const s of strongholds(seed)) {
      if (s.x + 40 < x0 || s.x - 40 > x0 + 15 || s.z + 40 < z0 || s.z - 40 > z0 + 15) continue;
      const put = (x, y, z, id, d) => {
        const lx = x - x0, lz = z - z0;
        if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 1 || y > 255) return;
        chunk.set(lx, y, lz, id, d || 0);
      };
      const brick = (x, y, z) => {
        const r = MC.hash3(seed + 41, x, y, z);
        put(x, y, z, 98, r < 0.2 ? 1 : r < 0.35 ? 2 : 0);
      };
      // Полая коробка из каменных кирпичей
      const room = (ax, ay, az, bx, by, bz) => {
        for (let x = ax; x <= bx; x++) for (let y = ay; y <= by; y++) for (let z = az; z <= bz; z++) {
          if (x === ax || x === bx || y === ay || y === by || z === az || z === bz) brick(x, y, z);
          else put(x, y, z, 0, 0);
        }
      };
      const Y = s.y;
      // Коридоры: на север (−z) и на запад/восток (±x), 3 в ширину, 3 в высоту
      room(s.x - 2, Y - 1, s.z - 34, s.x + 2, Y + 3, s.z - 7);
      room(s.x - 34, Y - 1, s.z - 2, s.x - 5, Y + 3, s.z + 2);
      room(s.x + 5, Y - 1, s.z - 2, s.x + 34, Y + 3, s.z + 2);
      for (let k = -30; k <= -9; k += 6) put(s.x, Y + 2, s.z + k, 89, 0);
      for (let k = 8; k <= 32; k += 6) { put(s.x - k, Y + 2, s.z, 89, 0); put(s.x + k, Y + 2, s.z, 89, 0); }
      // Комната с порталом 11×15, высота 7
      room(s.x - 5, Y - 1, s.z - 7, s.x + 5, Y + 7, s.z + 7);
      for (const [dx, dz] of [[0, -7], [-5, 0], [5, 0]]) for (let dy = 0; dy < 3; dy++) for (let w = -1; w <= 1; w++) {
        put(s.x + dx + (dz ? w : 0), Y + dy, s.z + dz + (dx ? w : 0), 0, 0);
      }
      // Помост с рамкой портала над лавой; 10 % рамок уже с оком, как в игре
      const pcx = s.x, pcz = s.z + 2;
      for (let x = pcx - 3; x <= pcx + 3; x++) for (let z = pcz - 3; z <= pcz + 3; z++) brick(x, Y, z);
      for (let x = pcx - 1; x <= pcx + 1; x++) for (let z = pcz - 1; z <= pcz + 1; z++) { put(x, Y, z, 11, 0); put(x, Y + 1, z, 0, 0); }
      for (let i = -1; i <= 1; i++) {
        const eye = (k) => (MC.hash3(seed + 77, s.x, k, s.z) < 0.1 ? 4 : 0);
        put(pcx + i, Y + 1, pcz - 2, 120, 0 | eye(i));
        put(pcx + i, Y + 1, pcz + 2, 120, 2 | eye(i + 10));
        put(pcx - 2, Y + 1, pcz + i, 120, 3 | eye(i + 20));
        put(pcx + 2, Y + 1, pcz + i, 120, 1 | eye(i + 30));
      }
      // Лестница к помосту и светокамень на потолке
      for (let x = pcx - 1; x <= pcx + 1; x++) put(x, Y, pcz - 4, 109, 2);
      for (const [dx, dz] of [[-4, -6], [4, -6], [-4, 6], [4, 6]]) put(s.x + dx, Y + 6, s.z + dz, 89, 0);
      for (let z = s.z - 6; z <= s.z + 6; z += 3) { put(s.x - 4, Y + 1, z, 101, 0); put(s.x + 4, Y + 1, z, 101, 0); }
    }
  }

  // ---------- Нижний мир ----------
  class NetherGenerator {
    constructor(seed, record) {
      this.seed = seed | 0;
      this.record = record || null;
      this.n1 = new MC.Perlin(seed + 101);
      this.n2 = new MC.Perlin(seed + 102);
      this.n3 = new MC.Perlin(seed + 103);
      this.LAVA = 31;
    }

    density(x, y, z) {
      let d = this.n1.noise3(x / 48, y / 28, z / 48) + 0.5 * this.n2.noise3(x / 16, y / 12, z / 16) - 0.12;
      if (y < 24) d += (24 - y) / 10;
      if (y > 100) d += (y - 100) / 8;
      return d;
    }

    generate(cx, cz) {
      const chunk = new MC.Chunk(cx, cz);
      const H = this.seed;
      for (let x = 0; x < 16; x++) {
        for (let z = 0; z < 16; z++) {
          const wx = cx * 16 + x, wz = cz * 16 + z;
          for (let y = 0; y <= 127; y++) {
            let id = 0;
            if (y === 0 || y === 127 || (y < 5 && MC.hash3(H, wx, y, wz) < 0.5 - y * 0.1) || (y > 122 && MC.hash3(H, wx, y, wz) < 0.5 - (127 - y) * 0.1)) id = 7;
            else if (this.density(wx, y, wz) > 0) {
              id = 87;
              const r = MC.hash3(H + 5, wx, y, wz);
              if (r < 0.018) id = 153;
              else if (y >= 28 && y <= 33 && r > 0.9) id = 213;
            } else if (y <= this.LAVA) id = 11;
            if (id) chunk.set(x, y, z, id, 0);
          }
          // Песок душ и гравий у берегов лавового моря, светокамень под потолком
          const patch = this.n3.noise2(wx / 24, wz / 24);
          for (let y = 30; y <= 40; y++) {
            if (chunk.getId(x, y, z) !== 87 || chunk.getId(x, y + 1, z) !== 0) continue;
            if (patch > 0.3) { chunk.set(x, y, z, 88, 0); if (y > 30) chunk.set(x, y - 1, z, 88, 0); }
            else if (patch < -0.4) chunk.set(x, y, z, 13, 0);
          }
          for (let y = 60; y < 122; y++) {
            if (chunk.getId(x, y, z) !== 87 || chunk.getId(x, y - 1, z) !== 0) continue;
            if (MC.hash3(H + 9, wx, y, wz) < 0.006) {
              const n = 2 + Math.floor(MC.hash3(H + 10, wx, y, wz) * 4);
              for (let k = 1; k <= n && chunk.getId(x, y - k, z) === 0; k++) chunk.set(x, y - k, z, 89, 0);
            }
          }
        }
      }
      this.fortress(chunk, cx, cz);
      chunk.recalcHeight();
      return chunk;
    }

    // Адская крепость: мосты из адского кирпича крестом через участок 128×128, опоры до земли, зал с адским наростом
    fortressAt(rx, rz) {
      if (MC.hash3(this.seed + 55, rx, 0, rz) > 0.55) return null;
      return {
        x: rx * 128 + 32 + Math.floor(MC.hash3(this.seed + 56, rx, 1, rz) * 64),
        y: 64 + Math.floor(MC.hash3(this.seed + 57, rx, 2, rz) * 10),
        z: rz * 128 + 32 + Math.floor(MC.hash3(this.seed + 58, rx, 3, rz) * 64)
      };
    }

    fortress(chunk, cx, cz) {
      const x0 = cx * 16, z0 = cz * 16;
      const rx = Math.floor((x0 + 8) / 128), rz = Math.floor((z0 + 8) / 128);
      for (let ax = rx - 1; ax <= rx + 1; ax++) for (let az = rz - 1; az <= rz + 1; az++) {
        const f = this.fortressAt(ax, az);
        if (!f || f.x + 56 < x0 || f.x - 56 > x0 + 15 || f.z + 56 < z0 || f.z - 56 > z0 + 15) continue;
        const put = (x, y, z, id, d) => {
          const lx = x - x0, lz = z - z0;
          if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 1 || y > 126) return;
          chunk.set(lx, y, lz, id, d || 0);
        };
        const get = (x, y, z) => chunk.getId(x - x0, y, z - z0);
        const inChunk = (x, z) => x >= x0 && x <= x0 + 15 && z >= z0 && z <= z0 + 15;
        const Y = f.y;
        // Мост: настил 5 в ширину, перила-заборы, проход высотой 4
        const bridge = (along) => {
          for (let t = -52; t <= 52; t++) for (let w = -2; w <= 2; w++) {
            const x = along ? f.x + t : f.x + w, z = along ? f.z + w : f.z + t;
            if (!inChunk(x, z)) continue;
            put(x, Y, z, 112, 0);
            for (let dy = 1; dy <= 4; dy++) put(x, Y + dy, z, 0, 0);
            if (Math.abs(w) === 2) put(x, Y + 1, z, 113, 0);
            // Опоры через каждые 8 блоков до земли или лавы
            if (t % 8 === 0 && Math.abs(w) === 2) for (let y = Y - 1; y > 1; y--) {
              const id = get(x, y, z);
              if (id !== 0 && id !== 10 && id !== 11) break;
              put(x, y, z, 112, 0);
            }
          }
        };
        bridge(true);
        bridge(false);
        // Центральный зал 11×11 с окнами и грядками адского нароста на песке душ
        for (let x = f.x - 5; x <= f.x + 5; x++) for (let z = f.z - 5; z <= f.z + 5; z++) for (let y = Y; y <= Y + 6; y++) {
          if (!inChunk(x, z)) continue;
          const edge = x === f.x - 5 || x === f.x + 5 || z === f.z - 5 || z === f.z + 5;
          if (y === Y || y === Y + 6) put(x, y, z, 112, 0);
          else if (edge) put(x, y, z, (y === Y + 3 && (x + z) % 3 === 0) ? 113 : 112, 0);
          else put(x, y, z, 0, 0);
        }
        for (const [dx, dz] of [[0, -5], [0, 5], [-5, 0], [5, 0]]) for (let w = -1; w <= 1; w++) for (let dy = 1; dy <= 3; dy++) {
          put(f.x + dx + (dz ? w : 0), Y + dy, f.z + dz + (dx ? w : 0), 0, 0);
        }
        for (const sx of [-3, 2]) for (let x = f.x + sx; x <= f.x + sx + 1; x++) for (let z = f.z - 3; z <= f.z + 3; z++) {
          put(x, Y, z, 88, 0);
          put(x, Y + 1, z, 115, Math.floor(MC.hash3(this.seed + 59, x, Y, z) * 4));
        }
        // Сундуки крепости в углах зала
        const chests = [[f.x - 4, Y + 1, f.z + 4, 2], [f.x + 4, Y + 1, f.z - 4, 3]];
        for (const [x, y, z, d] of chests) {
          if (!inChunk(x, z)) continue;
          put(x, y, z, 54, d);
          fillLoot(this.record, 'n:' + x + ',' + y + ',' + z, LOOT.fortress, this.seed + 61, x, y, z);
        }
        // Площадки с рассадниками ифритов на двух концах мостов: настил 7×7, заборы по краю, проход по мосту
        for (const [sx, sz] of [[f.x + 40, f.z], [f.x, f.z - 40]]) {
          for (let dx = -3; dx <= 3; dx++) for (let dz = -3; dz <= 3; dz++) {
            const x = sx + dx, z = sz + dz;
            if (!inChunk(x, z)) continue;
            put(x, Y, z, 112, 0);
            for (let dy = 1; dy <= 4; dy++) put(x, Y + dy, z, 0, 0);
            const edge = Math.abs(dx) === 3 || Math.abs(dz) === 3;
            const path = sx === f.x ? Math.abs(dx) <= 1 : Math.abs(dz) <= 1;
            if (edge && !path) put(x, Y + 1, z, 113, 0);
          }
          const bx = sx + (sx === f.x ? 2 : 0), bz = sz + (sx === f.x ? 0 : 2);
          if (inChunk(bx, bz)) put(bx, Y + 1, bz, 52, 4);
        }
      }
    }

    findSpawn() { return { x: 0.5, y: 64, z: 0.5 }; }
  }

  // ---------- Добыча в сундуках ----------
  // [id, мин, макс, вес]
  const LOOT = {
    fortress: [[265, 1, 5, 5], [266, 1, 3, 5], [264, 1, 3, 2], [329, 1, 1, 3], [418, 1, 1, 2], [372, 3, 7, 4], [49, 2, 4, 2], [283, 1, 1, 3], [315, 1, 1, 3], [259, 1, 1, 3]],
    endCity: [[264, 2, 7, 5], [265, 4, 8, 10], [266, 2, 7, 15], [388, 2, 6, 2], [329, 1, 1, 3], [417, 1, 1, 1], [418, 1, 1, 1], [419, 1, 1, 1],
      [276, 1, 1, 3], [278, 1, 1, 3], [310, 1, 1, 3], [311, 1, 1, 3], [312, 1, 1, 3], [313, 1, 1, 3], [432, 2, 6, 4]],
    dungeon: [[297, 1, 1, 15], [296, 1, 4, 10], [265, 1, 4, 10], [266, 1, 4, 5], [331, 1, 4, 10], [329, 1, 1, 10], [322, 1, 1, 2], [287, 1, 4, 10],
      [325, 1, 1, 10], [289, 1, 4, 10], [421, 1, 1, 10], [352, 1, 4, 10], [367, 1, 4, 10]]
  };

  // Сундук с добычей при первой генерации (key — ключ контейнера с префиксом измерения)
  function fillLoot(record, key, table, seed, x, y, z, extra) {
    if (!record) return;
    if (!record.containers) record.containers = {};
    if (record.containers[key]) return;
    const slots = new Array(27).fill(null);
    const total = table.reduce((acc, t) => acc + t[3], 0);
    const n = 3 + Math.floor(MC.hash3(seed, x, y, z) * 5);
    for (let i = 0; i < n; i++) {
      let r = MC.hash3(seed + i + 1, x, y, z) * total;
      let pick = table[0];
      for (const t of table) { r -= t[3]; if (r <= 0) { pick = t; break; } }
      const cnt = pick[1] + Math.floor(MC.hash3(seed + 50 + i, x, y, z) * (pick[2] - pick[1] + 1));
      slots[Math.floor(MC.hash3(seed + 100 + i, x, y, z) * 27)] = { id: pick[0], data: 0, count: cnt };
    }
    for (const it of extra || []) { const free = slots.indexOf(null); if (free >= 0) slots[free] = it; }
    record.containers[key] = slots;
  }

  // ---------- Край ----------
  // Центральный остров со столбами и кристаллами, внешние острова (дальше 1000 блоков) с хорусом и городами Края
  const OUTER_R = 1000;
  const GATEWAY_R = 96, GATEWAY_Y = 75;

  class EndGenerator {
    constructor(seed, record) {
      this.seed = seed | 0;
      this.record = record;
      this.n1 = new MC.Perlin(seed + 201);
      this.n2 = new MC.Perlin(seed + 202);
      this.cities = new Map();
    }

    // Обсидиановые столбы вокруг центра: 10 штук на окружности радиусом 42, два — в клетках из решёток
    pillars() {
      if (this._pillars) return this._pillars;
      const out = [];
      for (let i = 0; i < 10; i++) {
        const a = i * Math.PI * 2 / 10;
        out.push({ i, x: Math.round(Math.cos(a) * 42), z: Math.round(Math.sin(a) * 42), r: 2 + (i % 3), h: 76 + ((i * 7) % 10) * 3, cage: i === 3 || i === 9 });
      }
      this._pillars = out;
      return out;
    }

    // Внешний остров в столбце: {top, bottom} или null
    outerColumn(wx, wz) {
      if (Math.hypot(wx, wz) < OUTER_R) return null;
      const S = 56, H = this.seed + 301;
      const cx = Math.floor(wx / S), cz = Math.floor(wz / S);
      let best = null;
      for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
        const ax = cx + dx, az = cz + dz;
        if (MC.hash3(H, ax, 0, az) > 0.62) continue;
        const x0 = ax * S + 8 + MC.hash3(H, ax, 1, az) * 40, z0 = az * S + 8 + MC.hash3(H, ax, 2, az) * 40;
        if (Math.hypot(x0, z0) < OUTER_R) continue;
        const R = 9 + MC.hash3(H, ax, 3, az) * 16;
        const d = Math.hypot(wx - x0, wz - z0);
        const edge = R * (0.8 + 0.35 * this.n1.noise2(wx / 12, wz / 12));
        if (d >= edge) continue;
        const top = 56 + Math.floor(MC.hash3(H, ax, 4, az) * 12) + Math.floor(this.n2.noise2(wx / 9, wz / 9) * 1.5);
        const depth = Math.floor((1 - (d / edge) * (d / edge)) * R * 0.9) + 1;
        if (!best || top > best.top) best = { top, bottom: top - depth };
      }
      return best;
    }

    generate(cx, cz) {
      const chunk = new MC.Chunk(cx, cz);
      const H = this.seed;
      const far = Math.hypot(cx * 16 + 8, cz * 16 + 8) > OUTER_R - 40;
      for (let x = 0; x < 16; x++) {
        for (let z = 0; z < 16; z++) {
          const wx = cx * 16 + x, wz = cz * 16 + z;
          if (far) {
            const col = this.outerColumn(wx, wz);
            if (!col) continue;
            for (let y = col.bottom; y <= col.top; y++) chunk.set(x, y, z, 121, 0);
            // Хорус: стебель с цветком, иногда с ветками
            if (col.top - col.bottom >= 3 && MC.hash3(H + 310, wx, 0, wz) < 0.008) {
              const h = 2 + Math.floor(MC.hash3(H + 311, wx, 0, wz) * 4);
              for (let y = 1; y <= h; y++) chunk.set(x, col.top + y, z, 240, 0);
              chunk.set(x, col.top + h + 1, z, 200, 0);
              const by = col.top + 1 + Math.floor(MC.hash3(H + 312, wx, 0, wz) * h);
              const dir = Math.floor(MC.hash3(H + 313, wx, 0, wz) * 4);
              const [bx, bz] = [[1, 0], [-1, 0], [0, 1], [0, -1]][dir];
              if (x + bx >= 0 && x + bx < 16 && z + bz >= 0 && z + bz < 16) { chunk.set(x + bx, by, z + bz, 240, 0); chunk.set(x + bx, by + 1, z + bz, 200, 0); }
            }
            continue;
          }
          const r = Math.hypot(wx, wz);
          const edge = 68 + this.n1.noise2(wx / 40, wz / 40) * 10;
          if (r >= edge) continue;
          const top = 60 + Math.floor(this.n1.noise2(wx / 25 + 50, wz / 25) * 2);
          const depth = 3 + Math.floor((1 - r / edge) * (1 - r / edge) * 45);
          for (let y = top - depth; y <= top; y++) chunk.set(x, y, z, 121, 0);
        }
      }
      if (!far) {
        for (const p of this.pillars()) {
          for (let x = p.x - p.r - 2; x <= p.x + p.r + 2; x++) for (let z = p.z - p.r - 2; z <= p.z + p.r + 2; z++) {
            const lx = x - cx * 16, lz = z - cz * 16;
            if (lx < 0 || lx > 15 || lz < 0 || lz > 15) continue;
            if (Math.hypot(x - p.x, z - p.z) <= p.r + 0.5) {
              for (let y = 50; y <= p.h; y++) chunk.set(lx, y, lz, 49, 0);
              if (x === p.x && z === p.z) chunk.set(lx, p.h + 1, lz, 7, 0);
            }
            // Клетка из железных решёток вокруг кристалла
            if (p.cage && Math.abs(x - p.x) <= 2 && Math.abs(z - p.z) <= 2) {
              const edge = Math.abs(x - p.x) === 2 || Math.abs(z - p.z) === 2;
              for (let y = p.h + 1; y <= p.h + 4; y++) if (edge) chunk.set(lx, y, lz, 101, 0);
              chunk.set(lx, p.h + 5, lz, 101, 0);
            }
          }
        }
        this.exitPortal(chunk, cx, cz);
      } else this.cityParts(chunk, cx, cz);
      chunk.recalcHeight();
      return chunk;
    }

    // Портал выхода в центре: чаша из бедрока; портал открывается после победы над драконом
    exitPortal(chunk, cx, cz) {
      const open = !!(this.record && this.record.dragonKilled);
      for (let x = -4; x <= 4; x++) for (let z = -4; z <= 4; z++) {
        const lx = x - cx * 16, lz = z - cz * 16;
        if (lx < 0 || lx > 15 || lz < 0 || lz > 15) continue;
        const r = Math.hypot(x, z);
        if (r > 3.5) continue;
        chunk.set(lx, 60, lz, 7, 0);
        if (r > 2.5) chunk.set(lx, 61, lz, 7, 0);
        else chunk.set(lx, 61, lz, open ? 119 : 0, 0);
        if (x === 0 && z === 0) for (let y = 61; y <= 64; y++) chunk.set(lx, y, lz, 7, 0);
        else for (let y = 62; y <= 66; y++) chunk.set(lx, y, lz, 0, 0);
      }
    }

    // Город Края в ячейке 400×400 (если в её точке есть остров)
    cityAt(rx, rz) {
      const k = rx + ',' + rz;
      if (this.cities.has(k)) return this.cities.get(k);
      let c = null;
      const H = this.seed + 401;
      if (MC.hash3(H, rx, 0, rz) < 0.55) {
        const x = rx * 400 + 100 + Math.floor(MC.hash3(H, rx, 1, rz) * 200), z = rz * 400 + 100 + Math.floor(MC.hash3(H, rx, 2, rz) * 200);
        if (Math.hypot(x, z) > OUTER_R + 100) {
          let col = null;
          // Город ставится на ближайший к точке остров
          for (let r = 0; r <= 40 && !col; r += 4) for (let a = 0; a < 8 && !col; a++) {
            const tx = x + Math.round(Math.cos(a * Math.PI / 4) * r), tz = z + Math.round(Math.sin(a * Math.PI / 4) * r);
            const cc = this.outerColumn(tx, tz);
            if (cc && cc.top - cc.bottom >= 4) col = { x: tx, z: tz, y: cc.top + 1 };
          }
          if (col) c = { x: col.x, y: col.y, z: col.z, blocks: null };
        }
      }
      this.cities.set(k, c);
      return c;
    }

    // Блоки города: башня из пурпура с лестницей, комната с сундуком наверху, корабль Края с элитрами
    cityBlocks(c) {
      if (c.blocks) return c.blocks;
      const out = [], chests = [], shulkers = [];
      const put = (x, y, z, id, d) => out.push([x, y, z, id, d || 0]);
      const X = c.x, Y = c.y, Z = c.z, TH = 26;
      // Башня 9×9
      for (let y = Y; y < Y + TH; y++) for (let x = -4; x <= 4; x++) for (let z = -4; z <= 4; z++) {
        const edge = Math.abs(x) === 4 || Math.abs(z) === 4;
        const floor = (y - Y) % 7 === 0;
        const corner = Math.abs(x) === 4 && Math.abs(z) === 4;
        let id = 0, d = 0;
        if (corner) { id = 201; d = 2; }
        else if (edge) id = ((y - Y) % 7 === 3 && (x === 0 || z === 0)) ? 0 : 201;
        else if (floor && !(x === 3 && z === 0)) id = y === Y ? 206 : 201;
        put(X + x, y, Z + z, id, d);
      }
      for (let y = Y + 1; y < Y + TH + 1; y++) put(X + 3, y, Z, 65, 4);
      // Вход
      for (let y = Y + 1; y <= Y + 2; y++) put(X, y, Z - 4, 0);
      // Верхняя комната 11×11 с крышей и стержнями Края
      const R = Y + TH;
      for (let y = R; y <= R + 5; y++) for (let x = -5; x <= 5; x++) for (let z = -5; z <= 5; z++) {
        const edge = Math.abs(x) === 5 || Math.abs(z) === 5;
        let id = 0;
        if (y === R && !(x === 3 && z === 0)) id = 201;
        else if (y === R + 5) id = 201;
        else if (edge) id = (y === R + 2 && (Math.abs(x) === 2 || Math.abs(z) === 2)) ? 20 : 201;
        put(X + x, y, Z + z, id, Math.abs(x) === 5 && Math.abs(z) === 5 ? 2 : 0);
      }
      for (const [x, z] of [[-5, -5], [5, -5], [-5, 5], [5, 5]]) put(X + x, R + 6, Z + z, 208, 1);
      put(X, R + 1, Z + 3, 54, 2);
      chests.push([X, R + 1, Z + 3, null]);
      shulkers.push([X - 3, R + 1, Z - 3], [X + 3, R + 1, Z - 3], [X - 3, Y + 8, Z - 3]);
      // Корабль Края: висит рядом с городом
      const SX = X + 22, SY = R + 10, SZ = Z;
      for (let x = -10; x <= 10; x++) {
        const half = x < -7 ? 1 : x > 7 ? Math.max(0, 10 - x) : 3;
        for (let z = -half; z <= half; z++) {
          put(SX + x, SY, SZ + z, 201);
          if (Math.abs(z) === half) { put(SX + x, SY + 1, SZ + z, 201); put(SX + x, SY + 2, SZ + z, 203, z > 0 ? 3 : 2); }
        }
        if (Math.abs(x) <= 7) put(SX + x, SY - 1, SZ, 206);
      }
      for (let y = SY + 1; y <= SY + 12; y++) put(SX - 2, y, SZ, 208, 1);
      for (let z = -4; z <= 4; z++) put(SX - 2, SY + 10, SZ + z, 35, 10);
      // Каюта внизу с сундуками: в одном элитры
      for (let x = -4; x <= 4; x++) for (let z = -2; z <= 2; z++) for (let y = SY - 4; y <= SY - 1; y++) {
        const edge = Math.abs(x) === 4 || Math.abs(z) === 2 || y === SY - 4;
        put(SX + x, y, SZ + z, edge ? 201 : 0);
      }
      put(SX + 3, SY - 1, SZ, 0);
      put(SX + 3, SY, SZ, 0);
      put(SX - 3, SY - 3, SZ - 1, 54, 3);
      put(SX - 3, SY - 3, SZ + 1, 54, 2);
      chests.push([SX - 3, SY - 3, SZ - 1, [{ id: 444, data: 0, count: 1 }]], [SX - 3, SY - 3, SZ + 1, null]);
      shulkers.push([SX + 1, SY - 3, SZ], [SX + 6, SY + 1, SZ]);
      c.blocks = out;
      c.chests = chests;
      c.shulkers = shulkers;
      return out;
    }

    cityParts(chunk, cx, cz) {
      const x0 = cx * 16, z0 = cz * 16;
      const rx = Math.floor((x0 + 8) / 400), rz = Math.floor((z0 + 8) / 400);
      for (let ax = rx - 1; ax <= rx + 1; ax++) for (let az = rz - 1; az <= rz + 1; az++) {
        const c = this.cityAt(ax, az);
        if (!c || c.x + 40 < x0 || c.x - 20 > x0 + 15 || c.z + 20 < z0 || c.z - 20 > z0 + 15) continue;
        for (const [x, y, z, id, d] of this.cityBlocks(c)) {
          const lx = x - x0, lz = z - z0;
          if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 1 || y > 254) continue;
          chunk.set(lx, y, lz, id, d);
        }
        const rec = this.record;
        for (const [x, y, z, extra] of c.chests) {
          if (x < x0 || x > x0 + 15 || z < z0 || z > z0 + 15) continue;
          fillLoot(rec, 'e:' + x + ',' + y + ',' + z, LOOT.endCity, this.seed + 77, x, y, z, extra);
        }
        if (rec) {
          if (!rec.fixedSpawns) rec.fixedSpawns = [];
          for (const [x, y, z] of c.shulkers) {
            if (x < x0 || x > x0 + 15 || z < z0 || z > z0 + 15) continue;
            const id = 'shulker:' + x + ',' + y + ',' + z;
            if (!rec.fixedSpawns.some((f) => f.id === id)) rec.fixedSpawns.push({ id, d: 2, x, y, z, type: 54 });
          }
        }
      }
    }

    // Точка на внешнем острове в направлении (dx, dz) примерно в 1024 блоках от центра
    outerLanding(dx, dz) {
      const l = Math.hypot(dx, dz) || 1;
      const bx = Math.round(dx / l * 1024), bz = Math.round(dz / l * 1024);
      for (let r = 0; r <= 160; r += 4) {
        for (let a = 0; a < 16; a++) {
          const x = bx + Math.round(Math.cos(a * Math.PI / 8) * r), z = bz + Math.round(Math.sin(a * Math.PI / 8) * r);
          const c = this.outerColumn(x, z);
          if (c && c.top - c.bottom >= 3) return { x, y: c.top + 1, z };
          if (r === 0) break;
        }
      }
      return { x: bx, y: 0, z: bz };
    }

    findSpawn() { return { x: 100.5, y: 49, z: 0.5 }; }
  }

  // ---------- Порталы и переходы ----------
  const isAir = (id) => id === 0 || id === 51;
  const DIM_NAMES = ['Обычный мир', 'Нижний мир', 'Край'];

  class Portals {
    constructor(game) {
      this.game = game;
      this.world = game.world;
      this.check = new Set();
      this.fires = new Map();
      this.portalT = 0;
      this.cooldown = false;
      // Чанк центра Края мог загрузиться уже после победы: портал выхода и яйцо ставятся при загрузке
      game.world.onChunkSet((cx, cz) => {
        if (this.game.dimension !== 2) return;
        if (cx === 0 && cz === 0 && this.game.record.dragonKilled) this.openExit();
        this.placeGateways(cx, cz);
      });
      game.world.onBlockSet((x, y, z, id) => {
        if (id === 90) return;
        for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) this.check.add((x + dx) + ',' + (y + dy) + ',' + (z + dz));
      });
    }

    // Огниво: внутри обсидиановой рамки зажигает портал, иначе ставит огонь
    ignite(x, y, z) {
      const w = this.world;
      if (!isAir(w.getId(x, y, z))) return false;
      for (const axis of [1, 2]) {
        const f = this.findFrame(x, y, z, axis);
        if (!f) continue;
        for (let i = 0; i < f.w; i++) for (let j = 0; j < f.h; j++) w.setBlock(f.x + f.dx * i, f.y + j, f.z + f.dz * i, 90, axis);
        MC.Sound.play('fire.ignite', { x, y, z }, 1, 1);
        return true;
      }
      return false;
    }

    // Рамка портала: обсидиан по краям прямоугольника от 2×3 до 21×21; углы не обязательны
    findFrame(x, y, z, axis) {
      const w = this.world;
      const dx = axis === 1 ? 1 : 0, dz = axis === 2 ? 1 : 0;
      let by = y;
      for (let k = 0; k < 22 && isAir(w.getId(x, by - 1, z)); k++) by--;
      if (w.getId(x, by - 1, z) !== 49) return null;
      let sx = x, sz = z;
      for (let k = 0; k < 22 && isAir(w.getId(sx - dx, by, sz - dz)); k++) { sx -= dx; sz -= dz; }
      if (w.getId(sx - dx, by, sz - dz) !== 49) return null;
      let width = 0;
      while (width < 22 && isAir(w.getId(sx + dx * width, by, sz + dz * width))) width++;
      if (width < 2 || width > 21 || w.getId(sx + dx * width, by, sz + dz * width) !== 49) return null;
      let height = 0;
      while (height < 22 && isAir(w.getId(sx, by + height, sz))) height++;
      if (height < 3 || height > 21 || w.getId(sx, by + height, sz) !== 49) return null;
      for (let i = 0; i < width; i++) {
        if (w.getId(sx + dx * i, by - 1, sz + dz * i) !== 49 || w.getId(sx + dx * i, by + height, sz + dz * i) !== 49) return null;
        for (let j = 0; j < height; j++) if (!isAir(w.getId(sx + dx * i, by + j, sz + dz * i))) return null;
      }
      for (let j = 0; j < height; j++) {
        if (w.getId(sx - dx, by + j, sz - dz) !== 49 || w.getId(sx + dx * width, by + j, sz + dz * width) !== 49) return null;
      }
      return { x: sx, y: by, z: sz, w: width, h: height, dx, dz };
    }

    // Огонь от огнива и огненных шаров гаснет через 3–8 с (на адском камне горит вечно)
    addFire(x, y, z) {
      const w = this.world;
      if (!isAir(w.getId(x, y, z)) || w.getId(x, y, z) === 51) return false;
      const below = w.getId(x, y - 1, z);
      if (!Blocks.list[below].solid) return false;
      w.setBlock(x, y, z, 51, 0);
      if (below !== 87) this.fires.set(x + ',' + y + ',' + z, 3 + Math.random() * 5);
      MC.Sound.play('fire.ignite', { x: x + 0.5, y, z: z + 0.5 }, 1, 1);
      return true;
    }

    // Око Края в рамку портала; 12 рамок с оком открывают портал в Край
    placeEye(hit) {
      const w = this.world;
      if (hit.id !== 120 || hit.data & 4) return false;
      w.setBlock(hit.x, hit.y, hit.z, 120, hit.data | 4);
      MC.Sound.play('random.orb', { x: hit.x, y: hit.y, z: hit.z }, 1, 0.6);
      const g = this.game;
      if (g.particles.swirl) for (let i = 0; i < 8; i++) g.particles.swirl(hit.x + Math.random(), hit.y + 0.9, hit.z + Math.random(), [0.3, 0.7, 0.5], 0.05, 0.3);
      for (let cx = hit.x - 2; cx <= hit.x + 2; cx++) for (let cz = hit.z - 2; cz <= hit.z + 2; cz++) {
        let ok = true;
        for (let i = -1; i <= 1 && ok; i++) {
          for (const [x, z] of [[cx + i, cz - 2], [cx + i, cz + 2], [cx - 2, cz + i], [cx + 2, cz + i]]) {
            if (w.getId(x, hit.y, z) !== 120 || !(w.getData(x, hit.y, z) & 4)) { ok = false; break; }
          }
        }
        if (!ok) continue;
        for (let x = cx - 1; x <= cx + 1; x++) for (let z = cz - 1; z <= cz + 1; z++) w.setBlock(x, hit.y, z, 119, 0);
        MC.Sound.play('random.levelup', null, 1, 0.5);
        g.ui.setPopup('§5Портал в Край открыт');
        return true;
      }
      return true;
    }

    // Портал рушится, если сломать рамку
    validPortal(x, y, z) {
      const w = this.world;
      const d = w.getData(x, y, z);
      const ok = (id) => id === 90 || id === 49;
      const sides = d === 2 ? [[0, 0, 1], [0, 0, -1]] : [[1, 0, 0], [-1, 0, 0]];
      for (const [dx, dy, dz] of sides.concat([[0, 1, 0], [0, -1, 0]])) if (!ok(w.getId(x + dx, y + dy, z + dz))) return false;
      return true;
    }

    breakPortal(x, y, z) {
      const w = this.world;
      const queue = [[x, y, z]], seen = new Set();
      while (queue.length && seen.size < 600) {
        const [a, b, c] = queue.pop();
        const k = a + ',' + b + ',' + c;
        if (seen.has(k) || w.getId(a, b, c) !== 90) continue;
        seen.add(k);
        w.setBlock(a, b, c, 0, 0);
        for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) queue.push([a + dx, b + dy, c + dz]);
      }
    }

    update(dt) {
      const g = this.game, w = this.world, p = g.player;
      if (this.check.size) {
        const list = Array.from(this.check);
        this.check.clear();
        for (const k of list) {
          const [x, y, z] = k.split(',').map(Number);
          if (w.getId(x, y, z) === 90 && !this.validPortal(x, y, z)) this.breakPortal(x, y, z);
        }
      }
      for (const [k, t] of this.fires) {
        const left = t - dt;
        if (left > 0) { this.fires.set(k, left); continue; }
        this.fires.delete(k);
        const [x, y, z] = k.split(',').map(Number);
        if (w.getId(x, y, z) === 51) w.setBlock(x, y, z, 0, 0);
      }
      if (g.traveling || g.dead) return;
      const feet = w.getId(Math.floor(p.x), Math.floor(p.y + 0.2), Math.floor(p.z));
      const body = w.getId(Math.floor(p.x), Math.floor(p.y + 1), Math.floor(p.z));
      if (feet === 119 || body === 119) {
        if (!this.cooldown) { this.cooldown = true; this.travel(g.dimension === 2 ? 0 : 2); }
        return;
      }
      // Врата Края: мгновенный перенос на внешние острова и обратно
      if (feet === 209 || body === 209) {
        if (!this.cooldown) {
          this.cooldown = true;
          const by = feet === 209 ? Math.floor(p.y + 0.2) : Math.floor(p.y + 1);
          this.enterGateway(Math.floor(p.x), by, Math.floor(p.z));
        }
        return;
      }
      if (feet === 90 || body === 90) {
        if (this.cooldown) return;
        this.portalT += dt;
        if (g.particles.swirl && Math.random() < 0.5) g.particles.swirl(p.x + (Math.random() - 0.5), p.y + Math.random() * 2, p.z + (Math.random() - 0.5), [0.5, 0.2, 0.8], 0.05, 0.4);
        // В выживании нужно постоять 4 секунды, в творческом — мгновенно
        if (this.portalT >= (g.gamemode === 1 ? 0.3 : 4)) {
          this.portalT = 0;
          this.cooldown = true;
          this.travel(g.dimension === 1 ? 0 : 1);
        }
        return;
      }
      this.portalT = 0;
      this.cooldown = false;
    }

    async travel(target) {
      const g = this.game, p = g.player;
      const from = g.dimension || 0;
      let x = p.x, y = p.y, z = p.z;
      if (from === 0 && target === 1) { x = p.x / 8; z = p.z / 8; y = Math.max(34, Math.min(110, p.y)); }
      else if (from === 1 && target === 0) { x = p.x * 8; z = p.z * 8; }
      else if (target === 2) { x = 100.5; y = 49; z = 0.5; }
      g.ui.setPopup('§7Перемещение: ' + DIM_NAMES[target] + '…');
      if (target === 0 && from === 2) {
        await g.switchDimension(0, null);
        // Первый выход из Края после победы — финальные титры, как в Minecraft
        if (g.record.dragonKilled && !g.record.creditsSeen) { g.record.creditsSeen = true; g.ui.showCredits(g); }
        return;
      }
      await g.switchDimension(target, { x, y, z });
      if (target === 2) {
        // Обсидиановая площадка 5×5 и воздух над ней, как при входе в Край
        const w = this.world;
        for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) {
          w.setBlock(100 + dx, 48, dz, 49, 0);
          for (let dy = 1; dy <= 3; dy++) w.setBlock(100 + dx, 48 + dy, dz, 0, 0);
        }
        p.x = 100.5; p.y = 49; p.z = 0.5;
        this.spawnDragon();
        return;
      }
      const found = this.findPortal(Math.floor(x), Math.floor(z), target === 1 ? 16 : 64);
      if (found) { p.x = found.x + 0.5; p.y = found.y; p.z = found.z + 0.5; return; }
      const made = this.buildPortal(Math.floor(x), Math.floor(y), Math.floor(z), target);
      p.x = made.x + 0.5; p.y = made.y; p.z = made.z + 0.5;
    }

    // ---------- Врата Края ----------
    gatewayPos(i) {
      // 20 врат по кругу в порядке, как у генератора Minecraft (случайный, но постоянный для мира)
      const order = [];
      for (let k = 0; k < 20; k++) order.push(k);
      const seed = this.game.record.seed | 0;
      for (let k = 19; k > 0; k--) { const j = Math.floor(MC.hash3(seed + 501, k, 0, 0) * (k + 1)); const t = order[k]; order[k] = order[j]; order[j] = t; }
      const a = order[i % 20] * Math.PI * 2 / 20;
      return { x: Math.floor(Math.cos(a) * GATEWAY_R), y: GATEWAY_Y, z: Math.floor(Math.sin(a) * GATEWAY_R) };
    }

    // Врата и их рамка из бедрока (сверху и снизу); ставятся в загруженный чанк
    placeGate(x, y, z) {
      const w = this.world;
      if (!w.isLoaded(x, z)) return false;
      if (w.getId(x, y, z) !== 209) {
        w.setBlock(x, y, z, 209, 0);
        w.setBlock(x, y - 1, z, 7, 0);
        w.setBlock(x, y + 1, z, 7, 0);
        for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { w.setBlock(x + dx, y - 2, z + dz, 7, 0); w.setBlock(x + dx, y + 2, z + dz, 7, 0); }
      }
      return true;
    }

    placeGateways(cx, cz) {
      const rec = this.game.record;
      const list = (rec.gateways || []).concat(Object.values(rec.gatewayExits || {}));
      for (const gw of list) if ((gw.x >> 4) === cx && (gw.z >> 4) === cz) this.placeGate(gw.x, gw.y, gw.z);
    }

    spawnGateway() {
      const rec = this.game.record;
      if (!rec.gateways) rec.gateways = [];
      if (rec.gateways.length >= 20) return;
      const pos = this.gatewayPos(rec.gateways.length);
      rec.gateways.push(pos);
      this.placeGate(pos.x, pos.y, pos.z);
    }

    async enterGateway(x, y, z) {
      const g = this.game, p = g.player, rec = g.record;
      if (!rec.gatewayExits) rec.gatewayExits = {};
      const gen = g.generators[2];
      g.ui.setPopup('§5Врата Края…');
      if (Math.hypot(x, z) < OUTER_R / 2) {
        // Из центра — к внешним островам; выходные врата ставятся на острове
        const key = x + ',' + z;
        let exit = rec.gatewayExits[key];
        if (!exit) {
          const land = gen.outerLanding(x, z);
          exit = { x: land.x, y: Math.max(land.y + 2, 40), z: land.z, from: key, island: land.y > 0 };
          rec.gatewayExits[key] = exit;
        }
        await g.switchDimension(2, { x: exit.x + 2.5, y: exit.y, z: exit.z + 0.5 });
        if (!exit.island) {
          // Острова рядом нет: небольшая площадка из камня Края
          for (let dx = -3; dx <= 3; dx++) for (let dz = -3; dz <= 3; dz++) this.world.setBlock(exit.x + dx, exit.y - 3, exit.z + dz, 121, 0);
        }
        this.placeGate(exit.x, exit.y, exit.z);
        p.x = exit.x + 2.5; p.z = exit.z + 0.5;
        p.y = exit.island ? exit.y - 1 : exit.y - 2;
        while (p.y < 250 && this.world.getId(Math.floor(p.x), Math.floor(p.y), Math.floor(p.z))) p.y++;
        return;
      }
      // С внешних островов — обратно на центральный остров
      await g.switchDimension(2, gen.findSpawn());
      const s = gen.findSpawn();
      for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) {
        this.world.setBlock(Math.floor(s.x) + dx, 48, Math.floor(s.z) + dz, 49, 0);
        for (let dy = 1; dy <= 3; dy++) this.world.setBlock(Math.floor(s.x) + dx, 48 + dy, Math.floor(s.z) + dz, 0, 0);
      }
      p.x = s.x; p.y = s.y; p.z = s.z;
      this.spawnDragon();
    }

    // ---------- Кристаллы Края ----------
    // Живые кристаллы на столбах (пока дракон жив) и поставленные игроком — сущности из записи мира
    restoreCrystals() {
      const g = this.game, rec = g.record, ents = g.ents;
      if (!ents) return;
      const have = new Set();
      for (const c of ents.list.values()) if (c.kind === 'crystal') have.add(c.placed ? 'p' + c.x + ',' + c.y + ',' + c.z : 'i' + c.idx);
      if (g.dimension === 2 && !rec.dragonKilled) {
        if (!Array.isArray(rec.endCrystals)) rec.endCrystals = new Array(10).fill(true);
        for (const pl of g.generators[2].pillars()) {
          if (!rec.endCrystals[pl.i] || have.has('i' + pl.i)) continue;
          ents.spawnCrystal(pl.x + 0.5, pl.h + 2, pl.z + 0.5, { idx: pl.i });
        }
      }
      for (const c of rec.placedCrystals || []) {
        if (c.d !== (g.dimension || 0) || have.has('p' + c.x + ',' + c.y + ',' + c.z)) continue;
        ents.spawnCrystal(c.x, c.y, c.z, { placed: true });
      }
    }

    crystalDestroyed(c) {
      const rec = this.game.record;
      if (c.idx !== undefined && Array.isArray(rec.endCrystals)) rec.endCrystals[c.idx] = false;
      if (c.placed && rec.placedCrystals) {
        const d = this.game.dimension || 0;
        rec.placedCrystals = rec.placedCrystals.filter((q) => !(q.d === d && q.x === c.x && q.y === c.y && q.z === c.z));
      }
    }

    // Кристалл Края из инвентаря: только на обсидиан или бедрок с воздухом сверху
    placeCrystal(hit) {
      const g = this.game, w = this.world;
      if (!hit || (hit.id !== 49 && hit.id !== 7)) return false;
      if (w.getId(hit.x, hit.y + 1, hit.z) || w.getId(hit.x, hit.y + 2, hit.z)) return false;
      const rec = g.record;
      if (!rec.placedCrystals) rec.placedCrystals = [];
      const c = { d: g.dimension || 0, x: hit.x + 0.5, y: hit.y + 1, z: hit.z + 0.5 };
      if (g.ents.crystalAt(c.x, c.y + 1, c.z, 0.2)) return false;
      rec.placedCrystals.push(c);
      g.ents.spawnCrystal(c.x, c.y, c.z, { placed: true });
      this.checkRespawn();
      return true;
    }

    // Возрождение дракона: четыре кристалла по сторонам портала выхода (на бедроке), как в Minecraft
    checkRespawn() {
      const g = this.game, rec = g.record;
      if (g.dimension !== 2 || !rec.dragonKilled) return;
      const spots = [[3.5, 0.5], [-2.5, 0.5], [0.5, 3.5], [0.5, -2.5]];
      const found = [];
      for (const [x, z] of spots) {
        const c = Array.from(g.ents.list.values()).find((e) => e.kind === 'crystal' && e.placed && Math.abs(e.x - x) < 1.1 && Math.abs(e.z - z) < 1.1 && Math.abs(e.y - 62) < 1.1);
        if (!c) return;
        found.push(c);
      }
      for (const c of found) { g.ents.list.delete(c.eid); this.crystalDestroyed(c); }
      rec.dragonKilled = false;
      rec.endCrystals = new Array(10).fill(true);
      const w = this.world;
      for (let x = -3; x <= 3; x++) for (let z = -3; z <= 3; z++) if (w.getId(x, 61, z) === 119) w.setBlock(x, 61, z, 0, 0);
      g.ui.setPopup('§5Дракон Края возрождается!');
      MC.Sound.play('mob.enderdragon.growl', null, 1, 1);
      this.spawnDragon();
    }

    // Ближайший портал в загруженных чанках вокруг точки (самый нижний блок портала)
    findPortal(x, z, r) {
      const w = this.world;
      let best = null, bd = Infinity;
      for (let px = x - r; px <= x + r; px++) for (let pz = z - r; pz <= z + r; pz++) {
        if (!w.isLoaded(px, pz)) continue;
        for (let py = 1; py < 255; py++) {
          if (w.getId(px, py, pz) !== 90 || w.getId(px, py - 1, pz) === 90) continue;
          const d = (px - x) ** 2 + (pz - z) ** 2;
          if (d < bd) { bd = d; best = { x: px, y: py, z: pz }; }
        }
      }
      return best;
    }

    // Новый портал 4×5 (проём 2×3) на подходящем месте; если места нет — с обсидиановой площадкой
    buildPortal(x, y, z, dim) {
      const w = this.world;
      const lo = dim === 1 ? 32 : 4, hi = dim === 1 ? 118 : 250;
      let spot = null;
      for (let r = 0; r <= 12 && !spot; r += 2) {
        for (let dx = -r; dx <= r && !spot; dx += 2) for (let dz = -r; dz <= r && !spot; dz += 2) {
          for (let dy = 0; dy <= 60 && !spot; dy++) for (const yy of [y - dy, y + dy]) {
            if (yy < lo || yy > hi) continue;
            const bx = x + dx, bz = z + dz;
            let ok = true;
            for (let i = -1; i <= 2 && ok; i++) {
              if (!Blocks.list[w.getId(bx + i, yy - 1, bz)].opaque) ok = false;
              for (let j = 0; j < 4 && ok; j++) if (w.getId(bx + i, yy + j, bz) !== 0) ok = false;
            }
            if (ok) { spot = { x: bx, y: yy, z: bz }; break; }
          }
        }
      }
      if (!spot) {
        const yy = Math.max(lo, Math.min(hi - 5, dim === 1 ? 70 : y));
        spot = { x, y: yy, z };
        for (let i = -1; i <= 2; i++) for (let k = -1; k <= 1; k++) {
          w.setBlock(x + i, yy - 1, z + k, 49, 0);
          for (let j = 0; j < 4; j++) w.setBlock(x + i, yy + j, z + k, 0, 0);
        }
      }
      const { x: sx, y: sy, z: sz } = spot;
      for (let i = -1; i <= 2; i++) for (let j = -1; j <= 3; j++) {
        const edge = i === -1 || i === 2 || j === -1 || j === 3;
        w.setBlock(sx + i, sy + j, sz, edge ? 49 : 90, edge ? 0 : 1);
      }
      return spot;
    }

    // ---------- Дракон Края ----------
    spawnDragon() {
      const g = this.game;
      this.restoreCrystals();
      if (g.dimension !== 2 || g.record.dragonKilled) return;
      for (const e of g.ents.list.values()) if (e.kind === 'mob' && e.type === 53) return;
      const m = g.ents.spawnMob(53, 0, 80, 40);
      if (m) { m.egg = true; this.dragonHurt(m); }
    }

    dragonHurt(m) {
      const g = this.game;
      const hp = Math.max(0, Math.ceil(m.hp)), max = m.def.hp;
      if (!this.bar || !this.bar.isConnected) {
        this.bar = document.createElement('div');
        this.bar.className = 'bossbar';
        this.bar.innerHTML = '<div class="bossbar-name">Дракон Края</div><div class="bossbar-track"><div class="bossbar-fill"></div></div>';
        g.ui.hud.appendChild(this.bar);
      }
      this.bar.querySelector('.bossbar-fill').style.width = (hp / max * 100).toFixed(1) + '%';
      this.bar.style.display = hp > 0 ? '' : 'none';
    }

    hideBar() { if (this.bar) this.bar.style.display = 'none'; }

    // Портал выхода в чаше из бедрока и яйцо дракона на центральном столбе (яйцо — один раз)
    openExit() {
      const g = this.game, w = this.world;
      if (!w.isLoaded(0, 0)) return;
      for (let x = -2; x <= 2; x++) for (let z = -2; z <= 2; z++) if (Math.hypot(x, z) <= 2.5 && w.getId(x, 61, z) === 0) w.setBlock(x, 61, z, 119, 0);
      if (!g.record.eggPlaced) { w.setBlock(0, 65, 0, 122, 0); g.record.eggPlaced = true; }
    }

    // Победа: портал выхода, яйцо дракона (один раз), врата Края, опыт (за первого дракона 12000, потом 500)
    dragonKilled() {
      const g = this.game, rec = g.record;
      const first = !rec.dragonKills;
      rec.dragonKills = (rec.dragonKills || 0) + 1;
      rec.dragonKilled = true;
      rec.endCrystals = new Array(10).fill(false);
      for (const c of Array.from(g.ents.list.values())) if (c.kind === 'crystal' && !c.placed) g.ents.list.delete(c.eid);
      this.hideBar();
      this.openExit();
      this.spawnGateway();
      g.addXp(first ? 12000 : 500);
      g.ui.setPopup(first ? '§dДракон Края повержен! Портал выхода открыт, появились врата Края' : '§dДракон Края снова повержен!');
      MC.Sound.play('random.levelup', null, 1, 0.8);
    }
  }

  MC.Dimensions = { strongholds, nearestStronghold, carveStronghold, NetherGenerator, EndGenerator, Portals, NAMES: DIM_NAMES, LOOT, fillLoot };
})();
