// Игровая сессия: одиночный мир (выживание или творческий режим, сохранение в IndexedDB) или сервер MCPE 1.1.x
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const Blocks = MC.Blocks;
  const ACT = MC.PLAYER_ACTION;
  const CHEST_DIRS = [[-1, 0], [1, 0], [0, -1], [0, 1]];
  // Массив из двух половин: индексы 0-26 — первая, 27-53 — вторая
  function pairView(a, b) {
    return new Proxy([], {
      get(t, k) {
        if (k === 'length') return 54;
        if (typeof k === 'string' && /^\d+$/.test(k)) { const i = +k; return i < 27 ? a[i] : b[i - 27]; }
        return Reflect.get(t, k);
      },
      set(t, k, v) {
        if (typeof k === 'string' && /^\d+$/.test(k)) { const i = +k; if (i < 27) a[i] = v; else b[i - 27] = v; return true; }
        return Reflect.set(t, k, v);
      }
    });
  }
  // Окна сервера MCPE 1.1: число ячеек по умолчанию (уточняется пакетом содержимого) и названия
  const WINDOW_SIZE = { 0: 27, 2: 3, 3: 2, 4: 5, 5: 3, 6: 9, 7: 9, 8: 5, 10: 27, 11: 5 };
  const WINDOW_TITLE = { 0: 'Сундук', 2: 'Печь', 3: 'Стол зачарований', 4: 'Варочная стойка', 5: 'Наковальня', 6: 'Раздатчик', 7: 'Выбрасыватель', 8: 'Воронка', 10: 'Вагонетка с сундуком', 11: 'Вагонетка с воронкой' };
  MC.WINDOW_TITLE = WINDOW_TITLE;
  // Измерения: 0 — обычный мир, 1 — Нижний мир (Ад), 2 — Край; приставки ключей чанков и контейнеров
  const DIM_KEY = { 1: 'n', 2: 'e' };
  const DIM_FROM_KEY = { n: 1, e: 2 };
  const EYE = MC.PLAYER_EYE;
  const ORE_XP = { 16: [0, 2], 56: [3, 7], 129: [3, 7], 21: [2, 5], 73: [1, 5], 74: [1, 5], 153: [2, 5] };

  // Блоки, по которым клик открывает интерфейс или меняет состояние: их обрабатывает сервер
  const INTERACTIVE = new Set([23, 25, 26, 54, 58, 61, 62, 64, 69, 71, 77, 84, 92, 93, 94, 96, 107, 116, 117, 118, 125, 130, 138, 143, 145, 146,
    137, 149, 150, 151, 154, 167, 178, 183, 184, 185, 186, 187, 188, 189, 193, 194, 195, 196, 197, 205, 218]);
  const DOORS = new Set([64, 193, 194, 195, 196, 197]);
  const GATES = new Set([107, 183, 184, 185, 186, 187]);
  const FACE_DIR = [[0, -1, 0], [0, 1, 0], [0, 0, -1], [0, 0, 1], [-1, 0, 0], [1, 0, 0]];

  function daylightAt(time) {
    const f = (((time % 24000) + 24000) % 24000) / 24000;
    let a = f - 0.25;
    if (a < 0) a += 1;
    const dark = Math.max(0, Math.min(1, 1 - (Math.cos(a * Math.PI * 2) * 2 + 0.5)));
    return 0.2 + 0.8 * (1 - dark);
  }

  // Направление взгляда по горизонтали: 0 юг (+z), 1 запад (-x), 2 север (-z), 3 восток (+x)
  function yawDir(yaw) { return Math.floor((((yaw % 360) + 360) % 360) / 90 + 0.5) & 3; }

  class Game {
    constructor(app, mode, opts) {
      this.app = app;
      this.mode = mode;
      this.opts = opts;
      this.world = new MC.World();
      this.player = new MC.Player(this.world);
      this.dirty = new Set();
      this.world.onSectionDirty((cx, sy, cz) => this.dirty.add(cx + ',' + sy + ',' + cz));
      this.time = 6000;
      this.selected = 0;
      this.gamemode = 1;
      this.health = 20;
      this.food = 20;
      this.dead = false;
      this.ready = false;
      this.stopped = false;
      this.immutable = false;
      this.entities = new Map();
      this.playerInfo = new Map();
      this.inv = [];
      this.hotbarMap = [0, 1, 2, 3, 4, 5, 6, 7, 8];
      this.creativeItems = null;
      this.blockEntities = new Map();
      this.pendingContent = new Map();
      this.breaking = null;
      this.useCooldown = 0;
      this.attackCooldown = 0;
      this.lastMoveSent = 0;
      this.lastSent = null;
      this.lastJumpTap = 0;
      this.flyShown = null;
      this.lastItemKey = '';
      this.fps = 0;
      this.frames = 0;
      this.fpsTime = 0;
      this.serverRadius = app.settings.renderDistance;
      this.loading = new Set();
      this.lastSave = performance.now();
      // Одиночная игра: инвентарь, существа и состояние выживания
      this.sinv = new MC.Survival.Inventory();
      this.ents = null;
      this.invuln = 0;
      this.exhaustion = 0;
      this.saturation = 5;
      this.air = 15;
      this.lavaT = 0;
      this.regenT = 0;
      this.fx = { absorb: 0 };
      // Эффекты зелий (и в одиночной игре, и от сервера): скорость, прыгучесть, ночное зрение и другие
      this.effects = new MC.Effects.EffectSet();
      this.tickTimer = 0;
      this.hitCooldown = 0;
      this.eating = null;
      this.armor = [null, null, null, null];
      this.invScreen = null;
      this.particles = new MC.Particles(this);
      this.applyParticleSetting();
      // Сетевая игра: рецепты сервера и открытые им окна (сундук, печь)
      this.recipes = [];
      this.windows = new Map();
    }

    get renderer() { return this.app.renderer; }
    get ui() { return this.app.ui; }
    get input() { return this.app.input; }

    // ---------- Запуск ----------
    async start() {
      if (this.mode === 'sp') return this.startSingle();
      return this.startMulti();
    }

    async startSingle() {
      const w = this.opts.world;
      this.record = w;
      // Генераторы трёх измерений; игрок сохраняется в том измерении, где вышел
      this.generators = { 0: w.gen === 2 ? new MC.Generator(w.seed, w) : new MC.LegacyGenerator(w.seed), 1: new MC.Dimensions.NetherGenerator(w.seed, w), 2: new MC.Dimensions.EndGenerator(w.seed, w) };
      this.dimension = w.dimension === 1 || w.dimension === 2 ? w.dimension : 0;
      this.generator = this.generators[this.dimension];
      this.dimGen = 0;
      this.ents = new MC.Entities(this);
      this.portals = new MC.Dimensions.Portals(this);
      // Механика одиночной игры: поршни, редстоун, падающие блоки — реагирует на изменения блоков
      this.mechanics = new MC.Mechanics(this);
      this.building = new MC.Building(this);
      this.schematic = new MC.Schematics.View(this);
      this.pvp = new MC.PvP(this);
      await this.pvp.loadWaypoints();
      this.world.onBlockSet((x, y, z) => this.mechanics.mark(x, y, z));
      // Миры, созданные до появления выживания, остаются творческими
      this.gamemode = typeof w.gamemode === 'number' ? w.gamemode : 1;
      this.player.canFly = this.gamemode === 1;
      this.time = typeof w.time === 'number' ? w.time : 6000;
      this.health = typeof w.health === 'number' ? w.health : 20;
      this.food = typeof w.food === 'number' ? w.food : 20;
      this.saturation = typeof w.saturation === 'number' ? w.saturation : 5;
      this.setXpTotal(typeof w.xp === 'number' ? w.xp : 0);
      this.effects = new MC.Effects.EffectSet(w.effects);
      this.fx.absorb = typeof w.absorb === 'number' && this.effects.has(MC.Effects.E.ABSORPTION) ? w.absorb : 0;
      this.armor = [0, 1, 2, 3].map((i) => (w.armor && w.armor[i] && w.armor[i].id ? { id: w.armor[i].id, data: w.armor[i].data || 0, count: 1 } : null));
      const p = w.player || this.generator.findSpawn();
      this.player.x = p.x; this.player.y = p.y; this.player.z = p.z;
      this.player.yaw = p.yaw || 0; this.player.pitch = p.pitch || 0;
      this.player.flying = this.gamemode === 1 && !!p.flying;
      if (w.inventory) this.sinv = new MC.Survival.Inventory(w.inventory);
      else if (w.hotbar) this.sinv = new MC.Survival.Inventory(w.hotbar);
      else if (this.gamemode === 1) this.sinv = new MC.Survival.Inventory([[1, 0], [3, 0], [2, 0], [4, 0], [5, 0], [17, 0], [20, 0], [50, 0], [89, 0]].map(([id, data]) => ({ id, data, count: 64 })));
      // Чанк под игроком загружается до входа, чтобы не провалиться
      await this.loadChunkSP(Math.floor(this.player.x) >> 4, Math.floor(this.player.z) >> 4);
      if (this.dimension === 2) this.portals.spawnDragon();
      else this.portals.restoreCrystals();
      this.ready = true;
    }

    // Ключ хранилища чанков текущего измерения: у Нижнего мира и Края — свой
    get storeId() { return this.record.id + (this.dimension ? ':' + DIM_KEY[this.dimension] : ''); }

    // Переход в другое измерение: сохранить чанки, очистить мир, загрузить чанки вокруг новой точки.
    // pos = null — точка возрождения обычного мира
    async switchDimension(dim, pos) {
      const p = this.player;
      this.traveling = true;
      try {
        await this.save();
        this.dimGen++;
        this.loading.clear();
        for (const c of Array.from(this.world.chunks.values())) this.world.removeChunk(c.cx, c.cz);
        this.renderer.clearSections();
        this.dirty.clear();
        this.ents.clear();
        this.mechanics.reset();
        this.portals.hideBar();
        if (this.pvp) this.pvp.resetMap();
        this.breaking = null;
        this.dimension = dim;
        this.record.dimension = dim;
        this.generator = this.generators[dim];
        const s = pos || this.spawnPoint();
        p.x = s.x; p.y = s.y; p.z = s.z;
        p.vx = p.vy = p.vz = 0;
        p.fallStart = null;
        const pcx = Math.floor(p.x) >> 4, pcz = Math.floor(p.z) >> 4;
        const jobs = [];
        for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) jobs.push(this.loadChunkSP(pcx + dx, pcz + dz));
        await Promise.all(jobs);
        if (!pos) { const s2 = this.spawnPoint(); p.x = s2.x; p.y = s2.y; p.z = s2.z; }
        this.portals.restoreCrystals();
        this.ui.setPopup(MC.Dimensions.NAMES[dim]);
      } finally {
        this.traveling = false;
      }
    }

    startMulti() {
      const st = this.app.settings;
      const srv = this.opts.server;
      return new Promise((resolve, reject) => {
        this.onReady = resolve;
        this.onFail = reject;
        const skin = st.skin ? MC.Skin.fromBase64(st.skin) : MC.Skin.defaultSkin();
        this.client = new MC.McpeClient({
          relayUrl: MC.Storage.relayUrl(st),
          host: srv.host,
          port: srv.port,
          username: st.nickname,
          uuid: st.uuid,
          skin,
          chunkRadius: st.renderDistance,
          touch: this.input.touchMode,
          device: MC.Storage.deviceInfo(st, srv, this.input.touchMode)
        }, this.handlers());
        this.client.connect().catch((e) => this.disconnected(e.message));
      });
    }

    // ---------- Сетевые события ----------
    handlers() {
      const g = this;
      return {
        onStatus(text) { if (!g.ready) g.app.connectStatus(text); },
        onSpawn() {
          g.spawned = true;
          g.app.connectStatus('Загрузка чанков...');
          g.checkReady();
          // Если сервер не прислал чанк под игроком, всё равно входим в игру
          setTimeout(() => g.becomeReady(), 5000);
        },
        onDisconnect(reason) { g.disconnected(reason); },
        onStartGame(s) {
          g.eid = s.eid;
          g.gamemode = s.gamemode;
          g.player.x = s.pos.x; g.player.y = s.pos.y; g.player.z = s.pos.z;
          g.player.yaw = s.yaw; g.player.pitch = s.pitch;
          g.player.canFly = s.gamemode === 1;
          g.respawnPos = { x: s.spawn.x + 0.5, y: s.spawn.y, z: s.spawn.z + 0.5 };
          // Вход сразу в Нижний мир или Край (игрок вышел там): туман и свет измерения
          g.dimension = s.dimension === 1 || s.dimension === 2 ? s.dimension : 0;
        },
        onText(t) { g.text(t); },
        onTime(t) { g.time = t; },
        onAddPlayer(p) {
          const info = g.playerInfo.get(p.uuid);
          g.entities.set(p.eid, {
            kind: 'player', eid: p.eid, uuid: p.uuid, name: p.name,
            // AddPlayer передаёт позицию ног (Nukkit и PocketMine), а MovePlayer — глаз. Неподвижные NPC иначе уходили под землю
            x: p.pos.x, y: p.pos.y, z: p.pos.z, tx: p.pos.x, ty: p.pos.y, tz: p.pos.z,
            yaw: p.yaw, pitch: p.pitch, walk: 0, walkAmount: 0, swingTime: 0, hurt: 0,
            skinKey: 'p:' + p.uuid, skin: info ? info.skin : null, armor: [null, null, null, null],
            held: p.item && p.item.id ? p.item : null, invisible: !!p.meta.invisible, sneaking: !!p.meta.sneaking,
            alwaysTag: !!p.meta.alwaysTag, scale: p.meta.scale > 0 ? p.meta.scale : 1,
            nametag: p.meta.nametag !== undefined ? p.meta.nametag : p.name
          });
        },
        onMobEquipment(eid, item) {
          const e = g.entities.get(eid);
          if (e) e.held = item && item.id ? item : null;
        },
        // Флаги и надписи сущностей меняются на лету: невидимость, присед, ник (на серверах в нём часто здоровье или ранг)
        onEntityData(eid, m) {
          const e = g.entities.get(eid);
          if (!e) return;
          if (m.invisible !== undefined) e.invisible = m.invisible;
          if (m.sneaking !== undefined) e.sneaking = m.sneaking;
          if (m.usingItem !== undefined) { e.usingItem = m.usingItem; e.usingBow = m.usingItem && !!e.held && e.held.id === 261; e.eating = m.usingItem && !!e.held && e.held.id !== 261; }
          if (m.gliding !== undefined) e.gliding = m.gliding;
          if (m.alwaysTag !== undefined) e.alwaysTag = m.alwaysTag;
          if (m.nametag !== undefined) e.nametag = m.nametag;
          if (m.scale !== undefined) e.scale = m.scale;
          if (m.variant !== undefined) e.variant = m.variant;
          if (m.fuse !== undefined) { e.fuse = m.fuse; e.fuseT = performance.now(); }
        },
        onExplode(pos, radius) {
          MC.Sound.event('explode', pos.x, pos.y, pos.z);
          g.particles.explosion(pos.x, pos.y, pos.z, radius || 4);
        },
        // Лобби → игра: сервер меняет мир; убираем старые чанки и сущности, ждём новые
        onChangeDimension(dim, pos) {
          g.entities.clear();
          g.particles.clear();
          for (const c of Array.from(g.world.chunks.values())) { g.world.removeChunk(c.cx, c.cz); g.removeChunkMeshes(c.cx, c.cz); }
          g.dirty.clear();
          g.player.x = pos.x; g.player.y = pos.y - EYE; g.player.z = pos.z;
          g.player.vx = g.player.vy = g.player.vz = 0;
          g.player.fallStart = null;
          g.lastSent = null;
          g.dimension = dim;
          if (g.pvp) g.pvp.resetMap();
          if (g.building) g.building.clearNet();
          if (g.schematic && g.schematic.s) g.schematic.rebuild();
        },
        onMobArmor(eid, items) {
          const e = g.entities.get(eid);
          if (e) e.armor = items.map((it) => (it && it.id ? it : null));
        },
        onAddEntity(e) {
          // Кристалл Края, око Края и огненный шар дракона с сервера: размеры для рисования и прицела
          if (MC.ENTITY_LOOK && !MC.ENTITY_LOOK[e.type] && (e.type === 70 || e.type === 71 || e.type === 79)) {
            MC.ENTITY_LOOK[e.type] = e.type === 71 ? ['Кристалл Края', [0.85, 0.55, 0.95], [2, 2, 2]] : e.type === 70 ? ['Око Края', [0.3, 0.7, 0.5], [0.25, 0.25, 0.25]] : ['Огненный шар дракона', [0.6, 0.2, 0.7], [1, 1, 1]];
          }
          const m = e.meta || {};
          g.entities.set(e.eid, { kind: 'mob', eid: e.eid, type: e.type, x: e.pos.x, y: e.pos.y, z: e.pos.z, tx: e.pos.x, ty: e.pos.y, tz: e.pos.z, yaw: e.yaw, pitch: e.pitch, hurt: 0,
            invisible: !!m.invisible, nametag: m.nametag || '', alwaysTag: !!m.alwaysTag, scale: m.scale || 1, variant: m.variant || 0, held: null,
            fuse: m.fuse, fuseT: m.fuse !== undefined ? performance.now() : 0 });
        },
        onAddItemEntity(e) {
          g.entities.set(e.eid, { kind: 'item', eid: e.eid, item: e.item, x: e.pos.x, y: e.pos.y, z: e.pos.z, tx: e.pos.x, ty: e.pos.y, tz: e.pos.z });
        },
        onRemoveEntity(eid) {
          const e = g.entities.get(eid);
          if (e && e.kind === 'player') g.renderer.dropSkin(e.skinKey);
          g.entities.delete(eid);
        },
        onMoveEntity(m) {
          const e = g.entities.get(m.eid);
          if (!e) return;
          e.tx = m.pos.x;
          e.ty = e.kind === 'player' ? m.pos.y - EYE : m.pos.y;
          e.tz = m.pos.z;
          e.yaw = e.kind === 'player' ? m.headYaw : m.yaw;
          e.pitch = m.pitch;
        },
        onTeleport(m) {
          g.player.x = m.pos.x; g.player.y = m.pos.y - EYE; g.player.z = m.pos.z;
          g.player.vx = g.player.vy = g.player.vz = 0;
          g.player.yaw = m.yaw; g.player.pitch = m.pitch;
          g.player.fallStart = null;
          g.lastSent = null;
        },
        onBlock(x, y, z, id, data) {
          g.world.setBlock(x, y, z, id, data);
          if (g.building) g.building.netConfirm(x, y, z, id);
          if (g.breaking && g.breaking.x === x && g.breaking.y === y && g.breaking.z === z) g.breaking = null;
        },
        onEntityEvent(eid, ev) {
          if (g.pvp) g.pvp.onEntityEvent(eid, ev);
          if (ev === 2 && eid === g.eid) { if (g.pvp) g.pvp.onHurt(); g.ui.flashHurt(); MC.Sound.play('game.player.hurt', null, 1, 0.8 + Math.random() * 0.4); return; }
          if (ev === 3 && eid === g.eid) { if (g.pvp) g.pvp.onDeath(); MC.Sound.play('game.player.die', null, 1, 1); return; }
          // 65 — сработал тотем бессмертия
          if (ev === 65) {
            if (eid === g.eid) { g.ui.totemPop(); MC.Sound.play('random.levelup', null, 1, 1.2); return; }
            const t = g.entities.get(eid);
            if (t) MC.Sound.play('random.levelup', { x: t.x, y: t.y + 1, z: t.z }, 1, 1.2);
            return;
          }
          const e = g.entities.get(eid);
          if (ev === 2 && e) e.hurt = 0.35;
          // Смерть другого игрока или существа: модель заваливается на бок
          if (ev === 3 && e) { e.deathT = performance.now(); e.hurt = 0.5; }
          // Другой игрок доел (сервер рассылает USE_ITEM зрителям): крошки его еды у головы
          if (ev === 9 && e && e.kind === 'player' && e.held && e.held.id) {
            const yr = (e.yaw || 0) * Math.PI / 180;
            g.particles.eat(e.held, e.x, e.y + 1.62, e.z, [-Math.sin(yr), 0, Math.cos(yr)]);
          }
          if (ev === 7 && e) g.particles.hearts(e.x, e.y, e.z);
          if ((ev === 2 || ev === 3) && e && e.kind !== 'item') MC.Sound.entity(e.kind === 'player' ? 'player' : e.type, ev === 2 ? 'hurt' : 'death', e.x, e.y + 1, e.z);
        },
        onTakeItem(item, picker) {
          if (picker === g.eid) MC.Sound.event('pop');
          this.onRemoveEntity(item);
        },
        // Эффекты от сервера: скорость, прыгучесть и ночное зрение применяются и в движении клиента
        onMobEffect(m) {
          if (m.eid !== g.eid) return;
          if (m.ev === 3) g.effects.remove(m.id);
          else { g.effects.remove(m.id); g.effects.add(m.id, m.amp, m.dur / 20); }
          if (g.pvp) g.pvp.onMobEffect(m);
        },
        onLevelSound(s) { MC.Sound.network(s.sound, s.x, s.y, s.z, s.extra); },
        onLevelEvent(ev) {
          if (ev.id === 2001) {
            // Частицы разрушения блока: звук ломания (свой блок уже озвучен локально)
            const o = g.lastOwnBreak;
            if (o && performance.now() - o.t < 1500 && Math.floor(ev.x) === o.x && Math.floor(ev.y) === o.y && Math.floor(ev.z) === o.z) return;
            MC.Sound.block(ev.data & 0xff, 'break', ev.x, ev.y, ev.z);
            g.particles.blockBreak(Math.floor(ev.x), Math.floor(ev.y), Math.floor(ev.z), ev.data & 0xff, (ev.data >> 8) & 0xf);
          } else if (ev.id === 1003) MC.Sound.play(Math.random() < 0.5 ? 'random.door_open' : 'random.door_close', ev, 1, 1);
          else if (ev.id === 1000 || ev.id === 3500) MC.Sound.play('random.click', ev, 0.6, 1);
          else if (ev.id === 1005) MC.Sound.play('random.fuse', ev, 1, 1);
          else if (ev.id === 1004) MC.Sound.event('fizz', ev.x, ev.y, ev.z);
          else if (ev.id === 1051) MC.Sound.play('random.orb', ev, 0.3, 1);
        },
        onAttributes(a) {
          if (a['minecraft:health']) g.setHealth(a['minecraft:health'].value);
          if (a['minecraft:player.hunger']) g.food = a['minecraft:player.hunger'].value;
          if (a['minecraft:player.saturation']) g.saturation = a['minecraft:player.saturation'].value;
          // Опыт: уровень и заполнение полосы (0..1) присылает сервер
          if (a['minecraft:player.level']) {
            const lv = Math.round(a['minecraft:player.level'].value);
            if (g.xpLevel !== undefined && lv > g.xpLevel && lv % 5 === 0) MC.Sound.play('random.levelup', null, 0.75, 1);
            g.xpLevel = lv;
          }
          if (a['minecraft:player.experience']) g.xpProgress = Math.max(0, Math.min(1, a['minecraft:player.experience'].value));
        },
        onMotion(m) {
          g.player.vx = m.x * 20; g.player.vy = m.y * 20; g.player.vz = m.z * 20;
        },
        onHealth(h) { g.setHealth(h); },
        onSpawnPosition(p) { g.respawnPos = { x: p.x + 0.5, y: p.y, z: p.z + 0.5 }; },
        onSwing(eid) {
          const e = g.entities.get(eid);
          if (e) e.swingTime = 1;
        },
        onRespawn(pos) { g.respawnPos = { x: pos.x, y: pos.y, z: pos.z }; },
        onSlot(windowId, slot, hotbarSlot, item) {
          const it = item && item.id ? item : null;
          if (windowId === 0) g.inv[slot] = it;
          else if (windowId === 0x78) { if (slot < 4) g.armor[slot] = it; }
          else if (g.windows.has(windowId)) g.windows.get(windowId).slots[slot] = it;
          if (g.invScreen) g.invScreen.onServerUpdate();
        },
        onContent(windowId, slots, hotbar) {
          const items = slots.map((it) => (it && it.id ? it : null));
          if (windowId === 0) {
            g.inv = items;
            if (hotbar.length) {
              const map = hotbar.slice(0, 9).map((h) => (h < 0 ? -1 : h - 9));
              // Пустая связь (-1) показывала пустую ячейку панели, хотя предмет лежит в инвентаре (еду нельзя было взять в руку).
              // Такие ячейки связываем с ячейкой инвентаря того же номера, как делает панель при открытии инвентаря
              for (let i = 0; i < 9; i++) if (map[i] < 0 && !map.includes(i)) map[i] = i;
              g.hotbarMap = map;
            }
          } else if (windowId === 0x78) {
            g.armor = [0, 1, 2, 3].map((i) => items[i] || null);
          } else if (windowId === 121) {
            g.creativeItems = slots.filter((it) => it && it.id);
          } else if (g.windows.has(windowId)) {
            const w = g.windows.get(windowId);
            const resized = w.slots.length !== items.length && w.type !== 2;
            if (resized) w.slots = new Array(items.length).fill(null);
            for (let i = 0; i < items.length; i++) w.slots[i] = items[i];
            // Размер окна стал известен только сейчас (большой сундук на 54 ячейки) — перестраиваем экран
            if (resized && g.invScreen && g.invScreen.window === w) { g.invScreen.build(); g.invScreen.refresh(); return; }
          } else if (windowId > 0 && windowId < 100) {
            g.pendingContent.set(windowId, items);
          }
          if (g.invScreen) g.invScreen.onServerUpdate();
        },
        onCraftingData(recipes) { g.recipes = recipes; },
        // Сервер открыл сундук (0) или печь (2); верстак (1) открывает сам клиент
        // Сервер открыл окно: сундук (0), печь (2), раздатчик/выбрасыватель (6/7), воронка (8) и др.
        // Меню серверов (выбор режима по компасу и т. п.) — это тоже окна-сундуки, часто на 54 ячейки
        onContainerOpen(windowId, type, pos) {
          const size = WINDOW_SIZE[type] || 27;
          const be = g.blockEntities.get(pos.x + ',' + pos.y + ',' + pos.z);
          const w = { id: windowId, type, pos, slots: new Array(size).fill(null), cook: 0, burn: 0, burnMax: 0, title: be && be.CustomName ? be.CustomName : null };
          // Содержимое могло прийти раньше пакета открытия
          const early = g.pendingContent.get(windowId);
          if (early) { w.slots = early.slice(); g.pendingContent.delete(windowId); }
          g.windows.set(windowId, w);
          if (type === 0 || type === 10) MC.Sound.event('chest.open', pos.x + 0.5, pos.y + 0.5, pos.z + 0.5);
          g.openContainer(type === 2 ? 'furnace' : type === 4 ? 'brewing' : 'chest', { window: w });
        },
        onBlockEntity(pos, nbt) {
          if (nbt) g.blockEntities.set(pos.x + ',' + pos.y + ',' + pos.z, nbt);
        },
        onContainerClose(windowId) {
          if (!g.windows.has(windowId)) return;
          g.windows.delete(windowId);
          if (g.invScreen && g.invScreen.window && g.invScreen.window.id === windowId) { g.invScreen.window = null; g.app.resume(); }
        },
        onContainerData(windowId, property, value) {
          const w = g.windows.get(windowId);
          if (!w) return;
          // Варочная стойка: 0 — осталось тиков варки (из 400), 1 — заряды огненного порошка
          if (w.type === 4) {
            if (property === 0) w.time = value > 0 ? MC.Effects.BREW_TIME - value / 20 : 0;
            else if (property === 1) w.fuel = value;
            if (g.invScreen) g.invScreen.onServerUpdate();
            return;
          }
          // 0 — ход готовки (тики из 200), 1 — остаток горения в тиках
          if (property === 0) w.cook = value / 20;
          else if (property === 1) { w.burn = value / 20; w.burnMax = Math.max(w.burnMax, w.burn); }
          if (g.invScreen) g.invScreen.onServerUpdate();
        },
        onAdventure(a) {
          g.immutable = a.worldImmutable;
          g.player.canFly = a.allowFlight || g.gamemode === 1;
          if (!g.player.canFly) g.player.flying = false;
          else if (a.flying) g.player.flying = true;
        },
        onChunk(c) {
          g.world.setChunk(new MC.Chunk(c.cx, c.cz, c.sections));
          g.unloadFar(g.serverRadius + 2);
          g.checkReady();
        },
        onGamemode(m) {
          g.gamemode = m;
          g.player.canFly = m === 1;
          if (!g.player.canFly) g.player.flying = false;
        },
        onPlayerList(p) {
          if (p.add) {
            const skin = p.skin && (p.skin.length === 8192 || p.skin.length === 16384) ? p.skin : null;
            g.playerInfo.set(p.uuid, { name: p.name, skin });
            for (const e of g.entities.values()) {
              if (e.kind === 'player' && e.uuid === p.uuid && skin) { g.renderer.dropSkin(e.skinKey); e.skin = skin; }
            }
          } else {
            g.playerInfo.delete(p.uuid);
          }
        },
        onChunkRadius(r) {
          g.serverRadius = r;
          g.renderer.renderDistance = Math.min(g.app.settings.renderDistance, r);
        },
        onTransfer(address, port) {
          g.ui.addChat('§eПереход на сервер ' + address + ':' + port);
          g.app.transfer({ name: address, host: address, port });
        },
        onTitle(type, text) {
          if (type === 0 || type === 1) g.ui.setTitle('', '', 1);
          else if (type === 2) g.ui.setTitle(text, null);
          else if (type === 3) g.ui.setTitle(null, text);
          else if (type === 4) g.ui.setPopup(text);
        }
      };
    }

    checkReady() {
      if (this.ready || !this.spawned) return;
      if (this.world.isLoaded(Math.floor(this.player.x), Math.floor(this.player.z))) this.becomeReady();
    }

    becomeReady() {
      if (this.ready || this.stopped || !this.spawned) return;
      this.ready = true;
      // Строительство фигурами и схемы на сервере: блоки ставятся обычными пакетами установки
      this.building = new MC.Building(this);
      this.schematic = new MC.Schematics.View(this);
      this.pvp = new MC.PvP(this);
      this.pvp.loadWaypoints();
      if (this.onReady) this.onReady();
    }

    disconnected(reason) {
      if (this.stopped) return;
      this.stopped = true;
      if (!this.ready && this.onFail) this.onFail(new Error(reason));
      else this.app.lostConnection(reason);
    }

    text(t) {
      let msg;
      switch (t.type) {
        case 1: msg = MC.translate('chat.type.text', [t.source, t.message]); break;
        case 3: case 4: this.ui.setPopup(t.message); return;
        case 6: msg = '§7' + t.source + ' шепчет: ' + t.message; break;
        case 7: msg = MC.translate('chat.type.announcement', [t.source, t.message]); break;
        default: msg = t.message;
      }
      if (this.scripts) this.scripts.emit('message', { type: t.type, source: t.source || '', text: t.message, line: msg });
      this.ui.addChat(msg);
      if (this.pvp) this.pvp.onChat(msg);
    }

    setHealth(h) {
      if (h < this.health && h > 0) { this.ui.flashHurt(); if (this.pvp) this.pvp.onHurt(); }
      this.health = h;
      if (h <= 0 && !this.dead) {
        this.dead = true;
        this.cancelBreak();
        this.app.showDeath();
      } else if (h > 0 && this.dead) {
        this.dead = false;
      }
    }

    respawn() {
      const p = this.player;
      if (this.mode === 'sp') {
        // Из Нижнего мира и Края возрождение — в обычном мире
        if (this.dimension) this.switchDimension(0, null).catch((e) => console.warn('Переход', e));
        const s = this.dimension ? this.player : this.spawnPoint();
        p.x = s.x; p.y = s.y; p.z = s.z;
        p.vx = p.vy = p.vz = 0;
        p.fallStart = null;
        this.health = 20;
        this.food = 20;
        this.saturation = 5;
        this.air = 15;
        this.exhaustion = 0;
        this.dead = false;
        return;
      }
      this.client.sendAction(ACT.RESPAWN, Math.floor(p.x), Math.floor(p.y), Math.floor(p.z), 0);
      if (this.respawnPos) {
        p.x = this.respawnPos.x; p.y = this.respawnPos.y; p.z = this.respawnPos.z;
        p.vx = p.vy = p.vz = 0;
      }
      this.dead = false;
      this.lastSent = null;
    }

    // ---------- Чанки ----------
    removeChunkMeshes(cx, cz) {
      for (let sy = 0; sy < 16; sy++) {
        this.renderer.removeSection(cx, sy, cz);
        this.dirty.delete(cx + ',' + sy + ',' + cz);
      }
    }

    unloadFar(radius) {
      const pcx = Math.floor(this.player.x) >> 4, pcz = Math.floor(this.player.z) >> 4;
      for (const c of Array.from(this.world.chunks.values())) {
        if (Math.max(Math.abs(c.cx - pcx), Math.abs(c.cz - pcz)) <= radius) continue;
        if (this.mode === 'sp' && c.modified) MC.Storage.Worlds.saveChunk(this.storeId, c).catch((e) => console.warn('Сохранение чанка', e));
        this.world.removeChunk(c.cx, c.cz);
        this.removeChunkMeshes(c.cx, c.cz);
      }
    }

    async loadChunkSP(cx, cz) {
      const k = MC.chunkKey(cx, cz);
      if (this.world.chunks.has(k) || this.loading.has(k)) return;
      this.loading.add(k);
      const gen = this.dimGen;
      let chunk = null;
      try {
        const saved = await MC.Storage.Worlds.loadChunk(this.storeId, cx, cz);
        if (saved && saved.sections) {
          chunk = new MC.Chunk(cx, cz, saved.sections.map((s) => (s ? { ids: new Uint8Array(s.ids), meta: new Uint8Array(s.meta) } : null)));
        }
      } catch (e) {
        console.warn('Чтение чанка', e);
      }
      // Пока чанк читался, игрок мог перейти в другое измерение
      if (gen !== this.dimGen) return;
      if (!chunk) chunk = this.generator.generate(cx, cz);
      this.loading.delete(k);
      if (this.stopped) return;
      this.world.setChunk(chunk);
    }

    updateChunksSP() {
      const r = this.app.settings.renderDistance;
      const pcx = Math.floor(this.player.x) >> 4, pcz = Math.floor(this.player.z) >> 4;
      if (this.loading.size < 3) {
        let best = null, bestD = Infinity;
        for (let dx = -r; dx <= r; dx++) {
          for (let dz = -r; dz <= r; dz++) {
            const d = dx * dx + dz * dz;
            if (d >= bestD || d > r * r + 1) continue;
            const k = MC.chunkKey(pcx + dx, pcz + dz);
            if (this.world.chunks.has(k) || this.loading.has(k)) continue;
            best = [pcx + dx, pcz + dz];
            bestD = d;
          }
        }
        if (best) this.loadChunkSP(best[0], best[1]);
      }
      if (this.frames % 30 === 0) this.unloadFar(r + 2);
    }

    // Пересборка изменённых секций, начиная с ближайших к игроку, в пределах бюджета времени кадра
    rebuildMeshes(budgetMs) {
      if (!this.dirty.size) return;
      const t0 = performance.now();
      const px = this.player.x / 16, py = this.player.y / 16, pz = this.player.z / 16;
      // Секции дальше дальности прорисовки не строим (на серверах чанков присылают больше): они ждут, пока игрок подойдёт
      const far = (this.renderer.renderDistance + 1.5) ** 2;
      const cache = this.dirtyPos || (this.dirtyPos = new Map());
      const list = [];
      for (const k of this.dirty) {
        let p = cache.get(k);
        if (!p) { const a = k.split(','); p = [+a[0], +a[1], +a[2]]; cache.set(k, p); }
        const dx = p[0] + 0.5 - px, dz = p[2] + 0.5 - pz;
        if (dx * dx + dz * dz > far) continue;
        list.push([dx * dx + dz * dz + (p[1] + 0.5 - py) ** 2 * 0.5, k, p[0], p[1], p[2]]);
      }
      if (cache.size > 20000) cache.clear();
      list.sort((a, b) => a[0] - b[0]);
      for (const [, k, cx, sy, cz] of list) {
        this.dirty.delete(k);
        const chunk = this.world.getChunk(cx, cz);
        if (!chunk || !chunk.sections[sy]) {
          this.renderer.removeSection(cx, sy, cz);
          continue;
        }
        this.renderer.setSection(cx, sy, cz, MC.Mesher.buildSection(this.world, cx, sy, cz));
        if (performance.now() - t0 > budgetMs) break;
      }
    }

    // ---------- Инвентарь ----------
    hotbarItem(i) {
      if (this.mode === 'sp') return this.sinv.slots[i];
      const slot = this.hotbarMap[i];
      if (slot === undefined || slot < 0) return null;
      const it = this.inv[slot];
      return it && it.id ? it : null;
    }

    heldItem() { return this.hotbarItem(this.selected) || { id: 0, data: 0, count: 0 }; }

    hotbarItems() {
      const out = [];
      for (let i = 0; i < 9; i++) out.push(this.hotbarItem(i));
      return out;
    }

    selectHotbar(i) {
      this.selected = ((i % 9) + 9) % 9;
      this.cancelBreak();
      this.eating = null;
      if (this.mode === 'mp') this.mpEquip();
    }

    // Есть ли предмет в творческом меню сервера (только такие сервер разрешает брать в руку пакетом MobEquipment)
    onServerList(it) {
      if (!this.creativeItems) return true;
      return this.creativeItems.some((c) => c.id === it.id && (c.data === it.data || c.data < 0));
    }

    // Сообщить серверу, что в руке. В творческом режиме Nukkit/PocketMine отклоняют MobEquipment для предметов вне своего меню
    // (бетон, новые блоки), но принимают изменение ячейки инвентаря. Поэтому берём в руку любой предмет из меню сервера
    // в эту ячейку панели, а затем кладём в неё нужный предмет — сервер держит в руке именно его
    mpEquip() {
      const h = this.selected;
      const slot = this.hotbarMap[h];
      const item = this.heldItem();
      if (this.gamemode === 1 && item.id && !this.onServerList(item)) {
        const base = this.creativeItems.find((c) => c.id > 0 && c.id < 256) || this.creativeItems[0];
        if (base) {
          const it = { id: item.id, data: item.data, count: item.count, nbt: item.nbt };
          this.inv[h] = it;
          this.hotbarMap[h] = h;
          this.client.sendEquipment({ id: base.id, data: base.data < 0 ? 0 : base.data, count: 1, nbt: base.nbt }, h + 9, h);
          this.client.sendSetSlot(0, h, it, h);
          return;
        }
      }
      this.client.sendEquipment(item, slot >= 0 ? slot + 9 : 255, h);
    }

    openInventory() {
      this.closeInventory();
      if (this.mode === 'mp') this.linkHotbar();
      this.invScreen = new MC.InvScreen(this, this.gamemode === 1 ? 'creative' : 'survival');
    }

    // На сервере панель — это ячейки 0..8 инвентаря (как в Java); связь выбранной ячейки сообщаем серверу
    linkHotbar() {
      this.hotbarMap = [0, 1, 2, 3, 4, 5, 6, 7, 8];
      this.mpEquip();
    }

    // Изменение ячейки на сервере: сервер складывает пары таких пакетов в транзакцию и проверяет баланс
    mpSetSlot(windowId, slot, item) {
      if (this.mode !== 'mp') return;
      this.client.sendSetSlot(windowId, slot, item && item.id ? item : { id: 0, data: 0, count: 0 }, this.selected);
    }

    // Крафт на сервере: ищем рецепт сервера, подходящий к сетке, и отправляем CraftingEvent
    mpCraft(grid, size) {
      const r = MC.Survival.matchServerRecipe(this.recipes, grid, size);
      if (!r) return null;
      // Nukkit 1.1 ждёт всегда 9 ячеек (3x3) в раскладке самого рецепта, начиная с левого верхнего угла
      const air = { id: 0, data: 0, count: 0 };
      const input = [];
      for (let y = 0; y < 3; y++) for (let x = 0; x < 3; x++) {
        let it = null;
        if (r.type === 'shaped') { if (x < r.w && y < r.h) it = r.input[y * r.w + x]; } else { const k = y * 3 + x; if (k < r.input.length) it = r.input[k]; }
        input.push(it && it.id ? { id: it.id, data: it.data, count: 1, nbt: it.nbt } : air);
      }
      this.client.sendCraftingEvent(0, size === 3, r.uuid, input, [r.out]);
      return r.out;
    }

    openContainer(kind, opts) {
      this.closeInventory();
      this.app.openMenu(() => { this.invScreen = new MC.InvScreen(this, kind, opts); });
    }

    // Возвращает в инвентарь предмет из руки и содержимое сетки крафта при закрытии экрана
    closeInventory() {
      if (!this.invScreen) return;
      const s = this.invScreen;
      this.invScreen = null;
      s.close();
      // Творческий режим на сервере: в выбранную ячейку панели могли положить предмет вне меню сервера — сообщаем, что в руке
      if (this.mode === 'mp' && this.gamemode === 1) this.mpEquip();
    }

    setCreativeSlot(item) {
      if (this.mode === 'sp') {
        this.sinv.slots[this.selected] = { id: item.id, data: item.data, count: item.count };
        return;
      }
      this.inv[this.selected] = item;
      this.hotbarMap[this.selected] = this.selected;
      this.mpEquip();
    }

    pickBlock() {
      if (this.gamemode !== 1) return;
      const hit = this.player.raycast(6);
      if (!hit) return;
      const b = Blocks.list[hit.id];
      const data = b.variants > 1 ? hit.data : 0;
      if (this.mode === 'sp') this.setCreativeSlot({ id: hit.id, data, count: 64 });
      else {
        const it = this.creativeItems && this.creativeItems.find((c) => c.id === hit.id && (c.data === data || c.data < 0));
        const pi = MC.Building.placeItem(hit.id, data);
        if (it) this.setCreativeSlot({ id: it.id, data: it.data < 0 ? 0 : it.data, count: 64, nbt: it.nbt });
        else if (pi && pi.id) this.setCreativeSlot({ id: pi.id, data: pi.data, count: 64 });
      }
    }

    // Выбросить предмет из руки: один (Q) или всю стопку
    dropSelected(all) {
      const p = this.player;
      if (this.mode === 'mp') {
        const slot = this.hotbarMap[this.selected];
        const it = this.inv[slot];
        if (!it || !it.id) return;
        const drop = { id: it.id, data: it.data, count: all ? it.count : 1, nbt: it.nbt };
        this.client.sendDropItem(drop);
        return;
      }
      const it = this.sinv.takeFromSlot(this.selected, all ? 64 : 1);
      if (!it) return;
      const d = p.lookDir();
      this.ents.spawnItem(it, p.x + d[0] * 0.3, p.eyeY - 0.3, p.z + d[2] * 0.3, d[0] * 5, d[1] * 5 + 2, d[2] * 5, 1.5);
    }

    onPickup(item) {
      MC.Sound.event('pop');
      this.ui.setPopup('+' + item.count + ' ' + MC.Items.itemName(item.id, MC.Survival.isTool(item.id) ? 0 : item.data));
    }

    // ---------- Сундук и печь (хранятся в записи мира по координатам) ----------
    // Ключ контейнера: в Нижнем мире и Крае — с приставкой измерения, чтобы координаты не совпадали с обычным миром
    ckey(x, y, z) { return (this.dimension ? DIM_KEY[this.dimension] + ':' : '') + x + ',' + y + ',' + z; }

    // Координаты контейнера по ключу или null, если он в другом измерении
    keyPos(key) {
      const i = key.indexOf(':');
      const dim = i < 0 ? 0 : DIM_FROM_KEY[key.slice(0, i)];
      if (dim !== (this.dimension || 0)) return null;
      return key.slice(i + 1).split(',').map(Number);
    }

    chestAt(x, y, z) {
      const key = this.ckey(x, y, z);
      if (!this.record.containers) this.record.containers = {};
      const c = this.record.containers[key];
      if (!c || !Array.isArray(c)) this.record.containers[key] = new Array(27).fill(null);
      return this.record.containers[key];
    }

    // Соседний сундук того же вида: null — нет, false — ставить нельзя (получился бы тройной)
    chestPairFor(x, y, z, id) {
      const w = this.world;
      const near = (cx, cz, sx, sz) => CHEST_DIRS.filter(([dx, dz]) => !(cx + dx === sx && cz + dz === sz) && w.getId(cx + dx, y, cz + dz) === id).map(([dx, dz]) => ({ x: cx + dx, z: cz + dz }));
      const n = near(x, z, NaN, NaN);
      if (n.length > 1) return false;
      if (!n.length) return null;
      if (near(n[0].x, n[0].z, x, z).length) return false;
      return n[0];
    }

    // Большой сундук: 54 ячейки из двух записей по 27 (первая — у половины с меньшей координатой)
    chestView(x, y, z, id) {
      const own = this.chestAt(x, y, z);
      for (const [dx, dz] of CHEST_DIRS) {
        if (this.world.getId(x + dx, y, z + dz) !== id) continue;
        const other = this.chestAt(x + dx, y, z + dz);
        const first = dx < 0 || dz < 0;
        return pairView(first ? other : own, first ? own : other);
      }
      return own;
    }

    // Варочная стойка: [ингредиент, 3 бутылки, огненный порошок], заряд топлива и ход варки
    brewAt(x, y, z) {
      const key = this.ckey(x, y, z);
      if (!this.record.containers) this.record.containers = {};
      const c = this.record.containers[key];
      if (!c || c.type !== 'brewing') this.record.containers[key] = { type: 'brewing', slots: [null, null, null, null, null], fuel: 0, time: 0 };
      return this.record.containers[key];
    }

    furnaceAt(x, y, z) {
      const key = this.ckey(x, y, z);
      if (!this.record.containers) this.record.containers = {};
      const c = this.record.containers[key];
      if (!c || c.type !== 'furnace') this.record.containers[key] = { type: 'furnace', input: null, fuel: null, output: null, burn: 0, burnMax: 0, cook: 0 };
      return this.record.containers[key];
    }

    // Печи работают по времени, пока мир открыт: горящая печь меняет блок на 62
    tickFurnaces(dt) {
      const c = this.record.containers;
      if (!c) return;
      for (const key in c) {
        const f = c[key];
        if (!f) continue;
        if (f.type === 'brewing') {
          if (this.keyPos(key)) MC.Effects.tickBrewing(f, dt);
          continue;
        }
        if (f.type !== 'furnace') continue;
        const pos = this.keyPos(key);
        if (!pos) continue;
        const wasLit = f.burn > 0;
        const lit = MC.Survival.tickFurnace(f, dt);
        if (lit === wasLit && !f.output) continue;
        const [x, y, z] = pos;
        if (!this.world.isLoaded(x, z)) continue;
        const id = this.world.getId(x, y, z);
        if (id === 61 && lit) this.world.setBlock(x, y, z, 62, this.world.getData(x, y, z));
        else if (id === 62 && !lit) this.world.setBlock(x, y, z, 61, this.world.getData(x, y, z));
        else if (id !== 61 && id !== 62) delete c[key];
      }
    }

    // ---------- Чат ----------
    chat(text) {
      if (this.scripts && this.scripts.handleChat(text)) return;
      if (this.mode === 'mp') {
        this.client.sendChat(text);
        return;
      }
      if (text.startsWith('/')) this.command(text.slice(1).trim().split(/\s+/));
      else this.ui.addChat(MC.translate('chat.type.text', [this.app.settings.nickname, text]));
    }

    // Команды одиночной игры
    command(args) {
      const name = (args[0] || '').toLowerCase();
      const p = this.player;
      if (name === 'time' && args[1] === 'set') {
        const v = { day: 1000, noon: 6000, night: 13000, midnight: 18000 }[args[2]];
        const t = v !== undefined ? v : parseInt(args[2], 10);
        if (isNaN(t)) { this.ui.addChat('§cИспользование: /time set <day|night|noon|midnight|число>'); return; }
        this.time = t;
        this.ui.addChat('Время установлено: ' + t);
      } else if (name === 'tp' && args.length >= 4) {
        const c = (s, cur) => (s.startsWith('~') ? cur + (parseFloat(s.slice(1)) || 0) : parseFloat(s));
        const x = c(args[1], p.x), y = c(args[2], p.y), z = c(args[3], p.z);
        if ([x, y, z].some(isNaN)) { this.ui.addChat('§cИспользование: /tp <x> <y> <z>'); return; }
        p.x = x; p.y = y; p.z = z; p.vx = p.vy = p.vz = 0; p.fallStart = null;
        this.ui.addChat('Телепортация на ' + x.toFixed(1) + ' ' + y.toFixed(1) + ' ' + z.toFixed(1));
      } else if (name === 'seed') {
        this.ui.addChat('Зерно мира: ' + this.record.seed);
      } else if (name === 'spawn') {
        const s = this.spawnPoint();
        p.x = s.x; p.y = s.y; p.z = s.z; p.vx = p.vy = p.vz = 0; p.fallStart = null;
      } else if (name === 'gamemode' && args[1] !== undefined) {
        const m = { 0: 0, s: 0, survival: 0, 1: 1, c: 1, creative: 1 }[args[1].toLowerCase()];
        if (m === undefined) { this.ui.addChat('§cИспользование: /gamemode <0|1>'); return; }
        this.setGamemodeSP(m);
        this.ui.addChat(MC.translate('commands.gamemode.success.self', [m ? 'gameMode.creative' : 'gameMode.survival']));
      } else if (name === 'give' && args[1]) {
        const id = parseInt(args[1], 10), count = parseInt(args[2], 10) || 1, data = parseInt(args[3], 10) || 0;
        if (!(id > 0 && id < 512)) { this.ui.addChat('§cИспользование: /give <id> [количество] [данные]'); return; }
        const left = this.sinv.add({ id, data, count });
        if (left) this.ents.spawnItem({ id, data, count: left }, p.x, p.y + 1, p.z);
        this.ui.addChat('Выдано: ' + MC.Items.itemName(id, data) + ' x' + count);
      } else if (name === 'summon' && args[1]) {
        const type = MC.Entities.TYPES[args[1].toLowerCase()];
        if (!type) { this.ui.addChat('§cСущества: ' + Object.keys(MC.Entities.TYPES).join(', ')); return; }
        const d = p.lookDir();
        this.ents.spawnMob(type, p.x + d[0] * 3, p.y + 0.5, p.z + d[2] * 3);
      } else if (name === 'kill') {
        this.damagePlayer(1000, p.x, p.z, 'Вы погибли');
      } else {
        this.ui.addChat('§7Команды: /gamemode 0|1, /give <id> [кол-во] [данные], /summon <zombie|creeper|spider|pig|cow|sheep|chicken>, /time set <day|night>, /tp x y z, /spawn, /seed, /kill');
      }
    }

    // ---------- Выживание (одиночная игра) ----------
    survival() { return this.gamemode === 0 || (this.mode === 'mp' && this.gamemode === 2); }

    daylight() { return this.dimension ? 0 : daylightAt(this.time); }

    spawnPoint() {
      const s = this.record.spawn;
      if (s && Blocks.list[this.world.getId(Math.floor(s.x), Math.floor(s.y), Math.floor(s.z))].solid === false) return { x: s.x, y: s.y, z: s.z };
      return this.generator.findSpawn();
    }

    setGamemodeSP(m) {
      this.gamemode = m;
      this.player.canFly = m === 1;
      if (m !== 1) this.player.flying = false;
      this.health = 20;
      this.food = 20;
    }

    // Быстрое переключение выживание ↔ творческий (кнопка в игре, только одиночная)
    toggleCreativeSP() {
      if (this.mode !== 'sp') return;
      const m = this.gamemode === 1 ? 0 : 1;
      this.setGamemodeSP(m);
      this.ui.setPopup(m === 1 ? 'Творческий режим' : 'Выживание');
    }

    damagePlayer(amount, srcX, srcZ, cause) {
      if (this.mode !== 'sp' || this.gamemode !== 0 || this.dead || this.invuln > 0) return;
      const p = this.player;
      // Броня не спасает от падения, утопления, голода и пустоты (как в Minecraft)
      if (!/падении|Утонул|голода|Выпал из мира/.test(cause || '')) {
        const pts = MC.Survival.armorPoints(this.armor);
        if (pts > 0) {
          amount = Math.round(amount * (1 - pts / 25) * 2) / 2;
          this.wearArmor(Math.max(1, Math.floor(amount / 4)));
        }
      }
      const E = MC.Effects.E;
      if (this.effects.has(E.FIRE_RES) && /лаве|огне|Сгорел/.test(cause || '')) return;
      // Сопротивление: −20 % урона за уровень (кроме пустоты)
      const res = this.effects.level(E.RESISTANCE);
      if (res && !/Выпал из мира/.test(cause || '')) amount = amount * Math.max(0, 1 - 0.2 * res);
      if (amount <= 0) return;
      // Поглощение (золотое яблоко, тотем) принимает урон первым
      if (this.fx.absorb > 0) {
        const a = Math.min(this.fx.absorb, amount);
        this.fx.absorb -= a;
        amount -= a;
      }
      this.health = Math.max(0, this.health - amount);
      this.invuln = 0.5;
      this.exhaustion += 0.1;
      if (srcX !== null && srcX !== undefined) {
        const dx = p.x - srcX, dz = p.z - srcZ, l = Math.hypot(dx, dz) || 1;
        p.vx += dx / l * 8;
        p.vz += dz / l * 8;
        p.vy = Math.max(p.vy, 5);
      }
      this.ui.flashHurt(); if (this.pvp) this.pvp.onHurt();
      if (this.health > 0) MC.Sound.play('game.player.hurt', null, 1, 0.8 + Math.random() * 0.4);
      if (this.health <= 0 && this.useTotem()) return;
      if (this.health <= 0) this.dieSP(typeof cause === 'string' ? cause : 'Вы погибли');
    }

    // Тотем бессмертия (450): в руке, а если в руке нет — в любой ячейке хотбара (левой руки в игре нет).
    // Спасает от смерти: 1 здоровье, Регенерация II 40 с, Поглощение II 5 с, Огнестойкость 40 с
    useTotem() {
      const slots = this.sinv.slots;
      let i = -1;
      if (slots[this.selected] && slots[this.selected].id === 450) i = this.selected;
      else for (let k = 0; k < 9; k++) if (slots[k] && slots[k].id === 450) { i = k; break; }
      if (i < 0) return false;
      this.sinv.takeFromSlot(i, 1);
      this.health = 1;
      this.invuln = 1;
      const E = MC.Effects.E;
      this.effects.clear();
      this.addEffect(E.REGEN, 1, 40);
      this.addEffect(E.ABSORPTION, 1, 5);
      this.addEffect(E.FIRE_RES, 0, 40);
      this.ui.totemPop();
      MC.Sound.play('random.levelup', null, 1, 1.2);
      this.ui.setPopup('§eТотем бессмертия спас вас');
      return true;
    }

    // Износ брони: каждая надетая вещь теряет прочность при уроне
    wearArmor(n) {
      for (let i = 0; i < 4; i++) {
        const a = this.armor[i];
        if (!a) continue;
        a.data += n;
        if (a.data >= MC.Survival.durabilityOf(a.id)) {
          this.armor[i] = null;
          this.ui.setPopup('§cБроня сломалась: ' + MC.Items.itemName(a.id, 0));
        }
      }
    }

    // Надеть броню из руки (нажатие «использовать»); снятая вещь возвращается в руку
    equipArmor(held) {
      const inf = MC.Survival.armorInfo(held.id);
      if (!inf) return false;
      const cur = this.armor[inf[0]];
      this.armor[inf[0]] = { id: held.id, data: held.data, count: 1 };
      this.sinv.slots[this.selected] = cur;
      MC.Sound.click();
      this.ui.setPopup('Надето: ' + MC.Items.itemName(held.id, 0));
      return true;
    }

    // Опыт в одиночной игре (формулы Minecraft): очки на следующий уровень растут с уровнем
    setXpTotal(total) {
      this.xpTotal = Math.max(0, Math.floor(total));
      let lv = 0, left = this.xpTotal;
      for (;;) {
        const need = lv < 16 ? 2 * lv + 7 : lv < 31 ? 5 * lv - 38 : 9 * lv - 158;
        if (left < need) { this.xpProgress = left / need; break; }
        left -= need;
        lv++;
      }
      this.xpLevel = lv;
    }

    addXp(n) {
      if (n <= 0 || this.gamemode !== 0) return;
      const before = this.xpLevel || 0;
      this.setXpTotal((this.xpTotal || 0) + n);
      MC.Sound.play('random.orb', null, 0.4, 0.8 + Math.random() * 0.6);
      if (this.xpLevel > before && this.xpLevel % 5 === 0) MC.Sound.play('random.levelup', null, 0.75, 1);
    }

    dieSP(cause) {
      const p = this.player;
      this.dead = true;
      if (this.pvp) this.pvp.onDeath();
      this.fx = { absorb: 0 };
      this.effects.clear();
      this.fireT = 0;
      this.closeInventory();
      MC.Sound.play('game.player.die', null, 1, 1);
      this.breaking = null;
      this.eating = null;
      // Всё содержимое инвентаря и броня выпадают на месте смерти
      for (const it of this.sinv.clear()) this.ents.spawnItem(it, p.x, p.y + 1, p.z, (Math.random() - 0.5) * 6, 4, (Math.random() - 0.5) * 6, 1);
      for (let i = 0; i < 4; i++) if (this.armor[i]) { this.ents.spawnItem(this.armor[i], p.x, p.y + 1, p.z, (Math.random() - 0.5) * 6, 4, (Math.random() - 0.5) * 6, 1); this.armor[i] = null; }
      this.setXpTotal(0);
      this.ui.addChat(this.app.settings.nickname + ': ' + cause);
      this.app.showDeath(cause);
    }

    // Поджечь игрока на sec секунд (стрела с огнём, огненный шар, лава)
    setOnFire(sec) {
      if (this.mode !== 'sp' || this.gamemode !== 0 || this.dead) return;
      this.fireT = Math.max(this.fireT || 0, sec);
    }

    // Эффект на игрока (одиночная игра): мгновенные исцеление и вред срабатывают сразу
    addEffect(id, amp, sec) {
      const E = MC.Effects.E;
      if (id === E.HEAL) { if (this.gamemode === 0 && !this.dead) this.health = Math.min(20, this.health + (4 << Math.min(amp, 4))); return; }
      if (id === E.HARM) { this.invuln = 0; this.damagePlayer(6 << Math.min(amp, 4), null, null, 'Убит магией'); return; }
      if (sec <= 0) return;
      if (this.effects.add(id, amp, sec) && id === E.ABSORPTION) this.fx.absorb = 4 * (amp + 1);
    }

    // Действие зелья по data; k — доля силы (взрывное зелье вдали от центра, оседающее облако)
    applyPotion(data, k) {
      const p = MC.Effects.POTION[data];
      if (!p) return;
      const [id, sec, amp] = p;
      if (MC.Effects.INSTANT.has(id)) {
        if (k >= 0.99) this.addEffect(id, amp, 0);
        else {
          const E = MC.Effects.E;
          const n = Math.round((id === E.HEAL ? 4 : 6) * (1 << amp) * k);
          if (id === E.HEAL) { if (this.gamemode === 0) this.health = Math.min(20, this.health + n); }
          else if (n > 0) { this.invuln = 0; this.damagePlayer(n, null, null, 'Убит магией'); }
        }
        return;
      }
      this.addEffect(id, amp, Math.round(sec * k));
    }

    drink(item) {
      const p = this.player;
      if (item.id === 373) {
        this.applyPotion(item.data, 1);
        if (this.gamemode !== 1) this.replaceHeld(item, { id: 374, data: 0, count: 1 });
      } else {
        this.effects.clear();
        this.fx.absorb = 0;
        if (this.gamemode !== 1) this.replaceHeld(item, { id: 325, data: 0, count: 1 });
      }
      MC.Sound.play('random.burp', null, 0.5, 1);
      if (this.particles.potion) this.particles.potion(p.x, p.y + 1, p.z, MC.Effects.potionColor(item.data), 6);
    }

    // Использованный предмет из руки заменяется остатком (пустая бутылка, ведро, миска)
    replaceHeld(item, rest) {
      const s = this.sinv.slots[this.selected];
      if (!s || s.id !== item.id) return;
      if (s.count > 1) {
        s.count--;
        if (this.sinv.add(rest)) this.ents.spawnItem(rest, this.player.x, this.player.y + 1, this.player.z);
      } else this.sinv.slots[this.selected] = rest;
    }

    eat(item) {
      // Зелье и молоко пьются; бутылка или ведро остаются в руке
      if (item.id === 373 || (item.id === 325 && item.data === 1)) { this.drink(item); return; }
      const f = MC.Survival.FOOD[item.id];
      if (!f) return;
      const E = MC.Effects.E;
      this.food = Math.min(20, this.food + f[0]);
      this.saturation = Math.min(this.food, this.saturation + f[1]);
      // Эффекты еды как в Minecraft
      if (item.id === 322) { this.addEffect(E.REGEN, 1, 5); this.addEffect(E.ABSORPTION, 0, 120); }
      if (item.id === 466) { this.addEffect(E.REGEN, 1, 20); this.addEffect(E.ABSORPTION, 3, 120); this.addEffect(E.RESISTANCE, 0, 300); this.addEffect(E.FIRE_RES, 0, 300); }
      if (item.id === 367 && Math.random() < 0.8) this.addEffect(E.HUNGER, 0, 30);
      if (item.id === 365 && Math.random() < 0.3) this.addEffect(E.HUNGER, 0, 30);
      if (item.id === 375) this.addEffect(E.POISON, 0, 4);
      if (item.id === 394 && Math.random() < 0.6) this.addEffect(E.POISON, 0, 4);
      if (item.id === 432) this.chorusTeleport();
      if (item.id === 462) { this.addEffect(E.POISON, 3, 60); this.addEffect(E.HUNGER, 2, 15); this.addEffect(E.NAUSEA, 1, 15); }
      const left = this.sinv.slots[this.selected];
      if (left && left.id === item.id) {
        this.sinv.takeFromSlot(this.selected, 1);
        if (f[2]) {
          if (!this.sinv.slots[this.selected]) this.sinv.slots[this.selected] = { id: f[2], data: 0, count: 1 };
          else if (this.sinv.add({ id: f[2], data: 0, count: 1 })) this.ents.spawnItem({ id: f[2], data: 0, count: 1 }, this.player.x, this.player.y + 1, this.player.z);
        }
      }
    }

    // Плод хоруса: телепорт в случайную безопасную точку до 8 блоков (как в Minecraft)
    chorusTeleport() {
      const p = this.player, w = this.world;
      for (let i = 0; i < 16; i++) {
        const x = Math.floor(p.x + (Math.random() * 2 - 1) * 8);
        const z = Math.floor(p.z + (Math.random() * 2 - 1) * 8);
        let y = Math.min(250, Math.floor(p.y + (Math.random() * 2 - 1) * 8));
        if (!w.isLoaded(x, z)) continue;
        while (y > 1 && !this.solidBlock(x, y - 1, z)) y--;
        if (y <= 1 || !this.solidBlock(x, y - 1, z) || this.solidBlock(x, y, z) || this.solidBlock(x, y + 1, z)) continue;
        if (w.getId(x, y, z) >= 8 && w.getId(x, y, z) <= 11) continue;
        MC.Sound.play('mob.endermen.portal', [p.x, p.y, p.z], 1, 1);
        p.x = x + 0.5; p.y = y; p.z = z + 0.5;
        p.vx = p.vy = p.vz = 0;
        p.fallStart = null;
        MC.Sound.play('mob.endermen.portal', [p.x, p.y, p.z], 1, 1);
        return true;
      }
      return false;
    }

    solidBlock(x, y, z) {
      const id = this.world.getId(x, y, z);
      return !!id && !!Blocks.list[id] && !!Blocks.list[id].solid;
    }

    // Здоровье, голод, воздух, урон от падения, лавы и пустоты
    updateSurvival(dt, fall, moved, jumped) {
      const p = this.player;
      this.invuln = Math.max(0, this.invuln - dt);
      const E = MC.Effects.E;
      const surv = this.gamemode === 0 && !this.dead;
      this.effects.tick(dt, {
        heal: (n) => { if (surv) this.health = Math.min(20, this.health + n); },
        // Яд не убивает (оставляет полсердца), иссушение — может
        hurt: (n, why) => {
          if (!surv) return;
          if (why === 'poison') { if (this.health > 1) { this.health = Math.max(1, this.health - n); this.ui.flashHurt(); } return; }
          this.invuln = 0;
          this.damagePlayer(n, null, null, 'Иссушился');
        },
        hunger: (n) => { if (surv) this.exhaustion += n; },
        saturate: (n) => { if (surv) { this.food = Math.min(20, this.food + n); this.saturation = Math.min(this.food, this.saturation + n * 2); } },
        expired: (id) => { if (id === E.ABSORPTION) this.fx.absorb = 0; }
      });
      if (this.gamemode !== 0 || this.dead) { this.air = 15; this.fireT = 0; return; }
      // Прыгучесть уменьшает урон от падения на уровень
      const safe = 3 + this.effects.level(E.JUMP);
      if (fall > safe + 0.4 && !p.inWater) this.damagePlayer(Math.floor(fall - safe), null, null, 'Разбился при падении');
      if (p.headInWater && !this.effects.has(E.WATER_BREATHING)) {
        this.air -= dt;
        if (this.air < 0) { this.air += 1; this.damagePlayer(2, null, null, 'Утонул'); }
      } else {
        this.air = Math.min(15, this.air + dt * 5);
      }
      if (p.inLava) {
        this.lavaT -= dt;
        if (this.lavaT <= 0) { this.lavaT = 0.5; this.invuln = 0; this.damagePlayer(4, null, null, 'Сгорел в лаве'); }
      }
      // Огонь: лава поджигает на 15 с, блок огня — на 8 с; горение — 1 урон в секунду, вода тушит
      const feetId = this.world.getId(Math.floor(p.x), Math.floor(p.y + 0.1), Math.floor(p.z));
      const bodyId = this.world.getId(Math.floor(p.x), Math.floor(p.y + 1), Math.floor(p.z));
      if (p.inLava) this.setOnFire(15);
      if (feetId === 51 || bodyId === 51) {
        this.setOnFire(8);
        this.fireBlockT = (this.fireBlockT || 0) - dt;
        if (this.fireBlockT <= 0) { this.fireBlockT = 0.5; this.invuln = 0; this.damagePlayer(1, null, null, 'Сгорел в огне'); }
      }
      if (this.fireT > 0) {
        if (p.inWater) { this.fireT = 0; MC.Sound.play('random.fizz', null, 0.5, 1.5); }
        else {
          this.fireT -= dt;
          this.burnT = (this.burnT || 0) + dt;
          if (this.burnT >= 1) { this.burnT = 0; this.invuln = 0; this.damagePlayer(1, null, null, 'Сгорел заживо'); }
          if (this.particles.flame && Math.random() < 0.6) {
            const d = p.lookDir();
            this.particles.flame(p.x + d[0] * 0.6 + (Math.random() - 0.5) * 0.6, p.y + Math.random() * 1.2, p.z + d[2] * 0.6 + (Math.random() - 0.5) * 0.6);
          }
        }
      }
      if (p.y < -64) { this.invuln = 0; this.damagePlayer(4, null, null, 'Выпал из мира'); }
      // Голод: бег и прыжки расходуют насыщение, потом еду
      this.exhaustion += moved * (p.sprinting ? 0.1 : 0.01) + (jumped ? (p.sprinting ? 0.2 : 0.05) : 0);
      while (this.exhaustion >= 4) {
        this.exhaustion -= 4;
        if (this.saturation > 0) this.saturation = Math.max(0, this.saturation - 1);
        else this.food = Math.max(0, this.food - 1);
      }
      this.regenT += dt;
      if (this.regenT >= 4) {
        this.regenT = 0;
        if (this.food >= 18 && this.health < 20) { this.health = Math.min(20, this.health + 1); this.exhaustion += 3; }
        else if (this.food <= 0 && this.health > 1) this.damagePlayer(1, null, null, 'Умер от голода');
      }
    }

    // Рост растений и саженцев (случайные такты блоков рядом с игроком)
    randomTicks() {
      const w = this.world, p = this.player;
      const pcx = Math.floor(p.x) >> 4, pcz = Math.floor(p.z) >> 4;
      for (let dx = -4; dx <= 4; dx++) for (let dz = -4; dz <= 4; dz++) {
        const c = w.getChunk(pcx + dx, pcz + dz);
        if (!c) continue;
        for (let sy = 0; sy < 16; sy++) {
          const sec = c.sections[sy];
          if (!sec) continue;
          for (let n = 0; n < 3; n++) {
            const i = Math.floor(Math.random() * 4096);
            const id = sec.ids[i];
            if (id === 2 || id === 78 || id === 79) {
              this.surfaceTick(c.cx * 16 + (i >> 8), sy * 16 + (i & 15), c.cz * 16 + ((i >> 4) & 15), id);
              continue;
            }
            if (id !== 59 && id !== 141 && id !== 142 && id !== 244 && id !== 6 && id !== 104 && id !== 105 && id !== 83 && id !== 81) continue;
            const x = c.cx * 16 + (i >> 8), z = c.cz * 16 + ((i >> 4) & 15), y = sy * 16 + (i & 15);
            this.growAt(x, y, z, id, sec.meta[i], 1);
          }
        }
      }
    }

    // Трава зарастает на землю и гибнет под непрозрачным блоком; снег и лёд тают у источников света
    surfaceTick(x, y, z, id) {
      const w = this.world, L = Blocks.LIGHT;
      if (id === 2) {
        if (Blocks.list[w.getId(x, y + 1, z)].opaque) { w.setBlock(x, y, z, 3, 0); return; }
        const tx = x + Math.floor(Math.random() * 3) - 1, ty = y + Math.floor(Math.random() * 5) - 3, tz = z + Math.floor(Math.random() * 3) - 1;
        if (w.getId(tx, ty, tz) === 3 && w.getData(tx, ty, tz) === 0 && !Blocks.list[w.getId(tx, ty + 1, tz)].opaque && !Blocks.list[w.getId(tx, ty + 1, tz)].liquid) w.setBlock(tx, ty, tz, 2, 0);
        return;
      }
      let lit = 0;
      for (let dx = -2; dx <= 2; dx++) for (let dy = -2; dy <= 2; dy++) for (let dz = -2; dz <= 2; dz++) {
        const v = L[w.getId(x + dx, y + dy, z + dz)] - Math.abs(dx) - Math.abs(dy) - Math.abs(dz);
        if (v > lit) lit = v;
      }
      if (lit > 11) w.setBlock(x, y, z, id === 79 ? 9 : 0, 0);
    }

    growAt(x, y, z, id, data, steps) {
      const w = this.world;
      if (id === 59 || id === 141 || id === 142 || id === 244) {
        if (data < 7) w.setBlock(x, y, z, id, Math.min(7, data + steps));
        return data < 7;
      }
      if (id === 6) {
        if (steps === 1 && Math.random() > 0.15) return false;
        this.growTree(x, y, z, data & 7);
        return true;
      }
      if ((id === 83 || id === 81) && steps === 1) {
        let h = 1;
        while (w.getId(x, y - h, z) === id) h++;
        if (h < 3 && w.getId(x, y + 1, z) === 0) w.setBlock(x, y + 1, z, id, 0);
        return true;
      }
      if ((id === 104 || id === 105) && steps === 1) {
        if (data < 7) { w.setBlock(x, y, z, id, data + 1); return true; }
        for (const [ax, az] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          if (w.getId(x + ax, y, z + az) === 0 && Blocks.list[w.getId(x + ax, y - 1, z + az)].opaque) {
            w.setBlock(x + ax, y, z + az, id === 104 ? 86 : 103, 0);
            return true;
          }
        }
      }
      return false;
    }

    growTree(x, y, z, kind) {
      const w = this.world;
      const log = kind >= 4 ? 162 : 17, leaves = kind >= 4 ? 161 : 18, d = kind >= 4 ? kind - 4 : kind;
      const h = 4 + Math.floor(Math.random() * 3);
      for (let i = 1; i <= h + 1; i++) if (w.getId(x, y + i, z) !== 0 && w.getId(x, y + i, z) !== leaves) return;
      for (let yy = h - 2; yy <= h + 1; yy++) {
        const r = yy >= h ? 1 : 2;
        for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) {
          if (r === 2 && Math.abs(dx) === 2 && Math.abs(dz) === 2 && Math.random() < 0.5) continue;
          if (yy === h + 1 && Math.abs(dx) + Math.abs(dz) > 1) continue;
          if (w.getId(x + dx, y + yy, z + dz) === 0) w.setBlock(x + dx, y + yy, z + dz, leaves, d);
        }
      }
      for (let i = 0; i < h; i++) w.setBlock(x, y + i, z, log, d);
    }

    // ---------- Разрушение и установка блоков ----------
    canEdit() {
      if (this.mode === 'sp') return true;
      return !this.immutable && this.gamemode !== 2 && this.gamemode !== 3;
    }

    cancelBreak() {
      if (this.breaking && this.mode === 'mp') {
        const b = this.breaking;
        this.client.sendAction(ACT.ABORT_BREAK, b.x, b.y, b.z, b.face);
      }
      this.breaking = null;
    }

    breakTimeFor(hit) {
      if (this.gamemode === 1) return this.mode === 'sp' ? 0 : 0.2;
      const held = this.heldItem();
      const t = Blocks.breakTime(hit.id, held.id, this.player.onGround, this.player.headInWater) / this.effects.digMul();
      return this.mode === 'mp' ? t + 0.1 : t;
    }

    // Портит инструмент; возвращает false, если он сломался
    wearTool(amount) {
      if (this.mode !== 'sp' || this.gamemode !== 0) return;
      const it = this.sinv.slots[this.selected];
      if (!it) return;
      const t = MC.Survival.toolInfo(it.id);
      if (!t) return;
      it.data += amount;
      if (it.data >= t[2]) {
        this.sinv.slots[this.selected] = null;
        this.ui.setPopup('§cИнструмент сломался: ' + MC.Items.itemName(it.id, 0));
      }
    }

    // Убирает блок в одиночной игре вместе со второй половиной двери/кровати и тем, что на нём стояло
    // Тип головы на блоке 144 (0 скелет, 1 иссушитель, 2 зомби, 3 игрок, 4 крипер, 5 дракон)
    skullType(x, y, z) { return this.record && this.record.skulls ? this.record.skulls[this.ckey(x, y, z)] || 0 : 0; }

    forgetSkull(x, y, z) { if (this.record && this.record.skulls) delete this.record.skulls[this.ckey(x, y, z)]; }

    removeBlockSP(x, y, z, drops) {
      const w = this.world;
      const id = w.getId(x, y, z), data = w.getData(x, y, z);
      const held = this.heldItem();
      const survival = this.gamemode === 0;
      if (id === 144) {
        if (drops && survival) this.ents.spawnItem({ id: 397, data: this.skullType(x, y, z), count: 1 }, x + 0.5, y + 0.3, z + 0.5);
        this.forgetSkull(x, y, z);
        drops = false;
      }
      if (drops && survival) {
        const got = MC.Survival.blockDrops(id, data, held.id);
        for (const it of got) this.ents.spawnItem(it, x + 0.5, y + 0.3, z + 0.5);
        // Опыт за руду — только если руда выпала как ресурс (уголь, алмаз, изумруд, лазурит, редстоун, кварц)
        const ore = ORE_XP[id];
        if (ore && got.length && !got.some((it) => it.id === id)) this.addXp(ore[0] + Math.floor(Math.random() * (ore[1] - ore[0] + 1)));
      }
      if ((id === 54 || id === 146 || id === 61 || id === 62 || id === 117) && this.record.containers) {
        const key = this.ckey(x, y, z);
        const c = this.record.containers[key];
        const items = Array.isArray(c) ? c : c && c.type === 'brewing' ? c.slots : c ? [c.input, c.fuel, c.output] : [];
        for (const it of items) if (it) this.ents.spawnItem(it, x + 0.5, y + 0.5, z + 0.5);
        delete this.record.containers[key];
      }
      w.setBlock(x, y, z, 0, 0);
      if (DOORS.has(id) || id === 71) {
        const oy = data & 8 ? y - 1 : y + 1;
        if (w.getId(x, oy, z) === id) w.setBlock(x, oy, z, 0, 0);
      }
      if (id === 26) {
        const dir = [[0, 1], [-1, 0], [0, -1], [1, 0]][data & 3];
        const s = data & 8 ? -1 : 1;
        if (w.getId(x + dir[0] * s, y, z + dir[1] * s) === 26) w.setBlock(x + dir[0] * s, y, z + dir[1] * s, 0, 0);
      }
      // Растения, факелы, двери и снег не висят в воздухе
      for (let yy = y + 1; yy < 256; yy++) {
        const above = w.getId(x, yy, z);
        const b = Blocks.list[above];
        const attached = above && (b.shape === 'cross' || b.shape === 'crop' || b.shape === 'torch' || b.shape === 'flat' || above === 78 || above === 81 || above === 83 || DOORS.has(above) || above === 71);
        if (!attached) break;
        if (drops && survival && !DOORS.has(above) && above !== 71) for (const it of MC.Survival.blockDrops(above, w.getData(x, yy, z), 0)) this.ents.spawnItem(it, x + 0.5, yy + 0.3, z + 0.5);
        w.setBlock(x, yy, z, 0, 0);
      }
      if (id === 46 && !drops) this.ents.primeTnt(x, y, z, 0.5 + Math.random());
    }

    updateBreaking(dt, hit) {
      const p = this.player;
      if (!this.input.attackHeld || !hit || !this.canEdit() || this.eating) {
        if (this.breaking) this.cancelBreak();
        return;
      }
      const b = this.breaking;
      if (b && (b.x !== hit.x || b.y !== hit.y || b.z !== hit.z)) {
        // Прицел на грани блока на пару кадров перескакивает на соседний: даём 0,25 с, прежде чем начать заново
        b.miss = (b.miss || 0) + dt;
        if (b.miss < 0.25) { hit = b; } 
      } else if (b) b.miss = 0;
      if (!b || b.x !== hit.x || b.y !== hit.y || b.z !== hit.z) {
        if (b) this.cancelBreak();
        if (this.attackCooldown > 0) return;
        const time = this.breakTimeFor(hit);
        if (!isFinite(time)) return;
        this.breaking = { x: hit.x, y: hit.y, z: hit.z, face: hit.face, id: hit.id, time, start: performance.now(), elapsed: 0, swing: 0 };
        if (this.mode === 'mp') {
          this.client.sendAction(ACT.ABORT_BREAK, hit.x, hit.y, hit.z, hit.face);
          this.client.sendAction(ACT.START_BREAK, hit.x, hit.y, hit.z, hit.face);
          this.client.sendSwing();
        }
      }
      const br = this.breaking;
      // Сервер сверяет время разрушения по своим часам, поэтому считаем по реальному времени, а не по кадрам
      br.elapsed = (performance.now() - br.start) / 1000;
      br.swing -= dt;
      if (br.swing <= 0) {
        if (br.time > 0) {
          MC.Sound.block(br.id, 'hit', br.x + 0.5, br.y + 0.5, br.z + 0.5);
          this.particles.blockHit(br.x, br.y, br.z, br.id, this.world.getData(br.x, br.y, br.z), br.face);
        }
        if (this.mode === 'mp') this.client.sendSwing();
        p.swingTime = 1;
        br.swing = 0.25;
      }
      if (br.elapsed >= br.time) {
        if (this.scripts && this.scripts.emit('blockBreak', { x: br.x, y: br.y, z: br.z, id: br.id, data: this.world.getData(br.x, br.y, br.z) }) === false) {
          this.cancelBreak();
          this.attackCooldown = 0.25;
          return;
        }
        MC.Sound.block(br.id, 'break', br.x + 0.5, br.y + 0.5, br.z + 0.5);
        this.particles.blockBreak(br.x, br.y, br.z, br.id, this.world.getData(br.x, br.y, br.z));
        if (this.mode === 'mp') {
          this.lastOwnBreak = { x: br.x, y: br.y, z: br.z, t: performance.now() };
          this.client.sendSoundEvent(4, br.x + 0.5, br.y + 0.5, br.z + 0.5, br.id);
          this.client.sendAction(ACT.STOP_BREAK, br.x, br.y, br.z, br.face);
          this.client.sendRemoveBlock(br.x, br.y, br.z);
          // Показываем результат сразу; сервер вернёт блок пакетом UpdateBlock, если отказал
          this.world.setBlock(br.x, br.y, br.z, 0, 0);
        } else {
          if (br.id === 46 && this.gamemode === 0) {
            this.world.setBlock(br.x, br.y, br.z, 0, 0);
            this.ents.spawnItem({ id: 46, data: 0, count: 1 }, br.x + 0.5, br.y + 0.3, br.z + 0.5);
          } else {
            this.removeBlockSP(br.x, br.y, br.z, true);
          }
          const t = MC.Survival.toolInfo(this.heldItem().id);
          if (Blocks.list[br.id].hardness > 0) this.wearTool(t && t[0] === 'sword' ? 2 : 1);
          this.exhaustion += 0.005;
        }
        this.breaking = null;
        this.attackCooldown = this.gamemode === 1 ? 0.25 : 0.05;
        p.swingTime = 1;
      }
    }

    // Данные (ориентация) блока при установке в одиночной игре
    placeData(id, data, hit, face) {
      const p = this.player;
      const dir = yawDir(p.yaw);
      const fy = hit.hit[1] - hit.y;
      const upper = face === 0 || (face > 1 && fy > 0.5);
      if (id === 17 || id === 162 || id === 170) return (data & 3) | (face <= 1 ? 0 : face <= 3 ? 8 : 4);
      if (id === 50 || id === 75 || id === 76) return [5, 5, 4, 3, 2, 1][face];
      if (id === 93 || id === 94) return dir;
      // Поршень смотрит в сторону игрока (туда и выдвигается); командные блоки ставятся так же
      if (id === 33 || id === 29 || id === 137 || id === 188 || id === 189) {
        const d = p.lookDir();
        const ax = Math.abs(d[0]), ay = Math.abs(d[1]), az = Math.abs(d[2]);
        if (ay >= ax && ay >= az) return d[1] < 0 ? 1 : 0;
        if (az >= ax) return d[2] < 0 ? 3 : 2;
        return d[0] < 0 ? 5 : 4;
      }
      if (id === 65) return face >= 2 ? face : 2;
      if (id === 44 || id === 158 || id === 182) return (data & 7) | (upper ? 8 : 0);
      if ([53, 67, 108, 109, 114, 128, 134, 135, 136, 156, 163, 164, 180, 203].indexOf(id) >= 0) {
        return [2, 1, 3, 0][dir] | (upper ? 4 : 0);
      }
      if ([54, 61, 62, 130, 146, 23, 125, 86, 91].indexOf(id) >= 0) {
        if (id === 86 || id === 91) return [2, 3, 0, 1][dir];
        return [2, 5, 3, 4][dir];
      }
      if (GATES.has(id)) return [0, 1, 2, 3][dir];
      if (id === 96 || id === 167) return [2, 1, 3, 0][dir] | (upper ? 4 : 0);
      return data;
    }

    // Луч до ближайшей жидкости (для ведра)
    liquidRay(maxDist) {
      const p = this.player, d = p.lookDir();
      for (let t = 0.2; t < maxDist; t += 0.1) {
        const x = Math.floor(p.x + d[0] * t), y = Math.floor(p.eyeY + d[1] * t), z = Math.floor(p.z + d[2] * t);
        const id = this.world.getId(x, y, z);
        if (Blocks.list[id].liquid) return { x, y, z, id, data: this.world.getData(x, y, z) };
        if (id && Blocks.list[id].solid) return null;
      }
      return null;
    }

    consumeHeld() {
      if (this.mode === 'sp' && this.gamemode === 0) this.sinv.takeFromSlot(this.selected, 1);
    }

    setHeld(item) {
      if (this.mode !== 'sp' || this.gamemode !== 0) return;
      const cur = this.sinv.slots[this.selected];
      if (cur && cur.count > 1) {
        cur.count--;
        if (this.sinv.add(item)) this.ents.spawnItem(item, this.player.x, this.player.y + 1, this.player.z);
      } else {
        this.sinv.slots[this.selected] = item;
      }
    }

    useItem(hit, fresh) {
      const p = this.player;
      const held = this.heldItem();
      if (this.mode === 'mp') {
        const px = p.x, py = p.eyeY, pz = p.z;
        if (!hit) {
          if (held.id) this.client.sendUseItem(0, 0, 0, -1, 0, 0, 0, px, py, pz, this.selected, held, 0);
          return;
        }
        const fx = hit.hit[0] - hit.x, fy = hit.hit[1] - hit.y, fz = hit.hit[2] - hit.z;
        this.client.sendUseItem(hit.x, hit.y, hit.z, hit.face, fx, fy, fz, px, py, pz, this.selected, held, hit.id);
        this.client.sendSwing();
        p.swingTime = 1;
        if (hit.id === 58 && !p.sneaking) { this.linkHotbar(); this.openContainer('table'); return; }
        if (!this.canEdit()) return;
        if (INTERACTIVE.has(hit.id) && !p.sneaking) return;
        // Обычный блок показываем сразу; двери, кровати и прочее рисуем только после ответа сервера
        if (held.id > 0 && held.id < 256 && Blocks.list[held.id].shape === 'cube' && !INTERACTIVE.has(held.id)) this.placeLocal(hit, held.id, held.data, false);
        return;
      }
      // Фейерверк в полёте на элитрах — ускорение (как в Minecraft)
      if (held.id === 401 && p.gliding) {
        p.boostT = 1.1;
        MC.Sound.play('fireworks.launch', null, 1, 1);
        this.consumeHeld();
        return;
      }
      // Головы: ставятся на блок; третий череп скелета-иссушителя на Т из песка душ призывает иссушителя
      if (held.id === 397 && hit) {
        const rep = Blocks.list[hit.id].replaceable, F = FACE_DIR[hit.face];
        const tx = rep ? hit.x : hit.x + F[0], ty = rep ? hit.y : hit.y + F[1], tz = rep ? hit.z : hit.z + F[2];
        if (this.placeLocal(hit, 144, hit.face, false)) {
          if (!this.record.skulls) this.record.skulls = {};
          this.record.skulls[this.ckey(tx, ty, tz)] = held.data || 0;
          this.consumeHeld();
          if ((held.data || 0) === 1) this.ents.trySummonWither(tx, ty, tz);
        }
        return;
      }
      // Кристалл Края ставится на обсидиан или бедрок; четыре у портала выхода возрождают дракона
      if (held.id === 426) {
        if (this.portals.placeCrystal(hit)) { this.consumeHeld(); p.swingTime = 1; }
        return;
      }
      // Пустая бутылка набирает драконье дыхание из облака или воду
      if (held.id === 374) {
        const cloud = this.ents.breathAt(p.x, p.eyeY, p.z, p.lookDir(), 4);
        if (cloud) {
          cloud.r -= 0.5;
          MC.Sound.play('random.pop', null, 0.5, 1);
          if (this.gamemode === 0) this.setHeld({ id: 437, data: 0, count: 1 });
          else this.sinv.add({ id: 437, data: 0, count: 1 });
          return;
        }
        const l = this.liquidRay(5);
        if (l && l.id <= 9) {
          MC.Sound.event('bucket.fill.water', l.x + 0.5, l.y + 0.5, l.z + 0.5);
          if (this.gamemode === 0) this.setHeld({ id: 373, data: 0, count: 1 });
          else if (this.sinv.add({ id: 373, data: 0, count: 1 })) this.ui.setPopup('Инвентарь полон');
        }
        return;
      }
      // Вёдра работают и без блока под прицелом
      if (held.id === 325) {
        const l = this.liquidRay(5);
        if (l && l.data === 0) {
          this.world.setBlock(l.x, l.y, l.z, 0, 0);
          MC.Sound.event(l.id <= 9 ? 'bucket.fill.water' : 'bucket.fill.lava', l.x + 0.5, l.y + 0.5, l.z + 0.5);
          this.setHeld({ id: l.id <= 9 ? 326 : 327, data: 0, count: 1 });
        }
        return;
      }
      if (fresh && this.gamemode === 0 && MC.Survival.armorInfo(held.id) && this.equipArmor(held)) return;
      if (fresh && (held.id === 368 || held.id === 332 || held.id === 344 || held.id === 438 || held.id === 441)) { this.throwItem(held); return; }
      if (fresh && held.id === 381 && (!hit || hit.id !== 120)) { this.throwEye(); return; }
      if (!hit) return;
      if (!p.sneaking && this.interactSP(hit)) return;
      // Яйцо призыва: существо появляется на грани блока под прицелом
      if (held.id === 383) {
        if (!fresh) return;
        const fd0 = FACE_DIR[hit.face];
        const name = MC.Items.itemName(383, held.data);
        if (!this.ents.canSpawnFromEgg(held.data)) { this.ui.setPopup('§e' + name + ': это существо в одиночной игре не поддерживается'); return; }
        this.ents.spawnFromEgg(held.data, hit.x + fd0[0] + 0.5, hit.y + Math.max(0, fd0[1]), hit.z + fd0[2] + 0.5);
        if (this.gamemode === 0) this.consumeHeld();
        p.swingTime = 1;
        return;
      }
      let id = held.id, data = held.data;
      if (!id) return;
      const w = this.world;
      const fd = FACE_DIR[hit.face];
      if (held.id === 326 || held.id === 327) {
        const x = hit.x + fd[0], y = hit.y + fd[1], z = hit.z + fd[2];
        if (!Blocks.list[w.getId(x, y, z)].replaceable) return;
        w.setBlock(x, y, z, held.id === 326 ? 9 : 11, 0);
        MC.Sound.event(held.id === 326 ? 'bucket.empty.water' : 'bucket.empty.lava', x + 0.5, y + 0.5, z + 0.5);
        if (this.gamemode === 0) this.sinv.slots[this.selected] = { id: 325, data: 0, count: 1 };
        return;
      }
      if (held.id >= 290 && held.id <= 294) {
        if ((hit.id === 2 || hit.id === 3) && hit.face === 1 && w.getId(hit.x, hit.y + 1, hit.z) === 0) {
          w.setBlock(hit.x, hit.y, hit.z, 60, 0);
          this.wearTool(1);
          p.swingTime = 1;
        }
        return;
      }
      if (held.id === 351 && held.data === 15) {
        const steps = 2 + Math.floor(Math.random() * 4);
        if (this.growAt(hit.x, hit.y, hit.z, hit.id, hit.data, steps)) this.consumeHeld();
        p.swingTime = 1;
        return;
      }
      if (held.id === 259) {
        MC.Sound.event('ignite', hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
        if (hit.id === 46) { this.world.setBlock(hit.x, hit.y, hit.z, 0, 0); this.ents.primeTnt(hit.x, hit.y, hit.z, 4); this.wearTool(1); return; }
        // Огниво у обсидиановой рамки зажигает портал в Нижний мир, иначе ставит огонь
        if (!fresh) return;
        const fx = hit.x + fd[0], fy = hit.y + fd[1], fz = hit.z + fd[2];
        if (this.dimension !== 2 && this.portals.ignite(fx, fy, fz)) { this.wearTool(1); p.swingTime = 1; return; }
        if (this.portals.addFire(fx, fy, fz)) { this.wearTool(1); p.swingTime = 1; }
        return;
      }
      // Око Края: в рамку портала, иначе бросок — летит в сторону ближайшей крепости
      if (held.id === 381 && fresh) {
        if (hit.id === 120) { if (this.portals.placeEye(hit)) this.consumeHeld(); p.swingTime = 1; return; }
      }
      // Вода в Нижнем мире испаряется
      if (held.id === 326 && this.dimension === 1) {
        MC.Sound.play('random.fizz', { x: hit.x, y: hit.y, z: hit.z }, 0.5, 2);
        if (this.gamemode === 0) this.sinv.slots[this.selected] = { id: 325, data: 0, count: 1 };
        return;
      }
      if (id >= 256) {
        const pl = MC.Items.PLACES[id];
        if (!pl) return;
        id = pl[0];
        data = pl[1];
        // Семена и овощи сажаются только на грядку
        if ([59, 141, 142, 244, 104, 105].indexOf(id) >= 0 && (hit.id !== 60 || hit.face !== 1)) return;
        if (id === 115 && (hit.id !== 88 || hit.face !== 1)) return;
      }
      if (id === 6 || id === 31 || id === 37 || id === 38 || id === 83) {
        const ground = Blocks.list[hit.id].replaceable ? w.getId(hit.x, hit.y - 1, hit.z) : hit.face === 1 ? hit.id : -1;
        if ([2, 3, 60, 12].indexOf(ground) < 0 || (id !== 83 && ground === 12)) return;
      }
      if (this.placeLocal(hit, id, data, true)) this.consumeHeld();
    }

    // Двери, люки, калитки, верстак, печь, сундук и кровать в одиночной игре
    interactSP(hit) {
      const w = this.world;
      // Редстоун: рычаг переключается, кнопка нажимается
      if (hit.id === 69 && this.mechanics) { this.mechanics.toggleLever(hit.x, hit.y, hit.z); this.player.swingTime = 1; return true; }
      if ((hit.id === 151 || hit.id === 178) && this.mechanics) { this.mechanics.toggleSensor(hit.x, hit.y, hit.z); this.player.swingTime = 1; return true; }
      if ((hit.id === 77 || hit.id === 143) && this.mechanics) {
        if (!(hit.data & 8)) this.mechanics.pressButton(hit.x, hit.y, hit.z, hit.id);
        this.player.swingTime = 1;
        return true;
      }
      // Повторитель: правый клик меняет задержку 1..4 такта
      if ((hit.id === 93 || hit.id === 94) && this.mechanics) {
        w.setBlock(hit.x, hit.y, hit.z, hit.id, (hit.data & 3) | ((((hit.data >> 2) + 1) & 3) << 2));
        MC.Sound.play('random.click', { x: hit.x + 0.5, y: hit.y + 0.5, z: hit.z + 0.5 }, 0.3, 0.6);
        this.player.swingTime = 1;
        return true;
      }
      if (DOORS.has(hit.id)) {
        const y = hit.data & 8 ? hit.y - 1 : hit.y;
        const nd = w.getData(hit.x, y, hit.z) ^ 4;
        w.setBlock(hit.x, y, hit.z, hit.id, nd);
        w.setBlock(hit.x, y + 1, hit.z, hit.id, w.getData(hit.x, y + 1, hit.z));
        MC.Sound.play(nd & 4 ? 'random.door_open' : 'random.door_close', { x: hit.x + 0.5, y: y + 1, z: hit.z + 0.5 }, 1, 0.9 + Math.random() * 0.1);
        return true;
      }
      if (hit.id === 96 || GATES.has(hit.id)) {
        const nd = hit.data ^ (hit.id === 96 ? 8 : 4);
        w.setBlock(hit.x, hit.y, hit.z, hit.id, nd);
        MC.Sound.play(nd & (hit.id === 96 ? 8 : 4) ? 'random.door_open' : 'random.door_close', { x: hit.x + 0.5, y: hit.y + 0.5, z: hit.z + 0.5 }, 1, 0.9 + Math.random() * 0.1);
        return true;
      }
      if (hit.id === 54 || hit.id === 146 || hit.id === 130) MC.Sound.event('chest.open', hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
      if (hit.id === 58) { this.openContainer('table'); return true; }
      if (hit.id === 54 || hit.id === 146) {
        const view = this.chestView(hit.x, hit.y, hit.z, hit.id);
        this.openContainer('chest', { chest: view, title: (view.length > 27 ? 'Большой сундук' : 'Сундук') + (hit.id === 146 ? '-ловушка' : '') });
        return true;
      }
      if (hit.id === 130) {
        // Сундук Края: одно общее хранилище на весь мир, из любого такого сундука
        if (!Array.isArray(this.record.ender)) this.record.ender = new Array(27).fill(null);
        this.openContainer('chest', { chest: this.record.ender, title: 'Сундук Края' });
        return true;
      }
      if (hit.id === 61 || hit.id === 62) { this.openContainer('furnace', { furnace: this.furnaceAt(hit.x, hit.y, hit.z) }); return true; }
      if (hit.id === 117) { this.openContainer('brewing', { brew: this.brewAt(hit.x, hit.y, hit.z) }); return true; }
      if (hit.id === 26) {
        const p = this.player;
        // Кровать в Нижнем мире и Крае взрывается, как в Minecraft
        if (this.dimension) {
          this.removeBlockSP(hit.x, hit.y, hit.z, false);
          this.ents.explode(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5, 5, true, 'Взорван кроватью');
          return true;
        }
        this.record.spawn = { x: p.x, y: p.y, z: p.z };
        if (this.daylight() > 0.5) { this.ui.setPopup('Точка возрождения установлена. Спать можно только ночью'); return true; }
        if (this.ents.nearHostile(p.x, p.y, p.z, 8)) { this.ui.setPopup('§cНельзя спать: рядом монстры'); return true; }
        this.time = Math.ceil(this.time / 24000) * 24000;
        this.ui.setPopup('Доброе утро! Точка возрождения установлена');
        return true;
      }
      return false;
    }

    // Ставит блок; возвращает true, если блок поставлен
    placeLocal(hit, id, data, orient) {
      const w = this.world;
      let x = hit.x, y = hit.y, z = hit.z;
      if (!Blocks.list[hit.id].replaceable) {
        const d = FACE_DIR[hit.face];
        x += d[0]; y += d[1]; z += d[2];
      }
      if (y < 0 || y > 255) return false;
      if (!Blocks.list[w.getId(x, y, z)].replaceable) return false;
      const b = Blocks.list[id];
      if (b.solid) {
        const boxes = Blocks.collisionBoxes(id, data, w, x, y, z) || [];
        const bb = this.player.aabb(this.player.x, this.player.y, this.player.z);
        for (const c of boxes) {
          if (bb[3] > x + c[0] && bb[0] < x + c[3] && bb[4] > y + c[1] && bb[1] < y + c[4] && bb[5] > z + c[2] && bb[2] < z + c[5]) return false;
        }
      }
      const d = orient ? this.placeData(id, data, hit, hit.face) : data;
      if (this.scripts && this.scripts.emit('blockPlace', { x, y, z, id, data: d }) === false) return false;
      if (DOORS.has(id) || id === 71) {
        if (y > 254 || !Blocks.list[w.getId(x, y + 1, z)].replaceable) return false;
        w.setBlock(x, y, z, id, (yawDir(this.player.yaw) + 1) & 3);
        w.setBlock(x, y + 1, z, id, 8);
      } else if (id === 26) {
        const dir = yawDir(this.player.yaw);
        const off = [[0, 1], [-1, 0], [0, -1], [1, 0]][dir];
        if (!Blocks.list[w.getId(x + off[0], y, z + off[1])].replaceable) return false;
        w.setBlock(x, y, z, 26, dir);
        w.setBlock(x + off[0], y, z + off[1], 26, dir | 8);
      } else if (id === 54 || id === 146) {
        // Два одинаковых сундука рядом — большой сундук; третий рядом с большим поставить нельзя
        const pair = this.chestPairFor(x, y, z, id);
        if (pair === false) { this.ui.setPopup('§cРядом уже большой сундук'); return false; }
        let dd = d;
        if (pair) {
          // Обе половины смотрят в одну сторону, поперёк линии соединения
          const nd = w.getData(pair.x, y, pair.z);
          if (pair.x !== x) dd = nd === 2 || nd === 3 ? nd : (this.player.z < z + 0.5 ? 2 : 3);
          else dd = nd === 4 || nd === 5 ? nd : (this.player.x < x + 0.5 ? 4 : 5);
          if (nd !== dd) w.setBlock(pair.x, y, pair.z, id, dd);
        }
        w.setBlock(x, y, z, id, dd);
      } else {
        w.setBlock(x, y, z, id, d);
      }
      MC.Sound.block(id, 'place', x + 0.5, y + 0.5, z + 0.5);
      if (this.mode === 'mp') this.client.sendSoundEvent(5, x + 0.5, y + 0.5, z + 0.5, id);
      this.player.swingTime = 1;
      return true;
    }

    setGliding(v) {
      const p = this.player;
      p.gliding = v;
      if (this.mode === 'mp' && this.glidingSent !== v) {
        this.client.sendAction(v ? ACT.START_GLIDE : ACT.STOP_GLIDE, Math.floor(p.x), Math.floor(p.y), Math.floor(p.z), 0);
      }
      this.glidingSent = v;
      if (v) MC.Sound.play('random.bow', null, 0.6, 1.2);
    }

    // Око Края летит на 12 блоков к ближайшей крепости; в Нижнем мире и Крае не работает
    throwEye() {
      const p = this.player;
      if (this.dimension) { this.ui.setPopup('§7Око Края работает только в обычном мире'); return; }
      const s = MC.Dimensions.nearestStronghold(this.generators[0].seed, p.x, p.z);
      const dx = s.x - p.x, dz = s.z - p.z, d = Math.hypot(dx, dz) || 1;
      const k = Math.min(12, d) / d;
      // Рядом с крепостью око уходит вниз — она под землёй
      this.ents.throwEye(p.x, p.eyeY, p.z, p.x + dx * k, p.z + dz * k, d < 12 ? p.eyeY - 3 : p.eyeY + 8);
      p.swingTime = 1;
      if (this.gamemode === 0) this.consumeHeld();
    }

    // Бросок жемчуга Края, снежка или яйца (одиночная игра)
    throwItem(held) {
      const p = this.player;
      const dir = p.lookDir();
      // Зелья летят медленнее и по более крутой дуге
      const potion = held.id === 438 || held.id === 441;
      const d2 = potion ? [dir[0], dir[1] + 0.2, dir[2]] : dir;
      this.ents.throwProjectile(held, p.x + dir[0] * 0.3, p.eyeY - 0.1, p.z + dir[2] * 0.3, d2, potion ? 16 : 30);
      MC.Sound.play('random.bow', null, 0.5, 0.4 + Math.random() * 0.4);
      p.swingTime = 1;
      if (this.gamemode !== 1) {
        held.count--;
        if (held.count <= 0) this.sinv.slots[this.selected] = null;
      }
    }

    attackEntity(eid, part) {
      const p = this.player;
      if (this.scripts && this.scripts.emit('attack', { eid }) === false) return;
      p.swingTime = 1;
      if (this.pvp) this.pvp.onAttack(eid);
      this.hitParticles(eid);
      if (this.mode === 'mp') {
        this.client.sendInteract(2, eid);
        this.client.sendSwing();
        return;
      }
      const m = this.ents.list.get(eid);
      if (m && m.kind === 'fireball') { this.ents.reflectFireball(eid); return; }
      // Кристалл Края взрывается от любого удара, снаряд шалкера сбивается
      if (m && m.kind === 'crystal') { this.ents.destroyCrystal(m); return; }
      if (m && m.kind === 'bullet') { this.ents.list.delete(eid); MC.Sound.play('random.break', [m.x, m.y, m.z], 0.6, 1.4); return; }
      if (!m || m.kind !== 'mob') return;
      const held = this.heldItem();
      let dmg = MC.Survival.attackDamage(held.id);
      // Критический удар в падении
      const crit = !p.onGround && p.vy < 0 && !p.inWater;
      dmg = Math.max(0, dmg + this.effects.meleeBonus());
      if (crit) dmg = Math.floor(dmg * 1.5);
      if (this.gamemode === 1) dmg = Math.max(dmg, 20);
      // Дракон: полный урон только по голове, по телу, крыльям и хвосту — четверть + 1
      if (m.def.dragon && part && part !== 'head') dmg = dmg / 4 + Math.min(dmg, 1);
      if (this.ents.hurtMob(m, dmg, p.x, p.z, true)) {
        if (this.pvp) this.pvp.onHitConfirmed(eid, crit);
        // Опыт за убитого моба: враждебные — 5, животные — 1–3
        if (m.hp <= 0 && !m.def.dragon) this.addXp(m.def.xp || (m.def.hostile ? 5 : 1 + Math.floor(Math.random() * 3)));
        if (p.sprinting) { m.body.vx *= 1.6; m.body.vz *= 1.6; }
        const t = MC.Survival.toolInfo(held.id);
        if (t) this.wearTool(t[0] === 'sword' ? 1 : 2);
        this.exhaustion += 0.1;
      }
    }

    // Криты как в игре: удар в падении — белые искры, оружие с чарами — голубые
    hitParticles(eid) {
      const p = this.player;
      const t = this.mode === 'mp' ? this.entities.get(eid) : this.ents.list.get(eid);
      if (!t || t.kind === 'item' || (this.pvp && this.pvp.cfg.hitParticles === false)) return;
      const crit = !p.onGround && p.vy < 0 && !p.inWater && !p.flying;
      const magic = MC.Items.enchants(this.heldItem()).length > 0;
      if (!crit && !magic) return;
      const look = t.kind === 'player' ? null : MC.ENTITY_LOOK && MC.ENTITY_LOOK[t.type];
      const h = t.kind === 'player' ? 1.8 : look ? look[2][1] : 1.2;
      const bx = t.body ? t.body.x : t.x, by = t.body ? t.body.y : t.y, bz = t.body ? t.body.z : t.z;
      if (crit) this.particles.crit(bx, by, bz, h, false);
      if (magic) this.particles.crit(bx, by, bz, h, true);
    }

    // Угол обзора: зум (C или кнопка 🔍), бег расширяет обзор (+10%, в полёте +15%), плавно
    updateFov(dt, active) {
      const st = this.app.settings, c = this.pvp ? this.pvp.cfg : {};
      const base = st.fov || 70;
      const p = this.player;
      let target = base;
      if (c.dynamicFov !== false && p.sprinting) target *= p.flying ? 1.15 : 1.1;
      // Натянутый лук приближает, как в игре
      if (this.bow) target *= 1 - 0.15 * Math.min(1, (this.bow.t * this.bow.t + 2 * this.bow.t) / 3);
      this.zooming = active && this.input.zoomHeld();
      if (this.zooming) target = base / Math.max(1.5, (c.zoom || 4) * (this.zoomMul || 1));
      else this.zoomMul = 1;
      if (this.fovCur === undefined) this.fovCur = base;
      const smooth = this.zooming || this.fovCur < base * 0.9 ? c.smoothZoom !== false : true;
      this.fovCur = smooth ? this.fovCur + (target - this.fovCur) * Math.min(1, dt * 14) : target;
      this.renderer.fov = this.fovCur;
      // Наклон камеры от удара (hurt cam): быстро наклоняется и плавно возвращается
      if (this.hurtCam > 0) this.hurtCam = Math.max(0, this.hurtCam - dt * 2.2);
    }

    // Колесо мыши при зажатом зуме меняет приближение (×0.5 … ×4)
    zoomScroll(d) {
      this.zoomMul = Math.max(0.5, Math.min(4, (this.zoomMul || 1) * (d > 0 ? 0.8 : 1.25)));
    }

    applyParticleSetting() {
      const v = this.app.settings.particles || 'all';
      this.particles.enabled = v !== 'off';
      this.particles.level = v === 'less' ? 0.4 : 1;
      if (!this.particles.enabled) this.particles.clear();
    }

    // ---------- Кадр ----------
    frame(dt, active) {
      const p = this.player;
      const input = this.input;
      const now = performance.now();
      this.frames++;
      if (now - this.fpsTime > 1000) { this.fps = Math.round(this.frames * 1000 / (now - this.fpsTime)); this.frames = 0; this.fpsTime = now; this.autoResolution(); }

      if (this.mode === 'sp') this.updateChunksSP();
      this.time += dt * 20;
      if (this.scripts) this.scripts.emit('tick', dt);

      // Обзор
      const look = input.consumeLook();
      // Помощь в прицеливании (как у геймпада в Bedrock): над целью обзор медленнее, а при повороте камеры прицел мягко
      // подтягивается к центру цели. Сам по себе прицел не крутится — только когда игрок сам ведёт камеру или бьёт
      const aimLvl = this.aimLevel();
      const tgt = this.aimTarget;
      if (tgt && aimLvl !== 'off' && active && !this.dead) {
        const slow = { weak: 0.8, normal: 0.65, strong: 0.5 }[aimLvl];
        if (this.pvp && this.pvp.cfg.aimSlow !== false) { look.dx *= slow; look.dy *= slow; }
        const turning = Math.abs(look.dx) + Math.abs(look.dy) > 0.01 || input.attackHeld;
        const pull = input.touchMode || input.gamepadActive ? { weak: 2, normal: 4.5, strong: 8 }[aimLvl] : { weak: 0, normal: 1.5, strong: 3 }[aimLvl];
        if (turning && pull > 0) {
          const vx = tgt.x - p.x, vy = tgt.y + tgt.h * 0.6 - p.eyeY, vz = tgt.z - p.z;
          const wantYaw = Math.atan2(-vx, vz) * 180 / Math.PI;
          const wantPitch = Math.atan2(-vy, Math.hypot(vx, vz)) * 180 / Math.PI;
          let dy = ((wantYaw - p.yaw) % 360 + 540) % 360 - 180;
          const dp = wantPitch - p.pitch;
          const k = Math.min(1, pull * dt);
          // Не больше 3° за кадр: помощь, а не автонаведение
          look.dx += Math.max(-3, Math.min(3, dy * k));
          look.dy += Math.max(-3, Math.min(3, dp * k));
        }
      }
      this.updateFov(dt, active);
      // При зуме чувствительность падает вместе с углом обзора, как в OptiFine
      const zoomK = this.fovCur / (this.app.settings.fov || 70);
      look.dx *= zoomK; look.dy *= zoomK;
      // Свободный обзор (Freelook): камера крутится вокруг игрока, направление игрока и сервер не меняются
      if (active && input.freelookHeld()) {
        if (!this.freelook) this.freelook = { yaw: p.yaw, pitch: p.pitch };
        this.freelook.yaw = (this.freelook.yaw + look.dx) % 360;
        this.freelook.pitch = Math.max(-90, Math.min(90, this.freelook.pitch + look.dy));
      } else {
        this.freelook = null;
        if (active) {
          p.yaw = (p.yaw + look.dx) % 360;
          p.pitch = Math.max(-90, Math.min(90, p.pitch + look.dy));
        }
      }

      // Движение
      const mv = active && !this.dead ? input.move() : { forward: 0, strafe: 0, jump: false, sneak: false, sprint: false, autoJump: false };
      this.sprintControl(dt, mv);
      this.lastMove = mv;
      if (this.eating || this.bow) { mv.forward *= 0.3; mv.strafe *= 0.3; mv.sprint = false; this.sprintLatch = false; }
      const wasGround = p.onGround, wasSprint = p.sprinting, wasSneak = p.sneaking;
      const ox = p.x, oz = p.z;
      // Элитры: прыжок в падении начинает планирование, земля или вода заканчивают
      const jumpEdge = mv.jump && !this.prevJump;
      this.prevJump = mv.jump;
      const hasElytra = !!(this.armor[1] && this.armor[1].id === 444);
      if (jumpEdge && hasElytra && !p.onGround && !p.flying && !p.inWater && !p.gliding && p.vy < -1) this.setGliding(true);
      if (p.gliding && (!hasElytra || p.onGround || p.inWater || p.flying)) this.setGliding(false);
      p.speedMul = this.effects.speedMul();
      p.jumpBoost = this.effects.level(MC.Effects.E.JUMP);
      const lev = this.mode === 'sp' ? this.effects.level(MC.Effects.E.LEVITATION) : 0;
      p.levitation = lev > 0 ? 0.9 * lev : 0;
      const fall = this.traveling ? 0 : p.update(dt, mv);
      if (this.glidingSent && !p.gliding) this.setGliding(false);
      const jumped = wasGround && !p.onGround && p.vy > 0;
      this.footstepSounds(wasGround, jumped, fall, Math.hypot(p.x - ox, p.z - oz));
      if (this.mode === 'mp') {
        if (jumped) this.client.sendAction(ACT.JUMP, Math.floor(p.x), Math.floor(p.y), Math.floor(p.z), 0);
        if (wasSprint !== p.sprinting) this.client.sendAction(p.sprinting ? ACT.START_SPRINT : ACT.STOP_SPRINT, 0, 0, 0, 0);
        if (wasSneak !== p.sneaking) this.client.sendAction(p.sneaking ? ACT.START_SNEAK : ACT.STOP_SNEAK, 0, 0, 0, 0);
        this.sendMovement(now);
        this.effects.tick(dt, { heal() {}, hurt() {} });
      } else {
        this.updateSurvival(dt, fall, Math.hypot(p.x - ox, p.z - oz), jumped);
        if (p.y < -64 && this.gamemode === 1) { const s = this.spawnPoint(); p.x = s.x; p.y = s.y; p.z = s.z; p.vy = 0; }
        if (this.mechanics) this.mechanics.update(dt);
        this.portals.update(dt);
        if (!this.traveling) this.ents.update(dt);
        this.tickFurnaces(dt);
        if (this.invScreen) this.invScreen.tick();
        this.tickTimer += dt;
        if (this.tickTimer >= 1) { this.tickTimer = 0; this.randomTicks(); }
      }
      if (this.flyShown !== p.flying) { this.flyShown = p.flying; input.setFlyingButtons(p.flying); }
      if (p.swingTime > 0) p.swingTime = Math.max(0, p.swingTime - dt * 4);

      // Цель взгляда: блок и ближайшее существо
      const reach = MC.Building.reachOf(this);
      let hit = active && !this.dead ? p.raycast(reach) : null;
      // На сервере дальше его предела (от ног) не целимся: он всё равно отклонит действие
      if (hit && this.mode === 'mp' && !MC.Building.inReach(this, hit.x, hit.y, hit.z, reach)) hit = null;
      let ent = null;
      if (active && !this.dead) {
        let list;
        if (this.mode === 'mp') {
          list = [];
          for (const e of this.entities.values()) {
            if (e.kind === 'item') continue;
            const look2 = e.kind === 'player' ? [0, 0, [0.6, 1.8, 0.6]] : MC.ENTITY_LOOK[e.type] || [0, 0, [0.6, 1, 0.6]];
            list.push({ eid: e.eid, x: e.x, y: e.y, z: e.z, w: look2[2][0], h: look2[2][1] });
          }
        } else {
          list = this.ents.targets();
        }
        const margin = this.aimMargin();
        ent = p.raycastEntities(list, 3.5, margin);
        if (margin && this.pvp) ent = this.pvp.sticky(list, ent, margin);
        if (ent && hit && hit.t < ent.t) ent = null;
      }
      // Цель для подсветки и притягивания прицела в следующем кадре
      this.aimTarget = ent && ent.e ? { eid: ent.eid, x: ent.e.x, y: ent.e.y, z: ent.e.z, w: ent.e.w, h: ent.e.h, assisted: !!ent.assisted } : null;

      this.attackCooldown = Math.max(0, this.attackCooldown - dt);
      this.useCooldown = Math.max(0, this.useCooldown - dt);
      this.hitCooldown = Math.max(0, this.hitCooldown - dt);
      if (active && !this.dead) {
        const tap = input.consumeTap();
        const attack = input.consumeAttack();
        let use = input.consumeUse();
        this.updateEating(dt, hit);
        this.updateBow(dt, hit);
        if (ent && !this.bow && !this.eating && (attack || tap || (input.attackHeld && this.hitCooldown <= 0))) {
          if (this.hitCooldown <= 0) {
            this.attackEntity(ent.eid, ent.e && ent.e.part);
            this.hitCooldown = 0.2;
          }
          use = false;
          if (this.breaking) this.cancelBreak();
        } else if (!ent) {
          // Строительство фигурами: первое нажатие «ломать» задаёт фигуру, удержание после него не ломает блок
          const eb = this.building;
          const atkEdge = input.attackHeld && !this.prevAttackHeld;
          if (eb && atkEdge && eb.onAttack(hit)) this.ebHold = true;
          if (this.ebHold && !input.attackHeld) this.ebHold = false;
          if (this.ebHold || this.bow) { if (this.breaking) this.cancelBreak(); } else this.updateBreaking(dt, hit);
        }
        this.prevAttackHeld = input.attackHeld;
        // Easy Place: «использовать» на голограмме схемы ставит именно её блок
        const sv = this.schematic;
        if (sv && sv.easyPlace && !this.eating && (use || (input.useHeld && this.useCooldown <= 0)) && sv.easyUse()) {
          use = false;
          this.useCooldown = 0.2;
        }
        const eb = this.building && this.building.active() && (this.building.cfg.mode === 'copy' || this.building.buildable(this.heldItem())) ? this.building : null;
        if (eb && !this.eating) {
          // В режиме строительства блок ставится только отдельным нажатием, без повтора при удержании
          if (use && !eb.onUse(hit)) this.useItem(hit, use);
        } else if (!this.eating && !this.bow && (use || (input.useHeld && this.useCooldown <= 0))) {
          // С луком в руке «использовать» только открывает двери, сундуки и прочее; остальное — натяжение лука
          if ((use || hit) && (this.heldItem().id !== 261 || (use && hit && INTERACTIVE.has(hit.id)))) {
            this.useItem(hit, use);
            // В творческом режиме блоки ставятся быстрее при удержании — удобнее строить
            this.useCooldown = this.gamemode === 1 && input.useHeld ? 0.14 : 0.25;
          }
        }
      } else {
        if (this.breaking) this.cancelBreak();
        this.eating = null;
        this.bow = null;
      }

      // Сетевые сущности: плавное движение к последней позиции с сервера
      const k = 1 - Math.exp(-dt * 12);
      for (const e of this.entities.values()) {
        const ex = e.x, ez = e.z;
        e.x += (e.tx - e.x) * k; e.y += (e.ty - e.y) * k; e.z += (e.tz - e.z) * k;
        const dist = Math.hypot(e.x - ex, e.z - ez);
        if (e.kind === 'player') {
          e.walk += dist * 4;
          e.walkAmount += ((dt > 0 ? Math.min(1, dist / dt / 4) : 0) - e.walkAmount) * Math.min(1, dt * 10);
          if (e.swingTime > 0) e.swingTime = Math.max(0, e.swingTime - dt * 4);
        } else if (e.kind === 'mob') {
          e.walk = (e.walk || 0) + dist;
        }
        if (e.hurt > 0) e.hurt = Math.max(0, e.hurt - dt);
      }

      if (this.pvp) this.pvp.update(dt, active && !this.dead ? ent : null);
      this.particles.update(dt);
      if (this.building) this.building.update(active && !this.dead ? hit : null);
      if (this.schematic) this.schematic.update(dt);
      if (this.building) {
        const eb = this.building;
        this.ui.setBuildHint(eb.active() ? eb.hint : this.schematic.s ? this.schematic.hint() + (eb.netInfo ? ' · ' + eb.netInfo : '') : eb.netInfo);
      }
      this.rebuildMeshes(this.ready ? 6 : 20);
      this.draw(hit, dt);
      this.updateHud();

      if (this.mode === 'sp' && now - this.lastSave > 30000) {
        this.lastSave = now;
        this.save().catch((e) => console.warn('Автосохранение', e));
      }
    }

    // Шаги, прыжок и приземление звучат по материалу блока под ногами
    footstepSounds(wasGround, jumped, fall, moved) {
      const p = this.player;
      MC.Sound.setListener(p.x, p.eyeY, p.z, p.yaw);
      if (p.flying || p.inWater) { this.stepDist = 0; return; }
      const under = this.world.getId(Math.floor(p.x), Math.floor(p.y - 0.2), Math.floor(p.z));
      if (jumped && under) MC.Sound.step(under, 'jump', p.x, p.y, p.z, 0.2);
      if (!wasGround && p.onGround && under && fall > 1.2) {
        this.particles.landing(p.x, Math.floor(p.y - 0.2) + 1, p.z, under, this.world.getData(Math.floor(p.x), Math.floor(p.y - 0.2), Math.floor(p.z)), fall);
      }
      if (p.sprinting && p.onGround && under && moved > 0 && Math.random() < 0.35) {
        this.particles.sprintDust(p.x, Math.floor(p.y - 0.2) + 1, p.z, under, this.world.getData(Math.floor(p.x), Math.floor(p.y - 0.2), Math.floor(p.z)));
      }
      if (!wasGround && p.onGround && under) {
        if (fall > 3.4 && (this.mode === 'mp' || this.gamemode === 0)) MC.Sound.play(fall > 6 ? 'damage.fallbig' : 'damage.fallsmall', null, 0.75, 1);
        else if (fall > 0.6) MC.Sound.step(under, 'fall', p.x, p.y, p.z, 0.4);
      }
      if (!p.onGround || p.sneaking || !under) return;
      this.stepDist = (this.stepDist || 0) + moved;
      if (this.stepDist >= 1.67) {
        this.stepDist = 0;
        MC.Sound.step(under, 'step', p.x, p.y, p.z, 0.25);
      }
    }

    // Еда: удерживать палец/правую кнопку с едой в руке 1,6 секунды
    updateEating(dt, hit) {
      const held = this.heldItem();
      // На сервере пьются зелья и молоко (сервер сам применяет эффект), они не требуют голода
      const drink = held.id === 373 || (held.id === 325 && held.data === 1);
      const food = MC.Survival.FOOD[held.id] || drink;
      const plant = (held.id === 391 || held.id === 392 || held.id === 457) && hit && hit.id === 60;
      const always = drink || held.id === 322 || held.id === 466 || held.id === 432;
      const hungry = this.mode === 'mp' ? this.food < 20 || always : this.gamemode === 0 && (this.food < 20 || always);
      const holding = this.input.useHolding();
      if (!food || !hungry || !holding || plant) {
        this.eating = null;
        return;
      }
      if (!this.eating || this.eating.id !== held.id) {
        this.eating = { id: held.id, t: 0 };
        if (this.mode === 'mp') {
          const p = this.player;
          this.client.sendUseItem(0, 0, 0, -1, 0, 0, 0, p.x, p.eyeY, p.z, this.selected, held, 0);
        }
      }
      const before = this.eating.t;
      this.eating.t += dt;
      if (Math.floor(before / 0.25) !== Math.floor(this.eating.t / 0.25) && this.eating.t > 0.4) {
        MC.Sound.play(drink ? 'random.drink' : 'random.eat', null, 0.5 + Math.random() * 0.5, 0.8 + Math.random() * 0.4);
        if (!drink) this.particles.eat(held, this.player.x, this.player.eyeY, this.player.z, this.player.lookDir());
      }
      if (this.eating.t >= 1.6) {
        MC.Sound.event('burp');
        if (this.mode === 'mp') this.client.sendEntityEvent(9, 0);
        else this.eat(held);
        this.eating = null;
        this.useCooldown = 0.4;
      }
    }

    // Лук: удерживать «использовать», отпустить — выстрел. Сила как в Minecraft: (t² + 2t) / 3, полная через 1 секунду
    updateBow(dt, hit) {
      const held = this.heldItem();
      const holding = this.input.useHolding();
      if (held.id !== 261) { this.bow = null; return; }
      if (holding) {
        if (!this.bow) {
          if (hit && INTERACTIVE.has(hit.id) && !this.player.sneaking) return;
          if (this.mode === 'sp' && this.gamemode !== 1 && !this.bowInfinite(held) && this.findArrow() < 0) {
            const now = performance.now();
            if (!(now - this.noArrowT < 3000)) { this.noArrowT = now; this.ui.showItemName('Нет стрел: скрафтите их из кремня, палки и пера'); }
            return;
          }
          this.bow = { t: 0, slot: this.selected };
          if (this.breaking) this.cancelBreak();
          // Сервер (Nukkit) начинает натяжение по UseItem без блока и стреляет по RELEASE_ITEM
          if (this.mode === 'mp') {
            const p = this.player;
            this.client.sendUseItem(0, 0, 0, -1, 0, 0, 0, p.x, p.eyeY, p.z, this.selected, held, 0);
          }
        }
        if (this.bow.slot !== this.selected) { this.bow = null; return; }
        this.bow.t += dt;
        return;
      }
      if (!this.bow) return;
      const t = this.bow.t;
      this.bow = null;
      const p = this.player;
      if (this.mode === 'mp') {
        this.client.sendAction(ACT.RELEASE_ITEM, 0, 0, 0, 0);
        p.swingTime = 0;
        return;
      }
      const f = Math.min(1, (t * t + 2 * t) / 3);
      if (f < 0.1) return;
      let slot = -1;
      if (this.gamemode !== 1) {
        slot = this.findArrow();
        if (slot < 0) return;
      }
      const arrow = slot >= 0 ? this.sinv.slots[slot] : { id: 262, data: 0 };
      const ench = {};
      for (const e of MC.Items.enchants(held)) ench[e.id] = e.lvl;
      const infinite = this.gamemode === 1 || (ench[22] && arrow.data === 0);
      if (slot >= 0 && !infinite) this.sinv.takeFromSlot(slot, 1);
      const d = p.lookDir();
      const sp = f * 60;
      this.ents.shootArrow(p.x + d[0] * 0.2, p.eyeY - 0.1, p.z + d[2] * 0.2, d[0] * sp, d[1] * sp, d[2] * sp, {
        shooter: 'player', dmg: 2 + (ench[19] ? 0.5 * ench[19] + 0.5 : 0), crit: f >= 1, potion: arrow.data > 0 ? arrow.data - 1 : 0,
        pickup: !infinite, fire: !!ench[21], punch: ench[20] || 0
      });
      this.wearTool(1);
      this.exhaustion += 0.1;
    }

    // Уровень помощи в прицеливании: off / weak / normal / strong
    aimLevel() {
      const st = this.app.settings;
      return st.aimAssist === false ? 'off' : st.aimLevel || 'normal';
    }

    // Насколько расширяется рамка цели (блоки): на сенсоре и геймпаде больше, с мышью меньше
    aimMargin() {
      const lvl = this.aimLevel();
      if (lvl === 'off') return 0;
      const pad = this.input.touchMode || this.input.gamepadActive;
      return (pad ? { weak: 0.25, normal: 0.45, strong: 0.7 } : { weak: 0.1, normal: 0.2, strong: 0.35 })[lvl] || 0;
    }

    bowInfinite(held) { return MC.Items.enchants(held).some((e) => e.id === 22); }

    // Ячейка со стрелами (обычными или с зельем) для лука
    findArrow() {
      const s = this.sinv.slots;
      if (s[this.selected] && s[this.selected].id === 262) return this.selected;
      for (let i = 0; i < s.length; i++) if (s[i] && s[i].id === 262 && s[i].count > 0) return i;
      return -1;
    }

    sendMovement(now) {
      if (!this.ready || now - this.lastMoveSent < 50) return;
      const p = this.player;
      const s = this.lastSent;
      if (s && Math.abs(s.x - p.x) < 0.001 && Math.abs(s.y - p.y) < 0.001 && Math.abs(s.z - p.z) < 0.001 && s.yaw === p.yaw && s.pitch === p.pitch && now - this.lastMoveSent < 1000) return;
      this.lastMoveSent = now;
      this.lastSent = { x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch };
      const yaw = ((p.yaw % 360) + 360) % 360;
      this.client.sendMove(p.x, p.eyeY, p.z, yaw, p.pitch, p.onGround);
    }

    draw(hit, dt) {
      dt = dt || 0.016;
      const p = this.player;
      // В Нижнем мире и Крае нет смены дня и ночи: ровный тусклый свет
      const dim = this.dimension || 0;
      // Time Changer (мод): только своя картинка, время на сервере не меняется
      const tc = this.pvp && !dim ? this.pvp.cfg.timeChanger : 'off';
      const viewTime = tc === 'day' ? 6000 : tc === 'sunset' ? 12600 : tc === 'night' ? 18000 : this.time;
      const daylight = dim === 1 ? 0.85 : dim === 2 ? 0.8 : daylightAt(viewTime);
      const light = this.effects.has(MC.Effects.E.NIGHT_VISION) ? 1 : daylight;
      this.renderer.fullbright = !!(this.pvp && this.pvp.cfg.fullbright) || this.effects.has(MC.Effects.E.NIGHT_VISION);
      this.renderer.clearWater = !!(this.pvp && this.pvp.cfg.clearWater);
      const players = [], mobs = [], items = [], tagOnly = [], crystals = [];
      if (this.mode === 'sp') {
        const l = this.ents.sceneLists();
        mobs.push(...l.mobs);
        items.push(...l.items);
        crystals.push(...l.crystals);
      }
      const beacons = this.mode === 'sp' ? this.ents.beaconBeams() : null;
      for (const e of this.entities.values()) {
        // Невидимых (зелье, ваниш у администрации) сервер помечает флагом — не рисуем.
        // Но надпись остаётся: так серверы показывают голограммы и подписи NPC в лобби
        if (e.invisible) { if (e.nametag && e.kind !== 'item') tagOnly.push(e); continue; }
        if (e.kind === 'player') players.push(e);
        // Кристалл Края с сервера рисуется так же, как в одиночной игре
        else if (e.kind === 'mob' && e.type === 71) crystals.push({ x: e.x, y: e.y, z: e.z, age: performance.now() / 1000 + e.eid, base: true });
        else if (e.kind === 'mob') mobs.push(e);
        else items.push(e);
      }
      const eye = p.eyeY - (p.sneaking ? 0.08 : 0);
      if (!this.ownSkin) this.ownSkin = this.app.settings.skin ? MC.Skin.fromBase64(this.app.settings.skin) : MC.Skin.defaultSkin();
      // Вид от третьего лица (как в Minecraft PE): сзади или спереди, камера не проходит сквозь блоки
      // Свободный обзор показывает игрока сзади под своим углом камеры
      const fl = this.freelook;
      const view = fl ? 'back' : this.app.settings.camera || 'first';
      let cam = { x: p.x, y: eye, z: p.z, yaw: p.yaw, pitch: p.pitch };
      if (view !== 'first' && !this.dead) {
        const cy = (fl ? fl.yaw : p.yaw) * Math.PI / 180, cp = (fl ? fl.pitch : p.pitch) * Math.PI / 180;
        const d = [-Math.sin(cy) * Math.cos(cp), -Math.sin(cp), Math.cos(cy) * Math.cos(cp)];
        const sign = view === 'front' ? 1 : -1;
        let dist = 4;
        for (let t = 0.3; t <= 4; t += 0.1) {
          const id = this.world.getId(Math.floor(p.x + d[0] * t * sign), Math.floor(eye + d[1] * t * sign), Math.floor(p.z + d[2] * t * sign));
          if (id && Blocks.list[id].solid) { dist = Math.max(0.3, t - 0.3); break; }
        }
        const camYaw = fl ? fl.yaw : p.yaw, camPitch = fl ? fl.pitch : p.pitch;
        cam = { x: p.x + d[0] * dist * sign, y: eye + d[1] * dist * sign, z: p.z + d[2] * dist * sign, yaw: view === 'front' ? camYaw + 180 : camYaw, pitch: view === 'front' ? -camPitch : camPitch };
        const hs = Math.hypot(p.vx, p.vz);
        this.selfWalkAmount = (this.selfWalkAmount || 0) + ((p.onGround ? Math.min(1, hs / 4) : 0) - (this.selfWalkAmount || 0)) * 0.2;
        players.push({ eid: -1, x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch, walk: p.walkDist * 4, walkAmount: this.selfWalkAmount,
          swingTime: p.swingTime, hurt: this.invuln > 0.25 ? 0.2 : 0, skinKey: 'self', skin: this.ownSkin, armor: this.armor, held: this.heldItem(),
          sneaking: p.sneaking && !p.flying, usingBow: !!this.bow, eating: !!this.eating, gliding: !!p.gliding, scale: 1 });
      }
      if (this.hurtCam > 0 && (!this.pvp || this.pvp.cfg.hurtCam !== false)) cam.roll = 9 * Math.sin(this.hurtCam * this.hurtCam * Math.PI);
      // Покачивание камеры при ходьбе (view bobbing из Minecraft): вбок, вверх-вниз и лёгкий наклон
      const hs0 = p.onGround && !p.flying && !this.dead ? Math.hypot(p.vx, p.vz) : 0;
      this.bobAmt = (this.bobAmt || 0) + (Math.min(1.3, hs0 / 4.3) - (this.bobAmt || 0)) * Math.min(1, dt * 8);
      if (view === 'first' && this.app.settings.viewBob !== false && this.bobAmt > 0.01) {
        const ph = p.walkDist * 0.6 * Math.PI, a = this.bobAmt;
        const side = Math.sin(ph) * a * 0.045, upd = -Math.abs(Math.cos(ph)) * a * 0.07;
        const yr = cam.yaw * Math.PI / 180;
        cam.x += Math.cos(yr) * side; cam.z += Math.sin(yr) * side; cam.y += upd;
        cam.roll = (cam.roll || 0) + Math.sin(ph) * a * 1.2;
        cam.pitch += Math.abs(Math.cos(ph - 0.2)) * a * 1.0;
      }
      // Смена предмета: рука опускается и поднимается (как в Minecraft)
      const heldNow = this.heldItem();
      const heldKey = this.selected + ':' + (heldNow.id || 0) + ':' + (heldNow.data || 0);
      if (heldKey !== this.lastHeldKey) { if (this.lastHeldKey !== undefined) this.equipT = 1; this.lastHeldKey = heldKey; }
      if (this.equipT > 0) this.equipT = Math.max(0, this.equipT - dt * 5);
      if (this.pvp) this.renderer.outline = this.pvp.outlineColor();
      const scene = {
        daylight,
        dimension: dim,
        light,
        time: viewTime,
        underwater: p.headInWater,
        inLava: p.headInLava,
        players,
        entities: mobs,
        items,
        crystals,
        beacons,
        particles: this.particles,
        selection: hit ? { x: hit.x, y: hit.y, z: hit.z, boxes: hit.boxes } : null,
        aimTarget: this.aimTarget && this.app.settings.aimHighlight !== false ? this.aimTarget : null,
        build: this.building && this.building.active() ? this.building.preview : null,
        schemMarks: this.schematic ? this.schematic.marks() : null,
        breakProgress: this.breaking && this.breaking.time > 0 ? Math.min(1, this.breaking.elapsed / this.breaking.time) : 0,
        hand: this.dead || view !== 'first' ? null : {
          item: this.bow ? Object.assign({}, this.heldItem(), { data: 10000 + (this.bow.t < 0.45 ? 0 : this.bow.t < 0.9 ? 1 : 2) }) : this.heldItem(), swing: p.swingTime, walk: p.onGround ? p.walkDist * 0.6 : this.lastWalk || 0,
          skinKey: 'self', skin: this.ownSkin, daylight: light, eating: this.eating ? this.eating.t : 0, armor: this.armor,
          equip: this.equipT || 0, bow: this.bow ? this.bow.t : 0, style: this.pvp ? this.pvp.cfg.handStyle || 'modern' : 'modern', bob: this.bobAmt || 0,
          // Блокирование мечом (анимация 1.7 из PvP-клиентов): только картинка, на сервер ничего не уходит
          block: !!(this.pvp && this.pvp.cfg.blockHit !== false && !this.bow && !this.eating && MC.Survival.toolInfo(this.heldItem().id) && MC.Survival.toolInfo(this.heldItem().id)[0] === 'sword' && this.input.useHolding())
        }
      };
      if (p.onGround) this.lastWalk = p.walkDist * 0.6;
      this.renderer.render(cam, scene);
      const tags = [];
      for (const e of players) {
        if (e.eid === -1) continue;
        const d = Math.hypot(e.x - p.x, e.y - p.y, e.z - p.z);
        // В приседе ник виден только вблизи, как в игре
        if (d > (e.sneaking ? 8 : 48)) continue;
        const name = e.nametag !== undefined ? e.nametag : e.name;
        if (!name) continue;
        const s = this.renderer.project(e.x, e.y + (e.sneaking ? 2.0 : 2.15) * (e.scale > 0 ? e.scale : 1), e.z);
        if (s) tags.push({ key: String(e.eid), name, x: s.x, y: s.y, d });
      }
      // Надписи над существами: NPC в лобби серверов («SkyWars», «Магазин») и именованные мобы
      for (const e of mobs) {
        if (!e.nametag || e.eid === undefined || this.mode !== 'mp') continue;
        const d = Math.hypot(e.x - p.x, e.y - p.y, e.z - p.z);
        if (d > (e.alwaysTag ? 48 : 10)) continue;
        const look = MC.ENTITY_LOOK[e.type];
        const h = (look ? look[2][1] : 1.8) * (e.scale || 1);
        const s = this.renderer.project(e.x, e.y + h + 0.35, e.z);
        if (s) tags.push({ key: 'm' + e.eid, name: e.nametag, x: s.x, y: s.y, d });
      }
      // Голограммы: невидимая сущность с надписью (надпись на месте сущности, как в игре)
      for (const e of tagOnly) {
        const d = Math.hypot(e.x - p.x, e.y - p.y, e.z - p.z);
        if (d > 48) continue;
        const h = e.kind === 'player' ? 1.8 * (e.scale > 0 ? e.scale : 1) + 0.35 : ((MC.ENTITY_LOOK[e.type] || [0, 0, [0, 0.5, 0]])[2][1]) * (e.scale || 1) + 0.35;
        const s = this.renderer.project(e.x, e.y + h, e.z);
        if (s) tags.push({ key: 't' + e.eid, name: e.nametag, x: s.x, y: s.y, d });
      }
      if (tags.length > 40) tags.sort((a, b) => a.d - b.d);
      this.ui.setNametags(tags);
      if (this.pvp) this.pvp.drawLabels();
    }

    // Бег: «удержание» — пока зажат; «не сбрасывать» — начавшись, продолжается, пока идёте вперёд (как в Java);
    // «авто» — всегда при движении вперёд. Бег сбрасывается при упоре в стену и голоде ≤ 6, затем возобновляется сам
    sprintControl(dt, mv) {
      const p = this.player;
      const st = this.app.settings;
      const mode = st.sprintMode || (st.autoSprint ? 'auto' : 'keep');
      const fwd = mv.forward >= 0.5 && !mv.sneak;
      if (mode === 'auto' && fwd) mv.sprint = true;
      if (mode !== 'hold') {
        if (mv.sprint && fwd) this.sprintLatch = true;
        if (!fwd) this.sprintLatch = false;
        if (this.sprintLatch) mv.sprint = true;
      }
      // Упор в стену: бег выключается и включается снова через 0,3 с после того, как путь свободен
      this.wallT = p.horizontalBlocked && Math.hypot(p.vx, p.vz) < 1 && !p.flying ? 0.3 : Math.max(0, (this.wallT || 0) - dt);
      if (this.wallT > 0) mv.sprint = false;
      if (this.survival() && this.food <= 6 && !p.flying) mv.sprint = false;
      if (!mv.sprint && mode === 'hold') this.sprintLatch = false;
    }

    updateHud() {
      const items = this.hotbarItems();
      this.ui.setHotbar(items, this.selected);
      const held = items[this.selected];
      const key = this.selected + ':' + (held ? held.id + ':' + (MC.Survival.isTool(held.id) ? 0 : held.data) + ':' + MC.Items.label(held) + ':' + (held.nbt ? held.nbt.length : 0) : '');
      if (key !== this.lastItemKey) {
        this.lastItemKey = key;
        if (held && held.id) {
          const ench = MC.Items.enchants(held).map((e) => e.text).join(', ');
          this.ui.showItemName(MC.Items.label(held) + (ench ? '\n§7' + ench : ''));
        }
      }
      const survival = this.survival();
      this.ui.setStats(survival, this.health, survival ? this.food : null, MC.Survival.armorPoints(this.armor), survival && this.xpLevel !== undefined ? { level: this.xpLevel, progress: this.xpProgress || 0 } : null);
      const p = this.player;
      this.ui.setAir(survival && this.mode === 'sp' && (p.headInWater || this.air < 15) ? Math.ceil(Math.max(0, this.air) / 1.5) : null);
      const t = (((Math.floor(this.time) % 24000) + 24000) % 24000);
      // Строка в углу: FPS, пинг (зелёный < 80 мс, жёлтый < 200, красный дальше), координаты. Обновляется 4 раза в секунду
      const now = performance.now();
      if (!this.lastInfoT || now - this.lastInfoT > 250) {
        this.lastInfoT = now;
        const st = this.app.settings;
        const parts = [];
        if (st.showInfo !== false) parts.push(this.fps + ' FPS');
        if (this.mode === 'mp' && st.showPing !== false && this.client && this.client.rak) {
          const ms = Math.round(this.client.rak.latency || 0);
          parts.push((ms < 80 ? '§a' : ms < 200 ? '§e' : '§c') + 'пинг ' + ms + ' мс§r');
        }
        if (st.showInfo !== false) {
          parts.push('XYZ ' + p.x.toFixed(1) + ' ' + p.y.toFixed(1) + ' ' + p.z.toFixed(1));
          if (this.mode === 'mp') parts.push(this.opts.server.host);
          parts.push('время ' + t + (p.flying ? ' · полёт' : ''));
        }
        this.ui.setDebug(parts.join(' · '));
      }
      this.ui.tick();
    }

    // Авто-разрешение: 3 секунды ниже 28 FPS — разрешение на 10% ниже (до 50%), 3 секунды выше 50 FPS — обратно
    autoResolution() {
      const app = this.app;
      if (app.settings.autoRes === false || document.hidden || !app.active) { this.lowFps = this.highFps = 0; if (app.settings.autoRes === false && app.dynScale && app.dynScale !== 1) { app.dynScale = 1; app.resize(); } return; }
      const cur = app.dynScale || 1;
      this.lowFps = this.fps < 28 ? (this.lowFps || 0) + 1 : 0;
      this.highFps = this.fps > 50 ? (this.highFps || 0) + 1 : 0;
      let next = cur;
      if (this.lowFps >= 3 && cur > 0.5) next = Math.max(0.5, cur - 0.1);
      else if (this.highFps >= 3 && cur < 1) next = Math.min(1, cur + 0.1);
      if (next !== cur) { app.dynScale = Math.round(next * 10) / 10; app.resize(); this.lowFps = this.highFps = 0; }
    }

    toggleFly() {
      if (this.player.canFly) {
        this.player.flying = !this.player.flying;
        this.player.vy = 0;
      }
    }

    touchButton(name) {
      if (name === 'jump' || name === 'flyup') {
        const now = performance.now();
        if (now - this.lastJumpTap < 300) this.toggleFly();
        this.lastJumpTap = now;
      } else if (name === 'sneak') {
        this.input.sneakToggle = !this.input.sneakToggle;
      } else if (name === 'gm') {
        this.toggleCreativeSP();
      }
    }

    // ---------- Сохранение и выход ----------
    async save() {
      if (this.mode !== 'sp') return;
      const p = this.player;
      const id = this.storeId;
      const jobs = [];
      for (const c of this.world.chunks.values()) {
        if (!c.modified) continue;
        c.modified = false;
        jobs.push(MC.Storage.Worlds.saveChunk(id, c));
      }
      const r = this.record;
      r.player = { x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch, flying: p.flying };
      r.inventory = this.sinv.toJSON();
      delete r.hotbar;
      r.gamemode = this.gamemode;
      r.health = this.dead ? 20 : this.health;
      r.food = this.dead ? 20 : this.food;
      r.saturation = this.saturation;
      r.xp = this.xpTotal || 0;
      r.effects = this.dead ? [] : this.effects.toJSON();
      r.absorb = this.fx.absorb || 0;
      r.armor = this.armor.map((a) => (a ? { id: a.id, data: a.data, count: 1 } : null));
      delete r.fuel;
      r.time = Math.floor(this.time) % 24000;
      r.lastPlayed = Date.now();
      jobs.push(MC.Storage.Worlds.put(r));
      await Promise.all(jobs);
    }

    async stop() {
      if (this.scripts) { this.scripts.stop(); this.scripts = null; }
      this.closeInventory();
      if (this.mode === 'sp') {
        try { await this.save(); } catch (e) { console.warn('Сохранение мира', e); }
        this.ents.clear();
      }
      this.stopped = true;
      if (this.client) this.client.disconnect();
      for (const e of this.entities.values()) if (e.kind === 'player') this.renderer.dropSkin(e.skinKey);
      this.renderer.dropSkin('self');
      this.entities.clear();
      this.renderer.clearSections();
    }
  }

  MC.Game = Game;
})();
