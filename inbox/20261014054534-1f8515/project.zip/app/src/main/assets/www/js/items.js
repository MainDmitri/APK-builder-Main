// Предметы Minecraft PE 1.1: названия, иконки из атласа предметов APK и рисование иконок блоков
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const A = window.MC_ASSETS;
  const Blocks = MC.Blocks;

  const DYES = ['black', 'red', 'green', 'brown', 'blue', 'purple', 'cyan', 'silver', 'gray', 'pink', 'lime', 'yellow', 'light_blue', 'magenta', 'orange', 'white'];
  const DYES_RU = ['Чёрный', 'Красный', 'Зелёный', 'Коричневый', 'Синий', 'Фиолетовый', 'Бирюзовый', 'Светло-серый', 'Серый', 'Розовый', 'Лаймовый', 'Жёлтый', 'Голубой', 'Пурпурный', 'Оранжевый', 'Белый'];

  // Зелья MCPE 1.1 по data: [эффект для текстуры, название эффекта, вариант (+ долгое, II усиленное)]
  const POTIONS = [
    [null, 'Бутылка воды'], [null, 'Непримечательное зелье'], [null, 'Непримечательное зелье', '+'], [null, 'Густое зелье'], [null, 'Грубое зелье'],
    ['nightVision', 'ночного зрения'], ['nightVision', 'ночного зрения', '+'], ['invisibility', 'невидимости'], ['invisibility', 'невидимости', '+'],
    ['jump', 'прыгучести'], ['jump', 'прыгучести', '+'], ['jump', 'прыгучести', 'II'], ['fireResistance', 'огнестойкости'], ['fireResistance', 'огнестойкости', '+'],
    ['moveSpeed', 'стремительности'], ['moveSpeed', 'стремительности', '+'], ['moveSpeed', 'стремительности', 'II'],
    ['moveSlowdown', 'медлительности'], ['moveSlowdown', 'медлительности', '+'], ['waterBreathing', 'подводного дыхания'], ['waterBreathing', 'подводного дыхания', '+'],
    ['heal', 'исцеления'], ['heal', 'исцеления', 'II'], ['harm', 'вреда'], ['harm', 'вреда', 'II'],
    ['poison', 'отравления'], ['poison', 'отравления', '+'], ['poison', 'отравления', 'II'], ['regeneration', 'регенерации'], ['regeneration', 'регенерации', '+'],
    ['regeneration', 'регенерации', 'II'], ['damageBoost', 'силы'], ['damageBoost', 'силы', '+'], ['damageBoost', 'силы', 'II'],
    ['weakness', 'слабости'], ['weakness', 'слабости', '+'], ['wither', 'разложения', 'II']
  ];
  // Наконечники стрел (у стрелы data = номер зелья + 1)
  const ARROW_TEX = { nightVision: 'nightvision', invisibility: 'invisibility', jump: 'leaping', fireResistance: 'fireres', moveSpeed: 'swift', moveSlowdown: 'slow',
    waterBreathing: 'waterbreathing', heal: 'healing', harm: 'harm', poison: 'poison', regeneration: 'regen', damageBoost: 'strength', weakness: 'weakness', wither: 'wither' };
  function potionTex(prefix, base) {
    return (d) => { const p = POTIONS[d]; return p && p[0] ? prefix + p[0] : base; };
  }
  function potionName(kind, d) {
    const p = POTIONS[d];
    if (!p) return kind;
    const suffix = p[2] ? ' ' + p[2] : '';
    if (p[0]) return kind + ' ' + p[1] + suffix;
    if (kind === 'Зелье') return p[1] + suffix;
    return kind + ' (' + (d === 0 ? 'вода' : p[1].split(' ')[0].toLowerCase()) + ')' + suffix;
  }

  // Яйца призыва по типу существа: [название, текстура]
  const EGGS = {
    10: ['курицы', 'chicken'], 11: ['коровы', 'cow'], 12: ['свиньи', 'pig'], 13: ['овцы', 'sheep'], 14: ['волка', 'wolf'], 15: ['жителя', 'villager'],
    16: ['грибной коровы', 'mushroomcow'], 17: ['спрута', 'squid'], 18: ['кролика', 'rabbit'], 19: ['летучей мыши', 'bat'], 22: ['оцелота', 'ocelot'],
    23: ['лошади', 'horse'], 24: ['осла', 'donkey'], 25: ['мула', 'mule'], 26: ['лошади-скелета', 'skeletonhorse'], 27: ['лошади-зомби', 'zombiehorse'],
    28: ['белого медведя', 'polarbear'], 29: ['ламы', 'llama'], 32: ['зомби', 'zombie'], 33: ['крипера', 'creeper'], 34: ['скелета', 'skeleton'],
    35: ['паука', 'spider'], 36: ['зомби-свиночеловека', 'pigzombie'], 37: ['слизня', 'slime'], 38: ['эндермена', 'enderman'], 39: ['чешуйницы', 'silverfish'],
    40: ['пещерного паука', 'cave_spider'], 41: ['гаста', 'ghast'], 42: ['магмового куба', 'lava_slime'], 43: ['ифрита', 'blaze'], 44: ['зомби-жителя', 'zombie'],
    45: ['ведьмы', 'witch'], 46: ['зимогора', 'stray'], 47: ['кадавра', 'husk'], 48: ['скелета-иссушителя', 'wither'], 49: ['стража', 'guardian'],
    50: ['древнего стража', 'elderguardian'], 51: ['NPC', 'npc'], 54: ['шалкера', 'shulker'], 55: ['эндермита', 'endermite'], 57: ['поборника', 'vindicator'],
    104: ['вызывателя', 'evoker'], 105: ['вредины', 'vex']
  };

  // id: [название, текстура | функция(data) -> текстура]
  const ITEMS = {
    256: ['Железная лопата', 'iron_shovel'], 257: ['Железная кирка', 'iron_pickaxe'], 258: ['Железный топор', 'iron_axe'],
    259: ['Огниво', 'flint_and_steel'], 260: ['Яблоко', 'apple'], 261: ['Лук', (d) => d >= 10000 ? 'bow_pulling_' + Math.min(2, d - 10000) : 'bow_standby'],
    262: ['Стрела', (d) => { const p = POTIONS[d - 1]; return p && p[0] ? 'tipped_arrow_' + ARROW_TEX[p[0]] : 'arrow'; }],
    263: ['Уголь', (d) => (d === 1 ? 'charcoal' : 'coal')], 264: ['Алмаз', 'diamond'], 265: ['Железный слиток', 'iron_ingot'],
    266: ['Золотой слиток', 'gold_ingot'], 267: ['Железный меч', 'iron_sword'], 268: ['Деревянный меч', 'wood_sword'],
    269: ['Деревянная лопата', 'wood_shovel'], 270: ['Деревянная кирка', 'wood_pickaxe'], 271: ['Деревянный топор', 'wood_axe'],
    272: ['Каменный меч', 'stone_sword'], 273: ['Каменная лопата', 'stone_shovel'], 274: ['Каменная кирка', 'stone_pickaxe'],
    275: ['Каменный топор', 'stone_axe'], 276: ['Алмазный меч', 'diamond_sword'], 277: ['Алмазная лопата', 'diamond_shovel'],
    278: ['Алмазная кирка', 'diamond_pickaxe'], 279: ['Алмазный топор', 'diamond_axe'], 280: ['Палка', 'stick'], 281: ['Миска', 'bowl'],
    282: ['Грибной суп', 'mushroom_stew'], 283: ['Золотой меч', 'gold_sword'], 284: ['Золотая лопата', 'gold_shovel'],
    285: ['Золотая кирка', 'gold_pickaxe'], 286: ['Золотой топор', 'gold_axe'], 287: ['Нить', 'string'], 288: ['Перо', 'feather'],
    289: ['Порох', 'gunpowder'], 290: ['Деревянная мотыга', 'wood_hoe'], 291: ['Каменная мотыга', 'stone_hoe'], 292: ['Железная мотыга', 'iron_hoe'],
    293: ['Алмазная мотыга', 'diamond_hoe'], 294: ['Золотая мотыга', 'gold_hoe'], 295: ['Семена пшеницы', 'seeds_wheat'], 296: ['Пшеница', 'wheat'],
    297: ['Хлеб', 'bread'], 298: ['Кожаный шлем', 'leather_helmet'], 299: ['Кожаная куртка', 'leather_chestplate'], 300: ['Кожаные штаны', 'leather_leggings'],
    301: ['Кожаные ботинки', 'leather_boots'], 302: ['Кольчужный шлем', 'chainmail_helmet'], 303: ['Кольчужная кираса', 'chainmail_chestplate'],
    304: ['Кольчужные поножи', 'chainmail_leggings'], 305: ['Кольчужные ботинки', 'chainmail_boots'], 306: ['Железный шлем', 'iron_helmet'],
    307: ['Железная кираса', 'iron_chestplate'], 308: ['Железные поножи', 'iron_leggings'], 309: ['Железные ботинки', 'iron_boots'],
    310: ['Алмазный шлем', 'diamond_helmet'], 311: ['Алмазная кираса', 'diamond_chestplate'], 312: ['Алмазные поножи', 'diamond_leggings'],
    313: ['Алмазные ботинки', 'diamond_boots'], 314: ['Золотой шлем', 'gold_helmet'], 315: ['Золотая кираса', 'gold_chestplate'],
    316: ['Золотые поножи', 'gold_leggings'], 317: ['Золотые ботинки', 'gold_boots'], 318: ['Кремень', 'flint'], 319: ['Сырая свинина', 'porkchop_raw'],
    320: ['Жареная свинина', 'porkchop_cooked'], 321: ['Картина', 'painting'], 322: ['Золотое яблоко', 'apple_golden'], 323: ['Табличка', 'sign'],
    324: ['Дубовая дверь', 'door_wood'], 325: ['Ведро', (d) => (d === 1 ? 'bucket_milk' : d === 8 ? 'bucket_water' : d === 10 ? 'bucket_lava' : 'bucket_empty')],
    328: ['Вагонетка', 'minecart_normal'], 329: ['Седло', 'saddle'], 330: ['Железная дверь', 'door_iron'], 331: ['Редстоун', 'redstone_dust'],
    332: ['Снежок', 'snowball'], 333: ['Лодка', (d) => ['boat_oak', 'boat_spruce', 'boat_birch', 'boat_jungle', 'boat_acacia', 'boat_darkoak'][d] || 'boat_oak'],
    334: ['Кожа', 'leather'], 336: ['Кирпич', 'brick'], 337: ['Комок глины', 'clay_ball'], 338: ['Сахарный тростник', 'reeds'], 339: ['Бумага', 'paper'],
    340: ['Книга', 'book_normal'], 341: ['Слизь', 'slimeball'], 342: ['Вагонетка с сундуком', 'minecart_chest'], 344: ['Яйцо', 'egg'],
    345: ['Компас', 'compass_item'], 346: ['Удочка', 'fishing_rod_uncast'], 347: ['Часы', 'clock_item'], 348: ['Светопыль', 'glowstone_dust'],
    349: ['Сырая рыба', (d) => ['fish_raw', 'fish_salmon_raw', 'fish_clownfish_raw', 'fish_pufferfish_raw'][d] || 'fish_raw'],
    350: ['Жареная рыба', (d) => (d === 1 ? 'fish_salmon_cooked' : 'fish_cooked')], 351: ['Краситель', (d) => 'dye_powder_' + (DYES[d] || 'black')],
    352: ['Кость', 'bone'], 353: ['Сахар', 'sugar'], 354: ['Торт', 'cake'], 355: ['Кровать', (d) => 'bed_' + (Blocks.COLORS[d] || 'red')],
    356: ['Повторитель', 'repeater'], 357: ['Печенье', 'cookie'], 358: ['Карта', 'map_filled'], 359: ['Ножницы', 'shears'], 360: ['Ломтик арбуза', 'melon'],
    361: ['Семена тыквы', 'seeds_pumpkin'], 362: ['Семена арбуза', 'seeds_melon'], 363: ['Сырая говядина', 'beef_raw'], 364: ['Стейк', 'beef_cooked'],
    365: ['Сырая курица', 'chicken_raw'], 366: ['Жареная курица', 'chicken_cooked'], 367: ['Гнилая плоть', 'rotten_flesh'], 368: ['Жемчуг Края', 'ender_pearl'],
    369: ['Огненный стержень', 'blaze_rod'], 370: ['Слеза гаста', 'ghast_tear'], 371: ['Золотой самородок', 'gold_nugget'], 372: ['Адский нарост', 'nether_wart'],
    373: ['Зелье', potionTex('potion_bottle_', 'potion_bottle_drinkable')], 374: ['Пузырёк', 'potion_bottle_empty'], 375: ['Паучий глаз', 'spider_eye'],
    376: ['Маринованный паучий глаз', 'spider_eye_fermented'], 377: ['Огненный порошок', 'blaze_powder'], 378: ['Сгусток магмы', 'magma_cream'],
    379: ['Варочная стойка', 'brewing_stand'], 380: ['Котёл', 'cauldron'], 381: ['Око Края', 'ender_eye'], 382: ['Сверкающий ломтик арбуза', 'melon_speckled'],
    383: ['Яйцо призыва', (d) => (EGGS[d] ? 'egg_' + EGGS[d][1] : 'spawn_egg')], 384: ['Пузырёк опыта', 'experience_bottle'], 385: ['Огненный шар', 'fireball'], 386: ['Книга и перо', 'book_writable'],
    387: ['Написанная книга', 'book_written'], 388: ['Изумруд', 'emerald'], 389: ['Рамка', 'item_frame'], 390: ['Цветочный горшок', 'flower_pot'],
    391: ['Морковь', 'carrot'], 392: ['Картофель', 'potato'], 393: ['Печёный картофель', 'potato_baked'], 394: ['Ядовитый картофель', 'potato_poisonous'],
    395: ['Пустая карта', 'map_empty'], 396: ['Золотая морковь', 'carrot_golden'],
    397: ['Голова', (d) => ['skull_skeleton', 'skull_wither', 'skull_zombie', 'skull_steve', 'skull_creeper', 'skull_dragon'][d] || 'skull_skeleton'],
    398: ['Удочка с морковкой', 'carrot_on_a_stick'], 399: ['Звезда Нижнего мира', 'nether_star'], 400: ['Тыквенный пирог', 'pumpkin_pie'],
    403: ['Зачарованная книга', 'book_enchanted'], 404: ['Компаратор', 'comparator'], 405: ['Адский кирпич', 'netherbrick'], 406: ['Кварц', 'quartz'],
    407: ['Вагонетка с динамитом', 'minecart_tnt'], 408: ['Вагонетка с воронкой', 'minecart_hopper'], 409: ['Осколок призмарина', 'prismarine_shard'],
    410: ['Воронка', 'hopper'], 411: ['Сырая крольчатина', 'rabbit_raw'], 412: ['Жареная крольчатина', 'rabbit_cooked'], 413: ['Тушёный кролик', 'rabbit_stew'],
    414: ['Кроличья лапка', 'rabbit_foot'], 415: ['Кроличья шкурка', 'rabbit_hide'], 416: ['Кожаная конская броня', 'leather_horse_armor'],
    417: ['Железная конская броня', 'iron_horse_armor'], 418: ['Золотая конская броня', 'gold_horse_armor'], 419: ['Алмазная конская броня', 'diamond_horse_armor'],
    420: ['Поводок', 'lead'], 421: ['Бирка', 'name_tag'], 422: ['Кристаллы призмарина', 'prismarine_crystals'], 423: ['Сырая баранина', 'mutton_raw'],
    424: ['Жареная баранина', 'mutton_cooked'], 426: ['Кристалл Края', 'end_crystal'], 427: ['Еловая дверь', 'door_spruce'], 428: ['Берёзовая дверь', 'door_birch'],
    429: ['Тропическая дверь', 'door_jungle'], 430: ['Дверь из акации', 'door_acacia'], 431: ['Дверь из тёмного дуба', 'door_dark_oak'],
    432: ['Плод хоруса', 'chorus_fruit'], 433: ['Приготовленный плод хоруса', 'chorus_fruit_popped'], 437: ['Драконье дыхание', 'dragons_breath'],
    438: ['Взрывное зелье', potionTex('potion_bottle_splash_', 'potion_bottle_splash')],
    441: ['Оседающее зелье', potionTex('potion_bottle_lingering_', 'potion_bottle_lingering_empty')], 444: ['Элитры', (d) => (d >= 431 ? 'broken_elytra' : 'elytra')],
    445: ['Панцирь шалкера', 'shulker_shell'], 450: ['Тотем бессмертия', 'totem'], 452: ['Железный самородок', 'iron_nugget'], 457: ['Свёкла', 'beetroot'],
    458: ['Семена свёклы', 'seeds_beetroot'], 459: ['Свекольный суп', 'beetroot_soup'], 460: ['Сырой лосось', 'fish_salmon_raw'],
    461: ['Тропическая рыба', 'fish_clownfish_raw'], 462: ['Иглобрюх', 'fish_pufferfish_raw'], 463: ['Жареный лосось', 'fish_salmon_cooked'],
    466: ['Зачарованное золотое яблоко', 'apple_golden'],
    454: ['Доска', (d) => ['chalkboard_small', 'chalkboard_medium', 'chalkboard_large'][d] || 'chalkboard_small'], 456: ['Портфолио', 'book_portfolio'], 498: ['Фотоаппарат', 'camera'],
    500: ['Пластинка', 'record_13'], 501: ['Пластинка', 'record_cat'], 502: ['Пластинка', 'record_blocks'], 503: ['Пластинка', 'record_chirp'],
    504: ['Пластинка', 'record_far'], 505: ['Пластинка', 'record_mall'], 506: ['Пластинка', 'record_mellohi'], 507: ['Пластинка', 'record_stal'],
    508: ['Пластинка', 'record_strad'], 509: ['Пластинка', 'record_ward'], 510: ['Пластинка', 'record_11'], 511: ['Пластинка', 'record_wait']
  };

  // Какие предметы ставят блок (для мгновенного отображения установки)
  const PLACES = { 324: [64, 0], 330: [71, 0], 427: [193, 0], 428: [194, 0], 429: [195, 0], 430: [196, 0], 431: [197, 0], 338: [83, 0],
    354: [92, 0], 331: [55, 0], 356: [93, 0], 404: [149, 0], 379: [117, 0], 380: [118, 0], 390: [140, 0], 295: [59, 0], 361: [104, 0],
    362: [105, 0], 391: [141, 0], 392: [142, 0], 458: [244, 0], 372: [115, 0], 410: [154, 0] };

  function itemName(id, data) {
    if (id < 256) {
      if (id === 0) return '';
      if (id === 51 && data === 1) return 'Огонь';
      return Blocks.displayName(id, data);
    }
    const it = ITEMS[id];
    if (!it) return 'Предмет #' + id;
    if (id === 351) return DYES_RU[data] ? DYES_RU[data] + ' краситель' : it[0];
    if (id === 373 || id === 438 || id === 441) return potionName(it[0], data);
    if (id === 262) { const p = POTIONS[data - 1]; return p && p[0] ? 'Стрела ' + p[1] + (p[2] ? ' ' + p[2] : '') : it[0]; }
    if (id === 383) return EGGS[data] ? 'Яйцо призыва ' + EGGS[data][0] : it[0];
    if (id === 454) return ['Маленькая доска', 'Доска для объявлений', 'Большая доска'][data] || it[0];
    return it[0];
  }

  function itemTexture(id, data) {
    const it = ITEMS[id];
    if (!it) return null;
    const name = typeof it[1] === 'function' ? it[1](data) : it[1];
    return A.itemTiles[name] !== undefined ? A.itemTiles[name] : null;
  }

  // ---------- Иконки: изометрический куб для блоков, плоская картинка для остальных ----------
  const iconCache = new Map();
  let blockImg = null, itemImg = null;

  function loadImages() {
    return Promise.all([A.blockAtlas, A.itemAtlas].map((src) => new Promise((res, rej) => {
      const im = new Image();
      im.onload = () => res(im);
      im.onerror = () => rej(new Error('Не удалось загрузить атлас текстур'));
      im.src = src;
    }))).then(([b, i]) => { blockImg = b; itemImg = i; });
  }

  function tileXY(index, grid) { return [(index % grid) * 16, Math.floor(index / grid) * 16]; }

  function drawFace(ctx, img, grid, tile, transform, shade) {
    const [sx, sy] = tileXY(tile, grid);
    ctx.save();
    ctx.setTransform(transform[0], transform[1], transform[2], transform[3], transform[4], transform[5]);
    ctx.drawImage(img, sx, sy, 16, 16, 0, 0, 16, 16);
    if (shade < 1) {
      ctx.globalCompositeOperation = 'source-atop';
      ctx.fillStyle = 'rgba(0,0,0,' + (1 - shade) + ')';
      ctx.fillRect(0, 0, 16, 16);
    }
    ctx.restore();
  }

  function icon(id, data) {
    const key = id + ':' + data;
    if (iconCache.has(key)) return iconCache.get(key);
    const c = document.createElement('canvas');
    c.width = 32;
    c.height = 32;
    const ctx = c.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    let url = '';
    if (id > 0 && id < 256 && blockImg) {
      const b = Blocks.list[id];
      const flat = b.shape === 'cross' || b.shape === 'crop' || b.shape === 'torch' || b.shape === 'flat' || id === 65 || id === 106 || id === 101 || id === 102 || id === 160;
      const d = b.variants > 1 ? data : data & 0;
      if (flat) {
        const [sx, sy] = tileXY(b.tex(d, 2), A.blockGrid);
        ctx.drawImage(blockImg, sx, sy, 16, 16, 0, 0, 32, 32);
      } else {
        const tmp = document.createElement('canvas');
        tmp.width = 32;
        tmp.height = 32;
        const t = tmp.getContext('2d');
        t.imageSmoothingEnabled = false;
        // Верх, левая (юг) и правая (восток) грани в изометрии
        drawFace(t, blockImg, A.blockGrid, b.tex(d, 1), [1, 0.5, -1, 0.5, 16, 0], 1);
        drawFace(t, blockImg, A.blockGrid, b.tex(d, 3), [1, 0.5, 0, 1, 0, 8], 0.8);
        drawFace(t, blockImg, A.blockGrid, b.tex(d, 5), [1, -0.5, 0, 1, 16, 16], 0.6);
        ctx.drawImage(tmp, 0, 0);
      }
      url = c.toDataURL();
    } else if (id >= 256 && itemImg) {
      const tile = itemTexture(id, data);
      if (tile !== null) {
        const [sx, sy] = tileXY(tile, A.itemGrid);
        ctx.drawImage(itemImg, sx, sy, 16, 16, 0, 0, 32, 32);
      } else {
        const [sx, sy] = tileXY(Blocks.MISSING, A.blockGrid);
        ctx.drawImage(blockImg, sx, sy, 16, 16, 0, 0, 32, 32);
      }
      url = c.toDataURL();
    }
    iconCache.set(key, url);
    return url;
  }

  // Набор предметов для одиночной игры (творческий режим)
  function creativeList() {
    const list = [];
    // Пропускаем только технические блоки, жидкости, активные дубли (горящая печь, лампа вкл и т. п.)
    // и блоки, которые ставятся предметом (двери, грядки, проводка и т. д.) — они уже есть как предметы
    const skip = new Set([0, 8, 9, 10, 11, 26, 34, 36, 51, 119, 55, 59, 62, 63, 64, 68, 71, 74, 75, 83, 90, 92, 93, 94, 95, 104, 105, 115, 117, 118, 120, 124, 127, 132, 140, 141, 142, 144, 149, 150, 154, 178, 193, 194, 195, 196, 197, 199, 209, 210, 211, 212, 244, 247, 248, 249, 250, 252, 255]);
    for (let id = 1; id < 256; id++) {
      if (skip.has(id)) continue;
      const b = Blocks.list[id];
      if (b.name.startsWith('Блок #')) continue;
      const n = b.variants || 1;
      for (let d = 0; d < n; d++) list.push({ id, data: d, count: 64 });
    }
    // Предметы: инструменты, еда, броня, элитры, жемчуг Края и прочее; красители — все 16 цветов
    for (const key of Object.keys(ITEMS)) {
      const id = +key;
      if (id < 256) continue;
      const it = ITEMS[id];
      if (typeof it[1] === 'function') {
        if (id === 351) { for (let d = 0; d < 16; d++) list.push({ id, data: d, count: 64 }); }
        else if (id === 373 || id === 438 || id === 441) { for (let d = 0; d < POTIONS.length; d++) list.push({ id, data: d, count: 1 }); }
        else if (id === 262) { list.push({ id, data: 0, count: 64 }); for (let d = 5; d < POTIONS.length; d++) list.push({ id, data: d + 1, count: 64 }); }
        else if (id === 383) { for (const k of Object.keys(EGGS)) list.push({ id, data: +k, count: 64 }); }
        else if (id === 454) { for (let d = 0; d < 3; d++) list.push({ id, data: d, count: 16 }); }
        else if (A.itemTiles[it[1](0)] !== undefined) list.push({ id, data: 0, count: 64 });
      } else if (A.itemTiles[it[1]] !== undefined) {
        list.push({ id, data: 0, count: 64 });
      }
    }
    return list;
  }

  // ---------- NBT Bedrock (little-endian): имя и описание предмета от сервера ----------
  // network = true — сетевой вариант (числа и длины в varint), как в BlockEntityData
  function readNbt(bytes, network) {
    if (!bytes || !bytes.length) return null;
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let o = 0;
    const uvar = () => { let v = 0, sh = 0, b; do { b = bytes[o++]; v += (b & 0x7f) * Math.pow(2, sh); sh += 7; } while (b & 0x80 && sh < 70); return v; };
    const zz = () => { const v = uvar(); return v % 2 ? -(v + 1) / 2 : v / 2; };
    const int = () => { if (network) return zz(); const v = dv.getInt32(o, true); o += 4; return v; };
    const str = () => { const n = network ? uvar() : dv.getUint16(o, true); if (!network) o += 2; const t = new TextDecoder().decode(bytes.subarray(o, o + n)); o += n; return t; };
    const payload = (t) => {
      switch (t) {
        case 1: return dv.getInt8(o++);
        case 2: { const v = dv.getInt16(o, true); o += 2; return v; }
        case 3: return int();
        case 4: { if (network) return zz(); const v = Number(dv.getBigInt64(o, true)); o += 8; return v; }
        case 5: { const v = dv.getFloat32(o, true); o += 4; return v; }
        case 6: { const v = dv.getFloat64(o, true); o += 8; return v; }
        case 7: { const n = int(); const v = bytes.slice(o, o + n); o += n; return v; }
        case 8: return str();
        case 9: { const et = bytes[o++]; const n = int(); const a = []; for (let i = 0; i < n; i++) a.push(payload(et)); return a; }
        case 10: { const c = {}; for (;;) { const tt = bytes[o++]; if (!tt) break; const name = str(); c[name] = payload(tt); } return c; }
        case 11: { const n = int(); const a = []; for (let i = 0; i < n; i++) a.push(int()); return a; }
        default: throw new Error('NBT: тип ' + t);
      }
    };
    try {
      const t = bytes[o++];
      if (t !== 10) return null;
      str();
      return payload(10);
    } catch (e) {
      return null;
    }
  }

  const nbtCache = new WeakMap();
  function itemNbt(it) {
    if (!it || !it.nbt || !it.nbt.length || !(it.nbt instanceof Uint8Array)) return null;
    if (nbtCache.has(it.nbt)) return nbtCache.get(it.nbt);
    const v = readNbt(it.nbt, false);
    nbtCache.set(it.nbt, v);
    return v;
  }

  // Имя предмета с учётом названия от сервера (например, «§aSkyWars» в меню выбора сервера)
  function label(it) {
    if (!it || !it.id) return '';
    const n = itemNbt(it);
    if (n && n.display && typeof n.display.Name === 'string' && n.display.Name) return n.display.Name;
    return itemName(it.id, MC.Survival && MC.Survival.isTool(it.id) || it.data < 0 ? 0 : it.data);
  }

  // Чары MCPE 1.1: список ench [{id, lvl}] в NBT предмета (у книг — тоже ench или StoredEnchantments)
  const ENCH = ['Защита', 'Огнеупорность', 'Невесомость', 'Взрывоустойчивость', 'Защита от снарядов', 'Шипы', 'Подводное дыхание',
    'Подводная ходьба', 'Подводник', 'Острота', 'Небесная кара', 'Бич членистоногих', 'Отдача', 'Заговор огня', 'Добыча',
    'Эффективность', 'Шёлковое касание', 'Прочность', 'Удача', 'Сила', 'Откидывание', 'Горящая стрела', 'Бесконечность',
    'Везучий рыбак', 'Приманка', 'Ледоход', 'Починка', 'Проклятие несъёмности', 'Проклятие утраты'];
  const ROMAN = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];
  function enchants(it) {
    const n = itemNbt(it);
    if (!n) return [];
    const list = Array.isArray(n.ench) ? n.ench : Array.isArray(n.StoredEnchantments) ? n.StoredEnchantments : [];
    return list.filter((e) => e && typeof e.id === 'number').map((e) => {
      const lvl = typeof e.lvl === 'number' ? e.lvl : 1;
      const name = ENCH[e.id] || 'Чары #' + e.id;
      return { id: e.id, lvl, text: name + (ENCH[e.id] && (e.id === 16 || e.id === 22 || e.id === 8 || e.id === 26 || e.id >= 27) && lvl === 1 ? '' : ' ' + (ROMAN[lvl] || lvl)) };
    });
  }
  // Блеск чар: зачарованные предметы, зачарованная книга и зачарованное золотое яблоко
  function glint(it) { return !!it && !!it.id && (it.id === 403 || it.id === 466 || it.id === 384 || it.id === 399 || enchants(it).length > 0); }

  function lore(it) {
    const n = itemNbt(it);
    return n && n.display && Array.isArray(n.display.Lore) ? n.display.Lore.filter((x) => typeof x === 'string') : [];
  }

  // Слой блеска поверх иконки: анимированный градиент по форме самого предмета (маска — его иконка)
  function addGlint(parent, it, url) {
    if (!glint(it)) return;
    const g = document.createElement('div');
    g.className = 'glint';
    g.style.webkitMaskImage = g.style.maskImage = 'url(' + url + ')';
    parent.appendChild(g);
  }

  MC.Items = { POTIONS, EGGS, itemName, itemTexture, icon, loadImages, creativeList, PLACES, readNbt, label, lore, enchants, glint, addGlint };
})();
