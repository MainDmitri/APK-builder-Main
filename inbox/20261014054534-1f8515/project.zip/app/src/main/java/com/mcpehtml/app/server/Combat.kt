package com.mcpehtml.app.server

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.sqrt

// Эффекты зелий, лук и снаряды на своём сервере: стрелы, взрывные и оседающие зелья, снежки, яйца, жемчуг Края.
// Таблицы те же, что в client/js/effects.js
object Potions {
    const val SPEED = 1; const val SLOWNESS = 2; const val HASTE = 3; const val FATIGUE = 4; const val STRENGTH = 5
    const val HEAL = 6; const val HARM = 7; const val JUMP = 8; const val NAUSEA = 9; const val REGEN = 10
    const val RESISTANCE = 11; const val FIRE_RES = 12; const val WATER_BREATHING = 13; const val INVISIBILITY = 14
    const val BLINDNESS = 15; const val NIGHT_VISION = 16; const val HUNGER = 17; const val WEAKNESS = 18
    const val POISON = 19; const val WITHER = 20; const val ABSORPTION = 22; const val SATURATION = 23

    // data зелья -> [эффект, секунды, уровень]
    val POTION: Array<IntArray?> = arrayOf(
        null, null, null, null, null,
        intArrayOf(NIGHT_VISION, 180, 0), intArrayOf(NIGHT_VISION, 480, 0),
        intArrayOf(INVISIBILITY, 180, 0), intArrayOf(INVISIBILITY, 480, 0),
        intArrayOf(JUMP, 180, 0), intArrayOf(JUMP, 480, 0), intArrayOf(JUMP, 90, 1),
        intArrayOf(FIRE_RES, 180, 0), intArrayOf(FIRE_RES, 480, 0),
        intArrayOf(SPEED, 180, 0), intArrayOf(SPEED, 480, 0), intArrayOf(SPEED, 90, 1),
        intArrayOf(SLOWNESS, 90, 0), intArrayOf(SLOWNESS, 240, 0),
        intArrayOf(WATER_BREATHING, 180, 0), intArrayOf(WATER_BREATHING, 480, 0),
        intArrayOf(HEAL, 0, 0), intArrayOf(HEAL, 0, 1),
        intArrayOf(HARM, 0, 0), intArrayOf(HARM, 0, 1),
        intArrayOf(POISON, 45, 0), intArrayOf(POISON, 90, 0), intArrayOf(POISON, 22, 1),
        intArrayOf(REGEN, 45, 0), intArrayOf(REGEN, 90, 0), intArrayOf(REGEN, 22, 1),
        intArrayOf(STRENGTH, 180, 0), intArrayOf(STRENGTH, 480, 0), intArrayOf(STRENGTH, 90, 1),
        intArrayOf(WEAKNESS, 90, 0), intArrayOf(WEAKNESS, 240, 0),
        intArrayOf(WITHER, 40, 1)
    )

    fun potion(data: Int): IntArray? = if (data in POTION.indices) POTION[data] else null

    // ---------- Варка ----------
    private fun m(vararg p: Int): Map<Int, Int> { val r = HashMap<Int, Int>(); var i = 0; while (i < p.size) { r[p[i]] = p[i + 1]; i += 2 }; return r }
    private val BREW: Map<Int, Map<Int, Int>> = mapOf(
        372 to m(0, 4),
        348 to m(0, 3, 9, 11, 14, 16, 21, 22, 23, 24, 25, 27, 28, 30, 31, 33),
        331 to m(0, 2, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19, 20, 25, 26, 28, 29, 31, 32, 34, 35),
        353 to m(0, 1, 4, 14), 414 to m(0, 1, 4, 9), 377 to m(0, 1, 4, 31), 382 to m(0, 1, 4, 21), 375 to m(0, 1, 4, 25),
        370 to m(0, 1, 4, 28), 378 to m(0, 1, 4, 12), 462 to m(0, 1, 4, 19), 396 to m(0, 1, 4, 5),
        376 to m(0, 34, 1, 34, 3, 34, 4, 34, 14, 17, 15, 18, 16, 17, 9, 17, 10, 18, 11, 17, 21, 23, 22, 24, 25, 23, 26, 23, 27, 24,
            5, 7, 6, 8, 12, 17, 13, 18, 31, 34, 32, 35, 33, 34, 28, 34, 29, 35, 30, 34)
    )

    fun brewResult(bottle: Item?, ing: Item?): Item? {
        if (bottle == null || ing == null) return null
        if (ing.id == 289) return if (bottle.id == 373) Item(438, bottle.data, 1) else null
        if (ing.id == 437) return if (bottle.id == 438) Item(441, bottle.data, 1) else null
        val map = BREW[ing.id] ?: return null
        if (bottle.id != 373 && bottle.id != 438 && bottle.id != 441) return null
        val to = map[bottle.data] ?: return null
        return Item(bottle.id, to, 1)
    }

    fun isIngredient(id: Int) = id == 289 || id == 437 || BREW.containsKey(id)

    // Цвет брызг для частиц (RGB)
    fun color(data: Int): Int {
        val p = potion(data) ?: return 0x385dc6
        return when (p[0]) {
            SPEED -> 0x7cafc6; SLOWNESS -> 0x5a6c81; STRENGTH -> 0x932423; HEAL -> 0xf82423; HARM -> 0x430a09; JUMP -> 0x22ff4c
            REGEN -> 0xcd5cab; FIRE_RES -> 0xe49a3a; WATER_BREATHING -> 0x2e5299; INVISIBILITY -> 0x7f8392; NIGHT_VISION -> 0x1f1fa1
            WEAKNESS -> 0x484d48; POISON -> 0x4e9331; WITHER -> 0x352a27; else -> 0x385dc6
        }
    }
}

class Combat(private val s: MineServer) {
    // Снаряд: 80 — стрела, 81 — снежок, 82 — яйцо, 86 — зелье, 87 — жемчуг Края
    class Proj(val eid: Long, val type: Int, val shooter: Player, var x: Double, var y: Double, var z: Double, var vx: Double, var vy: Double, var vz: Double, val dim: Int) {
        var age = 0
        var stuck = false
        var dmg = 2.0
        var crit = false
        var potion = 0          // у стрелы с зельем — data зелья, у брошенного зелья — data
        var lingering = false
        var pickup = true
    }

    class Cloud(val x: Double, val y: Double, val z: Double, val data: Int, val dim: Int) { var r = 3.0; var age = 0 }

    private val projs = LinkedHashMap<Long, Proj>()
    private val clouds = ArrayList<Cloud>()
    private val bowStart = HashMap<Long, Int>()
    private val rnd = java.util.Random()

    // ---------- Эффекты игрока: id -> [уровень, тиков осталось, таймер] ----------
    fun addEffect(p: Player, id: Int, amp: Int, sec: Int) {
        if (!p.alive) return
        if (id == Potions.HEAL) { s.heal(p, (4 shl minOf(amp, 4)).toFloat()); return }
        if (id == Potions.HARM) { p.hurtCooldown = 0; s.damage(p, (6 shl minOf(amp, 4)).toFloat(), "magic", null); return }
        if (sec <= 0) return
        val cur = p.effects[id]
        if (cur != null && (cur[0] > amp || (cur[0] == amp && cur[1] >= sec * 20))) return
        p.effects[id] = intArrayOf(amp, sec * 20, cur?.get(2) ?: 0)
        if (id == Potions.ABSORPTION) p.absorb = 4f * (amp + 1)
        sendEffect(p, if (cur == null) 1 else 2, id, amp, sec * 20)
    }

    fun clearEffects(p: Player) {
        for (id in p.effects.keys.toList()) sendEffect(p, 3, id, 0, 0)
        p.effects.clear()
        p.absorb = 0f
    }

    private fun sendEffect(p: Player, ev: Int, id: Int, amp: Int, ticks: Int) {
        val pk = Pk.new(Pk.MOB_EFFECT).varlong(p.eid).byte(ev).varint(id).varint(amp).bool(true).varint(ticks).toBytes()
        for (o in s.players.values) if (o.spawned) o.send(W(pk.size).raw(pk))
    }

    fun level(p: Player, id: Int): Int = p.effects[id]?.let { it[0] + 1 } ?: 0

    // Урон с учётом огнестойкости, сопротивления и поглощения; null — урона нет
    fun adjustDamage(p: Player, amount: Float, cause: String): Float? {
        if (cause in setOf("lava", "fire") && p.effects.containsKey(Potions.FIRE_RES)) return null
        var a = amount
        val res = level(p, Potions.RESISTANCE)
        if (res > 0 && cause != "void") a *= maxOf(0f, 1f - 0.2f * res)
        if (p.absorb > 0) { val t = minOf(p.absorb, a); p.absorb -= t; a -= t }
        return if (a <= 0f) null else a
    }

    fun meleeBonus(p: Player): Float = 3f * level(p, Potions.STRENGTH) - 4f * level(p, Potions.WEAKNESS)

    // Зелья с периодическим действием: регенерация, яд, иссушение, голод (раз в тик)
    private fun tickEffects(p: Player) {
        if (p.effects.isEmpty() || !p.alive) return
        for ((id, e) in p.effects.entries.toList()) {
            e[1]--; e[2]++
            val surv = p.survivalLike
            when (id) {
                Potions.REGEN -> if (e[2] >= maxOf(1, 50 shr e[0])) { e[2] = 0; if (surv) s.heal(p, 1f) }
                Potions.POISON -> if (e[2] >= maxOf(1, 25 shr e[0])) { e[2] = 0; if (surv && p.health > 1f) { p.hurtCooldown = 0; s.damage(p, minOf(1f, p.health - 1f), "poison", null) } }
                Potions.WITHER -> if (e[2] >= maxOf(1, 40 shr e[0])) { e[2] = 0; if (surv) { p.hurtCooldown = 0; s.damage(p, 1f, "wither", null) } }
                Potions.HUNGER -> if (surv) p.exhaustion += 0.005f * (e[0] + 1)
                Potions.SATURATION -> if (surv) { p.food = minOf(20, p.food + e[0] + 1); p.saturation = minOf(p.food.toFloat(), p.saturation + 2f * (e[0] + 1)); p.statsDirty = true }
            }
            if (e[1] <= 0) {
                p.effects.remove(id)
                if (id == Potions.ABSORPTION) p.absorb = 0f
                sendEffect(p, 3, id, 0, 0)
            }
        }
    }

    fun applyPotion(p: Player, data: Int, k: Double) {
        val pt = Potions.potion(data) ?: return
        val id = pt[0]
        if (id == Potions.HEAL || id == Potions.HARM) {
            val n = ((if (id == Potions.HEAL) 4 else 6) * (1 shl pt[2]) * k).toFloat()
            if (id == Potions.HEAL) s.heal(p, n) else if (n > 0) { p.hurtCooldown = 0; s.damage(p, n, "magic", null) }
            return
        }
        addEffect(p, id, pt[2], (pt[1] * k).toInt())
    }

    // Выпить зелье или молоко (EntityEvent 9 с бутылкой/ведром в руке); true — обработано
    fun drink(p: Player, it: Item): Boolean {
        if (it.id == 373) {
            applyPotion(p, it.data, 1.0)
            if (p.gamemode != 1) p.setSlot(p.heldSlot, Item(374, 0, 1))
            return true
        }
        if (it.id == 325 && it.data == 1) {
            clearEffects(p)
            if (p.gamemode != 1) p.setSlot(p.heldSlot, Item(325, 0, 1))
            return true
        }
        return false
    }

    // Эффекты еды (золотые яблоки, гнилая плоть, паучий глаз, иглобрюх)
    fun foodEffects(p: Player, id: Int) {
        when (id) {
            322 -> { addEffect(p, Potions.REGEN, 1, 5); addEffect(p, Potions.ABSORPTION, 0, 120) }
            466 -> { addEffect(p, Potions.REGEN, 1, 20); addEffect(p, Potions.ABSORPTION, 3, 120); addEffect(p, Potions.RESISTANCE, 0, 300); addEffect(p, Potions.FIRE_RES, 0, 300) }
            367 -> if (rnd.nextDouble() < 0.8) addEffect(p, Potions.HUNGER, 0, 30)
            375 -> addEffect(p, Potions.POISON, 0, 4)
            394 -> if (rnd.nextDouble() < 0.6) addEffect(p, Potions.POISON, 0, 4)
            462 -> { addEffect(p, Potions.POISON, 3, 60); addEffect(p, Potions.HUNGER, 2, 15); addEffect(p, Potions.NAUSEA, 1, 15) }
        }
    }

    // ---------- Лук ----------
    // UseItem без блока с луком в руке — начало натяжения (как в Nukkit)
    fun startBow(p: Player) {
        if (p.gamemode != 1 && p.count(262, -1) <= 0) return
        bowStart[p.eid] = s.ticks
    }

    // PlayerAction RELEASE_ITEM: выстрел с силой по времени натяжения
    fun releaseBow(p: Player) {
        val start = bowStart.remove(p.eid) ?: return
        if (!p.alive || p.held.id != 261) return
        val t = (s.ticks - start) / 20.0
        val f = minOf(1.0, (t * t + 2 * t) / 3)
        if (f < 0.1) return
        var arrowData = 0
        if (p.gamemode != 1) {
            val slot = p.inventory.indexOfFirst { it != null && it.id == 262 }
            if (slot < 0) return
            val a = p.inventory[slot]!!
            arrowData = a.data
            p.setSlot(slot, if (a.count > 1) Item(a.id, a.data, a.count - 1, a.nbt) else null)
            val bow = p.inventory[p.heldSlot]
            if (bow != null && bow.id == 261) p.setSlot(p.heldSlot, if (bow.data + 1 >= 385) null else Item(261, bow.data + 1, 1, bow.nbt))
        }
        val d = look(p)
        val sp = f * 3.0
        val pr = spawn(80, p, d, sp)
        pr.crit = f >= 1.0
        pr.potion = if (arrowData > 0) arrowData - 1 else 0
        pr.pickup = p.gamemode != 1
        sound(p, 20)
    }

    // Бросок снежка, яйца, жемчуга Края, взрывного или оседающего зелья
    fun throwItem(p: Player, item: Item): Boolean {
        val type = when (item.id) { 332 -> 81; 344 -> 82; 368 -> 87; 438, 441 -> 86; else -> return false }
        val slot = p.inventory[p.heldSlot]
        if (p.gamemode != 1) {
            if (slot == null || slot.id != item.id) return true
            p.setSlot(p.heldSlot, if (slot.count > 1) Item(slot.id, slot.data, slot.count - 1, slot.nbt) else null)
        }
        val d = look(p)
        val potion = type == 86
        val pr = spawn(type, p, if (potion) doubleArrayOf(d[0], d[1] + 0.2, d[2]) else d, if (potion) 0.5 else 1.5)
        if (potion) { pr.potion = item.data; pr.lingering = item.id == 441 }
        return true
    }

    private fun look(p: Player): DoubleArray {
        val yaw = Math.toRadians(p.yaw.toDouble()); val pitch = Math.toRadians(p.pitch.toDouble())
        return doubleArrayOf(-sin(yaw) * cos(pitch), -sin(pitch), cos(yaw) * cos(pitch))
    }

    private fun spawn(type: Int, p: Player, d: DoubleArray, sp: Double): Proj {
        val l = sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]).coerceAtLeast(1e-6)
        val pr = Proj(s.newEid(), type, p, p.x + d[0] / l * 0.3, p.y + 1.52, p.z + d[2] / l * 0.3, d[0] / l * sp, d[1] / l * sp, d[2] / l * sp, p.dim)
        projs[pr.eid] = pr
        val w = Pk.new(Pk.ADD_ENTITY, 96).varlong(pr.eid).varlong(pr.eid).uvarint(type)
            .vec3(pr.x.toFloat(), pr.y.toFloat(), pr.z.toFloat()).vec3(pr.vx.toFloat(), pr.vy.toFloat(), pr.vz.toFloat())
            .lfloat(p.pitch).lfloat(p.yaw).uvarint(0).uvarint(0).uvarint(0)
        s.sendDim(pr.dim, w.toBytes())
        return pr
    }

    private fun sound(p: Player, id: Int) {
        val pk = Pk.new(Pk.LEVEL_SOUND_EVENT).byte(id).vec3(p.x.toFloat(), p.y.toFloat() + 1.5f, p.z.toFloat()).varint(0).varint(-1).bool(false).bool(false).toBytes()
        s.sendDim(p.dim, pk)
    }

    private fun remove(pr: Proj) {
        projs.remove(pr.eid)
        s.sendDim(pr.dim, Pk.new(Pk.REMOVE_ENTITY).varlong(pr.eid).toBytes())
    }

    private fun solid(dim: Int, x: Double, y: Double, z: Double): Boolean {
        val bx = floor(x).toInt(); val by = floor(y).toInt(); val bz = floor(z).toInt()
        if (by < 0 || by > 255) return false
        val w = s.worldAt(dim)
        if (!w.isLoaded(bx shr 4, bz shr 4)) return true
        return Blocks.solid[w.getId(bx, by, bz)]
    }

    // Облако зелья (оседающее зелье, драконье дыхание)
    fun addCloud(dim: Int, x: Double, y: Double, z: Double, data: Int) { clouds.add(Cloud(x, y, z, data, dim)) }

    private fun playerAt(dim: Int, x: Double, y: Double, z: Double, skip: Player?): Player? {
        for (o in s.players.values) {
            if (!o.alive || o === skip || o.gamemode == 3 || o.dim != dim) continue
            if (abs(o.x - x) < 0.4 && abs(o.z - z) < 0.4 && y > o.y - 0.1 && y < o.y + 1.9) return o
        }
        return null
    }

    // ---------- Такт ----------
    fun tick() {
        for (p in s.players.values) tickEffects(p)
        for (pr in projs.values.toList()) tickProj(pr)
        tickClouds()
        bowStart.keys.retainAll(s.players.values.map { it.eid }.toSet())
    }

    private fun tickProj(pr: Proj) {
        pr.age++
        if (pr.stuck) {
            if (pr.age > 1200) { remove(pr); return }
            if (!pr.pickup) return
            for (o in s.players.values) {
                if (!o.alive || o.gamemode == 3 || o.dim != pr.dim) continue
                if (abs(o.x - pr.x) > 1.2 || abs(o.z - pr.z) > 1.2 || pr.y < o.y - 0.5 || pr.y > o.y + 2.2) continue
                if (o.gamemode != 1 && o.give(Item(262, if (pr.potion > 0) pr.potion + 1 else 0, 1)) > 0) continue
                s.sendDim(pr.dim, Pk.new(Pk.TAKE_ITEM_ENTITY).varlong(pr.eid).varlong(o.eid).toBytes())
                remove(pr)
                return
            }
            return
        }
        if (pr.age > 600 || pr.y < -64) { remove(pr); return }
        val arrow = pr.type == 80
        val w = s.worldAt(pr.dim)
        val inWater = w.getId(floor(pr.x).toInt(), floor(pr.y).toInt(), floor(pr.z).toInt()) in 8..9
        pr.vy -= if (arrow) 0.05 else 0.03
        val drag = if (inWater) 0.6 else 0.99
        pr.vx *= drag; pr.vy *= drag; pr.vz *= drag
        val speed = sqrt(pr.vx * pr.vx + pr.vy * pr.vy + pr.vz * pr.vz)
        val steps = maxOf(1, ceil(speed / 0.3).toInt())
        for (i in 0 until steps) {
            val nx = pr.x + pr.vx / steps; val ny = pr.y + pr.vy / steps; val nz = pr.z + pr.vz / steps
            // Кристаллы Края и дракон: любой снаряд взрывает кристалл, стрела ранит дракона
            if (s.end.projectileHit(pr, nx, ny, nz, speed)) {
                pr.x = nx; pr.y = ny; pr.z = nz
                remove(pr)
                if (pr.type == 86) splash(pr) else if (pr.type == 87) pearl(pr)
                return
            }
            // Жемчуг, брошенный во врата Края, переносит через них
            if (pr.type == 87 && w.getId(floor(nx).toInt(), floor(ny).toInt(), floor(nz).toInt()) == 209) {
                remove(pr)
                if (pr.shooter.alive && pr.shooter.dim == pr.dim) s.portals.enterGateway(pr.shooter, floor(nx).toInt(), floor(ny).toInt(), floor(nz).toInt())
                return
            }
            val hit = playerAt(pr.dim, nx, ny, nz, if (pr.age < 5) pr.shooter else null)
            if (hit != null) { hitPlayer(pr, hit, speed); return }
            if (solid(pr.dim, nx, ny, nz)) { hitBlock(pr); return }
            pr.x = nx; pr.y = ny; pr.z = nz
        }
        val pk = Pk.new(Pk.MOVE_ENTITY).varlong(pr.eid).vec3(pr.x.toFloat(), pr.y.toFloat(), pr.z.toFloat()).byte(0).byte(0).byte(0).bool(false).bool(false).toBytes()
        s.sendDim(pr.dim, pk)
    }

    private fun hitPlayer(pr: Proj, t: Player, speed: Double) {
        val pvp = s.rules["pvp"] == true || t === pr.shooter
        when (pr.type) {
            80 -> {
                remove(pr)
                if (!pvp) return
                var dmg = ceil(speed * pr.dmg)
                if (pr.crit) dmg += rnd.nextInt((dmg / 2 + 2).toInt())
                t.hurtCooldown = 0
                if (!s.damage(t, dmg.toFloat(), "arrow", pr.shooter)) return
                val l = sqrt(pr.vx * pr.vx + pr.vz * pr.vz).coerceAtLeast(0.01)
                t.send(Pk.new(Pk.SET_ENTITY_MOTION).varlong(t.eid).vec3((pr.vx / l * 0.4).toFloat(), 0.3f, (pr.vz / l * 0.4).toFloat()))
                val pt = Potions.potion(pr.potion)
                if (pt != null && pr.potion > 0) addEffect(t, pt[0], pt[2], pt[1] / 8)
                if (pr.shooter !== t) pr.shooter.send(Pk.new(Pk.LEVEL_SOUND_EVENT).byte(21).vec3(t.x.toFloat(), t.y.toFloat() + 1, t.z.toFloat()).varint(0).varint(-1).bool(false).bool(false))
            }
            86 -> { remove(pr); splash(pr) }
            87 -> { remove(pr); pearl(pr) }
            else -> {
                remove(pr)
                if (pvp && t !== pr.shooter) {
                    val l = sqrt(pr.vx * pr.vx + pr.vz * pr.vz).coerceAtLeast(0.01)
                    t.send(Pk.new(Pk.SET_ENTITY_MOTION).varlong(t.eid).vec3((pr.vx / l * 0.3).toFloat(), 0.2f, (pr.vz / l * 0.3).toFloat()))
                }
            }
        }
    }

    private fun hitBlock(pr: Proj) {
        when (pr.type) {
            80 -> {
                pr.stuck = true; pr.age = 0
                pr.vx = 0.0; pr.vy = 0.0; pr.vz = 0.0
                val pk = Pk.new(Pk.MOVE_ENTITY).varlong(pr.eid).vec3(pr.x.toFloat(), pr.y.toFloat(), pr.z.toFloat()).byte(0).byte(0).byte(0).bool(true).bool(false).toBytes()
                s.sendDim(pr.dim, pk)
            }
            86 -> { remove(pr); splash(pr) }
            87 -> { remove(pr); pearl(pr) }
            else -> remove(pr)
        }
    }

    // Взрывное зелье действует на всех в радиусе 4 блоков (сильнее в центре), оседающее оставляет облако на 30 с
    private fun splash(pr: Proj) {
        val ev = Pk.new(Pk.LEVEL_EVENT).varint(2002).vec3(pr.x.toFloat(), pr.y.toFloat(), pr.z.toFloat()).varint(Potions.color(pr.potion)).toBytes()
        s.sendDim(pr.dim, ev)
        if (pr.lingering) { clouds.add(Cloud(pr.x, floor(pr.y + 0.01), pr.z, pr.potion, pr.dim)); return }
        for (o in s.players.values) {
            if (!o.alive || o.gamemode == 3 || o.dim != pr.dim) continue
            val d = sqrt((o.x - pr.x) * (o.x - pr.x) + (o.y + 0.9 - pr.y) * (o.y + 0.9 - pr.y) + (o.z - pr.z) * (o.z - pr.z))
            if (d < 4) applyPotion(o, pr.potion, maxOf(0.25, 1 - d / 4))
        }
    }

    private fun tickClouds() {
        val it = clouds.iterator()
        while (it.hasNext()) {
            val c = it.next()
            c.age++
            if (c.age > 600 || c.r <= 0.5) { it.remove(); continue }
            if (c.age % 20 != 0) continue
            var used = false
            for (o in s.players.values) {
                if (!o.alive || o.gamemode == 3 || o.dim != c.dim) continue
                if (sqrt((o.x - c.x) * (o.x - c.x) + (o.z - c.z) * (o.z - c.z)) < c.r && abs(o.y - c.y) < 2) { applyPotion(o, c.data, 0.25); used = true }
            }
            if (c.age % 40 == 0) {
                val ev = Pk.new(Pk.LEVEL_EVENT).varint(2002).vec3(c.x.toFloat(), c.y.toFloat() + 0.2f, c.z.toFloat()).varint(Potions.color(c.data)).toBytes()
                s.sendDim(c.dim, ev)
            }
            c.r -= if (used) 0.5 else 0.1
        }
    }

    // Жемчуг Края: перенос в точку падения и 5 урона
    private fun pearl(pr: Proj) {
        val p = pr.shooter
        if (!p.alive || p.dim != pr.dim || p.dimWait) return
        s.teleport(p, pr.x, pr.y, pr.z)
        p.hurtCooldown = 0
        s.damage(p, 5f, "fall", null)
    }

    fun forget(p: Player) { bowStart.remove(p.eid) }
}
