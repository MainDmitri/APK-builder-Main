package com.mcpehtml.app.server

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// Битва с драконом Края на сервере (как updateDragon в client/js/mobs.js): дракон, кристаллы на столбах,
// огненные шары с дыханием, портал выхода, яйцо, врата Края, возрождение дракона четырьмя кристаллами.
// Состояние Края хранится в world_end/end.json
class EndFight(private val s: MineServer) {
    // idx — номер столба (кристалл лечит дракона), -1 — поставлен игроком
    class Crystal(val eid: Long, val dim: Int, val x: Double, val y: Double, val z: Double, val idx: Int)

    class Dragon(val eid: Long, var x: Double, var y: Double, var z: Double) {
        var vx = 0.0; var vy = 0.0; var vz = 0.0
        var yaw = 0.0
        var hp = MAX_HP
        var phase = "hold"
        var ang = atan2(z, x); var timer = 8.0; var dir = 1
        var landStep = 0; var perchT = 0.0; var breathT = 0.0; var strafeT = 0.0; var chargeT = 0.0; var shotDone = false
        var damageTaken = 0f
        var invuln = 0                 // тики неуязвимости после удара
        var wingCd = 0.0
        var healT = 0.0
        var healing = -1L              // кристалл, который лечит
        var dead = -1.0                // секунд до конца анимации смерти, < 0 — жив
        var shownHp = -1
    }

    class Fireball(val eid: Long, var x: Double, var y: Double, var z: Double, val vx: Double, val vy: Double, val vz: Double) { var age = 0.0 }

    // Око Края летит к крепости
    class Eye(val eid: Long, val sx: Double, val sz: Double, val tx: Double, val tz: Double, val ty: Double, var x: Double, var y: Double, var z: Double) { var age = 0.0 }

    companion object {
        const val MAX_HP = 200f
        const val DT = 0.05
        const val T_DRAGON = 53; const val T_CRYSTAL = 71; const val T_FIREBALL = 79; const val T_EYE = 70
        // Блоки, которые дракон не ломает
        val PROOF = setOf(7, 49, 101, 119, 120, 121, 122, 209, 51)
        private fun yawTo(dx: Double, dz: Double) = Math.toDegrees(atan2(-dx, dz))
    }

    var dragonKilled = false
    var dragonKills = 0
    var eggPlaced = false
    val endCrystals = BooleanArray(10) { true }
    val gateways = ArrayList<IntArray>()
    val gatewayExits = LinkedHashMap<String, IntArray>()       // ключ "x,z" входа -> [x, y, z, остров 1/0]
    private val placed = ArrayList<DoubleArray>()              // кристаллы игроков: [измерение, x, y, z]
    private var savedHp = 0f
    private var file: File? = null

    val crystals = LinkedHashMap<Long, Crystal>()
    var dragon: Dragon? = null
        private set
    private val fireballs = LinkedHashMap<Long, Fireball>()
    private val eyes = LinkedHashMap<Long, Eye>()
    private val rnd = java.util.Random()
    private var killer: Player? = null

    private val endWorld get() = s.worldAt(2)
    private val gen get() = endWorld.gen as EndGenerator

    // ---------- Сохранение ----------
    fun load(f: File) {
        file = f
        if (!f.exists()) return
        try {
            val o = JSONObject(f.readText())
            dragonKilled = o.optBoolean("dragonKilled", false)
            dragonKills = o.optInt("dragonKills", 0)
            eggPlaced = o.optBoolean("eggPlaced", false)
            savedHp = o.optDouble("dragonHp", 0.0).toFloat()
            o.optJSONArray("endCrystals")?.let { a -> for (i in 0 until minOf(10, a.length())) endCrystals[i] = a.optBoolean(i, true) }
            o.optJSONArray("gateways")?.let { a -> for (i in 0 until a.length()) a.optJSONArray(i)?.let { g -> if (g.length() == 3) gateways.add(intArrayOf(g.getInt(0), g.getInt(1), g.getInt(2))) } }
            o.optJSONObject("gatewayExits")?.let { e -> for (k in e.keys()) e.optJSONArray(k)?.let { g -> if (g.length() == 4) gatewayExits[k] = IntArray(4) { g.getInt(it) } } }
            o.optJSONArray("placed")?.let { a -> for (i in 0 until a.length()) a.optJSONArray(i)?.let { c -> if (c.length() == 4) placed.add(DoubleArray(4) { c.getDouble(it) }) } }
        } catch (e: Exception) {
            s.log("Не удалось прочитать end.json: $e")
        }
    }

    fun save() {
        val f = file ?: return
        val o = JSONObject()
        o.put("dragonKilled", dragonKilled).put("dragonKills", dragonKills).put("eggPlaced", eggPlaced)
        o.put("dragonHp", (dragon?.takeIf { it.dead < 0 }?.hp ?: savedHp).toDouble())
        o.put("endCrystals", JSONArray().also { a -> for (b in endCrystals) a.put(b) })
        o.put("gateways", JSONArray().also { a -> for (g in gateways) a.put(JSONArray().put(g[0]).put(g[1]).put(g[2])) })
        o.put("gatewayExits", JSONObject().also { e -> for ((k, g) in gatewayExits) e.put(k, JSONArray().put(g[0]).put(g[1]).put(g[2]).put(g[3])) })
        o.put("placed", JSONArray().also { a -> for (c in placed) a.put(JSONArray().put(c[0].toInt()).put(c[1]).put(c[2]).put(c[3])) })
        try { f.parentFile?.mkdirs(); f.writeText(o.toString()) } catch (e: Exception) { }
    }

    // Кристаллы, поставленные игроками (в любом измерении), появляются при запуске сервера
    fun restorePlaced() {
        for (c in placed) {
            val e = Crystal(s.newEid(), c[0].toInt(), c[1], c[2], c[3], -1)
            crystals[e.eid] = e
        }
    }

    // Пока жив дракон, центр Края не выгружается
    fun keepChunk(dim: Int, cx: Int, cz: Int) = dim == 2 && dragon != null && abs(cx) <= 4 && abs(cz) <= 4

    // ---------- Появление дракона ----------
    // Игрок вошёл в Край: кристаллы на столбах и дракон, если он ещё не побеждён
    fun onEnter(p: Player) { spawnDragon() }

    fun spawnDragon() {
        restoreCrystals()
        if (dragonKilled || dragon != null) return
        val d = Dragon(s.newEid(), 0.0, 80.0, 40.0)
        if (savedHp > 0f && savedHp <= MAX_HP) d.hp = savedHp
        dragon = d
        s.log("Дракон Края появился (${d.hp.toInt()} HP)")
    }

    private fun restoreCrystals() {
        if (dragonKilled) return
        for (pl in gen.pillars) {
            if (!endCrystals[pl.i] || crystals.values.any { it.idx == pl.i }) continue
            val c = Crystal(s.newEid(), 2, pl.x + 0.5, pl.h + 2.0, pl.z + 0.5, pl.i)
            crystals[c.eid] = c
        }
    }

    // ---------- Сеть ----------
    private fun ck(x: Double, z: Double) = ((floor(x).toInt() shr 4).toLong() shl 32) or ((floor(z).toInt() shr 4).toLong() and 0xffffffffL)

    private fun dragonTag(d: Dragon) = "§dДракон Края §f${max(0, ceil(d.hp.toDouble()).toInt())}/${MAX_HP.toInt()}"
    private val DRAGON_FLAGS = (1L shl Meta.FLAG_CAN_SHOW_NAMETAG) or (1L shl Meta.FLAG_ALWAYS_SHOW_NAMETAG)

    private fun addPacket(eid: Long, type: Int, x: Double, y: Double, z: Double, vx: Double, vy: Double, vz: Double, yaw: Double, tag: String, flags: Long): ByteArray {
        val w = Pk.new(Pk.ADD_ENTITY, 128).varlong(eid).varlong(eid).uvarint(type)
            .vec3(x.toFloat(), y.toFloat(), z.toFloat()).vec3(vx.toFloat(), vy.toFloat(), vz.toFloat())
            .lfloat(0f).lfloat(yaw.toFloat()).uvarint(0)
        Meta.writeMob(w, flags, tag)
        w.uvarint(0)
        return w.toBytes()
    }

    private fun moveBytes(eid: Long, x: Double, y: Double, z: Double, yaw: Double): ByteArray {
        val b = (Math.floorMod(Math.round(yaw / 360.0 * 256).toInt(), 256))
        return Pk.new(Pk.MOVE_ENTITY).varlong(eid).vec3(x.toFloat(), y.toFloat(), z.toFloat()).byte(0).byte(b).byte(b).bool(false).bool(false).toBytes()
    }

    private fun toSeers(eid: Long, pk: ByteArray) {
        for (p in s.players.values) if (p.seenEnts.contains(eid)) p.send(W(pk.size).raw(pk))
    }

    private fun despawn(eid: Long) {
        val pk = Pk.new(Pk.REMOVE_ENTITY).varlong(eid).toBytes()
        for (p in s.players.values) if (p.seenEnts.remove(eid)) p.send(W(pk.size).raw(pk))
    }

    private fun show(p: Player, eid: Long, visible: Boolean, make: () -> ByteArray) {
        if (visible) { if (p.seenEnts.add(eid)) { val b = make(); p.send(W(b.size).raw(b)) } }
        else if (p.seenEnts.remove(eid)) p.send(Pk.new(Pk.REMOVE_ENTITY).varlong(eid))
    }

    // Показать игрокам сущности их измерения в загруженных ими чанках
    private fun sync() {
        val d = dragon
        for (p in s.players.values) {
            if (!p.spawned) continue
            val ready = !p.dimWait
            // Кристаллы на столбах видны со всего Края (как в игре — их видно с площадки), поставленные — в загруженных чанках
            for (c in crystals.values) show(p, c.eid, ready && c.dim == p.dim && (c.idx >= 0 || p.sentChunks.contains(ck(c.x, c.z)))) { addPacket(c.eid, T_CRYSTAL, c.x, c.y, c.z, 0.0, 0.0, 0.0, 0.0, "", 0L) }
            if (d != null) show(p, d.eid, ready && p.dim == 2) { addPacket(d.eid, T_DRAGON, d.x, d.y, d.z, 0.0, 0.0, 0.0, d.yaw, dragonTag(d), DRAGON_FLAGS) }
            for (f in fireballs.values) show(p, f.eid, ready && p.dim == 2) { addPacket(f.eid, T_FIREBALL, f.x, f.y, f.z, f.vx * DT, f.vy * DT, f.vz * DT, 0.0, "", 0L) }
            for (e in eyes.values) show(p, e.eid, ready && p.dim == 0 && p.sentChunks.contains(ck(e.x, e.z))) { addPacket(e.eid, T_EYE, e.x, e.y, e.z, 0.0, 0.0, 0.0, 0.0, "", 0L) }
        }
    }

    // ---------- Такт ----------
    fun tick() {
        tickEyes()
        val inEnd = s.players.values.filter { it.spawned && it.dim == 2 && !it.dimWait }
        // Если в Крае никого нет, дракон ждёт
        if (dragon != null && inEnd.isNotEmpty()) tickDragon(dragon!!, inEnd)
        if (inEnd.isNotEmpty()) tickFireballs(inEnd)
        sync()
    }

    private fun solid(x: Double, y: Double, z: Double): Boolean {
        val by = floor(y).toInt()
        if (by < 0 || by > 255) return false
        return Blocks.solid[endWorld.getId(floor(x).toInt(), by, floor(z).toInt())]
    }

    // Прямая видимость между точками
    private fun sees(x1: Double, y1: Double, z1: Double, x2: Double, y2: Double, z2: Double): Boolean {
        val d = sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1) + (z2 - z1) * (z2 - z1))
        var t = 0.0
        while (t < d) {
            val k = t / d
            if (solid(x1 + (x2 - x1) * k, y1 + (y2 - y1) * k, z1 + (z2 - z1) * k)) return false
            t += 0.5
        }
        return true
    }

    private fun tickDragon(m: Dragon, inEnd: List<Player>) {
        val dt = DT
        if (m.invuln > 0) m.invuln--
        m.wingCd = max(0.0, m.wingCd - dt)
        if (m.dead >= 0) {
            // Смерть: 6 секунд поднимается и вращается, затем взрыв
            m.dead -= dt
            m.y += dt * 1.5
            m.yaw += dt * 30
            if (s.ticks % 5 == 0) fx(m.x + (rnd.nextDouble() - 0.5) * 8, m.y + rnd.nextDouble() * 4, m.z + (rnd.nextDouble() - 0.5) * 8, 2.0)
            if (s.ticks % 2 == 0) toSeers(m.eid, moveBytes(m.eid, m.x, m.y, m.z, m.yaw))
            if (m.dead <= 0) {
                despawn(m.eid)
                dragon = null
                fx(m.x, m.y + 2, m.z, 6.0)
                killed()
            }
            return
        }
        // Цель — ближайший живой игрок в выживании у центрального острова
        val p = inEnd.filter { it.alive && it.survivalLike && hypot(it.x, it.z) < 180 }
            .minByOrNull { (it.x - m.x) * (it.x - m.x) + (it.y - m.y) * (it.y - m.y) + (it.z - m.z) * (it.z - m.z) }
        val active = p != null
        // Лечение от ближайшего кристалла на столбе в радиусе 32 блоков: 1 HP за 0,5 с
        m.healT -= dt
        var healer: Crystal? = null
        var hd = 32.0
        for (c in crystals.values) {
            if (c.idx < 0 || c.dim != 2) continue
            val d = sqrt((c.x - m.x) * (c.x - m.x) + (c.y - m.y) * (c.y - m.y) + (c.z - m.z) * (c.z - m.z))
            if (d < hd) { hd = d; healer = c }
        }
        m.healing = healer?.eid ?: -1L
        if (healer != null && m.healT <= 0 && m.hp < MAX_HP) { m.healT = 0.5; m.hp = min(MAX_HP, m.hp + 1f); updateTag(m) }
        val crystalsLeft = crystals.values.count { it.idx >= 0 }
        var tx = m.x; var ty = m.y; var tz = m.z; var sp = 14.0
        val toP = if (p != null) sqrt((p.x - m.x) * (p.x - m.x) + (p.y - m.y) * (p.y - m.y) + (p.z - m.z) * (p.z - m.z)) else Double.MAX_VALUE
        fun choose() {
            m.timer = 6 + rnd.nextDouble() * 8
            if (!active) { m.phase = "hold"; return }
            val r = rnd.nextDouble()
            // Чем меньше кристаллов, тем чаще садится (шанс 1 из 3 + кристаллы)
            if (r < 1.0 / (3 + crystalsLeft)) { m.phase = "land"; m.landStep = 0 }
            else if (r < 0.65) { m.phase = "strafe"; m.shotDone = false; m.strafeT = 10.0 }
            else { m.phase = "charge"; m.chargeT = 7.0 }
        }
        when (m.phase) {
            "hold" -> {
                // Кружит над столбами
                m.ang += dt * 0.32 * m.dir
                val R = 52 + sin(m.ang * 3) * 10
                tx = cos(m.ang) * R; tz = sin(m.ang) * R; ty = 80 + sin(m.ang * 2) * 7
                m.timer -= dt
                if (m.timer <= 0) { if (rnd.nextDouble() < 0.15) m.dir = -m.dir; choose() }
            }
            "strafe" -> {
                // Подлёт на расстояние выстрела и огненный шар с дыханием
                m.strafeT -= dt
                if (p == null || m.strafeT <= 0) { m.phase = "hold"; m.timer = 6.0 }
                else {
                    tx = p.x; ty = p.y + 12; tz = p.z; sp = 16.0
                    if (!m.shotDone && toP < 48 && sees(m.x, m.y + 2, m.z, p.x, p.y + 1.5, p.z)) {
                        m.shotDone = true
                        shootFireball(m, p.x - m.x, p.y + 0.5 - m.y, p.z - m.z)
                        m.phase = "hold"; m.timer = 5 + rnd.nextDouble() * 5
                    }
                }
            }
            "charge" -> {
                // Таран
                m.chargeT -= dt
                if (p == null || m.chargeT <= 0) { m.phase = "hold"; m.timer = 6.0 }
                else { tx = p.x; ty = p.y + 1; tz = p.z; sp = 22.0 }
            }
            "land" -> {
                // Сначала над порталом, затем вниз на столб
                if (m.landStep == 0) {
                    tx = 0.0; ty = 76.0; tz = 0.0; sp = 14.0
                    if (sqrt(m.x * m.x + (m.y - 76) * (m.y - 76) + m.z * m.z) < 3) m.landStep = 1
                } else {
                    tx = 0.0; ty = 65.0; tz = 0.0; sp = 6.0
                    if (sqrt(m.x * m.x + (m.y - 65) * (m.y - 65) + m.z * m.z) < 0.8) {
                        m.phase = "perch"; m.perchT = 9 + rnd.nextDouble() * 4; m.breathT = 1.5; m.damageTaken = 0f
                    }
                }
            }
            "perch" -> {
                // Сидит на портале, поворачивается к игроку и дышит фиолетовым пламенем
                tx = 0.0; ty = 65.0; tz = 0.0; sp = 2.0
                if (p != null) m.yaw = yawTo(p.x - m.x, p.z - m.z)
                m.perchT -= dt
                m.breathT -= dt
                if (m.breathT <= 0 && active) {
                    m.breathT = 3.5
                    val yr = Math.toRadians(m.yaw); val fx = -sin(yr); val fz = cos(yr)
                    for (i in 0 until 3) breathCloud(fx * (6 + i * 3), 64.0, fz * (6 + i * 3))
                }
                // Улетает через 9–13 секунд или после 25 урона
                if (m.perchT <= 0 || m.damageTaken >= 25 || (!active && m.perchT < 6)) m.phase = "takeoff"
            }
            "takeoff" -> {
                tx = m.x * 1.5 + 10; ty = 90.0; tz = m.z * 1.5 + 10; sp = 10.0
                if (m.y > 85) { m.phase = "hold"; m.ang = atan2(m.z, m.x); m.timer = 8.0 }
            }
        }
        // Плавный разворот: скорость меняется постепенно
        val dx = tx - m.x; val dy = ty - m.y; val dz = tz - m.z
        val l = sqrt(dx * dx + dy * dy + dz * dz).let { if (it == 0.0) 1.0 else it }
        val want = min(sp, l / dt)
        val k = min(1.0, dt * (if (m.phase == "perch") 6.0 else 1.6))
        m.vx += (dx / l * want - m.vx) * k
        m.vy += (dy / l * want - m.vy) * k
        m.vz += (dz / l * want - m.vz) * k
        m.x += m.vx * dt; m.y += m.vy * dt; m.z += m.vz * dt
        if (m.phase != "perch" && hypot(m.vx, m.vz) > 0.5) m.yaw = yawTo(m.vx, m.vz)
        // Удар головой (10) и крыльями (5): отбрасывает
        if (m.wingCd <= 0) {
            val yr = Math.toRadians(m.yaw)
            val hx = m.x - sin(yr) * 6; val hz = m.z + cos(yr) * 6
            var hit = false
            for (o in inEnd) {
                if (!o.alive || !o.survivalLike) continue
                val head = hypot(o.x - hx, o.z - hz) < 2.5 && abs(o.y - m.y) < 3
                val body = hypot(o.x - m.x, o.z - m.z) < 4.5 && o.y > m.y - 2 && o.y < m.y + 3
                if (!head && !(body && m.phase != "perch")) continue
                hit = true
                o.hurtCooldown = 0
                s.damage(o, if (head) 10f else 5f, "dragon", null)
                val ox = o.x - m.x; val oz = o.z - m.z; val ol = hypot(ox, oz).let { if (it == 0.0) 1.0 else it }
                o.send(Pk.new(Pk.SET_ENTITY_MOTION).varlong(o.eid).vec3((ox / ol * 0.6).toFloat(), 0.3f, (oz / ol * 0.6).toFloat()))
            }
            if (hit) { m.wingCd = 0.5; if (m.phase == "charge") { m.phase = "hold"; m.timer = 6.0 } }
        }
        // Блоки на пути дракона разрушаются
        if (m.phase != "perch" && m.phase != "land") smash(m)
        if (s.ticks % 2 == 0) toSeers(m.eid, moveBytes(m.eid, m.x, m.y, m.z, m.yaw))
    }

    private fun smash(m: Dragon) {
        val w = endWorld
        var n = 0
        for (x in floor(m.x - 3).toInt()..floor(m.x + 3).toInt()) for (z in floor(m.z - 3).toInt()..floor(m.z + 3).toInt()) for (y in floor(m.y).toInt()..floor(m.y + 3).toInt()) {
            if (n >= 24 || y < 0 || y > 255) continue
            val id = w.getId(x, y, z)
            if (id == 0 || id in PROOF) continue
            val data = w.getData(x, y, z)
            s.containers.broken(2, x, y, z)
            Place.removeWithPartner(s, w, x, y, z, id, data)
            s.sendDim(2, Pk.new(Pk.LEVEL_EVENT).varint(2001).vec3(x + 0.5f, y + 0.5f, z + 0.5f).varint(id or (data shl 8)).toBytes())
            n++
        }
    }

    private fun updateTag(m: Dragon) {
        val hp = max(0, ceil(m.hp.toDouble()).toInt())
        if (hp == m.shownHp) return
        m.shownHp = hp
        val w = Pk.new(Pk.SET_ENTITY_DATA).varlong(m.eid)
        Meta.writeMob(w, DRAGON_FLAGS, dragonTag(m))
        toSeers(m.eid, w.toBytes())
    }

    // Урон дракону; true — прошёл
    fun hurtDragon(dmg: Float, by: Player?): Boolean {
        val m = dragon ?: return false
        if (m.dead >= 0 || m.invuln > 0 || dmg <= 0) return false
        m.hp -= dmg
        m.invuln = 5
        m.vx = 0.0; m.vy = 0.0; m.vz = 0.0
        m.damageTaken += dmg
        if (by != null) killer = by
        toSeers(m.eid, Pk.new(Pk.ENTITY_EVENT).varlong(m.eid).byte(2).varint(0).toBytes())
        updateTag(m)
        if (m.hp <= 0f) {
            m.hp = 0f
            m.dead = 6.0
            m.healing = -1
            savedHp = 0f
            toSeers(m.eid, Pk.new(Pk.ENTITY_EVENT).varlong(m.eid).byte(3).varint(0).toBytes())
            s.log("Дракон Края убит" + (killer?.let { " (${it.name})" } ?: ""))
        }
        return true
    }

    // ---------- Удар игрока по дракону или кристаллу (Interact); true — цель наша ----------
    fun attack(p: Player, target: Long): Boolean {
        val c = crystals[target]
        if (c != null) {
            if (c.dim != p.dim) return true
            val dx = c.x - p.x; val dy = c.y + 1 - (p.y + 1.62); val dz = c.z - p.z
            if (dx * dx + dy * dy + dz * dz > 64) return true
            destroyCrystal(c, p)
            return true
        }
        val m = dragon
        if (m != null && m.eid == target) {
            if (p.dim != 2 || m.dead >= 0) return true
            if (hypot(m.x - p.x, m.z - p.z) > 14 || abs(m.y - p.y) > 12) return true
            hurtDragon(s.meleeDamage(p), p)
            return true
        }
        return fireballs.containsKey(target) || eyes.containsKey(target)
    }

    // ---------- Снаряды игроков ----------
    private fun crystalAt(dim: Int, x: Double, y: Double, z: Double, pad: Double): Crystal? =
        crystals.values.firstOrNull { it.dim == dim && abs(x - it.x) < 1 + pad && abs(z - it.z) < 1 + pad && y > it.y - pad && y < it.y + 2 + pad }

    fun projectileHit(pr: Combat.Proj, x: Double, y: Double, z: Double, speed: Double): Boolean {
        val c = crystalAt(pr.dim, x, y, z, 0.15)
        if (c != null) { destroyCrystal(c, pr.shooter); return true }
        val m = dragon ?: return false
        if (pr.dim != 2 || m.dead >= 0) return false
        if (abs(x - m.x) > 4 || abs(z - m.z) > 4 || y < m.y - 1 || y > m.y + 4) return false
        if (pr.type == 80) {
            var dmg = ceil(speed * pr.dmg)
            if (pr.crit) dmg += rnd.nextInt((dmg / 2 + 2).toInt())
            if (hurtDragon(dmg.toFloat(), pr.shooter)) pr.shooter.send(Pk.new(Pk.LEVEL_SOUND_EVENT).byte(21).vec3(m.x.toFloat(), m.y.toFloat() + 1, m.z.toFloat()).varint(0).varint(-1).bool(false).bool(false))
        }
        return true
    }

    // ---------- Кристаллы ----------
    // Кристалл взрывается от любого урона; если он лечил дракона, дракон получает 10 урона
    fun destroyCrystal(c: Crystal, by: Player?) {
        if (crystals.remove(c.eid) == null) return
        despawn(c.eid)
        val m = dragon
        if (m != null && m.dead < 0 && m.healing == c.eid) { m.healing = -1; m.invuln = 0; hurtDragon(10f, by) }
        if (c.idx >= 0) endCrystals[c.idx] = false
        else placed.removeIf { it[0].toInt() == c.dim && it[1] == c.x && it[2] == c.y && it[3] == c.z }
        explode(c.dim, c.x, c.y + 1, c.z, 6.0, by)
        save()
    }

    // Кристалл Края из инвентаря: на обсидиан или бедрок с воздухом сверху
    fun placeCrystal(p: Player, w: World, x: Int, y: Int, z: Int, clicked: Int): Boolean {
        if (clicked != 49 && clicked != 7) return false
        if (y > 253 || w.getId(x, y + 1, z) != 0 || w.getId(x, y + 2, z) != 0) return false
        val cx = x + 0.5; val cy = y + 1.0; val cz = z + 0.5
        if (crystalAt(w.dim, cx, cy + 1, cz, 0.2) != null) return false
        placed.add(doubleArrayOf(w.dim.toDouble(), cx, cy, cz))
        val c = Crystal(s.newEid(), w.dim, cx, cy, cz, -1)
        crystals[c.eid] = c
        checkRespawn(w.dim)
        save()
        return true
    }

    // Возрождение дракона: четыре кристалла по сторонам портала выхода
    private fun checkRespawn(dim: Int) {
        if (dim != 2 || !dragonKilled) return
        val spots = arrayOf(doubleArrayOf(3.5, 0.5), doubleArrayOf(-2.5, 0.5), doubleArrayOf(0.5, 3.5), doubleArrayOf(0.5, -2.5))
        val found = ArrayList<Crystal>()
        for (sp in spots) {
            val c = crystals.values.firstOrNull { it.idx < 0 && it.dim == 2 && abs(it.x - sp[0]) < 1.1 && abs(it.z - sp[1]) < 1.1 && abs(it.y - 62) < 1.1 } ?: return
            found.add(c)
        }
        for (c in found) {
            crystals.remove(c.eid)
            despawn(c.eid)
            placed.removeIf { it[0].toInt() == 2 && it[1] == c.x && it[2] == c.y && it[3] == c.z }
        }
        dragonKilled = false
        savedHp = 0f
        java.util.Arrays.fill(endCrystals, true)
        val w = endWorld
        for (x in -3..3) for (z in -3..3) if (w.getId(x, 61, z) == 119) s.setBlock(w, x, 61, z, 0, 0)
        for (o in s.players.values) if (o.spawned && o.dim == 2) o.popup("§5Дракон Края возрождается!")
        s.log("Дракон Края возрождён кристаллами")
        spawnDragon()
        save()
    }

    // ---------- Взрыв (кристалл, кровать в Нижнем мире): урон игрокам и дракону, блоки целы ----------
    fun explode(dim: Int, x: Double, y: Double, z: Double, power: Double, src: Player?) {
        fx(x, y, z, power, dim)
        for (o in s.players.values.toList()) {
            if (!o.alive || o.dim != dim || o.dimWait) continue
            val ox = o.x - x; val oy = o.y + 0.9 - y; val oz = o.z - z
            val pd = sqrt(ox * ox + oy * oy + oz * oz)
            if (pd >= power * 2) continue
            val impact = 1 - pd / (power * 2)
            o.hurtCooldown = 0
            if (s.damage(o, floor((impact * impact + impact) * 3.5 * power + 1).toFloat(), "explosion", src)) {
                val l = hypot(ox, oz).let { if (it == 0.0) 1.0 else it }
                o.send(Pk.new(Pk.SET_ENTITY_MOTION).varlong(o.eid).vec3((ox / l * impact).toFloat(), (0.3 + impact * 0.4).toFloat(), (oz / l * impact).toFloat()))
            }
        }
        val m = dragon
        if (dim == 2 && m != null && m.dead < 0) {
            val ed = sqrt((m.x - x) * (m.x - x) + (m.y - y) * (m.y - y) + (m.z - z) * (m.z - z))
            if (ed < power * 2) {
                val impact = 1 - ed / (power * 2)
                m.invuln = 0
                hurtDragon(floor((impact * impact + impact) * 3.5 * power + 1).toFloat(), src)
            }
        }
        // Цепная реакция: соседние кристаллы тоже взрываются
        val boom = crystals.values.filter { it.dim == dim && sqrt((it.x - x) * (it.x - x) + (it.y + 1 - y) * (it.y + 1 - y) + (it.z - z) * (it.z - z)) < power * 1.5 }
        for (c in boom) if (crystals.containsKey(c.eid)) destroyCrystal(c, src)
    }

    // Только картинка и звук взрыва
    private fun fx(x: Double, y: Double, z: Double, power: Double, dim: Int = 2) {
        s.sendDim(dim, Pk.new(Pk.EXPLODE).vec3(x.toFloat(), y.toFloat(), z.toFloat()).varint((power * 32).toInt()).uvarint(0).toBytes())
    }

    // ---------- Огненные шары и дыхание ----------
    private fun shootFireball(m: Dragon, dx: Double, dy: Double, dz: Double) {
        val l = sqrt(dx * dx + dy * dy + dz * dz).let { if (it == 0.0) 1.0 else it }
        val f = Fireball(s.newEid(), m.x, m.y, m.z, dx / l * 22, dy / l * 22, dz / l * 22)
        fireballs[f.eid] = f
    }

    private fun tickFireballs(inEnd: List<Player>) {
        val w = endWorld
        for (f in fireballs.values.toList()) {
            f.age += DT
            if (f.age > 10 || !w.isLoaded(floor(f.x).toInt() shr 4, floor(f.z).toInt() shr 4)) { fireballs.remove(f.eid); despawn(f.eid); continue }
            var hit = false
            for (i in 0 until 4) {
                val nx = f.x + f.vx * DT / 4; val ny = f.y + f.vy * DT / 4; val nz = f.z + f.vz * DT / 4
                val hitP = inEnd.any { it.alive && it.gamemode != 3 && abs(it.x - nx) < 0.5 && abs(it.z - nz) < 0.5 && ny > it.y - 0.2 && ny < it.y + 2.0 }
                if (hitP || solid(nx, ny, nz)) { hit = true; break }
                f.x = nx; f.y = ny; f.z = nz
            }
            if (hit) {
                fireballs.remove(f.eid)
                despawn(f.eid)
                breathCloud(f.x, floor(f.y + 0.01), f.z)
                continue
            }
            toSeers(f.eid, moveBytes(f.eid, f.x, f.y, f.z, 0.0))
        }
    }

    // Облако драконьего дыхания: ранит тех, кто в нём стоит
    private fun breathCloud(x: Double, y0: Double, z: Double) {
        var y = y0
        while (y > 1 && !solid(x, y - 0.5, z)) y--
        s.combat.addCloud(2, x, y, z, 23)
        s.sendDim(2, Pk.new(Pk.LEVEL_EVENT).varint(2002).vec3(x.toFloat(), y.toFloat() + 0.3f, z.toFloat()).varint(0xcc4dcc).toBytes())
    }

    // ---------- Победа ----------
    // Портал выхода, яйцо (один раз), врата Края, опыт (за первого дракона 12000, потом 500)
    private fun killed() {
        val first = dragonKills == 0
        dragonKills++
        dragonKilled = true
        savedHp = 0f
        java.util.Arrays.fill(endCrystals, false)
        for (c in crystals.values.filter { it.idx >= 0 }) { crystals.remove(c.eid); despawn(c.eid) }
        for (f in fireballs.keys.toList()) despawn(f)
        fireballs.clear()
        openExit()
        spawnGateway()
        for (o in s.players.values) if (o.spawned && o.dim == 2 && !o.dead) s.addXp(o, if (first) 12000 else 500)
        s.broadcastMessage(if (first) "§dДракон Края повержен! Портал выхода открыт, появились врата Края" else "§dДракон Края снова повержен!")
        s.plugins.fire("dragonKilled", mapOf("player" to killer, "first" to first))
        killer = null
        save()
    }

    // Портал выхода в чаше из бедрока и яйцо дракона на центральном столбе
    private fun openExit() {
        val w = endWorld
        for (x in -2..2) for (z in -2..2) if (hypot(x.toDouble(), z.toDouble()) <= 2.5 && w.getId(x, 61, z) == 0) s.setBlock(w, x, 61, z, 119, 0)
        if (!eggPlaced) { s.setBlock(w, 0, 65, 0, 122, 0); eggPlaced = true }
    }

    private fun spawnGateway() {
        if (gateways.size >= 20) return
        val pos = gen.gatewayPos(gateways.size)
        gateways.add(pos)
        placeGate(pos[0], pos[1], pos[2])
    }

    // Врата и рамка из бедрока сверху и снизу
    fun placeGate(x: Int, y: Int, z: Int) {
        val w = endWorld
        if (w.getId(x, y, z) == 209) return
        s.setBlock(w, x, y, z, 209, 0)
        s.setBlock(w, x, y - 1, z, 7, 0)
        s.setBlock(w, x, y + 1, z, 7, 0)
        for (d in arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))) {
            s.setBlock(w, x + d[0], y - 2, z + d[1], 7, 0)
            s.setBlock(w, x + d[0], y + 2, z + d[1], 7, 0)
        }
    }

    // ---------- Око Края ----------
    // Летит до 12 блоков к ближайшей крепости; у крепости уходит вниз. 80 % — выпадает обратно
    fun throwEye(p: Player) {
        val st = Strongholds.nearest(s.cfg.seed, p.x, p.z)
        val dx = st[0] - p.x; val dz = st[2] - p.z
        val d = hypot(dx, dz).let { if (it == 0.0) 1.0 else it }
        val k = min(12.0, d) / d
        val ey = p.y + 1.62
        val e = Eye(s.newEid(), p.x, p.z, p.x + dx * k, p.z + dz * k, if (d < 12) ey - 3 else ey + 8, p.x, ey, p.z)
        eyes[e.eid] = e
    }

    private fun tickEyes() {
        for (e in eyes.values.toList()) {
            e.age += DT
            val k = min(1.0, e.age / 2)
            e.x = e.sx + (e.tx - e.sx) * k
            e.z = e.sz + (e.tz - e.sz) * k
            e.y += (e.ty - e.y) * min(1.0, DT * 1.5)
            toSeers(e.eid, moveBytes(e.eid, e.x, e.y, e.z, 0.0))
            if (e.age < 2.6) continue
            eyes.remove(e.eid)
            despawn(e.eid)
            if (rnd.nextDouble() < 0.8) s.items.spawn(Item(381, 0, 1), e.x, e.y, e.z, 0.0, 0.05, 0.0, 10, 0)
            else s.sendDim(0, Pk.new(Pk.LEVEL_EVENT).varint(2002).vec3(e.x.toFloat(), e.y.toFloat(), e.z.toFloat()).varint(0x4d9966).toBytes())
        }
    }
}
