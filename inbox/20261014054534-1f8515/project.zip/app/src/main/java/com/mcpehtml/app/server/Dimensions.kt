package com.mcpehtml.app.server

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

// Измерения сервера: Нижний мир и Край, крепости с порталом в Край, добыча в сундуках.
// Та же математика, что в client/js/dimensions.js: по одному зерну сервер и одиночная игра строят одинаковый мир

// Сундук с добычей при генерации чанка: (x, y, z, 27 ячеек)
typealias LootFn = (Int, Int, Int, Array<Item?>) -> Unit

private fun h3(s: Int, x: Int, y: Int, z: Int) = Perlin.hash3(s, x, y, z)
private fun jsRound(v: Double) = floor(v + 0.5).toInt()

// ---------- Добыча в сундуках ----------
object Loot {
    // [id, мин, макс, вес]
    val FORTRESS = arrayOf(intArrayOf(265, 1, 5, 5), intArrayOf(266, 1, 3, 5), intArrayOf(264, 1, 3, 2), intArrayOf(329, 1, 1, 3), intArrayOf(418, 1, 1, 2),
        intArrayOf(372, 3, 7, 4), intArrayOf(49, 2, 4, 2), intArrayOf(283, 1, 1, 3), intArrayOf(315, 1, 1, 3), intArrayOf(259, 1, 1, 3))
    val END_CITY = arrayOf(intArrayOf(264, 2, 7, 5), intArrayOf(265, 4, 8, 10), intArrayOf(266, 2, 7, 15), intArrayOf(388, 2, 6, 2), intArrayOf(329, 1, 1, 3),
        intArrayOf(417, 1, 1, 1), intArrayOf(418, 1, 1, 1), intArrayOf(419, 1, 1, 1), intArrayOf(276, 1, 1, 3), intArrayOf(278, 1, 1, 3), intArrayOf(310, 1, 1, 3),
        intArrayOf(311, 1, 1, 3), intArrayOf(312, 1, 1, 3), intArrayOf(313, 1, 1, 3), intArrayOf(432, 2, 6, 4))

    // Как fillLoot клиента: число и выбор предметов по хешу координат сундука
    fun roll(table: Array<IntArray>, seed: Int, x: Int, y: Int, z: Int, extra: List<Item>?): Array<Item?> {
        val slots = arrayOfNulls<Item>(27)
        val total = table.sumOf { it[3] }
        val n = 3 + floor(h3(seed, x, y, z) * 5).toInt()
        for (i in 0 until n) {
            var r = h3(seed + i + 1, x, y, z) * total
            var pick = table[0]
            for (t in table) { r -= t[3]; if (r <= 0) { pick = t; break } }
            val cnt = pick[1] + floor(h3(seed + 50 + i, x, y, z) * (pick[2] - pick[1] + 1)).toInt()
            slots[floor(h3(seed + 100 + i, x, y, z) * 27).toInt()] = Item(pick[0], 0, cnt)
        }
        if (extra != null) for (it in extra) { val free = slots.indexOfFirst { s -> s == null }; if (free >= 0) slots[free] = it }
        return slots
    }
}

// ---------- Крепости в обычном мире ----------
// Три крепости на кольце 320–640 блоков от центра: комната с рамкой портала в Край и три коридора
object Strongholds {
    const val Y = 28
    private val cache = HashMap<Int, List<IntArray>>()

    fun list(seed: Int): List<IntArray> = synchronized(cache) {
        cache.getOrPut(seed) {
            val a0 = h3(seed, 11, 22, 33) * PI * 2
            (0 until 3).map { i ->
                val a = a0 + i * PI * 2 / 3
                val r = 320 + h3(seed, i, 5, 7) * 320
                intArrayOf(floor(cos(a) * r).toInt(), Y, floor(sin(a) * r).toInt())
            }
        }
    }

    fun nearest(seed: Int, x: Double, z: Double): IntArray = list(seed).minByOrNull { hypot(it[0] - x, it[2] - z) }!!

    // Блоки ставятся только внутри генерируемого чанка
    fun carve(seed: Int, c: Chunk, cx: Int, cz: Int) {
        val x0 = cx * 16; val z0 = cz * 16
        for (s in list(seed)) {
            val sx = s[0]; val sz = s[2]
            if (sx + 40 < x0 || sx - 40 > x0 + 15 || sz + 40 < z0 || sz - 40 > z0 + 15) continue
            fun put(x: Int, y: Int, z: Int, id: Int, d: Int = 0) {
                val lx = x - x0; val lz = z - z0
                if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 1 || y > 255) return
                c.set(lx, y, lz, id, d)
            }
            fun brick(x: Int, y: Int, z: Int) {
                val r = h3(seed + 41, x, y, z)
                put(x, y, z, 98, if (r < 0.2) 1 else if (r < 0.35) 2 else 0)
            }
            // Полая коробка из каменных кирпичей
            fun room(ax: Int, ay: Int, az: Int, bx: Int, by: Int, bz: Int) {
                for (x in ax..bx) for (y in ay..by) for (z in az..bz) {
                    if (x == ax || x == bx || y == ay || y == by || z == az || z == bz) brick(x, y, z) else put(x, y, z, 0)
                }
            }
            val y0 = s[1]
            room(sx - 2, y0 - 1, sz - 34, sx + 2, y0 + 3, sz - 7)
            room(sx - 34, y0 - 1, sz - 2, sx - 5, y0 + 3, sz + 2)
            room(sx + 5, y0 - 1, sz - 2, sx + 34, y0 + 3, sz + 2)
            var k = -30
            while (k <= -9) { put(sx, y0 + 2, sz + k, 89); k += 6 }
            k = 8
            while (k <= 32) { put(sx - k, y0 + 2, sz, 89); put(sx + k, y0 + 2, sz, 89); k += 6 }
            // Комната с порталом 11×15, высота 7, и проходы в коридоры
            room(sx - 5, y0 - 1, sz - 7, sx + 5, y0 + 7, sz + 7)
            for (d in arrayOf(intArrayOf(0, -7), intArrayOf(-5, 0), intArrayOf(5, 0))) for (dy in 0 until 3) for (w in -1..1) {
                put(sx + d[0] + (if (d[1] != 0) w else 0), y0 + dy, sz + d[1] + (if (d[0] != 0) w else 0), 0)
            }
            // Помост с рамкой портала над лавой; 10 % рамок уже с оком
            val pcx = sx; val pcz = sz + 2
            for (x in pcx - 3..pcx + 3) for (z in pcz - 3..pcz + 3) brick(x, y0, z)
            for (x in pcx - 1..pcx + 1) for (z in pcz - 1..pcz + 1) { put(x, y0, z, 11); put(x, y0 + 1, z, 0) }
            fun eye(k2: Int) = if (h3(seed + 77, sx, k2, sz) < 0.1) 4 else 0
            for (i in -1..1) {
                put(pcx + i, y0 + 1, pcz - 2, 120, 0 or eye(i))
                put(pcx + i, y0 + 1, pcz + 2, 120, 2 or eye(i + 10))
                put(pcx - 2, y0 + 1, pcz + i, 120, 3 or eye(i + 20))
                put(pcx + 2, y0 + 1, pcz + i, 120, 1 or eye(i + 30))
            }
            // Лестница к помосту, светокамень на потолке, решётки вдоль стен
            for (x in pcx - 1..pcx + 1) put(x, y0, pcz - 4, 109, 2)
            for (d in arrayOf(intArrayOf(-4, -6), intArrayOf(4, -6), intArrayOf(-4, 6), intArrayOf(4, 6))) put(sx + d[0], y0 + 6, sz + d[1], 89)
            var z = sz - 6
            while (z <= sz + 6) { put(sx - 4, y0 + 1, z, 101); put(sx + 4, y0 + 1, z, 101); z += 3 }
        }
    }
}

// ---------- Нижний мир ----------
class NetherGenerator(override val seed: Int) : WorldGen {
    override var loot: LootFn? = null
    private val n1 = Perlin(seed + 101)
    private val n2 = Perlin(seed + 102)
    private val n3 = Perlin(seed + 103)
    val LAVA = 31

    private fun density(x: Int, y: Int, z: Int): Double {
        var d = n1.noise3(x / 48.0, y / 28.0, z / 48.0) + 0.5 * n2.noise3(x / 16.0, y / 12.0, z / 16.0) - 0.12
        if (y < 24) d += (24 - y) / 10.0
        if (y > 100) d += (y - 100) / 8.0
        return d
    }

    override fun generate(cx: Int, cz: Int): Chunk {
        val c = Chunk(cx, cz)
        val H = seed
        for (x in 0 until 16) for (z in 0 until 16) {
            val wx = cx * 16 + x; val wz = cz * 16 + z
            for (y in 0..127) {
                var id = 0
                if (y == 0 || y == 127 || (y < 5 && h3(H, wx, y, wz) < 0.5 - y * 0.1) || (y > 122 && h3(H, wx, y, wz) < 0.5 - (127 - y) * 0.1)) id = 7
                else if (density(wx, y, wz) > 0) {
                    id = 87
                    val r = h3(H + 5, wx, y, wz)
                    if (r < 0.018) id = 153 else if (y in 28..33 && r > 0.9) id = 213
                } else if (y <= LAVA) id = 11
                if (id != 0) c.set(x, y, z, id, 0)
            }
            // Песок душ и гравий у берегов лавового моря, светокамень под потолком
            val patch = n3.noise2(wx / 24.0, wz / 24.0)
            for (y in 30..40) {
                if (c.getId(x, y, z) != 87 || c.getId(x, y + 1, z) != 0) continue
                if (patch > 0.3) { c.set(x, y, z, 88, 0); if (y > 30) c.set(x, y - 1, z, 88, 0) }
                else if (patch < -0.4) c.set(x, y, z, 13, 0)
            }
            for (y in 60 until 122) {
                if (c.getId(x, y, z) != 87 || c.getId(x, y - 1, z) != 0) continue
                if (h3(H + 9, wx, y, wz) < 0.006) {
                    val n = 2 + floor(h3(H + 10, wx, y, wz) * 4).toInt()
                    var k = 1
                    while (k <= n && c.getId(x, y - k, z) == 0) { c.set(x, y - k, z, 89, 0); k++ }
                }
            }
        }
        fortress(c, cx, cz)
        c.recalcHeight()
        return c
    }

    // Адская крепость: мосты крестом через участок 128×128, опоры до земли, зал с адским наростом
    fun fortressAt(rx: Int, rz: Int): IntArray? {
        if (h3(seed + 55, rx, 0, rz) > 0.55) return null
        return intArrayOf(rx * 128 + 32 + floor(h3(seed + 56, rx, 1, rz) * 64).toInt(), 64 + floor(h3(seed + 57, rx, 2, rz) * 10).toInt(),
            rz * 128 + 32 + floor(h3(seed + 58, rx, 3, rz) * 64).toInt())
    }

    private fun fortress(c: Chunk, cx: Int, cz: Int) {
        val x0 = cx * 16; val z0 = cz * 16
        val rx = Math.floorDiv(x0 + 8, 128); val rz = Math.floorDiv(z0 + 8, 128)
        for (ax in rx - 1..rx + 1) for (az in rz - 1..rz + 1) {
            val f = fortressAt(ax, az) ?: continue
            val fx = f[0]; val y0 = f[1]; val fz = f[2]
            if (fx + 56 < x0 || fx - 56 > x0 + 15 || fz + 56 < z0 || fz - 56 > z0 + 15) continue
            fun put(x: Int, y: Int, z: Int, id: Int, d: Int = 0) {
                val lx = x - x0; val lz = z - z0
                if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 1 || y > 126) return
                c.set(lx, y, lz, id, d)
            }
            fun get(x: Int, y: Int, z: Int) = c.getId(x - x0, y, z - z0)
            fun inChunk(x: Int, z: Int) = x >= x0 && x <= x0 + 15 && z >= z0 && z <= z0 + 15
            // Мост: настил 5 в ширину, перила-заборы, проход высотой 4, опоры через 8 блоков
            fun bridge(along: Boolean) {
                for (t in -52..52) for (w in -2..2) {
                    val x = if (along) fx + t else fx + w; val z = if (along) fz + w else fz + t
                    if (!inChunk(x, z)) continue
                    put(x, y0, z, 112)
                    for (dy in 1..4) put(x, y0 + dy, z, 0)
                    if (abs(w) == 2) put(x, y0 + 1, z, 113)
                    if (t % 8 == 0 && abs(w) == 2) {
                        var y = y0 - 1
                        while (y > 1) {
                            val id = get(x, y, z)
                            if (id != 0 && id != 10 && id != 11) break
                            put(x, y, z, 112)
                            y--
                        }
                    }
                }
            }
            bridge(true)
            bridge(false)
            // Центральный зал 11×11 с окнами и грядками адского нароста
            for (x in fx - 5..fx + 5) for (z in fz - 5..fz + 5) for (y in y0..y0 + 6) {
                if (!inChunk(x, z)) continue
                val edge = x == fx - 5 || x == fx + 5 || z == fz - 5 || z == fz + 5
                if (y == y0 || y == y0 + 6) put(x, y, z, 112)
                else if (edge) put(x, y, z, if (y == y0 + 3 && (x + z) % 3 == 0) 113 else 112)
                else put(x, y, z, 0)
            }
            for (d in arrayOf(intArrayOf(0, -5), intArrayOf(0, 5), intArrayOf(-5, 0), intArrayOf(5, 0))) for (w in -1..1) for (dy in 1..3) {
                put(fx + d[0] + (if (d[1] != 0) w else 0), y0 + dy, fz + d[1] + (if (d[0] != 0) w else 0), 0)
            }
            for (sx in intArrayOf(-3, 2)) for (x in fx + sx..fx + sx + 1) for (z in fz - 3..fz + 3) {
                put(x, y0, z, 88)
                put(x, y0 + 1, z, 115, floor(h3(seed + 59, x, y0, z) * 4).toInt())
            }
            // Сундуки крепости в углах зала
            for (ch in arrayOf(intArrayOf(fx - 4, y0 + 1, fz + 4, 2), intArrayOf(fx + 4, y0 + 1, fz - 4, 3))) {
                if (!inChunk(ch[0], ch[2])) continue
                put(ch[0], ch[1], ch[2], 54, ch[3])
                loot?.invoke(ch[0], ch[1], ch[2], Loot.roll(Loot.FORTRESS, seed + 61, ch[0], ch[1], ch[2], null))
                c.modified = true
            }
            // Площадки с рассадниками ифритов на концах мостов
            for (sp in arrayOf(intArrayOf(fx + 40, fz), intArrayOf(fx, fz - 40))) {
                val sx = sp[0]; val sz = sp[1]
                for (dx in -3..3) for (dz in -3..3) {
                    val x = sx + dx; val z = sz + dz
                    if (!inChunk(x, z)) continue
                    put(x, y0, z, 112)
                    for (dy in 1..4) put(x, y0 + dy, z, 0)
                    val edge = abs(dx) == 3 || abs(dz) == 3
                    val path = if (sx == fx) abs(dx) <= 1 else abs(dz) <= 1
                    if (edge && !path) put(x, y0 + 1, z, 113)
                }
                val bx = sx + (if (sx == fx) 2 else 0); val bz = sz + (if (sx == fx) 0 else 2)
                if (inChunk(bx, bz)) put(bx, y0 + 1, bz, 52, 4)
            }
        }
    }

    override fun findSpawn(): DoubleArray = doubleArrayOf(0.5, 64.0, 0.5)
    override fun mcpeBiome(x: Int, z: Int): Int = 8
}

// ---------- Край ----------
// Центральный остров со столбами, внешние острова дальше 1000 блоков с хорусом и городами Края
class EndGenerator(override val seed: Int) : WorldGen {
    override var loot: LootFn? = null
    // Портал выхода открыт (дракон побеждён)
    var exitOpen: () -> Boolean = { false }
    private val n1 = Perlin(seed + 201)
    private val n2 = Perlin(seed + 202)

    class Pillar(val i: Int, val x: Int, val z: Int, val r: Int, val h: Int, val cage: Boolean)
    class Col(val top: Int, val bottom: Int)
    class City(val x: Int, val y: Int, val z: Int) {
        var blocks: List<IntArray>? = null
        val chests = ArrayList<Pair<IntArray, List<Item>?>>()
    }

    private val cities = HashMap<Long, City?>()

    companion object {
        const val OUTER_R = 1000
        const val GATEWAY_R = 96
        const val GATEWAY_Y = 75
        val SPAWN = doubleArrayOf(100.5, 49.0, 0.5)
    }

    // 10 обсидиановых столбов на окружности радиусом 42, два — в клетках из решёток
    val pillars: List<Pillar> = (0 until 10).map { i ->
        val a = i * PI * 2 / 10
        Pillar(i, jsRound(cos(a) * 42), jsRound(sin(a) * 42), 2 + (i % 3), 76 + ((i * 7) % 10) * 3, i == 3 || i == 9)
    }

    fun outerColumn(wx: Int, wz: Int): Col? {
        if (hypot(wx.toDouble(), wz.toDouble()) < OUTER_R) return null
        val S = 56; val H = seed + 301
        val cx = Math.floorDiv(wx, S); val cz = Math.floorDiv(wz, S)
        var best: Col? = null
        for (dx in -1..1) for (dz in -1..1) {
            val ax = cx + dx; val az = cz + dz
            if (h3(H, ax, 0, az) > 0.62) continue
            val x0 = ax * S + 8 + h3(H, ax, 1, az) * 40; val z0 = az * S + 8 + h3(H, ax, 2, az) * 40
            if (hypot(x0, z0) < OUTER_R) continue
            val R = 9 + h3(H, ax, 3, az) * 16
            val d = hypot(wx - x0, wz - z0)
            val edge = R * (0.8 + 0.35 * n1.noise2(wx / 12.0, wz / 12.0))
            if (d >= edge) continue
            val top = 56 + floor(h3(H, ax, 4, az) * 12).toInt() + floor(n2.noise2(wx / 9.0, wz / 9.0) * 1.5).toInt()
            val depth = floor((1 - (d / edge) * (d / edge)) * R * 0.9).toInt() + 1
            if (best == null || top > best.top) best = Col(top, top - depth)
        }
        return best
    }

    override fun generate(cx: Int, cz: Int): Chunk {
        val c = Chunk(cx, cz)
        val H = seed
        val far = hypot(cx * 16 + 8.0, cz * 16 + 8.0) > OUTER_R - 40
        for (x in 0 until 16) for (z in 0 until 16) {
            val wx = cx * 16 + x; val wz = cz * 16 + z
            if (far) {
                val col = outerColumn(wx, wz) ?: continue
                for (y in col.bottom..col.top) c.set(x, y, z, 121, 0)
                // Хорус: стебель с цветком, иногда с веткой
                if (col.top - col.bottom >= 3 && h3(H + 310, wx, 0, wz) < 0.008) {
                    val h = 2 + floor(h3(H + 311, wx, 0, wz) * 4).toInt()
                    for (y in 1..h) c.set(x, col.top + y, z, 240, 0)
                    c.set(x, col.top + h + 1, z, 200, 0)
                    val by = col.top + 1 + floor(h3(H + 312, wx, 0, wz) * h).toInt()
                    val dir = floor(h3(H + 313, wx, 0, wz) * 4).toInt()
                    val b = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))[dir]
                    if (x + b[0] in 0..15 && z + b[1] in 0..15) { c.set(x + b[0], by, z + b[1], 240, 0); c.set(x + b[0], by + 1, z + b[1], 200, 0) }
                }
                continue
            }
            val r = hypot(wx.toDouble(), wz.toDouble())
            val edge = 68 + n1.noise2(wx / 40.0, wz / 40.0) * 10
            if (r >= edge) continue
            val top = 60 + floor(n1.noise2(wx / 25.0 + 50, wz / 25.0) * 2).toInt()
            val depth = 3 + floor((1 - r / edge) * (1 - r / edge) * 45).toInt()
            for (y in top - depth..top) c.set(x, y, z, 121, 0)
        }
        if (!far) {
            for (p in pillars) {
                for (x in p.x - p.r - 2..p.x + p.r + 2) for (z in p.z - p.r - 2..p.z + p.r + 2) {
                    val lx = x - cx * 16; val lz = z - cz * 16
                    if (lx < 0 || lx > 15 || lz < 0 || lz > 15) continue
                    if (hypot((x - p.x).toDouble(), (z - p.z).toDouble()) <= p.r + 0.5) {
                        for (y in 50..p.h) c.set(lx, y, lz, 49, 0)
                        if (x == p.x && z == p.z) c.set(lx, p.h + 1, lz, 7, 0)
                    }
                    // Клетка из железных решёток вокруг кристалла
                    if (p.cage && abs(x - p.x) <= 2 && abs(z - p.z) <= 2) {
                        val edge = abs(x - p.x) == 2 || abs(z - p.z) == 2
                        for (y in p.h + 1..p.h + 4) if (edge) c.set(lx, y, lz, 101, 0)
                        c.set(lx, p.h + 5, lz, 101, 0)
                    }
                }
            }
            exitPortal(c, cx, cz)
        } else cityParts(c, cx, cz)
        c.recalcHeight()
        return c
    }

    // Чаша портала выхода из бедрока; портал открывается после победы над драконом
    private fun exitPortal(c: Chunk, cx: Int, cz: Int) {
        val open = exitOpen()
        for (x in -4..4) for (z in -4..4) {
            val lx = x - cx * 16; val lz = z - cz * 16
            if (lx < 0 || lx > 15 || lz < 0 || lz > 15) continue
            val r = hypot(x.toDouble(), z.toDouble())
            if (r > 3.5) continue
            c.set(lx, 60, lz, 7, 0)
            if (r > 2.5) c.set(lx, 61, lz, 7, 0) else c.set(lx, 61, lz, if (open) 119 else 0, 0)
            if (x == 0 && z == 0) for (y in 61..64) c.set(lx, y, lz, 7, 0)
            else for (y in 62..66) c.set(lx, y, lz, 0, 0)
        }
    }

    // Город Края в ячейке 400×400, если рядом с её точкой есть остров
    private fun cityAt(rx: Int, rz: Int): City? {
        val k = (rx.toLong() shl 32) or (rz.toLong() and 0xffffffffL)
        if (cities.containsKey(k)) return cities[k]
        var c: City? = null
        val H = seed + 401
        if (h3(H, rx, 0, rz) < 0.55) {
            val x = rx * 400 + 100 + floor(h3(H, rx, 1, rz) * 200).toInt(); val z = rz * 400 + 100 + floor(h3(H, rx, 2, rz) * 200).toInt()
            if (hypot(x.toDouble(), z.toDouble()) > OUTER_R + 100) {
                var r = 0
                search@ while (r <= 40) {
                    for (a in 0 until 8) {
                        val tx = x + jsRound(cos(a * PI / 4) * r); val tz = z + jsRound(sin(a * PI / 4) * r)
                        val cc = outerColumn(tx, tz)
                        if (cc != null && cc.top - cc.bottom >= 4) { c = City(tx, cc.top + 1, tz); break@search }
                    }
                    r += 4
                }
            }
        }
        cities[k] = c
        return c
    }

    // Башня из пурпура с лестницей, комната с сундуком наверху, корабль Края с элитрами
    private fun cityBlocks(c: City): List<IntArray> {
        c.blocks?.let { return it }
        val out = ArrayList<IntArray>()
        fun put(x: Int, y: Int, z: Int, id: Int, d: Int = 0) { out.add(intArrayOf(x, y, z, id, d)) }
        val X = c.x; val Y = c.y; val Z = c.z; val TH = 26
        for (y in Y until Y + TH) for (x in -4..4) for (z in -4..4) {
            val edge = abs(x) == 4 || abs(z) == 4
            val floorL = (y - Y) % 7 == 0
            val corner = abs(x) == 4 && abs(z) == 4
            var id = 0; var d = 0
            if (corner) { id = 201; d = 2 }
            else if (edge) id = if ((y - Y) % 7 == 3 && (x == 0 || z == 0)) 0 else 201
            else if (floorL && !(x == 3 && z == 0)) id = if (y == Y) 206 else 201
            put(X + x, y, Z + z, id, d)
        }
        for (y in Y + 1 until Y + TH + 1) put(X + 3, y, Z, 65, 4)
        for (y in Y + 1..Y + 2) put(X, y, Z - 4, 0)
        val R = Y + TH
        for (y in R..R + 5) for (x in -5..5) for (z in -5..5) {
            val edge = abs(x) == 5 || abs(z) == 5
            var id = 0
            if (y == R && !(x == 3 && z == 0)) id = 201
            else if (y == R + 5) id = 201
            else if (edge) id = if (y == R + 2 && (abs(x) == 2 || abs(z) == 2)) 20 else 201
            put(X + x, y, Z + z, id, if (abs(x) == 5 && abs(z) == 5) 2 else 0)
        }
        for (d in arrayOf(intArrayOf(-5, -5), intArrayOf(5, -5), intArrayOf(-5, 5), intArrayOf(5, 5))) put(X + d[0], R + 6, Z + d[1], 208, 1)
        put(X, R + 1, Z + 3, 54, 2)
        c.chests.add(intArrayOf(X, R + 1, Z + 3) to null)
        // Корабль Края рядом с городом
        val SX = X + 22; val SY = R + 10; val SZ = Z
        for (x in -10..10) {
            val half = if (x < -7) 1 else if (x > 7) max(0, 10 - x) else 3
            for (z in -half..half) {
                put(SX + x, SY, SZ + z, 201)
                if (abs(z) == half) { put(SX + x, SY + 1, SZ + z, 201); put(SX + x, SY + 2, SZ + z, 203, if (z > 0) 3 else 2) }
            }
            if (abs(x) <= 7) put(SX + x, SY - 1, SZ, 206)
        }
        for (y in SY + 1..SY + 12) put(SX - 2, y, SZ, 208, 1)
        for (z in -4..4) put(SX - 2, SY + 10, SZ + z, 35, 10)
        // Каюта с сундуками: в одном элитры
        for (x in -4..4) for (z in -2..2) for (y in SY - 4..SY - 1) {
            val edge = abs(x) == 4 || abs(z) == 2 || y == SY - 4
            put(SX + x, y, SZ + z, if (edge) 201 else 0)
        }
        put(SX + 3, SY - 1, SZ, 0)
        put(SX + 3, SY, SZ, 0)
        put(SX - 3, SY - 3, SZ - 1, 54, 3)
        put(SX - 3, SY - 3, SZ + 1, 54, 2)
        c.chests.add(intArrayOf(SX - 3, SY - 3, SZ - 1) to listOf(Item(444, 0, 1)))
        c.chests.add(intArrayOf(SX - 3, SY - 3, SZ + 1) to null)
        c.blocks = out
        return out
    }

    private fun cityParts(ch: Chunk, cx: Int, cz: Int) {
        val x0 = cx * 16; val z0 = cz * 16
        val rx = Math.floorDiv(x0 + 8, 400); val rz = Math.floorDiv(z0 + 8, 400)
        for (ax in rx - 1..rx + 1) for (az in rz - 1..rz + 1) {
            val c = cityAt(ax, az) ?: continue
            if (c.x + 40 < x0 || c.x - 20 > x0 + 15 || c.z + 20 < z0 || c.z - 20 > z0 + 15) continue
            for (b in cityBlocks(c)) {
                val lx = b[0] - x0; val lz = b[2] - z0
                if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || b[1] < 1 || b[1] > 254) continue
                ch.set(lx, b[1], lz, b[3], b[4])
            }
            for ((p, extra) in c.chests) {
                if (p[0] < x0 || p[0] > x0 + 15 || p[2] < z0 || p[2] > z0 + 15) continue
                loot?.invoke(p[0], p[1], p[2], Loot.roll(Loot.END_CITY, seed + 77, p[0], p[1], p[2], extra))
                ch.modified = true
            }
        }
    }

    // Точка на внешнем острове в направлении (dx, dz) примерно в 1024 блоках от центра: [x, y, z], y = 0 — острова нет
    fun outerLanding(dx: Int, dz: Int): IntArray {
        val l = hypot(dx.toDouble(), dz.toDouble()).let { if (it == 0.0) 1.0 else it }
        val bx = jsRound(dx / l * 1024); val bz = jsRound(dz / l * 1024)
        var r = 0
        while (r <= 160) {
            for (a in 0 until 16) {
                val x = bx + jsRound(cos(a * PI / 8) * r); val z = bz + jsRound(sin(a * PI / 8) * r)
                val c = outerColumn(x, z)
                if (c != null && c.top - c.bottom >= 3) return intArrayOf(x, c.top + 1, z)
                if (r == 0) break
            }
            r += 4
        }
        return intArrayOf(bx, 0, bz)
    }

    // 20 врат Края по кругу в постоянном для мира порядке
    fun gatewayPos(i: Int): IntArray {
        val order = IntArray(20) { it }
        for (k in 19 downTo 1) { val j = floor(h3(seed + 501, k, 0, 0) * (k + 1)).toInt(); val t = order[k]; order[k] = order[j]; order[j] = t }
        val a = order[i % 20] * PI * 2 / 20
        return intArrayOf(floor(cos(a) * GATEWAY_R).toInt(), GATEWAY_Y, floor(sin(a) * GATEWAY_R).toInt())
    }

    override fun findSpawn(): DoubleArray = SPAWN.copyOf()
    override fun mcpeBiome(x: Int, z: Int): Int = 9
}
