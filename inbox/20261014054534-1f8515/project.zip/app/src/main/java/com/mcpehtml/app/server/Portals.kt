package com.mcpehtml.app.server

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

// Порталы и переходы между измерениями (как Portals в client/js/dimensions.js):
// портал в Нижний мир из обсидиановой рамки, портал в Край из 12 рамок с оком, врата Края
class Portals(private val s: MineServer) {
    companion object {
        val NAMES = arrayOf("Обычный мир", "Нижний мир", "Край")
        private val SIDES = arrayOf(intArrayOf(1, 0, 0), intArrayOf(-1, 0, 0), intArrayOf(0, 1, 0), intArrayOf(0, -1, 0), intArrayOf(0, 0, 1), intArrayOf(0, 0, -1))
    }

    class Frame(val x: Int, val y: Int, val z: Int, val w: Int, val h: Int, val dx: Int, val dz: Int)

    // Пока строим портал или рушим его, проверка рамки не нужна
    private var quiet = false

    private fun isAir(id: Int) = id == 0 || id == 51
    private fun opaque(id: Int) = Blocks.solid[id] && Blocks.blocksLight[id]

    // ---------- Портал в Нижний мир ----------
    // Огниво: внутри обсидиановой рамки зажигает портал (data — ось: 1 вдоль x, 2 вдоль z)
    fun ignite(w: World, x: Int, y: Int, z: Int): Boolean {
        if (!isAir(w.getId(x, y, z))) return false
        for (axis in intArrayOf(1, 2)) {
            val f = findFrame(w, x, y, z, axis) ?: continue
            quiet = true
            try {
                for (i in 0 until f.w) for (j in 0 until f.h) s.setBlock(w, f.x + f.dx * i, f.y + j, f.z + f.dz * i, 90, axis)
            } finally { quiet = false }
            return true
        }
        return false
    }

    // Рамка: обсидиан по краям прямоугольника с проёмом от 2×3 до 21×21; углы не обязательны
    fun findFrame(w: World, x: Int, y: Int, z: Int, axis: Int): Frame? {
        val dx = if (axis == 1) 1 else 0; val dz = if (axis == 2) 1 else 0
        var by = y
        var k = 0
        while (k < 22 && isAir(w.getId(x, by - 1, z))) { by--; k++ }
        if (w.getId(x, by - 1, z) != 49) return null
        var sx = x; var sz = z
        k = 0
        while (k < 22 && isAir(w.getId(sx - dx, by, sz - dz))) { sx -= dx; sz -= dz; k++ }
        if (w.getId(sx - dx, by, sz - dz) != 49) return null
        var width = 0
        while (width < 22 && isAir(w.getId(sx + dx * width, by, sz + dz * width))) width++
        if (width < 2 || width > 21 || w.getId(sx + dx * width, by, sz + dz * width) != 49) return null
        var height = 0
        while (height < 22 && isAir(w.getId(sx, by + height, sz))) height++
        if (height < 3 || height > 21 || w.getId(sx, by + height, sz) != 49) return null
        for (i in 0 until width) {
            if (w.getId(sx + dx * i, by - 1, sz + dz * i) != 49 || w.getId(sx + dx * i, by + height, sz + dz * i) != 49) return null
            for (j in 0 until height) if (!isAir(w.getId(sx + dx * i, by + j, sz + dz * i))) return null
        }
        for (j in 0 until height) {
            if (w.getId(sx - dx, by + j, sz - dz) != 49 || w.getId(sx + dx * width, by + j, sz + dz * width) != 49) return null
        }
        return Frame(sx, by, sz, width, height, dx, dz)
    }

    // Портал цел, если по сторонам его плоскости и сверху-снизу — портал или обсидиан
    private fun validPortal(w: World, x: Int, y: Int, z: Int): Boolean {
        val d = w.getData(x, y, z)
        fun ok(id: Int) = id == 90 || id == 49
        val side = if (d == 2) arrayOf(intArrayOf(0, 0, 1), intArrayOf(0, 0, -1)) else arrayOf(intArrayOf(1, 0, 0), intArrayOf(-1, 0, 0))
        for (o in side + arrayOf(intArrayOf(0, 1, 0), intArrayOf(0, -1, 0))) if (!ok(w.getId(x + o[0], y + o[1], z + o[2]))) return false
        return true
    }

    // Блок изменился: соседний портал без рамки рушится целиком
    fun checkAround(w: World, x: Int, y: Int, z: Int) {
        if (quiet) return
        for (o in SIDES) {
            val nx = x + o[0]; val ny = y + o[1]; val nz = z + o[2]
            if (ny < 0 || ny > 255 || !w.isLoaded(nx shr 4, nz shr 4)) continue
            if (w.getId(nx, ny, nz) == 90 && !validPortal(w, nx, ny, nz)) breakPortal(w, nx, ny, nz)
        }
    }

    private fun breakPortal(w: World, x: Int, y: Int, z: Int) {
        val queue = ArrayDeque<IntArray>()
        queue.add(intArrayOf(x, y, z))
        val seen = HashSet<Long>()
        quiet = true
        try {
            while (queue.isNotEmpty() && seen.size < 600) {
                val c = queue.removeLast()
                if (c[1] < 0 || c[1] > 255) continue
                val k = (c[0].toLong() shl 36) or ((c[1].toLong() and 0xff) shl 28) or (c[2].toLong() and 0xfffffff)
                if (seen.contains(k) || w.getId(c[0], c[1], c[2]) != 90) continue
                seen.add(k)
                s.setBlock(w, c[0], c[1], c[2], 0, 0)
                for (o in SIDES) queue.add(intArrayOf(c[0] + o[0], c[1] + o[1], c[2] + o[2]))
            }
        } finally { quiet = false }
    }

    // ---------- Стоя в портале ----------
    fun tick(p: Player) {
        if (!p.alive) return
        val w = s.worldOf(p)
        val bx = floor(p.x).toInt(); val bz = floor(p.z).toInt()
        val fy = floor(p.y + 0.2).toInt(); val hy = floor(p.y + 1).toInt()
        if (!w.isLoaded(bx shr 4, bz shr 4)) return
        val feet = w.getId(bx, fy, bz); val body = w.getId(bx, hy, bz)
        if (feet == 119 || body == 119) {
            if (!p.portalCooldown) { p.portalCooldown = true; travelEnd(p) }
            return
        }
        // Врата Края: мгновенный перенос на внешние острова и обратно
        if (feet == 209 || body == 209) {
            if (!p.portalCooldown) { p.portalCooldown = true; enterGateway(p, bx, if (feet == 209) fy else hy, bz) }
            return
        }
        if (feet == 90 || body == 90) {
            if (p.portalCooldown) return
            p.portalTicks++
            // В выживании нужно постоять 4 секунды, в творческом — почти сразу
            if (p.portalTicks >= (if (p.gamemode == 1) 6 else 80)) {
                p.portalTicks = 0
                p.portalCooldown = true
                travelNether(p)
            }
            return
        }
        p.portalTicks = 0
        p.portalCooldown = false
    }

    // Обычный мир ↔ Нижний мир: координаты делятся (умножаются) на 8, портал ищется рядом или строится
    private fun travelNether(p: Player) {
        val from = p.dim
        val target = if (from == 1) 0 else 1
        var x = p.x; var y = p.y; var z = p.z
        if (from == 0 && target == 1) { x = p.x / 8; z = p.z / 8; y = max(34.0, min(110.0, p.y)) }
        else if (from == 1 && target == 0) { x = p.x * 8; z = p.z * 8 }
        val tw = s.worldAt(target)
        val ix = floor(x).toInt(); val iz = floor(z).toInt()
        val spot = findPortal(tw, ix, iz, if (target == 1) 16 else 64) ?: buildPortal(tw, ix, floor(y).toInt(), iz, target)
        s.changeDimension(p, target, spot[0] + 0.5, spot[1].toDouble(), spot[2] + 0.5)
        p.popup("§7" + NAMES[target])
    }

    // Портал Края: из обычного мира (и Нижнего) — на площадку в Крае, из Края — домой
    private fun travelEnd(p: Player) {
        if (p.dim == 2) {
            val sp = s.respawnPoint(p)
            s.changeDimension(p, 0, sp[0], sp[1], sp[2])
            p.popup("§7" + NAMES[0])
            return
        }
        toEndPlatform(p)
    }

    // Обсидиановая площадка 5×5 у центрального острова и воздух над ней, как при входе в Край
    private fun endPlatform(): DoubleArray {
        val w = s.worldAt(2)
        val sp = EndGenerator.SPAWN
        val bx = floor(sp[0]).toInt(); val bz = floor(sp[2]).toInt()
        quiet = true
        try {
            for (dx in -2..2) for (dz in -2..2) {
                s.setBlock(w, bx + dx, 48, bz + dz, 49, 0)
                for (dy in 1..3) s.setBlock(w, bx + dx, 48 + dy, bz + dz, 0, 0)
            }
        } finally { quiet = false }
        return sp
    }

    private fun toEndPlatform(p: Player) {
        val sp = endPlatform()
        if (p.dim == 2) { s.teleport(p, sp[0], sp[1], sp[2]); s.end.spawnDragon() }
        else s.changeDimension(p, 2, sp[0], sp[1], sp[2])
        p.popup("§7" + NAMES[2])
    }

    // Ближайший портал (нижний блок) вокруг точки: ближние чанки загружаются, дальние — только уже загруженные
    private fun findPortal(w: World, x: Int, z: Int, r: Int): IntArray? {
        var best: IntArray? = null
        var bd = Long.MAX_VALUE
        for (cx in ((x - r) shr 4)..((x + r) shr 4)) for (cz in ((z - r) shr 4)..((z + r) shr 4)) {
            val near = cx * 16 + 15 >= x - 16 && cx * 16 <= x + 16 && cz * 16 + 15 >= z - 16 && cz * 16 <= z + 16
            if (!near && !w.isLoaded(cx, cz)) continue
            val c = w.chunk(cx, cz)
            for (lx in 0 until 16) for (lz in 0 until 16) {
                val px = cx * 16 + lx; val pz = cz * 16 + lz
                if (abs(px - x) > r || abs(pz - z) > r) continue
                for (sy in 0 until 16) {
                    if (c.ids[sy] == null) continue
                    for (yy in 0 until 16) {
                        val py = (sy shl 4) + yy
                        if (py < 1 || py > 254) continue
                        if (c.getId(lx, py, lz) != 90 || c.getId(lx, py - 1, lz) == 90) continue
                        val d = (px - x).toLong() * (px - x) + (pz - z).toLong() * (pz - z)
                        if (d < bd) { bd = d; best = intArrayOf(px, py, pz) }
                    }
                }
            }
        }
        return best
    }

    // Новый портал 4×5 (проём 2×3) на подходящем месте; если места нет — с обсидиановой площадкой
    private fun buildPortal(w: World, x: Int, y: Int, z: Int, dim: Int): IntArray {
        val lo = if (dim == 1) 32 else 4; val hi = if (dim == 1) 118 else 250
        var spot: IntArray? = null
        var r = 0
        search@ while (r <= 12) {
            var dx = -r
            while (dx <= r) {
                var dz = -r
                while (dz <= r) {
                    for (dy in 0..60) for (yy in intArrayOf(y - dy, y + dy)) {
                        if (yy < lo || yy > hi) continue
                        val bx = x + dx; val bz = z + dz
                        var ok = true
                        var i = -1
                        while (i <= 2 && ok) {
                            if (!opaque(w.getId(bx + i, yy - 1, bz))) ok = false
                            var j = 0
                            while (j < 4 && ok) { if (w.getId(bx + i, yy + j, bz) != 0) ok = false; j++ }
                            i++
                        }
                        if (ok) { spot = intArrayOf(bx, yy, bz); break@search }
                    }
                    dz += 2
                }
                dx += 2
            }
            r += 2
        }
        quiet = true
        try {
            if (spot == null) {
                val yy = max(lo, min(hi - 5, if (dim == 1) 70 else y))
                spot = intArrayOf(x, yy, z)
                for (i in -1..2) for (k in -1..1) {
                    s.setBlock(w, x + i, yy - 1, z + k, 49, 0)
                    for (j in 0 until 4) s.setBlock(w, x + i, yy + j, z + k, 0, 0)
                }
            }
            val sx = spot[0]; val sy = spot[1]; val sz = spot[2]
            for (i in -1..2) for (j in -1..3) {
                val edge = i == -1 || i == 2 || j == -1 || j == 3
                s.setBlock(w, sx + i, sy + j, sz, if (edge) 49 else 90, if (edge) 0 else 1)
            }
        } finally { quiet = false }
        return spot!!
    }

    // ---------- Портал в Край ----------
    // Око Края в рамку; когда у всех 12 рамок кольца есть око — середина 3×3 заполняется порталом
    fun placeEye(w: World, x: Int, y: Int, z: Int): Boolean {
        val d = w.getData(x, y, z)
        if (w.getId(x, y, z) != 120 || d and 4 != 0) return false
        s.setBlock(w, x, y, z, 120, d or 4)
        for (cx in x - 2..x + 2) for (cz in z - 2..z + 2) {
            var ok = true
            for (i in -1..1) {
                for (f in arrayOf(intArrayOf(cx + i, cz - 2), intArrayOf(cx + i, cz + 2), intArrayOf(cx - 2, cz + i), intArrayOf(cx + 2, cz + i))) {
                    if (w.getId(f[0], y, f[1]) != 120 || w.getData(f[0], y, f[1]) and 4 == 0) { ok = false; break }
                }
                if (!ok) break
            }
            if (!ok) continue
            for (px in cx - 1..cx + 1) for (pz in cz - 1..cz + 1) s.setBlock(w, px, y, pz, 119, 0)
            for (o in s.players.values) if (o.spawned && o.dim == w.dim && hypot(o.x - cx, o.z - cz) < 24) o.popup("§5Портал в Край открыт")
            return true
        }
        return true
    }

    // ---------- Врата Края ----------
    // Из центра — к внешним островам (выход запоминается), с внешних островов — на центральный остров
    fun enterGateway(p: Player, x: Int, y: Int, z: Int) {
        if (p.dim != 2) return
        val w = s.worldAt(2)
        val gen = w.gen as EndGenerator
        p.popup("§5Врата Края…")
        if (hypot(x.toDouble(), z.toDouble()) < EndGenerator.OUTER_R / 2) {
            val key = "$x,$z"
            val exit = s.end.gatewayExits.getOrPut(key) {
                val land = gen.outerLanding(x, z)
                intArrayOf(land[0], max(land[1] + 2, 40), land[2], if (land[1] > 0) 1 else 0)
            }
            val ex = exit[0]; val ey = exit[1]; val ez = exit[2]; val island = exit[3] == 1
            if (!island) {
                // Острова рядом нет: небольшая площадка из камня Края
                for (dx in -3..3) for (dz in -3..3) s.setBlock(w, ex + dx, ey - 3, ez + dz, 121, 0)
            }
            s.end.placeGate(ex, ey, ez)
            val px = ex + 2.5; val pz = ez + 0.5
            var py = if (island) ey - 1.0 else ey - 2.0
            while (py < 250 && w.getId(floor(px).toInt(), floor(py).toInt(), floor(pz).toInt()) != 0) py++
            s.teleport(p, px, py, pz)
            s.end.save()
            return
        }
        toEndPlatform(p)
    }

    // ---------- Команда /dim ----------
    // Перенос в измерение: в Нижний мир — на безопасное место у координат /8, в Край — на площадку, домой — на точку возрождения
    fun sendTo(p: Player, dim: Int) {
        when (dim) {
            0 -> { val sp = s.respawnPoint(p); s.teleportTo(p, 0, sp[0], sp[1], sp[2]) }
            1 -> {
                val w = s.worldAt(1)
                val x = if (p.dim == 0) floor(p.x / 8).toInt() else if (p.dim == 1) floor(p.x).toInt() else 0
                val z = if (p.dim == 0) floor(p.z / 8).toInt() else if (p.dim == 1) floor(p.z).toInt() else 0
                val spot = findPortal(w, x, z, 16) ?: safeSpot(w, x, z)
                s.teleportTo(p, 1, spot[0] + 0.5, spot[1].toDouble(), spot[2] + 0.5)
            }
            2 -> toEndPlatform(p)
        }
        p.popup("§7" + NAMES[dim])
    }

    // Место в Нижнем мире: два блока воздуха над твёрдым блоком, иначе обсидиановая площадка на высоте 70
    private fun safeSpot(w: World, x: Int, z: Int): IntArray {
        var r = 0
        while (r <= 12) {
            for (dx in -r..r) for (dz in -r..r) {
                if (maxOf(abs(dx), abs(dz)) != r) continue
                for (dy in 0..40) for (yy in intArrayOf(64 - dy, 64 + dy)) {
                    if (yy < 33 || yy > 118) continue
                    val bx = x + dx; val bz = z + dz
                    val below = w.getId(bx, yy - 1, bz)
                    if (opaque(below) && below != 10 && below != 11 && w.getId(bx, yy, bz) == 0 && w.getId(bx, yy + 1, bz) == 0) return intArrayOf(bx, yy, bz)
                }
            }
            r += 4
        }
        quiet = true
        try {
            for (dx in -1..1) for (dz in -1..1) {
                s.setBlock(w, x + dx, 69, z + dz, 49, 0)
                for (dy in 0..2) s.setBlock(w, x + dx, 70 + dy, z + dz, 0, 0)
            }
        } finally { quiet = false }
        return intArrayOf(x, 70, z)
    }
}
