package com.mcpehtml.app.server

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

// Генератор мира с биомами (тот же, что Generator в js/world.js с версии 1.15): климат, океаны, реки,
// болота, столовые горы, пещеры-тоннели, руды жилами, тростник, кувшинки, колодцы, разные деревья
class Generator2(override val seed: Int) : WorldGen {
    override var loot: LootFn? = null
    private val n1 = Perlin(seed)
    private val n2 = Perlin(seed + 1)
    private val n3 = Perlin(seed + 2)
    private val cave = Perlin(seed + 3)
    private val biome = Perlin(seed + 4)
    private val humid = Perlin(seed + 5)
    private val cont = Perlin(seed + 6)
    private val riverN = Perlin(seed + 7)
    private val tunA = Perlin(seed + 8)
    private val tunB = Perlin(seed + 9)
    val SEA = 62

    companion object {
        const val OCEAN = 0; const val PLAINS = 1; const val DESERT = 2; const val MOUNTAINS = 3; const val FOREST = 4
        const val TAIGA = 5; const val SWAMP = 6; const val RIVER = 7; const val FROZEN_OCEAN = 10; const val SNOWY = 12
        const val JUNGLE = 21; const val DEEP_OCEAN = 24; const val BIRCH = 27; const val SNOWY_TAIGA = 30
        const val SAVANNA = 35; const val MESA = 37

        // [id, data, жил на чанк, размер, нижняя и верхняя высота]
        val ORES = arrayOf(
            intArrayOf(13, 0, 6, 20, 5, 120), intArrayOf(3, 0, 8, 20, 5, 120), intArrayOf(1, 1, 6, 22, 5, 80), intArrayOf(1, 3, 6, 22, 5, 80),
            intArrayOf(1, 5, 6, 22, 5, 80), intArrayOf(16, 0, 18, 12, 5, 128), intArrayOf(15, 0, 16, 8, 5, 64), intArrayOf(14, 0, 2, 8, 5, 32),
            intArrayOf(73, 0, 7, 7, 5, 16), intArrayOf(56, 0, 1, 7, 5, 16), intArrayOf(21, 0, 1, 6, 5, 30)
        )
        val MESA_BANDS = intArrayOf(1, 1, 0, 4, 172, 1, 14, 0, 0, 12, 172, 1, 8, 0, 4, 172)
    }

    private fun h3(s: Int, x: Int, y: Int, z: Int) = Perlin.hash3(s, x, y, z)

    fun climate(x: Int, z: Int): DoubleArray =
        doubleArrayOf(biome.fbm2(x / 520.0, z / 520.0, 2) * 2, humid.fbm2(x / 440.0 + 31.7, z / 440.0 - 12.3, 2) * 2)

    fun heightAt(x: Int, z: Int): Int {
        val base = n1.fbm2(x / 160.0, z / 160.0, 4)
        val hills = n2.fbm2(x / 60.0, z / 60.0, 3)
        val mount = max(0.0, n3.fbm2(x / 300.0, z / 300.0, 2)) * 2.2
        var h = 64 + base * 14 + hills * 6 + mount * mount * 40
        val c = cont.fbm2(x / 700.0, z / 700.0, 2)
        if (c < -0.18) h -= min(1.0, (-0.18 - c) / 0.2) * (h - 38)
        val w = climate(x, z)[1]
        if (w > 0.28 && h > SEA - 2 && h < 80) {
            val k = min(1.0, (w - 0.28) / 0.08)
            h += (SEA + 0.5 - h) * k * 0.85
        }
        val r = abs(riverN.fbm2(x / 380.0, z / 380.0, 3))
        if (r < 0.025 && h > SEA - 4 && h < 100) {
            val k = 1 - r / 0.025
            h += (SEA - 4 - h) * k * k * (3 - 2 * k)
        }
        return floor(h).toInt()
    }

    private fun isRiver(x: Int, z: Int) = abs(riverN.fbm2(x / 380.0, z / 380.0, 3)) < 0.018

    fun biomeAt(x: Int, z: Int, hh: Int = Int.MIN_VALUE): Int {
        val h = if (hh == Int.MIN_VALUE) heightAt(x, z) else hh
        val cl = climate(x, z)
        val t = cl[0]; val w = cl[1]
        if (h < SEA - 1) {
            if (isRiver(x, z) && h >= SEA - 5) return if (t < -0.3) FROZEN_OCEAN else RIVER
            return if (t < -0.3) FROZEN_OCEAN else if (h < 46) DEEP_OCEAN else OCEAN
        }
        if (h > 100 && t < 0.3) return MOUNTAINS
        if (t > 0.22) {
            if (w < -0.22 && t > 0.36) return MESA
            if (w < 0) return DESERT
            if (w > 0.2) return JUNGLE
            return SAVANNA
        }
        if (t < -0.26) return if (w > 0) SNOWY_TAIGA else SNOWY
        if (t < -0.1) return TAIGA
        if (w > 0.28) return SWAMP
        if (w > 0.06) return if (n3.noise2(x / 90.0, z / 90.0) > 0.12) BIRCH else FOREST
        return PLAINS
    }

    override fun mcpeBiome(x: Int, z: Int): Int = biomeAt(x, z)

    private fun caveAt(x: Int, y: Int, z: Int): Boolean {
        if (cave.noise3(x / 28.0, y / 18.0, z / 28.0) > 0.42) return true
        return abs(tunA.noise3(x / 42.0, y / 24.0, z / 42.0)) < 0.045 && abs(tunB.noise3(x / 42.0, y / 24.0, z / 42.0)) < 0.045
    }

    // Шум пещер по сетке 4×4×4 с интерполяцией
    private class CaveGrid(val g: DoubleArray, val ny: Int)

    private fun caveGrid(cx: Int, cz: Int, maxY: Int): CaveGrid {
        val ny = (maxY shr 2) + 2
        val g = DoubleArray(5 * 5 * ny * 2)
        for (i in 0 until 5) for (k in 0 until 5) for (j in 0 until ny) {
            val x = cx * 16 + i * 4; val y = j * 4; val z = cz * 16 + k * 4
            val o = ((i * 5 + k) * ny + j) * 2
            g[o] = cave.noise3(x / 28.0, y / 18.0, z / 28.0)
            g[o + 1] = max(abs(tunA.noise3(x / 42.0, y / 24.0, z / 42.0)), abs(tunB.noise3(x / 42.0, y / 24.0, z / 42.0)))
        }
        return CaveGrid(g, ny)
    }

    private fun caveSample(cg: CaveGrid, x: Int, y: Int, z: Int, ch: Int): Double {
        val fx = x / 4.0; val fy = y / 4.0; val fz = z / 4.0
        val i = min(3, fx.toInt()); val j = min(cg.ny - 2, fy.toInt()); val k = min(3, fz.toInt())
        val tx = fx - i; val ty = fy - j; val tz = fz - k
        val g = cg.g; val ny = cg.ny
        fun at(a: Int, b: Int, c: Int) = g[((a * 5 + c) * ny + b) * 2 + ch]
        fun l(a: Double, b: Double, t: Double) = a + (b - a) * t
        return l(l(l(at(i, j, k), at(i + 1, j, k), tx), l(at(i, j + 1, k), at(i + 1, j + 1, k), tx), ty),
            l(l(at(i, j, k + 1), at(i + 1, j, k + 1), tx), l(at(i, j + 1, k + 1), at(i + 1, j + 1, k + 1), tx), ty), tz)
    }

    override fun generate(cx: Int, cz: Int): Chunk {
        val c = Chunk(cx, cz)
        val H = seed
        val hs = IntArray(256); val bs = IntArray(256)
        var maxH = 0
        for (x in 0 until 16) for (z in 0 until 16) {
            val wx = cx * 16 + x; val wz = cz * 16 + z
            val h = min(250, heightAt(wx, wz))
            hs[x * 16 + z] = h
            bs[x * 16 + z] = biomeAt(wx, wz, h)
            if (h > maxH) maxH = h
        }
        val cg = caveGrid(cx, cz, max(maxH, SEA) + 4)
        for (x in 0 until 16) for (z in 0 until 16) {
            val wx = cx * 16 + x; val wz = cz * 16 + z
            val h = hs[x * 16 + z]; val b = bs[x * 16 + z]
            val cold = b == SNOWY || b == SNOWY_TAIGA || b == FROZEN_OCEAN
            val beach = h <= SEA + 1 && h >= SEA - 1 && b != SWAMP && b != RIVER
            val water = h < SEA
            var top = 2; var fill = 3; var deep = 3
            if (b == DESERT) { top = 12; fill = 12; deep = 24 }
            else if (b == MESA) { top = 12; fill = 172; deep = 172 }
            else if (beach) { top = if (cold) 13 else 12; fill = top; deep = if (cold) 1 else 24 }
            else if (water) {
                val r = h3(H + 41, wx shr 2, 0, wz shr 2)
                top = if (b == RIVER && r < 0.35) 82 else if (r < 0.25) 13 else 12
                fill = if (top == 82) 82 else 12; deep = 24
                if (b == DEEP_OCEAN) { top = 13; fill = 13; deep = 1 }
            } else if (b == MOUNTAINS && h > 108) { top = 1; fill = 1; deep = 1 }
            else if (b == TAIGA && n2.noise2(wx / 12.0, wz / 12.0) > 0.45) top = 243
            c.set(x, 0, z, 7, 0)
            for (y in 1..3) if (h3(H, wx, y, wz) < 0.5) c.set(x, y, z, 7, 0)
            val sandRed = if (b == MESA) 1 else 0
            for (y in 1..h) {
                if (c.getId(x, y, z) == 7) continue
                var id: Int; var d = 0
                if (y == h) { id = top; if (id == 12) d = sandRed }
                else if (y > h - 4) { id = if (y > h - 3) fill else deep; if (id == 12) d = sandRed }
                else id = 1
                if (b == MESA && y > h - 18 && y < h && y > SEA - 2) {
                    val band = MESA_BANDS[(y + floor(n2.noise2(wx / 40.0, wz / 40.0) * 3).toInt() + 64) % MESA_BANDS.size]
                    if (band == 172) { id = 172; d = 0 } else { id = 159; d = band }
                }
                if (y > 4 && y < h - (if (water) 6 else 3)) {
                    if (caveSample(cg, x, y, z, 0) > 0.42 || caveSample(cg, x, y, z, 1) < 0.045) { id = if (y < 11) 11 else 0; d = 0 }
                }
                if (id != 0) c.set(x, y, z, id, d)
            }
            for (y in h + 1..SEA) c.set(x, y, z, 9, 0)
            if (water && cold) c.set(x, SEA, z, 79, 0)
            if (h >= SEA) {
                val tid = c.getId(x, h, z)
                if (tid == 2 && (cold || (b == MOUNTAINS && h > 118))) c.set(x, h + 1, z, 78, 0)
                else if (tid == 1 && h > 125) c.set(x, h + 1, z, 78, 0)
            }
            decorate(c, x, z, wx, wz, h, b)
        }
        ores(c, cx, cz)
        caneAndLilies(c, cx, cz, hs, bs)
        for (tx in cx * 16 - 3 until cx * 16 + 19) for (tz in cz * 16 - 3 until cz * 16 + 19) {
            val r = h3(H + 21, tx, 0, tz)
            if (r >= 0.09) continue
            val lx = tx - cx * 16; val lz = tz - cz * 16
            val inside = lx in 0..15 && lz in 0..15
            val h = if (inside) hs[lx * 16 + lz] else heightAt(tx, tz)
            if (h <= SEA || h > 125) continue
            val b = if (inside) bs[lx * 16 + lz] else biomeAt(tx, tz, h)
            val t = treeFor(b, r, tx, tz)
            if (t < 0) continue
            if (caveAt(tx, h, tz)) continue
            placeTree(c, tx, h + 1, tz, t, h3(H + 23, tx, 0, tz))
        }
        wells(c, cx, cz, hs, bs)
        // Подземные крепости с порталом в Край
        Strongholds.carve(seed, c, cx, cz)
        c.recalcHeight()
        return c
    }

    private fun treeFor(b: Int, r: Double, x: Int, z: Int): Int {
        val kind = h3(seed + 22, x, 0, z)
        return when (b) {
            FOREST -> if (r < 0.045) (if (kind < 0.25) 2 else 0) else -1
            BIRCH -> if (r < 0.045) (if (kind < 0.85) 2 else 0) else -1
            PLAINS -> if (r < 0.003) 0 else -1
            TAIGA, SNOWY_TAIGA -> if (r < 0.035) 1 else -1
            SNOWY -> if (r < 0.004) 1 else -1
            JUNGLE -> if (r < 0.09) (if (kind < 0.55) 3 else 0) else -1
            SAVANNA -> if (r < 0.005) 4 else -1
            SWAMP -> if (r < 0.012) 5 else -1
            MOUNTAINS -> if (r < 0.006) 1 else -1
            else -> -1
        }
    }

    private fun decorate(c: Chunk, x: Int, z: Int, wx: Int, wz: Int, h: Int, b: Int) {
        if (h < SEA || h > 250 || c.getId(x, h + 1, z) != 0) return
        val H = seed
        val top = c.getId(x, h, z)
        val r = h3(H + 11, wx, 0, wz); val r2 = h3(H + 12, wx, 1, wz)
        if (top == 12 || top == 172 || top == 159) {
            if ((b == DESERT || b == MESA) && r < 0.004 && top == 12) {
                val tall = 1 + floor(h3(H + 14, wx, 0, wz) * 3).toInt()
                for (y in 1..tall) c.set(x, h + y, z, 81, 0)
            } else if ((b == DESERT || b == MESA) && r > 0.993) c.set(x, h + 1, z, 32, 0)
            return
        }
        if (top != 2 && top != 243) return
        var grass = 0.1; var flowers = 0.024
        when (b) {
            PLAINS -> { grass = 0.28; flowers = 0.04 }
            JUNGLE -> { grass = 0.3; flowers = 0.006 }
            SAVANNA -> { grass = 0.35; flowers = 0.004 }
            TAIGA, SNOWY_TAIGA, SNOWY -> { grass = 0.14; flowers = 0.004 }
            SWAMP -> { grass = 0.12; flowers = 0.004 }
        }
        val ferny = b == TAIGA || b == SNOWY_TAIGA || b == JUNGLE
        if (r < grass) c.set(x, h + 1, z, 31, if (ferny && r2 < 0.4) 2 else 1)
        else if (r < grass + flowers) {
            if (r2 < 0.45) c.set(x, h + 1, z, 37, 0)
            else c.set(x, h + 1, z, 38, if (b == SWAMP) 1 else floor(r2 * 9).toInt())
        } else if (r < grass + flowers + 0.003 && (b == SWAMP || b == TAIGA || b == SNOWY_TAIGA)) c.set(x, h + 1, z, if (r2 < 0.5) 39 else 40, 0)
        else if (r > 0.9993 && (b == PLAINS || b == FOREST || b == TAIGA)) c.set(x, h + 1, z, 86, floor(r2 * 4).toInt())
        else if (r > 0.997 && b == JUNGLE) c.set(x, h + 1, z, 103, 0)
    }

    private fun ores(c: Chunk, cx: Int, cz: Int) {
        val H = seed + 300
        for (ax in cx - 1..cx + 1) for (az in cz - 1..cz + 1) {
            for (oi in ORES.indices) {
                val o = ORES[oi]
                val id = o[0]; val data = o[1]; val count = o[2]; val size = o[3]; val y0 = o[4]; val y1 = o[5]
                for (i in 0 until count) {
                    val k = oi * 64 + i
                    var x = ax * 16 + h3(H + k, ax, 1, az) * 16
                    var z = az * 16 + h3(H + k, ax, 2, az) * 16
                    var y = y0 + h3(H + k, ax, 3, az) * (y1 - y0)
                    if (abs(x - (cx * 16 + 8)) > 8 + size / 2.0 + 2 || abs(z - (cz * 16 + 8)) > 8 + size / 2.0 + 2) continue
                    for (n in 0 until size) {
                        val lx = floor(x).toInt() - cx * 16; val lz = floor(z).toInt() - cz * 16; val yy = floor(y).toInt()
                        if (lx in 0..15 && lz in 0..15 && yy in 1..255 && c.getId(lx, yy, lz) == 1 && c.getData(lx, yy, lz) == 0) c.set(lx, yy, lz, id, data)
                        val a = h3(H + k, ax * 31 + n, 4, az); val bb = h3(H + k, ax, 5 + n, az * 17)
                        x += floor(a * 3) - 1; z += floor(bb * 3) - 1
                        y += floor(h3(H + k + n, ax, 6, az) * 3) - 1
                    }
                }
            }
        }
        for (i in 0 until 4) {
            val lx = floor(h3(H + 900 + i, cx, 0, cz) * 16).toInt(); val lz = floor(h3(H + 901 + i, cx, 0, cz) * 16).toInt()
            val y = 5 + floor(h3(H + 902 + i, cx, 0, cz) * 27).toInt()
            if (biomeAt(cx * 16 + lx, cz * 16 + lz) == MOUNTAINS && c.getId(lx, y, lz) == 1) c.set(lx, y, lz, 129, 0)
        }
    }

    private fun caneAndLilies(c: Chunk, cx: Int, cz: Int, hs: IntArray, bs: IntArray) {
        val H = seed
        for (x in 0 until 16) for (z in 0 until 16) {
            val h = hs[x * 16 + z]; val b = bs[x * 16 + z]; val wx = cx * 16 + x; val wz = cz * 16 + z
            val r = h3(H + 51, wx, 0, wz)
            if (h < SEA && b == SWAMP && h >= SEA - 2 && r < 0.08 && c.getId(x, SEA, z) == 9) c.set(x, SEA + 1, z, 111, 0)
            if (h != SEA && h != SEA + 1) continue
            val top = c.getId(x, h, z)
            if ((top != 2 && top != 12 && top != 3) || c.getId(x, h + 1, z) != 0 || r > 0.12) continue
            var wet = false
            for (dd in arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))) {
                val nx = x + dd[0]; val nz = z + dd[1]
                if (nx < 0 || nx > 15 || nz < 0 || nz > 15) continue
                val id = c.getId(nx, h, nz)
                if (id == 8 || id == 9) wet = true
            }
            if (!wet) continue
            val tall = 1 + floor(h3(H + 52, wx, 0, wz) * 3).toInt()
            for (y in 1..tall) c.set(x, h + y, z, 83, 0)
        }
    }

    private fun wells(c: Chunk, cx: Int, cz: Int, hs: IntArray, bs: IntArray) {
        if (h3(seed + 61, cx, 0, cz) > 0.006) return
        val x = 5; val z = 5; val h = hs[x * 16 + z]
        if (bs[x * 16 + z] != DESERT || h <= SEA) return
        for (dx in -2..2) for (dz in -2..2) {
            c.set(x + dx, h, z + dz, 24, 0)
            for (y in 1..4) c.set(x + dx, h + y, z + dz, 0, 0)
            val edge = abs(dx) == 2 || abs(dz) == 2
            if (!edge && abs(dx) + abs(dz) <= 1) c.set(x + dx, h, z + dz, 9, 0)
            if (abs(dx) == 1 && abs(dz) == 1) c.set(x + dx, h + 1, z + dz, 24, 0)
            if (edge && dx != 0 && dz != 0) continue
            if (!edge) continue
            c.set(x + dx, h + 1, z + dz, 44, 1)
        }
        c.set(x, h - 1, z, 9, 0)
        for (dd in arrayOf(intArrayOf(-1, -1), intArrayOf(1, -1), intArrayOf(-1, 1), intArrayOf(1, 1))) for (y in 1..2) c.set(x + dd[0], h + y, z + dd[1], 24, 0)
        for (dx in -1..1) for (dz in -1..1) c.set(x + dx, h + 3, z + dz, 44, 1)
    }

    private fun placeTree(c: Chunk, tx: Int, ty: Int, tz: Int, kind: Int, r: Double) {
        fun put(x: Int, y: Int, z: Int, id: Int, d: Int, onlyAir: Boolean = false) {
            val lx = x - c.cx * 16; val lz = z - c.cz * 16
            if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 0 || y > 255) return
            if (onlyAir) { val cur = c.getId(lx, y, lz); if (cur != 0 && cur != 31 && cur != 78 && cur != 106) return }
            c.set(lx, y, lz, id, d)
        }
        fun at(x: Int, y: Int, z: Int): Int {
            val lx = x - c.cx * 16; val lz = z - c.cz * 16
            return if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 0 || y > 255) -1 else c.getId(lx, y, lz)
        }
        val sides = arrayOf(intArrayOf(1, 0, 2), intArrayOf(-1, 0, 8), intArrayOf(0, 1, 4), intArrayOf(0, -1, 1))
        fun vines(x: Int, y: Int, z: Int, len: Int) {
            for (s in sides) {
                if (h3(seed + 37, x + s[0] * 3, y, z + s[1] * 5) > 0.3) continue
                var k = 0
                while (k < len && at(x + s[0], y - k, z + s[1]) == 0) { put(x + s[0], y - k, z + s[1], 106, s[2], true); k++ }
            }
        }
        val trunk = 4 + floor(r * 3).toInt()
        if (kind == 1) {
            for (y in 0 until trunk + 2) put(tx, ty + y, tz, 17, 1)
            var rad = 0
            for (y in trunk + 2 downTo 2) {
                for (dx in -rad..rad) for (dz in -rad..rad) {
                    if (abs(dx) + abs(dz) > rad + 1 || (dx == 0 && dz == 0 && y < trunk + 2)) continue
                    put(tx + dx, ty + y, tz + dz, 18, 1, true)
                }
                rad = if (rad >= 2) 1 else rad + 1
            }
            put(tx, ty + trunk + 2, tz, 18, 1, true)
            put(tx, ty + trunk + 3, tz, 18, 1, true)
            return
        }
        if (kind == 3) {
            val t = 6 + floor(r * 7).toInt()
            for (y in 0 until t) put(tx, ty + y, tz, 17, 3)
            for (y in t - 3..t + 1) {
                val rad = if (y >= t) 2 - (y - t) else 3
                for (dx in -rad..rad) for (dz in -rad..rad) {
                    if (dx * dx + dz * dz > rad * rad + 1) continue
                    put(tx + dx, ty + y, tz + dz, 18, 3, true)
                }
            }
            for (s in sides) if (h3(seed + 38, tx + s[0], ty, tz + s[1]) < 0.5) for (y in 1 until t - 3) put(tx + s[0], ty + y, tz + s[1], 106, s[2], true)
            if (h3(seed + 39, tx, ty, tz) < 0.3) put(tx + 1, ty + t - 4, tz, 127, 3, true)
            return
        }
        if (kind == 4) {
            val t = 4 + floor(r * 2).toInt()
            val dirs = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))
            val dir = dirs[floor(h3(seed + 40, tx, 0, tz) * 4).toInt()]
            var x = tx; var z = tz
            for (y in 0 until t) {
                if (y >= t - 2) { x += dir[0]; z += dir[1] }
                put(x, ty + y, z, 162, 0)
            }
            val top = ty + t
            for (dx in -2..2) for (dz in -2..2) {
                if (abs(dx) == 2 && abs(dz) == 2) continue
                put(x + dx, top - 1, z + dz, 161, 0, true)
                if (abs(dx) <= 1 && abs(dz) <= 1) put(x + dx, top, z + dz, 161, 0, true)
            }
            return
        }
        val leaf = if (kind == 2) 2 else 0
        for (y in 0 until trunk) put(tx, ty + y, tz, 17, leaf)
        for (y in trunk - 3..trunk) {
            val rad = if (y >= trunk - 1) 1 else 2
            for (dx in -rad..rad) for (dz in -rad..rad) {
                if (rad == 2 && abs(dx) == 2 && abs(dz) == 2 && h3(seed + 31, tx + dx, ty + y, tz + dz) < 0.5) continue
                if (rad == 1 && y == trunk && abs(dx) == 1 && abs(dz) == 1) continue
                put(tx + dx, ty + y, tz + dz, 18, leaf, true)
            }
        }
        if (kind == 5) {
            for (dx in -3..3) for (dz in -3..3) if (abs(dx) == 3 || abs(dz) == 3) {
                if (abs(dx) + abs(dz) > 4) continue
                put(tx + dx, ty + trunk - 2, tz + dz, 18, 0, true)
            }
            for (dx in -3..3) for (dz in -3..3) if (at(tx + dx, ty + trunk - 2, tz + dz) == 18) vines(tx + dx, ty + trunk - 3, tz + dz, 4)
        }
    }

    override fun findSpawn(): DoubleArray {
        for (i in 0 until 600) {
            val x = floor(Math.cos(i.toDouble()) * i * 2).toInt()
            val z = floor(Math.sin(i.toDouble()) * i * 2).toInt()
            val h = heightAt(x, z)
            val b = biomeAt(x, z, h)
            if (h > SEA + 1 && b != DESERT && b != MESA && b != SWAMP && b != MOUNTAINS && !caveAt(x, h, z)) return doubleArrayOf(x + 0.5, h + 1.0, z + 0.5)
        }
        return doubleArrayOf(0.5, heightAt(0, 0) + 2.0, 0.5)
    }
}
