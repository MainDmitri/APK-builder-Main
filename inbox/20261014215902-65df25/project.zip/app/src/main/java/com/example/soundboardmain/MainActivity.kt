package com.example.soundboardmain

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.soundboardmain.overlay.OverlayService
import com.example.soundboardmain.ui.MainViewModel
import com.example.soundboardmain.ui.Screen
import com.example.soundboardmain.ui.SettingsScreen
import com.example.soundboardmain.ui.SoundboardScreen
import com.example.soundboardmain.ui.theme.AppTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()
    private var notificationAsked = false

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        viewModel.importUris(uris)
    }

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            viewModel.startRecording()
        } else {
            viewModel.showMessage(
                "Нет доступа к микрофону — запись невозможна. Разрешите микрофон в настройках приложения."
            )
        }
    }

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) {
            viewModel.showMessage("Уведомления запрещены: панель работает, но её значок в шторке не будет показан.")
        }
        launchOverlayService()
    }

    private val overlaySettings = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        viewModel.refreshOverlayPermission()
        if (Settings.canDrawOverlays(this)) {
            startOverlay()
        } else {
            viewModel.showMessage("Разрешение «Поверх других приложений» не выдано — панель не может быть показана.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))

        val backCallback = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                viewModel.back()
            }
        }
        onBackPressedDispatcher.addCallback(this, backCallback)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.screen.collect { backCallback.isEnabled = it != Screen.MAIN }
            }
        }

        setContent {
            AppTheme {
                val screen by viewModel.screen.collectAsStateWithLifecycle()
                when (screen) {
                    Screen.MAIN -> SoundboardScreen(
                        onPickFiles = ::pickFiles,
                        onRecord = ::requestRecording,
                        onStartOverlay = ::startOverlay,
                        onStopOverlay = ::stopOverlay,
                        onOpenOverlaySettings = ::openOverlaySettings,
                    )
                    Screen.SETTINGS -> SettingsScreen()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshOverlayPermission()
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) viewModel.interruptRecording()
    }

    private fun pickFiles() {
        try {
            pickAudio.launch(arrayOf("audio/*"))
        } catch (e: ActivityNotFoundException) {
            viewModel.showMessage("На устройстве нет приложения для выбора файлов")
        }
    }

    private fun requestRecording() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            viewModel.startRecording()
        } else {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !notificationAsked &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationAsked = true
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        launchOverlayService()
    }

    private fun launchOverlayService() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        } catch (e: Exception) {
            viewModel.showMessage("Не удалось запустить панель: ${e.message}")
        }
    }

    private fun stopOverlay() {
        stopService(Intent(this, OverlayService::class.java))
    }

    private fun openOverlaySettings() {
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        try {
            overlaySettings.launch(intent)
        } catch (e: ActivityNotFoundException) {
            try {
                overlaySettings.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            } catch (e2: ActivityNotFoundException) {
                viewModel.showMessage("На устройстве нет экрана настройки показа поверх других приложений")
            }
        }
    }
}
