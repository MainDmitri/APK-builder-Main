package com.example.soundboardmain.data

import android.content.Context
import android.content.SharedPreferences
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.core.content.edit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.MalformedURLException
import java.net.URI
import java.net.URISyntaxException
import java.net.URLDecoder
import java.net.UnknownHostException
import java.util.UUID

object SoundRepository {
    private const val KEY_SOUNDS = "sounds"
    private const val MAX_FILE_BYTES = 50L * 1024 * 1024
    private const val DEFAULT_NAME = "Звук"

    private lateinit var appContext: Context
    private lateinit var prefs: SharedPreferences
    private val lock = Any()

    private val _sounds = MutableStateFlow<List<Sound>>(emptyList())
    val sounds: StateFlow<List<Sound>> = _sounds.asStateFlow()

    fun init(context: Context) {
        synchronized(lock) {
            if (::prefs.isInitialized) return
            appContext = context.applicationContext
            prefs = appContext.getSharedPreferences("app", Context.MODE_PRIVATE)
            val loaded = load()
            val existing = loaded.filter { fileFor(it).exists() }
            _sounds.value = existing
            if (existing.size != loaded.size) persist(existing)
        }
    }

    fun fileFor(sound: Sound): File = File(soundsDir(), sound.fileName)

    fun createSoundFile(extension: String): File =
        File(soundsDir(), "${UUID.randomUUID()}.${sanitizeExtension(extension) ?: "audio"}")

    fun addFile(file: File, name: String) {
        val sound = Sound(
            id = file.nameWithoutExtension,
            name = name.trim().ifBlank { DEFAULT_NAME },
            fileName = file.name,
            favorite = false,
            createdAt = System.currentTimeMillis(),
        )
        mutate { it + sound }
    }

    suspend fun importFromUri(uri: Uri): Sound = withContext(Dispatchers.IO) {
        val resolver = appContext.contentResolver
        val displayName = queryDisplayName(uri) ?: DEFAULT_NAME
        val extension = extensionOf(displayName)
            ?: MimeTypeMap.getSingleton().getExtensionFromMimeType(resolver.getType(uri))
        val file = createSoundFile(extension ?: "audio")
        try {
            val input = resolver.openInputStream(uri) ?: throw IOException("не удалось открыть файл")
            input.use { source -> copyLimited(source, file) }
            validateAudio(file)
        } catch (e: Exception) {
            file.delete()
            throw IOException("«$displayName»: ${e.message ?: "ошибка чтения"}", e)
        }
        val sound = Sound(
            id = file.nameWithoutExtension,
            name = displayName.substringBeforeLast('.').trim().ifBlank { DEFAULT_NAME },
            fileName = file.name,
            favorite = false,
            createdAt = System.currentTimeMillis(),
        )
        mutate { it + sound }
        sound
    }

    suspend fun downloadFromUrl(urlText: String, customName: String): Sound = withContext(Dispatchers.IO) {
        val url = try {
            URI(urlText.trim()).toURL()
        } catch (e: URISyntaxException) {
            throw IOException("Некорректная ссылка", e)
        } catch (e: IllegalArgumentException) {
            throw IOException("Некорректная ссылка", e)
        } catch (e: MalformedURLException) {
            throw IOException("Некорректная ссылка", e)
        }
        if (url.protocol != "https") throw IOException("Поддерживаются только ссылки https://")
        val connection = url.openConnection() as HttpURLConnection
        var file: File? = null
        try {
            connection.connectTimeout = 15_000
            connection.readTimeout = 30_000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("User-Agent", "SoundboardMAIN/1.0 (Android)")
            val code = connection.responseCode
            if (code !in 200..299) throw IOException("Сервер ответил кодом $code")
            val length = connection.contentLengthLong
            if (length > MAX_FILE_BYTES) throw IOException("Файл больше 50 МБ")
            val finalUrl = connection.url
            val pathName = try {
                URLDecoder.decode(finalUrl.path.substringAfterLast('/'), "UTF-8")
            } catch (e: IllegalArgumentException) {
                finalUrl.path.substringAfterLast('/')
            }
            val mime = connection.contentType?.substringBefore(';')?.trim()
            val extension = extensionOf(pathName)
                ?: mime?.let { MimeTypeMap.getSingleton().getExtensionFromMimeType(it) }
            val target = createSoundFile(extension ?: "audio")
            file = target
            connection.inputStream.use { source -> copyLimited(source, target) }
            validateAudio(target)
            val name = customName.trim().ifBlank {
                pathName.substringBeforeLast('.').trim().ifBlank { DEFAULT_NAME }
            }
            val sound = Sound(
                id = target.nameWithoutExtension,
                name = name,
                fileName = target.name,
                favorite = false,
                createdAt = System.currentTimeMillis(),
            )
            mutate { it + sound }
            sound
        } catch (e: UnknownHostException) {
            file?.delete()
            throw IOException("Нет подключения к интернету или сервер не найден", e)
        } catch (e: SocketTimeoutException) {
            file?.delete()
            throw IOException("Превышено время ожидания ответа сервера", e)
        } catch (e: IOException) {
            file?.delete()
            throw e
        } catch (e: RuntimeException) {
            file?.delete()
            throw IOException(e.message ?: "Ошибка загрузки", e)
        } finally {
            connection.disconnect()
        }
    }

    fun rename(id: String, name: String) {
        val newName = name.trim()
        if (newName.isEmpty()) return
        mutate { list -> list.map { if (it.id == id) it.copy(name = newName) else it } }
    }

    fun toggleFavorite(id: String) {
        mutate { list -> list.map { if (it.id == id) it.copy(favorite = !it.favorite) else it } }
    }

    fun delete(id: String) {
        val sound = _sounds.value.firstOrNull { it.id == id } ?: return
        fileFor(sound).delete()
        mutate { list -> list.filterNot { it.id == id } }
    }

    private fun soundsDir(): File = File(appContext.filesDir, "sounds").apply { mkdirs() }

    private fun mutate(transform: (List<Sound>) -> List<Sound>) {
        synchronized(lock) {
            val updated = transform(_sounds.value)
            _sounds.value = updated
            persist(updated)
        }
    }

    private fun persist(list: List<Sound>) {
        val array = JSONArray()
        list.forEach { array.put(it.toJson()) }
        prefs.edit { putString(KEY_SOUNDS, array.toString()) }
    }

    private fun load(): List<Sound> {
        val raw = prefs.getString(KEY_SOUNDS, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { index ->
                try {
                    Sound.fromJson(array.getJSONObject(index))
                } catch (e: JSONException) {
                    null
                }
            }
        } catch (e: JSONException) {
            emptyList()
        }
    }

    private fun queryDisplayName(uri: Uri): String? =
        appContext.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) cursor.getString(index) else null
                } else {
                    null
                }
            }

    private fun extensionOf(name: String): String? {
        if (!name.contains('.')) return null
        return sanitizeExtension(name.substringAfterLast('.'))
    }

    private fun sanitizeExtension(extension: String?): String? {
        val clean = extension?.lowercase()?.filter { it in 'a'..'z' || it in '0'..'9' } ?: return null
        return if (clean.isEmpty() || clean.length > 5) null else clean
    }

    private fun copyLimited(source: InputStream, target: File) {
        target.outputStream().use { output ->
            val buffer = ByteArray(64 * 1024)
            var total = 0L
            while (true) {
                val read = source.read(buffer)
                if (read < 0) break
                total += read
                if (total > MAX_FILE_BYTES) throw IOException("Файл больше 50 МБ")
                output.write(buffer, 0, read)
            }
        }
    }

    private fun validateAudio(file: File) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(file.absolutePath)
            val hasAudio = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
            if (hasAudio != "yes") throw IOException("файл не содержит аудио")
        } catch (e: IOException) {
            throw e
        } catch (e: RuntimeException) {
            throw IOException("неподдерживаемый формат аудио")
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
                // release() на API 29+ объявляет IOException; проверка файла уже выполнена
            }
        }
    }
}
