package com.example.soundboardmain.ui

import android.app.Application
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.soundboardmain.audio.MicRecorder
import com.example.soundboardmain.audio.SoundPlayer
import com.example.soundboardmain.data.AppSettings
import com.example.soundboardmain.data.SettingsRepository
import com.example.soundboardmain.data.Sound
import com.example.soundboardmain.data.SoundRepository
import com.example.soundboardmain.data.sortedForDisplay
import com.example.soundboardmain.overlay.OverlayService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.IOException

enum class Screen { MAIN, SETTINGS }

data class RecordingState(
    val active: Boolean = false,
    val startedAt: Long = 0L,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    init {
        SoundRepository.init(application)
        SettingsRepository.init(application)
    }

    val sounds: StateFlow<List<Sound>> = SoundRepository.sounds
        .map { it.sortedForDisplay() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, SoundRepository.sounds.value.sortedForDisplay())

    val settings: StateFlow<AppSettings> = SettingsRepository.settings
    val playing: StateFlow<Set<String>> = SoundPlayer.playing
    val overlayRunning: StateFlow<Boolean> = OverlayService.running

    private val _screen = MutableStateFlow(Screen.MAIN)
    val screen: StateFlow<Screen> = _screen.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _recording = MutableStateFlow(RecordingState())
    val recording: StateFlow<RecordingState> = _recording.asStateFlow()

    private val _overlayGranted = MutableStateFlow(Settings.canDrawOverlays(application))
    val overlayGranted: StateFlow<Boolean> = _overlayGranted.asStateFlow()

    private val recorder = MicRecorder(application)

    fun refreshOverlayPermission() {
        _overlayGranted.value = Settings.canDrawOverlays(getApplication<Application>())
    }

    fun showMessage(text: String) {
        _message.value = text
    }

    fun messageShown() {
        _message.value = null
    }

    fun openSettings() {
        _screen.value = Screen.SETTINGS
    }

    fun back(): Boolean {
        if (_screen.value == Screen.MAIN) return false
        _screen.value = Screen.MAIN
        return true
    }

    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _busy.value = true
            var added = 0
            val errors = mutableListOf<String>()
            for (uri in uris) {
                try {
                    SoundRepository.importFromUri(uri)
                    added++
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    errors += e.message ?: "ошибка чтения файла"
                }
            }
            _busy.value = false
            _message.value = buildString {
                if (added > 0) append("Добавлено звуков: $added")
                if (errors.isNotEmpty()) {
                    if (isNotEmpty()) append(". ")
                    append("Не добавлено: ")
                    append(errors.joinToString("; "))
                }
            }
        }
    }

    fun download(url: String, name: String) {
        viewModelScope.launch {
            _busy.value = true
            try {
                val sound = SoundRepository.downloadFromUrl(url, name)
                _message.value = "Звук «${sound.name}» загружен"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _message.value = "Ошибка загрузки: ${e.message ?: "неизвестная ошибка"}"
            } finally {
                _busy.value = false
            }
        }
    }

    fun startRecording() {
        if (recorder.isRecording) return
        try {
            val file = SoundRepository.createSoundFile("m4a")
            recorder.start(file)
            _recording.value = RecordingState(active = true, startedAt = SystemClock.elapsedRealtime())
        } catch (e: IOException) {
            _message.value = e.message ?: "Не удалось начать запись"
        }
    }

    fun recordingAmplitude(): Int = recorder.amplitude()

    fun saveRecording(name: String) {
        val file = recorder.stop()
        _recording.value = RecordingState()
        if (file == null) {
            _message.value = "Запись слишком короткая и не сохранена"
        } else {
            SoundRepository.addFile(file, name)
            _message.value = "Запись сохранена"
        }
    }

    fun cancelRecording() {
        recorder.cancel()
        _recording.value = RecordingState()
    }

    fun interruptRecording() {
        if (!recorder.isRecording) return
        cancelRecording()
        _message.value = "Запись прервана: приложение было свёрнуто"
    }

    fun play(sound: Sound) {
        SoundPlayer.toggle(sound) { error -> _message.value = error }
    }

    fun stopAll() {
        SoundPlayer.stopAll()
    }

    fun rename(sound: Sound, name: String) {
        SoundRepository.rename(sound.id, name)
    }

    fun toggleFavorite(sound: Sound) {
        SoundRepository.toggleFavorite(sound.id)
    }

    fun delete(sound: Sound) {
        SoundPlayer.stop(sound.id)
        SoundRepository.delete(sound.id)
        _message.value = "Звук «${sound.name}» удалён"
    }

    fun setVolume(value: Float) {
        SettingsRepository.setVolume(value)
        SoundPlayer.applyVolume(SettingsRepository.settings.value.volume)
    }

    fun setStopPrevious(value: Boolean) {
        SettingsRepository.setStopPrevious(value)
    }

    fun setOverlayAlpha(value: Float) {
        SettingsRepository.setOverlayAlpha(value)
    }

    fun setOverlayColumns(value: Int) {
        SettingsRepository.setOverlayColumns(value)
    }

    override fun onCleared() {
        recorder.cancel()
        super.onCleared()
    }
}
