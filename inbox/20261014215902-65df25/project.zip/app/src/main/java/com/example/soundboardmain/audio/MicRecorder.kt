package com.example.soundboardmain.audio

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File
import java.io.IOException

class MicRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var output: File? = null

    val isRecording: Boolean
        get() = recorder != null

    fun start(file: File) {
        if (recorder != null) return
        val newRecorder = createRecorder()
        try {
            newRecorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            newRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            newRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            newRecorder.setAudioEncodingBitRate(128_000)
            newRecorder.setAudioSamplingRate(44_100)
            newRecorder.setOutputFile(file.absolutePath)
            newRecorder.prepare()
            newRecorder.start()
        } catch (e: Exception) {
            newRecorder.release()
            file.delete()
            throw IOException("Не удалось начать запись: микрофон занят или недоступен", e)
        }
        recorder = newRecorder
        output = file
    }

    fun amplitude(): Int = try {
        recorder?.maxAmplitude ?: 0
    } catch (e: IllegalStateException) {
        0
    }

    /** Останавливает запись. Возвращает файл или null, если запись слишком короткая/повреждена. */
    fun stop(): File? {
        val current = recorder ?: return null
        val file = output
        recorder = null
        output = null
        return try {
            current.stop()
            file
        } catch (e: RuntimeException) {
            file?.delete()
            null
        } finally {
            current.release()
        }
    }

    fun cancel() {
        val current = recorder ?: return
        val file = output
        recorder = null
        output = null
        try {
            current.stop()
        } catch (e: RuntimeException) {
            // Запись не успела начаться — файл всё равно удаляется ниже
        }
        current.release()
        file?.delete()
    }

    private fun createRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(context) else legacyRecorder()

    @Suppress("DEPRECATION")
    private fun legacyRecorder(): MediaRecorder = MediaRecorder()
}
