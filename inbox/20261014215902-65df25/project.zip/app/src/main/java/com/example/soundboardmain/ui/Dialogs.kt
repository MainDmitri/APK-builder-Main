package com.example.soundboardmain.ui

import android.os.SystemClock
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.soundboardmain.data.Sound
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun RenameDialog(sound: Sound, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember(sound.id) { mutableStateOf(sound.name) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Переименовать") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Название") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(name) }, enabled = name.isNotBlank()) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@Composable
fun DeleteDialog(sound: Sound, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Удалить звук?") },
        text = { Text("«${sound.name}» будет удалён из приложения вместе с файлом.") },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Удалить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@Composable
fun UrlDialog(onConfirm: (url: String, name: String) -> Unit, onDismiss: () -> Unit) {
    var url by remember { mutableStateOf("https://") }
    var name by remember { mutableStateOf("") }
    val valid = url.trim().startsWith("https://") && url.trim().length > "https://".length
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Скачать по ссылке") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Прямая ссылка на аудиофайл (mp3, ogg, wav, m4a и др.), до 50 МБ.",
                    style = MaterialTheme.typography.bodySmall,
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("Ссылка https://") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Название (необязательно)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(url.trim(), name.trim()) }, enabled = valid) { Text("Скачать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@Composable
fun OverlayPermissionDialog(onOpenSettings: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Нужно разрешение") },
        text = {
            Text(
                "Чтобы плавающая панель работала поверх игр и других приложений, " +
                    "разрешите Soundboard MAIN «Показ поверх других приложений». " +
                    "Найдите приложение в открывшемся списке и включите переключатель."
            )
        },
        confirmButton = { TextButton(onClick = onOpenSettings) { Text("Открыть настройки") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@Composable
fun RecordDialog(
    startedAt: Long,
    defaultName: String,
    amplitude: () -> Int,
    onSave: (String) -> Unit,
    onCancel: () -> Unit,
) {
    var name by remember { mutableStateOf(defaultName) }
    var elapsed by remember { mutableLongStateOf(0L) }
    var level by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(startedAt) {
        while (true) {
            elapsed = SystemClock.elapsedRealtime() - startedAt
            level = (amplitude() / 32767f).coerceIn(0f, 1f)
            delay(100)
        }
    }

    val seconds = elapsed / 1000
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Запись с микрофона") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    String.format(Locale.US, "● %02d:%02d", seconds / 60, seconds % 60),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.error,
                )
                LinearProgressIndicator(progress = { level }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Название") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(name) }) { Text("Стоп и сохранить") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Отмена") } },
    )
}
