package com.example.soundboardmain.data

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val volume: Float = 1f,
    val stopPrevious: Boolean = true,
    val overlayAlpha: Float = 0.95f,
    val overlayColumns: Int = 3,
)

object SettingsRepository {
    private const val KEY_VOLUME = "volume"
    private const val KEY_STOP_PREVIOUS = "stop_previous"
    private const val KEY_OVERLAY_ALPHA = "overlay_alpha"
    private const val KEY_OVERLAY_COLUMNS = "overlay_columns"
    private const val KEY_OVERLAY_X = "overlay_x"
    private const val KEY_OVERLAY_Y = "overlay_y"

    private lateinit var prefs: SharedPreferences
    private val lock = Any()

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    fun init(context: Context) {
        synchronized(lock) {
            if (::prefs.isInitialized) return
            prefs = context.applicationContext.getSharedPreferences("app", Context.MODE_PRIVATE)
            _settings.value = AppSettings(
                volume = prefs.getFloat(KEY_VOLUME, 1f).coerceIn(0f, 1f),
                stopPrevious = prefs.getBoolean(KEY_STOP_PREVIOUS, true),
                overlayAlpha = prefs.getFloat(KEY_OVERLAY_ALPHA, 0.95f).coerceIn(0.3f, 1f),
                overlayColumns = prefs.getInt(KEY_OVERLAY_COLUMNS, 3).coerceIn(2, 4),
            )
        }
    }

    fun setVolume(value: Float) {
        val v = value.coerceIn(0f, 1f)
        _settings.value = _settings.value.copy(volume = v)
        prefs.edit { putFloat(KEY_VOLUME, v) }
    }

    fun setStopPrevious(value: Boolean) {
        _settings.value = _settings.value.copy(stopPrevious = value)
        prefs.edit { putBoolean(KEY_STOP_PREVIOUS, value) }
    }

    fun setOverlayAlpha(value: Float) {
        val v = value.coerceIn(0.3f, 1f)
        _settings.value = _settings.value.copy(overlayAlpha = v)
        prefs.edit { putFloat(KEY_OVERLAY_ALPHA, v) }
    }

    fun setOverlayColumns(value: Int) {
        val v = value.coerceIn(2, 4)
        _settings.value = _settings.value.copy(overlayColumns = v)
        prefs.edit { putInt(KEY_OVERLAY_COLUMNS, v) }
    }

    fun overlayX(default: Int): Int = prefs.getInt(KEY_OVERLAY_X, default)

    fun overlayY(default: Int): Int = prefs.getInt(KEY_OVERLAY_Y, default)

    fun saveOverlayPosition(x: Int, y: Int) {
        prefs.edit {
            putInt(KEY_OVERLAY_X, x)
            putInt(KEY_OVERLAY_Y, y)
        }
    }
}
