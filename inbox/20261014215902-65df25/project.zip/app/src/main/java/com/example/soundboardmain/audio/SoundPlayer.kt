package com.example.soundboardmain.audio

import android.media.AudioAttributes
import android.media.MediaPlayer
import com.example.soundboardmain.data.SettingsRepository
import com.example.soundboardmain.data.Sound
import com.example.soundboardmain.data.SoundRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Проигрывает звуки через MediaPlayer. Все методы вызываются из главного потока
 * (UI приложения и окно оверлея), колбэки MediaPlayer тоже приходят в главный поток.
 */
object SoundPlayer {
    private val active = mutableMapOf<MediaPlayer, String>()
    private val prepared = mutableSetOf<MediaPlayer>()

    private val _playing = MutableStateFlow<Set<String>>(emptySet())
    val playing: StateFlow<Set<String>> = _playing.asStateFlow()

    fun toggle(sound: Sound, onError: (String) -> Unit) {
        if (sound.id in _playing.value) stop(sound.id) else play(sound, onError)
    }

    fun play(sound: Sound, onError: (String) -> Unit) {
        val settings = SettingsRepository.settings.value
        if (settings.stopPrevious) stopAll()
        val file = SoundRepository.fileFor(sound)
        if (!file.exists()) {
            onError("Файл звука «${sound.name}» не найден")
            return
        }
        val player = MediaPlayer()
        try {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            player.setDataSource(file.absolutePath)
            player.setVolume(settings.volume, settings.volume)
            player.setOnPreparedListener { mp ->
                prepared.add(mp)
                val volume = SettingsRepository.settings.value.volume
                mp.setVolume(volume, volume)
                mp.start()
            }
            player.setOnCompletionListener { mp -> release(mp) }
            player.setOnErrorListener { mp, _, _ ->
                release(mp)
                onError("Не удалось воспроизвести «${sound.name}»")
                true
            }
            active[player] = sound.id
            publish()
            player.prepareAsync()
        } catch (e: Exception) {
            release(player)
            onError("Не удалось воспроизвести «${sound.name}»")
        }
    }

    fun stop(soundId: String) {
        active.filterValues { it == soundId }.keys.toList().forEach { release(it) }
    }

    fun stopAll() {
        active.keys.toList().forEach { release(it) }
    }

    fun applyVolume(volume: Float) {
        prepared.toList().forEach { player ->
            try {
                player.setVolume(volume, volume)
            } catch (e: IllegalStateException) {
                release(player)
            }
        }
    }

    private fun release(player: MediaPlayer) {
        active.remove(player)
        prepared.remove(player)
        try {
            player.release()
        } catch (e: Exception) {
            // Плеер уже освобождён системой
        }
        publish()
    }

    private fun publish() {
        _playing.value = active.values.toSet()
    }
}
