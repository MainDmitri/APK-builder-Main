package com.example.soundboardmain.overlay

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.soundboardmain.MainActivity
import com.example.soundboardmain.R
import com.example.soundboardmain.audio.SoundPlayer
import com.example.soundboardmain.data.SettingsRepository
import com.example.soundboardmain.data.Sound
import com.example.soundboardmain.data.SoundRepository
import com.example.soundboardmain.data.sortedForDisplay
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.soundboardmain.action.STOP_OVERLAY"
        private const val CHANNEL_ID = "overlay"
        private const val NOTIFICATION_ID = 1
        private const val BUBBLE_SIZE = 56
        private const val PANEL_WIDTH = 280
        private const val BUTTON_HEIGHT = 52
        private const val BUTTON_MARGIN = 3
        private const val MAX_GRID_HEIGHT = 320

        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running.asStateFlow()
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var windowManager: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var root: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var panel: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var grid: LinearLayout
    private lateinit var emptyText: TextView
    private var attached = false
    private var currentSounds: List<Sound> = emptyList()
    private var currentPlaying: Set<String> = emptySet()
    private val buttons = mutableMapOf<String, TextView>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        SoundRepository.init(this)
        SettingsRepository.init(this)
        createChannel()
        try {
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            } else {
                0
            }
            ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), type)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось запустить панель: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Нет разрешения «Поверх других приложений»", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        buildViews()
        try {
            windowManager.addView(root, params)
            attached = true
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось показать панель: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        _running.value = true

        scope.launch {
            SoundRepository.sounds.collect { list ->
                currentSounds = list.sortedForDisplay()
                rebuildGrid()
            }
        }
        scope.launch {
            SoundPlayer.playing.collect { ids ->
                currentPlaying = ids
                updateHighlight()
            }
        }
        scope.launch {
            SettingsRepository.settings.map { it.overlayAlpha }.distinctUntilChanged().collect { alpha ->
                params.alpha = alpha
                updateLayout()
            }
        }
        scope.launch {
            SettingsRepository.settings.map { it.overlayColumns }.distinctUntilChanged().collect {
                rebuildGrid()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (attached) clampPosition()
    }

    override fun onDestroy() {
        scope.cancel()
        if (attached) {
            try {
                windowManager.removeView(root)
            } catch (e: IllegalArgumentException) {
                // Окно уже удалено системой
            }
            attached = false
        }
        if (_running.value) SoundPlayer.stopAll()
        _running.value = false
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    @SuppressLint("ClickableViewAccessibility")
    private fun buildViews() {
        val primary = ContextCompat.getColor(this, R.color.primary)

        bubble = TextView(this).apply {
            text = "♪"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = getString(R.string.overlay_bubble)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(primary)
                setStroke(dp(2), Color.WHITE)
            }
            layoutParams = LinearLayout.LayoutParams(dp(BUBBLE_SIZE), dp(BUBBLE_SIZE))
            setOnClickListener { togglePanel() }
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, 0, dp(6))
        }
        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            setTextColor(Color.WHITE)
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(headerButton("⌂", "Открыть приложение") { openApp() })
        header.addView(headerButton("■", "Остановить все звуки") { SoundPlayer.stopAll() })
        header.addView(headerButton("✕", "Закрыть панель") { stopSelf() })

        emptyText = TextView(this).apply {
            text = getString(R.string.overlay_empty)
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }

        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = true
            addView(grid, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(ContextCompat.getColor(this@OverlayService, R.color.overlay_panel))
            }
            addView(header)
            addView(emptyText)
            addView(scroll)
        }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bubble)
            addView(panel, LinearLayout.LayoutParams(dp(PANEL_WIDTH), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(6)
            })
        }

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            legacyWindowType()
        }
        params = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = SettingsRepository.overlayX(dp(16))
            y = SettingsRepository.overlayY(dp(160))
            alpha = SettingsRepository.settings.value.overlayAlpha
        }
        clampValues()

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        bubble.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(view: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).roundToInt()
                        val dy = (event.rawY - touchY).roundToInt()
                        if (!moved && (abs(dx) > touchSlop || abs(dy) > touchSlop)) moved = true
                        if (moved) {
                            params.x = startX + dx
                            params.y = startY + dy
                            clampValues()
                            updateLayout()
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            SettingsRepository.saveOverlayPosition(params.x, params.y)
                        } else {
                            view.performClick()
                        }
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> return true
                }
                return false
            }
        })
    }

    @Suppress("DEPRECATION")
    private fun legacyWindowType(): Int = WindowManager.LayoutParams.TYPE_PHONE

    private fun headerButton(symbol: String, description: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = symbol
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = description
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(ContextCompat.getColor(this@OverlayService, R.color.overlay_button))
            }
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginStart = dp(6) }
            setOnClickListener { onClick() }
        }

    private fun togglePanel() {
        panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        clampPosition()
    }

    private fun clampValues() {
        val metrics = resources.displayMetrics
        val width = if (::panel.isInitialized && panel.visibility == View.VISIBLE) dp(PANEL_WIDTH) else dp(BUBBLE_SIZE)
        params.x = params.x.coerceIn(0, (metrics.widthPixels - width).coerceAtLeast(0))
        params.y = params.y.coerceIn(0, (metrics.heightPixels - dp(BUBBLE_SIZE)).coerceAtLeast(0))
    }

    private fun clampPosition() {
        clampValues()
        updateLayout()
    }

    private fun updateLayout() {
        if (!attached) return
        try {
            windowManager.updateViewLayout(root, params)
        } catch (e: IllegalArgumentException) {
            attached = false
        }
    }

    private fun rebuildGrid() {
        if (!::grid.isInitialized) return
        grid.removeAllViews()
        buttons.clear()
        val columns = SettingsRepository.settings.value.overlayColumns
        val isEmpty = currentSounds.isEmpty()
        emptyText.visibility = if (isEmpty) View.VISIBLE else View.GONE
        scroll.visibility = if (isEmpty) View.GONE else View.VISIBLE

        val rows = currentSounds.chunked(columns)
        rows.forEach { rowSounds ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowSounds.forEach { sound ->
                val button = soundButton(sound)
                row.addView(button, cellParams())
                buttons[sound.id] = button
            }
            repeat(columns - rowSounds.size) { row.addView(Space(this), cellParams()) }
            grid.addView(row)
        }

        val contentHeight = rows.size * dp(BUTTON_HEIGHT + BUTTON_MARGIN * 2)
        scroll.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            if (contentHeight > dp(MAX_GRID_HEIGHT)) dp(MAX_GRID_HEIGHT) else ViewGroup.LayoutParams.WRAP_CONTENT,
        )
        updateHighlight()
    }

    private fun cellParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, dp(BUTTON_HEIGHT), 1f).apply {
            val m = dp(BUTTON_MARGIN)
            setMargins(m, m, m, m)
        }

    private fun soundButton(sound: Sound): TextView = TextView(this).apply {
        text = if (sound.favorite) "★ ${sound.name}" else sound.name
        textSize = 12f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
        setPadding(dp(4), dp(2), dp(4), dp(2))
        background = GradientDrawable().apply { cornerRadius = dp(10).toFloat() }
        setOnClickListener {
            SoundPlayer.toggle(sound) { error ->
                Toast.makeText(this@OverlayService, error, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateHighlight() {
        val normal = ContextCompat.getColor(this, R.color.overlay_button)
        val playing = ContextCompat.getColor(this, R.color.overlay_button_playing)
        buttons.forEach { (id, view) ->
            (view.background as? GradientDrawable)?.setColor(if (id in currentPlaying) playing else normal)
        }
    }

    private fun openApp() {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        try {
            startActivity(intent)
            panel.visibility = View.GONE
            clampPosition()
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть приложение", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createChannel() {
        val channel = NotificationChannelCompat.Builder(CHANNEL_ID, NotificationManagerCompat.IMPORTANCE_LOW)
            .setName(getString(R.string.notification_channel))
            .setShowBadge(false)
            .build()
        NotificationManagerCompat.from(this).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags,
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            flags,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notification_text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, getString(R.string.notification_stop), stopIntent)
            .build()
    }
}
