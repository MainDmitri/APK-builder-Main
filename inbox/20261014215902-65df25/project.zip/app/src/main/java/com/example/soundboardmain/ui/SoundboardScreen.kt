package com.example.soundboardmain.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.soundboardmain.R
import com.example.soundboardmain.data.Sound

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundboardScreen(
    onPickFiles: () -> Unit,
    onRecord: () -> Unit,
    onStartOverlay: () -> Unit,
    onStopOverlay: () -> Unit,
    onOpenOverlaySettings: () -> Unit,
    viewModel: MainViewModel = viewModel(),
) {
    val sounds by viewModel.sounds.collectAsStateWithLifecycle()
    val playing by viewModel.playing.collectAsStateWithLifecycle()
    val busy by viewModel.busy.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val overlayRunning by viewModel.overlayRunning.collectAsStateWithLifecycle()
    val overlayGranted by viewModel.overlayGranted.collectAsStateWithLifecycle()
    val recording by viewModel.recording.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var addMenuOpen by remember { mutableStateOf(false) }
    var showUrlDialog by remember { mutableStateOf(false) }
    var showOverlayPermissionDialog by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<Sound?>(null) }
    var deleteTarget by remember { mutableStateOf<Sound?>(null) }
    var query by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(message) {
        val text = message ?: return@LaunchedEffect
        viewModel.messageShown()
        snackbarHostState.showSnackbar(text)
    }

    val visibleSounds = remember(sounds, query) {
        val q = query.trim()
        if (q.isEmpty()) sounds else sounds.filter { it.name.contains(q, ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.app_name)) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary,
                ),
                actions = {
                    if (playing.isNotEmpty()) {
                        IconButton(onClick = { viewModel.stopAll() }) {
                            Icon(Icons.Filled.Clear, contentDescription = "Остановить все звуки")
                        }
                    }
                    IconButton(onClick = { viewModel.openSettings() }) {
                        Icon(Icons.Filled.Settings, contentDescription = "Настройки")
                    }
                },
            )
        },
        floatingActionButton = {
            Box {
                FloatingActionButton(onClick = { addMenuOpen = true }) {
                    Icon(Icons.Filled.Add, contentDescription = "Добавить звук")
                }
                DropdownMenu(expanded = addMenuOpen, onDismissRequest = { addMenuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Файлы с устройства") },
                        onClick = {
                            addMenuOpen = false
                            onPickFiles()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Скачать по ссылке") },
                        onClick = {
                            addMenuOpen = false
                            showUrlDialog = true
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Записать с микрофона") },
                        onClick = {
                            addMenuOpen = false
                            onRecord()
                        },
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

            OverlayCard(
                running = overlayRunning,
                granted = overlayGranted,
                onClick = {
                    when {
                        overlayRunning -> onStopOverlay()
                        overlayGranted -> onStartOverlay()
                        else -> showOverlayPermissionDialog = true
                    }
                },
            )

            if (sounds.isNotEmpty()) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Поиск звука") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Filled.Clear, contentDescription = "Очистить поиск")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }

            when {
                sounds.isEmpty() -> EmptyState(onPickFiles = onPickFiles)
                visibleSounds.isEmpty() -> Text(
                    "Ничего не найдено",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    textAlign = TextAlign.Center,
                )
                else -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 150.dp),
                    contentPadding = PaddingValues(start = 12.dp, top = 4.dp, end = 12.dp, bottom = 96.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(visibleSounds, key = { it.id }) { sound ->
                        SoundCard(
                            sound = sound,
                            isPlaying = sound.id in playing,
                            onClick = { viewModel.play(sound) },
                            onToggleFavorite = { viewModel.toggleFavorite(sound) },
                            onRename = { renameTarget = sound },
                            onDelete = { deleteTarget = sound },
                        )
                    }
                }
            }
        }
    }

    if (showUrlDialog) {
        UrlDialog(
            onConfirm = { url, name ->
                showUrlDialog = false
                viewModel.download(url, name)
            },
            onDismiss = { showUrlDialog = false },
        )
    }

    if (showOverlayPermissionDialog) {
        OverlayPermissionDialog(
            onOpenSettings = {
                showOverlayPermissionDialog = false
                onOpenOverlaySettings()
            },
            onDismiss = { showOverlayPermissionDialog = false },
        )
    }

    renameTarget?.let { target ->
        RenameDialog(
            sound = target,
            onConfirm = { name ->
                viewModel.rename(target, name)
                renameTarget = null
            },
            onDismiss = { renameTarget = null },
        )
    }

    deleteTarget?.let { target ->
        DeleteDialog(
            sound = target,
            onConfirm = {
                viewModel.delete(target)
                deleteTarget = null
            },
            onDismiss = { deleteTarget = null },
        )
    }

    if (recording.active) {
        RecordDialog(
            startedAt = recording.startedAt,
            defaultName = "Запись ${sounds.size + 1}",
            amplitude = { viewModel.recordingAmplitude() },
            onSave = { name -> viewModel.saveRecording(name) },
            onCancel = { viewModel.cancelRecording() },
        )
    }
}

@Composable
private fun OverlayCard(running: Boolean, granted: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 12.dp, top = 12.dp, end = 12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
        ),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Плавающая панель", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                when {
                    running -> "Панель запущена. Нажмите на синюю кнопку ♪ поверх любого приложения, " +
                        "чтобы открыть звуки. Кнопку можно перетаскивать."
                    !granted -> "Для работы поверх других приложений нужно разрешение «Показ поверх других приложений»."
                    else -> "Запустите панель, чтобы проигрывать звуки поверх игр и других приложений."
                },
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(modifier = Modifier.height(12.dp))
            if (running) {
                OutlinedButton(onClick = onClick) { Text("Остановить панель") }
            } else {
                Button(onClick = onClick) { Text(if (granted) "Запустить панель" else "Выдать разрешение") }
            }
        }
    }
}

@Composable
private fun EmptyState(onPickFiles: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Звуков пока нет", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "Добавьте аудиофайлы с устройства, скачайте по ссылке или запишите с микрофона через кнопку «+».",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onPickFiles) { Text("Выбрать файлы") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SoundCard(
    sound: Sound,
    isPlaying: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(96.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            contentColor = if (isPlaying) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                if (isPlaying) Icons.Filled.Close else Icons.Filled.PlayArrow,
                contentDescription = if (isPlaying) "Остановить" else "Воспроизвести",
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                sound.name,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "Действия")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text(if (sound.favorite) "Убрать из избранного" else "В избранное") },
                            leadingIcon = { Icon(Icons.Filled.Star, contentDescription = null) },
                            onClick = {
                                menuOpen = false
                                onToggleFavorite()
                            },
                        )
                        DropdownMenuItem(
                            text = { Text("Переименовать") },
                            leadingIcon = { Icon(Icons.Filled.Edit, contentDescription = null) },
                            onClick = {
                                menuOpen = false
                                onRename()
                            },
                        )
                        DropdownMenuItem(
                            text = { Text("Удалить") },
                            leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null) },
                            onClick = {
                                menuOpen = false
                                onDelete()
                            },
                        )
                    }
                }
                if (sound.favorite) {
                    Icon(
                        Icons.Filled.Star,
                        contentDescription = "Избранное",
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
        }
    }
}
