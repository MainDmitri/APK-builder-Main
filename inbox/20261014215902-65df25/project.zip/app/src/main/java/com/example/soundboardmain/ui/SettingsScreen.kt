package com.example.soundboardmain.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: MainViewModel = viewModel()) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Настройки") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                ),
                navigationIcon = {
                    IconButton(onClick = { viewModel.back() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                },
            )
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Column {
                Text("Громкость звуков: ${(settings.volume * 100).roundToInt()}%", style = MaterialTheme.typography.titleSmall)
                Slider(
                    value = settings.volume,
                    onValueChange = { viewModel.setVolume(it) },
                    valueRange = 0f..1f,
                )
                Text(
                    "Громкость относительно системной громкости мультимедиа.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Останавливать предыдущий звук", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "Если выключено, звуки накладываются друг на друга.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Switch(checked = settings.stopPrevious, onCheckedChange = { viewModel.setStopPrevious(it) })
            }

            Column {
                Text(
                    "Непрозрачность панели: ${(settings.overlayAlpha * 100).roundToInt()}%",
                    style = MaterialTheme.typography.titleSmall,
                )
                Slider(
                    value = settings.overlayAlpha,
                    onValueChange = { viewModel.setOverlayAlpha(it) },
                    valueRange = 0.3f..1f,
                )
            }

            Column {
                Text("Кнопок в ряду на панели: ${settings.overlayColumns}", style = MaterialTheme.typography.titleSmall)
                Slider(
                    value = settings.overlayColumns.toFloat(),
                    onValueChange = { viewModel.setOverlayColumns(it.roundToInt()) },
                    valueRange = 2f..4f,
                    steps = 1,
                )
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                ),
            ) {
                Row(modifier = Modifier.padding(16.dp)) {
                    Icon(Icons.Filled.Info, contentDescription = null)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Как звук попадает в микрофон", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Android не разрешает приложениям подменять сигнал микрофона в других приложениях " +
                                "(это возможно только с root-доступом). Soundboard MAIN проигрывает звук через " +
                                "динамик телефона, и микрофон улавливает его — собеседник в игре или звонке слышит звук.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                        Text(
                            "Для лучшего результата: громкость мультимедиа на максимум, громкая связь во время звонка, " +
                                "без наушников, а в приложении голосового чата отключите шумо- и эхоподавление, " +
                                "если такая настройка есть.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }
    }
}
