package com.example.soundboardmain.data

import org.json.JSONObject

data class Sound(
    val id: String,
    val name: String,
    val fileName: String,
    val favorite: Boolean,
    val createdAt: Long,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("fileName", fileName)
        .put("favorite", favorite)
        .put("createdAt", createdAt)

    companion object {
        fun fromJson(json: JSONObject): Sound = Sound(
            id = json.getString("id"),
            name = json.getString("name"),
            fileName = json.getString("fileName"),
            favorite = json.optBoolean("favorite", false),
            createdAt = json.optLong("createdAt", 0L),
        )
    }
}

fun List<Sound>.sortedForDisplay(): List<Sound> =
    sortedWith(compareByDescending<Sound> { it.favorite }.thenBy { it.createdAt })
