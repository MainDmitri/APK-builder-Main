// Существа и выброшенные предметы одиночной игры: появление, поведение, бой, взрывы, подбор предметов
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const Blocks = MC.Blocks;

  // hp, скорость (доля от скорости игрока), враждебность, урон, добыча [id, data, min, max]
  const DEFS = {
    10: { hp: 4, speed: 0.4, drops: [[288, 0, 0, 2], [365, 0, 1, 1]], cooked: { 365: 366 } },
    11: { hp: 10, speed: 0.35, drops: [[334, 0, 0, 2], [363, 0, 1, 3]], cooked: { 363: 364 } },
    12: { hp: 10, speed: 0.4, drops: [[319, 0, 1, 3]], cooked: { 319: 320 } },
    13: { hp: 8, speed: 0.4, drops: [[35, 0, 1, 1], [423, 0, 1, 2]], cooked: { 423: 424 } },
    32: { hp: 20, speed: 0.55, hostile: true, damage: 3, burns: true, kill: 'Убит зомби', drops: [[367, 0, 0, 2]] },
    33: { hp: 20, speed: 0.5, hostile: true, creeper: true, drops: [[289, 0, 0, 2]] },
    35: { hp: 16, speed: 0.7, hostile: true, damage: 2, dayNeutral: true, kill: 'Убит пауком', drops: [[287, 0, 0, 2], [375, 0, 0, 1]] }
  };
  const PASSIVE = [12, 11, 13, 10];
  const HOSTILE = [32, 32, 33, 35];
  const MOB_CAP = 10, HOSTILE_CAP = 8;
  const ITEM_CAP = 1500;

  const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  const yawTo = (dx, dz) => Math.atan2(-dx, dz) * 180 / Math.PI;

  class Entities {
    constructor(game) {
      this.game = game;
      this.world = game.world;
      this.list = new Map();
      this.nextId = 1;
      this.spawnTimer = 0;
    }

    // ---------- Предметы ----------
    spawnItem(item, x, y, z, vx, vy, vz, delay) {
      if (!item || !item.id || item.count <= 0) return;
      const eid = this.nextId++;
      this.list.set(eid, {
        kind: 'item', eid, item: { id: item.id, data: item.data, count: item.count },
        x, y, z, vx: vx === undefined ? (Math.random() - 0.5) * 2 : vx, vy: vy === undefined ? 3 : vy, vz: vz === undefined ? (Math.random() - 0.5) * 2 : vz,
        age: 0, delay: delay === undefined ? 0.5 : delay
      });
    }

    liquidAt(x, y, z) {
      const id = this.world.getId(Math.floor(x), Math.floor(y), Math.floor(z));
      return id >= 8 && id <= 11;
    }

    // Объединение одинаковых лежащих рядом предметов в стопки до 64 (как в Minecraft)
    mergeItems() {
      const cells = new Map();
      for (const e of this.list.values()) {
        if (e.kind !== 'item' || e.item.count >= 64) continue;
        const key = Math.floor(e.x) + ',' + Math.floor(e.y) + ',' + Math.floor(e.z) + ',' + e.item.id + ',' + (e.item.data | 0);
        const o = cells.get(key);
        if (!o || !this.list.has(o.eid)) { cells.set(key, e); continue; }
        if (e.item.nbt || o.item.nbt) continue;
        const max = MC.Survival.maxStack(e.item.id);
        const n = Math.min(e.item.count, max - o.item.count);
        if (n <= 0) { cells.set(key, e); continue; }
        o.item.count += n;
        o.age = Math.min(o.age, e.age);
        o.delay = Math.max(o.delay, e.delay);
        e.item.count -= n;
        if (e.item.count <= 0) this.list.delete(e.eid);
        if (o.item.count >= max) cells.delete(key);
      }
    }

    // Снаряды: жемчуг Края (телепорт), снежок и яйцо (толчок)
    throwProjectile(item, x, y, z, dir, speed) {
      const eid = this.nextId++;
      this.list.set(eid, { kind: 'proj', eid, item: { id: item.id, data: item.data, count: 1 }, x, y, z, vx: dir[0] * speed, vy: dir[1] * speed, vz: dir[2] * speed, age: 0 });
    }

    updateProj(e, dt) {
      e.age += dt;
      if (e.age > 20) { this.list.delete(e.eid); return; }
      const w = this.world;
      if (!w.isLoaded(Math.floor(e.x), Math.floor(e.z))) { this.list.delete(e.eid); return; }
      e.vy -= 12 * dt;
      const drag = Math.pow(0.99, dt * 20);
      e.vx *= drag; e.vy *= drag; e.vz *= drag;
      const steps = 4;
      for (let i = 0; i < steps; i++) {
        const px = e.x, py = e.y, pz = e.z;
        const nx = e.x + e.vx * dt / steps, ny = e.y + e.vy * dt / steps, nz = e.z + e.vz * dt / steps;
        let target = null;
        for (const m of this.list.values()) {
          if (m.kind !== 'mob' || m.dead) continue;
          const b = m.body;
          const mw = m.def.size ? m.def.size[0] : 0.6, mh = m.def.size ? m.def.size[1] : 1.8;
          if (Math.abs(nx - b.x) < mw / 2 + 0.15 && Math.abs(nz - b.z) < mw / 2 + 0.15 && ny > b.y - 0.15 && ny < b.y + mh + 0.15) { target = m; break; }
        }
        if (target || this.solidAt(nx, ny, nz)) { this.projectileHit(e, px, py, pz, target); return; }
        e.x = nx; e.y = ny; e.z = nz;
      }
    }

    projectileHit(e, x, y, z, mob) {
      const g = this.game, p = g.player;
      this.list.delete(e.eid);
      if (mob) this.hurtMob(mob, 0, x, z, true);
      if (e.item.id === 368) {
        // Жемчуг Края: игрок переносится в точку падения и получает 5 урона (как в Minecraft)
        let ty = y;
        while (ty > 1 && !this.solidAt(x, ty - 0.05, z)) ty -= 0.05;
        p.x = x; p.y = ty + 0.01; p.z = z;
        p.vx = 0; p.vy = 0; p.vz = 0;
        p.fallStart = null;
        MC.Sound.play('mob.endermen.portal', [x, y, z], 1, 1);
        g.damagePlayer(5, null, null, 'Телепортация жемчугом Края');
      } else if (e.item.id === 344) {
        if (Math.random() < 0.125) this.spawnMob(10, x, y, z);
      }
    }

    solidAt(x, y, z) {
      const bx = Math.floor(x), by = Math.floor(y), bz = Math.floor(z);
      const id = this.world.getId(bx, by, bz);
      if (!id) return false;
      const boxes = Blocks.collisionBoxes(id, this.world.getData(bx, by, bz), this.world, bx, by, bz);
      if (!boxes) return false;
      return boxes.some((b) => y - by >= b[1] - 1e-4 && y - by < b[4] && x - bx >= b[0] && x - bx <= b[3] && z - bz >= b[2] && z - bz <= b[5]);
    }

    updateItem(e, dt) {
      e.age += dt;
      e.delay -= dt;
      if (e.age > 300) { this.list.delete(e.eid); return; }
      const w = this.world;
      if (!w.isLoaded(Math.floor(e.x), Math.floor(e.z))) return;
      const p0 = this.game.player;
      const near = Math.abs(e.x - p0.x) < 3 && Math.abs(e.z - p0.z) < 3 && Math.abs(e.y - p0.y) < 4;
      // Лежащий предмет «спит»: физика не считается, раз в секунду проверяется опора
      if (e.rest) {
        e.restCheck -= dt;
        if (e.restCheck > 0 && !near) return;
        e.restCheck = 1 + Math.random() * 0.5;
        if (this.solidAt(e.x, e.y - 0.05, e.z) && !this.solidAt(e.x, e.y + 0.1, e.z) && !this.liquidAt(e.x, e.y, e.z)) {
          if (!near) return;
        } else e.rest = false;
      }
      const inWater = (() => { const id = w.getId(Math.floor(e.x), Math.floor(e.y), Math.floor(e.z)); return id === 8 || id === 9; })();
      e.vy -= (inWater ? 4 : 20) * dt;
      if (inWater) e.vy = Math.max(e.vy, 1);
      const nx = e.x + e.vx * dt, nz = e.z + e.vz * dt, ny = e.y + e.vy * dt;
      if (!this.solidAt(nx, e.y + 0.05, e.z)) e.x = nx; else e.vx = 0;
      if (!this.solidAt(e.x, e.y + 0.05, nz)) e.z = nz; else e.vz = 0;
      if (e.vy < 0 && this.solidAt(e.x, ny, e.z)) {
        const by = Math.floor(ny);
        const id = w.getId(Math.floor(e.x), by, Math.floor(e.z));
        const boxes = Blocks.collisionBoxes(id, w.getData(Math.floor(e.x), by, Math.floor(e.z)), w, Math.floor(e.x), by, Math.floor(e.z)) || [[0, 0, 0, 1, 1, 1]];
        e.y = by + Math.max(...boxes.map((b) => b[4]));
        e.vy = 0;
        e.vx *= Math.pow(0.02, dt);
        e.vz *= Math.pow(0.02, dt);
        if (Math.abs(e.vx) < 0.05 && Math.abs(e.vz) < 0.05 && !inWater) { e.vx = 0; e.vz = 0; e.rest = true; e.restCheck = 1; }
      } else if (e.vy > 0 && this.solidAt(e.x, ny + 0.25, e.z)) {
        e.vy = 0;
      } else {
        e.y = ny;
      }
      if (this.solidAt(e.x, e.y + 0.1, e.z)) e.y = Math.floor(e.y + 0.1) + 1;
      // Подбор игроком
      const p = this.game.player;
      if (e.delay <= 0 && !this.game.dead && Math.abs(e.x - p.x) < 1.4 && Math.abs(e.z - p.z) < 1.4 && e.y > p.y - 0.8 && e.y < p.y + 2.2) {
        const left = this.game.sinv.add(e.item);
        if (left < e.item.count) this.game.onPickup(e.item);
        if (left <= 0) this.list.delete(e.eid); else e.item.count = left;
      }
    }

    // ---------- Существа ----------
    spawnMob(type, x, y, z) {
      const def = DEFS[type];
      if (!def) return null;
      const body = new MC.Player(this.world);
      body.canFly = false;
      body.x = x; body.y = y; body.z = z;
      body.yaw = Math.random() * 360;
      const eid = this.nextId++;
      const m = { kind: 'mob', eid, type, def, body, hp: def.hp, hurt: 0, invuln: 0, wander: 0, walking: false, flee: 0, angry: 0, attackCd: 0, fuse: 0, burn: 0, lava: 0, dead: 0 };
      this.list.set(eid, m);
      return m;
    }

    hurtMob(m, dmg, fromX, fromZ, byPlayer) {
      if (m.dead || m.invuln > 0) return false;
      m.hp -= dmg;
      m.hurt = 0.4;
      m.invuln = 0.25;
      const dx = m.body.x - fromX, dz = m.body.z - fromZ;
      const l = Math.hypot(dx, dz) || 1;
      m.body.vx += dx / l * 7;
      m.body.vz += dz / l * 7;
      m.body.vy = 5;
      if (byPlayer) { m.flee = 4; m.angry = 30; }
      MC.Sound.entity(m.type, m.hp <= 0 ? 'death' : 'hurt', m.body.x, m.body.y + 1, m.body.z);
      if (m.hp <= 0) {
        m.dead = 0.6;
        if (byPlayer) {
          for (const [id, data, a, b] of m.def.drops) {
            const n = rnd(a, b);
            if (n > 0) this.spawnItem({ id: m.burn > 0 && m.def.cooked && m.def.cooked[id] ? m.def.cooked[id] : id, data, count: n }, m.body.x, m.body.y + 0.5, m.body.z);
          }
        }
      }
      return true;
    }

    hostileCount() {
      let h = 0, a = 0;
      for (const e of this.list.values()) if (e.kind === 'mob') { if (e.def.hostile) h++; else a++; }
      return [a, h];
    }

    trySpawn() {
      const g = this.game, w = this.world, p = g.player;
      const [passive, hostile] = this.hostileCount();
      const night = g.daylight() < 0.45;
      const ang = Math.random() * Math.PI * 2, dist = 24 + Math.random() * 20;
      const x = Math.floor(p.x + Math.cos(ang) * dist), z = Math.floor(p.z + Math.sin(ang) * dist);
      if (!w.isLoaded(x, z) || !w.isLoaded(x + 1, z + 1) || !w.isLoaded(x - 1, z - 1)) return;
      const top = w.height(x, z);
      if (Math.random() < 0.5 && passive < MOB_CAP) {
        if (w.getId(x, top - 1, z) !== 2 || w.getId(x, top, z) !== 0 || w.getId(x, top + 1, z) !== 0) return;
        const type = PASSIVE[rnd(0, PASSIVE.length - 1)];
        const n = rnd(1, 3);
        for (let i = 0; i < n; i++) this.spawnMob(type, x + 0.5 + i * 0.3, top, z + 0.5);
        return;
      }
      if (hostile >= HOSTILE_CAP) return;
      // Ночью — на поверхности, в любое время — в пещерах под землёй
      let y = -1;
      if (night && w.getId(x, top, z) === 0 && w.getId(x, top + 1, z) === 0 && Blocks.list[w.getId(x, top - 1, z)].solid && !Blocks.list[w.getId(x, top - 1, z)].liquid) y = top;
      else {
        for (let t = 0; t < 6 && y < 0; t++) {
          const yy = rnd(6, Math.max(7, top - 8));
          if (w.getId(x, yy, z) === 0 && w.getId(x, yy + 1, z) === 0 && Blocks.list[w.getId(x, yy - 1, z)].opaque) y = yy;
        }
      }
      if (y < 0 || this.litAt(x, y, z) > 7) return;
      this.spawnMob(HOSTILE[rnd(0, HOSTILE.length - 1)], x + 0.5, y, z + 0.5);
    }

    // Уровень блочного света в точке (источник минус манхэттенское расстояние)
    litAt(x, y, z) {
      const w = this.world, L = Blocks.LIGHT;
      let best = 0;
      for (let dx = -14; dx <= 14; dx++) for (let dz = -14; dz <= 14; dz++) {
        const ax = Math.abs(dx) + Math.abs(dz);
        if (ax > 14) continue;
        for (let dy = -(14 - ax); dy <= 14 - ax; dy++) {
          const l = L[w.getId(x + dx, y + dy, z + dz)];
          if (l) { const v = l - ax - Math.abs(dy); if (v > best) best = v; }
        }
      }
      return best;
    }

    updateMob(m, dt) {
      const g = this.game, p = g.player, b = m.body, w = this.world;
      if (!w.isLoaded(Math.floor(b.x), Math.floor(b.z))) { this.list.delete(m.eid); return; }
      m.hurt = Math.max(0, m.hurt - dt);
      m.invuln = Math.max(0, m.invuln - dt);
      m.attackCd = Math.max(0, m.attackCd - dt);
      m.flee = Math.max(0, m.flee - dt);
      m.angry = Math.max(0, m.angry - dt);
      if (m.dead) {
        m.dead -= dt;
        if (m.dead <= 0) this.list.delete(m.eid);
        return;
      }
      const dx = p.x - b.x, dz = p.z - b.z, dy = p.y - b.y;
      const dist = Math.hypot(dx, dz, dy);
      const def = m.def;
      if (def.hostile && dist > 72) { this.list.delete(m.eid); return; }
      const input = { forward: 0, strafe: 0, jump: b.inWater || b.inLava, sneak: false, sprint: false, autoJump: true };
      const target = !g.dead && g.survival() && dist < 16;
      const aggressive = def.hostile && target && (!def.dayNeutral || g.daylight() < 0.6 || m.angry > 0);
      // Голоса существ время от времени
      m.ambient = (m.ambient === undefined ? Math.random() * 8 : m.ambient) - dt;
      if (m.ambient <= 0) {
        m.ambient = 6 + Math.random() * 10;
        if (dist < 16) MC.Sound.entity(m.type, 'ambient', b.x, b.y + 1, b.z);
      }
      if (def.creeper && target && dist < 3.2) {
        if (m.fuse === 0) MC.Sound.entity(m.type, 'fuse', b.x, b.y + 1, b.z);
        m.fuse += dt;
        b.yaw = yawTo(dx, dz);
        if (m.fuse >= 1.5) { this.explode(b.x, b.y + 0.5, b.z, 3); this.list.delete(m.eid); return; }
      } else {
        m.fuse = Math.max(0, m.fuse - dt);
        if (aggressive) {
          b.yaw = yawTo(dx, dz);
          input.forward = def.speed;
          if (def.damage && m.attackCd <= 0 && Math.hypot(dx, dz) < 1.5 && Math.abs(dy) < 1.6) {
            m.attackCd = 1;
            g.damagePlayer(def.damage, b.x, b.z, def.kill);
          }
        } else if (m.flee > 0) {
          // Направление бегства меняется раз в полсекунды, иначе модель дёргается каждый кадр
          m.fleeT = (m.fleeT || 0) - dt;
          if (m.fleeT <= 0) { m.fleeT = 0.5; m.fleeYaw = (Math.random() - 0.5) * 40; }
          b.yaw = yawTo(-dx, -dz) + m.fleeYaw;
          input.forward = Math.min(1, def.speed * 1.8);
        } else {
          m.wander -= dt;
          if (m.wander <= 0) {
            m.walking = Math.random() < 0.6;
            b.yaw = Math.random() * 360;
            m.wander = 1 + Math.random() * 4;
          }
          if (m.walking) input.forward = def.speed * 0.6;
        }
      }
      const fall = b.update(dt, input);
      if (fall > 3) this.hurtMob(m, Math.floor(fall - 3), b.x, b.z, false);
      if (b.inLava) {
        m.lava -= dt;
        if (m.lava <= 0) { m.lava = 0.5; this.hurtMob(m, 4, b.x, b.z, false); }
      }
      // Зомби горят на солнце
      if (def.burns && g.daylight() > 0.75 && !b.inWater && b.y + 1.6 >= w.height(Math.floor(b.x), Math.floor(b.z))) {
        m.burn += dt;
        if (m.burn >= 1) { m.burn = 0.01; m.invuln = 0; this.hurtMob(m, 1, b.x, b.z, false); }
      }
      if (b.y < -64) this.list.delete(m.eid);
    }

    // ---------- Динамит ----------
    primeTnt(x, y, z, fuse) {
      const eid = this.nextId++;
      const a = Math.random() * Math.PI * 2, s = 0.9 + Math.random() * 0.6;
      this.list.set(eid, { kind: 'tnt', eid, x: x + 0.5, y, z: z + 0.5, vx: Math.cos(a) * s, vy: 2.2, vz: Math.sin(a) * s, fuse });
      MC.Sound.play('random.fuse', { x: x + 0.5, y: y + 0.5, z: z + 0.5 }, 1, 1);
    }

    updateTnt(e, dt) {
      e.fuse -= dt;
      e.vy -= 20 * dt;
      const ny = e.y + e.vy * dt;
      if (e.vy < 0 && this.solidAt(e.x, ny, e.z)) { e.y = Math.floor(ny) + 1; e.vy = 0; } else e.y = ny;
      const nx = e.x + (e.vx || 0) * dt, nz = e.z + (e.vz || 0) * dt;
      if (!this.solidAt(nx, e.y + 0.1, e.z)) e.x = nx; else e.vx = 0;
      if (!this.solidAt(e.x, e.y + 0.1, nz)) e.z = nz; else e.vz = 0;
      const drag = Math.pow(0.6, dt);
      e.vx = (e.vx || 0) * drag; e.vz = (e.vz || 0) * drag;
      if (e.fuse <= 0) {
        this.list.delete(e.eid);
        this.explode(e.x, e.y + 0.5, e.z, 4);
      }
    }

    // ---------- Падающие блоки (песок, гравий, бетонная пудра, наковальня) ----------
    spawnFalling(x, y, z, id, data) {
      const eid = this.nextId++;
      this.list.set(eid, { kind: 'fall', eid, x: x + 0.5, y, z: z + 0.5, vx: 0, vy: 0, vz: 0, bid: id, bdata: data });
    }

    updateFalling(e, dt) {
      const w = this.world;
      if (!w.isLoaded(Math.floor(e.x), Math.floor(e.z))) { this.list.delete(e.eid); return; }
      e.vy = Math.max(e.vy - 24 * dt, -40);
      const nx = e.x + (e.vx || 0) * dt, nz = e.z + (e.vz || 0) * dt;
      if (!this.solidAt(nx, e.y + 0.1, e.z)) e.x = nx; else e.vx = 0;
      if (!this.solidAt(e.x, e.y + 0.1, nz)) e.z = nz; else e.vz = 0;
      const drag = Math.pow(0.5, dt);
      e.vx = (e.vx || 0) * drag; e.vz = (e.vz || 0) * drag;
      const ny = e.y + e.vy * dt;
      if (e.vy < 0 && this.solidAt(e.x, ny, e.z)) {
        this.list.delete(e.eid);
        this.landFalling(Math.floor(e.x), Math.floor(ny) + 1, Math.floor(e.z), e.bid, e.bdata);
      } else {
        e.y = ny;
        if (e.y < -8) this.list.delete(e.eid);
      }
    }

    landFalling(x, y, z, id, data) {
      const w = this.world, g = this.game;
      const free = (yy) => yy >= 0 && yy <= 255 && Blocks.list[w.getId(x, yy, z)].replaceable;
      const ty = free(y) ? y : free(y + 1) ? y + 1 : -1;
      if (ty >= 0) {
        w.setBlock(x, ty, z, id, data);
        MC.Sound.block(id, 'place', x + 0.5, ty + 0.5, z + 0.5);
      } else if (g.gamemode === 0) {
        this.spawnItem({ id, data, count: 1 }, x + 0.5, y + 0.5, z + 0.5);
      }
    }

    // ---------- Взрыв ----------
    explode(x, y, z, power) {
      const w = this.world, g = this.game;
      const r = Math.ceil(power);
      MC.Sound.event('explode', x, y, z);
      for (let bx = -r; bx <= r; bx++) for (let by = -r; by <= r; by++) for (let bz = -r; bz <= r; bz++) {
        const d = Math.hypot(bx, by, bz);
        if (d > power * (0.7 + Math.random() * 0.45)) continue;
        const X = Math.floor(x) + bx, Y = Math.floor(y) + by, Z = Math.floor(z) + bz;
        const id = w.getId(X, Y, Z);
        if (!id) continue;
        const blk = Blocks.list[id];
        if (blk.hardness < 0 || blk.hardness >= 50 || blk.liquid) continue;
        const data = w.getData(X, Y, Z);
        if (id !== 46 && Math.random() < 0.3) for (const it of MC.Survival.blockDrops(id, data, 278)) this.spawnItem(it, X + 0.5, Y + 0.5, Z + 0.5);
        g.removeBlockSP(X, Y, Z, false);
      }
      const p = g.player;
      const pd = Math.hypot(p.x - x, p.y + 0.9 - y, p.z - z);
      if (pd < power * 2) {
        const impact = 1 - pd / (power * 2);
        g.damagePlayer(Math.floor((impact * impact + impact) * 3.5 * power + 1), x, z, 'Взорван');
      }
      for (const e of this.list.values()) {
        if (e.kind !== 'mob') continue;
        const ed = Math.hypot(e.body.x - x, e.body.y - y, e.body.z - z);
        if (ed < power * 2) {
          const impact = 1 - ed / (power * 2);
          e.invuln = 0;
          this.hurtMob(e, Math.floor((impact * impact + impact) * 3.5 * power + 1), x, z, false);
        }
      }
      // Разлёт сущностей (динамит, предметы, падающие блоки) от взрыва
      for (const o of this.list.values()) {
        if (o.kind !== 'tnt' && o.kind !== 'item' && o.kind !== 'fall') continue;
        const ox = o.x - x, oy = o.y - y, oz = o.z - z;
        const od = Math.hypot(ox, oy, oz);
        if (od > 0.1 && od < power * 2) {
          const impact = (1 - od / (power * 2)) * 9;
          o.vx = (o.vx || 0) + ox / od * impact;
          o.vy = (o.vy || 0) + oy / od * impact + 2.5;
          o.rest = false;
          o.vz = (o.vz || 0) + oz / od * impact;
        }
      }
      g.ui.addChat('§7Бабах!');
    }

    // ---------- Кадр ----------
    update(dt) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        this.spawnTimer = 1.5;
        if (this.game.survival() || this.hostileCount()[0] < MOB_CAP) this.trySpawn();
      }
      this.mergeTimer = (this.mergeTimer || 0) - dt;
      if (this.mergeTimer <= 0) { this.mergeTimer = 0.5; this.mergeItems(); }
      // Предметов не больше ITEM_CAP: самые старые исчезают
      if (this.list.size > ITEM_CAP) {
        this.mergeItems();
        const old = [];
        for (const e of this.list.values()) if (e.kind === 'item') old.push(e);
        if (old.length > ITEM_CAP) {
          old.sort((a, b) => b.age - a.age);
          for (let i = 0; i < old.length - ITEM_CAP; i++) this.list.delete(old[i].eid);
        }
      }
      for (const e of Array.from(this.list.values())) {
        if (e.kind === 'item') this.updateItem(e, dt);
        else if (e.kind === 'proj') this.updateProj(e, dt);
        else if (e.kind === 'tnt') this.updateTnt(e, dt);
        else if (e.kind === 'fall') this.updateFalling(e, dt);
        else this.updateMob(e, dt);
      }
    }

    sceneLists() {
      const mobs = [], items = [];
      for (const e of this.list.values()) {
        if (e.kind === 'item' || e.kind === 'proj') items.push(e);
        else if (e.kind === 'tnt') mobs.push({ eid: e.eid, type: 65, x: e.x, y: e.y, z: e.z, yaw: 0, fuse: 4 - e.fuse, hurt: 0 });
        else if (e.kind === 'fall') mobs.push({ eid: e.eid, type: 66, x: e.x, y: e.y, z: e.z, yaw: 0, blockId: e.bid, blockData: e.bdata, hurt: 0 });
        else {
          const b = e.body;
          mobs.push({ eid: e.eid, type: e.type, x: b.x, y: b.y, z: b.z, yaw: b.yaw, walk: b.walkDist, hurt: e.hurt, fuse: e.fuse, dead: e.dead > 0 });
        }
      }
      return { mobs, items };
    }

    targets() {
      const out = [];
      for (const e of this.list.values()) {
        if (e.kind !== 'mob' || e.dead) continue;
        const look = MC.ENTITY_LOOK[e.type];
        out.push({ eid: e.eid, x: e.body.x, y: e.body.y, z: e.body.z, w: look[2][0], h: look[2][1] });
      }
      return out;
    }

    nearHostile(x, y, z, r) {
      for (const e of this.list.values()) {
        if (e.kind === 'mob' && e.def.hostile && !e.dead && Math.hypot(e.body.x - x, e.body.y - y, e.body.z - z) < r) return true;
      }
      return false;
    }

    clear() { this.list.clear(); }
  }

  Entities.TYPES = { zombie: 32, creeper: 33, spider: 35, pig: 12, cow: 11, sheep: 13, chicken: 10 };
  MC.Entities = Entities;
})();
