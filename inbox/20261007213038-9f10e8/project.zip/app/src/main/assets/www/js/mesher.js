// Построение геометрии секции 16x16x16: отсечение скрытых граней, затенение углов (AO), формы блоков
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const Blocks = MC.Blocks;
  const A = window.MC_ASSETS;
  const LIST = Blocks.list;

  const GRID = A.blockGrid;
  const TS = 1 / GRID;
  const EPS = TS * 0.002;

  const OPAQUE = new Uint8Array(256);
  for (let i = 0; i < 256; i++) OPAQUE[i] = LIST[i].opaque ? 1 : 0;

  // Светящиеся блоки: рисуются в полную яркость без затенения «под навесом»
  const EMIT = new Uint8Array(256);
  for (const id of [10, 11, 89, 91, 124, 138, 169, 213]) EMIT[id] = 1;

  const FACES = [
    { n: [0, -1, 0], c: [[0, 0, 1], [0, 0, 0], [1, 0, 0], [1, 0, 1]], shade: 0.5 },
    { n: [0, 1, 0], c: [[0, 1, 0], [0, 1, 1], [1, 1, 1], [1, 1, 0]], shade: 1.0 },
    { n: [0, 0, -1], c: [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]], shade: 0.8 },
    { n: [0, 0, 1], c: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]], shade: 0.8 },
    { n: [-1, 0, 0], c: [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]], shade: 0.6 },
    { n: [1, 0, 0], c: [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]], shade: 0.6 }
  ];
  const AO_CURVE = [0.45, 0.65, 0.82, 1.0];
  const SHADOW = 0.62;

  function faceUV(f, x, y, z) {
    switch (f) {
      case 0: return [x, 1 - z];
      case 1: return [x, z];
      case 2: return [1 - x, 1 - y];
      case 3: return [x, 1 - y];
      case 4: return [z, 1 - y];
      default: return [1 - z, 1 - y];
    }
  }

  class Buf {
    constructor() { this.a = new Float32Array(6 * 1024); this.n = 0; }
    push6(x, y, z, u, v, l) {
      if (this.n + 6 > this.a.length) {
        const na = new Float32Array(this.a.length * 2);
        na.set(this.a);
        this.a = na;
      }
      const a = this.a, n = this.n;
      a[n] = x; a[n + 1] = y; a[n + 2] = z; a[n + 3] = u; a[n + 4] = v; a[n + 5] = l;
      this.n = n + 6;
    }
    result() { return this.a.slice(0, this.n); }
  }

  // Локальная копия блоков секции с запасом в 1 блок по краям (18x18x18)
  const P = 18;
  const pIds = new Uint8Array(P * P * P);
  const pData = new Uint8Array(P * P * P);
  const pHeight = new Uint8Array(P * P);
  const pi = (x, y, z) => ((x + 1) * P + (z + 1)) * P + (y + 1);

  function fill(world, cx, sy, cz) {
    pIds.fill(0);
    pData.fill(0);
    pHeight.fill(0);
    const y0 = sy * 16;
    for (let dcx = -1; dcx <= 1; dcx++) {
      for (let dcz = -1; dcz <= 1; dcz++) {
        const ch = world.getChunk(cx + dcx, cz + dcz);
        const xs = dcx === -1 ? 15 : 0, xe = dcx === 1 ? 0 : 15;
        const zs = dcz === -1 ? 15 : 0, ze = dcz === 1 ? 0 : 15;
        for (let lx = xs; lx <= xe; lx++) {
          for (let lz = zs; lz <= ze; lz++) {
            const px = lx + dcx * 16, pz = lz + dcz * 16;
            if (!ch) {
              // Незагруженный сосед считается сплошным, чтобы не рисовать грани на границе мира
              for (let py = -1; py <= 16; py++) pIds[pi(px, py, pz)] = 1;
              pHeight[(px + 1) * P + (pz + 1)] = 0;
              continue;
            }
            pHeight[(px + 1) * P + (pz + 1)] = ch.height[(lz << 4) | lx];
            for (let py = -1; py <= 16; py++) {
              const wy = y0 + py;
              if (wy < 0 || wy > 255) continue;
              const s = ch.sections[wy >> 4];
              if (!s) continue;
              const i = (lx << 8) | (lz << 4) | (wy & 15);
              const t = pi(px, py, pz);
              pIds[t] = s.ids[i];
              pData[t] = s.meta[i];
            }
          }
        }
      }
    }
  }

  const ctx = { world: null, x: 0, y: 0, z: 0 };
  const localWorld = {
    sx: 0, sy: 0, sz: 0,
    getId(x, y, z) { return pIds[pi(x - this.sx, y - this.sy, z - this.sz)]; },
    getData(x, y, z) { return pData[pi(x - this.sx, y - this.sy, z - this.sz)]; }
  };

  function skyAt(x, y, z) {
    const h = pHeight[(x + 1) * P + (z + 1)];
    return y + localWorld.sy >= h ? 1 : SHADOW;
  }

  // ---------- Блочный свет: факелы, лава, светокамень освещают всё вокруг (до 15 блоков) ----------
  const LIGHT = Blocks.LIGHT;
  const LR = 15, LS = 16 + LR * 2;
  const lIds = new Uint8Array(LS * LS * LS);
  const lVal = new Uint8Array(LS * LS * LS);
  const lQueue = new Int32Array(LS * LS * LS * 2);
  let lActive = false;
  const li = (x, y, z) => ((x + LR) * LS + (z + LR)) * LS + (y + LR);

  function computeBlockLight(world, cx, sy, cz) {
    lActive = false;
    const y0 = sy * 16;
    let qn = 0;
    let filled = false;
    for (let dcx = -1; dcx <= 1; dcx++) {
      for (let dcz = -1; dcz <= 1; dcz++) {
        const ch = world.getChunk(cx + dcx, cz + dcz);
        if (!ch) continue;
        for (let s = Math.max(0, (y0 - LR) >> 4); s <= Math.min(15, (y0 + 15 + LR) >> 4); s++) {
          const sec = ch.sections[s];
          if (!sec) continue;
          const ids = sec.ids;
          // Кэш «есть ли в секции светящиеся блоки» (сбрасывается при изменении блока)
          if (sec.lit === undefined) { sec.lit = false; for (let i = 0; i < 4096; i++) if (LIGHT[ids[i]]) { sec.lit = true; break; } }
          if (!sec.lit) continue;
          for (let i = 0; i < 4096; i++) {
            const id = ids[i];
            if (!LIGHT[id]) continue;
            const lx = i >> 8, lz = (i >> 4) & 15, wy = s * 16 + (i & 15);
            const px = lx + dcx * 16, pz = lz + dcz * 16, py = wy - y0;
            if (px < -LR || px > 15 + LR || pz < -LR || pz > 15 + LR || py < -LR || py > 15 + LR) continue;
            if (!filled) { filled = true; fillLight(world, cx, sy, cz); }
            const k = li(px, py, pz);
            if (lVal[k] < LIGHT[id]) { lVal[k] = LIGHT[id]; lQueue[qn++] = k; }
          }
        }
      }
    }
    if (!qn) return;
    lActive = true;
    // Разлив света: каждый шаг через непрозрачный блок не проходит, уровень падает на 1
    let qh = 0;
    const SS = LS * LS;
    while (qh < qn) {
      const k = lQueue[qh++];
      const lv = lVal[k] - 1;
      if (lv <= 0) continue;
      const y = k % LS, z = ((k - y) / LS) % LS, x = (k - y - z * LS) / SS;
      if (y > 0) spread(k - 1, lv);
      if (y < LS - 1) spread(k + 1, lv);
      if (z > 0) spread(k - LS, lv);
      if (z < LS - 1) spread(k + LS, lv);
      if (x > 0) spread(k - SS, lv);
      if (x < LS - 1) spread(k + SS, lv);
    }
    function spread(n, lv) {
      if (lVal[n] >= lv || OPAQUE[lIds[n]]) return;
      lVal[n] = lv;
      if (qn < lQueue.length) lQueue[qn++] = n;
    }
  }

  function fillLight(world, cx, sy, cz) {
    lIds.fill(0);
    lVal.fill(0);
    const y0 = sy * 16;
    for (let dcx = -1; dcx <= 1; dcx++) {
      for (let dcz = -1; dcz <= 1; dcz++) {
        const ch = world.getChunk(cx + dcx, cz + dcz);
        if (!ch) continue;
        for (let lx = 0; lx < 16; lx++) {
          const px = lx + dcx * 16;
          if (px < -LR || px > 15 + LR) continue;
          for (let lz = 0; lz < 16; lz++) {
            const pz = lz + dcz * 16;
            if (pz < -LR || pz > 15 + LR) continue;
            for (let py = -LR; py <= 15 + LR; py++) {
              const wy = y0 + py;
              if (wy < 0 || wy > 255) continue;
              const sec = ch.sections[wy >> 4];
              if (!sec) continue;
              lIds[li(px, py, pz)] = sec.ids[(lx << 8) | (lz << 4) | (wy & 15)];
            }
          }
        }
      }
    }
  }

  // Уровень блочного света в клетке секции (локальные координаты -1..16), 0..15
  function blAt(x, y, z) { return lActive ? lVal[li(x, y, z)] : 0; }
  // Кодирование в атрибут: свет неба + 2*флаг качания + 8*блочный свет (целый 0..15)
  const enc = (v) => 8 * Math.min(15, Math.max(0, Math.round(v)));

  function tileUV(tile) {
    return [(tile % GRID) * TS, Math.floor(tile / GRID) * TS];
  }

  function emitQuad(buf, verts, uvs, lights, flip) {
    const order = flip ? [1, 2, 3, 1, 3, 0] : [0, 1, 2, 0, 2, 3];
    for (const k of order) buf.push6(verts[k][0], verts[k][1], verts[k][2], uvs[k][0], uvs[k][1], lights[k]);
  }

  // Полный куб с AO
  function cubeFaces(buf, x, y, z, id, data, b) {
    const sway = id === 18 || id === 161 ? 2 : 0;
    for (let f = 0; f < 6; f++) {
      const F = FACES[f];
      const nx = x + F.n[0], ny = y + F.n[1], nz = z + F.n[2];
      const nid = pIds[pi(nx, ny, nz)];
      if (OPAQUE[nid]) continue;
      if (!b.opaque && nid === id) continue;
      if (b.id === 18 && nid === 18 || b.id === 161 && nid === 161) continue;
      ctx.x = localWorld.sx + x; ctx.y = localWorld.sy + y; ctx.z = localWorld.sz + z;
      const tile = b.tex(data, f, ctx);
      const [tu, tv] = tileUV(tile);
      const sky = EMIT[id] ? 1 : skyAt(nx, ny, nz);
      const verts = [], uvs = [], lights = [], ao = [];
      for (let k = 0; k < 4; k++) {
        const c = F.c[k];
        verts.push([x + c[0], y + c[1], z + c[2]]);
        const uv = faceUV(f, c[0], c[1], c[2]);
        uvs.push([tu + EPS + uv[0] * (TS - 2 * EPS), tv + EPS + uv[1] * (TS - 2 * EPS)]);
        // Соседи в плоскости грани для затенения углов
        let s1x = 0, s1y = 0, s1z = 0, s2x = 0, s2y = 0, s2z = 0;
        if (F.n[0] !== 0) { s1y = c[1] ? 1 : -1; s2z = c[2] ? 1 : -1; }
        else if (F.n[1] !== 0) { s1x = c[0] ? 1 : -1; s2z = c[2] ? 1 : -1; }
        else { s1x = c[0] ? 1 : -1; s2y = c[1] ? 1 : -1; }
        const o1 = OPAQUE[pIds[pi(nx + s1x, ny + s1y, nz + s1z)]];
        const o2 = OPAQUE[pIds[pi(nx + s2x, ny + s2y, nz + s2z)]];
        const oc = OPAQUE[pIds[pi(nx + s1x + s2x, ny + s1y + s2y, nz + s1z + s2z)]];
        const a = o1 && o2 ? 0 : 3 - (o1 + o2 + oc);
        ao.push(a);
        let bl = 0;
        if (lActive) {
          // Сглаженный блочный свет: среднее по прозрачным соседям угла
          let sum = blAt(nx, ny, nz), cnt = 1;
          if (!o1) { sum += blAt(nx + s1x, ny + s1y, nz + s1z); cnt++; }
          if (!o2) { sum += blAt(nx + s2x, ny + s2y, nz + s2z); cnt++; }
          if (!oc && !(o1 && o2)) { sum += blAt(nx + s1x + s2x, ny + s1y + s2y, nz + s1z + s2z); cnt++; }
          bl = sum / cnt * F.shade * AO_CURVE[a];
        }
        lights.push(F.shade * AO_CURVE[a] * sky + sway + enc(bl));
      }
      emitQuad(buf, verts, uvs, lights, ao[0] + ao[2] < ao[1] + ao[3]);
    }
  }

  // Произвольные параллелепипеды (ступеньки, плиты, заборы...)
  function boxFaces(buf, x, y, z, id, data, b, boxes, cullEdges) {
    const sky = skyAt(x, y, z);
    for (const bx of boxes) {
      for (let f = 0; f < 6; f++) {
        const F = FACES[f];
        // Грань на краю блока, прилегающая к непрозрачному соседу, не видна
        if (cullEdges) {
          const onEdge = (f === 0 && bx[1] === 0) || (f === 1 && bx[4] === 1) || (f === 2 && bx[2] === 0) || (f === 3 && bx[5] === 1) || (f === 4 && bx[0] === 0) || (f === 5 && bx[3] === 1);
          if (onEdge && OPAQUE[pIds[pi(x + F.n[0], y + F.n[1], z + F.n[2])]]) continue;
        }
        ctx.x = localWorld.sx + x; ctx.y = localWorld.sy + y; ctx.z = localWorld.sz + z;
        const tile = b.tex(data, f, ctx);
        const [tu, tv] = tileUV(tile);
        const verts = [], uvs = [], lights = [];
        const light = F.shade * (f === 1 ? sky : Math.min(1, sky + 0.1)) + enc(Math.max(blAt(x, y, z), blAt(x + F.n[0], y + F.n[1], z + F.n[2])) * F.shade);
        for (let k = 0; k < 4; k++) {
          const c = F.c[k];
          const px = c[0] ? bx[3] : bx[0], py = c[1] ? bx[4] : bx[1], pz = c[2] ? bx[5] : bx[2];
          verts.push([x + px, y + py, z + pz]);
          const uv = faceUV(f, px, py, pz);
          uvs.push([tu + EPS + uv[0] * (TS - 2 * EPS), tv + EPS + uv[1] * (TS - 2 * EPS)]);
          lights.push(light);
        }
        emitQuad(buf, verts, uvs, lights, false);
      }
    }
  }

  // Верхние вершины (2 и 3) получают флаг качания: трава и цветы колышутся в режиме «Красиво»
  function doubleQuad(buf, pts, tile, light) {
    const [tu, tv] = tileUV(tile);
    const u0 = tu + EPS, u1 = tu + TS - EPS, v0 = tv + EPS, v1 = tv + TS - EPS;
    const uvs = [[u0, v1], [u1, v1], [u1, v0], [u0, v0]];
    const l = [light, light, light + 2, light + 2];
    emitQuad(buf, pts, uvs, l, false);
    emitQuad(buf, [pts[1], pts[0], pts[3], pts[2]], [uvs[1], uvs[0], uvs[3], uvs[2]], l, false);
  }

  function crossShape(buf, x, y, z, b, data) {
    ctx.x = localWorld.sx + x; ctx.y = localWorld.sy + y; ctx.z = localWorld.sz + z;
    const tile = b.tex(data, 2, ctx);
    const light = 0.9 * skyAt(x, y, z) + enc(blAt(x, y, z) * 0.9);
    const a = 0.05, c = 0.95;
    doubleQuad(buf, [[x + a, y, z + a], [x + c, y, z + c], [x + c, y + 1, z + c], [x + a, y + 1, z + a]], tile, light);
    doubleQuad(buf, [[x + a, y, z + c], [x + c, y, z + a], [x + c, y + 1, z + a], [x + a, y + 1, z + c]], tile, light);
  }

  function cropShape(buf, x, y, z, b, data) {
    const tile = b.tex(data, 2, null);
    const light = 0.9 * skyAt(x, y, z) + enc(blAt(x, y, z) * 0.9);
    for (const o of [0.25, 0.75]) {
      doubleQuad(buf, [[x + o, y, z], [x + o, y, z + 1], [x + o, y + 1, z + 1], [x + o, y + 1, z]], tile, light);
      doubleQuad(buf, [[x, y, z + o], [x + 1, y, z + o], [x + 1, y + 1, z + o], [x, y + 1, z + o]], tile, light);
    }
  }

  function flatShape(buf, x, y, z, b, data) {
    const tile = b.tex(data, 1, null);
    const light = skyAt(x, y, z) + enc(blAt(x, y, z));
    const h = y + 0.02;
    doubleQuad(buf, [[x, h, z + 1], [x + 1, h, z + 1], [x + 1, h, z], [x, h, z]], tile, light);
  }

  function torchShape(buf, x, y, z, b, data) {
    let ox = 0, oz = 0, oy = 0;
    switch (data & 7) {
      case 1: ox = -0.3125; oy = 0.2; break;
      case 2: ox = 0.3125; oy = 0.2; break;
      case 3: oz = -0.3125; oy = 0.2; break;
      case 4: oz = 0.3125; oy = 0.2; break;
      default: break;
    }
    const bx = [0.4375 + ox, oy, 0.4375 + oz, 0.5625 + ox, 0.625 + oy, 0.5625 + oz];
    const tile = b.tex(data, 2, null);
    const [tu, tv] = tileUV(tile);
    const light = Math.max(0.8, skyAt(x, y, z));
    for (let f = 0; f < 6; f++) {
      const F = FACES[f];
      const verts = [], uvs = [], lights = [];
      for (let k = 0; k < 4; k++) {
        const c = F.c[k];
        const px = c[0] ? bx[3] : bx[0], py = c[1] ? bx[4] : bx[1], pz = c[2] ? bx[5] : bx[2];
        verts.push([x + px, y + py, z + pz]);
        // Текстура факела: столбец 7..9 и строки 6..16 исходной картинки
        const uv = faceUV(f, px - ox, py - oy, pz - oz);
        uvs.push([tu + EPS + uv[0] * (TS - 2 * EPS), tv + EPS + uv[1] * (TS - 2 * EPS)]);
        lights.push(light * F.shade + (1 - F.shade) * 0.5 + enc(blAt(x, y, z)));
      }
      emitQuad(buf, verts, uvs, lights, false);
    }
  }

  function liquidShape(buf, x, y, z, id, data, b) {
    const family = id <= 9 ? 8 : 10;
    const same = (n) => n === family || n === family + 1;
    const above = pIds[pi(x, y + 1, z)];
    const level = data & 7;
    const h = same(above) ? 1 : level === 0 || data >= 8 ? 0.875 : Math.max(0.125, (8 - level) / 9);
    const sky = family === 10 ? 1 : skyAt(x, y, z);
    for (let f = 0; f < 6; f++) {
      const F = FACES[f];
      const nid = pIds[pi(x + F.n[0], y + F.n[1], z + F.n[2])];
      if (same(nid)) continue;
      if (OPAQUE[nid] && f !== 1) continue;
      if (f === 1 && OPAQUE[nid] && h === 1) continue;
      const tile = b.tex(data, f, null);
      const [tu, tv] = tileUV(tile);
      const verts = [], uvs = [], lights = [];
      for (let k = 0; k < 4; k++) {
        const c = F.c[k];
        const py = c[1] ? h : 0;
        verts.push([x + c[0], y + py, z + c[2]]);
        const uv = faceUV(f, c[0], py, c[2]);
        uvs.push([tu + EPS + uv[0] * (TS - 2 * EPS), tv + EPS + uv[1] * (TS - 2 * EPS)]);
        lights.push(F.shade * sky + (f === 1 && family === 8 && !same(above) ? 4 : 0) + enc(Math.max(blAt(x, y, z), blAt(x + F.n[0], y + F.n[1], z + F.n[2])) * F.shade));
      }
      emitQuad(buf, verts, uvs, lights, false);
      // Поверхность воды видна и снизу
      if (f === 1 && b.layer === 'translucent') {
        emitQuad(buf, [verts[1], verts[0], verts[3], verts[2]], [uvs[1], uvs[0], uvs[3], uvs[2]], lights, false);
      }
    }
  }

  function buildSection(world, cx, sy, cz) {
    fill(world, cx, sy, cz);
    computeBlockLight(world, cx, sy, cz);
    localWorld.sx = cx * 16;
    localWorld.sy = sy * 16;
    localWorld.sz = cz * 16;
    ctx.world = localWorld;
    const solid = new Buf(), trans = new Buf();
    for (let x = 0; x < 16; x++) {
      for (let z = 0; z < 16; z++) {
        for (let y = 0; y < 16; y++) {
          const t = pi(x, y, z);
          const id = pIds[t];
          if (id === 0) continue;
          const data = pData[t];
          const b = LIST[id];
          const buf = b.layer === 'translucent' ? trans : solid;
          switch (b.shape) {
            case 'none': break;
            case 'cube': cubeFaces(buf, x, y, z, id, data, b); break;
            case 'cross': crossShape(buf, x, y, z, b, data); break;
            case 'crop': cropShape(buf, x, y, z, b, data); break;
            case 'flat': flatShape(buf, x, y, z, b, data); break;
            case 'torch': torchShape(buf, x, y, z, b, data); break;
            case 'liquid': liquidShape(buf, x, y, z, id, data, b); break;
            default: {
              const wx = localWorld.sx + x, wy = localWorld.sy + y, wz = localWorld.sz + z;
              const boxes = Blocks.boxesOf(id, data, localWorld, wx, wy, wz, false);
              if (boxes && boxes.length) boxFaces(buf, x, y, z, id, data, b, boxes, true);
            }
          }
        }
      }
    }
    return { solid: solid.result(), trans: trans.result() };
  }

  MC.Mesher = { buildSection, FACES, faceUV, tileUV };
})();
