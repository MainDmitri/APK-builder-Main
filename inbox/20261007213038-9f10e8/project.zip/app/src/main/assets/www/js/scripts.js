// Пользовательские скрипты (.js): хранятся в IndexedDB, запускаются при входе в мир или на сервер.
// Каждый скрипт получает объект mc с API игры (см. README, раздел «Скрипты»).
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const KEY = 'scripts';
  const MAX_SIZE = 512 * 1024;

  // ---------- Хранилище ----------
  async function list() {
    const l = await MC.Storage.kv.get(KEY);
    return Array.isArray(l) ? l : [];
  }
  async function saveList(l) { await MC.Storage.kv.put(KEY, l); }

  async function addFile(file) {
    if (!/\.(js|txt)$/i.test(file.name)) throw new Error('Нужен файл .js');
    if (file.size > MAX_SIZE) throw new Error('Скрипт больше 512 КБ');
    const code = await file.text();
    // Проверка синтаксиса до сохранения
    try { new Function('mc', code); } catch (e) { throw new Error('Ошибка в скрипте: ' + e.message); }
    const l = await list();
    const old = l.find((s) => s.name === file.name);
    if (old) { old.code = code; old.size = code.length; old.updated = Date.now(); }
    else l.push({ id: MC.Storage.uuidv4(), name: file.name, code, size: code.length, enabled: true, updated: Date.now() });
    await saveList(l);
    return old ? 'Скрипт ' + file.name + ' обновлён' : 'Скрипт ' + file.name + ' добавлен';
  }
  async function setEnabled(id, on) {
    const l = await list();
    const s = l.find((x) => x.id === id);
    if (s) { s.enabled = !!on; await saveList(l); }
  }
  async function remove(id) { await saveList((await list()).filter((s) => s.id !== id)); }

  // ---------- Выполнение ----------
  const EVENTS = ['tick', 'chat', 'message', 'blockBreak', 'blockPlace', 'attack', 'stop'];

  class Runtime {
    constructor(game) {
      this.game = game;
      this.scripts = [];
      this.commands = new Map();
      this.stopped = false;
    }

    report(s, where, e) {
      console.warn('Скрипт ' + s.name + ' (' + where + ')', e);
      if (this.game.ui) this.game.ui.addChat('§c[' + s.name + '] ' + where + ': ' + (e && e.message ? e.message : String(e)));
    }

    load(rec) {
      const s = { name: rec.name, handlers: {}, timers: new Set(), errors: 0 };
      for (const ev of EVENTS) s.handlers[ev] = [];
      try {
        new Function('mc', '"use strict";\n' + rec.code)(this.api(s));
        this.scripts.push(s);
      } catch (e) {
        this.report(s, 'запуск', e);
        this.clearTimers(s);
      }
    }

    // Вызывает обработчики события; false, если какой-то обработчик вернул false (отмена действия)
    emit(ev, arg) {
      if (this.stopped) return true;
      let ok = true;
      for (const s of this.scripts) {
        for (const fn of s.handlers[ev]) {
          try {
            if (fn(arg) === false) ok = false;
          } catch (e) {
            s.errors++;
            this.report(s, ev, e);
            // Скрипт, который постоянно падает в tick, отключается, чтобы не засыпать чат
            if (ev === 'tick' && s.errors >= 5) { s.handlers.tick = []; this.game.ui.addChat('§c[' + s.name + '] tick отключён после 5 ошибок'); }
          }
        }
      }
      return ok;
    }

    // Сообщение игрока: своя команда скрипта или событие chat. true — сообщение обработано скриптом
    handleChat(text) {
      if (text.startsWith('/')) {
        const args = text.slice(1).trim().split(/\s+/);
        const c = this.commands.get((args[0] || '').toLowerCase());
        if (c) {
          try { c.fn(args.slice(1), text); } catch (e) { this.report(c.script, '/' + args[0], e); }
          return true;
        }
      }
      return this.emit('chat', text) === false;
    }

    clearTimers(s) {
      for (const t of s.timers) { clearTimeout(t); clearInterval(t); }
      s.timers.clear();
    }

    stop() {
      if (this.stopped) return;
      this.emit('stop');
      this.stopped = true;
      for (const s of this.scripts) this.clearTimers(s);
      this.scripts = [];
      this.commands.clear();
    }

    api(s) {
      const rt = this, g = this.game;
      const sp = () => g.mode === 'sp';
      const needSp = (what) => { if (!sp()) throw new Error(what + ' работает только в одиночной игре'); };
      const num = (v, name) => { const n = Number(v); if (!isFinite(n)) throw new Error(name + ' должно быть числом'); return n; };
      const wrapTimer = (fn) => () => { try { fn(); } catch (e) { rt.report(s, 'таймер', e); } };
      const storeKey = 'mcpehtml.script.' + s.name + '.';
      const p = () => g.player;

      const player = {
        get x() { return p().x; }, get y() { return p().y; }, get z() { return p().z; },
        get yaw() { return p().yaw; }, get pitch() { return p().pitch; },
        get vx() { return p().vx; }, get vy() { return p().vy; }, get vz() { return p().vz; },
        get onGround() { return p().onGround; },
        get flying() { return !!p().flying; },
        get sneaking() { return !!p().sneaking; },
        get health() { return g.health; },
        get food() { return g.food; },
        get gamemode() { return g.gamemode; },
        get name() { return g.app.settings.nickname; },
        get dead() { return !!g.dead; },
        lookDir() { return p().lookDir(); },
        teleport(x, y, z) {
          const q = p();
          q.x = num(x, 'x'); q.y = num(y, 'y'); q.z = num(z, 'z');
          q.vx = q.vy = q.vz = 0; q.fallStart = null;
        },
        setVelocity(vx, vy, vz) { const q = p(); q.vx = num(vx, 'vx'); q.vy = num(vy, 'vy'); q.vz = num(vz, 'vz'); },
        look(yaw, pitch) { const q = p(); q.yaw = num(yaw, 'yaw') % 360; q.pitch = Math.max(-90, Math.min(90, num(pitch, 'pitch'))); },
        setHealth(h) { needSp('setHealth'); g.health = Math.max(0, Math.min(20, num(h, 'health'))); if (g.health <= 0) g.damagePlayer(1000, p().x, p().z, 'Скрипт'); },
        setFood(f) { needSp('setFood'); g.food = Math.max(0, Math.min(20, num(f, 'food'))); },
        setGamemode(m) { needSp('setGamemode'); g.setGamemodeSP(num(m, 'gamemode') ? 1 : 0); },
        setFlying(v) { const q = p(); if (q.canFly || g.gamemode === 1) q.flying = !!v; }
      };

      const world = {
        getBlock(x, y, z) {
          const w = g.world, bx = Math.floor(num(x, 'x')), by = Math.floor(num(y, 'y')), bz = Math.floor(num(z, 'z'));
          if (!w.isLoaded(bx, bz)) return null;
          const id = w.getId(bx, by, bz), data = w.getData(bx, by, bz);
          return { id, data, name: MC.Blocks.list[id] ? MC.Blocks.list[id].name : '' };
        },
        setBlock(x, y, z, id, data) {
          needSp('setBlock');
          const bx = Math.floor(num(x, 'x')), by = Math.floor(num(y, 'y')), bz = Math.floor(num(z, 'z'));
          const bid = num(id, 'id') | 0;
          if (bid < 0 || bid > 255 || !MC.Blocks.list[bid]) throw new Error('Нет блока с id ' + id);
          if (by < 0 || by > 255 || !g.world.isLoaded(bx, bz)) return false;
          g.world.setBlock(bx, by, bz, bid, (num(data || 0, 'data') | 0) & 15);
          return true;
        },
        isLoaded(x, z) { return g.world.isLoaded(Math.floor(num(x, 'x')), Math.floor(num(z, 'z'))); },
        height(x, z) { return g.world.height(Math.floor(num(x, 'x')), Math.floor(num(z, 'z'))); },
        get time() { return g.time; },
        set time(t) { needSp('time'); g.time = num(t, 'time'); },
        explode(x, y, z, power) { needSp('explode'); g.ents.explode(num(x, 'x'), num(y, 'y'), num(z, 'z'), Math.min(8, num(power || 4, 'power'))); },
        raycast(dist) {
          const h = p().raycast(Math.min(64, num(dist || 6, 'dist')));
          return h ? { x: h.x, y: h.y, z: h.z, id: h.id, data: h.data, face: h.face } : null;
        }
      };

      const inventory = {
        held() { const it = g.heldItem(); return it && it.id ? { id: it.id, data: it.data, count: it.count } : null; },
        give(id, count, data) {
          needSp('give');
          const it = { id: num(id, 'id') | 0, data: num(data || 0, 'data') | 0, count: Math.max(1, num(count || 1, 'count') | 0) };
          if (!(it.id > 0 && it.id < 512)) throw new Error('Нет предмета с id ' + id);
          const left = g.sinv.add(it);
          if (left) g.ents.spawnItem({ id: it.id, data: it.data, count: left }, p().x, p().y + 1, p().z);
        },
        get selected() { return g.selected; },
        select(i) { g.selectHotbar(Math.max(0, Math.min(8, num(i, 'slot') | 0))); }
      };

      const entities = {
        list() {
          const out = [];
          if (sp() && g.ents) {
            for (const e of g.ents.list.values()) {
              if (e.kind === 'mob') out.push({ eid: e.eid, kind: 'mob', type: e.type, x: e.body.x, y: e.body.y, z: e.body.z, health: e.hp });
              else out.push({ eid: e.eid, kind: e.kind, x: e.x, y: e.y, z: e.z, item: e.item ? { id: e.item.id, data: e.item.data, count: e.item.count } : undefined });
            }
          }
          for (const e of g.entities.values()) out.push({ eid: e.eid, kind: e.kind, type: e.type, name: e.name, x: e.x, y: e.y, z: e.z });
          return out;
        },
        spawn(type, x, y, z) {
          needSp('spawn');
          const t = typeof type === 'string' ? MC.Entities.TYPES[type.toLowerCase()] : type;
          if (!t) throw new Error('Существа: ' + Object.keys(MC.Entities.TYPES).join(', '));
          const m = g.ents.spawnMob(t, num(x, 'x'), num(y, 'y'), num(z, 'z'));
          return m ? m.eid : null;
        },
        dropItem(id, count, data, x, y, z) {
          needSp('dropItem');
          g.ents.spawnItem({ id: num(id, 'id') | 0, data: num(data || 0, 'data') | 0, count: Math.max(1, num(count || 1, 'count') | 0) }, num(x, 'x'), num(y, 'y'), num(z, 'z'));
        },
        attack(eid) { g.attackEntity(eid); }
      };

      return {
        version: '1.1',
        get mode() { return g.mode; },
        player, world, inventory, entities,
        blocks: {
          name(id, data) { return MC.Items.itemName(num(id, 'id') | 0, (data | 0)); }
        },
        on(ev, fn) {
          if (!EVENTS.includes(ev)) throw new Error('Неизвестное событие ' + ev + '. Есть: ' + EVENTS.join(', '));
          if (typeof fn !== 'function') throw new Error('Обработчик должен быть функцией');
          s.handlers[ev].push(fn);
        },
        off(ev, fn) { if (s.handlers[ev]) s.handlers[ev] = s.handlers[ev].filter((f) => f !== fn); },
        command(name, fn) {
          if (typeof fn !== 'function') throw new Error('Команда должна быть функцией');
          rt.commands.set(String(name).toLowerCase().replace(/^\//, ''), { fn, script: s });
        },
        // Строка в чат только себе
        print(text) { g.ui.addChat(String(text)); },
        // Сообщение от имени игрока: на сервере уходит в общий чат, команды /... выполняются
        say(text) { g.chat(String(text)); },
        popup(text) { g.ui.setPopup(String(text)); },
        sound(name, volume, pitch) { MC.Sound.play(String(name), null, volume === undefined ? 1 : volume, pitch === undefined ? 1 : pitch); },
        setTimeout(fn, ms) { const t = setTimeout(() => { s.timers.delete(t); wrapTimer(fn)(); }, ms); s.timers.add(t); return t; },
        setInterval(fn, ms) { const t = setInterval(wrapTimer(fn), Math.max(10, ms | 0)); s.timers.add(t); return t; },
        clearTimer(t) { clearTimeout(t); clearInterval(t); s.timers.delete(t); },
        storage: {
          get(key, def) { try { const v = localStorage.getItem(storeKey + key); return v === null ? def : JSON.parse(v); } catch (e) { return def; } },
          set(key, value) { try { localStorage.setItem(storeKey + key, JSON.stringify(value)); } catch (e) { /* переполнено или недоступно */ } }
        }
      };
    }
  }

  // Запуск включённых скриптов для игры; возвращает Runtime (или null, если скриптов нет)
  async function attach(game) {
    let recs = [];
    try { recs = (await list()).filter((s) => s.enabled); } catch (e) { console.warn('Скрипты недоступны', e); }
    if (!recs.length || game.stopped) return null;
    const rt = new Runtime(game);
    for (const r of recs) rt.load(r);
    game.ui.addChat('§7Скриптов запущено: ' + rt.scripts.length + ' из ' + recs.length);
    return rt;
  }

  // Перезапуск скриптов в текущей игре после изменений в настройках
  async function reload(game) {
    if (!game || game.stopped) return;
    if (game.scripts) game.scripts.stop();
    game.scripts = await attach(game);
  }

  MC.Scripts = { list, addFile, setEnabled, remove, attach, reload, EVENTS };
})();
