package com.dahua.checker

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.wifi.WifiManager
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface

object LocalNetworkScanner {

    data class SubnetInfo(
        val ip: String,
        val prefix: Int,
        val gateway: String?,
        val ssid: String?
    )

    fun getLocalSubnet(context: Context): SubnetInfo? {
        // Способ 1: через ConnectivityManager (Android 6+)
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return fallbackSubnet()
            val lp: LinkProperties = cm.getLinkProperties(network) ?: return fallbackSubnet()

            for (la in lp.linkAddresses) {
                val addr = la.address
                if (addr is Inet4Address && !addr.isLoopbackAddress) {
                    val prefix = la.prefixLength
                    val gateway = lp.routes
                        .filter { it.gateway is Inet4Address && it.gateway?.hostAddress != "0.0.0.0" }
                        .map { it.gateway?.hostAddress }
                        .firstOrNull()

                    val ssid = getWifiSsid(context)
                    return SubnetInfo(addr.hostAddress ?: "", prefix, gateway, ssid)
                }
            }
        } catch (_: Exception) {}

        return fallbackSubnet()
    }

    private fun fallbackSubnet(): SubnetInfo? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
            for (ni in interfaces) {
                if (ni.isLoopback || !ni.isUp) continue
                for (ia in ni.inetAddresses) {
                    if (ia is Inet4Address && !ia.isLoopbackAddress) {
                        val prefix = ni.interfaceAddresses
                            .filter { it.address is Inet4Address }
                            .map { it.networkPrefixLength.toInt() }
                            .firstOrNull() ?: 24
                        return SubnetInfo(ia.hostAddress ?: "", prefix, null, null)
                    }
                }
            }
        } catch (_: Exception) {}
        return null
    }

    @Suppress("DEPRECATION")
    private fun getWifiSsid(context: Context): String? {
        return try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val info = wm.connectionInfo
            val ssid = info.ssid
            if (ssid != null && ssid != "<unknown ssid>" && ssid != "0x") {
                ssid.removePrefix("\"").removeSuffix("\"")
            } else null
        } catch (_: Exception) {
            null
        }
    }

    fun generateIpsForSubnet(subnet: SubnetInfo): List<String> {
        val ip = subnet.ip
        val prefix = subnet.prefix

        val parts = ip.split(".")
        if (parts.size != 4) return emptyList()

        val ipLong = parts.fold(0L) { acc, s ->
            (acc shl 8) or (s.toIntOrNull()?.toLong() ?: 0L)
        }

        val mask = if (prefix == 0) 0L else (0xFFFFFFFFL shl (32 - prefix)) and 0xFFFFFFFFL
        val network = ipLong and mask
        val hostCount = 1L shl (32 - prefix)

        // Ограничение: максимум /16 = 65534 хоста
        if (hostCount > 65536) return emptyList()

        val result = mutableListOf<String>()
        // Пропускаем network и broadcast
        val start = if (prefix >= 31) 0L else 1L
        val end = if (prefix >= 31) hostCount else hostCount - 1

        for (i in start until end) {
            val h = network + i
            // Пропускаем свой IP
            if (h == ipLong) continue
            result.add(
                "${(h shr 24) and 0xFF}.${(h shr 16) and 0xFF}.${(h shr 8) and 0xFF}.${h and 0xFF}"
            )
        }
        return result
    }
}
