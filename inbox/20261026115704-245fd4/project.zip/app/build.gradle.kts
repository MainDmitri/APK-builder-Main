plugins {
    id("com.android.application")
    // org.jetbrains.kotlin.android is NOT used with AGP 9.0+ — Kotlin support is built in
}

android {
    namespace = "com.maindmitri.adbscanner"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.maindmitri.adbscanner"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }

    packaging {
        resources {
            excludes += setOf(
                "META-INF/LICENSE.md",
                "META-INF/LICENSE-notice.md",
                "META-INF/NOTICE.md",
                "META-INF/AL2.0",
                "META-INF/LGPL2.1",
                "META-INF/*.kotlin_module"
            )
        }
    }
}

dependencies {
    // Always-on from the engine (we declare them explicitly in C2 mode)
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.2.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    // App-specific
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("dev.mobile:dadb:1.2.10") {
        // Exclude JUnit transitive dependencies that cause META-INF/LICENSE.md conflicts
        exclude(group = "org.junit.jupiter")
        exclude(group = "org.junit.platform")
        exclude(group = "org.junit.vintage")
        exclude(group = "org.junit")
    }
}
