package com.dahua.checker

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            val dark = darkColorScheme(
                primary = Color(0xFF00E676),
                secondary = Color(0xFF00BCD4),
                tertiary = Color(0xFFFF5252),
                background = Color(0xFF0D1117),
                surface = Color(0xFF161B22),
                surfaceVariant = Color(0xFF21262D),
                onBackground = Color(0xFFE6EDF3),
                onSurface = Color(0xFFE6EDF3),
                onSurfaceVariant = Color(0xFF8B949E),
                outline = Color(0xFF30363D)
            )
            MaterialTheme(colorScheme = dark) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DahuaApp()
                }
            }
        }
    }
}

// ─── Цвета ───
val Green400 = Color(0xFF00E676)
val Green900 = Color(0xFF1B5E20)
val Cyan400 = Color(0xFF00BCD4)
val Red400 = Color(0xFFFF5252)
val Orange400 = Color(0xFFFFB74D)
val Yellow400 = Color(0xFFFFEE58)
val Gray500 = Color(0xFF8B949E)
val SurfaceDark = Color(0xFF161B22)
val SurfaceDark2 = Color(0xFF21262D)
val BorderDark = Color(0xFF30363D)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DahuaApp() {
    var ipInput by remember { mutableStateOf("") }
    var portInput by remember { mutableStateOf("37777") }
    var isScanning by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<ScanProgress?>(null) }
    val results = remember { mutableStateListOf<ScanResult>() }
    var scanner by remember { mutableStateOf<DahuaScanner?>(null) }
    var parseError by remember { mutableStateOf<String?>(null) }
    var selectedResult by remember { mutableStateOf<ScanResult?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize()) {
        // ─── Header ───
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF0D1117), Color(0xFF161B22))
                    )
                )
                .padding(top = 48.dp, bottom = 16.dp, start = 16.dp, end = 16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Green400.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("👁", fontSize = 22.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Dahua Scanner",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        "Mass camera checker",
                        fontSize = 12.sp,
                        color = Gray500
                    )
                }
                // Счётчик найденных
                if (results.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Green400.copy(alpha = 0.15f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            "${results.count { !it.blocked }}",
                            color = Green400,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            }
        }

        // ─── Content ───
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // ─── Input card ───
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "Цель",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Gray500,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        OutlinedTextField(
                            value = ipInput,
                            onValueChange = { ipInput = it; parseError = null },
                            placeholder = {
                                Text(
                                    "192.168.1.1\n10.0.0.1-10.0.0.50\n172.16.0.0/24",
                                    color = Gray500.copy(alpha = 0.5f),
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3,
                            maxLines = 8,
                            textStyle = LocalTextStyle.current.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 14.sp
                            ),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                            isError = parseError != null,
                            enabled = !isScanning,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Green400,
                                unfocusedBorderColor = BorderDark,
                                cursorColor = Green400,
                                focusedContainerColor = Color(0xFF0D1117),
                                unfocusedContainerColor = Color(0xFF0D1117)
                            )
                        )

                        if (parseError != null) {
                            Text(
                                parseError!!,
                                color = Red400,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        Spacer(Modifier.height(12.dp))

                        // Port row
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Порт:", fontSize = 13.sp, color = Gray500)
                            Spacer(Modifier.width(8.dp))
                            OutlinedTextField(
                                value = portInput,
                                onValueChange = { portInput = it.filter { c -> c.isDigit() }.take(5) },
                                modifier = Modifier.width(100.dp),
                                textStyle = LocalTextStyle.current.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 14.sp
                                ),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                enabled = !isScanning,
                                shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Green400,
                                    unfocusedBorderColor = BorderDark,
                                    focusedContainerColor = Color(0xFF0D1117),
                                    unfocusedContainerColor = Color(0xFF0D1117)
                                )
                            )
                        }

                        Spacer(Modifier.height(16.dp))

                        // Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val ips = IpParser.parseMultiline(ipInput)
                                    if (ips.isEmpty()) {
                                        parseError = "Некорректный ввод IP"
                                        return@Button
                                    }
                                    if (ips.size > 65536) {
                                        parseError = "Максимум 65536 IP"
                                        return@Button
                                    }
                                    val port = portInput.toIntOrNull() ?: DahuaScanner.DEFAULT_PORT
                                    parseError = null
                                    results.clear()
                                    isScanning = true
                                    progress = ScanProgress(ips.size, 0, 0, 0, 0)
                                    val s = DahuaScanner()
                                    scanner = s

                                    scope.launch {
                                        try {
                                            s.scan(
                                                ips = ips,
                                                port = port,
                                                onResult = { r ->
                                                    withContext(Dispatchers.Main) {
                                                        results.add(0, r) // новые сверху
                                                    }
                                                },
                                                onProgress = { p ->
                                                    withContext(Dispatchers.Main) {
                                                        progress = p
                                                    }
                                                }
                                            )
                                        } catch (_: Exception) {
                                        } finally {
                                            withContext(Dispatchers.Main) {
                                                isScanning = false
                                            }
                                        }
                                    }
                                },
                                enabled = !isScanning && ipInput.isNotBlank(),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Green400,
                                    contentColor = Color.Black,
                                    disabledContainerColor = Green400.copy(alpha = 0.3f)
                                )
                            ) {
                                Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Сканировать", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }

                            if (isScanning) {
                                OutlinedButton(
                                    onClick = { scanner?.cancelled = true },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Red400),
                                    border = ButtonDefaults.outlinedButtonBorder(enabled = true).copy(
                                        brush = Brush.linearGradient(listOf(Red400, Red400))
                                    )
                                ) {
                                    Icon(Icons.Default.Close, null, modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Стоп", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // ─── Progress ───
            progress?.let { p ->
                if (p.total > 0) {
                    item {
                        ProgressCard(p, isScanning)
                    }
                }
            }

            // ─── Stats strip ───
            if (results.isNotEmpty()) {
                item {
                    StatsStrip(results)
                }
            }

            // ─── Results ───
            val successResults = results.filter { !it.blocked }
            val blockedResults = results.filter { it.blocked }

            if (successResults.isNotEmpty()) {
                item {
                    Text(
                        "НАЙДЕНО",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Green400,
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                items(successResults) { result ->
                    ResultCard(result, context) { selectedResult = result }
                }
            }

            if (blockedResults.isNotEmpty()) {
                item {
                    Text(
                        "ЗАБЛОКИРОВАНО",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Orange400,
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                items(blockedResults) { result ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Orange400.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🔒", fontSize = 16.sp)
                            }
                            Spacer(Modifier.width(12.dp))
                            Text(
                                result.ip,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 14.sp,
                                color = Orange400
                            )
                        }
                    }
                }
            }
        }
    }

    // ─── Snapshot dialog ───
    selectedResult?.let { r ->
        SnapshotFullDialog(r, context) { selectedResult = null }
    }
}

@Composable
fun ProgressCard(p: ScanProgress, scanning: Boolean) {
    val pct = if (p.total > 0) (p.checked.toFloat() / p.total) else 0f
    val speed = if (p.elapsedMs > 200) (p.checked * 1000.0 / p.elapsedMs) else 0.0
    val eta = if (speed > 0.01 && p.checked < p.total) {
        ((p.total - p.checked) / speed).toInt()
    } else 0

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (scanning) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = Green400
                        )
                        Spacer(Modifier.width(8.dp))
                    }
                    Text(
                        if (p.finished) "Завершено" else if (p.cancelled) "Отменено" else "Сканирование",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = when {
                            p.finished -> Green400
                            p.cancelled -> Orange400
                            else -> Color.White
                        }
                    )
                }
                Text(
                    "${(pct * 100).toInt()}%",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Green400
                )
            }

            Spacer(Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { pct },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = Green400,
                trackColor = BorderDark
            )

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                StatMini("Проверено", "${p.checked}/${p.total}", Cyan400)
                StatMini("Найдено", "${p.successful}", Green400)
                StatMini("Блокировка", "${p.blocked}", Orange400)
                if (speed > 0.01) {
                    StatMini("Скорость", "${"%.1f".format(speed)}/с", Color.White)
                }
                if (scanning && eta > 0) {
                    StatMini("ETA", "%d:%02d".format(eta / 60, eta % 60), Yellow400)
                }
            }
        }
    }
}

@Composable
fun StatMini(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color)
        Text(label, fontSize = 10.sp, color = Gray500)
    }
}

@Composable
fun StatsStrip(results: List<ScanResult>) {
    val withPhoto = results.count { it.snapshot != null && it.snapshot.size > 100 }
    val withoutPhoto = results.count { !it.blocked && (it.snapshot == null || it.snapshot.size <= 100) }
    val blocked = results.count { it.blocked }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatChip("📸 $withPhoto фото", Green400, Modifier.weight(1f))
        StatChip("🔑 $withoutPhoto без фото", Cyan400, Modifier.weight(1f))
        if (blocked > 0) {
            StatChip("🔒 $blocked блок", Orange400, Modifier.weight(1f))
        }
    }
}

@Composable
fun StatChip(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.1f))
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = color)
    }
}

@Composable
fun ResultCard(result: ScanResult, context: Context, onClick: () -> Unit) {
    val hasPhoto = result.snapshot != null && result.snapshot.size > 100
    val timeFmt = remember(result.timestampMs) {
        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(result.timestampMs))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(modifier = Modifier.padding(12.dp)) {
            // Thumbnail or icon
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (hasPhoto) Color.Transparent else SurfaceDark2),
                contentAlignment = Alignment.Center
            ) {
                if (hasPhoto) {
                    val bmp = remember(result.snapshot) {
                        BitmapFactory.decodeByteArray(result.snapshot!!, 0, result.snapshot.size)
                    }
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                } else {
                    Text("📷", fontSize = 28.sp)
                }
            }

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                // IP
                Text(
                    result.ip,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 15.sp,
                    color = Color.White
                )

                Spacer(Modifier.height(2.dp))

                // Creds
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Green400.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            "${result.login}:${result.password}",
                            fontSize = 12.sp,
                            color = Green400,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(Modifier.width(6.dp))

                    // Copy button
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(SurfaceDark2)
                            .clickable {
                                val clip = ClipboardManager::class.java
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(
                                    ClipData.newPlainText(
                                        "dahua",
                                        "${result.ip}:${result.port} ${result.login}:${result.password}"
                                    )
                                )
                                Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Share,
                            null,
                            tint = Gray500,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                Spacer(Modifier.height(4.dp))

                // Model + channels + time
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (result.model.isNotEmpty() && result.model != "unknown") {
                        Text(
                            result.model,
                            fontSize = 11.sp,
                            color = Cyan400,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Spacer(Modifier.width(4.dp))
                    }
                    if (result.channels > 0) {
                        Text(
                            "${result.channels}ch",
                            fontSize = 11.sp,
                            color = Gray500
                        )
                        Spacer(Modifier.width(4.dp))
                    }
                    Text(timeFmt, fontSize = 11.sp, color = Gray500)
                }

                if (!hasPhoto) {
                    Text(
                        "без снапшота",
                        fontSize = 11.sp,
                        color = Gray500.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}

@Composable
fun SnapshotFullDialog(result: ScanResult, context: Context, onDismiss: () -> Unit) {
    val hasPhoto = result.snapshot != null && result.snapshot.size > 100

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        shape = RoundedCornerShape(20.dp),
        confirmButton = {
            Row {
                TextButton(onClick = {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val info = buildString {
                        appendLine("IP: ${result.ip}:${result.port}")
                        appendLine("Login: ${result.login}")
                        appendLine("Password: ${result.password}")
                        if (result.model.isNotEmpty()) appendLine("Model: ${result.model}")
                        appendLine("Channels: ${result.channels}")
                    }
                    cm.setPrimaryClip(ClipData.newPlainText("dahua", info))
                    Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                }) {
                    Text("Копировать", color = Cyan400)
                }
                TextButton(onClick = onDismiss) {
                    Text("Закрыть", color = Gray500)
                }
            }
        },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Green400)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    result.ip,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        },
        text = {
            Column {
                // Info grid
                InfoRow("Порт", "${result.port}")
                InfoRow("Логин", result.login)
                InfoRow("Пароль", result.password)
                if (result.model.isNotEmpty() && result.model != "unknown") {
                    InfoRow("Модель", result.model)
                }
                InfoRow("Каналов", "${result.channels}")

                // Snapshot
                if (hasPhoto) {
                    Spacer(Modifier.height(12.dp))
                    val bmp = remember(result.snapshot) {
                        BitmapFactory.decodeByteArray(result.snapshot!!, 0, result.snapshot.size)
                    }
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.FillWidth
                        )
                    }
                }
            }
        }
    )
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 13.sp, color = Gray500)
        Text(
            value,
            fontSize = 13.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            color = Color.White
        )
    }
}
