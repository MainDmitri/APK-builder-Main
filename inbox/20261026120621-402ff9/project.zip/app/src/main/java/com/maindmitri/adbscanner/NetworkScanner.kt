package com.maindmitri.adbscanner

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

object NetworkScanner {

    private const val ADB_PORT = 5555
    private const val TIMEOUT_MS = 400

    /**
     * Detects the local /24 subnet from WiFi, falls back to the user-supplied prefix.
     */
    fun detectSubnet(context: Context): String? {
        return try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val ip = wm.connectionInfo.ipAddress
            if (ip == 0) return null
            val a = ip and 0xff
            val b = (ip shr 8) and 0xff
            val c = (ip shr 16) and 0xff
            "$a.$b.$c"
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Scans [subnet].1 … [subnet].254 concurrently.
     * [onProgress] is called with (current, total) from the IO dispatcher.
     */
    suspend fun scan(
        subnet: String,
        onProgress: suspend (Int, Int) -> Unit = { _, _ -> }
    ): List<DeviceItem> = withContext(Dispatchers.IO) {
        val total = 254
        val jobs = (1..total).map { last ->
            async {
                val ip = "$subnet.$last"
                val open = isPortOpen(ip, ADB_PORT)
                onProgress(last, total)
                if (open) DeviceItem(ip = ip, port = ADB_PORT) else null
            }
        }
        jobs.awaitAll().filterNotNull()
    }

    private fun isPortOpen(host: String, port: Int): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), TIMEOUT_MS)
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
