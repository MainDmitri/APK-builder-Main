package com.maindmitri.adbscanner

data class DeviceItem(
    val ip: String,
    val port: Int = 5555,
    var isConnected: Boolean = false,
    var info: String = "ADB port open"
) {
    val address: String get() = "$ip:$port"
}
