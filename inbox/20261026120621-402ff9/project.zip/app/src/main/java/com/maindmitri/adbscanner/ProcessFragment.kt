package com.maindmitri.adbscanner

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ProcessFragment : Fragment() {

    private lateinit var rvProcesses: RecyclerView
    private lateinit var procAdapter: ProcessAdapter
    private var selectedPid: String? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.fragment_processes, container, false)

        rvProcesses = view.findViewById(R.id.rvProcesses)
        procAdapter = ProcessAdapter { pid, name ->
            selectedPid = pid
            Toast.makeText(requireContext(), "Выбрано: $name (PID $pid)", Toast.LENGTH_SHORT).show()
        }
        rvProcesses.layoutManager = LinearLayoutManager(requireContext())
        rvProcesses.adapter = procAdapter

        view.findViewById<MaterialButton>(R.id.btnRefreshProc).setOnClickListener { loadProcesses() }

        view.findViewById<MaterialButton>(R.id.btnKillProc).setOnClickListener {
            val pid = selectedPid ?: run {
                Toast.makeText(requireContext(), "Выберите процесс", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            // FIX: check connection before kill
            if (!AdbManager.isConnected) {
                Toast.makeText(requireContext(), "Нет подключения", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            runShell("kill -9 $pid") {
                Toast.makeText(requireContext(), "Процесс $pid завершён", Toast.LENGTH_SHORT).show()
                selectedPid = null
                loadProcesses()
            }
        }

        return view
    }

    private fun loadProcesses() {
        if (!AdbManager.isConnected) {
            Toast.makeText(requireContext(), "Нет подключения", Toast.LENGTH_SHORT).show()
            return
        }
        // FIX: lifecycle scope
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            val result = AdbManager.shell("ps -A")
            withContext(Dispatchers.Main) {
                result.onSuccess { output ->
                    val procs = output.lines().drop(1)
                        .filter { it.isNotBlank() }
                        .map { line ->
                            val parts = line.trim().split("\\s+".toRegex())
                            ProcessEntry(
                                pid  = parts.getOrElse(1) { "?" },
                                name = parts.lastOrNull() ?: "?",
                                user = parts.getOrElse(0) { "?" },
                                raw  = line
                            )
                        }
                    procAdapter.submitList(procs)
                }.onFailure {
                    Toast.makeText(requireContext(), "Ошибка: ${it.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // FIX: check connection + lifecycle scope
    private fun runShell(cmd: String, onResult: () -> Unit) {
        if (!AdbManager.isConnected) { return }
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            AdbManager.shell(cmd)
            withContext(Dispatchers.Main) { onResult() }
        }
    }
}

data class ProcessEntry(val pid: String, val name: String, val user: String, val raw: String)

class ProcessAdapter(private val onClick: (String, String) -> Unit) :
    RecyclerView.Adapter<ProcessAdapter.VH>() {

    private var items = listOf<ProcessEntry>()

    fun submitList(list: List<ProcessEntry>) { items = list; notifyDataSetChanged() }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvPid:  TextView = v.findViewById(R.id.tvProcPid)
        val tvName: TextView = v.findViewById(R.id.tvProcName)
        val tvUser: TextView = v.findViewById(R.id.tvProcUser)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_process, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.tvPid.text  = item.pid
        holder.tvName.text = item.name
        holder.tvUser.text = item.user
        holder.itemView.setOnClickListener { onClick(item.pid, item.name) }
    }
}
