package com.maindmitri.adbscanner

import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ScreenshotFragment : Fragment() {

    private lateinit var ivScreenshot: ImageView
    private lateinit var tvStatus: TextView
    private lateinit var btnSave: MaterialButton
    private var lastPngBytes: ByteArray? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.fragment_screenshot, container, false)

        ivScreenshot = view.findViewById(R.id.ivScreenshot)
        tvStatus     = view.findViewById(R.id.tvScreenshotStatus)
        btnSave      = view.findViewById(R.id.btnSaveScreenshot)

        view.findViewById<MaterialButton>(R.id.btnCapture).setOnClickListener { captureScreen() }
        btnSave.setOnClickListener { saveToGallery() }

        return view
    }

    private fun captureScreen() {
        if (!AdbManager.isConnected) {
            tvStatus.text = "! нет подключения"
            return
        }
        tvStatus.text = "Захват экрана..."
        // FIX: lifecycle scope
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            // shellBytes strips \r\n → \n to get clean PNG bytes
            val result = AdbManager.shellBytes("screencap -p")
            withContext(Dispatchers.Main) {
                result.onSuccess { bytes ->
                    lastPngBytes = bytes
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (bmp != null) {
                        ivScreenshot.setImageBitmap(bmp)
                        tvStatus.text = "Снято: ${bmp.width}×${bmp.height}px"
                        btnSave.isEnabled = true
                    } else {
                        tvStatus.text = "! не удалось декодировать PNG (${bytes.size} байт)"
                    }
                }.onFailure { e ->
                    tvStatus.text = "! ошибка: ${e.message}"
                }
            }
        }
    }

    private fun saveToGallery() {
        val bytes = lastPngBytes ?: return
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            try {
                val dir  = File(requireContext().getExternalFilesDir(null), "screenshots").also { it.mkdirs() }
                val file = File(dir, "screen_${System.currentTimeMillis()}.png")
                file.writeBytes(bytes)
                withContext(Dispatchers.Main) {
                    Toast.makeText(requireContext(), "Сохранено: ${file.absolutePath}", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(requireContext(), "Ошибка сохранения: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
