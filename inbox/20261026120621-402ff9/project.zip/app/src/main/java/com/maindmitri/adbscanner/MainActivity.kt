package com.maindmitri.adbscanner

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.google.android.material.textfield.TextInputEditText
import dadb.AdbKeyPair
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var etSubnet: TextInputEditText
    private lateinit var btnScan: MaterialButton
    private lateinit var progressBar: LinearProgressIndicator
    private lateinit var rvDevices: RecyclerView
    private lateinit var tabLayout: TabLayout
    private lateinit var viewPager: ViewPager2

    private lateinit var deviceAdapter: DeviceAdapter
    private lateinit var keyPair: AdbKeyPair

    private val foundDevices = mutableListOf<DeviceItem>()

    private val tabs = listOf(
        "SHELL"    to { ShellFragment()      as Fragment },
        "FILES"    to { FileManagerFragment() as Fragment },
        "APKs"     to { ApkManagerFragment() as Fragment },
        "PROCS"    to { ProcessFragment()     as Fragment },
        "SCREEN"   to { ScreenshotFragment()  as Fragment },
        "АЛИСА"    to { AliceFragment()        as Fragment }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content)) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        // Bind views
        tvStatus    = findViewById(R.id.tvStatus)
        etSubnet    = findViewById(R.id.etSubnet)
        btnScan     = findViewById(R.id.btnScan)
        progressBar = findViewById(R.id.progressBar)
        rvDevices   = findViewById(R.id.rvDevices)
        tabLayout   = findViewById(R.id.tabLayout)
        viewPager   = findViewById(R.id.viewPager)

        // Key pair — generated once, stored in app's private files dir
        keyPair = AdbManager.getOrCreateKeyPair(filesDir)

        // Auto-detect subnet
        val detected = NetworkScanner.detectSubnet(this)
        if (detected != null) etSubnet.setText(detected)

        // Device list adapter
        deviceAdapter = DeviceAdapter(foundDevices) { device -> onConnectClick(device) }
        rvDevices.layoutManager = LinearLayoutManager(this)
        rvDevices.adapter = deviceAdapter

        // Scan button
        btnScan.setOnClickListener { startScan() }

        // ViewPager + Tabs
        viewPager.adapter = object : FragmentStateAdapter(this) {
            override fun getItemCount() = tabs.size
            override fun createFragment(position: Int) = tabs[position].second()
        }
        viewPager.offscreenPageLimit = tabs.size  // keep all fragments alive

        TabLayoutMediator(tabLayout, viewPager) { tab, pos ->
            tab.text = tabs[pos].first
        }.attach()

        setStatus("// READY — tap SCAN")
    }

    // ─── Scan ────────────────────────────────────────────────────────────────

    private fun startScan() {
        val subnet = etSubnet.text?.toString()?.trim()
        if (subnet.isNullOrBlank()) { setStatus("! укажите подсеть"); return }

        btnScan.isEnabled = false
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0
        foundDevices.clear()
        deviceAdapter.notifyDataSetChanged()
        setStatus("SCANNING $subnet.0/24 …")

        lifecycleScope.launch {
            val results = NetworkScanner.scan(subnet) { done, total ->
                val pct = (done * 100) / total
                runOnUiThread { progressBar.progress = pct }
            }

            foundDevices.addAll(results)
            deviceAdapter.notifyDataSetChanged()

            val msg = if (results.isEmpty()) "Устройств не найдено" else "Найдено: ${results.size}"
            setStatus(msg)
            progressBar.visibility = View.GONE
            btnScan.isEnabled = true
        }
    }

    // ─── Connect / Disconnect ────────────────────────────────────────────────

    private fun onConnectClick(device: DeviceItem) {
        if (device.isConnected) disconnectDevice(device) else connectDevice(device)
    }

    private fun connectDevice(device: DeviceItem) {
        setStatus("Подключение к ${device.address} …")
        lifecycleScope.launch {
            val result = AdbManager.connect(device.ip, device.port, keyPair)
            result.onSuccess { info ->
                device.isConnected = true
                device.info = "● $info"
                deviceAdapter.updateItem(device)
                setStatus("Подключено: ${device.address}")
            }.onFailure { err ->
                device.info = "× ${err.message?.take(40)}"
                deviceAdapter.updateItem(device)
                setStatus("Ошибка подключения")
            }
        }
    }

    private fun disconnectDevice(device: DeviceItem) {
        lifecycleScope.launch {
            AdbManager.disconnect()
            device.isConnected = false
            device.info = "ADB port open"
            deviceAdapter.updateItem(device)
            setStatus("Отключено")
        }
    }

    private fun setStatus(msg: String) { tvStatus.text = msg }
}
