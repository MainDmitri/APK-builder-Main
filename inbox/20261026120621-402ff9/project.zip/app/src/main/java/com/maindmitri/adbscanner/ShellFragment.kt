package com.maindmitri.adbscanner

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.ScrollView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ShellFragment : Fragment() {

    private lateinit var tvOutput: TextView
    private lateinit var scrollOutput: ScrollView
    private lateinit var etCommand: TextInputEditText

    private val quickCommands = mapOf(
        R.id.chipModel   to "getprop ro.product.model",
        R.id.chipVersion to "getprop ro.build.version.release",
        R.id.chipUptime  to "uptime",
        R.id.chipCpu     to "cat /proc/cpuinfo | grep 'model name' | head -1",
        R.id.chipMem     to "cat /proc/meminfo | head -5",
        R.id.chipBat     to "dumpsys battery",
        R.id.chipNet     to "netstat -an | head -20",
        R.id.chipPs      to "ps -A | head -20"
    )

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.fragment_shell, container, false)

        tvOutput     = view.findViewById(R.id.tvOutput)
        scrollOutput = view.findViewById(R.id.scrollOutput)
        etCommand    = view.findViewById(R.id.etCommand)

        val btnRun = view.findViewById<MaterialButton>(R.id.btnRun)
        btnRun.setOnClickListener { runCommand() }

        etCommand.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { runCommand(); true } else false
        }

        quickCommands.forEach { (id, cmd) ->
            view.findViewById<Chip>(id)?.setOnClickListener {
                etCommand.setText(cmd)
                runCommand()
            }
        }

        return view
    }

    private fun runCommand() {
        val cmd = etCommand.text?.toString()?.trim() ?: return
        if (cmd.isEmpty()) return
        etCommand.setText("")

        if (!AdbManager.isConnected) {
            append("! нет подключения к устройству\n"); return
        }

        append("$ $cmd\n")
        // FIX: use viewLifecycleOwner.lifecycleScope to avoid leaks on fragment destruction
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            val result = AdbManager.shell(cmd)
            withContext(Dispatchers.Main) {
                result.onSuccess { out ->
                    append(out.trimEnd() + "\n")
                }.onFailure { e ->
                    append("! ошибка: ${e.message}\n")
                }
                append("\n")
            }
        }
    }

    private fun append(text: String) {
        tvOutput.append(text)
        scrollOutput.post { scrollOutput.fullScroll(View.FOCUS_DOWN) }
    }
}
