package com.maindmitri.adbscanner

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DeviceAdapter(
    private val items: MutableList<DeviceItem> = mutableListOf(),
    private val onConnect: (DeviceItem) -> Unit
) : RecyclerView.Adapter<DeviceAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvIp: TextView = view.findViewById(R.id.tvIp)
        val tvInfo: TextView = view.findViewById(R.id.tvInfo)
        val indicator: View = view.findViewById(R.id.viewIndicator)
        val btnConnect: Button = view.findViewById(R.id.btnConnect)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_device, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.tvIp.text = item.address
        holder.tvInfo.text = item.info
        if (item.isConnected) {
            holder.indicator.setBackgroundColor(Color.parseColor("#00E676"))
            holder.btnConnect.text = "DISCONNECT"
            holder.tvInfo.text = "● connected"
        } else {
            holder.indicator.setBackgroundColor(Color.parseColor("#2E7D32"))
            holder.btnConnect.text = "CONNECT"
        }
        holder.btnConnect.setOnClickListener { onConnect(item) }
    }

    override fun getItemCount() = items.size

    fun setItems(newItems: List<DeviceItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    fun updateItem(device: DeviceItem) {
        val idx = items.indexOfFirst { it.address == device.address }
        if (idx >= 0) {
            items[idx] = device
            notifyItemChanged(idx)
        }
    }
}
