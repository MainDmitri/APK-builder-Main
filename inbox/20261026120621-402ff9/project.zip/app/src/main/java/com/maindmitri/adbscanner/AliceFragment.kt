package com.maindmitri.adbscanner

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Яндекс Алиса — вкладка для управления Яндекс Станцией через ADB.
 *
 * Яндекс Станция работает на Android (AOSP-based).
 * Если ADB по Wi-Fi открыт (порт 5555), сканер найдёт устройство,
 * и подключение работает через обычный dadb. Команды — стандартные Android shell.
 *
 * Известные package-имена приложений на Яндекс Станции:
 *   ru.yandex.quasar.app       — основное приложение Алисы
 *   ru.yandex.video            — Кинопоиск
 *   com.google.android.youtube.tv — YouTube TV
 *   com.android.settings       — Настройки
 */
class AliceFragment : Fragment() {

    private lateinit var tvAliceInfo: TextView
    private lateinit var tvAliceLog: TextView

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.fragment_alice, container, false)

        tvAliceInfo = view.findViewById(R.id.tvAliceInfo)
        tvAliceLog  = view.findViewById(R.id.tvAliceLog)

        val etTts = view.findViewById<TextInputEditText>(R.id.etTts)

        // Info button — collect device info
        view.findViewById<MaterialButton>(R.id.btnAliceInfo).setOnClickListener {
            runMultiShell(
                listOf(
                    "getprop ro.product.model",
                    "getprop ro.build.version.release",
                    "getprop ro.build.version.sdk",
                    "getprop ro.serialno",
                    "uptime",
                    "dumpsys battery | grep -E 'level|status|temperature'"
                )
            ) { results ->
                val labels = listOf("Модель", "Android", "SDK", "Serial", "Uptime", "Battery")
                tvAliceInfo.text = labels.zip(results).joinToString("\n") { (l, r) -> "$l: ${r.trim()}" }
            }
        }

        // TTS via Android am broadcast
        view.findViewById<MaterialButton>(R.id.btnSpeak).setOnClickListener {
            val text = etTts.text?.toString()?.trim() ?: return@setOnClickListener
            if (text.isEmpty()) return@setOnClickListener
            val cmd = "am broadcast -a android.intent.action.TTS_SERVICE --es text \"$text\""
            runShell(cmd) { log("TTS: $text") }
            etTts.setText("")
        }

        // Volume controls — standard Android key events
        view.findViewById<MaterialButton>(R.id.btnAliceVolUp).setOnClickListener {
            runShell("input keyevent 24") { log("Volume UP") }
        }
        view.findViewById<MaterialButton>(R.id.btnAliceVolDown).setOnClickListener {
            runShell("input keyevent 25") { log("Volume DOWN") }
        }
        view.findViewById<MaterialButton>(R.id.btnAliceMute).setOnClickListener {
            runShell("input keyevent 164") { log("MUTE toggled") }
        }

        // FIX: requireContext() in AlertDialog
        view.findViewById<MaterialButton>(R.id.btnAliceReboot).setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Перезагрузка")
                .setMessage("Перезагрузить Яндекс Станцию?")
                .setPositiveButton("ДА") { _, _ ->
                    runShell("reboot") { log("Reboot sent") }
                }
                .setNegativeButton("Отмена", null)
                .show()
        }

        // App launchers
        view.findViewById<MaterialButton>(R.id.btnLaunchYoutube).setOnClickListener {
            launchApp("com.google.android.youtube.tv")
        }
        view.findViewById<MaterialButton>(R.id.btnLaunchKinopoisk).setOnClickListener {
            launchApp("ru.yandex.video")
        }
        view.findViewById<MaterialButton>(R.id.btnLaunchAlice).setOnClickListener {
            launchApp("ru.yandex.quasar.app")
        }
        view.findViewById<MaterialButton>(R.id.btnLaunchSettings).setOnClickListener {
            launchApp("com.android.settings")
        }

        return view
    }

    private fun launchApp(pkg: String) {
        val cmd = "monkey -p $pkg -c android.intent.category.LAUNCHER 1"
        runShell(cmd) { log("Запущено: $pkg") }
    }

    // FIX: viewLifecycleOwner.lifecycleScope instead of CoroutineScope(IO)
    private fun runShell(cmd: String, onSuccess: (String) -> Unit) {
        if (!AdbManager.isConnected) { log("! нет подключения"); return }
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            val result = AdbManager.shell(cmd)
            withContext(Dispatchers.Main) {
                result.onSuccess { onSuccess(it) }
                      .onFailure { log("! ${it.message}") }
            }
        }
    }

    private fun runMultiShell(commands: List<String>, onResults: (List<String>) -> Unit) {
        if (!AdbManager.isConnected) { log("! нет подключения"); return }
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            val results = commands.map { cmd -> AdbManager.shell(cmd).getOrElse { "—" } }
            withContext(Dispatchers.Main) { onResults(results) }
        }
    }

    private fun log(msg: String) {
        tvAliceLog.append("> $msg\n")
    }
}
