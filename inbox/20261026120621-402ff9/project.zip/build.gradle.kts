// Top-level build file — versions managed by the engine's Gradle 9.3.1
// Note: org.jetbrains.kotlin.android is NOT needed with AGP 9.0+ (Kotlin support is built in)
plugins {
    id("com.android.application") version "9.1.0" apply false
}
