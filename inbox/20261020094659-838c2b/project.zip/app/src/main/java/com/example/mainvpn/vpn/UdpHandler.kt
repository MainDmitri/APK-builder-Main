package com.example.mainvpn.vpn

import android.os.SystemClock
import com.example.mainvpn.net.DnsMessage
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

class TrafficCounters {
    val udpBlocked = AtomicLong()
    val dnsViaTor = AtomicLong()
    val dnsDirect = AtomicLong()
    val dnsCached = AtomicLong()
    val aaaaFiltered = AtomicLong()
}

/**
 * UDP из туннеля. Tor передаёт только TCP, поэтому:
 * • DNS (порт 53) перехватывается: при защите от утечек — в DNSPort Tor, иначе — напрямую на DNS провайдера;
 *   успешные ответы кэшируются по TTL, чтобы повторные запросы не ждали круг через цепочку Tor;
 *   запросы AAAA получают пустой ответ: приложения сразу идут по IPv4, которое поддерживают все выходные узлы,
 *   и не открывают через Tor по два соединения (IPv6 + IPv4) на каждый сайт;
 * • весь остальной UDP (QUIC, STUN/WebRTC и т. п.) отбрасывается, чтобы он не шёл мимо Tor; в ответ отправляется
 *   ICMP «порт недоступен», и браузеры сразу переходят с QUIC на TCP, не дожидаясь тайм-аута.
 */
class UdpHandler(
    private val tun: TunWriter,
    private val dnsPort: () -> Int,
    private val dnsProtection: () -> Boolean,
    private val systemDns: () -> List<InetAddress>,
    private val counters: TrafficCounters
) {
    private class CachedAnswer(val response: ByteArray, val expiresAt: Long)

    private val loopback: InetAddress = InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1))
    private val cache = ConcurrentHashMap<String, CachedAnswer>()

    private val pool = ThreadPoolExecutor(
        4, 32, 30, TimeUnit.SECONDS, LinkedBlockingQueue(512),
        { r -> Thread(null, r, "dns", 128 * 1024).apply { isDaemon = true } },
        ThreadPoolExecutor.DiscardPolicy()
    )

    fun handle(p: IpPacket.Parsed, buf: ByteArray) {
        val off = p.payloadOffset
        if (p.payloadEnd - off < 8) return
        val srcPort = IpPacket.u16(buf, off)
        val dstPort = IpPacket.u16(buf, off + 2)
        val udpLen = IpPacket.u16(buf, off + 4)
        val payloadStart = off + 8
        val payloadLen = minOf(udpLen - 8, p.payloadEnd - payloadStart)
        if (payloadLen <= 0) return
        if (dstPort != 53) {
            counters.udpBlocked.incrementAndGet()
            tun.write(IpPacket.buildPortUnreachable(buf, p.payloadEnd, p.dst, p.src))
            return
        }
        val query = buf.copyOfRange(payloadStart, payloadStart + payloadLen)
        val questionEnd = DnsMessage.questionEnd(query, query.size)
        if (questionEnd > 0) {
            if (DnsMessage.questionType(query, questionEnd) == DnsMessage.TYPE_AAAA) {
                counters.aaaaFiltered.incrementAndGet()
                reply(p.dst, p.src, srcPort, DnsMessage.emptyResponse(query, questionEnd))
                return
            }
            val key = DnsMessage.cacheKey(query, questionEnd)
            val hit = cache[key]
            if (hit != null) {
                if (hit.expiresAt > SystemClock.elapsedRealtime()) {
                    counters.dnsCached.incrementAndGet()
                    val response = hit.response.copyOf()
                    response[0] = query[0]
                    response[1] = query[1]
                    reply(p.dst, p.src, srcPort, response)
                    return
                }
                cache.remove(key, hit)
            }
            pool.execute { resolve(p.src, srcPort, p.dst, query, key) }
        } else {
            pool.execute { resolve(p.src, srcPort, p.dst, query, null) }
        }
    }

    /** Сбрасывает кэш: после смены цепочки или страны выхода CDN могут отдавать другие адреса. */
    fun clearCache() {
        cache.clear()
    }

    private fun reply(server: ByteArray, client: ByteArray, clientPort: Int, response: ByteArray) {
        tun.write(IpPacket.buildUdp(server, client, 53, clientPort, response, 0, response.size))
    }

    private fun resolve(client: ByteArray, clientPort: Int, server: ByteArray, query: ByteArray, key: String?) {
        val target = if (dnsProtection()) {
            val port = dnsPort()
            if (port <= 0) return
            counters.dnsViaTor.incrementAndGet()
            InetSocketAddress(loopback, port)
        } else {
            val address = if (server.contentEquals(PacketEngine.VIRTUAL_DNS)) {
                systemDns().firstOrNull() ?: return
            } else {
                InetAddress.getByAddress(server)
            }
            counters.dnsDirect.incrementAndGet()
            InetSocketAddress(address, 53)
        }
        try {
            DatagramSocket().use { socket ->
                socket.soTimeout = 10_000
                socket.send(DatagramPacket(query, query.size, target))
                val resp = ByteArray(4096)
                val packet = DatagramPacket(resp, resp.size)
                socket.receive(packet)
                tun.write(IpPacket.buildUdp(server, client, 53, clientPort, resp, 0, packet.length))
                if (key != null) remember(key, resp, packet.length)
            }
        } catch (e: IOException) {
            // Нет ответа резолвера — приложение повторит запрос само.
        }
    }

    private fun remember(key: String, resp: ByteArray, length: Int) {
        val ttl = DnsMessage.minAnswerTtl(resp, length)
        if (ttl < 0) return
        if (cache.size >= MAX_ENTRIES) {
            val now = SystemClock.elapsedRealtime()
            cache.entries.removeIf { it.value.expiresAt <= now }
            if (cache.size >= MAX_ENTRIES) cache.clear()
        }
        val lifetimeSec = ttl.coerceIn(MIN_TTL_SEC, MAX_TTL_SEC)
        cache[key] = CachedAnswer(resp.copyOf(length), SystemClock.elapsedRealtime() + lifetimeSec * 1000L)
    }

    fun shutdown() {
        pool.shutdownNow()
        cache.clear()
    }

    private companion object {
        const val MAX_ENTRIES = 2048
        const val MIN_TTL_SEC = 30
        const val MAX_TTL_SEC = 600
    }
}
