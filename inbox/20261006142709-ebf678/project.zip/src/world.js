import * as THREE from 'three';

export const GOAL_HEIGHT = 1000;
export const CHECKPOINT_STEP = 100;
export const PLAYER_RADIUS = 0.36;
export const PLAYER_HEIGHT = 1.4;
export const FALL_DEPTH = 13;
export const JUMP_BUFFER = 0.13;
export const PHYS = { gravity: 28, jumpVel: 11, springVel: 17.5, maxFall: 42, speed: 6.4 };

const COYOTE = 0.11;
const EDGE = 0.15;
const STEP_ASSIST = 0.45;
const BLINK_T = 4.2;

export const ZONES = [
  { from: 0, name: 'Зелёные луга' },
  { from: 150, name: 'Облачный путь' },
  { from: 350, name: 'Золотой закат' },
  { from: 550, name: 'Стратосфера' },
  { from: 750, name: 'Звёздная ночь' },
  { from: 900, name: 'Космос' },
];

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const lerp = (a, b, t) => a + (b - a) * t;
const smooth = (a, b, v) => {
  const t = clamp((v - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

export function zoneIndexAt(y) {
  let k = 0;
  for (let i = 0; i < ZONES.length; i++) if (y >= ZONES[i].from) k = i;
  return k;
}

/* ---------- небо и ветер ---------- */

const SKY_STOPS = [
  [0, 0x8fd3ff], [150, 0x68b6f3], [300, 0xbcd6ee], [400, 0xffc596], [520, 0xf08a6e],
  [620, 0x9a5aa0], [740, 0x35378c], [850, 0x14164a], [930, 0x060720], [1000, 0x010108],
].map(([y, c]) => ({ y, color: new THREE.Color(c) }));

export function skyColorAt(y, out) {
  if (y <= SKY_STOPS[0].y) return out.copy(SKY_STOPS[0].color);
  for (let i = 1; i < SKY_STOPS.length; i++) {
    const b = SKY_STOPS[i];
    if (y <= b.y) {
      const a = SKY_STOPS[i - 1];
      return out.copy(a.color).lerp(b.color, (y - a.y) / (b.y - a.y));
    }
  }
  return out.copy(SKY_STOPS[SKY_STOPS.length - 1].color);
}

export const WIND = { x: 0, z: 0, s: 0 };
export function windAt(y, t) {
  const k = clamp((y - 550) / 450, 0, 1);
  if (k <= 0) {
    WIND.x = 0; WIND.z = 0; WIND.s = 0;
    return WIND;
  }
  const gust = 0.55 + 0.45 * Math.sin(t * 0.7 + y * 0.02);
  const ang = t * 0.11 + y * 0.013;
  const m = k * 3.4 * gust;
  WIND.x = Math.cos(ang) * m;
  WIND.z = Math.sin(ang) * m;
  WIND.s = k * gust;
  return WIND;
}

/* ---------- генерация уровня ---------- */

function mulberry32(a) {
  return function () {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function airReach(vJ, dy) {
  const disc = vJ * vJ - 2 * PHYS.gravity * dy;
  if (disc <= 0) return 0;
  return PHYS.speed * ((vJ + Math.sqrt(disc)) / PHYS.gravity);
}

function rectGap(ax, az, ahw, ahd, bx, bz, bhw, bhd) {
  const gx = Math.abs(ax - bx) - (ahw + bhw);
  const gz = Math.abs(az - bz) - (ahd + bhd);
  if (gx <= 0 && gz <= 0) return 0;
  return Math.hypot(Math.max(gx, 0), Math.max(gz, 0));
}

function pickType(y, diff, prev, hazardRun, rnd) {
  const hazardOk = hazardRun < (y < 400 ? 1 : 2);
  const w = [];
  if (hazardOk) {
    if (y > 80) w.push(['moving', 0.12 + 0.06 * diff]);
    if (y > 150) w.push(['crumble', 0.1 + 0.1 * diff]);
    if (y > 500) w.push(['blink', 0.1 + 0.08 * diff]);
  }
  if (y > 40 && prev.type !== 'spring') w.push(['spring', 0.07]);
  if (y > 300) w.push(['ice', 0.1 + 0.05 * diff]);
  const roll = rnd();
  let acc = 0;
  for (const [t, v] of w) {
    acc += v;
    if (roll <= acc) return t;
  }
  return 'normal';
}

function movingCollides(m, o, amp) {
  if (Math.abs(o.y - m.y) > 2.6) return false;
  for (const sg of [-1, 1]) {
    const mx = m.x + m.lx * amp * sg;
    const mz = m.z + m.lz * amp * sg;
    if (rectGap(mx, mz, m.w / 2, m.d / 2, o.x, o.z, o.w / 2, o.d / 2) < 0.3) return true;
  }
  return false;
}

function fixMoving(specs) {
  for (let k = 1; k < specs.length; k++) {
    const m = specs[k];
    if (m.type !== 'moving') continue;
    let amp = m.amp;
    let bad = false;
    for (const o of [specs[k - 2], specs[k - 1], specs[k + 1], specs[k + 2]]) {
      if (!o) continue;
      while (amp > 0.7 && movingCollides(m, o, amp)) amp -= 0.2;
      if (movingCollides(m, o, amp)) { bad = true; break; }
    }
    if (bad) m.type = 'normal';
    else m.amp = amp;
  }
}

export function generateLevel(seed) {
  const rnd = mulberry32(seed);
  const specs = [{ type: 'start', x: 0, z: 0, y: 0, w: 12, d: 12, h: 1.6 }];
  let prev = specs[0];
  let nextCp = CHECKPOINT_STEP;
  let hazardRun = 0;
  let afterSpring = false;

  for (let guard = 0; guard < 3000; guard++) {
    const i = specs.length;
    const y0 = prev.y;
    const diff = clamp(y0 / GOAL_HEIGHT, 0, 1);
    const vJ = afterSpring ? PHYS.springVel : PHYS.jumpVel;
    let dy = afterSpring ? lerp(2.6, 4.0, rnd()) : lerp(1.0, 1.75, rnd());
    let type = 'normal';
    let top = y0 + dy;
    if (y0 + dy >= GOAL_HEIGHT - 0.01) {
      type = 'finish'; top = GOAL_HEIGHT; dy = GOAL_HEIGHT - y0;
    } else if (y0 + dy >= nextCp) {
      type = 'checkpoint'; top = nextCp; dy = nextCp - y0;
    } else if (i > 2 && !afterSpring && prev.type !== 'checkpoint') {
      type = pickType(y0, diff, prev, hazardRun, rnd);
    }

    const scale = lerp(1, 0.62, Math.pow(diff, 0.9));
    let w = lerp(2.6, 4.2, rnd()) * scale;
    let d = lerp(2.6, 4.2, rnd()) * scale;
    const minSize = type === 'moving' || type === 'crumble' ? 3.0 : type === 'ice' ? 3.4 : afterSpring ? 3.2 : type === 'blink' ? 2.4 : 1.9;
    w = Math.max(w, minSize);
    d = Math.max(d, minSize);
    let h = 0.8;
    if (type === 'spring') { w = d = Math.max(2.4, Math.min(w, d)); }
    if (type === 'checkpoint') { w = d = 5.5; h = 1.0; }
    if (type === 'finish') { w = d = 8; h = 1.4; }
    if (type === 'moving') h = 0.7;

    const factor = lerp(0.4, 0.8, Math.pow(diff, 0.85));
    let maxGap = airReach(vJ, dy) * factor;
    if (type === 'checkpoint' || type === 'finish') maxGap *= 0.8;
    if (afterSpring) maxGap -= prev.w / 2;
    const target = Math.max(0.9, maxGap * lerp(0.62, 1, rnd()));

    let x;
    let z;
    if (i === 1) {
      x = prev.w / 2 + 1.3 + w / 2;
      z = 0;
    } else {
      const R = 8.2 + 2.4 * Math.sin(i * 0.087 + 0.6) + 1.3 * Math.sin(i * 0.23 + 2.1);
      const theta = Math.atan2(prev.z, prev.x);
      let lo = 0.02;
      let hi = 1.5;
      for (let k = 0; k < 22; k++) {
        const mid = (lo + hi) / 2;
        const px = Math.cos(theta + mid) * R;
        const pz = Math.sin(theta + mid) * R;
        const g = rectGap(prev.x, prev.z, prev.w / 2, prev.d / 2, px, pz, w / 2, d / 2);
        if (g < target) lo = mid; else hi = mid;
      }
      x = Math.cos(theta + lo) * R;
      z = Math.sin(theta + lo) * R;
    }

    const spec = { type, x, z, y: top, w, d, h };
    if (type === 'moving') {
      const dx = x - prev.x;
      const dz = z - prev.z;
      const len = Math.hypot(dx, dz) || 1;
      spec.lx = -dz / len;
      spec.lz = dx / len;
      spec.amp = lerp(1.8, 2.8, rnd());
      spec.period = lerp(4.2, 6.0, rnd());
      spec.phase = rnd() * Math.PI * 2;
    }
    if (type === 'blink') spec.phase = rnd() * BLINK_T;
    specs.push(spec);

    hazardRun = type === 'moving' || type === 'crumble' || type === 'blink' ? hazardRun + 1 : 0;
    afterSpring = type === 'spring';
    if (type === 'checkpoint') nextCp += CHECKPOINT_STEP;
    prev = spec;
    if (type === 'finish') break;
  }
  fixMoving(specs);
  return specs;
}

/* ---------- материалы и геометрия ---------- */

function makeBoxGeo() {
  const g = new THREE.BoxGeometry(1, 1, 1);
  const n = g.attributes.normal;
  const col = new Float32Array(n.count * 3);
  for (let i = 0; i < n.count; i++) {
    const ny = n.getY(i);
    const v = ny > 0.5 ? 1 : ny < -0.5 ? 0.42 : 0.7;
    col[i * 3] = v; col[i * 3 + 1] = v; col[i * 3 + 2] = v;
  }
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  return g;
}

function makeMat(color, extra) {
  const c = new THREE.Color(color);
  return new THREE.MeshStandardMaterial({
    color: c,
    emissive: c.clone().multiplyScalar(0.16),
    roughness: 0.8,
    metalness: 0.04,
    vertexColors: true,
    ...(extra || {}),
  });
}

const TYPE_COLORS = {
  start: 0x7cb342, moving: 0xffa726, crumble: 0xb8865a, spring: 0x4caf50,
  ice: 0x9fe3ff, blink: 0xb36bd1, checkpoint: 0xffd54f, finish: 0xffd700,
};
const NORMAL_BY_ZONE = [0xc4a77d, 0x7f9bc2, 0x6a7fb5, 0xa7b6e8, 0x8ea0d9, 0xb8c4ee];

function makeLabel(text, color) {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 96;
  const g = c.getContext('2d');
  let size = 56;
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.font = `800 ${size}px system-ui, -apple-system, Roboto, sans-serif`;
  while (size > 20 && g.measureText(text).width > 228) {
    size -= 2;
    g.font = `800 ${size}px system-ui, -apple-system, Roboto, sans-serif`;
  }
  g.lineWidth = 10;
  g.lineJoin = 'round';
  g.strokeStyle = 'rgba(10,25,60,0.85)';
  g.strokeText(text, 128, 50);
  g.fillStyle = color || '#ffffff';
  g.fillText(text, 128, 50);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false }));
  sp.scale.set(2.8, 1.05, 1);
  return sp;
}

/* ---------- частицы ---------- */

function createParticles(scene, max) {
  const pos = new Float32Array(max * 3);
  const col = new Float32Array(max * 3);
  const base = new Float32Array(max * 3);
  const vel = new Float32Array(max * 3);
  const life = new Float32Array(max);
  const maxLife = new Float32Array(max);
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const mat = new THREE.PointsMaterial({
    size: 0.3, vertexColors: true, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
  });
  const pts = new THREE.Points(geo, mat);
  pts.frustumCulled = false;
  scene.add(pts);
  const tmp = new THREE.Color();
  let head = 0;
  let alive = 0;
  return {
    emit(x, y, z, count, color, speed, up) {
      tmp.set(color);
      for (let k = 0; k < count; k++) {
        const i = head;
        head = (head + 1) % max;
        const a = Math.random() * Math.PI * 2;
        const r = Math.random();
        pos[i * 3] = x; pos[i * 3 + 1] = y; pos[i * 3 + 2] = z;
        vel[i * 3] = Math.cos(a) * speed * r;
        vel[i * 3 + 1] = (up || 1) * (0.4 + Math.random());
        vel[i * 3 + 2] = Math.sin(a) * speed * r;
        base[i * 3] = tmp.r; base[i * 3 + 1] = tmp.g; base[i * 3 + 2] = tmp.b;
        life[i] = maxLife[i] = 0.45 + Math.random() * 0.4;
      }
      alive = max;
    },
    update(dt) {
      if (alive === 0) return;
      let any = 0;
      for (let i = 0; i < max; i++) {
        if (life[i] <= 0) continue;
        life[i] -= dt;
        if (life[i] <= 0) {
          col[i * 3] = 0; col[i * 3 + 1] = 0; col[i * 3 + 2] = 0;
          continue;
        }
        any++;
        vel[i * 3 + 1] -= 9 * dt;
        pos[i * 3] += vel[i * 3] * dt;
        pos[i * 3 + 1] += vel[i * 3 + 1] * dt;
        pos[i * 3 + 2] += vel[i * 3 + 2] * dt;
        const f = life[i] / maxLife[i];
        col[i * 3] = base[i * 3] * f; col[i * 3 + 1] = base[i * 3 + 1] * f; col[i * 3 + 2] = base[i * 3 + 2] * f;
      }
      geo.attributes.position.needsUpdate = true;
      geo.attributes.color.needsUpdate = true;
      if (any === 0) alive = 0;
    },
  };
}

/* ---------- мир ---------- */

export function createWorld(scene) {
  const specs = generateLevel(20260607);
  const bg = new THREE.Color(0x8fd3ff);
  scene.background = bg;
  scene.fog = new THREE.Fog(0x8fd3ff, 60, 340);

  const hemi = new THREE.HemisphereLight(0xffffff, 0x8a96a8, 2.2);
  scene.add(hemi);
  const sunLight = new THREE.DirectionalLight(0xffffff, 2.4);
  scene.add(sunLight);
  scene.add(sunLight.target);

  const boxGeo = makeBoxGeo();
  const mats = {};
  for (const k of Object.keys(TYPE_COLORS)) mats[k] = makeMat(TYPE_COLORS[k]);
  mats.finish.emissive = new THREE.Color(0x553f00);
  mats.checkpoint.emissive = new THREE.Color(0x4d3d00);
  const normalMats = NORMAL_BY_ZONE.map((c) => makeMat(c));
  const padGeo = new THREE.CylinderGeometry(0.75, 0.85, 0.22, 16);
  const padMat = new THREE.MeshStandardMaterial({ color: 0xffeb3b, emissive: 0x665c00, roughness: 0.5 });
  const poleGeo = new THREE.CylinderGeometry(0.06, 0.06, 2.2, 6);
  const poleMat = new THREE.MeshStandardMaterial({ color: 0xeceff1, roughness: 0.6 });
  const flagGeo = new THREE.BoxGeometry(0.9, 0.5, 0.05);

  const platformsRoot = new THREE.Group();
  scene.add(platformsRoot);

  const platforms = [];
  const dynamic = [];
  const cpIndex = [0];
  const flags = [];
  let finishStar = null;

  specs.forEach((s, id) => {
    const pl = {
      id, type: s.type, x: s.x, z: s.z, baseX: s.x, baseZ: s.z, y: s.y, w: s.w, d: s.d, h: s.h,
      hw: s.w / 2, hd: s.d / 2, solid: true, hidden: false, dx: 0, dz: 0, vx: 0, vz: 0,
      state: 'idle', timer: 0, fallY: 0, fallV: 0, squash: 0, cp: 0,
      lx: s.lx || 0, lz: s.lz || 0, amp: s.amp || 0, omega: s.period ? (Math.PI * 2) / s.period : 0,
      phase: s.phase || 0, group: null, body: null, deco: null, mat: null,
    };
    if (pl.type === 'moving') {
      const a = Math.sin(pl.phase);
      pl.x = pl.baseX + pl.lx * pl.amp * a;
      pl.z = pl.baseZ + pl.lz * pl.amp * a;
    }
    let mat = pl.type === 'normal' ? normalMats[zoneIndexAt(pl.y)] : mats[pl.type];
    if (pl.type === 'blink') {
      mat = mats.blink.clone();
      mat.transparent = true;
      pl.mat = mat;
    }
    const group = new THREE.Group();
    group.position.set(pl.x, pl.y, pl.z);
    const body = new THREE.Mesh(boxGeo, mat);
    body.scale.set(pl.w, pl.h, pl.d);
    body.position.y = -pl.h / 2;
    group.add(body);
    pl.group = group;
    pl.body = body;

    if (pl.type === 'spring') {
      const pad = new THREE.Mesh(padGeo, padMat);
      pad.position.y = 0.11;
      group.add(pad);
      pl.deco = pad;
    }
    if (pl.type === 'start') {
      const lb = makeLabel('СТАРТ', '#ffffff');
      lb.position.set(0, 3.2, -4);
      group.add(lb);
    }
    if (pl.type === 'checkpoint') {
      pl.cp = cpIndex.length;
      cpIndex.push(id);
      const pole = new THREE.Mesh(poleGeo, poleMat);
      pole.position.set(pl.hw - 0.6, 1.1, pl.hd - 0.6);
      group.add(pole);
      const flagMat = new THREE.MeshStandardMaterial({ color: 0xe53935, emissive: 0x330a09, roughness: 0.7 });
      const flag = new THREE.Mesh(flagGeo, flagMat);
      flag.position.set(pl.hw - 0.6 + 0.45, 1.9, pl.hd - 0.6);
      group.add(flag);
      flags.push({ mat: flagMat, k: pl.cp });
      const lb = makeLabel(`${pl.cp * CHECKPOINT_STEP} м`, '#ffe082');
      lb.position.set(0, 3.4, 0);
      group.add(lb);
    }
    if (pl.type === 'finish') {
      const beam = new THREE.Mesh(
        new THREE.CylinderGeometry(1.3, 1.3, 70, 14, 1, true),
        new THREE.MeshBasicMaterial({
          color: 0xfff59d, transparent: true, opacity: 0.22, side: THREE.DoubleSide,
          depthWrite: false, blending: THREE.AdditiveBlending, fog: false,
        }),
      );
      beam.position.y = 35;
      group.add(beam);
      finishStar = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.9, 0),
        new THREE.MeshBasicMaterial({ color: 0xffd54f }),
      );
      finishStar.position.y = 3.2;
      group.add(finishStar);
      const lb = makeLabel('ВЕРШИНА 1000 м', '#fff59d');
      lb.position.set(0, 5.4, 0);
      lb.scale.set(4.6, 1.7, 1);
      group.add(lb);
    }
    platformsRoot.add(group);
    platforms.push(pl);
    if (pl.type === 'moving' || pl.type === 'crumble' || pl.type === 'blink' || pl.type === 'spring') dynamic.push(pl);
  });

  const tops = new Float64Array(platforms.map((p) => p.y));
  const range = { lo: 0, hi: 0 };
  function lowerBound(v) {
    let lo = 0;
    let hi = tops.length;
    while (lo < hi) {
      const m = (lo + hi) >> 1;
      if (tops[m] < v) lo = m + 1; else hi = m;
    }
    return lo;
  }
  function upperBound(v) {
    let lo = 0;
    let hi = tops.length;
    while (lo < hi) {
      const m = (lo + hi) >> 1;
      if (tops[m] <= v) lo = m + 1; else hi = m;
    }
    return lo;
  }
  function queryRange(y0, y1) {
    range.lo = lowerBound(y0);
    range.hi = upperBound(y1);
    return range;
  }

  /* звёзды */
  const rnd = mulberry32(777);
  const starGeo = new THREE.OctahedronGeometry(0.36, 0);
  const starMat = new THREE.MeshBasicMaterial({ color: 0xffd54f });
  const stars = [];
  const starsRoot = new THREE.Group();
  scene.add(starsRoot);
  for (let i = 1; i < platforms.length - 1; i++) {
    const a = platforms[i];
    const b = platforms[i + 1];
    if (a.type === 'checkpoint' || a.type === 'finish') continue;
    const roll = rnd();
    const mx = (a.baseX + b.baseX) / 2;
    const mz = (a.baseZ + b.baseZ) / 2;
    const my = lerp(a.y, b.y, 0.4);
    let pos = null;
    if (roll < 0.2) {
      pos = [mx, my + 1.7, mz];
    } else if (roll < 0.29 && a.type !== 'moving') {
      pos = [a.baseX, a.y + 1.0, a.baseZ];
    } else if (roll < 0.36) {
      const dx = b.baseX - a.baseX;
      const dz = b.baseZ - a.baseZ;
      const len = Math.hypot(dx, dz) || 1;
      const side = rnd() < 0.5 ? -1 : 1;
      pos = [mx - (dz / len) * 2.6 * side, my + 2.0, mz + (dx / len) * 2.6 * side];
    }
    if (!pos) continue;
    const mesh = new THREE.Mesh(starGeo, starMat);
    mesh.position.set(pos[0], pos[1], pos[2]);
    starsRoot.add(mesh);
    stars.push({ id: stars.length, x: pos[0], y: pos[1], z: pos[2], mesh, taken: false });
  }

  /* окружение */
  const env = new THREE.Group();
  scene.add(env);
  const ground = new THREE.Mesh(
    new THREE.CircleGeometry(900, 48),
    new THREE.MeshStandardMaterial({ color: 0x5fa05a, roughness: 1, emissive: 0x0e220e }),
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -40;
  scene.add(ground);

  const coneGeo = new THREE.ConeGeometry(1, 1, 7, 1);
  const mtMat = new THREE.MeshStandardMaterial({ color: 0x6f8f7a, roughness: 1, flatShading: true, emissive: 0x101c14 });
  const rndEnv = mulberry32(4242);
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * Math.PI * 2 + rndEnv() * 0.3;
    const r = 190 + rndEnv() * 150;
    const hgt = 60 + rndEnv() * 110;
    const rad = 35 + rndEnv() * 45;
    const m = new THREE.Mesh(coneGeo, mtMat);
    m.scale.set(rad, hgt, rad);
    m.position.set(Math.cos(a) * r, -40 + hgt / 2, Math.sin(a) * r);
    env.add(m);
  }

  const cloudGeo = new THREE.IcosahedronGeometry(1, 1);
  const cloudMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const cloudCount = 165;
  const clouds = new THREE.InstancedMesh(cloudGeo, cloudMat, cloudCount);
  const mtx = new THREE.Matrix4();
  const qt = new THREE.Quaternion();
  const sc = new THREE.Vector3();
  const ps = new THREE.Vector3();
  for (let c = 0; c < cloudCount / 3; c++) {
    const a = rndEnv() * Math.PI * 2;
    const r = 52 + rndEnv() * 140;
    const y = -5 + rndEnv() * 790;
    const s = 5 + rndEnv() * 9;
    for (let k = 0; k < 3; k++) {
      const ox = (rndEnv() - 0.5) * s * 1.8;
      const oz = (rndEnv() - 0.5) * s * 1.2;
      const ss = s * (0.6 + rndEnv() * 0.5);
      ps.set(Math.cos(a) * r + ox, y + (rndEnv() - 0.5) * 2, Math.sin(a) * r + oz);
      sc.set(ss * 1.6, ss * 0.5, ss);
      mtx.compose(ps, qt, sc);
      clouds.setMatrixAt(c * 3 + k, mtx);
    }
  }
  clouds.instanceMatrix.needsUpdate = true;
  clouds.frustumCulled = false;
  env.add(clouds);

  const starPoints = (() => {
    const n = 650;
    const arr = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const u = rndEnv() * 2 - 1;
      const a = rndEnv() * Math.PI * 2;
      const s = Math.sqrt(1 - u * u);
      arr[i * 3] = Math.cos(a) * s * 700;
      arr[i * 3 + 1] = u * 700;
      arr[i * 3 + 2] = Math.sin(a) * s * 700;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(arr, 3));
    const m = new THREE.PointsMaterial({
      color: 0xffffff, size: 2.4, sizeAttenuation: false, transparent: true, opacity: 0, fog: false, depthWrite: false,
    });
    const p = new THREE.Points(g, m);
    p.frustumCulled = false;
    p.visible = false;
    scene.add(p);
    return p;
  })();

  const sunMesh = new THREE.Mesh(
    new THREE.SphereGeometry(30, 14, 10),
    new THREE.MeshBasicMaterial({ color: 0xfff2b8, fog: false }),
  );
  scene.add(sunMesh);
  const sunDir = new THREE.Vector3(0.5, 0.3, -0.82).normalize().multiplyScalar(650);

  const particles = createParticles(scene, 140);

  /* динамика платформ */
  function crumbleStep(pl, dt) {
    if (pl.state === 'shake') {
      pl.timer -= dt;
      pl.body.position.x = (Math.random() - 0.5) * 0.09;
      pl.body.position.z = (Math.random() - 0.5) * 0.09;
      if (pl.timer <= 0) {
        pl.state = 'fall';
        pl.solid = false;
        pl.timer = 0; pl.fallV = 0; pl.fallY = 0;
        pl.body.position.set(0, -pl.h / 2, 0);
      }
    } else if (pl.state === 'fall') {
      pl.timer += dt;
      pl.fallV += 26 * dt;
      pl.fallY -= pl.fallV * dt;
      pl.body.position.y = -pl.h / 2 + pl.fallY;
      const s = Math.max(0.02, 1 - pl.timer * 0.9);
      pl.body.scale.set(pl.w * s, pl.h * s, pl.d * s);
      if (pl.timer > 1.0) {
        pl.state = 'gone'; pl.hidden = true; pl.group.visible = false; pl.timer = 0;
      }
    } else if (pl.state === 'gone') {
      pl.timer += dt;
      if (pl.timer > 2.8) {
        pl.state = 'idle'; pl.hidden = false; pl.solid = true; pl.timer = 0;
        pl.body.position.set(0, -pl.h / 2, 0);
        pl.body.scale.set(pl.w, pl.h, pl.d);
        pl.group.visible = true;
      }
    }
  }

  function blinkStep(pl, t) {
    const c = (t + pl.phase) % BLINK_T;
    let op = 1;
    let solid = true;
    if (c >= 3.4) { op = 0.12; solid = false; }
    else if (c >= 2.8) op = Math.floor((c - 2.8) / 0.1) % 2 === 0 ? 0.35 : 1;
    pl.solid = solid;
    if (pl.mat.opacity !== op) pl.mat.opacity = op;
  }

  function stepPlatforms(t, dt) {
    for (let i = 0; i < dynamic.length; i++) {
      const pl = dynamic[i];
      if (pl.type === 'moving') {
        const ph = pl.omega * t + pl.phase;
        const nx = pl.baseX + pl.lx * pl.amp * Math.sin(ph);
        const nz = pl.baseZ + pl.lz * pl.amp * Math.sin(ph);
        pl.dx = nx - pl.x;
        pl.dz = nz - pl.z;
        pl.x = nx;
        pl.z = nz;
        const c = Math.cos(ph) * pl.omega * pl.amp;
        pl.vx = pl.lx * c;
        pl.vz = pl.lz * c;
        pl.group.position.x = nx;
        pl.group.position.z = nz;
      } else if (pl.type === 'crumble') {
        crumbleStep(pl, dt);
      } else if (pl.type === 'blink') {
        blinkStep(pl, t);
      } else if (pl.type === 'spring' && pl.squash > 0) {
        pl.squash = Math.max(0, pl.squash - dt * 5);
        pl.deco.scale.y = 1 - 0.6 * pl.squash;
      }
    }
  }

  function groundBelow(x, y, z) {
    const q = queryRange(y - 80, y + 0.3);
    for (let i = q.hi - 1; i >= q.lo; i--) {
      const pl = platforms[i];
      if (!pl.solid || pl.hidden) continue;
      if (Math.abs(x - pl.x) <= pl.hw && Math.abs(z - pl.z) <= pl.hd) return pl.y;
    }
    return null;
  }

  function cull(y) {
    const lo = y - 70;
    const hi = y + 120;
    for (let i = 0; i < platforms.length; i++) {
      const pl = platforms[i];
      pl.group.visible = !pl.hidden && pl.y > lo && pl.y < hi;
    }
    for (let i = 0; i < stars.length; i++) {
      const s = stars[i];
      s.mesh.visible = !s.taken && s.y > lo && s.y < hi;
    }
  }

  const skyC = new THREE.Color();
  const tmpC = new THREE.Color();
  const WHITE = new THREE.Color(0xffffff);
  const ORANGE = new THREE.Color(0xffa060);
  const NIGHT = new THREE.Color(0x8fa0ff);
  const SUN_Y = new THREE.Color(0xfff2b8);
  const SUN_O = new THREE.Color(0xff8f4a);
  const MOON = new THREE.Color(0xdfe6ff);
  let tick = 0;

  function updateVisuals(dt, t, y, camera, px, pz) {
    skyColorAt(y, skyC);
    bg.copy(skyC);
    scene.fog.color.copy(skyC);
    const day = 1 - smooth(450, 900, y);
    const warm = smooth(300, 480, y) * (1 - smooth(560, 700, y));
    hemi.intensity = 1.0 + 1.2 * day;
    hemi.color.copy(skyC).lerp(WHITE, 0.55);
    hemi.groundColor.set(0x8a96a8).multiplyScalar(0.5 + 0.5 * day);
    sunLight.intensity = 0.8 + 1.6 * day;
    sunLight.color.copy(WHITE).lerp(ORANGE, warm).lerp(NIGHT, smooth(650, 850, y));
    sunLight.position.set(px - 30, y + 55, pz + 25);
    sunLight.target.position.set(px, y, pz);
    cloudMat.color.copy(skyC).lerp(WHITE, 0.6 * day + 0.2);

    sunMesh.visible = y < 940;
    sunMesh.position.copy(camera.position).add(sunDir);
    tmpC.copy(SUN_Y).lerp(SUN_O, smooth(300, 480, y)).lerp(MOON, smooth(600, 780, y));
    sunMesh.material.color.copy(tmpC);
    sunMesh.scale.setScalar(1 + 0.5 * warm - 0.35 * smooth(650, 800, y));

    const so = smooth(560, 860, y);
    starPoints.visible = so > 0.01;
    starPoints.material.opacity = so;
    starPoints.position.copy(camera.position);

    if (tick++ % 6 === 0) cull(y);
    for (let i = 0; i < stars.length; i++) {
      const s = stars[i];
      if (!s.mesh.visible) continue;
      s.mesh.rotation.y += dt * 2.2;
      s.mesh.position.y = s.y + Math.sin(t * 2.2 + s.id) * 0.12;
    }
    if (finishStar) {
      finishStar.rotation.y += dt * 1.6;
      finishStar.position.y = 3.2 + Math.sin(t * 2) * 0.18;
    }
    particles.update(dt);
  }

  function resetStars(ids) {
    const set = new Set(ids);
    for (const s of stars) {
      s.taken = set.has(s.id);
      s.mesh.visible = !s.taken;
    }
  }

  function takeStar(s) {
    s.taken = true;
    s.mesh.visible = false;
  }

  function setCheckpointLevel(k) {
    for (const f of flags) f.mat.color.set(f.k <= k ? 0x43a047 : 0xe53935);
  }

  function setLowGfx(low) {
    env.visible = !low;
  }

  return {
    platforms, stars, cpIndex, particles, queryRange, stepPlatforms, groundBelow, updateVisuals,
    resetStars, takeStar, setCheckpointLevel, setLowGfx,
  };
}

/* ---------- модель игрока ---------- */

export function createPlayerModel(scene) {
  const group = new THREE.Group();
  const rig = new THREE.Group();
  group.add(rig);
  const mat = (c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.75, emissive: new THREE.Color(c).multiplyScalar(0.22) });
  const shirt = mat(0x1565c0);
  const skin = mat(0xf2c09a);
  const pants = mat(0x263238);
  const shoe = mat(0xf5f5f5);
  const band = mat(0xff5252);
  const hair = mat(0x3e2723);
  const dark = new THREE.MeshBasicMaterial({ color: 0x111111 });

  const box = (w, h, d, m, x, y, z, parent) => {
    const o = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
    o.position.set(x, y, z);
    (parent || rig).add(o);
    return o;
  };
  const limb = (x, y, w, h, d, m) => {
    const pivot = new THREE.Group();
    pivot.position.set(x, y, 0);
    rig.add(pivot);
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
    mesh.position.y = -h / 2;
    pivot.add(mesh);
    return pivot;
  };

  box(0.5, 0.56, 0.3, shirt, 0, 0.8, 0);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 12, 10), skin);
  head.position.set(0, 1.26, 0);
  rig.add(head);
  box(0.42, 0.13, 0.4, hair, 0, 1.4, -0.02);
  box(0.43, 0.07, 0.41, band, 0, 1.31, 0);
  box(0.06, 0.07, 0.02, dark, -0.07, 1.25, 0.19);
  box(0.06, 0.07, 0.02, dark, 0.07, 1.25, 0.19);
  const legL = limb(-0.13, 0.52, 0.19, 0.5, 0.22, pants);
  const legR = limb(0.13, 0.52, 0.19, 0.5, 0.22, pants);
  box(0.21, 0.1, 0.3, shoe, 0, -0.5, 0.04, legL);
  box(0.21, 0.1, 0.3, shoe, 0, -0.5, 0.04, legR);
  const armL = limb(-0.33, 1.04, 0.13, 0.46, 0.15, shirt);
  const armR = limb(0.33, 1.04, 0.13, 0.46, 0.15, shirt);
  box(0.12, 0.12, 0.14, skin, 0, -0.46, 0, armL);
  box(0.12, 0.12, 0.14, skin, 0, -0.46, 0, armR);
  scene.add(group);

  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(0.5, 20),
    new THREE.MeshBasicMaterial({
      color: 0x000000, transparent: true, opacity: 0.38, depthWrite: false,
      polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2,
    }),
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.visible = false;
  scene.add(shadow);

  let phase = 0;
  let sq = 0;
  const damp = (cur, to, k, dt) => cur + (to - cur) * (1 - Math.exp(-k * dt));

  return {
    group,
    setPosition(x, y, z) { group.position.set(x, y, z); },
    jump() { sq = -0.18; },
    land(impact) { sq = Math.min(0.32, impact * 0.015); },
    update(dt, s) {
      const sp = Math.min(1, s.speed / PHYS.speed);
      if (s.speed > 0.4) {
        const target = Math.atan2(s.vx, s.vz);
        let diff = target - group.rotation.y;
        diff = Math.atan2(Math.sin(diff), Math.cos(diff));
        group.rotation.y += diff * (1 - Math.exp(-14 * dt));
      }
      if (s.grounded) {
        if (sp > 0.05) phase += dt * (6 + sp * 9);
        const sw = Math.sin(phase) * 0.95 * sp;
        legL.rotation.x = damp(legL.rotation.x, sw, 30, dt);
        legR.rotation.x = damp(legR.rotation.x, -sw, 30, dt);
        armL.rotation.x = damp(armL.rotation.x, -sw * 0.9, 30, dt);
        armR.rotation.x = damp(armR.rotation.x, sw * 0.9, 30, dt);
        rig.position.y = sp > 0.05 ? Math.abs(Math.sin(phase)) * 0.06 * sp : Math.sin(s.time * 2) * 0.01;
      } else {
        const up = s.vy > 0;
        legL.rotation.x = damp(legL.rotation.x, up ? -0.7 : 0.35, 12, dt);
        legR.rotation.x = damp(legR.rotation.x, up ? 0.5 : -0.3, 12, dt);
        armL.rotation.x = damp(armL.rotation.x, up ? -2.6 : -1.2, 12, dt);
        armR.rotation.x = damp(armR.rotation.x, up ? -2.6 : -1.2, 12, dt);
        rig.position.y = 0;
      }
      sq *= Math.exp(-10 * dt);
      const st = s.grounded ? 0 : clamp(Math.abs(s.vy) * 0.012, 0, 0.16);
      const sy = 1 - sq + st;
      const sxz = 1 / Math.sqrt(sy);
      rig.scale.set(sxz, sy, sxz);
    },
    setShadow(groundY, y) {
      if (groundY === null) { shadow.visible = false; return; }
      shadow.visible = true;
      shadow.position.set(group.position.x, groundY + 0.02, group.position.z);
      const k = clamp(1 - (y - groundY) / 14, 0.35, 1);
      shadow.scale.set(k, k, k);
    },
  };
}

/* ---------- физика игрока ---------- */

export function newPlayerState() {
  return {
    x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, grounded: false, support: null, lastSupport: null,
    coyote: 0, jumpBuffer: 0, jumping: false, jumpAge: 0, maxSupportY: 0,
  };
}

function landOn(p, pl, impact, same, ev) {
  p.y = pl.y;
  p.lastSupport = pl;
  if (pl.type === 'spring') {
    p.vy = PHYS.springVel;
    p.grounded = false;
    p.jumping = false;
    p.coyote = 0;
    p.support = pl;
    pl.squash = 1;
    ev.spring(pl);
    return;
  }
  p.vy = 0;
  p.support = pl;
  p.grounded = true;
  if (pl.y > p.maxSupportY) p.maxSupportY = pl.y;
  if (!same) ev.land(pl, impact);
}

function sideCollide(world, p, ev) {
  const plats = world.platforms;
  const q = world.queryRange(p.y - 0.05, p.y + PLAYER_HEIGHT + 1.7);
  const R = PLAYER_RADIUS;
  for (let i = q.lo; i < q.hi; i++) {
    const pl = plats[i];
    if (!pl.solid) continue;
    const bot = pl.y - pl.h;
    if (p.y >= pl.y - 0.03 || p.y + PLAYER_HEIGHT <= bot + 0.03) continue;
    const cx = clamp(p.x, pl.x - pl.hw, pl.x + pl.hw);
    const cz = clamp(p.z, pl.z - pl.hd, pl.z + pl.hd);
    const ex = p.x - cx;
    const ez = p.z - cz;
    const d2 = ex * ex + ez * ez;
    if (d2 >= R * R) continue;
    if (pl.y - p.y <= STEP_ASSIST) {
      landOn(p, pl, 0, p.grounded && p.support === pl, ev);
      continue;
    }
    if (d2 > 1e-9) {
      const d = Math.sqrt(d2);
      const nx = ex / d;
      const nz = ez / d;
      p.x += nx * (R - d);
      p.z += nz * (R - d);
      const vn = p.vx * nx + p.vz * nz;
      if (vn < 0) { p.vx -= vn * nx; p.vz -= vn * nz; }
    } else {
      const ox = pl.hw - Math.abs(p.x - pl.x);
      const oz = pl.hd - Math.abs(p.z - pl.z);
      if (ox < oz) p.x += (p.x >= pl.x ? 1 : -1) * (ox + R);
      else p.z += (p.z >= pl.z ? 1 : -1) * (oz + R);
    }
  }
}

/* inp: { mx, mz, mag, held }; возвращает true, если игрок упал */
export function stepPlayer(world, p, inp, dt, t, ev) {
  world.stepPlatforms(t, dt);
  const plats = world.platforms;

  if (p.grounded && p.support) { p.x += p.support.dx; p.z += p.support.dz; }

  const ice = p.grounded && p.support && p.support.type === 'ice';
  let accel;
  if (inp.mag > 0.02) accel = p.grounded ? (ice ? 14 : 58) : 26;
  else accel = p.grounded ? (ice ? 5 : 64) : 2.2;
  const tvx = inp.mx * PHYS.speed;
  const tvz = inp.mz * PHYS.speed;
  const ddx = tvx - p.vx;
  const ddz = tvz - p.vz;
  const dl = Math.hypot(ddx, ddz);
  const md = accel * dt;
  if (dl <= md) { p.vx = tvx; p.vz = tvz; }
  else { p.vx += (ddx / dl) * md; p.vz += (ddz / dl) * md; }
  if (!p.grounded) {
    windAt(p.y, t);
    p.vx += WIND.x * dt;
    p.vz += WIND.z * dt;
  }

  p.jumpBuffer -= dt;
  p.coyote = p.grounded ? COYOTE : p.coyote - dt;
  if (p.jumpBuffer > 0 && p.coyote > 0) {
    p.vy = PHYS.jumpVel;
    p.jumping = true;
    p.jumpAge = 0;
    if (p.support) { p.vx += p.support.vx; p.vz += p.support.vz; }
    p.grounded = false;
    p.coyote = 0;
    p.jumpBuffer = 0;
    ev.jump(p.support);
  }
  if (p.jumping) {
    p.jumpAge += dt;
    if (p.vy <= 0) p.jumping = false;
    else if (!inp.held && p.jumpAge > 0.09) { p.vy *= 0.6; p.jumping = false; }
  }

  const prevY = p.y;
  const wasGrounded = p.grounded;
  const wasSupport = p.support;
  p.vy = Math.max(-PHYS.maxFall, p.vy - PHYS.gravity * dt);
  p.y += p.vy * dt;

  let landed = null;
  if (p.vy <= 0) {
    const q = world.queryRange(p.y - 1e-6, prevY + 0.03);
    for (let i = q.lo; i < q.hi; i++) {
      const pl = plats[i];
      if (!pl.solid || prevY < pl.y - 0.03) continue;
      if (Math.abs(p.x - pl.x) > pl.hw + EDGE || Math.abs(p.z - pl.z) > pl.hd + EDGE) continue;
      if (!landed || pl.y > landed.y) landed = pl;
    }
  }
  if (landed) {
    landOn(p, landed, -p.vy, wasGrounded && wasSupport === landed, ev);
  } else {
    p.grounded = false;
    if (p.vy > 0) {
      const headPrev = prevY + PLAYER_HEIGHT;
      const q = world.queryRange(headPrev - 0.1, p.y + PLAYER_HEIGHT + 1.7);
      for (let i = q.lo; i < q.hi; i++) {
        const pl = plats[i];
        if (!pl.solid) continue;
        const bot = pl.y - pl.h;
        if (headPrev <= bot + 0.03 && p.y + PLAYER_HEIGHT > bot
          && Math.abs(p.x - pl.x) <= pl.hw + 0.1 && Math.abs(p.z - pl.z) <= pl.hd + 0.1) {
          p.y = bot - PLAYER_HEIGHT - 0.001;
          p.vy = 0;
          p.jumping = false;
          break;
        }
      }
    }
  }

  p.x += p.vx * dt;
  p.z += p.vz * dt;
  sideCollide(world, p, ev);

  return p.y < p.maxSupportY - FALL_DEPTH;
}
