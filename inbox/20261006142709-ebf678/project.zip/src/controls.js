const JOY_R = 58;
const DEADZONE = 0.12;
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

const KEY_MOVE = {
  KeyW: [0, 1], ArrowUp: [0, 1], KeyS: [0, -1], ArrowDown: [0, -1],
  KeyA: [-1, 0], ArrowLeft: [-1, 0], KeyD: [1, 0], ArrowRight: [1, 0],
};

export function createControls(root) {
  root.innerHTML = `
    <div class="ctl-zone ctl-move"></div>
    <div class="ctl-zone ctl-look"></div>
    <div class="joy"><div class="joy-knob"></div></div>
    <button class="jump-btn" type="button" aria-label="Прыжок">
      <span class="jump-ico">▲</span><span class="jump-txt">Прыжок</span>
    </button>`;
  const moveZone = root.querySelector('.ctl-move');
  const lookZone = root.querySelector('.ctl-look');
  const joy = root.querySelector('.joy');
  const knob = root.querySelector('.joy-knob');
  const jumpBtn = root.querySelector('.jump-btn');

  const st = { jx: 0, jy: 0, held: false, queued: false, lookX: 0, lookY: 0 };
  const keys = new Set();
  let enabled = false;
  let joyId = null;
  let joyCx = 0;
  let joyCy = 0;
  let lookId = null;
  let lookLx = 0;
  let lookLy = 0;
  let jumpId = null;

  const capture = (el, e) => {
    try { el.setPointerCapture(e.pointerId); } catch (err) { /* указатель уже отпущен */ }
  };

  function setKnob(dx, dy) {
    knob.style.transform = `translate(${dx}px, ${dy}px)`;
  }

  function joyUpdate(e) {
    let dx = e.clientX - joyCx;
    let dy = e.clientY - joyCy;
    const len = Math.hypot(dx, dy);
    if (len > JOY_R) { dx = (dx / len) * JOY_R; dy = (dy / len) * JOY_R; }
    setKnob(dx, dy);
    let nx = dx / JOY_R;
    let ny = -dy / JOY_R;
    const mag = Math.hypot(nx, ny);
    if (mag < DEADZONE) {
      nx = 0; ny = 0;
    } else {
      const k = (mag - DEADZONE) / (1 - DEADZONE) / mag;
      nx *= k; ny *= k;
    }
    st.jx = nx;
    st.jy = ny;
  }

  function joyRelease() {
    joyId = null;
    st.jx = 0;
    st.jy = 0;
    setKnob(0, 0);
    joy.classList.remove('active');
    joy.style.left = '';
    joy.style.top = '';
    joy.style.right = '';
    joy.style.bottom = '';
  }

  moveZone.addEventListener('pointerdown', (e) => {
    if (!enabled || joyId !== null) return;
    e.preventDefault();
    joyId = e.pointerId;
    capture(moveZone, e);
    const rect = root.getBoundingClientRect();
    const half = joy.offsetWidth / 2;
    joyCx = clamp(e.clientX, rect.left + half + 6, rect.right - half - 6);
    joyCy = clamp(e.clientY, rect.top + half + 6, rect.bottom - half - 6);
    joy.style.left = `${joyCx - half - rect.left}px`;
    joy.style.top = `${joyCy - half - rect.top}px`;
    joy.style.right = 'auto';
    joy.style.bottom = 'auto';
    joy.classList.add('active');
    joyUpdate(e);
  });
  moveZone.addEventListener('pointermove', (e) => {
    if (e.pointerId === joyId) joyUpdate(e);
  });
  const joyEnd = (e) => { if (e.pointerId === joyId) joyRelease(); };
  moveZone.addEventListener('pointerup', joyEnd);
  moveZone.addEventListener('pointercancel', joyEnd);
  moveZone.addEventListener('lostpointercapture', joyEnd);

  lookZone.addEventListener('pointerdown', (e) => {
    if (!enabled || lookId !== null) return;
    e.preventDefault();
    lookId = e.pointerId;
    lookLx = e.clientX;
    lookLy = e.clientY;
    capture(lookZone, e);
  });
  lookZone.addEventListener('pointermove', (e) => {
    if (e.pointerId !== lookId) return;
    st.lookX += e.clientX - lookLx;
    st.lookY += e.clientY - lookLy;
    lookLx = e.clientX;
    lookLy = e.clientY;
  });
  const lookEnd = (e) => { if (e.pointerId === lookId) lookId = null; };
  lookZone.addEventListener('pointerup', lookEnd);
  lookZone.addEventListener('pointercancel', lookEnd);
  lookZone.addEventListener('lostpointercapture', lookEnd);

  jumpBtn.addEventListener('pointerdown', (e) => {
    if (!enabled) return;
    e.preventDefault();
    e.stopPropagation();
    jumpId = e.pointerId;
    capture(jumpBtn, e);
    st.held = true;
    st.queued = true;
    jumpBtn.classList.add('down');
  });
  const jumpEnd = (e) => {
    if (e.pointerId !== jumpId) return;
    jumpId = null;
    st.held = false;
    jumpBtn.classList.remove('down');
  };
  jumpBtn.addEventListener('pointerup', jumpEnd);
  jumpBtn.addEventListener('pointercancel', jumpEnd);
  jumpBtn.addEventListener('lostpointercapture', jumpEnd);

  root.addEventListener('contextmenu', (e) => e.preventDefault());

  window.addEventListener('keydown', (e) => {
    if (!enabled) return;
    if (e.code === 'Space') {
      e.preventDefault();
      if (!e.repeat) st.queued = true;
      keys.add('Space');
    } else if (KEY_MOVE[e.code] || e.code === 'KeyQ' || e.code === 'KeyE') {
      e.preventDefault();
      keys.add(e.code);
    }
  });
  window.addEventListener('keyup', (e) => { keys.delete(e.code); });
  window.addEventListener('blur', () => { keys.clear(); });

  function reset() {
    joyRelease();
    lookId = null;
    jumpId = null;
    st.held = false;
    st.queued = false;
    st.lookX = 0;
    st.lookY = 0;
    keys.clear();
    jumpBtn.classList.remove('down');
  }

  return {
    setEnabled(v) {
      enabled = v;
      if (!v) reset();
    },
    setLefty(v) {
      root.classList.toggle('lefty', !!v);
    },
    poll(dt) {
      let x = st.jx;
      let y = st.jy;
      if (keys.size) {
        let kx = 0;
        let ky = 0;
        for (const k of keys) {
          const m = KEY_MOVE[k];
          if (m) { kx += m[0]; ky += m[1]; }
        }
        if (kx || ky) {
          const l = Math.hypot(kx, ky);
          x = kx / l;
          y = ky / l;
        }
        if (keys.has('KeyQ')) st.lookX -= 380 * dt;
        if (keys.has('KeyE')) st.lookX += 380 * dt;
      }
      return { x, y, held: st.held || keys.has('Space') };
    },
    consumeJump() {
      const j = st.queued;
      st.queued = false;
      return j;
    },
    consumeLook() {
      const r = { dx: st.lookX, dy: st.lookY };
      st.lookX = 0;
      st.lookY = 0;
      return r;
    },
    reset,
  };
}
