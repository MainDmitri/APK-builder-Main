import * as THREE from 'three';
import './style.css';
import {
  createWorld, createPlayerModel, newPlayerState, stepPlayer, windAt, WIND,
  GOAL_HEIGHT, JUMP_BUFFER, ZONES, zoneIndexAt,
} from './world.js';
import { createControls } from './controls.js';
import { createUI } from './ui.js';

const STORAGE_KEY = 'app:v1';
const PHYS_STEP = 1 / 120;
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

/* ---------- хранилище (localStorage, JSON) ---------- */

function defaultState() {
  return {
    v: 1,
    settings: { sound: true, sens: 1, lefty: false, autoCam: true, lowGfx: false },
    stats: {
      plays: 0, wins: 0, winsHard: 0, perfect: 0, totalStars: 0, totalFalls: 0,
      bestHeight: 0, bestHeightHard: 0, bestTime: null, bestTimeHard: null, mostStars: 0,
    },
    run: null,
  };
}

const num = (v, min, max, d) => (typeof v === 'number' && isFinite(v) ? clamp(v, min, max) : d);

function loadState() {
  const st = defaultState();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return st;
    const d = JSON.parse(raw);
    if (!d || typeof d !== 'object') return st;
    const s = d.settings || {};
    for (const k of ['sound', 'lefty', 'autoCam', 'lowGfx']) {
      if (typeof s[k] === 'boolean') st.settings[k] = s[k];
    }
    st.settings.sens = num(s.sens, 0.5, 2, 1);
    const t = d.stats || {};
    for (const k of Object.keys(st.stats)) {
      if (k === 'bestTime' || k === 'bestTimeHard') {
        st.stats[k] = typeof t[k] === 'number' && t[k] > 0 && isFinite(t[k]) ? t[k] : null;
      } else {
        st.stats[k] = Math.round(num(t[k], 0, 1e9, 0));
      }
    }
    const r = d.run;
    if (r && typeof r === 'object' && r.mode === 'classic') {
      st.run = {
        mode: 'classic',
        checkpoint: Math.round(num(r.checkpoint, 0, 9, 0)),
        falls: Math.round(num(r.falls, 0, 1e6, 0)),
        time: num(r.time, 0, 1e7, 0),
        maxHeight: num(r.maxHeight, 0, GOAL_HEIGHT, 0),
        stars: Array.isArray(r.stars) ? r.stars.filter((x) => Number.isInteger(x) && x >= 0).slice(0, 5000) : [],
      };
    }
    return st;
  } catch (e) {
    return defaultState();
  }
}

let state = loadState();
let ui = null;
let saveFailed = false;
let dirty = false;
let lastSave = 0;

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    dirty = false;
  } catch (e) {
    if (!saveFailed && ui) {
      saveFailed = true;
      ui.toast('Не удалось сохранить прогресс', 'bad');
    }
  }
}

/* ---------- звук (Web Audio, без файлов) ---------- */

const audio = { ctx: null };

function audioUnlock() {
  try {
    if (!audio.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      audio.ctx = new AC();
    }
    if (audio.ctx.state === 'suspended') audio.ctx.resume();
  } catch (e) {
    audio.ctx = null;
  }
}

function tone(freq, dur, type, vol, slide, delay) {
  const ctx = audio.ctx;
  if (!state.settings.sound || !ctx || ctx.state !== 'running') return;
  const t0 = ctx.currentTime + (delay || 0);
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);
  if (slide) osc.frequency.exponentialRampToValueAtTime(slide, t0 + dur);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(vol, t0 + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(g);
  g.connect(ctx.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.03);
}

const sfx = {
  jump: () => tone(380, 0.14, 'square', 0.05, 760),
  land: () => tone(150, 0.09, 'sine', 0.12, 80),
  spring: () => tone(300, 0.25, 'square', 0.06, 1000),
  crumble: () => tone(110, 0.3, 'sawtooth', 0.06, 45),
  star: () => { tone(880, 0.09, 'triangle', 0.13); tone(1320, 0.14, 'triangle', 0.13, null, 0.07); },
  checkpoint: () => { [523, 659, 784].forEach((f, i) => tone(f, 0.18, 'triangle', 0.14, null, i * 0.09)); },
  fall: () => tone(420, 0.55, 'sawtooth', 0.1, 60),
  win: () => { [523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, 0.28, 'triangle', 0.15, null, i * 0.12)); },
};

/* ---------- сцена ---------- */

let renderer = null;
let scene = null;
let camera = null;
let world = null;
let model = null;
let controls = null;

const game = { run: null, finished: false, result: null, active: false, zone: 0 };
const player = newPlayerState();
const cam = { yaw: 0.6, pitch: 0.5, dist: 10.5, ty: 1, manualUntil: 0 };
const camTarget = new THREE.Vector3();
const camLook = new THREE.Vector3();
let simTime = 0;
let acc = 0;
let lastMs = 0;
let nowSec = 0;

function newRun(mode) {
  return { mode, checkpoint: 0, cpSeen: 0, falls: 0, time: 0, stars: new Set(), maxHeight: 0 };
}

function serializeRun(r) {
  return {
    mode: r.mode,
    checkpoint: r.checkpoint,
    falls: r.falls,
    time: Math.round(r.time * 10) / 10,
    maxHeight: Math.round(r.maxHeight * 10) / 10,
    stars: Array.from(r.stars),
  };
}

function persistRun() {
  if (game.run && game.run.mode === 'classic') state.run = serializeRun(game.run);
  saveState();
}

function nextPlatform() {
  const cur = player.lastSupport;
  return cur ? world.platforms[cur.id + 1] || null : null;
}

function alignCameraToPath() {
  const nxt = nextPlatform();
  if (!nxt) return;
  const fx = nxt.x - player.x;
  const fz = nxt.z - player.z;
  if (fx * fx + fz * fz > 0.5) cam.yaw = Math.atan2(-fx, -fz);
}

function respawn(k) {
  const pl = world.platforms[world.cpIndex[k] || 0];
  player.x = pl.x;
  player.y = pl.y;
  player.z = pl.z;
  player.vx = 0;
  player.vy = 0;
  player.vz = 0;
  player.grounded = true;
  player.support = pl;
  player.lastSupport = pl;
  player.maxSupportY = pl.y;
  player.coyote = 0;
  player.jumpBuffer = 0;
  player.jumping = false;
  acc = 0;
  cam.ty = pl.y + 1;
  alignCameraToPath();
  model.setPosition(player.x, player.y, player.z);
}

/* ---------- игровые события ---------- */

function reachCheckpoint(pl) {
  const run = game.run;
  if (!run || pl.cp <= run.cpSeen) return;
  run.cpSeen = pl.cp;
  world.setCheckpointLevel(pl.cp);
  sfx.checkpoint();
  world.particles.emit(pl.x, pl.y + 0.3, pl.z, 24, 0xffd54f, 4, 4);
  if (run.mode === 'classic') {
    run.checkpoint = pl.cp;
    ui.toast(`Контрольная точка: ${pl.cp * 100} м`, 'good');
    persistRun();
  } else {
    ui.toast(`Отметка: ${pl.cp * 100} м`, 'good');
  }
}

function takeStar(s) {
  const run = game.run;
  world.takeStar(s);
  run.stars.add(s.id);
  state.stats.totalStars++;
  sfx.star();
  world.particles.emit(s.x, s.y, s.z, 12, 0xffd54f, 3, 3);
  persistRun();
}

function handleFall() {
  const run = game.run;
  run.falls++;
  state.stats.totalFalls++;
  sfx.fall();
  ui.flash('fall');
  if (run.mode === 'hard') {
    run.checkpoint = 0;
    run.cpSeen = 0;
    run.time = 0;
    run.maxHeight = 0;
    run.stars.clear();
    world.resetStars([]);
    world.setCheckpointLevel(0);
    ui.toast('Падение! Всё сначала', 'bad');
  } else {
    ui.toast('Падение! Возврат на контрольную точку', 'bad');
  }
  persistRun();
  respawn(run.checkpoint);
}

function win() {
  const run = game.run;
  if (!run || game.finished) return;
  game.finished = true;
  const s = state.stats;
  const hard = run.mode === 'hard';
  s.wins++;
  if (hard) s.winsHard++;
  if (run.falls === 0) s.perfect++;
  const tkey = hard ? 'bestTimeHard' : 'bestTime';
  const newTime = s[tkey] === null || run.time < s[tkey];
  if (newTime) s[tkey] = run.time;
  const stars = run.stars.size;
  const newStars = stars > s.mostStars;
  if (newStars) s.mostStars = stars;
  if (hard) s.bestHeightHard = GOAL_HEIGHT; else s.bestHeight = GOAL_HEIGHT;
  game.result = {
    mode: run.mode, time: run.time, falls: run.falls, stars, totalStars: world.stars.length,
    perfect: run.falls === 0, newTime, newStars,
  };
  game.run = null;
  if (!hard) state.run = null;
  saveState();
  sfx.win();
  ui.flash('win');
  world.particles.emit(player.x, player.y + 1, player.z, 60, 0xffd54f, 6, 6);
  location.replace('#/win');
}

const events = {
  jump() {
    sfx.jump();
    model.jump();
    world.particles.emit(player.x, player.y + 0.05, player.z, 4, 0xffffff, 1.2, 0.6);
  },
  spring() {
    sfx.spring();
    model.jump();
    world.particles.emit(player.x, player.y + 0.1, player.z, 14, 0x9cff9c, 3, 3);
  },
  land(pl, impact) {
    if (impact > 5) sfx.land();
    model.land(impact);
    world.particles.emit(player.x, pl.y + 0.05, player.z, impact > 12 ? 10 : 4, 0xffffff, 1.6, 0.8);
    const run = game.run;
    if (!run || game.finished) return;
    if (pl.type === 'crumble' && pl.state === 'idle') {
      pl.state = 'shake';
      pl.timer = 0.65;
      sfx.crumble();
    } else if (pl.type === 'checkpoint') {
      reachCheckpoint(pl);
    } else if (pl.type === 'finish') {
      win();
    }
  },
};

/* ---------- запуск и продолжение забега ---------- */

function go(name) {
  if (currentRoute() === 'win') location.replace(`#/${name}`);
  else location.hash = `#/${name}`;
}

function startRun(mode) {
  audioUnlock();
  const needConfirm = game.run || (state.run && mode === 'classic');
  if (needConfirm && !window.confirm('Начать новое восхождение? Текущий прогресс будет потерян.')) return;
  state.stats.plays++;
  game.run = newRun(mode);
  game.finished = false;
  game.result = null;
  game.zone = 0;
  world.resetStars([]);
  world.setCheckpointLevel(0);
  if (mode === 'classic') state.run = serializeRun(game.run);
  saveState();
  respawn(0);
  go('game');
}

function continueRun() {
  audioUnlock();
  if (!game.run && state.run) {
    const r = state.run;
    game.run = {
      mode: 'classic', checkpoint: r.checkpoint, cpSeen: r.checkpoint, falls: r.falls,
      time: r.time, stars: new Set(r.stars), maxHeight: r.maxHeight,
    };
    game.finished = false;
    game.result = null;
    game.zone = zoneIndexAt(world.platforms[world.cpIndex[r.checkpoint] || 0].y);
    world.resetStars(r.stars);
    world.setCheckpointLevel(r.checkpoint);
    respawn(r.checkpoint);
  }
  if (game.run) go('game');
}

function resetProgress() {
  if (!window.confirm('Сбросить все рекорды и сохранённый прогресс?')) return;
  const keep = state.settings;
  state = defaultState();
  state.settings = keep;
  game.run = null;
  game.result = null;
  world.resetStars([]);
  world.setCheckpointLevel(0);
  respawn(0);
  saveState();
  ui.toast('Прогресс сброшен', 'good');
  ui.showSettings(state.settings);
}

function menuData() {
  const live = game.run;
  let cont = null;
  if (live) {
    cont = {
      mode: live.mode, height: player.y, checkpoint: live.checkpoint * 100, stars: live.stars.size,
    };
  } else if (state.run) {
    const r = state.run;
    cont = {
      mode: 'classic', height: world.platforms[world.cpIndex[r.checkpoint] || 0].y,
      checkpoint: r.checkpoint * 100, stars: r.stars.length,
    };
  }
  return { live: !!live, cont, stats: state.stats };
}

function onAction(name, data) {
  switch (name) {
    case 'play-classic': startRun('classic'); break;
    case 'play-hard': startRun('hard'); break;
    case 'continue': continueRun(); break;
    case 'replay': startRun(data.mode === 'hard' ? 'hard' : 'classic'); break;
    case 'back':
    case 'pause': history.back(); break;
    case 'reset-progress': resetProgress(); break;
    default: break;
  }
}

function onSetting(key, value) {
  const s = state.settings;
  if (key === 'sens') s.sens = clamp(value, 0.5, 2);
  else if (key in s && typeof value === 'boolean') s[key] = value;
  else return;
  if (key === 'lefty') controls.setLefty(s.lefty);
  if (key === 'lowGfx') { resize(); world.setLowGfx(s.lowGfx); }
  if (key === 'sound' && s.sound) { audioUnlock(); sfx.star(); }
  saveState();
}

/* ---------- маршрутизация (hash) ---------- */

function currentRoute() {
  const h = location.hash || '#/menu';
  return h.replace(/^#\/?/, '').split(/[/?]/)[0] || 'menu';
}

function route() {
  let r = currentRoute();
  if (!['menu', 'game', 'records', 'settings', 'win'].includes(r)) r = 'menu';
  if ((r === 'game' && !game.run) || (r === 'win' && !game.result)) {
    location.replace('#/menu');
    return;
  }
  document.body.dataset.route = r;
  game.active = r === 'game';
  controls.setEnabled(game.active);
  lastMs = 0;
  if (r !== 'game' && game.run) persistRun();
  switch (r) {
    case 'game': ui.hideScreens(); break;
    case 'records': ui.showRecords(state.stats); break;
    case 'settings': ui.showSettings(state.settings); break;
    case 'win': ui.showWin(game.result); break;
    default: ui.showMenu(menuData());
  }
}

/* ---------- камера ---------- */

function updateCamera(dt, inGame) {
  if (inGame) {
    const look = controls.consumeLook();
    const sens = state.settings.sens;
    if (look.dx || look.dy) {
      cam.yaw -= look.dx * 0.0055 * sens;
      cam.pitch = clamp(cam.pitch + look.dy * 0.0045 * sens, 0.15, 1.05);
      cam.manualUntil = nowSec + 2.5;
    }
    if (state.settings.autoCam && nowSec > cam.manualUntil) {
      const nxt = nextPlatform();
      if (nxt) {
        const fx = nxt.x - player.x;
        const fz = nxt.z - player.z;
        if (fx * fx + fz * fz > 1.5) {
          const want = Math.atan2(-fx, -fz);
          const diff = Math.atan2(Math.sin(want - cam.yaw), Math.cos(want - cam.yaw));
          cam.yaw += diff * (1 - Math.exp(-1.7 * dt));
        }
      }
    }
  } else {
    cam.yaw += dt * 0.2;
  }
  const rate = player.vy < -8 ? 10 : player.grounded ? 8 : 3.2;
  cam.ty += (player.y + 1 - cam.ty) * (1 - Math.exp(-rate * dt));
  camTarget.set(player.x, cam.ty, player.z);
  const cp = Math.cos(cam.pitch);
  camera.position.set(
    camTarget.x + Math.sin(cam.yaw) * cp * cam.dist,
    camTarget.y + Math.sin(cam.pitch) * cam.dist,
    camTarget.z + Math.cos(cam.yaw) * cp * cam.dist,
  );
  camLook.set(camTarget.x - Math.sin(cam.yaw) * 2.2, camTarget.y + 0.4, camTarget.z - Math.cos(cam.yaw) * 2.2);
  camera.lookAt(camLook);
}

/* ---------- кадр ---------- */

function simulate(dt) {
  const run = game.run;
  const inp = controls.poll(dt);
  if (controls.consumeJump()) player.jumpBuffer = JUMP_BUFFER;
  const sy = Math.sin(cam.yaw);
  const cy = Math.cos(cam.yaw);
  const mx = cy * inp.x - sy * inp.y;
  const mz = -sy * inp.x - cy * inp.y;
  const mag = Math.min(1, Math.hypot(inp.x, inp.y));
  const stepInput = { mx, mz, mag, held: inp.held };

  acc += dt;
  let n = 0;
  while (acc >= PHYS_STEP && n < 8) {
    const fell = stepPlayer(world, player, stepInput, PHYS_STEP, simTime, events);
    simTime += PHYS_STEP;
    acc -= PHYS_STEP;
    n++;
    if (game.finished) return;
    if (fell) {
      handleFall();
      return;
    }
  }
  if (n === 8) acc = 0;

  run.time += dt;
  if (player.grounded && player.y > run.maxHeight) {
    run.maxHeight = player.y;
    const key = run.mode === 'hard' ? 'bestHeightHard' : 'bestHeight';
    if (run.maxHeight > state.stats[key]) { state.stats[key] = Math.round(run.maxHeight * 10) / 10; dirty = true; }
  }

  const px = player.x;
  const py = player.y + 0.7;
  const pz = player.z;
  const stars = world.stars;
  for (let i = 0; i < stars.length; i++) {
    const s = stars[i];
    if (s.taken) continue;
    const dy = s.y - py;
    if (dy > 1.4 || dy < -1.4) continue;
    const dx = s.x - px;
    const dz = s.z - pz;
    if (dx * dx + dz * dz + dy * dy < 1.21) takeStar(s);
  }

  const zi = zoneIndexAt(player.y);
  if (zi !== game.zone) {
    if (zi > game.zone) ui.toast(ZONES[zi].name, 'zone');
    game.zone = zi;
  }

  if (dirty && nowSec - lastSave > 2.5) {
    lastSave = nowSec;
    persistRun();
  }
}

function frame(ms) {
  nowSec = ms / 1000;
  const dt = lastMs ? Math.min(0.05, (ms - lastMs) / 1000) : 0.016;
  lastMs = ms;
  const inGame = game.active && !!game.run && !game.finished;
  if (inGame) simulate(dt);
  else controls.consumeJump();

  updateCamera(dt, inGame);

  const hs = Math.hypot(player.vx, player.vz);
  model.update(dt, {
    speed: hs, grounded: player.grounded, vx: player.vx, vy: player.vy, vz: player.vz, time: nowSec,
  });
  model.setPosition(player.x, player.y, player.z);
  model.setShadow(world.groundBelow(player.x, player.y, player.z), player.y);
  world.updateVisuals(dt, nowSec, camTarget.y, camera, player.x, player.z);
  renderer.render(scene, camera);

  if (inGame && game.run) {
    const run = game.run;
    windAt(player.y, simTime);
    const sy = Math.sin(cam.yaw);
    const cy = Math.cos(cam.yaw);
    const sx = WIND.x * cy - WIND.z * sy;
    const sf = -WIND.x * sy - WIND.z * cy;
    ui.updateHud({
      height: player.y,
      maxHeight: run.maxHeight,
      stars: run.stars.size,
      totalStars: world.stars.length,
      falls: run.falls,
      time: run.time,
      mode: run.mode,
      zone: ZONES[zoneIndexAt(player.y)].name,
      wind: WIND.s,
      windAngle: (Math.atan2(sx, sf) * 180) / Math.PI,
    });
  }
}

function resize() {
  const w = window.innerWidth;
  const h = window.innerHeight;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, state.settings.lowGfx ? 1 : 2));
  renderer.setSize(w, h, false);
  camera.aspect = w / Math.max(1, h);
  camera.updateProjectionMatrix();
}

/* ---------- запуск приложения ---------- */

function boot() {
  ui = createUI({ onAction, onSetting });
  window.addEventListener('error', (e) => {
    if (e.error) ui.showError(`Ошибка: ${e.message || 'неизвестная ошибка'}`);
  });
  window.addEventListener('unhandledrejection', (e) => {
    ui.showError(`Ошибка: ${(e.reason && e.reason.message) || e.reason || 'неизвестная ошибка'}`);
  });

  try {
    const canvas = document.getElementById('scene');
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    canvas.addEventListener('webglcontextlost', (e) => {
      e.preventDefault();
      ui.showError('Графический контекст потерян. Перезапустите игру.');
    });
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(55, 1, 0.3, 1500);
    world = createWorld(scene);
    model = createPlayerModel(scene);
  } catch (e) {
    ui.showError(`Не удалось запустить 3D-графику (WebGL): ${e.message}`);
    return;
  }

  controls = createControls(document.getElementById('controls-root'));
  controls.setLefty(state.settings.lefty);
  world.setLowGfx(state.settings.lowGfx);
  respawn(0);
  resize();
  window.addEventListener('resize', resize);
  window.addEventListener('orientationchange', resize);

  const unlock = () => audioUnlock();
  window.addEventListener('pointerdown', unlock, { passive: true });
  window.addEventListener('keydown', unlock);

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) return;
    if (game.run) persistRun(); else saveState();
    if (currentRoute() === 'game') history.back();
  });
  window.addEventListener('pagehide', () => { if (game.run) persistRun(); else saveState(); });

  window.addEventListener('hashchange', route);
  if (!location.hash) history.replaceState(null, '', '#/menu');
  route();
  renderer.setAnimationLoop(frame);
}

boot();
