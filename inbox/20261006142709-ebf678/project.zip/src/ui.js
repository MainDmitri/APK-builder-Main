export const MODE_LABEL = { classic: 'Восхождение', hard: 'Без падений' };

export function fmtTime(sec) {
  if (sec === null || sec === undefined || !isFinite(sec)) return '—';
  const s = Math.floor(sec);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  const mm = String(m).padStart(2, '0');
  const ss = String(r).padStart(2, '0');
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

const fmtM = (v) => (v > 0 ? `${Math.round(v)} м` : '—');

const ACHIEVEMENTS = [
  ['100 м — первые шаги', (s) => Math.max(s.bestHeight, s.bestHeightHard) >= 100],
  ['250 м — над облаками', (s) => Math.max(s.bestHeight, s.bestHeightHard) >= 250],
  ['500 м — полпути', (s) => Math.max(s.bestHeight, s.bestHeightHard) >= 500],
  ['750 м — звёздное небо', (s) => Math.max(s.bestHeight, s.bestHeightHard) >= 750],
  ['1000 м — вершина', (s) => s.wins > 0],
  ['Идеальное восхождение', (s) => s.perfect > 0],
  ['Победа в режиме «Без падений»', (s) => s.winsHard > 0],
  ['100 звёзд собрано', (s) => s.totalStars >= 100],
];

export function createUI({ onAction, onSetting }) {
  const hudRoot = document.getElementById('hud-root');
  const screens = document.getElementById('screens-root');
  const toasts = document.getElementById('toast-root');
  const flashEl = document.getElementById('flash');
  const app = document.getElementById('app');

  let ticks = '';
  for (let k = 0; k <= 10; k++) ticks += `<i class="bar-tick" style="left:${k * 10}%"></i>`;
  hudRoot.innerHTML = `
    <div class="hud">
      <div class="hud-left">
        <div class="alt"><span id="h-alt">0</span><small> м</small></div>
        <div class="zone" id="h-zone"></div>
        <div class="wind hidden" id="h-wind">
          <svg viewBox="0 0 24 24" id="h-wind-ico"><path d="M12 2 L19 21 L12 17 L5 21 Z" fill="currentColor"/></svg>
          <span>Ветер</span>
        </div>
      </div>
      <div class="hud-mid">
        <div class="bar">${ticks}<div class="bar-fill" id="h-fill"></div><div class="bar-now" id="h-now"></div></div>
        <div class="bar-labels"><span>0</span><span>500</span><span>1000 м</span></div>
      </div>
      <div class="hud-right">
        <div class="chip">⭐ <b id="h-stars">0</b></div>
        <div class="chip"><span id="h-falls-l">Падения</span> <b id="h-falls">0</b></div>
        <div class="chip"><b id="h-time">00:00</b></div>
        <button class="icon-btn" id="h-pause" type="button" aria-label="Пауза">❚❚</button>
      </div>
    </div>`;

  const el = {
    alt: hudRoot.querySelector('#h-alt'),
    zone: hudRoot.querySelector('#h-zone'),
    wind: hudRoot.querySelector('#h-wind'),
    windIco: hudRoot.querySelector('#h-wind-ico'),
    fill: hudRoot.querySelector('#h-fill'),
    now: hudRoot.querySelector('#h-now'),
    stars: hudRoot.querySelector('#h-stars'),
    fallsL: hudRoot.querySelector('#h-falls-l'),
    falls: hudRoot.querySelector('#h-falls'),
    time: hudRoot.querySelector('#h-time'),
  };
  hudRoot.querySelector('#h-pause').addEventListener('click', () => onAction('pause', {}));

  const cache = {};
  function setText(key, node, value) {
    if (cache[key] !== value) {
      cache[key] = value;
      node.textContent = value;
    }
  }

  function updateHud(h) {
    setText('alt', el.alt, String(Math.max(0, Math.round(h.height))));
    setText('zone', el.zone, h.zone);
    setText('stars', el.stars, `${h.stars}/${h.totalStars}`);
    setText('fl', el.fallsL, h.mode === 'hard' ? 'Попытка' : 'Падения');
    setText('falls', el.falls, String(h.mode === 'hard' ? h.falls + 1 : h.falls));
    setText('time', el.time, fmtTime(h.time));
    const fillW = `${Math.min(100, (h.maxHeight / 10)).toFixed(1)}%`;
    if (cache.fill !== fillW) { cache.fill = fillW; el.fill.style.width = fillW; }
    const nowL = `${Math.min(100, Math.max(0, h.height / 10)).toFixed(1)}%`;
    if (cache.now !== nowL) { cache.now = nowL; el.now.style.left = nowL; }
    const showWind = h.wind > 0.05;
    if (cache.windShow !== showWind) {
      cache.windShow = showWind;
      el.wind.classList.toggle('hidden', !showWind);
    }
    if (showWind) {
      const deg = Math.round(h.windAngle);
      if (cache.windDeg !== deg) { cache.windDeg = deg; el.windIco.style.transform = `rotate(${deg}deg)`; }
    }
  }

  function toast(text, kind) {
    const t = document.createElement('div');
    t.className = `toast ${kind || ''}`;
    t.textContent = text;
    toasts.appendChild(t);
    while (toasts.children.length > 3) toasts.firstChild.remove();
    setTimeout(() => t.remove(), 2500);
  }

  function flash(kind) {
    flashEl.className = '';
    void flashEl.offsetWidth;
    flashEl.className = `on ${kind || 'fall'}`;
  }

  function show(html) {
    screens.innerHTML = `<section class="screen">${html}</section>`;
  }

  function hideScreens() {
    screens.innerHTML = '';
  }

  screens.addEventListener('click', (e) => {
    const t = e.target.closest('[data-act]');
    if (!t) return;
    e.preventDefault();
    onAction(t.dataset.act, t.dataset);
  });

  screens.addEventListener('input', (e) => {
    const t = e.target;
    if (!t.dataset || !t.dataset.set) return;
    if (t.type === 'checkbox') {
      onSetting(t.dataset.set, t.checked);
    } else {
      const v = parseFloat(t.value);
      onSetting(t.dataset.set, v);
      const out = screens.querySelector(`[data-out="${t.dataset.set}"]`);
      if (out) out.textContent = v.toFixed(1);
    }
  });

  function showMenu({ live, cont, stats }) {
    const best = Math.max(stats.bestHeight, stats.bestHeightHard);
    const contBtn = cont
      ? `<button class="btn btn-accent" data-act="continue" type="button">Продолжить
           <small>${MODE_LABEL[cont.mode]}: ${Math.round(cont.height)} м, отметка ${cont.checkpoint} м, звёзд ${cont.stars}</small>
         </button>`
      : '';
    show(`
      <div class="panel">
        <div class="menu-hero">
          <h1>${live ? 'Пауза' : 'ПАРКУР'}</h1>
          <p class="tagline">Поднимись с 0 до 1000 метров без падений</p>
          <ul class="how">
            <li>Левый стик — бег</li>
            <li>Кнопка прыжка — держи для высоты</li>
            <li>Правая часть экрана — поворот камеры</li>
          </ul>
          <div class="best">Рекорд высоты: <b>${fmtM(best)}</b></div>
        </div>
        <div class="menu-actions">
          ${contBtn}
          <button class="btn" data-act="play-classic" type="button">Восхождение
            <small>Контрольные точки каждые 100 м</small></button>
          <button class="btn" data-act="play-hard" type="button">Без падений
            <small>Упал — начинаешь с нуля</small></button>
          <div class="row2">
            <a class="btn btn-ghost center" href="#/records">Рекорды</a>
            <a class="btn btn-ghost center" href="#/settings">Настройки</a>
          </div>
        </div>
      </div>`);
  }

  function showRecords(s) {
    const cells = [
      ['Лучшая высота: Восхождение', fmtM(s.bestHeight)],
      ['Лучшая высота: Без падений', fmtM(s.bestHeightHard)],
      ['Лучшее время: Восхождение', fmtTime(s.bestTime)],
      ['Лучшее время: Без падений', fmtTime(s.bestTimeHard)],
      ['Вершин покорено', s.wins],
      ['Идеальных восхождений', s.perfect],
      ['Звёзд за один подъём', s.mostStars],
      ['Звёзд собрано всего', s.totalStars],
      ['Падений всего', s.totalFalls],
      ['Игр сыграно', s.plays],
    ].map(([l, v]) => `<div class="stat"><b>${v}</b><span>${l}</span></div>`).join('');
    const badges = ACHIEVEMENTS.map(([name, test]) => `<span class="badge ${test(s) ? 'on' : ''}">${name}</span>`).join('');
    show(`
      <div class="panel scroll">
        <div class="page">
          <div class="page-head">
            <button class="btn btn-ghost" data-act="back" type="button">‹ Назад</button>
            <h2>Рекорды</h2>
          </div>
          <div class="stat-grid">${cells}</div>
          <h2>Достижения</h2>
          <div class="badges">${badges}</div>
        </div>
      </div>`);
  }

  function showSettings(s) {
    const sw = (key, label, hint) => `
      <label class="row">
        <span>${label}<small>${hint}</small></span>
        <span class="switch"><input type="checkbox" data-set="${key}" ${s[key] ? 'checked' : ''}><span class="track"></span></span>
      </label>`;
    show(`
      <div class="panel scroll">
        <div class="page">
          <div class="page-head">
            <button class="btn btn-ghost" data-act="back" type="button">‹ Назад</button>
            <h2>Настройки</h2>
          </div>
          ${sw('sound', 'Звук', 'Эффекты прыжков, звёзд и контрольных точек')}
          <label class="row">
            <span>Чувствительность камеры<small>Значение: <span data-out="sens">${s.sens.toFixed(1)}</span></small></span>
            <input type="range" min="0.5" max="2" step="0.1" value="${s.sens}" data-set="sens">
          </label>
          ${sw('autoCam', 'Камера следует за путём', 'Сама поворачивается к следующей платформе')}
          ${sw('lefty', 'Управление для левши', 'Стик справа, кнопка прыжка слева')}
          ${sw('lowGfx', 'Экономный режим графики', 'Без облаков и гор, меньше нагрузка на телефон')}
          <button class="btn btn-danger" data-act="reset-progress" type="button">Сбросить рекорды и прогресс</button>
        </div>
      </div>`);
  }

  function showWin(r) {
    const flags = [];
    if (r.perfect) flags.push('Идеальное восхождение');
    if (r.newTime) flags.push('Новый рекорд времени');
    if (r.newStars) flags.push('Рекорд по звёздам');
    const badges = flags.map((f) => `<span class="badge on">${f}</span>`).join('');
    const attempts = r.mode === 'hard'
      ? `<div class="stat"><b>${r.falls + 1}</b><span>Попыток</span></div>`
      : `<div class="stat"><b>${r.falls}</b><span>Падений</span></div>`;
    show(`
      <div class="panel win-panel">
        <h1>Вершина покорена!</h1>
        <p class="tagline">${MODE_LABEL[r.mode]}: 1000 м</p>
        <div class="win-stats">
          <div class="stat"><b>${fmtTime(r.time)}</b><span>Время</span></div>
          ${attempts}
          <div class="stat"><b>${r.stars}/${r.totalStars}</b><span>Звёзд</span></div>
        </div>
        <div class="badges">${badges}</div>
        <div class="win-actions">
          <button class="btn" data-act="replay" data-mode="${r.mode}" type="button">Играть снова</button>
          <button class="btn btn-ghost" data-act="back" type="button">В меню</button>
        </div>
      </div>`);
  }

  function showError(msg) {
    let box = app.querySelector('.error-overlay');
    if (!box) {
      box = document.createElement('div');
      box.className = 'error-overlay';
      app.appendChild(box);
    }
    box.innerHTML = `
      <div class="error-box">
        <h2>Что-то пошло не так</h2>
        <p></p>
        <button class="btn" type="button" id="err-reload">Перезапустить игру</button>
      </div>`;
    box.querySelector('p').textContent = msg;
    box.querySelector('#err-reload').addEventListener('click', () => location.reload());
  }

  return { updateHud, toast, flash, hideScreens, showMenu, showRecords, showSettings, showWin, showError };
}
