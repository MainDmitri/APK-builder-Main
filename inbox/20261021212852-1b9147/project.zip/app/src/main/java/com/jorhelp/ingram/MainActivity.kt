package com.jorhelp.ingram

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.background
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.net.HttpURLConnection
import java.net.URL
import android.util.Base64

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val darkColorScheme = darkColorScheme(
                primary = Color(0xFF00E5FF),
                secondary = Color(0xFFFF4081),
                background = Color(0xFF0D1117),
                surface = Color(0xFF161B22),
                onPrimary = Color.Black,
                onBackground = Color(0xFFE6EDF3),
                onSurface = Color(0xFFE6EDF3)
            )
            MaterialTheme(colorScheme = darkColorScheme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ScannerScreen()
                }
            }
        }
    }
}

@Composable
fun ScannerScreen() {
    var targets by remember { mutableStateOf("192.168.1.1") }
    var ports by remember { mutableStateOf("80,8000,8080") }
    var users by remember { mutableStateOf("admin") }
    var passwords by remember { mutableStateOf("admin\nadmin12345") }
    var isScanning by remember { mutableStateOf(false) }
    val results = remember { mutableStateListOf<String>() }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Text(
            "INGRAM",
            style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Black, letterSpacing = 4.sp),
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
        )
        Text(
            "CAMERA VECTOR SCANNER",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )

        Spacer(Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.padding(12.dp)) {
                OutlinedTextField(
                    value = targets,
                    onValueChange = { targets = it },
                    label = { Text("TARGETS") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.onSurface.copy(0.3f)
                    )
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = ports,
                    onValueChange = { ports = it },
                    label = { Text("PORTS") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MaterialTheme.colorScheme.primary)
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = users,
                        onValueChange = { users = it },
                        label = { Text("USERS") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MaterialTheme.colorScheme.primary)
                    )
                    OutlinedTextField(
                        value = passwords,
                        onValueChange = { passwords = it },
                        label = { Text("PASSWORDS") },
                        modifier = Modifier.weight(1f),
                        minLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MaterialTheme.colorScheme.primary)
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        Button(
            onClick = {
                if (!isScanning) {
                    isScanning = true
                    results.clear()
                    results.add(">>> INITIATING SCAN VECTOR")
                    scope.launch {
                        runScan(targets, ports, users, passwords) { line ->
                            results.add(line)
                        }
                        results.add(">>> SCAN COMPLETE")
                        isScanning = false
                    }
                }
            },
            enabled = !isScanning,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            if (isScanning) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.Black, strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text("SCANNING", color = Color.Black, fontWeight = FontWeight.Bold)
            } else {
                Text("START SCAN", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(12.dp))

        Text(
            "OUTPUT",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(0.5f),
            modifier = Modifier.padding(bottom = 4.dp)
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(results) { line ->
                val color = when {
                    line.contains("VULN") -> Color(0xFFFF4081)
                    line.contains("→") -> Color(0xFF00E5FF)
                    line.contains("open") -> Color(0xFFFFA726)
                    else -> MaterialTheme.colorScheme.onSurface.copy(0.85f)
                }
                Text(
                    line,
                    color = color,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface.copy(0.4f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

private suspend fun runScan(
    targetsStr: String,
    portsStr: String,
    usersStr: String,
    passwordsStr: String,
    onLine: (String) -> Unit
) {
    val portList = portsStr.split(",").mapNotNull { it.trim().toIntOrNull() }.ifEmpty { listOf(80, 8000) }
    val userList = usersStr.lines().map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf("admin") }
    val passList = passwordsStr.lines().map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf("admin") }

    val targets = parseTargets(targetsStr)
    onLine(">>> TARGETS ${targets.size} | PORTS ${portList.joinToString()}")

    if (targets.isEmpty()) {
        onLine(">>> NO VALID TARGETS")
        return
    }

    coroutineScope {
        val semaphore = Semaphore(8) // limit concurrency
        targets.forEach { target ->
            launch(Dispatchers.IO) {
                semaphore.withPermit {
                    scanTarget(target, portList, userList, passList, onLine)
                }
            }
        }
    }
}

private fun parseTargets(input: String): List<String> {
    val result = mutableListOf<String>()
    input.lines().forEach { raw ->
        val line = raw.trim()
        if (line.isEmpty() || line.startsWith("#")) return@forEach
        when {
            line.contains("/") -> {
                val parts = line.split("/")
                val ip = parts[0]
                val prefix = parts.getOrNull(1)?.toIntOrNull() ?: 32
                if (prefix == 24) {
                    val base = ip.substringBeforeLast(".")
                    for (i in 1..254) result.add("$base.$i")
                } else if (prefix == 16) {
                    val base = ip.substringBeforeLast(".").substringBeforeLast(".")
                    for (i in 0..2) for (j in 1..10) result.add("$base.$i.$j") // limited
                } else result.add(ip)
            }
            line.contains("-") && line.count { it == '.' } >= 6 -> {
                // simple same-subnet range: 192.168.1.1-192.168.1.20
                val (start, end) = line.split("-", limit = 2)
                val startParts = start.split(".")
                val endParts = end.split(".")
                if (startParts.size == 4 && endParts.size == 4 && startParts.take(3) == endParts.take(3)) {
                    val base = startParts.take(3).joinToString(".")
                    val s = startParts[3].toIntOrNull() ?: 1
                    val e = endParts[3].toIntOrNull() ?: s
                    for (i in s..e.coerceAtMost(s + 50)) result.add("$base.$i")
                } else result.add(line)
            }
            else -> result.add(line)
        }
    }
    return result.distinct().take(80)
}

private fun scanTarget(
    target: String,
    ports: List<Int>,
    users: List<String>,
    passes: List<String>,
    onLine: (String) -> Unit
) {
    val ip = target.split(":").first().trim()
    val forced = target.split(":").getOrNull(1)?.toIntOrNull()
    val toScan = forced?.let { listOf(it) } ?: ports

    for (port in toScan) {
        try {
            val conn = URL("http://$ip:$port/").openConnection() as HttpURLConnection
            conn.connectTimeout = 3000
            conn.readTimeout = 3000
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            val code = conn.responseCode
            val body = runCatching {
                (if (code < 400) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText().take(1200) } ?: ""
            }.getOrDefault("")
            val hdrs = conn.headerFields.toString().lowercase()

            var product = "unknown"
            when {
                body.contains("hikvision", true) || body.contains("ivms", true) || hdrs.contains("app-webs") -> product = "hikvision"
                body.contains("dahua", true) || body.contains("dvr", true) -> product = "dahua"
                hdrs.contains("dcs") || body.contains("dlink", true) -> product = "dlink"
                body.contains("geovision", true) -> product = "geovision"
            }

            if (product != "unknown") {
                onLine("$ip:$port → $product (HTTP $code)")
                if (product == "hikvision") {
                    for (u in users) for (p in passes) {
                        try {
                            val token = Base64.encodeToString("$u:$p".toByteArray(), Base64.NO_WRAP)
                            val ac = URL("http://$ip:$port/ISAPI/Security/userCheck").openConnection() as HttpURLConnection
                            ac.setRequestProperty("Authorization", "Basic $token")
                            ac.connectTimeout = 2000
                            ac.readTimeout = 2000
                            if (ac.responseCode == 200) {
                                val txt = ac.inputStream.bufferedReader().use { it.readText() }
                                if (txt.contains("statusValue") && txt.contains("200")) {
                                    onLine("  VULN $ip:$port $product $u:$p")
                                    ac.disconnect()
                                    conn.disconnect()
                                    return
                                }
                            }
                            ac.disconnect()
                        } catch (_: Exception) {}
                    }
                }
            } else if (code in 200..499) {
                onLine("$ip:$port open (HTTP $code)")
            }
            conn.disconnect()
        } catch (_: Exception) {
            // silent closed port
        }
    }
}
