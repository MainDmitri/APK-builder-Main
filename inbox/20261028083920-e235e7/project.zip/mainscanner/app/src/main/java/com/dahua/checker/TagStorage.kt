package com.dahua.checker

import android.content.Context
import android.content.SharedPreferences

/**
 * TagStorage — SharedPreferences-обёртка для тегов на результатах скана.
 *
 * Ключ: "${ip}:${port}"
 * Значение: теги через запятую, напр. "проверено,интересно"
 *
 * Предустановленные теги (предлагаются в UI):
 *   ✅ проверено — уже просмотрели камеру живьём
 *   ⭐ интересно — стоит посмотреть позже
 *   🗑️ мусор     — не интересно / ложный результат
 *   🔒 закрыто   — камера была закрыта / пропала
 *   💎 VIP       — особо ценный результат
 */
class TagStorage(context: Context) {

    companion object {
        private const val PREFS_NAME = "camera_tags"
        private const val SEP = ","

        // Предустановленные теги с emoji
        val PRESET_TAGS = listOf(
            "✅ проверено",
            "⭐ интересно",
            "🗑️ мусор",
            "🔒 закрыто",
            "💎 VIP"
        )
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // Ключ по IP:Port
    private fun key(ip: String, port: Int): String = "$ip:$port"

    /**
     * Возвращает список тегов для данного результата (может быть пустым).
     */
    fun getTags(ip: String, port: Int): List<String> {
        val raw = prefs.getString(key(ip, port), null) ?: return emptyList()
        return raw.split(SEP).map { it.trim() }.filter { it.isNotEmpty() }
    }

    /**
     * Добавляет тег если его ещё нет. Идемпотентно.
     */
    fun addTag(ip: String, port: Int, tag: String) {
        val current = getTags(ip, port).toMutableList()
        val trimmed = tag.trim()
        if (trimmed.isNotEmpty() && trimmed !in current) {
            current.add(trimmed)
            save(ip, port, current)
        }
    }

    /**
     * Удаляет тег если есть.
     */
    fun removeTag(ip: String, port: Int, tag: String) {
        val current = getTags(ip, port).toMutableList()
        if (current.remove(tag.trim())) {
            save(ip, port, current)
        }
    }

    /**
     * Переключает тег: добавляет если нет, удаляет если есть.
     * Возвращает true если тег теперь активен.
     */
    fun toggleTag(ip: String, port: Int, tag: String): Boolean {
        val current = getTags(ip, port).toMutableList()
        val trimmed = tag.trim()
        return if (trimmed in current) {
            current.remove(trimmed)
            save(ip, port, current)
            false
        } else {
            current.add(trimmed)
            save(ip, port, current)
            true
        }
    }

    /**
     * Полностью заменяет список тегов.
     */
    fun setTags(ip: String, port: Int, tags: List<String>) {
        save(ip, port, tags.map { it.trim() }.filter { it.isNotEmpty() }.distinct())
    }

    /**
     * Удаляет все теги для результата.
     */
    fun clearTags(ip: String, port: Int) {
        prefs.edit().remove(key(ip, port)).apply()
    }

    /**
     * Проверяет наличие конкретного тега.
     */
    fun hasTag(ip: String, port: Int, tag: String): Boolean =
        tag.trim() in getTags(ip, port)

    /**
     * Возвращает все ключи у которых есть хотя бы один тег.
     * Формат ключа: "ip:port"
     */
    fun getAllTaggedKeys(): Set<String> =
        prefs.all.keys.toSet()

    /**
     * Возвращает все теги из всех результатов — для фильтра по тегу в StoredTab.
     */
    fun getAllUsedTags(): Set<String> {
        return prefs.all.values
            .filterIsInstance<String>()
            .flatMap { it.split(SEP) }
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toSet()
    }

    private fun save(ip: String, port: Int, tags: List<String>) {
        if (tags.isEmpty()) {
            prefs.edit().remove(key(ip, port)).apply()
        } else {
            prefs.edit().putString(key(ip, port), tags.joinToString(SEP)).apply()
        }
    }
}
