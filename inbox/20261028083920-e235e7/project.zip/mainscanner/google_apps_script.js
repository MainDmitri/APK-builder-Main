// ═══════════════════════════════════════════════════════════════
// Google Apps Script — бэкенд для Main Scanner
// Развёртывание: script.google.com → Новый проект → вставить код
// Деплой → Новое развёртывание → Веб-приложение → Все пользователи
// ═══════════════════════════════════════════════════════════════

const SHEET_NAME = "users";
const ADMIN_KEY = "MainC4yt552_admin_api_key";

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const action = data.action;

    if (action === "validate") {
      return json(validateCode(data.nickname, data.code));
    } else if (action === "generate") {
      if (data.adminKey !== ADMIN_KEY) return json({success: false, error: "Нет доступа"});
      return json(generateCode(data.nickname));
    } else if (action === "list") {
      if (data.adminKey !== ADMIN_KEY) return json({success: false, error: "Нет доступа"});
      return json(listUsers());
    } else if (action === "delete") {
      if (data.adminKey !== ADMIN_KEY) return json({success: false, error: "Нет доступа"});
      return json(deleteUser(data.nickname));
    }

    return json({success: false, error: "Неизвестное действие"});
  } catch (err) {
    return json({success: false, error: err.toString()});
  }
}

function getSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    sheet.appendRow(["nickname", "code", "createdAt"]);
  }
  return sheet;
}

function generateCode(nickname) {
  if (!nickname || nickname.trim() === "") {
    return {success: false, error: "Пустой ник"};
  }
  nickname = nickname.trim();
  const sheet = getSheet();
  const data = sheet.getDataRange().getValues();

  // Проверить, есть ли уже такой ник
  for (let i = 1; i < data.length; i++) {
    if (data[i][0].toString().toLowerCase() === nickname.toLowerCase()) {
      return {success: false, error: "Ник уже существует"};
    }
  }

  // Генерировать уникальный код
  const code = makeCode();
  const now = new Date().getTime();
  sheet.appendRow([nickname, code, now]);

  return {success: true, code: code};
}

function validateCode(nickname, code) {
  if (!nickname || !code) {
    return {success: false, error: "Пустые данные"};
  }
  nickname = nickname.trim();
  code = code.trim().toUpperCase();
  const sheet = getSheet();
  const data = sheet.getDataRange().getValues();

  for (let i = 1; i < data.length; i++) {
    const rowNick = data[i][0].toString().trim();
    const rowCode = data[i][1].toString().trim().toUpperCase();
    if (rowNick.toLowerCase() === nickname.toLowerCase() && rowCode === code) {
      return {success: true};
    }
  }

  return {success: false, error: "Неверный ник или код"};
}

function listUsers() {
  const sheet = getSheet();
  const data = sheet.getDataRange().getValues();
  const users = [];

  for (let i = 1; i < data.length; i++) {
    if (data[i][0].toString().trim() !== "") {
      users.push({
        nickname: data[i][0].toString(),
        code: data[i][1].toString(),
        createdAt: parseInt(data[i][2]) || 0
      });
    }
  }

  return {success: true, users: users};
}

function deleteUser(nickname) {
  if (!nickname) return {success: false, error: "Пустой ник"};
  nickname = nickname.trim();
  const sheet = getSheet();
  const data = sheet.getDataRange().getValues();

  for (let i = data.length - 1; i >= 1; i--) {
    if (data[i][0].toString().trim().toLowerCase() === nickname.toLowerCase()) {
      sheet.deleteRow(i + 1);
      return {success: true};
    }
  }

  return {success: false, error: "Пользователь не найден"};
}

function makeCode() {
  const chars = "0123456789ABCDEF";
  let parts = [];
  for (let p = 0; p < 3; p++) {
    let seg = "";
    for (let c = 0; c < 4; c++) {
      seg += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    parts.push(seg);
  }
  return parts.join("-");
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
