package com.maindmitri.botpanel

/**
 * Правила проекта tgcloud (как у `npx tgcloud`): имена модулей, импорт, локальная проверка кода.
 *
 * Модуль — это файл из папки tgcloud/ без расширения: `schema`, `lib/…`, `handlers/<тип апдейта>`,
 * `endpoints/<имя>`. Обработчики и эндпоинты экспортируют функцию через `export default`.
 */
object Project {
    const val SCHEMA = "schema"

    /** Типы апдейтов Telegram Bot API — допустимые имена в handlers/. */
    val UPDATE_TYPES = listOf(
        "message", "edited_message", "channel_post", "edited_channel_post",
        "business_connection", "business_message", "edited_business_message", "deleted_business_messages",
        "message_reaction", "message_reaction_count", "inline_query", "chosen_inline_result",
        "callback_query", "shipping_query", "pre_checkout_query", "purchased_paid_media",
        "poll", "poll_answer", "my_chat_member", "chat_member", "chat_join_request",
        "chat_boost", "removed_chat_boost",
    )

    val SDK_MODULES = setOf("sdk", "sdk/db", "sdk/api", "sdk/fetch")

    private val SEGMENT = Regex("^[A-Za-z0-9_-]+$")
    private val ENDPOINT_NAME = Regex("^[A-Za-z_][A-Za-z0-9_]*$")
    private const val MAX_SEGMENTS = 8

    /** Приводит ввод пользователя или путь файла к имени модуля: `tgcloud/handlers/message.js` → `handlers/message`. */
    fun normalizeName(raw: String): String {
        var n = raw.trim().replace('\\', '/').trim('/')
        val idx = n.indexOf("tgcloud/")
        if (idx == 0 || (idx > 0 && n[idx - 1] == '/')) n = n.substring(idx + "tgcloud/".length)
        if (n.endsWith(".js")) n = n.dropLast(3)
        return n.trim('/')
    }

    /** null — имя корректно, иначе текст ошибки. */
    fun checkName(name: String): String? {
        if (name == SCHEMA) return null
        val parts = name.split('/')
        if (parts.size < 2) {
            return "«$name»: имя модуля — schema, handlers/<тип>, endpoints/<имя> или lib/<имя>"
        }
        if (parts.size > MAX_SEGMENTS) return "«$name»: слишком много вложенных папок"
        if (parts.any { !SEGMENT.matches(it) }) {
            return "«$name»: допустимы латиница, цифры, _ и - (без пробелов и без .js)"
        }
        return when (parts[0]) {
            "handlers" -> when {
                parts.size != 2 -> "«$name»: в handlers/ нельзя делать подпапки"
                parts[1] !in UPDATE_TYPES ->
                    "«$name»: нет такого типа апдейта. Допустимо: ${UPDATE_TYPES.joinToString()}"
                else -> null
            }
            "endpoints" -> when {
                parts.size != 2 -> "«$name»: в endpoints/ нельзя делать подпапки"
                !ENDPOINT_NAME.matches(parts[1]) -> "«$name»: имя эндпоинта — латиница, цифры и _, не с цифры"
                else -> null
            }
            "lib" -> null
            else -> "«$name»: модуль должен лежать в handlers/, endpoints/ или lib/ (или называться schema)"
        }
    }

    /** Модуль по имени открытого файла: message.js → handlers/message, schema.js → schema, иначе lib/<имя>. */
    fun guessName(fileName: String): String {
        val base = fileName.substringAfterLast('/').substringBeforeLast(".js")
            .replace(Regex("""\s*\(\d+\)$"""), "")
            .trim()
        return when {
            base == SCHEMA -> SCHEMA
            base in UPDATE_TYPES -> "handlers/$base"
            else -> "lib/" + base.replace(Regex("[^A-Za-z0-9_-]"), "_").ifEmpty { "module" }
        }
    }

    /**
     * Имя модуля по пути внутри ZIP. Берётся всё после папки tgcloud/, иначе путь, который
     * начинается с handlers/, endpoints/, lib/ или равен schema.js (на любой глубине архива).
     */
    fun moduleFromArchivePath(path: String): String? {
        val p = path.replace('\\', '/').trim('/')
        if (!p.endsWith(".js")) return null
        val parts = p.split('/')
        if (parts.any { it.startsWith(".") || it == "node_modules" }) return null
        val tg = parts.indexOf("tgcloud")
        val tail = if (tg >= 0) {
            parts.drop(tg + 1)
        } else {
            val start = parts.indexOfFirst { it == "handlers" || it == "endpoints" || it == "lib" }
            when {
                start >= 0 && start < parts.size - 1 -> parts.drop(start)
                parts.last() == "schema.js" -> listOf("schema.js")
                else -> return null
            }
        }
        val name = tail.joinToString("/").dropLast(3)
        return if (checkName(name) == null) name else null
    }

    /** Заготовка нового модуля (как `npx tgcloud add`). */
    fun template(name: String): String {
        val base = name.substringAfterLast('/')
        return when {
            name == SCHEMA ->
                """
                |import { table, integer, text } from 'sdk/db';
                |
                |// Таблицы базы — именованные экспорты. Деплой не меняет базу: изменения применяет миграция.
                |// export const users = table('users', {
                |//   id:   integer('id').primaryKey({ autoIncrement: true }),
                |//   name: text('name').notNull(),
                |// });
                |""".trimMargin()
            name.startsWith("handlers/") ->
                """
                |import { api } from 'sdk';
                |
                |// Вызывается на каждый апдейт «$base»
                |export default async function ($base, ctx) {
                |}
                |""".trimMargin()
            name.startsWith("endpoints/") ->
                """
                |import { EndpointError } from 'sdk';
                |
                |// POST /api/$base из Mini App; ctx.initData уже проверена платформой
                |export default async function (input, ctx) {
                |  return {};
                |}
                |""".trimMargin()
            else ->
                """
                |// $name — общий модуль. Импорт из обработчика: import { … } from '../$name.js';
                |""".trimMargin()
        }
    }

    // ───────────────────────── Проверка кода ─────────────────────────

    data class Issue(val module: String, val line: Int, val message: String, val error: Boolean) {
        override fun toString(): String =
            (if (error) "✗ " else "! ") + module + (if (line > 0) ":$line" else "") + " — " + message
    }

    private val IMPORT_SPEC = Regex("""\b(from|import)\s*\(?\s*(['"])([^'"\n]*)\2""")
    private val RE_REQUIRE = Regex("""(?<![.\w$])require\s*\(""")
    private val RE_PROCESS = Regex("""(?<![.\w$])process\s*\.\s*(env|argv|exit|cwd)\b""")
    private val RE_MODULE_EXPORTS = Regex("""(?<![.\w$])(module\s*\.\s*exports|exports\s*\.\s*[A-Za-z_$])""")
    private val RE_DIRNAME = Regex("""(?<![.\w$])(__dirname|__filename)\b""")
    private val RE_INTERFACE = Regex("""^\s*(export\s+)?interface\s+[A-Za-z_$][\w$]*\s*[{<]""")
    private val RE_ENUM = Regex("""^\s*(export\s+)?(const\s+)?enum\s+[A-Za-z_$][\w$]*\s*\{""")
    private val RE_TYPE_ALIAS = Regex("""^\s*(export\s+)?type\s+[A-Za-z_$][\w$]*\s*(<[^>]*>)?\s*=""")
    private val RE_IMPORT_TYPE = Regex("""^\s*import\s+type\b""")
    private val RE_EXPORT_DEFAULT = Regex("""\bexport\s+default\b|\bexport\s*\{[^}]*\bas\s+default\b""")
    private val RE_POLLING = Regex("""\b(startPolling|bot\s*\.\s*launch|getUpdates|setWebhook)\b""")

    private val PACKAGE_HINTS = mapOf(
        "telegraf" to "Telegraf не нужен: обработчики — это handlers/<тип>.js, Bot API — api из 'sdk'",
        "grammy" to "grammY не нужен: обработчики — это handlers/<тип>.js, Bot API — api из 'sdk'",
        "node-telegram-bot-api" to "библиотека не нужна: Bot API — api из 'sdk'",
        "axios" to "для HTTP используйте fetch из 'sdk'",
        "node-fetch" to "для HTTP используйте fetch из 'sdk'",
        "dotenv" to "файлов .env в облаке нет, токен бота не нужен",
    )

    private val RE_DB_USE = Regex("""\bdb\s*\.\s*(select|insert|update|delete|run|all|get|values|query|\${'$'}count|transaction|batch)\b""")

    /** Работает ли код с базой (db.select/insert/run/… из 'sdk'). */
    fun usesDatabase(code: String): Boolean = RE_DB_USE.containsMatchIn(blank(code).text)

    /** Проверка всего проекта: имена модулей, импорты, export default, синтаксис скобок и строк. */
    fun lint(modules: Map<String, String>): List<Issue> {
        val names = modules.keys
        return modules.flatMap { (name, code) -> lintModule(name, code, names) }
    }

    fun lintModule(name: String, code: String, all: Set<String>): List<Issue> {
        val issues = mutableListOf<Issue>()
        checkName(name)?.let { issues.add(Issue(name, 0, it, true)) }
        val runnable = name.startsWith("handlers/") || name.startsWith("endpoints/")
        if (code.isBlank()) {
            issues.add(
                Issue(
                    name, 0,
                    if (name.startsWith("handlers/")) "файл пустой — апдейты этого типа будут игнорироваться"
                    else "файл пустой",
                    false,
                )
            )
            return issues
        }

        val scan = blank(code)
        scan.problems.forEach { (line, msg) -> issues.add(Issue(name, line, msg, true)) }
        val rawLines = code.split('\n')
        val lines = scan.text.split('\n')

        lines.forEachIndexed { idx, line ->
            val ln = idx + 1
            IMPORT_SPEC.findAll(rawLines.getOrElse(idx) { "" })
                .filter { line.startsWith(it.groupValues[1], it.range.first) }
                .forEach { m -> checkImport(name, m.groupValues[3], all)?.let { issues.add(Issue(name, ln, it.first, it.second)) } }
            if (RE_REQUIRE.containsMatchIn(line)) issues.add(Issue(name, ln, "require() нет — используйте import", true))
            if (RE_PROCESS.containsMatchIn(line)) issues.add(Issue(name, ln, "process нет: это не Node.js, переменных окружения нет", true))
            if (RE_MODULE_EXPORTS.containsMatchIn(line)) issues.add(Issue(name, ln, "module.exports/exports нет — используйте export", true))
            if (RE_DIRNAME.containsMatchIn(line)) issues.add(Issue(name, ln, "__dirname/__filename нет: файловой системы в облаке нет", true))
            if (RE_INTERFACE.containsMatchIn(line)) issues.add(Issue(name, ln, "TypeScript (interface) не поддерживается — только JavaScript", true))
            if (RE_ENUM.containsMatchIn(line)) issues.add(Issue(name, ln, "TypeScript (enum) не поддерживается — только JavaScript", true))
            if (RE_TYPE_ALIAS.containsMatchIn(line)) issues.add(Issue(name, ln, "TypeScript (type) не поддерживается — только JavaScript", true))
            if (RE_IMPORT_TYPE.containsMatchIn(line)) issues.add(Issue(name, ln, "TypeScript (import type) не поддерживается", true))
            if (RE_POLLING.containsMatchIn(line)) {
                issues.add(Issue(name, ln, "polling и setWebhook не нужны: платформа сама вызывает обработчик и держит вебхук", false))
            }
        }

        if (name != SCHEMA && SCHEMA !in all && RE_DB_USE.containsMatchIn(scan.text)) {
            issues.add(
                Issue(
                    name, 0,
                    "код работает с базой (db), но в проекте нет модуля schema — в облаке будет «no such table». " +
                        "Добавьте schema с таблицами, задеплойте и примените миграцию",
                    false,
                )
            )
        }
        if (runnable && !RE_EXPORT_DEFAULT.containsMatchIn(scan.text)) {
            issues.add(
                Issue(
                    name, 0,
                    "нет export default — платформа вызывает именно его: export default async function (payload, ctx) { … }",
                    true,
                )
            )
        }
        return issues
    }

    /** Проверка одного спецификатора импорта. Возвращает (текст, ошибка?) или null, если всё в порядке. */
    private fun checkImport(module: String, spec: String, all: Set<String>): Pair<String, Boolean>? {
        if (spec == "sdk" || spec.startsWith("sdk/")) {
            return if (spec in SDK_MODULES) null
            else "'$spec': такого модуля SDK нет. Есть ${SDK_MODULES.joinToString { "'$it'" }}" to true
        }
        if (spec.startsWith("/")) return "'$spec': абсолютные пути не работают — пишите '../lib/x.js'" to true
        if (spec.startsWith("./") || spec.startsWith("../")) {
            if (!spec.endsWith(".js")) return "'$spec': относительный импорт должен заканчиваться на .js ('$spec.js')" to true
            val target = resolveRelative(module, spec.dropLast(3))
                ?: return "'$spec': путь выходит за пределы папки tgcloud" to true
            return if (target in all) null
            else "'$spec' → модуль «$target» не найден в проекте" to true
        }
        val bare = spec.removeSuffix(".js")
        if (bare in all) return null
        val pkg = spec.split('/').let { if (spec.startsWith("@") && it.size > 1) it[0] + "/" + it[1] else it[0] }
        val hint = PACKAGE_HINTS[pkg] ?: "npm-пакетов в облаке нет, доступны только 'sdk' и модули проекта"
        return "импорт '$spec' не сработает: $hint" to true
    }

    private fun resolveRelative(module: String, rel: String): String? {
        val stack = module.split('/').dropLast(1).toMutableList()
        for (seg in rel.split('/')) {
            when (seg) {
                "", "." -> {}
                ".." -> if (stack.isEmpty()) return null else stack.removeAt(stack.size - 1)
                else -> stack.add(seg)
            }
        }
        return stack.joinToString("/")
    }

    // ───────────────────────── Лексический разбор ─────────────────────────

    data class Scan(val text: String, val problems: List<Pair<Int, String>>)

    private val REGEX_KEYWORDS = setOf(
        "return", "typeof", "case", "do", "else", "in", "of", "new", "delete", "void",
        "throw", "yield", "await", "instanceof",
    )

    /**
     * Заменяет содержимое строк, шаблонных строк, комментариев и регулярных выражений пробелами
     * (переводы строк и длина сохраняются, символ в символ), заодно проверяя незакрытые строки,
     * комментарии и парность скобок.
     */
    fun blank(src: String): Scan {
        val out = StringBuilder(src.length)
        val problems = mutableListOf<Pair<Int, String>>()
        val brackets = ArrayDeque<Pair<Char, Int>>()
        val templateDepths = ArrayDeque<Int>()
        var braceDepth = 0
        var line = 1
        var i = 0
        var lastSig: Char? = null
        val word = StringBuilder()
        var lastWord = ""

        fun put(c: Char) {
            out.append(c)
            if (c == '\n') line++
        }
        fun hide(c: Char) = put(if (c == '\n') '\n' else ' ')

        // Шаблонная строка с позиции i (после ` или после } закрытия ${…}). Возвращает true, если вошли в ${.
        fun template(): Boolean {
            val startLine = line
            while (i < src.length) {
                val c = src[i]
                when {
                    c == '\\' && i + 1 < src.length -> { hide(c); hide(src[i + 1]); i += 2 }
                    c == '`' -> { hide(c); i++; return false }
                    c == '$' && i + 1 < src.length && src[i + 1] == '{' -> {
                        hide(c); hide('{'); i += 2
                        braceDepth++
                        templateDepths.addLast(braceDepth)
                        return true
                    }
                    else -> { hide(c); i++ }
                }
            }
            problems.add(startLine to "шаблонная строка ` не закрыта")
            return false
        }

        fun regexEnd(start: Int): Int {
            var j = start + 1
            var inClass = false
            while (j < src.length) {
                val c = src[j]
                when {
                    c == '\n' -> return -1
                    c == '\\' -> j++
                    c == '[' -> inClass = true
                    c == ']' -> inClass = false
                    c == '/' && !inClass -> {
                        j++
                        while (j < src.length && (src[j].isLetter())) j++
                        return j
                    }
                }
                j++
            }
            return -1
        }

        while (i < src.length) {
            val c = src[i]
            if (c.isLetterOrDigit() || c == '_' || c == '$') {
                word.append(c)
            } else if (word.isNotEmpty()) {
                lastWord = word.toString(); word.clear()
            }
            when {
                c == '/' && i + 1 < src.length && src[i + 1] == '/' -> {
                    while (i < src.length && src[i] != '\n') { hide(src[i]); i++ }
                }
                c == '/' && i + 1 < src.length && src[i + 1] == '*' -> {
                    val startLine = line
                    hide(c); hide('*'); i += 2
                    var closed = false
                    while (i < src.length) {
                        if (src[i] == '*' && i + 1 < src.length && src[i + 1] == '/') {
                            hide('*'); hide('/'); i += 2; closed = true; break
                        }
                        hide(src[i]); i++
                    }
                    if (!closed) problems.add(startLine to "комментарий /* не закрыт")
                }
                c == '/' && (lastSig == null || lastSig in "(,=:[!&|?{};+-*%<>~^" ||
                    (lastSig.isLetterOrDigit() && lastWord in REGEX_KEYWORDS)) -> {
                    val end = regexEnd(i)
                    if (end < 0) {
                        put(c); lastSig = c; i++
                    } else {
                        while (i < end) { hide(src[i]); i++ }
                        lastSig = 'r'
                        lastWord = ""
                    }
                }
                c == '"' || c == '\'' -> {
                    val startLine = line
                    hide(c); i++
                    var closed = false
                    while (i < src.length) {
                        val d = src[i]
                        if (d == '\\' && i + 1 < src.length) { hide(d); hide(src[i + 1]); i += 2; continue }
                        if (d == '\n') break
                        hide(d); i++
                        if (d == c) { closed = true; break }
                    }
                    if (!closed) problems.add(startLine to "строка с $c не закрыта")
                    lastSig = 's'; lastWord = ""
                }
                c == '`' -> {
                    hide(c); i++
                    template()
                    lastSig = 's'; lastWord = ""
                }
                else -> {
                    when (c) {
                        '(', '[' -> brackets.addLast(c to line)
                        '{' -> { brackets.addLast(c to line); braceDepth++ }
                        ')', ']', '}' -> {
                            if (c == '}' && templateDepths.isNotEmpty() && templateDepths.last() == braceDepth) {
                                // Конец ${…} — продолжаем шаблонную строку.
                                templateDepths.removeLast()
                                braceDepth--
                                hide(c); i++
                                template()
                                lastSig = 's'; lastWord = ""
                                continue
                            }
                            val open = if (c == ')') '(' else if (c == ']') '[' else '{'
                            val top = brackets.removeLastOrNull()
                            if (top == null) {
                                problems.add(line to "лишняя закрывающая скобка '$c'")
                            } else if (top.first != open) {
                                problems.add(line to "скобка '$c' не подходит к '${top.first}' со строки ${top.second}")
                            }
                            if (c == '}') braceDepth--
                        }
                    }
                    put(c)
                    if (!c.isWhitespace()) lastSig = c
                    i++
                }
            }
        }
        brackets.forEach { (ch, ln) -> problems.add(ln to "скобка '$ch' не закрыта") }
        return Scan(out.toString(), problems.sortedBy { it.first })
    }
}
