package com.maindmitri.botpanel

import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Импорт модулей из отдельных .js-файлов или из ZIP с папкой проекта tgcloud. */
object Importer {
    data class Result(val modules: Map<String, String>, val notes: List<String>)

    private const val MAX_TOTAL_BYTES = 5 * 1024 * 1024

    /** `files` — пары (имя файла, содержимое). */
    fun fromFiles(files: List<Pair<String, String>>): Result {
        val modules = sortedMapOf<String, String>()
        val notes = mutableListOf<String>()
        for ((fileName, text) in files) {
            val split = SingleFile.split(text)
            if (split != null && Project.guessName(fileName).startsWith("lib/")) {
                split.keys.filter { it in modules }.forEach { notes.add("$it перезаписан модулем из $fileName") }
                modules.putAll(split)
                notes.add("$fileName — однофайловый бот, разложен на ${split.keys.joinToString()}")
            } else {
                val name = Project.guessName(fileName)
                if (name in modules) notes.add("$name перезаписан файлом $fileName")
                modules[name] = text
                notes.add("$fileName → $name")
            }
        }
        return Result(modules, notes)
    }

    fun fromZip(input: InputStream): Result {
        val modules = sortedMapOf<String, String>()
        val notes = mutableListOf<String>()
        var total = 0L
        ZipInputStream(input).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.isDirectory) continue
                val path = entry.name
                val name = Project.moduleFromArchivePath(path)
                if (name == null) {
                    if (path.endsWith(".js") && !path.contains("node_modules/")) notes.add("пропущен $path — не модуль tgcloud")
                    continue
                }
                val bytes = zip.readBytes()
                total += bytes.size
                if (total > MAX_TOTAL_BYTES) throw IllegalStateException("В архиве больше 5 МБ кода")
                modules[name] = String(bytes, Charsets.UTF_8)
                notes.add("$path → $name")
            }
        }
        if (modules.isEmpty()) {
            throw IllegalStateException(
                "В архиве нет модулей tgcloud. Нужна папка tgcloud/ (или handlers/, lib/, endpoints/, schema.js) с .js-файлами"
            )
        }
        return Result(modules, notes)
    }

    /** Пишет модули в ZIP как папку tgcloud/ (тот же формат, что принимает fromZip и CLI). */
    fun toZip(modules: Map<String, String>, out: OutputStream) {
        ZipOutputStream(out).use { zip ->
            for ((name, code) in modules) {
                zip.putNextEntry(ZipEntry("tgcloud/$name.js"))
                zip.write(code.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        }
    }
}
