package com.maindmitri.botpanel

import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    PanelScreen(viewModel())
                }
            }
        }
    }
}

@Composable
private fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val context = LocalContext.current
    val colors = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = colors, content = content)
}

private val Mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp)

@Composable
private fun PanelScreen(vm: PanelViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }

    Dialogs(vm)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .imePadding(),
    ) {
        Text(
            "Bot Panel",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 4.dp),
        )
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Проект") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Запуск") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Логи (${vm.logs.size})") })
        }
        if (vm.busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        Box(modifier = Modifier.weight(1f)) {
            when (tab) {
                0 -> if (vm.openModule != null) ModuleEditor(vm) else ProjectTab(vm)
                1 -> RunTab(vm, onShowLogs = { tab = 2 })
                else -> LogsTab(vm)
            }
        }
    }
}

// ───────────────────────── Проект ─────────────────────────

@Composable
private fun ProjectTab(vm: PanelViewModel) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var showToken by rememberSaveable { mutableStateOf(false) }
    var adding by rememberSaveable { mutableStateOf(false) }
    val openFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        vm.importFiles(uris)
    }
    val openZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importZip(uri)
    }
    val saveZip = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) vm.exportZip(uri)
    }
    val issues = remember(vm.modules) { Project.lint(vm.modules) }

    if (adding) AddModuleDialog(vm, onDismiss = { adding = false })

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        OutlinedTextField(
            value = vm.token,
            onValueChange = vm::updateToken,
            label = { Text("CLI-токен (app…:…)") },
            supportingText = { Text("BotFather → ваш бот → Serverless → CLI Access → Access token") },
            singleLine = true,
            visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            trailingIcon = {
                TextButton(onClick = { showToken = !showToken }) { Text(if (showToken) "Скрыть" else "Показать") }
            },
            modifier = Modifier.fillMaxWidth(),
        )

        SectionTitle("Модули (папка tgcloud/)")
        Text(
            "Как у npx tgcloud: handlers/<тип апдейта>.js с export default, lib/ — общий код, " +
                "endpoints/ — функции Mini App, schema — таблицы базы.",
            style = MaterialTheme.typography.bodySmall,
        )
        ButtonRow(
            "+ Модуль" to { adding = true },
            "Файлы .js" to { openFiles.launch(arrayOf("*/*")) },
        )
        ButtonRow(
            "ZIP проекта" to { openZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) },
            "Из облака" to vm::pull,
        )
        ButtonRow(
            "Промт для ИИ" to {
                clipboard.setText(AnnotatedString(vm.aiPrompt))
                Toast.makeText(context, "Промт скопирован — допишите задачу бота", Toast.LENGTH_SHORT).show()
            },
            "Пример" to vm::loadExample,
        )
        OutlinedButton(
            onClick = { saveZip.launch("tgcloud-project.zip") },
            enabled = vm.modules.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Экспорт проекта в ZIP") }

        if (vm.modules.isEmpty()) {
            Text(
                "Модулей нет. Откройте свои .js-файлы (message.js станет handlers/message), " +
                    "ZIP с папкой tgcloud или скачайте то, что уже задеплоено, кнопкой «Из облака».",
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        vm.modules.forEach { (name, code) ->
            val own = issues.filter { it.module == name }
            val errors = own.count { it.error }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { vm.open(name) },
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(name, style = MaterialTheme.typography.titleSmall, fontFamily = FontFamily.Monospace)
                    val lines = if (code.isEmpty()) 0 else code.count { it == '\n' } + 1
                    val status = when {
                        errors > 0 -> "ошибок: $errors"
                        own.isNotEmpty() -> "предупреждений: ${own.size}"
                        else -> "ок"
                    }
                    Text(
                        "$lines строк · $status",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (errors > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun ModuleEditor(vm: PanelViewModel) {
    val name = vm.openModule ?: return
    val code = vm.modules[name] ?: run { vm.open(null); return }
    var renaming by rememberSaveable { mutableStateOf(false) }
    var deleting by rememberSaveable { mutableStateOf(false) }
    val issues = remember(code, vm.modules.keys) { Project.lintModule(name, code, vm.modules.keys) }

    BackHandler { vm.open(null) }

    if (renaming) {
        NameDialog(
            title = "Переименовать модуль",
            initial = name,
            confirm = "Переименовать",
            onConfirm = { vm.renameModule(name, it) },
            onDismiss = { renaming = false },
        )
    }
    if (deleting) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            title = { Text("Удалить $name?") },
            text = { Text("Модуль удалится из проекта на телефоне. В облаке он исчезнет при следующем деплое.") },
            confirmButton = { TextButton(onClick = { deleting = false; vm.deleteModule(name) }) { Text("Удалить") } },
            dismissButton = { TextButton(onClick = { deleting = false }) { Text("Отмена") } },
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { vm.open(null) }) { Text("← Модули") }
            OutlinedButton(onClick = { renaming = true }) { Text("Имя") }
            OutlinedButton(onClick = { deleting = true }) { Text("Удалить") }
        }
        Text(name, style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Monospace)
        if (issues.isEmpty()) {
            Text("Проблем не найдено", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        } else {
            issues.forEach { issue ->
                Text(
                    (if (issue.line > 0) "строка ${issue.line}: " else "") + issue.message,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (issue.error) MaterialTheme.colorScheme.error else Color(0xFFB26A00),
                )
            }
        }
        OutlinedTextField(
            value = code,
            onValueChange = { vm.updateModule(name, it) },
            textStyle = Mono,
            minLines = 12,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun AddModuleDialog(vm: PanelViewModel, onDismiss: () -> Unit) {
    var name by rememberSaveable { mutableStateOf("handlers/") }
    var error by remember { mutableStateOf<String?>(null) }
    val suggestions = listOf(
        "handlers/message", "handlers/callback_query", "handlers/pre_checkout_query",
        "handlers/inline_query", "handlers/my_chat_member", "schema", "lib/", "endpoints/",
    ).filter { it !in vm.modules }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый модуль") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; error = null },
                    label = { Text("Имя модуля") },
                    singleLine = true,
                    isError = error != null,
                    supportingText = error?.let { { Text(it) } },
                    modifier = Modifier.fillMaxWidth(),
                )
                suggestions.forEach { s ->
                    TextButton(onClick = { name = s; error = null }) { Text(s, fontFamily = FontFamily.Monospace) }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val err = vm.addModule(name)
                if (err == null) onDismiss() else error = err
            }) { Text("Создать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@Composable
private fun NameDialog(
    title: String,
    initial: String,
    confirm: String,
    onConfirm: (String) -> String?,
    onDismiss: () -> Unit,
) {
    var name by rememberSaveable { mutableStateOf(initial) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it; error = null },
                singleLine = true,
                isError = error != null,
                supportingText = error?.let { { Text(it) } },
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = {
                val err = onConfirm(name)
                if (err == null) onDismiss() else error = err
            }) { Text(confirm) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

// ───────────────────────── Запуск ─────────────────────────

@Composable
private fun RunTab(vm: PanelViewModel, onShowLogs: () -> Unit) {
    var moduleMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionTitle("Деплой")
        Button(onClick = vm::diagnose, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) {
            Text("🔍 Диагностика: почему бот не отвечает")
        }
        OutlinedButton(onClick = vm::check, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) {
            Text("Проверить код")
        }
        Button(onClick = vm::deploy, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) {
            Text("🚀 Задеплоить проект")
        }
        ButtonRow(
            "Статус" to vm::status,
            "Синхр. вебхук" to { vm.syncWebhook(dropPending = false) },
            enabled = !vm.busy,
        )
        OutlinedButton(
            onClick = { vm.syncWebhook(dropPending = true) },
            enabled = !vm.busy,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Синхр. вебхук и сбросить очередь апдейтов") }

        HorizontalDivider()
        SectionTitle("База данных")
        Text(
            "Деплой не меняет базу: таблицы из schema создаются миграцией (как npx tgcloud migrate).",
            style = MaterialTheme.typography.bodySmall,
        )
        OutlinedButton(onClick = vm::checkDatabase, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) {
            Text("Проверить базу и применить миграцию")
        }

        HorizontalDivider()
        SectionTitle("Запуск без деплоя (как tgcloud run)")
        Box {
            OutlinedButton(onClick = { moduleMenu = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Модуль: ${vm.runModule.ifEmpty { "выберите" }}", fontFamily = FontFamily.Monospace)
            }
            DropdownMenu(expanded = moduleMenu, onDismissRequest = { moduleMenu = false }) {
                if (vm.runnableModules.isEmpty()) {
                    DropdownMenuItem(text = { Text("Нет handlers/ или endpoints/") }, onClick = { moduleMenu = false })
                }
                vm.runnableModules.forEach { m ->
                    DropdownMenuItem(
                        text = { Text(m, fontFamily = FontFamily.Monospace) },
                        onClick = { vm.updateRunModule(m); vm.fillArgsTemplate(); moduleMenu = false },
                    )
                }
            }
        }
        OutlinedTextField(
            value = vm.testUserId,
            onValueChange = vm::updateTestUserId,
            label = { Text("Ваш Telegram ID") },
            supportingText = { Text("Узнать: @userinfobot. Сначала напишите боту, иначе он не сможет ответить") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = vm.testText,
            onValueChange = vm::updateTestText,
            label = { Text("Текст / data кнопки / запрос") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedButton(onClick = vm::fillArgsTemplate, modifier = Modifier.fillMaxWidth()) {
            Text("Заполнить args по шаблону")
        }
        OutlinedTextField(
            value = vm.runArgs,
            onValueChange = vm::updateRunArgs,
            label = { Text("args (JSON — payload апдейта)") },
            textStyle = Mono,
            minLines = 3,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 300.dp),
        )
        OutlinedTextField(
            value = vm.runCtx,
            onValueChange = vm::updateRunCtx,
            label = { Text("ctx (JSON)") },
            textStyle = Mono,
            minLines = 1,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 200.dp),
        )
        Button(onClick = vm::test, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) {
            Text("▶ Выполнить в облаке")
        }

        if (vm.output.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (vm.outputIsError) MaterialTheme.colorScheme.errorContainer
                    else MaterialTheme.colorScheme.surfaceVariant,
                ),
                modifier = Modifier.fillMaxWidth(),
            ) {
                SelectionContainer {
                    Text(vm.output, style = Mono, modifier = Modifier.padding(12.dp))
                }
            }
            TextButton(onClick = onShowLogs) { Text("Полный журнал запросов →") }
        }
    }
}

// ───────────────────────── Логи ─────────────────────────

@Composable
private fun LogsTab(vm: PanelViewModel) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val listState = rememberLazyListState()
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { it.write(vm.logsText().toByteArray(Charsets.UTF_8)) }
                Toast.makeText(context, "Журнал сохранён", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Не удалось сохранить: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    LaunchedEffect(vm.logs.size) {
        if (vm.logs.isNotEmpty()) listState.scrollToItem(vm.logs.size - 1)
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
        ButtonRow(
            "Копировать" to {
                clipboard.setText(AnnotatedString(vm.logsText()))
                Toast.makeText(context, "Журнал скопирован", Toast.LENGTH_SHORT).show()
            },
            "Сохранить" to { save.launch("botpanel-log.txt") },
            "Очистить" to vm::clearLogs,
        )
        if (vm.logs.isEmpty()) {
            Text(
                "Здесь будет каждый запрос к облаку и полный ответ сервера: ошибки компиляции, " +
                    "лог выполнения, параметры ошибок.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 12.dp),
            )
        }
        SelectionContainer {
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                itemsIndexed(vm.logs) { _, entry ->
                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                        Text(
                            "[${entry.time}] ${entry.title}",
                            style = Mono,
                            color = when {
                                entry.title.startsWith("✗") -> MaterialTheme.colorScheme.error
                                entry.title.startsWith("✓") -> MaterialTheme.colorScheme.primary
                                else -> MaterialTheme.colorScheme.onSurface
                            },
                        )
                        if (entry.body.isNotEmpty()) {
                            Text(entry.body, style = Mono, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        HorizontalDivider(modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
        }
    }
}

// ───────────────────────── Общие диалоги ─────────────────────────

@Composable
private fun Dialogs(vm: PanelViewModel) {
    vm.pendingDeploy?.let { plan ->
        AlertDialog(
            onDismissRequest = vm::cancelDeploy,
            title = { Text("Удалить модули в облаке?") },
            text = {
                Text(
                    "Деплой делает облако точной копией проекта. Этих модулей нет на телефоне, и они будут удалены:\n\n" +
                        plan.deletions.joinToString("\n") +
                        "\n\nЕсли они нужны, отмените и нажмите «Из облака»."
                )
            },
            confirmButton = { TextButton(onClick = vm::confirmDeploy) { Text("Задеплоить") } },
            dismissButton = { TextButton(onClick = vm::cancelDeploy) { Text("Отмена") } },
        )
    }
    vm.pendingPull?.let { cloud ->
        AlertDialog(
            onDismissRequest = vm::cancelPull,
            title = { Text("Заменить проект облачным?") },
            text = {
                Text("Модули на телефоне будут заменены тем, что сейчас задеплоено:\n\n" + cloud.keys.sorted().joinToString("\n"))
            },
            confirmButton = { TextButton(onClick = vm::confirmPull) { Text("Заменить") } },
            dismissButton = { TextButton(onClick = vm::cancelPull) { Text("Отмена") } },
        )
    }
    vm.pendingMigration?.let { changes ->
        val hasWarnings = changes.any { it.optString("status") == "warning" }
        AlertDialog(
            onDismissRequest = vm::dismissMigration,
            title = { Text("Миграция базы: ${changes.size} изм.") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(changes.joinToString("\n\n") { TgCloudApi.describeChange(it) }, style = Mono)
                    Text(
                        "\n«Безопасные» — только изменения без риска для данных. " +
                            "«Все» — ещё и с предупреждениями (могут затронуть данные). " +
                            "Изменения «только вручную» приложение не применяет.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            },
            confirmButton = {
                Row {
                    if (hasWarnings) TextButton(onClick = { vm.applyMigration(includeWarnings = true) }) { Text("Все") }
                    TextButton(onClick = { vm.applyMigration(includeWarnings = false) }) { Text("Безопасные") }
                }
            },
            dismissButton = { TextButton(onClick = vm::dismissMigration) { Text("Позже") } },
        )
    }
    vm.pendingImport?.let { result ->
        AlertDialog(
            onDismissRequest = vm::cancelImport,
            title = { Text("Импорт: ${result.modules.size} модул.") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(result.notes.joinToString("\n"), style = Mono)
                    if (vm.modules.isNotEmpty()) {
                        Text(
                            "\n«Добавить» — заменит только модули с такими же именами. «Заменить всё» — проект станет ровно таким.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            },
            confirmButton = {
                Row {
                    if (vm.modules.isNotEmpty()) TextButton(onClick = { vm.applyImport(replace = true) }) { Text("Заменить всё") }
                    TextButton(onClick = { vm.applyImport(replace = false) }) { Text("Добавить") }
                }
            },
            dismissButton = { TextButton(onClick = vm::cancelImport) { Text("Отмена") } },
        )
    }
}

@Composable
private fun ButtonRow(vararg buttons: Pair<String, () -> Unit>, enabled: Boolean = true) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        buttons.forEach { (label, action) ->
            OutlinedButton(onClick = action, enabled = enabled, modifier = Modifier.weight(1f)) { Text(label) }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
}
