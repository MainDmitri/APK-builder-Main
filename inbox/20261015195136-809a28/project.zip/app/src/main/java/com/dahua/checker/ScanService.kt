package com.dahua.checker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

class ScanService : Service() {

    companion object {
        const val CHANNEL_ID = "dahua_scan"
        const val NOTIFICATION_ID = 1
        const val ACTION_START = "START_SCAN"
        const val ACTION_STOP = "STOP_SCAN"
        const val EXTRA_IPS = "ips"
        const val EXTRA_PORT = "port"
    }

    inner class ScanBinder : Binder() {
        fun getService(): ScanService = this@ScanService
    }

    private val binder = ScanBinder()
    private var scanner: DahuaScanner? = null
    private var scanJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val _progress = MutableStateFlow<ScanProgress?>(null)
    val progress: StateFlow<ScanProgress?> = _progress

    private val _results = MutableSharedFlow<ScanResult>(extraBufferCapacity = 256)
    val results: SharedFlow<ScanResult> = _results

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val ipsArray = intent.getStringArrayExtra(EXTRA_IPS) ?: return START_NOT_STICKY
                val port = intent.getIntExtra(EXTRA_PORT, DahuaScanner.DEFAULT_PORT)
                startScan(ipsArray.toList(), port)
            }
            ACTION_STOP -> {
                stopScan()
            }
        }
        return START_NOT_STICKY
    }

    private fun startScan(ips: List<String>, port: Int) {
        if (_isScanning.value) return

        val notification = buildNotification("Сканирование...", 0, 0)
        startForeground(NOTIFICATION_ID, notification)
        acquireWakeLock()

        _isScanning.value = true
        _progress.value = ScanProgress(ips.size, 0, 0, 0, 0)

        val s = DahuaScanner()
        scanner = s

        scanJob = scope.launch {
            try {
                s.scan(
                    ips = ips,
                    port = port,
                    onResult = { r ->
                        _results.emit(r)
                    },
                    onProgress = { p ->
                        _progress.value = p
                        updateNotification(p)
                        if (p.finished || p.cancelled) {
                            _isScanning.value = false
                            releaseWakeLock()
                            stopForeground(STOP_FOREGROUND_DETACH)
                            stopSelf()
                        }
                    }
                )
            } catch (_: Exception) {
                _isScanning.value = false
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_DETACH)
                stopSelf()
            }
        }
    }

    fun stopScan() {
        scanner?.cancelled = true
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DahuaChecker::ScanWakeLock")
        wakeLock?.acquire(60 * 60 * 1000L) // макс 1 час
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {}
        wakeLock = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Dahua Scanner",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Сканирование камер"
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String, checked: Int, total: Int): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, ScanService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("Dahua Scanner")
            .setContentText(text)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .addAction(android.R.drawable.ic_media_pause, "Стоп", stopPending)

        if (total > 0) {
            builder.setProgress(total, checked, false)
        }

        return builder.build()
    }

    private fun updateNotification(p: ScanProgress) {
        val text = if (p.finished) {
            "Завершено: ${p.successful} найдено, ${p.blocked} заблокировано"
        } else if (p.cancelled) {
            "Отменено: ${p.checked}/${p.total}"
        } else {
            "${p.checked}/${p.total} | Найдено: ${p.successful}"
        }
        val notification = buildNotification(text, p.checked, p.total)
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, notification)
    }

    override fun onDestroy() {
        scanJob?.cancel()
        releaseWakeLock()
        scope.cancel()
        super.onDestroy()
    }
}
