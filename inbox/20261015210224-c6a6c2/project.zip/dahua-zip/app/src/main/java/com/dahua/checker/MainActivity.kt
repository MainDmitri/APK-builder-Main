package com.dahua.checker

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var scanServiceState = mutableStateOf<ScanService?>(null)
    private var serviceBound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            scanServiceState.value = (binder as ScanService.ScanBinder).getService()
            serviceBound = true
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            scanServiceState.value = null
            serviceBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        requestBatteryOptimization()
        requestNotificationPermission()

        setContent {
            val dark = darkColorScheme(
                primary = Color(0xFF00E676),
                secondary = Color(0xFF00BCD4),
                tertiary = Color(0xFFFF5252),
                background = Color(0xFF0D1117),
                surface = Color(0xFF161B22),
                surfaceVariant = Color(0xFF21262D),
                onBackground = Color(0xFFE6EDF3),
                onSurface = Color(0xFFE6EDF3),
                onSurfaceVariant = Color(0xFF8B949E),
                outline = Color(0xFF30363D)
            )
            MaterialTheme(colorScheme = dark) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    DahuaApp(
                        onStartScan = { ips, port, multiPort -> startScanService(ips, port, multiPort) },
                        onStopScan = { scanServiceState.value?.stopScan() },
                        scanService = scanServiceState.value
                    )
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Intent(this, ScanService::class.java).also { bindService(it, connection, Context.BIND_AUTO_CREATE) }
    }

    override fun onStop() {
        super.onStop()
        if (serviceBound) { unbindService(connection); serviceBound = false }
    }

    private fun startScanService(ips: List<String>, port: Int, multiPort: Boolean) {
        if (!serviceBound) {
            Intent(this, ScanService::class.java).also { bindService(it, connection, Context.BIND_AUTO_CREATE) }
        }
        val intent = Intent(this, ScanService::class.java).apply {
            action = ScanService.ACTION_START
            putExtra(ScanService.EXTRA_IPS, ips.toTypedArray())
            putExtra(ScanService.EXTRA_PORT, port)
            putExtra(ScanService.EXTRA_MULTI_PORT, multiPort)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
    }

    private fun requestBatteryOptimization() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                })
            } catch (_: Exception) {}
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}

// ─── Цвета ───
val Green400 = Color(0xFF00E676)
val Cyan400 = Color(0xFF00BCD4)
val Red400 = Color(0xFFFF5252)
val Orange400 = Color(0xFFFFB74D)
val Yellow400 = Color(0xFFFFEE58)
val Purple400 = Color(0xFFCE93D8)
val Gray500 = Color(0xFF8B949E)
val SurfaceDark = Color(0xFF161B22)
val SurfaceDark2 = Color(0xFF21262D)
val BorderDark = Color(0xFF30363D)

fun brandColor(brand: String): Color = when {
    "Hikvision" in brand -> Color(0xFFFF6B6B)
    "Dahua" in brand -> Green400
    "XMeye" in brand -> Purple400
    else -> Cyan400
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DahuaApp(
    onStartScan: (List<String>, Int, Boolean) -> Unit,
    onStopScan: () -> Unit,
    scanService: ScanService?
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var ipInput by remember { mutableStateOf("") }
    var portInput by remember { mutableStateOf("37777") }
    var parseError by remember { mutableStateOf<String?>(null) }
    var selectedResult by remember { mutableStateOf<ScanResult?>(null) }
    var multiPortMode by remember { mutableStateOf(false) }

    var isScanning by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<ScanProgress?>(null) }
    val results = remember { mutableStateListOf<ScanResult>() }
    val savedResults = remember { mutableStateListOf<ScanResult>() }
    val storedResults = remember { mutableStateListOf<ScanResult>() }

    val context = LocalContext.current

    // Загрузка сохранённых при старте
    LaunchedEffect(Unit) {
        val loaded = ResultStorage.load(context)
        storedResults.addAll(loaded)
    }

    LaunchedEffect(scanService) {
        scanService?.let { svc ->
            launch { svc.isScanning.collect { isScanning = it } }
            launch { svc.progress.collect { p -> if (p != null) progress = p } }
            launch { svc.results.collect { r ->
                results.add(0, r)
                if (!r.blocked) {
                    savedResults.add(0, r)
                    ResultStorage.addResult(context, r)
                    storedResults.removeAll { it.ip == r.ip && it.port == r.port }
                    storedResults.add(0, r)
                }
            }}
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // ─── Header ───
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color(0xFF0D1117), Color(0xFF161B22))))
                .padding(top = 48.dp, bottom = 12.dp, start = 16.dp, end = 16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Green400.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) { Text("👁", fontSize = 22.sp) }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Camera Scanner", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text(
                        if (multiPortMode) "Multi-port × ${DahuaScanner.MAX_CONCURRENT}" else "Dahua × ${DahuaScanner.MAX_CONCURRENT}",
                        fontSize = 12.sp, color = Gray500
                    )
                }
                if (results.isNotEmpty()) {
                    Box(
                        modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(Green400.copy(alpha = 0.15f)).padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("${results.count { !it.blocked }}", color = Green400, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }

        // ─── Tabs ───
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF0D1117),
            contentColor = Green400,
            indicator = { TabRowDefaults.SecondaryIndicator(Modifier.fillMaxWidth(), color = Green400) }
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 },
                text = { Text("Сканер", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                selectedContentColor = Green400, unselectedContentColor = Gray500)
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Находки", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        if (savedResults.isNotEmpty()) {
                            Spacer(Modifier.width(6.dp))
                            Box(modifier = Modifier.clip(CircleShape).background(Green400).padding(horizontal = 6.dp, vertical = 1.dp)) {
                                Text("${savedResults.size}", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                },
                selectedContentColor = Green400, unselectedContentColor = Gray500)
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("💾 Сохранённые", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        if (storedResults.isNotEmpty()) {
                            Spacer(Modifier.width(6.dp))
                            Box(modifier = Modifier.clip(CircleShape).background(Cyan400).padding(horizontal = 6.dp, vertical = 1.dp)) {
                                Text("${storedResults.size}", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                },
                selectedContentColor = Cyan400, unselectedContentColor = Gray500)
        }

        when (selectedTab) {
            0 -> ScannerTab(
                ipInput = ipInput, onIpChange = { ipInput = it; parseError = null },
                portInput = portInput, onPortChange = { portInput = it.filter { c -> c.isDigit() }.take(5) },
                parseError = parseError, isScanning = isScanning, progress = progress, results = results,
                multiPortMode = multiPortMode, onMultiPortChange = { multiPortMode = it },
                onScan = {
                    val ips = IpParser.parseMultiline(ipInput)
                    if (ips.isEmpty()) { parseError = "Некорректный ввод IP"; return@ScannerTab }
                    if (ips.size > 65536) { parseError = "Максимум 65536 IP"; return@ScannerTab }
                    val port = portInput.toIntOrNull() ?: DahuaScanner.DEFAULT_PORT
                    parseError = null; results.clear()
                    progress = ScanProgress(ips.size, 0, 0, 0, 0)
                    onStartScan(ips, port, multiPortMode)
                },
                onStop = onStopScan,
                onResultClick = { selectedResult = it },
                onMyNetwork = {
                    val net = NetworkUtils.getLocalNetwork(context)
                    if (net != null) {
                        ipInput = net.subnet
                        Toast.makeText(context, "Сеть: ${net.subnet} (${net.ip})", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Не удалось определить сеть WiFi", Toast.LENGTH_SHORT).show()
                    }
                },
                context = context
            )
            1 -> FindingsTab(results = savedResults, onResultClick = { selectedResult = it }, context = context)
            2 -> StoredTab(
                results = storedResults,
                onResultClick = { selectedResult = it },
                onDelete = { r ->
                    ResultStorage.delete(context, r.ip, r.port)
                    storedResults.removeAll { it.ip == r.ip && it.port == r.port }
                },
                onClearAll = {
                    ResultStorage.clear(context)
                    storedResults.clear()
                },
                context = context
            )
        }
    }

    selectedResult?.let { r -> SnapshotFullDialog(r, context) { selectedResult = null } }
}

@Composable
fun ScannerTab(
    ipInput: String, onIpChange: (String) -> Unit,
    portInput: String, onPortChange: (String) -> Unit,
    parseError: String?, isScanning: Boolean, progress: ScanProgress?,
    results: List<ScanResult>,
    multiPortMode: Boolean, onMultiPortChange: (Boolean) -> Unit,
    onScan: () -> Unit, onStop: () -> Unit,
    onResultClick: (ScanResult) -> Unit,
    onMyNetwork: () -> Unit,
    context: Context
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Цель", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Gray500)
                        // Кнопка "Моя сеть"
                        OutlinedButton(
                            onClick = onMyNetwork,
                            enabled = !isScanning,
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(1.dp, Cyan400.copy(alpha = 0.5f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan400),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("📡", fontSize = 14.sp)
                            Spacer(Modifier.width(4.dp))
                            Text("Моя сеть", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = ipInput, onValueChange = onIpChange,
                        placeholder = { Text("192.168.1.1\n10.0.0.1-10.0.0.50\n172.16.0.0/24", color = Gray500.copy(alpha = 0.5f), fontSize = 13.sp, fontFamily = FontFamily.Monospace) },
                        modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 8,
                        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 14.sp),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                        isError = parseError != null, enabled = !isScanning, shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Green400, unfocusedBorderColor = BorderDark, cursorColor = Green400,
                            focusedContainerColor = Color(0xFF0D1117), unfocusedContainerColor = Color(0xFF0D1117)
                        )
                    )

                    if (parseError != null) {
                        Text(parseError, color = Red400, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }

                    Spacer(Modifier.height(12.dp))

                    // Multi-port переключатель
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Multi-port сканирование", fontSize = 13.sp, color = Color.White)
                            Text(
                                if (multiPortMode) "Все порты: 37777, 80, 8080, 34567..." else "Только порт Dahua (37777)",
                                fontSize = 11.sp, color = Gray500
                            )
                        }
                        Switch(
                            checked = multiPortMode,
                            onCheckedChange = onMultiPortChange,
                            enabled = !isScanning,
                            colors = SwitchDefaults.colors(checkedTrackColor = Green400, checkedThumbColor = Color.White)
                        )
                    }

                    // Порт — показываем только если НЕ multi-port
                    if (!multiPortMode) {
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Порт:", fontSize = 13.sp, color = Gray500)
                            Spacer(Modifier.width(8.dp))
                            OutlinedTextField(
                                value = portInput, onValueChange = onPortChange,
                                modifier = Modifier.width(100.dp),
                                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 14.sp),
                                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                enabled = !isScanning, shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Green400, unfocusedBorderColor = BorderDark,
                                    focusedContainerColor = Color(0xFF0D1117), unfocusedContainerColor = Color(0xFF0D1117))
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onScan, enabled = !isScanning && ipInput.isNotBlank(),
                            modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Green400, contentColor = Color.Black, disabledContainerColor = Green400.copy(alpha = 0.3f))
                        ) {
                            Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Сканировать", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        if (isScanning) {
                            OutlinedButton(
                                onClick = onStop, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Red400), border = BorderStroke(1.dp, Red400)
                            ) {
                                Icon(Icons.Default.Close, null, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Стоп", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        progress?.let { p -> if (p.total > 0) { item { ProgressCard(p, isScanning) } } }
        if (results.isNotEmpty()) { item { StatsStrip(results) } }

        val successResults = results.filter { !it.blocked }
        val blockedResults = results.filter { it.blocked }

        if (successResults.isNotEmpty()) {
            item { Text("НАЙДЕНО", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Green400, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            items(successResults, key = { "${it.ip}:${it.port}:${it.timestampMs}" }) { result -> ResultCard(result, context) { onResultClick(result) } }
        }
        if (blockedResults.isNotEmpty()) {
            item { Text("ЗАБЛОКИРОВАНО", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Orange400, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            items(blockedResults, key = { "blocked_${it.ip}:${it.timestampMs}" }) { result ->
                Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(Orange400.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) { Text("🔒", fontSize = 16.sp) }
                        Spacer(Modifier.width(12.dp))
                        Text(result.ip, fontFamily = FontFamily.Monospace, fontSize = 14.sp, color = Orange400)
                    }
                }
            }
        }
    }
}

@Composable
fun FindingsTab(results: List<ScanResult>, onResultClick: (ScanResult) -> Unit, context: Context) {
    val withPhoto = results.filter { it.snapshot != null && it.snapshot.size > 100 }
    val withoutPhoto = results.filter { it.snapshot == null || it.snapshot.size <= 100 }

    if (results.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("📷", fontSize = 48.sp)
                Spacer(Modifier.height(12.dp))
                Text("Пока ничего не найдено", fontSize = 16.sp, color = Gray500)
                Text("Запустите сканирование", fontSize = 13.sp, color = Gray500.copy(alpha = 0.6f))
            }
        }
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Всего найдено: ${results.size}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Green400)
                    Spacer(Modifier.height(8.dp))

                    // Бренды
                    val brands = results.groupBy { it.brand }.mapValues { it.value.size }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        brands.forEach { (brand, count) ->
                            StatChip("$brand: $count", brandColor(brand), Modifier.weight(1f))
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatChip("📸 ${withPhoto.size} со снапшотом", Green400, Modifier.weight(1f))
                        StatChip("🔑 ${withoutPhoto.size} без фото", Cyan400, Modifier.weight(1f))
                    }

                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val text = results.joinToString("\n") { r -> "${r.ip}:${r.port} ${r.login}:${r.password} [${r.brand}] ${r.model} ${r.channels}ch" }
                            cm.setPrimaryClip(ClipData.newPlainText("camera_all", text))
                            Toast.makeText(context, "Скопировано (${results.size})", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan400), border = BorderStroke(1.dp, Cyan400.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Копировать все", fontSize = 13.sp)
                    }
                }
            }
        }

        if (withPhoto.isNotEmpty()) {
            item { Text("СО СНАПШОТОМ", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Green400, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            items(withPhoto, key = { "f_${it.ip}:${it.port}:${it.timestampMs}" }) { result -> FindingCard(result, context) { onResultClick(result) } }
        }
        if (withoutPhoto.isNotEmpty()) {
            item { Text("БЕЗ СНАПШОТА", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Cyan400, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            items(withoutPhoto, key = { "nf_${it.ip}:${it.port}:${it.timestampMs}" }) { result -> ResultCard(result, context) { onResultClick(result) } }
        }
    }
}

@Composable
fun FindingCard(result: ScanResult, context: Context, onClick: () -> Unit) {
    val timeFmt = remember(result.timestampMs) {
        java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(result.timestampMs))
    }
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(14.dp)) {
        Column {
            if (result.snapshot != null && result.snapshot.size > 100) {
                val bmp = remember(result.snapshot) { BitmapFactory.decodeByteArray(result.snapshot, 0, result.snapshot.size) }
                if (bmp != null) {
                    Image(bitmap = bmp.asImageBitmap(), contentDescription = null,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp).clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)),
                        contentScale = ContentScale.Crop)
                }
            }
            Column(modifier = Modifier.padding(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(result.ip, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 15.sp, color = Color.White)
                    Box(modifier = Modifier.size(28.dp).clip(CircleShape).background(SurfaceDark2).clickable {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("cam", "${result.ip}:${result.port} ${result.login}:${result.password}"))
                        Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                    }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Share, null, tint = Gray500, modifier = Modifier.size(14.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Green400.copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text("${result.login}:${result.password}", fontSize = 12.sp, color = Green400, fontFamily = FontFamily.Monospace)
                    }
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(brandColor(result.brand).copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text(result.brand, fontSize = 11.sp, color = brandColor(result.brand))
                    }
                    if (result.model.isNotEmpty() && result.model != "unknown") {
                        Text(result.model, fontSize = 11.sp, color = Cyan400, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(timeFmt, fontSize = 11.sp, color = Gray500)
                }
            }
        }
    }
}

@Composable
fun ProgressCard(p: ScanProgress, scanning: Boolean) {
    val pct = if (p.total > 0) (p.checked.toFloat() / p.total) else 0f
    val speed = if (p.elapsedMs > 200) (p.checked * 1000.0 / p.elapsedMs) else 0.0
    val eta = if (speed > 0.01 && p.checked < p.total) ((p.total - p.checked) / speed).toInt() else 0

    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (scanning) { CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Green400); Spacer(Modifier.width(8.dp)) }
                    Text(
                        if (p.finished) "Завершено" else if (p.cancelled) "Отменено" else "Сканирование",
                        fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        color = when { p.finished -> Green400; p.cancelled -> Orange400; else -> Color.White }
                    )
                }
                Text("${(pct * 100).toInt()}%", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Green400)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)), color = Green400, trackColor = BorderDark)
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                StatMini("Проверено", "${p.checked}/${p.total}", Cyan400)
                StatMini("Найдено", "${p.successful}", Green400)
                StatMini("Блокировка", "${p.blocked}", Orange400)
                if (speed > 0.01) StatMini("Скорость", "${"%.1f".format(speed)}/с", Color.White)
                if (scanning && eta > 0) StatMini("ETA", "%d:%02d".format(eta / 60, eta % 60), Yellow400)
            }
        }
    }
}

@Composable
fun StatMini(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color)
        Text(label, fontSize = 10.sp, color = Gray500)
    }
}

@Composable
fun StatsStrip(results: List<ScanResult>) {
    val withPhoto = results.count { it.snapshot != null && it.snapshot.size > 100 }
    val withoutPhoto = results.count { !it.blocked && (it.snapshot == null || it.snapshot.size <= 100) }
    val blocked = results.count { it.blocked }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatChip("📸 $withPhoto фото", Green400, Modifier.weight(1f))
        StatChip("🔑 $withoutPhoto без фото", Cyan400, Modifier.weight(1f))
        if (blocked > 0) StatChip("🔒 $blocked блок", Orange400, Modifier.weight(1f))
    }
}

@Composable
fun StatChip(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(modifier = modifier.clip(RoundedCornerShape(10.dp)).background(color.copy(alpha = 0.1f)).padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = color)
    }
}

@Composable
fun ResultCard(result: ScanResult, context: Context, onClick: () -> Unit) {
    val hasPhoto = result.snapshot != null && result.snapshot.size > 100
    val timeFmt = remember(result.timestampMs) {
        java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(result.timestampMs))
    }
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(14.dp)) {
        Row(modifier = Modifier.padding(12.dp)) {
            Box(modifier = Modifier.size(72.dp).clip(RoundedCornerShape(10.dp)).background(if (hasPhoto) Color.Transparent else SurfaceDark2), contentAlignment = Alignment.Center) {
                if (hasPhoto) {
                    val bmp = remember(result.snapshot) { BitmapFactory.decodeByteArray(result.snapshot!!, 0, result.snapshot.size) }
                    if (bmp != null) Image(bitmap = bmp.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else { Text("📷", fontSize = 28.sp) }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(result.ip, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 15.sp, color = Color.White)
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Green400.copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text("${result.login}:${result.password}", fontSize = 12.sp, color = Green400, fontFamily = FontFamily.Monospace)
                    }
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(brandColor(result.brand).copy(alpha = 0.15f)).padding(horizontal = 5.dp, vertical = 2.dp)) {
                        Text(result.brand, fontSize = 10.sp, color = brandColor(result.brand))
                    }
                    Box(modifier = Modifier.size(24.dp).clip(CircleShape).background(SurfaceDark2).clickable {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("cam", "${result.ip}:${result.port} ${result.login}:${result.password}"))
                        Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                    }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Share, null, tint = Gray500, modifier = Modifier.size(14.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    if (result.model.isNotEmpty() && result.model != "unknown") {
                        Text(result.model, fontSize = 11.sp, color = Cyan400, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                        Spacer(Modifier.width(4.dp))
                    }
                    if (result.channels > 0) { Text("${result.channels}ch", fontSize = 11.sp, color = Gray500); Spacer(Modifier.width(4.dp)) }
                    Text(":${result.port}", fontSize = 11.sp, color = Gray500, fontFamily = FontFamily.Monospace)
                    Spacer(Modifier.width(4.dp))
                    Text(timeFmt, fontSize = 11.sp, color = Gray500)
                }
                if (!hasPhoto) Text("без снапшота", fontSize = 11.sp, color = Gray500.copy(alpha = 0.7f))
            }
        }
    }
}

@Composable
fun SnapshotFullDialog(result: ScanResult, context: Context, onDismiss: () -> Unit) {
    val hasPhoto = result.snapshot != null && result.snapshot.size > 100
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(modifier = Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(20.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(brandColor(result.brand)))
                    Spacer(Modifier.width(8.dp))
                    Text(result.ip, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(brandColor(result.brand).copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text(result.brand, fontSize = 11.sp, color = brandColor(result.brand))
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (hasPhoto) {
                    val bmp = remember(result.snapshot) { BitmapFactory.decodeByteArray(result.snapshot!!, 0, result.snapshot.size) }
                    if (bmp != null) Image(bitmap = bmp.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.FillWidth)
                    Spacer(Modifier.height(12.dp))
                }
                InfoRow("Порт", "${result.port}")
                InfoRow("Логин", result.login)
                InfoRow("Пароль", result.password)
                InfoRow("Бренд", result.brand)
                if (result.model.isNotEmpty() && result.model != "unknown") InfoRow("Модель", result.model)
                InfoRow("Каналов", "${result.channels}")
                Spacer(Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val info = buildString {
                            appendLine("IP: ${result.ip}:${result.port}")
                            appendLine("Login: ${result.login}")
                            appendLine("Password: ${result.password}")
                            appendLine("Brand: ${result.brand}")
                            if (result.model.isNotEmpty()) appendLine("Model: ${result.model}")
                            appendLine("Channels: ${result.channels}")
                        }
                        cm.setPrimaryClip(ClipData.newPlainText("cam", info))
                        Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                    }) { Text("Копировать", color = Cyan400) }
                    TextButton(onClick = onDismiss) { Text("Закрыть", color = Gray500) }
                }
            }
        }
    }
}

@Composable
fun StoredTab(
    results: List<ScanResult>,
    onResultClick: (ScanResult) -> Unit,
    onDelete: (ScanResult) -> Unit,
    onClearAll: () -> Unit,
    context: Context
) {
    if (results.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("💾", fontSize = 48.sp)
                Spacer(Modifier.height(12.dp))
                Text("Нет сохранённых камер", fontSize = 16.sp, color = Gray500)
                Text("Найденные камеры сохраняются автоматически", fontSize = 13.sp, color = Gray500.copy(alpha = 0.6f))
            }
        }
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("💾 Сохранено: ${results.size} камер", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Cyan400)
                    Text("Данные хранятся локально на устройстве", fontSize = 12.sp, color = Gray500)

                    Spacer(Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val text = results.joinToString("\n") { r -> "${r.ip}:${r.port} ${r.login}:${r.password} [${r.brand}] ${r.model}" }
                                cm.setPrimaryClip(ClipData.newPlainText("stored_all", text))
                                Toast.makeText(context, "Скопировано (${results.size})", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan400), border = BorderStroke(1.dp, Cyan400.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Копировать", fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = onClearAll,
                            modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Red400), border = BorderStroke(1.dp, Red400.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.Delete, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Очистить всё", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        items(results, key = { "stored_${it.ip}:${it.port}:${it.timestampMs}" }) { result ->
            StoredResultCard(result, context, onClick = { onResultClick(result) }, onDelete = { onDelete(result) })
        }
    }
}

@Composable
fun StoredResultCard(result: ScanResult, context: Context, onClick: () -> Unit, onDelete: () -> Unit) {
    val hasPhoto = result.snapshot != null && result.snapshot.size > 100
    val dateFmt = remember(result.timestampMs) {
        java.text.SimpleDateFormat("dd.MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(result.timestampMs))
    }
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(14.dp)) {
        Row(modifier = Modifier.padding(12.dp)) {
            Box(modifier = Modifier.size(72.dp).clip(RoundedCornerShape(10.dp)).background(if (hasPhoto) Color.Transparent else SurfaceDark2), contentAlignment = Alignment.Center) {
                if (hasPhoto) {
                    val bmp = remember(result.snapshot) { BitmapFactory.decodeByteArray(result.snapshot!!, 0, result.snapshot.size) }
                    if (bmp != null) Image(bitmap = bmp.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else { Text("📷", fontSize = 28.sp) }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(result.ip, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 15.sp, color = Color.White)
                    Row {
                        Box(modifier = Modifier.size(24.dp).clip(CircleShape).background(SurfaceDark2).clickable {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("cam", "${result.ip}:${result.port} ${result.login}:${result.password}"))
                            Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                        }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Share, null, tint = Gray500, modifier = Modifier.size(14.dp)) }
                        Spacer(Modifier.width(4.dp))
                        Box(modifier = Modifier.size(24.dp).clip(CircleShape).background(Red400.copy(alpha = 0.15f)).clickable { onDelete() }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Delete, null, tint = Red400, modifier = Modifier.size(14.dp))
                        }
                    }
                }
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Green400.copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text("${result.login}:${result.password}", fontSize = 12.sp, color = Green400, fontFamily = FontFamily.Monospace)
                    }
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(brandColor(result.brand).copy(alpha = 0.15f)).padding(horizontal = 5.dp, vertical = 2.dp)) {
                        Text(result.brand, fontSize = 10.sp, color = brandColor(result.brand))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    if (result.model.isNotEmpty() && result.model != "unknown") Text(result.model, fontSize = 11.sp, color = Cyan400, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    Text(":${result.port}", fontSize = 11.sp, color = Gray500, fontFamily = FontFamily.Monospace)
                    Spacer(Modifier.width(4.dp))
                    Text(dateFmt, fontSize = 11.sp, color = Gray500)
                }
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 13.sp, color = Gray500)
        Text(value, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, color = Color.White)
    }
}
