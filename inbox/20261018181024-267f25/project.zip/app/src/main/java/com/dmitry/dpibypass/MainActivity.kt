package com.dmitry.dpibypass

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) {
                Toast.makeText(
                    this,
                    "Без уведомлений прокси работает, но значок в шторке не будет виден",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    MainScreen(
                        onStart = { config -> startProxy(config) },
                        onStop = { stopProxy() }
                    )
                }
            }
        }
    }

    private fun startProxy(config: ProxyConfig) {
        SettingsStore.save(this, config)
        ProxyState.setError(null)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val intent = Intent(this, ProxyService::class.java).setAction(ProxyService.ACTION_START)
        try {
            ContextCompat.startForegroundService(this, intent)
        } catch (e: Exception) {
            ProxyState.setError("Не удалось запустить сервис: ${e.message}")
        }
    }

    private fun stopProxy() {
        try {
            startService(Intent(this, ProxyService::class.java).setAction(ProxyService.ACTION_STOP))
        } catch (e: Exception) {
            stopService(Intent(this, ProxyService::class.java))
        }
    }
}

private fun parsePort(text: String): Int? = text.trim().toIntOrNull()?.takeIf { it in 1024..65535 }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(onStart: (ProxyConfig) -> Unit, onStop: () -> Unit) {
    val context = LocalContext.current
    val initial = remember { SettingsStore.load(context) }

    var socksPort by rememberSaveable { mutableStateOf(initial.socksPort.toString()) }
    var httpEnabled by rememberSaveable { mutableStateOf(initial.httpEnabled) }
    var httpPort by rememberSaveable { mutableStateOf(initial.httpPort.toString()) }
    var dohUrl by rememberSaveable { mutableStateOf(initial.dohUrl) }
    var presetId by rememberSaveable { mutableStateOf(initial.preset.id) }
    var fragSize by rememberSaveable { mutableStateOf(initial.custom.fragSize.toString()) }
    var fragCount by rememberSaveable { mutableStateOf(initial.custom.fragCount.toString()) }
    var delayMs by rememberSaveable { mutableStateOf(initial.custom.delayMs.toString()) }
    var splitSni by rememberSaveable { mutableStateOf(initial.custom.splitSni) }
    var tlsRecordSplit by rememberSaveable { mutableStateOf(initial.custom.tlsRecordSplit) }
    var useTor by rememberSaveable { mutableStateOf(initial.useTor) }
    var upstreamEnabled by rememberSaveable { mutableStateOf(initial.upstreamEnabled && !initial.useTor) }
    var upstreamHost by rememberSaveable { mutableStateOf(initial.upstreamHost) }
    var upstreamPort by rememberSaveable { mutableStateOf(initial.upstreamPort.toString()) }

    // Статус Orbot
    var orbotInstalled by remember { mutableStateOf(OrbotHelper.isInstalled(context)) }
    var torReady by remember { mutableStateOf<Boolean?>(null) }
    var checking by remember { mutableStateOf(false) }
    var refreshTick by remember { mutableIntStateOf(0) }

    LifecycleResumeEffect(Unit) {
        // Вернулись из Orbot / магазина — обновим статус.
        refreshTick++
        onPauseOrDispose { }
    }
    LaunchedEffect(useTor, refreshTick) {
        if (!useTor) return@LaunchedEffect
        checking = true
        orbotInstalled = OrbotHelper.isInstalled(context)
        torReady = withContext(Dispatchers.IO) { OrbotHelper.isTorSocksReady() }
        checking = false
    }

    val running by ProxyState.running.collectAsState()
    val error by ProxyState.error.collectAsState()
    val connections by ProxyState.connections.collectAsState()
    val total by ProxyState.total.collectAsState()

    val preset = Preset.fromId(presetId)
    val editable = !running

    fun buildConfig(): ProxyConfig? {
        val sp = parsePort(socksPort)
        if (sp == null) {
            Toast.makeText(context, "Порт SOCKS должен быть от 1024 до 65535", Toast.LENGTH_LONG).show()
            return null
        }
        val hp = parsePort(httpPort)
        if (httpEnabled && (hp == null || hp == sp)) {
            Toast.makeText(context, "Порт HTTP должен быть от 1024 до 65535 и отличаться от SOCKS", Toast.LENGTH_LONG).show()
            return null
        }
        val upHost = upstreamHost.trim().ifEmpty { TOR_SOCKS_HOST }
        val upPort = upstreamPort.trim().toIntOrNull()?.takeIf { it in 1..65535 }
        if (!useTor && upstreamEnabled && upPort == null) {
            Toast.makeText(context, "Порт внешнего SOCKS5 должен быть от 1 до 65535", Toast.LENGTH_LONG).show()
            return null
        }
        if (!useTor && upstreamEnabled && upPort == sp &&
            (upHost == "127.0.0.1" || upHost.equals("localhost", ignoreCase = true))
        ) {
            Toast.makeText(context, "Внешний SOCKS5 не может указывать на наш же порт (петля)", Toast.LENGTH_LONG).show()
            return null
        }
        if (useTor && (sp == TOR_SOCKS_PORT || (httpEnabled && hp == TOR_SOCKS_PORT))) {
            Toast.makeText(context, "Порт $TOR_SOCKS_PORT занят Orbot — выберите другой порт", Toast.LENGTH_LONG).show()
            return null
        }
        val url = dohUrl.trim().ifEmpty { DEFAULT_DOH_URL }
        if (!url.startsWith("https://")) {
            Toast.makeText(context, "Адрес DoH должен начинаться с https://", Toast.LENGTH_LONG).show()
            return null
        }
        return ProxyConfig(
            socksPort = sp,
            httpEnabled = httpEnabled,
            httpPort = hp ?: DEFAULT_HTTP_PORT,
            dohUrl = url,
            preset = preset,
            custom = FragSettings(
                fragSize = fragSize.trim().toIntOrNull() ?: 2,
                fragCount = fragCount.trim().toIntOrNull() ?: 4,
                delayMs = delayMs.trim().toIntOrNull() ?: 10,
                splitSni = splitSni,
                tlsRecordSplit = tlsRecordSplit
            ).normalized(),
            useTor = useTor,
            upstreamEnabled = upstreamEnabled,
            upstreamHost = upHost,
            upstreamPort = upPort ?: TOR_SOCKS_PORT
        ).normalized()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Обход DPI", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            if (useTor) "Локальный SOCKS5-прокси → Tor (Orbot, 127.0.0.1:$TOR_SOCKS_PORT)"
            else "Локальный SOCKS5-прокси с фрагментацией TLS ClientHello и DNS-over-HTTPS",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // Статус
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Spacer(
                        Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(if (running) Color(0xFF2E7D32) else Color(0xFF9E9E9E))
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (running) "Статус: работает" else "Статус: остановлен",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
                if (running) {
                    Text("SOCKS5: 127.0.0.1:$socksPort")
                    if (useTor) Text("Выход: Tor (Orbot) 127.0.0.1:$TOR_SOCKS_PORT")
                    else if (upstreamEnabled) Text("Выход: внешний SOCKS5 ${upstreamHost.trim()}:${upstreamPort.trim()}")
                    else Text("Выход: напрямую + фрагментация (${preset.title})")
                    if (httpEnabled) Text("HTTP-прокси: 127.0.0.1:$httpPort")
                    Text("Активных соединений: $connections · всего: $total")
                }
                error?.let {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        )
                    ) {
                        Text(
                            "⚠ $it",
                            modifier = Modifier.padding(12.dp),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
                Button(
                    onClick = {
                        if (running) onStop() else buildConfig()?.let(onStart)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = if (running) ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    ) else ButtonDefaults.buttonColors()
                ) {
                    Text(if (running) "Остановить" else "Запустить")
                }
                OutlinedButton(
                    onClick = {
                        val address = "127.0.0.1:${socksPort.trim()}"
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("SOCKS5", address))
                        Toast.makeText(context, "Скопировано: $address", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Скопировать адрес 127.0.0.1:${socksPort.trim()}")
                }
            }
        }

        if (running) {
            Text(
                "Чтобы изменить настройки, остановите прокси.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Tor / Orbot
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Через Tor (Orbot)", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Весь трафик прокси уходит в Tor: SOCKS Orbot 127.0.0.1:$TOR_SOCKS_PORT",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = useTor,
                        onCheckedChange = { useTor = it; if (it) upstreamEnabled = false },
                        enabled = editable
                    )
                }
                if (useTor) {
                    StatusLine(
                        ok = orbotInstalled,
                        text = if (orbotInstalled) "Orbot установлен" else "Orbot не установлен"
                    )
                    StatusLine(
                        ok = torReady == true,
                        text = when {
                            checking -> "Проверяю SOCKS 127.0.0.1:$TOR_SOCKS_PORT…"
                            torReady == true -> "Tor SOCKS 127.0.0.1:$TOR_SOCKS_PORT отвечает"
                            torReady == false -> "Tor SOCKS 127.0.0.1:$TOR_SOCKS_PORT недоступен — запустите Orbot"
                            else -> "Статус Tor SOCKS не проверен"
                        }
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { refreshTick++ },
                            enabled = !checking,
                            modifier = Modifier.weight(1f)
                        ) { Text("Обновить") }
                        if (orbotInstalled) {
                            Button(
                                onClick = {
                                    if (!OrbotHelper.startOrbot(context)) {
                                        Toast.makeText(context, "Не удалось открыть Orbot", Toast.LENGTH_LONG).show()
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("Открыть Orbot") }
                        }
                    }
                    if (!orbotInstalled) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = {
                                    if (!OrbotHelper.openInstallPage(context)) {
                                        Toast.makeText(context, "Не удалось открыть магазин", Toast.LENGTH_LONG).show()
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("Установить Orbot") }
                            OutlinedButton(
                                onClick = {
                                    if (!OrbotHelper.openFdroidPage(context)) {
                                        Toast.makeText(context, "Не удалось открыть браузер", Toast.LENGTH_LONG).show()
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("F-Droid") }
                        }
                    }
                    Text("Как пользоваться:", fontWeight = FontWeight.SemiBold)
                    Text("1. Установи и запусти Orbot, дождись «Connected» (в Orbot можно включить мосты obfs4/Snowflake, если Tor не подключается).")
                    Text("2. Здесь включи «Через Tor» и нажми «Запустить».")
                    Text("3. В Telegram: SOCKS5 127.0.0.1:${socksPort.trim()} без логина (наш прокси → Tor).")
                    Text("4. Можно и напрямую: в Telegram SOCKS5 127.0.0.1:$TOR_SOCKS_PORT (сразу в Orbot).")
                    Text(
                        "Через Tor фрагментация не нужна — провайдер видит только Tor-трафик. " +
                            "DNS тоже резолвит Tor. Telegram работает только пока Orbot подключён.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    SwitchRow("Внешний SOCKS5 (цепочка)", upstreamEnabled, editable) { upstreamEnabled = it }
                    if (upstreamEnabled) {
                        OutlinedTextField(
                            value = upstreamHost,
                            onValueChange = { upstreamHost = it.trim() },
                            label = { Text("Адрес внешнего SOCKS5") },
                            singleLine = true,
                            enabled = editable,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = upstreamPort,
                            onValueChange = { upstreamPort = it.filter(Char::isDigit).take(5) },
                            label = { Text("Порт внешнего SOCKS5") },
                            singleLine = true,
                            enabled = editable,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            "В режиме цепочки фрагментация и DoH не применяются.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Сеть
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Подключение", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = socksPort,
                    onValueChange = { socksPort = it.filter(Char::isDigit).take(5) },
                    label = { Text("Порт SOCKS5") },
                    singleLine = true,
                    enabled = editable,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                SwitchRow("HTTP-прокси (CONNECT)", httpEnabled, editable) { httpEnabled = it }
                if (httpEnabled) {
                    OutlinedTextField(
                        value = httpPort,
                        onValueChange = { httpPort = it.filter(Char::isDigit).take(5) },
                        label = { Text("Порт HTTP-прокси") },
                        singleLine = true,
                        enabled = editable,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                OutlinedTextField(
                    value = dohUrl,
                    onValueChange = { dohUrl = it.trim() },
                    label = { Text("DNS-over-HTTPS (JSON API)") },
                    singleLine = true,
                    enabled = editable,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(enabled = editable, onClick = { dohUrl = "https://1.1.1.1/dns-query" }) {
                        Text("Cloudflare")
                    }
                    TextButton(enabled = editable, onClick = { dohUrl = "https://8.8.8.8/resolve" }) {
                        Text("Google")
                    }
                }
            }
        }

        // Режим фрагментации
        if (useTor || upstreamEnabled) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(
                    if (useTor) "Режим обхода: через Tor фрагментация не нужна и отключена."
                    else "Режим обхода: при внешнем SOCKS5 фрагментация отключена.",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Режим обхода", style = MaterialTheme.typography.titleMedium)
                val rows = Preset.entries.chunked(2)
                for (row in rows) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        for (p in row) {
                            FilterChip(
                                selected = preset == p,
                                onClick = { if (editable) presetId = p.id },
                                label = { Text(p.title) },
                                enabled = editable,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
                Text(
                    preset.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (preset == Preset.CUSTOM) {
                    OutlinedTextField(
                        value = fragSize,
                        onValueChange = { fragSize = it.filter(Char::isDigit).take(2) },
                        label = { Text("Размер первых фрагментов, байт (1–64)") },
                        singleLine = true,
                        enabled = editable,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = fragCount,
                        onValueChange = { fragCount = it.filter(Char::isDigit).take(2) },
                        label = { Text("Число первых фрагментов (0–32)") },
                        singleLine = true,
                        enabled = editable,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = delayMs,
                        onValueChange = { delayMs = it.filter(Char::isDigit).take(3) },
                        label = { Text("Задержка между фрагментами, мс (0–500)") },
                        singleLine = true,
                        enabled = editable,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    SwitchRow("Разрезать внутри SNI", splitSni, editable) { splitSni = it }
                    SwitchRow("Делить TLS-запись (tlsrec)", tlsRecordSplit, editable) { tlsRecordSplit = it }
                }
            }
        }

        // Справка
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Как подключить", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Telegram: Настройки → Данные и память → Тип соединения (Прокси) → Добавить прокси → SOCKS5, " +
                        "сервер 127.0.0.1, порт ${socksPort.trim()}, логин и пароль пустые." +
                        if (useTor) " Трафик пойдёт через Tor — Orbot должен быть запущен." else
                            " Без Tor Telegram часто не подключается: его IP блокируют, фрагментация не помогает."
                )
                Text(
                    "Firefox: в адресной строке about:config → network.proxy.type = 1, " +
                        "network.proxy.socks = 127.0.0.1, network.proxy.socks_port = ${socksPort.trim()}, " +
                        "network.proxy.socks_version = 5, network.proxy.socks_remote_dns = true."
                )
                if (httpEnabled) {
                    Text(
                        "Chrome и другие: Настройки Wi‑Fi → сеть → Прокси → Вручную, " +
                            "узел 127.0.0.1, порт ${httpPort.trim()} (только для этой Wi‑Fi сети)."
                    )
                }
                Text(
                    "Если сайт не открывается — попробуйте режим «Агрессивный» или «Мягкий». " +
                        "Это не VPN: трафик идёт только через приложения, в которых указан прокси.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun StatusLine(ok: Boolean, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Spacer(
            Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(if (ok) Color(0xFF2E7D32) else Color(0xFFC62828))
        )
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}
