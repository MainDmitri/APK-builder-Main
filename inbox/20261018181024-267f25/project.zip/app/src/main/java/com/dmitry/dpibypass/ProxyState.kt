package com.dmitry.dpibypass

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Общее состояние прокси для UI и сервиса. */
object ProxyState {
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _connections = MutableStateFlow(0)
    val connections: StateFlow<Int> = _connections.asStateFlow()

    private val _total = MutableStateFlow(0L)
    val total: StateFlow<Long> = _total.asStateFlow()

    fun setRunning(value: Boolean) {
        _running.value = value
        if (!value) _connections.value = 0
    }

    fun setError(message: String?) {
        _error.value = message
    }

    /** Сбрасывает ошибку, если она удовлетворяет условию (например, «Orbot недоступен» после восстановления). */
    fun clearErrorIf(predicate: (String) -> Boolean) {
        _error.update { cur -> if (cur != null && predicate(cur)) null else cur }
    }

    fun connectionOpened() {
        _connections.update { it + 1 }
        _total.update { it + 1 }
    }

    fun connectionClosed() {
        _connections.update { if (it > 0) it - 1 else 0 }
    }
}
