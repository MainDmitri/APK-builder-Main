package com.dmitry.dpibypass

import android.util.Log
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.DataInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URI
import java.net.UnknownHostException
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * Локальный SOCKS5 (и опционально HTTP CONNECT) прокси на 127.0.0.1
 * с фрагментацией первого пакета для обхода DPI.
 */
/** Ошибка внешнего SOCKS5 (Tor/Orbot); [socksCode] — код ответа для нашего клиента. */
class UpstreamSocksException(
    message: String,
    val socksCode: Int,
    cause: Throwable? = null,
    /** true — сам SOCKS-сервер (Orbot) недоступен, а не конкретный адрес назначения. */
    val unavailable: Boolean = false
) : IOException(message, cause)

class ProxyEngine(config: ProxyConfig) {

    private val config: ProxyConfig = config.normalized()

    private val threadCounter = AtomicInteger(0)
    private val executor = Executors.newCachedThreadPool { r ->
        Thread(r, "dpi-proxy-${threadCounter.incrementAndGet()}").apply { isDaemon = true }
    }
    private val dispatcher = executor.asCoroutineDispatcher()
    private val scope = CoroutineScope(
        SupervisorJob() + dispatcher + CoroutineExceptionHandler { _, e ->
            Log.w(TAG, "Ошибка в обработчике соединения", e)
        }
    )
    private val servers = Collections.synchronizedList(mutableListOf<ServerSocket>())
    private val openSockets: MutableSet<Socket> = Collections.newSetFromMap(ConcurrentHashMap())
    private val resolver = DohResolver(this.config.dohUrl)
    private val frag = this.config.frag

    /** Цепочка через внешний SOCKS5 (Tor/Orbot). Через неё DoH и фрагментация не применяются. */
    private val chain: Boolean = this.config.chainEnabled
    private val chainHost: String = this.config.chainHost
    private val chainPort: Int = this.config.chainPort
    private val chainLabel: String =
        if (this.config.useTor) "Tor/Orbot" else "Внешний SOCKS5"

    @Volatile
    private var running = false

    @Throws(IOException::class)
    fun start() {
        running = true
        try {
            val loopback = InetAddress.getByAddress("localhost", byteArrayOf(127, 0, 0, 1))
            val socks = openServer(loopback, config.socksPort)
            scope.launch { acceptLoop(socks) { handleSocks(it) } }
            if (config.httpEnabled) {
                val http = openServer(loopback, config.httpPort)
                scope.launch { acceptLoop(http) { handleHttp(it) } }
            }
            Log.i(
                TAG,
                "Прокси запущен: SOCKS5 ${config.socksPort}, HTTP ${config.httpEnabled}:${config.httpPort}" +
                    if (chain) ", цепочка → $chainLabel $chainHost:$chainPort" else ", прямой режим"
            )
        } catch (e: IOException) {
            stop()
            throw e
        }
    }

    fun stop() {
        running = false
        synchronized(servers) {
            servers.forEach { closeQuietly(it) }
            servers.clear()
        }
        openSockets.toList().forEach { closeQuietly(it) }
        openSockets.clear()
        scope.cancel()
        executor.shutdownNow()
    }

    private fun openServer(address: InetAddress, port: Int): ServerSocket {
        val server = ServerSocket()
        try {
            server.reuseAddress = true
            server.bind(InetSocketAddress(address, port), 256)
        } catch (e: IOException) {
            closeQuietly(server)
            throw IOException("порт $port занят или недоступен (${e.message})", e)
        }
        servers += server
        return server
    }

    private suspend fun acceptLoop(server: ServerSocket, handler: suspend (Socket) -> Unit) {
        coroutineScope {
            while (running && isActive) {
                val client = try {
                    server.accept()
                } catch (e: IOException) {
                    if (running) Log.w(TAG, "accept: ${e.message}")
                    break
                }
                track(client)
                launch {
                    ProxyState.connectionOpened()
                    try {
                        client.tcpNoDelay = true
                        handler(client)
                    } catch (e: Exception) {
                        Log.d(TAG, "Соединение закрыто: ${e.javaClass.simpleName}: ${e.message}")
                    } finally {
                        untrackAndClose(client)
                        ProxyState.connectionClosed()
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- SOCKS5

    private suspend fun handleSocks(client: Socket) {
        // Небуферизованный поток: ни один байт клиента после рукопожатия не «застрянет» в буфере.
        val input = DataInputStream(client.getInputStream())
        val out = client.getOutputStream()
        client.soTimeout = HANDSHAKE_TIMEOUT_MS

        val version = input.readUnsignedByte()
        if (version != 5) {
            Log.d(TAG, "Не SOCKS5 (версия $version)")
            return
        }
        val nMethods = input.readUnsignedByte()
        val methods = ByteArray(nMethods)
        input.readFully(methods)
        if (methods.none { it.toInt() == 0 }) {
            out.write(byteArrayOf(5, 0xFF.toByte()))
            out.flush()
            return
        }
        out.write(byteArrayOf(5, 0))
        out.flush()

        val ver = input.readUnsignedByte()
        val cmd = input.readUnsignedByte()
        input.readUnsignedByte() // RSV
        val atyp = input.readUnsignedByte()
        var literal: InetAddress? = null
        val host: String = when (atyp) {
            1 -> {
                val b = ByteArray(4); input.readFully(b)
                literal = InetAddress.getByAddress(b); literal.hostAddress ?: ""
            }
            3 -> {
                val len = input.readUnsignedByte()
                val b = ByteArray(len); input.readFully(b)
                String(b, Charsets.US_ASCII)
            }
            4 -> {
                val b = ByteArray(16); input.readFully(b)
                literal = InetAddress.getByAddress(b); literal.hostAddress ?: ""
            }
            else -> {
                socksReply(out, 8); return
            }
        }
        val port = input.readUnsignedShort()
        if (ver != 5 || cmd != 1) {
            socksReply(out, 7) // command not supported (UDP ASSOCIATE / BIND)
            return
        }

        val upstream = try {
            connectUpstream(host, literal, port)
        } catch (e: UpstreamSocksException) {
            socksReply(out, e.socksCode); return
        } catch (e: UnknownHostException) {
            socksReply(out, 4); return
        } catch (e: IOException) {
            socksReply(out, 5); return
        }
        try {
            socksReply(out, 0)
            client.soTimeout = 0
            tunnel(client, upstream, null)
        } finally {
            untrackAndClose(upstream)
        }
    }

    private fun socksReply(out: OutputStream, code: Int) {
        try {
            out.write(byteArrayOf(5, code.toByte(), 0, 1, 0, 0, 0, 0, 0, 0))
            out.flush()
        } catch (e: IOException) {
            // клиент уже ушёл
        }
    }

    // ---------------------------------------------------------------- HTTP

    private suspend fun handleHttp(client: Socket) {
        val input = client.getInputStream()
        val out = client.getOutputStream()
        client.soTimeout = HANDSHAKE_TIMEOUT_MS
        val headerBytes = readHttpHeader(input) ?: return
        val header = String(headerBytes, Charsets.ISO_8859_1)
        val lines = header.split("\r\n")
        val parts = lines.first().split(" ")
        if (parts.size < 3) {
            httpError(out, 400, "Bad Request"); return
        }
        val method = parts[0].uppercase()
        val target = parts[1]
        val version = parts[2]

        if (method == "CONNECT") {
            val (host, port) = parseHostPort(target, 443) ?: run {
                httpError(out, 400, "Bad Request"); return
            }
            val upstream = try {
                connectUpstream(host, null, port)
            } catch (e: IOException) {
                httpError(out, 502, "Bad Gateway"); return
            }
            try {
                out.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray(Charsets.ISO_8859_1))
                out.flush()
                client.soTimeout = 0
                tunnel(client, upstream, null)
            } finally {
                untrackAndClose(upstream)
            }
            return
        }

        // Обычный HTTP-запрос с абсолютным URI.
        val uri = try {
            URI(target)
        } catch (e: Exception) {
            httpError(out, 400, "Bad Request"); return
        }
        val host = uri.host
        if (uri.scheme?.lowercase() != "http" || host.isNullOrEmpty()) {
            httpError(out, 400, "Bad Request"); return
        }
        val port = if (uri.port > 0) uri.port else 80
        val path = buildString {
            append(if (uri.rawPath.isNullOrEmpty()) "/" else uri.rawPath)
            if (uri.rawQuery != null) append('?').append(uri.rawQuery)
        }
        val rebuilt = StringBuilder()
        rebuilt.append(method).append(' ').append(path).append(' ').append(version).append("\r\n")
        for (line in lines.drop(1)) {
            if (line.isEmpty()) continue
            val name = line.substringBefore(':').trim().lowercase()
            if (name == "proxy-connection" || name == "proxy-authorization" || name == "connection" ||
                name == "keep-alive"
            ) continue
            rebuilt.append(line).append("\r\n")
        }
        rebuilt.append("Connection: close\r\n\r\n")

        val upstream = try {
            connectUpstream(host.removePrefix("[").removeSuffix("]"), null, port)
        } catch (e: IOException) {
            httpError(out, 502, "Bad Gateway"); return
        }
        try {
            client.soTimeout = 0
            tunnel(client, upstream, rebuilt.toString().toByteArray(Charsets.ISO_8859_1))
        } finally {
            untrackAndClose(upstream)
        }
    }

    private fun readHttpHeader(input: InputStream): ByteArray? {
        val buf = ByteArrayOutputStream()
        var state = 0
        while (buf.size() < MAX_HTTP_HEADER) {
            val b = input.read()
            if (b < 0) return null
            buf.write(b)
            state = when {
                b == '\r'.code && (state == 0 || state == 2) -> state + 1
                b == '\n'.code && (state == 1 || state == 3) -> state + 1
                b == '\r'.code -> 1
                else -> 0
            }
            if (state == 4) return buf.toByteArray()
        }
        return null
    }

    private fun parseHostPort(target: String, defaultPort: Int): Pair<String, Int>? {
        return try {
            if (target.startsWith("[")) {
                val end = target.indexOf(']')
                if (end < 0) return null
                val host = target.substring(1, end)
                val port = target.substring(end + 1).removePrefix(":").toIntOrNull() ?: defaultPort
                host to port
            } else {
                val idx = target.lastIndexOf(':')
                if (idx < 0) target to defaultPort
                else target.substring(0, idx) to (target.substring(idx + 1).toIntOrNull() ?: defaultPort)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun httpError(out: OutputStream, code: Int, text: String) {
        try {
            out.write("HTTP/1.1 $code $text\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray(Charsets.ISO_8859_1))
            out.flush()
        } catch (e: IOException) {
            // игнорируем
        }
    }

    // ---------------------------------------------------------------- общий туннель

    @Throws(IOException::class)
    private fun connectUpstream(host: String, literal: InetAddress?, port: Int): Socket {
        if (port !in 1..65535) throw IOException("Неверный порт $port")
        return if (chain) connectViaSocks(host, literal, port) else connectDirect(host, literal, port)
    }

    /**
     * Подключение через внешний SOCKS5 (Orbot: 127.0.0.1:9050).
     * Имя хоста передаётся как домен (ATYP 0x03) — Tor резолвит его сам, DoH не используется.
     * IP-литералы (Telegram ходит по IP) передаются как IPv4/IPv6.
     */
    @Throws(IOException::class)
    private fun connectViaSocks(host: String, literal: InetAddress?, port: Int): Socket {
        val endpoint = "$chainHost:$chainPort"
        val s = Socket(Proxy.NO_PROXY)
        try {
            s.tcpNoDelay = true
            s.keepAlive = true
            try {
                s.connect(InetSocketAddress(chainHost, chainPort), UPSTREAM_CONNECT_TIMEOUT_MS)
            } catch (e: IOException) {
                throw UpstreamSocksException(unavailableMessage(endpoint), 1, e, unavailable = true)
            }
            track(s)
            // Tor строит цепь до цели — это может занять десятки секунд.
            s.soTimeout = TOR_HANDSHAKE_TIMEOUT_MS
            val input = DataInputStream(s.getInputStream())
            val out = s.getOutputStream()

            // Приветствие: версия 5, 1 метод, «без аутентификации».
            out.write(byteArrayOf(5, 1, 0))
            out.flush()
            val greeting = try {
                input.readUnsignedByte() to input.readUnsignedByte()
            } catch (e: IOException) {
                throw UpstreamSocksException(unavailableMessage(endpoint), 1, e, unavailable = true)
            }
            val greetVer = greeting.first
            val method = greeting.second
            if (greetVer != 5 || method != 0) {
                throw UpstreamSocksException(
                    "$chainLabel на $endpoint не принял SOCKS5 без пароля (ответ $greetVer/$method)", 1,
                    unavailable = true
                )
            }

            // CONNECT.
            val req = ByteArrayOutputStream()
            req.write(byteArrayOf(5, 1, 0))
            val ip: InetAddress? = literal ?: if (DohResolver.looksLikeIp(host)) InetAddress.getByName(host) else null
            when (ip) {
                is Inet4Address -> { req.write(1); req.write(ip.address) }
                is Inet6Address -> { req.write(4); req.write(ip.address) }
                else -> {
                    val name = host.toByteArray(Charsets.US_ASCII)
                    if (name.isEmpty() || name.size > 255) throw UpstreamSocksException("Слишком длинное имя хоста", 4)
                    req.write(3); req.write(name.size); req.write(name)
                }
            }
            req.write((port shr 8) and 0xFF)
            req.write(port and 0xFF)
            out.write(req.toByteArray())
            out.flush()

            val reply = try {
                val v = input.readUnsignedByte()
                val r = input.readUnsignedByte()
                input.readUnsignedByte() // RSV
                when (input.readUnsignedByte()) {
                    1 -> input.readFully(ByteArray(4))
                    3 -> input.readFully(ByteArray(input.readUnsignedByte()))
                    4 -> input.readFully(ByteArray(16))
                    else -> throw IOException("неизвестный ATYP в ответе")
                }
                input.readUnsignedShort()
                v to r
            } catch (e: SocketTimeoutException) {
                throw UpstreamSocksException("$chainLabel не успел подключиться к $host:$port (таймаут)", 6, e)
            }
            val ver = reply.first
            val rep = reply.second
            if (ver != 5) throw UpstreamSocksException("$chainLabel вернул не SOCKS5-ответ", 1)
            if (rep != 0) {
                // Ошибка конкретного адреса — не глобальная, в общий статус не пишем.
                Log.d(TAG, "$chainLabel: $host:$port → ${socksErrorText(rep)}")
                throw UpstreamSocksException("$chainLabel: ${socksErrorText(rep)}", rep.coerceIn(1, 8))
            }
            s.soTimeout = 0
            ProxyState.clearErrorIf { it.startsWith(chainLabel) }
            return s
        } catch (e: UpstreamSocksException) {
            untrackAndClose(s)
            if (e.unavailable) {
                Log.w(TAG, e.message ?: "")
                ProxyState.setError(e.message)
            }
            throw e
        } catch (e: IOException) {
            untrackAndClose(s)
            throw UpstreamSocksException("$chainLabel: ${e.message}", 1, e)
        }
    }

    private fun unavailableMessage(endpoint: String): String =
        if (config.useTor) "$chainLabel $UNAVAILABLE_MARKER $endpoint — запустите Orbot и дождитесь «Connected»"
        else "$chainLabel $UNAVAILABLE_MARKER $endpoint"

    private fun socksErrorText(code: Int): String = when (code) {
        1 -> "общая ошибка SOCKS-сервера"
        2 -> "соединение запрещено правилами"
        3 -> "сеть недоступна"
        4 -> "хост недоступен"
        5 -> "в соединении отказано"
        6 -> "истёк TTL / таймаут цепи"
        7 -> "команда не поддерживается"
        8 -> "тип адреса не поддерживается"
        else -> "код $code"
    }

    @Throws(IOException::class)
    private fun connectDirect(host: String, literal: InetAddress?, port: Int): Socket {
        val addresses: List<InetAddress> = when {
            literal != null -> listOf(literal)
            DohResolver.looksLikeIp(host) -> listOf(InetAddress.getByName(host))
            else -> resolver.resolve(host)
        }.sortedBy { if (it is Inet4Address) 0 else 1 }

        var last: IOException = UnknownHostException(host)
        for (addr in addresses) {
            // NO_PROXY: никогда не ходим через системный прокси (защита от петли).
            val s = Socket(Proxy.NO_PROXY)
            try {
                s.tcpNoDelay = true
                s.keepAlive = true
                s.connect(InetSocketAddress(addr, port), CONNECT_TIMEOUT_MS)
                track(s)
                return s
            } catch (e: IOException) {
                closeQuietly(s)
                last = e
            }
        }
        throw last
    }

    /**
     * Двунаправленная передача. Поток «сервер → клиент» стартует сразу (на случай протоколов,
     * где сервер говорит первым), а первый пакет клиента проходит через фрагментатор.
     */
    private suspend fun tunnel(client: Socket, upstream: Socket, initial: ByteArray?) = coroutineScope {
        val down = launch {
            try {
                pipe(upstream.getInputStream(), client.getOutputStream())
                try { client.shutdownOutput() } catch (e: IOException) { }
            } catch (e: IOException) {
                closeQuietly(client); closeQuietly(upstream)
            }
        }
        try {
            val cin = client.getInputStream()
            val uout = upstream.getOutputStream()
            if (chain) {
                // Через Tor провайдер видит только Tor-трафик — фрагментация не нужна.
                if (initial != null) {
                    uout.write(initial)
                    uout.flush()
                }
            } else if (initial != null) {
                Fragmenter.send(initial, uout, frag)
            } else {
                val first = readFirstPayload(client, cin)
                if (first != null) Fragmenter.send(first, uout, frag)
            }
            pipe(cin, uout)
            try { upstream.shutdownOutput() } catch (e: IOException) { }
        } catch (e: IOException) {
            closeQuietly(client); closeQuietly(upstream)
        }
        down.join()
    }

    /** Читает первый пакет клиента; для TLS дочитывает запись ClientHello целиком. */
    private fun readFirstPayload(client: Socket, input: InputStream): ByteArray? {
        val buf = ByteArray(MAX_FIRST_PACKET)
        val n = input.read(buf)
        if (n <= 0) return null
        var total = n
        if (buf[0].toInt() == 0x16) {
            val oldTimeout = client.soTimeout
            client.soTimeout = FIRST_PACKET_TIMEOUT_MS
            try {
                while (total < 5) {
                    val r = input.read(buf, total, 5 - total)
                    if (r < 0) break
                    total += r
                }
                if (total >= 5) {
                    val need = minOf(MAX_FIRST_PACKET, 5 + Fragmenter.recordLength(buf))
                    while (total < need) {
                        val r = input.read(buf, total, need - total)
                        if (r < 0) break
                        total += r
                    }
                }
            } catch (e: SocketTimeoutException) {
                // отправим то, что есть
            } finally {
                client.soTimeout = oldTimeout
            }
        }
        return buf.copyOf(total)
    }

    private fun pipe(input: InputStream, output: OutputStream) {
        val buf = ByteArray(BUFFER_SIZE)
        while (true) {
            val r = input.read(buf)
            if (r < 0) break
            if (r > 0) {
                output.write(buf, 0, r)
                output.flush()
            }
        }
    }

    private fun track(s: Socket) {
        openSockets += s
        if (!running) closeQuietly(s)
    }

    private fun untrackAndClose(s: Socket) {
        openSockets -= s
        closeQuietly(s)
    }

    private fun closeQuietly(c: Closeable?) {
        try {
            c?.close()
        } catch (e: Exception) {
            // игнорируем
        }
    }

    companion object {
        private const val TAG = "ProxyEngine"
        private const val CONNECT_TIMEOUT_MS = 10_000
        private const val UPSTREAM_CONNECT_TIMEOUT_MS = 3_000
        private const val TOR_HANDSHAKE_TIMEOUT_MS = 60_000
        const val UNAVAILABLE_MARKER = "недоступен на"
        private const val HANDSHAKE_TIMEOUT_MS = 15_000
        private const val FIRST_PACKET_TIMEOUT_MS = 1_500
        private const val MAX_FIRST_PACKET = 16_384 + 5
        private const val MAX_HTTP_HEADER = 32_768
        private const val BUFFER_SIZE = 32_768
    }
}
