package com.dmitry.dpibypass

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.Socket

/** Работа с Orbot (официальный клиент Tor для Android). */
object OrbotHelper {
    const val ORBOT_PACKAGE = "org.torproject.android"
    const val ORBOT_NIGHTLY_PACKAGE = "org.torproject.android.nightly"
    private val PACKAGES = listOf(ORBOT_PACKAGE, ORBOT_NIGHTLY_PACKAGE)

    /** Документированное Orbot действие запуска Tor (см. OrbotHelper в info.guardianproject.netcipher). */
    const val ACTION_START = "org.torproject.android.intent.action.START"
    const val EXTRA_PACKAGE_NAME = "org.torproject.android.intent.extra.PACKAGE_NAME"

    const val FDROID_URL = "https://guardianproject.info/fdroid/"

    /** Пакет установленного Orbot или null. */
    fun installedPackage(context: Context): String? {
        val pm = context.packageManager
        for (pkg in PACKAGES) {
            try {
                if (Build.VERSION.SDK_INT >= 33) {
                    pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getPackageInfo(pkg, 0)
                }
                return pkg
            } catch (e: PackageManager.NameNotFoundException) {
                // нет такого пакета
            }
        }
        return null
    }

    fun isInstalled(context: Context): Boolean = installedPackage(context) != null

    /**
     * Просит Orbot запустить Tor (broadcast ACTION_START) и открывает его окно,
     * чтобы пользователь видел статус подключения.
     * @return true, если удалось что-то запустить.
     */
    fun startOrbot(context: Context): Boolean {
        val pkg = installedPackage(context) ?: return false
        var ok = false
        try {
            val start = Intent(ACTION_START)
                .setPackage(pkg)
                .putExtra(EXTRA_PACKAGE_NAME, context.packageName)
            context.sendBroadcast(start)
            ok = true
        } catch (e: Exception) {
            // старые версии могут не принимать broadcast
        }
        val launch = context.packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) {
            try {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                ok = true
            } catch (e: Exception) {
                // игнорируем
            }
        }
        return ok
    }

    /** Открывает страницу Orbot в Google Play (приложение или браузер). */
    fun openInstallPage(context: Context): Boolean {
        val candidates = listOf(
            Uri.parse("market://details?id=$ORBOT_PACKAGE"),
            Uri.parse("https://play.google.com/store/apps/details?id=$ORBOT_PACKAGE")
        )
        return candidates.any { openUri(context, it) }
    }

    /** Открывает репозиторий F-Droid Guardian Project (если Google Play недоступен). */
    fun openFdroidPage(context: Context): Boolean = openUri(context, Uri.parse(FDROID_URL))

    private fun openUri(context: Context, uri: Uri): Boolean = try {
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }

    /** Проверяет, слушает ли кто-то SOCKS на host:port, и отвечает ли он как SOCKS5. Вызывать не из UI-потока. */
    fun isTorSocksReady(host: String = TOR_SOCKS_HOST, port: Int = TOR_SOCKS_PORT, timeoutMs: Int = 1_500): Boolean {
        val s = Socket(Proxy.NO_PROXY)
        return try {
            s.connect(InetSocketAddress(host, port), timeoutMs)
            s.soTimeout = timeoutMs
            val out = s.getOutputStream()
            out.write(byteArrayOf(5, 1, 0))
            out.flush()
            val input = s.getInputStream()
            val ver = input.read()
            val method = input.read()
            ver == 5 && method == 0
        } catch (e: IOException) {
            false
        } finally {
            try { s.close() } catch (e: IOException) { }
        }
    }
}
