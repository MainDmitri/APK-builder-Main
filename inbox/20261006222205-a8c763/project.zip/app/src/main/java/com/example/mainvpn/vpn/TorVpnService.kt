package com.example.mainvpn.vpn

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.Process
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.mainvpn.MainActivity
import com.example.mainvpn.R
import com.example.mainvpn.core.ConnState
import com.example.mainvpn.core.HopRole
import com.example.mainvpn.core.LogFile
import com.example.mainvpn.core.LogLine
import com.example.mainvpn.core.Protocol
import com.example.mainvpn.core.RelayInfo
import com.example.mainvpn.core.VpnStatus
import com.example.mainvpn.data.AppSettings
import com.example.mainvpn.data.BridgeMode
import com.example.mainvpn.data.SettingsStore
import com.example.mainvpn.net.Onionoo
import com.example.mainvpn.net.TorHttp
import com.example.mainvpn.tor.Bridges
import com.example.mainvpn.tor.PluggableTransports
import com.example.mainvpn.tor.TorController
import org.json.JSONObject
import java.io.File
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Системный VPN: поднимает TUN, запускает Tor (и при необходимости мосты),
 * перехватывает трафик приложений и отправляет его в Tor.
 * Работает в отдельном процессе :vpn, который завершается при отключении — так Tor
 * каждый раз стартует в чистом процессе.
 */
class TorVpnService : VpnService(), TorController.Listener {

    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "vpn-worker") }
    private val background = Executors.newCachedThreadPool { r -> Thread(r, "vpn-bg").apply { isDaemon = true } }
    private val scheduler = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "vpn-tick").apply { isDaemon = true } }
    private val mainHandler = Handler(Looper.getMainLooper())

    private val statusLock = Any()
    private var status = VpnStatus()

    @Volatile private var settings = AppSettings()
    @Volatile private var tunFd: ParcelFileDescriptor? = null
    @Volatile private var engine: PacketEngine? = null
    @Volatile private var tor: TorController? = null
    private var transports: PluggableTransports? = null
    @Volatile private var activeBridgeLines: List<String> = emptyList()

    private val started = AtomicBoolean(false)
    private val stopping = AtomicBoolean(false)
    @Volatile private var bootstrapDone = false
    @Volatile private var torDead = false
    @Volatile private var bootstrapStartedAt = 0L
    @Volatile private var snowflakeSuggested = false

    private lateinit var connectivity: ConnectivityManager
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var currentNetwork: Network? = null
    @Volatile private var systemDns: List<InetAddress> = emptyList()
    @Volatile private var networkLost = false
    @Volatile private var awaitingResync = false
    @Volatile private var resyncDeadline = 0L
    @Volatile private var reconnectDelaySec = 1
    @Volatile private var reconnectAt = 0L
    private var reconnectTask: ScheduledFuture<*>? = null

    private val pendingLogs = ArrayList<LogLine>()
    private val relayCountry = ConcurrentHashMap<String, String>()
    private val guardLatency = ConcurrentHashMap<String, Pair<Long, Long>>()
    private val circuitDirty = AtomicBoolean(true)
    private val circuitJob = AtomicBoolean(false)
    private val pingJob = AtomicBoolean(false)
    private val exitJob = AtomicBoolean(false)
    private val resyncProbe = AtomicBoolean(false)
    @Volatile private var lastCircuitRefresh = 0L
    @Volatile private var lastPing = 0L
    private var lastNotificationText = ""

    override fun onCreate() {
        super.onCreate()
        connectivity = getSystemService(ConnectivityManager::class.java)
        createNotificationChannel()
        scheduler.scheduleWithFixedDelay({ runCatching { flushLogs() } }, 500, 500, TimeUnit.MILLISECONDS)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            Protocol.ACTION_STOP -> {
                if (started.get()) {
                    Thread({ shutdown(ConnState.OFF, "") }, "vpn-stop").start()
                } else {
                    stopSelf()
                }
            }
            Protocol.ACTION_NEW_IDENTITY -> ifRunning { worker.execute { newIdentity(rebuild = false) } }
            Protocol.ACTION_REBUILD_CIRCUIT -> ifRunning { worker.execute { newIdentity(rebuild = true) } }
            Protocol.ACTION_UPDATE_SETTINGS -> ifRunning {
                val raw = intent.getStringExtra(Protocol.EXTRA_SETTINGS_JSON)
                if (raw != null) {
                    val newSettings = AppSettings.fromJson(JSONObject(raw))
                    worker.execute { updateSettings(newSettings) }
                }
            }
            Protocol.ACTION_DISMISS_SNOWFLAKE -> ifRunning { update { it.copy(suggestSnowflake = false) } }
            else -> startTunnel()
        }
        return START_NOT_STICKY
    }

    private inline fun ifRunning(block: () -> Unit) {
        if (started.get() && !stopping.get()) block() else if (!started.get()) stopSelf()
    }

    override fun onRevoke() {
        log(LogLine.Level.WARN, "Система отозвала VPN (включён другой VPN или разрешение отозвано)")
        Thread({ shutdown(ConnState.OFF, "VPN отключён системой") }, "vpn-revoke").start()
    }

    override fun onDestroy() {
        if (started.get() && !stopping.get()) {
            // Система уничтожает службу без команды: закрываем туннель немедленно.
            stopping.set(true)
            engine?.stop()
            publish(VpnStatus(state = ConnState.OFF, updatedAt = System.currentTimeMillis()))
        }
        flushLogs()
        scheduler.shutdownNow()
        background.shutdownNow()
        worker.shutdownNow()
        super.onDestroy()
        if (started.get()) {
            // Tor (libtor) нельзя надёжно перезапустить в том же процессе — завершаем процесс :vpn.
            Process.killProcess(Process.myPid())
        }
    }

    // ---------------------------------------------------------------- запуск

    private fun startTunnel() {
        // startForegroundService обязывает вызвать startForeground даже для повторной команды.
        startForegroundCompat(buildNotification("Подключение к сети Tor…"))
        if (!started.compareAndSet(false, true)) {
            if (stopping.get()) {
                publish(
                    VpnStatus(
                        state = ConnState.OFF,
                        message = "Предыдущий сеанс ещё завершается — нажмите кнопку ещё раз",
                        updatedAt = System.currentTimeMillis()
                    )
                )
                mainHandler.post {
                    ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            } else {
                notifySafely(NOTIFICATION_ID, buildNotification(notificationText(currentStatus())))
                publish(currentStatus())
            }
            return
        }
        settings = SettingsStore.load(this)
        bootstrapStartedAt = SystemClock.elapsedRealtime()
        update {
            VpnStatus(
                running = true,
                state = ConnState.CONNECTING,
                bootstrapSummary = "Запуск VPN-интерфейса",
                bridgeMode = settings.bridgeMode.name,
                exitCountrySetting = settings.exitCountry
            )
        }
        log(LogLine.Level.INFO, "Запуск туннеля (мосты: ${settings.bridgeMode.title})")
        scheduler.scheduleWithFixedDelay({
            try {
                tick()
            } catch (e: Exception) {
                log(LogLine.Level.WARN, "Ошибка периодической задачи: ${e.message}")
            }
        }, 1, 1, TimeUnit.SECONDS)
        worker.execute { connect() }
    }

    private fun connect() {
        try {
            if (VpnService.prepare(this) != null) {
                throw IllegalStateException("нет разрешения на VPN — подключитесь из приложения")
            }
            registerNetworkCallback()
            establishTun()
            update { it.copy(bootstrapSummary = "Запуск Tor") }

            val plan = startTransports(Bridges.linesFor(settings))
            activeBridgeLines = plan.first
            val controller = TorController(this, ::log, this)
            tor = controller
            controller.start(buildTorrc(plan.first, plan.second))
            update { it.copy(socksPort = controller.socksPort, dnsPort = controller.dnsPort) }
        } catch (e: Exception) {
            if (stopping.get()) return
            log(LogLine.Level.ERROR, "Ошибка запуска: ${e.message}")
            fail("Ошибка инициализации: ${e.message}")
        }
    }

    private fun establishTun() {
        val builder = Builder()
            .setSession(getString(R.string.app_name))
            .setMtu(PacketEngine.MTU)
            .addAddress(PacketEngine.ADDRESS_V4, 24)
            .addRoute("0.0.0.0", 0)
            .addDnsServer(PacketEngine.DNS_V4)
        try {
            builder.addAddress(PacketEngine.ADDRESS_V6, 64)
            builder.addRoute("::", 0)
        } catch (e: IllegalArgumentException) {
            log(LogLine.Level.WARN, "IPv6 в туннеле недоступен: ${e.message}")
        }
        builder.setBlocking(true)
        // Само приложение (и Tor внутри него) должно ходить в сеть напрямую, иначе Tor зациклится в туннеле.
        builder.addDisallowedApplication(packageName)
        for (pkg in settings.excludedApps) {
            try {
                builder.addDisallowedApplication(pkg)
            } catch (e: PackageManager.NameNotFoundException) {
                log(LogLine.Level.WARN, "Приложение $pkg не найдено, исключение пропущено")
            }
        }
        if (settings.excludedApps.isNotEmpty()) {
            log(LogLine.Level.INFO, "Раздельное туннелирование: исключено приложений — ${settings.excludedApps.size}")
        }
        builder.setConfigureIntent(
            PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) builder.setMetered(false)
        currentNetwork?.let { builder.setUnderlyingNetworks(arrayOf(it)) }

        val fd = builder.establish() ?: throw IllegalStateException("система не создала VPN-интерфейс")
        tunFd = fd
        val e = PacketEngine(
            fd,
            socksPort = { tor?.socksPort ?: -1 },
            dnsPort = { tor?.dnsPort ?: -1 },
            dnsProtection = { settings.dnsProtection },
            systemDns = { systemDns },
            onFatal = { msg -> worker.execute { fail(msg) } }
        )
        engine = e
        e.start()
        log(LogLine.Level.INFO, "VPN-интерфейс поднят (${PacketEngine.ADDRESS_V4}/24, DNS ${PacketEngine.DNS_V4}); трафик заморожен до готовности Tor")
    }

    /** Запускает нужные транспорты; возвращает пригодные строки мостов и порты плагинов. */
    private fun startTransports(lines: List<String>): Pair<List<String>, Map<String, Int>> {
        if (lines.isEmpty()) return lines to emptyMap()
        val pts = transports ?: PluggableTransports(this, ::log).also { transports = it }
        val plugins = LinkedHashMap<String, Int>()
        val usable = ArrayList<String>()
        for (line in lines) {
            val transport = Bridges.transportOf(line)
            if (transport == null) {
                usable.add(line)
                continue
            }
            if (!pts.isSupported(transport)) {
                log(LogLine.Level.WARN, "Транспорт «$transport» не поддерживается, мост пропущен")
                continue
            }
            if (transport !in plugins) {
                try {
                    plugins[transport] = pts.start(transport, line)
                } catch (e: Exception) {
                    log(LogLine.Level.ERROR, "Не удалось запустить транспорт $transport: ${e.message}")
                    continue
                }
            }
            usable.add(line)
        }
        if (usable.isEmpty()) throw IllegalStateException("ни один мост не может быть использован")
        return usable to plugins
    }

    private fun exitCacheFile() = File(filesDir, "exit_nodes.txt")

    private fun buildTorrc(bridgeLines: List<String>, plugins: Map<String, Int>): String {
        val sb = StringBuilder()
        // Фиксированные порты: листенеры с "auto" Tor пересоздаёт на новых портах при каждом SETCONF.
        sb.appendLine("SocksPort 127.0.0.1:${TorController.freeTcpPort()} IPv6Traffic")
        sb.appendLine("DNSPort 127.0.0.1:${TorController.freeUdpPort()}")
        sb.appendLine("AutomapHostsOnResolve 1")
        sb.appendLine("AutomapHostsSuffixes .onion,.exit")
        sb.appendLine("VirtualAddrNetworkIPv4 10.192.0.0/10")
        sb.appendLine("VirtualAddrNetworkIPv6 [FC00::]/7")
        sb.appendLine("ClientOnly 1")
        sb.appendLine("ClientUseIPv6 1")
        sb.appendLine("AvoidDiskWrites 1")
        sb.appendLine("SafeLogging 1")
        val country = settings.exitCountry
        val cache = exitCacheFile()
        if (country.isNotEmpty() && cache.exists()) {
            val lines = cache.readLines()
            if (lines.size >= 2 && lines[0] == country && lines[1].isNotBlank()) {
                sb.appendLine("ExitNodes " + lines[1].split(',').joinToString(",") { "\$$it" })
                sb.appendLine("StrictNodes 1")
            }
        }
        if (bridgeLines.isNotEmpty()) {
            sb.appendLine("UseBridges 1")
            plugins.forEach { (t, port) -> sb.appendLine("ClientTransportPlugin $t socks5 127.0.0.1:$port") }
            bridgeLines.forEach { sb.appendLine("Bridge $it") }
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- события Tor

    override fun onPortsChanged(socksPort: Int, dnsPort: Int) {
        update { it.copy(socksPort = socksPort, dnsPort = dnsPort) }
    }

    override fun onBootstrap(progress: Int, summary: String) {
        if (bootstrapDone) return
        update { it.copy(bootstrap = progress, bootstrapSummary = summary) }
        if (progress >= 100) {
            bootstrapDone = true
            worker.execute { onTorReady() }
        }
    }

    private fun onTorReady() {
        val t = tor ?: return
        log(LogLine.Level.INFO, "Bootstrap 100%: цепочки Tor готовы")
        if (settings.exitCountry.isNotEmpty()) {
            update { it.copy(bootstrapSummary = "Применение страны выхода") }
            applyExitCountry(t)
        }
        if (networkLost || torDead) return
        engine?.setFrozen(false)
        update { it.copy(state = ConnState.CONNECTED, message = "", suggestSnowflake = false) }
        log(LogLine.Level.INFO, "Туннель активен: трафик устройства идёт через Tor")
        background.execute { refreshExitInfo() }
        circuitDirty.set(true)
    }

    override fun onCircuitEstablished(established: Boolean) {
        if (!bootstrapDone || networkLost || awaitingResync || torDead) return
        if (!established) {
            engine?.setFrozen(true)
            update { it.copy(state = ConnState.ERROR, message = "Цепочка Tor разорвана — восстанавливаю, трафик приостановлен") }
        } else if (currentStatus().state == ConnState.ERROR) {
            engine?.setFrozen(false)
            update { it.copy(state = ConnState.CONNECTED, message = "") }
            log(LogLine.Level.INFO, "Цепочка восстановлена")
            background.execute { refreshExitInfo() }
        }
        circuitDirty.set(true)
    }

    override fun onBandwidth(read: Long, written: Long) {
        synchronized(statusLock) {
            status = status.copy(
                rxRate = read,
                txRate = written,
                rxTotal = status.rxTotal + read,
                txTotal = status.txTotal + written
            )
        }
    }

    override fun onCircuitChanged() {
        circuitDirty.set(true)
    }

    override fun onTorStopped(reason: String) {
        if (stopping.get()) return
        torDead = true
        worker.execute { fail(reason) }
    }

    /** Ошибка: при включённой аварийной блокировке туннель удерживается и весь трафик блокируется. */
    private fun fail(reason: String) {
        if (stopping.get()) return
        if (settings.killSwitch && tunFd != null) {
            engine?.setFrozen(true)
            update {
                it.copy(
                    state = ConnState.ERROR,
                    message = "$reason. Аварийная блокировка: интернет заблокирован, пока вы не отключите VPN"
                )
            }
            log(LogLine.Level.ERROR, "Kill Switch: трафик заблокирован ($reason)")
        } else {
            shutdown(ConnState.ERROR, reason)
        }
    }

    // ---------------------------------------------------------------- команды

    private fun newIdentity(rebuild: Boolean) {
        val t = tor ?: return
        if (!bootstrapDone || torDead) return
        update { it.copy(state = ConnState.UPDATING, message = if (rebuild) "Перестроение цепочки" else "Новая личность") }
        try {
            if (rebuild) {
                val closed = t.closeCircuits()
                log(LogLine.Level.INFO, "Закрыто цепочек: $closed")
            }
            t.newIdentity()
        } catch (e: Exception) {
            log(LogLine.Level.ERROR, "Не удалось сменить цепочку: ${e.message}")
        }
        relayCountry.clear()
        circuitDirty.set(true)
        background.execute {
            refreshExitInfo()
            refreshCircuit()
            update {
                if (it.state == ConnState.UPDATING) it.copy(state = ConnState.CONNECTED, message = "") else it
            }
        }
    }

    private fun applyExitCountry(t: TorController) {
        val country = settings.exitCountry
        try {
            if (country.isEmpty()) {
                t.setExitNodes(emptyList())
                exitCacheFile().delete()
                log(LogLine.Level.INFO, "Страна выхода: автоматически (ExitNodes сброшен)")
            } else {
                val fps = Onionoo.exitFingerprints(t.socksPort, country)
                if (fps.isEmpty()) {
                    log(LogLine.Level.WARN, "В стране ${country.uppercase()} сейчас нет выходных узлов — оставлен прежний выбор")
                    update { it.copy(message = "Нет выходных узлов в стране ${country.uppercase()}") }
                    return
                }
                t.setExitNodes(fps)
                exitCacheFile().writeText(country + "\n" + fps.joinToString(","))
                log(LogLine.Level.INFO, "ExitNodes: ${fps.size} узлов страны {${country}}, StrictNodes 1")
            }
            t.closeCircuits()
            t.newIdentity()
            relayCountry.clear()
            circuitDirty.set(true)
        } catch (e: Exception) {
            log(LogLine.Level.ERROR, "Не удалось применить страну выхода: ${e.message}")
            update { it.copy(message = "Страна выхода не применена: ${e.message}") }
        }
    }

    private fun updateSettings(newSettings: AppSettings) {
        val old = settings
        settings = newSettings
        update { it.copy(bridgeMode = newSettings.bridgeMode.name, exitCountrySetting = newSettings.exitCountry) }
        val t = tor ?: return
        if (old.bridgeMode != newSettings.bridgeMode || old.customBridges != newSettings.customBridges ||
            old.builtinBridgesJson != newSettings.builtinBridgesJson
        ) {
            try {
                val plan = startTransports(Bridges.linesFor(newSettings))
                t.applyBridges(plan.first, plan.second)
                activeBridgeLines = plan.first
                t.closeCircuits()
                log(LogLine.Level.INFO, "Мосты применены без перезапуска: ${newSettings.bridgeMode.title}")
                if (!bootstrapDone) {
                    bootstrapStartedAt = SystemClock.elapsedRealtime()
                    snowflakeSuggested = newSettings.bridgeMode == BridgeMode.SNOWFLAKE
                    update { it.copy(suggestSnowflake = false, bootstrapSummary = "Подключение через мосты") }
                }
            } catch (e: Exception) {
                log(LogLine.Level.ERROR, "Мосты не применены: ${e.message}")
            }
        }
        if (old.exitCountry != newSettings.exitCountry && bootstrapDone && !torDead) {
            update { it.copy(state = ConnState.UPDATING, message = "Смена страны выхода") }
            applyExitCountry(t)
            background.execute {
                refreshExitInfo()
                refreshCircuit()
                update { if (it.state == ConnState.UPDATING) it.copy(state = ConnState.CONNECTED, message = "") else it }
            }
        }
        if (old.excludedApps != newSettings.excludedApps) {
            log(LogLine.Level.INFO, "Список исключённых приложений применится при следующем подключении")
        }
        if (old.dnsProtection != newSettings.dnsProtection) {
            log(LogLine.Level.INFO, "Защита от утечек DNS: ${if (newSettings.dnsProtection) "включена" else "выключена"}")
        }
        if (old.killSwitch != newSettings.killSwitch) {
            log(LogLine.Level.INFO, "Аварийная блокировка: ${if (newSettings.killSwitch) "включена" else "выключена"}")
        }
    }

    // ---------------------------------------------------------------- сеть

    private fun registerNetworkCallback() {
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                // Сам VPN-интерфейс и сети без интернета не считаем сменой физической сети.
                val caps = connectivity.getNetworkCapabilities(network)
                if (caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) ||
                        !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))
                ) return
                val previous = currentNetwork
                currentNetwork = network
                systemDns = connectivity.getLinkProperties(network)?.dnsServers ?: emptyList()
                setUnderlyingNetworks(arrayOf(network))
                if (previous == null && !networkLost) return
                if (previous != network || networkLost) {
                    worker.execute { onNetworkSwitched() }
                }
            }

            override fun onLost(network: Network) {
                if (network == currentNetwork) {
                    currentNetwork = null
                    worker.execute { onNetworkLost() }
                }
            }

            override fun onLinkPropertiesChanged(network: Network, linkProperties: LinkProperties) {
                if (network == currentNetwork) systemDns = linkProperties.dnsServers
            }
        }
        connectivity.registerDefaultNetworkCallback(cb)
        networkCallback = cb
    }

    private fun onNetworkLost() {
        if (stopping.get() || torDead) return
        networkLost = true
        awaitingResync = false
        engine?.setFrozen(true)
        runCatching { tor?.setNetworkEnabled(false) }
        log(LogLine.Level.WARN, "Физическое подключение потеряно: VPN-адаптер удерживается, трафик заморожен")
        reconnectDelaySec = 1
        scheduleReconnect()
    }

    private fun onNetworkSwitched() {
        if (stopping.get() || torDead) return
        val wasLost = networkLost
        networkLost = false
        reconnectTask?.cancel(false)
        reconnectDelaySec = 1
        log(
            LogLine.Level.INFO,
            if (wasLost) "Сеть снова доступна" else "Смена сети (Wi-Fi/сотовая): трафик заморожен до синхронизации Tor"
        )
        attemptReconnect()
    }

    private fun scheduleReconnect() {
        reconnectTask?.cancel(false)
        val delay = reconnectDelaySec
        reconnectAt = SystemClock.elapsedRealtime() + delay * 1000L
        update {
            it.copy(
                state = ConnState.ERROR,
                message = "Нет подключения к интернету. Повтор через $delay с",
                networkFrozen = true
            )
        }
        reconnectTask = scheduler.schedule({ worker.execute { attemptReconnect() } }, delay.toLong(), TimeUnit.SECONDS)
    }

    private fun attemptReconnect() {
        if (stopping.get() || torDead) return
        val t = tor ?: return
        engine?.setFrozen(true)
        if (currentNetwork == null) {
            reconnectDelaySec = (reconnectDelaySec * 2).coerceAtMost(MAX_BACKOFF_SEC)
            log(LogLine.Level.INFO, "Сети нет, следующая попытка через $reconnectDelaySec с")
            scheduleReconnect()
            return
        }
        log(LogLine.Level.INFO, "Переподключение Tor к новой сети (окно ожидания ${maxOf(reconnectDelaySec, 15)} с)")
        try {
            t.setNetworkEnabled(false)
            t.setNetworkEnabled(true)
        } catch (e: Exception) {
            log(LogLine.Level.ERROR, "Tor не принял команду переподключения: ${e.message}")
        }
        if (!bootstrapDone) {
            update { it.copy(state = ConnState.CONNECTING, networkFrozen = true, message = "") }
            return
        }
        awaitingResync = true
        resyncDeadline = SystemClock.elapsedRealtime() + maxOf(reconnectDelaySec, 15) * 1000L
        update {
            it.copy(state = ConnState.UPDATING, message = "Синхронизация Tor с новой сетью", networkFrozen = true, reconnectInSec = 0)
        }
    }

    /** Проверка из тика: новая цепочка реально пропускает трафик → размораживаем туннель. */
    private fun checkResync() {
        if (!awaitingResync) return
        if (SystemClock.elapsedRealtime() > resyncDeadline) {
            awaitingResync = false
            reconnectDelaySec = (reconnectDelaySec * 2).coerceAtMost(MAX_BACKOFF_SEC)
            log(LogLine.Level.WARN, "Tor не синхронизировался, следующая попытка через $reconnectDelaySec с")
            worker.execute { scheduleReconnect() }
            return
        }
        val t = tor ?: return
        if (!resyncProbe.compareAndSet(false, true)) return
        background.execute {
            try {
                val ms = TorHttp.measureConnect(t.socksPort, PING_HOST, 443, 15_000)
                if (awaitingResync) {
                    awaitingResync = false
                    reconnectDelaySec = 1
                    engine?.setFrozen(false)
                    update {
                        it.copy(state = ConnState.CONNECTED, message = "", networkFrozen = false, pingMs = ms, reconnectInSec = 0)
                    }
                    log(LogLine.Level.INFO, "Tor синхронизирован с сетью, трафик разморожен (RTT $ms мс)")
                    relayCountry.clear()
                    circuitDirty.set(true)
                    refreshExitInfo()
                }
            } catch (e: Exception) {
                log(LogLine.Level.INFO, "Цепочка ещё не готова: ${e.message}")
            } finally {
                resyncProbe.set(false)
            }
        }
    }

    // ---------------------------------------------------------------- периодические задачи

    private fun tick() {
        if (stopping.get()) return
        val e = engine
        val now = SystemClock.elapsedRealtime()

        if (!bootstrapDone && !snowflakeSuggested && settings.bridgeMode != BridgeMode.SNOWFLAKE &&
            currentStatus().bootstrap < 15 && now - bootstrapStartedAt > 15_000 && tor != null
        ) {
            snowflakeSuggested = true
            log(LogLine.Level.WARN, "Bootstrap застрял ниже 15% дольше 15 с — возможна блокировка входных узлов")
            update { it.copy(suggestSnowflake = true) }
        }

        checkResync()

        val st = currentStatus()
        if (bootstrapDone && st.state == ConnState.CONNECTED) {
            if (now - lastPing > 15_000) {
                lastPing = now
                launch(pingJob) { measurePing() }
            }
            if (circuitDirty.get() && now - lastCircuitRefresh > 3_000 || now - lastCircuitRefresh > 30_000) {
                lastCircuitRefresh = now
                circuitDirty.set(false)
                launch(circuitJob) { refreshCircuit() }
            }
        }

        val lockdown = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && isLockdownEnabled
        val alwaysOn = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && isAlwaysOn
        val reconnectIn = if (networkLost) ((reconnectAt - now + 999) / 1000).toInt().coerceAtLeast(0) else 0
        update {
            it.copy(
                tcpSessions = e?.tcpSessions ?: 0,
                udpBlocked = e?.counters?.udpBlocked?.get() ?: 0,
                dnsViaTor = e?.counters?.dnsViaTor?.get() ?: 0,
                dnsDirect = e?.counters?.dnsDirect?.get() ?: 0,
                networkFrozen = e?.isFrozen ?: true,
                lockdownEnabled = lockdown,
                alwaysOn = alwaysOn,
                reconnectInSec = reconnectIn,
                message = if (networkLost) "Нет подключения к интернету. Повтор через $reconnectIn с" else it.message
            )
        }
    }

    private fun launch(flag: AtomicBoolean, job: () -> Unit) {
        if (!flag.compareAndSet(false, true)) return
        background.execute {
            try {
                job()
            } finally {
                flag.set(false)
            }
        }
    }

    private fun measurePing() {
        val t = tor ?: return
        try {
            val ms = TorHttp.measureConnect(t.socksPort, PING_HOST, 443)
            update { it.copy(pingMs = ms) }
        } catch (e: Exception) {
            log(LogLine.Level.WARN, "Пинг через Tor не удался: ${e.message}")
            update { it.copy(pingMs = -1) }
        }
    }

    private fun refreshExitInfo() {
        if (!exitJob.compareAndSet(false, true)) return
        try {
            val t = tor ?: return
            val resp = TorHttp.get(t.socksPort, "https://$PING_HOST/api/ip")
            if (resp.code != 200) throw IllegalStateException("HTTP ${resp.code}")
            val json = JSONObject(resp.text())
            val ip = json.optString("IP")
            val isTor = json.optBoolean("IsTor")
            val country = runCatching { Onionoo.searchByIp(t.socksPort, ip)?.country }.getOrNull()
                ?: currentStatus().circuit.lastOrNull()?.countryCode ?: ""
            update { it.copy(exitIp = ip, isTor = isTor, exitCountry = country) }
            log(LogLine.Level.INFO, "Выходной IP: $ip ${country.uppercase()} (IsTor=$isTor)")
        } catch (e: Exception) {
            log(LogLine.Level.WARN, "Не удалось определить выходной IP: ${e.message}")
        } finally {
            exitJob.set(false)
        }
    }

    private fun refreshCircuit() {
        val t = tor ?: return
        try {
            val hops = t.currentCircuit()
            if (hops.isEmpty()) {
                update { it.copy(circuit = emptyList()) }
                return
            }
            val picked = listOf(hops.first(), hops[1], hops.last())
            val bridges = activeBridgeLines
            val result = picked.mapIndexed { index, hop ->
                val role = when (index) {
                    0 -> HopRole.GUARD
                    1 -> HopRole.MIDDLE
                    else -> HopRole.EXIT
                }
                val bridgeLine = if (index == 0) bridges.firstOrNull { Bridges.fingerprint(it) == hop.fingerprint } else null
                val isBridge = index == 0 && bridges.isNotEmpty()
                val address = t.relayAddress(hop.fingerprint) ?: bridgeLine?.let { Bridges.address(it) }
                val country = if (isBridge) "" else relayCountry[hop.fingerprint] ?: runCatching {
                    Onionoo.lookup(t.socksPort, hop.fingerprint)?.country
                }.getOrNull()?.also { relayCountry[hop.fingerprint] = it } ?: ""
                val transport = bridgeLine?.let { Bridges.transportOf(it) }
                val latency = when {
                    role == HopRole.GUARD && address != null && transport != "snowflake" && transport != "meek_lite" ->
                        guardRtt(hop.fingerprint, address.first, address.second)
                    role == HopRole.EXIT -> currentStatus().pingMs
                    else -> -1L
                }
                RelayInfo(
                    role = role,
                    fingerprint = hop.fingerprint,
                    nickname = if (isBridge && hop.nickname.isEmpty()) "Мост" else hop.nickname,
                    ip = address?.first ?: "",
                    orPort = address?.second ?: 0,
                    countryCode = country,
                    isBridge = isBridge,
                    latencyMs = latency
                )
            }
            update { it.copy(circuit = result) }
        } catch (e: Exception) {
            log(LogLine.Level.WARN, "Не удалось прочитать цепочку: ${e.message}")
        }
    }

    /** Время TCP-рукопожатия до входного узла напрямую (провайдер и так видит это соединение). */
    private fun guardRtt(fp: String, host: String, port: Int): Long {
        val now = SystemClock.elapsedRealtime()
        guardLatency[fp]?.let { (value, at) -> if (now - at < 60_000) return value }
        val value = try {
            Socket().use { s ->
                val start = System.nanoTime()
                s.connect(InetSocketAddress(host, port), 5000)
                (System.nanoTime() - start) / 1_000_000
            }
        } catch (e: Exception) {
            -1L
        }
        guardLatency[fp] = value to now
        return value
    }

    // ---------------------------------------------------------------- остановка

    private fun shutdown(finalState: ConnState, message: String) {
        if (!stopping.compareAndSet(false, true)) return
        log(
            if (finalState == ConnState.ERROR) LogLine.Level.ERROR else LogLine.Level.INFO,
            if (message.isEmpty()) "Отключение туннеля" else "Отключение туннеля: $message"
        )
        reconnectTask?.cancel(false)
        networkCallback?.let { runCatching { connectivity.unregisterNetworkCallback(it) } }
        networkCallback = null
        engine?.stop()
        engine = null
        tunFd = null
        tor?.stop()
        tor = null
        transports?.stopAll()
        val final = VpnStatus(running = false, state = finalState, message = message, updatedAt = System.currentTimeMillis())
        synchronized(statusLock) { status = final }
        publish(final)
        flushLogs()
        mainHandler.post {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            if (finalState == ConnState.ERROR) notifySafely(ERROR_NOTIFICATION_ID, buildErrorNotification(message))
            stopSelf()
        }
    }

    // ---------------------------------------------------------------- состояние, журнал, уведомления

    private fun currentStatus(): VpnStatus = synchronized(statusLock) { status }

    private fun update(transform: (VpnStatus) -> VpnStatus) {
        if (stopping.get()) return
        val next = synchronized(statusLock) {
            status = transform(status).copy(running = true, updatedAt = System.currentTimeMillis())
            status
        }
        publish(next)
        val text = notificationText(next)
        if (text != lastNotificationText) {
            lastNotificationText = text
            notifySafely(NOTIFICATION_ID, buildNotification(text))
        }
    }

    private fun publish(s: VpnStatus) {
        runCatching { VpnStatus.save(this, s) }
        sendBroadcast(
            Intent(Protocol.BROADCAST_STATE)
                .setPackage(packageName)
                .putExtra(Protocol.EXTRA_STATE_JSON, s.toJson().toString())
        )
    }

    private fun notificationText(s: VpnStatus): String = when (s.state) {
        ConnState.CONNECTING -> "Подключение: Bootstrap ${s.bootstrap}%"
        ConnState.CONNECTED -> if (s.exitIp.isNotEmpty()) "Защищено. Выходной IP ${s.exitIp}" else "Защищено через Tor"
        ConnState.UPDATING -> "Обновление цепочки…"
        ConnState.ERROR -> s.message.ifEmpty { "Ошибка" }
        ConnState.OFF -> "Отключено"
    }

    fun log(level: LogLine.Level, message: String) {
        when (level) {
            LogLine.Level.INFO -> Log.i(TAG, message)
            LogLine.Level.WARN -> Log.w(TAG, message)
            LogLine.Level.ERROR -> Log.e(TAG, message)
        }
        synchronized(pendingLogs) { pendingLogs.add(LogLine(System.currentTimeMillis(), level, message)) }
    }

    private fun flushLogs() {
        val batch = synchronized(pendingLogs) {
            if (pendingLogs.isEmpty()) return
            val copy = ArrayList(pendingLogs)
            pendingLogs.clear()
            copy
        }
        runCatching { LogFile.append(this, batch) }
        sendBroadcast(
            Intent(Protocol.BROADCAST_LOG)
                .setPackage(packageName)
                .putStringArrayListExtra(Protocol.EXTRA_LOG_LINES, ArrayList(batch.map { it.encode() }))
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = getString(R.string.notification_channel_description) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun buildNotification(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, TorVpnService::class.java).setAction(Protocol.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_vpn)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openAppIntent())
            .addAction(0, getString(R.string.notification_action_disconnect), stop)
            .build()
    }

    private fun buildErrorNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_vpn)
            .setContentTitle("MAIN VPN отключён")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()

    private fun notifySafely(id: Int, notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        try {
            NotificationManagerCompat.from(this).notify(id, notification)
        } catch (e: SecurityException) {
            Log.w(TAG, "Уведомление не показано: ${e.message}")
        }
    }

    private fun startForegroundCompat(notification: Notification) {
        lastNotificationText = "Подключение к сети Tor…"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    companion object {
        private const val TAG = "MainVpn"
        private const val CHANNEL_ID = "vpn_status"
        private const val NOTIFICATION_ID = 1
        private const val ERROR_NOTIFICATION_ID = 2
        private const val MAX_BACKOFF_SEC = 64
        private const val PING_HOST = "check.torproject.org"
    }
}
