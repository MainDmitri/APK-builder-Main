package com.example.mainvpn.tor

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.os.IBinder
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.example.mainvpn.core.LogLine
import net.freehaven.tor.control.RawEventListener
import net.freehaven.tor.control.TorControlConnection
import org.torproject.jni.TorService
import java.io.IOException
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.ServerSocket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Управление демоном Tor (libtor из tor-android, работает внутри процесса :vpn)
 * через управляющий сокет (ControlSocket) и библиотеку jtorctl.
 */
class TorController(
    private val context: Context,
    private val log: (LogLine.Level, String) -> Unit,
    private val listener: Listener
) {
    interface Listener {
        fun onBootstrap(progress: Int, summary: String)
        fun onCircuitEstablished(established: Boolean)
        fun onBandwidth(read: Long, written: Long)
        fun onCircuitChanged()
        fun onTorStopped(reason: String)
        fun onPortsChanged(socksPort: Int, dnsPort: Int)
    }

    data class CircuitHop(val fingerprint: String, val nickname: String)

    @Volatile var socksPort: Int = -1
        private set
    @Volatile var dnsPort: Int = -1
        private set

    @Volatile private var connection: TorControlConnection? = null
    @Volatile private var torService: TorService? = null
    @Volatile private var stopping = false
    private var bound = false
    private var receiverRegistered = false
    private val serviceBound = CountDownLatch(1)
    private val torOff = CountDownLatch(1)
    private val events: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(r, "tor-events").apply { isDaemon = true }
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            torService = (binder as? TorService.LocalBinder)?.service
            serviceBound.countDown()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            torService = null
            if (!stopping) listener.onTorStopped("Служба Tor неожиданно завершилась")
        }
    }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            when (intent?.action) {
                TorService.ACTION_STATUS -> {
                    val status = intent.getStringExtra(TorService.EXTRA_STATUS)
                    if (status == TorService.STATUS_OFF) {
                        torOff.countDown()
                        if (!stopping) listener.onTorStopped("Процесс Tor завершил работу")
                    } else if (status == TorService.STATUS_STOPPING && !stopping) {
                        listener.onTorStopped("Tor остановился без команды пользователя")
                    }
                }
                TorService.ACTION_ERROR -> {
                    val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: "неизвестная ошибка"
                    log(LogLine.Level.ERROR, "Ошибка Tor: $text")
                }
            }
        }
    }

    private val rawListener = RawEventListener { keyword, data ->
        events.execute { handleEvent(keyword ?: "", data ?: "") }
    }

    /** Пишет torrc, поднимает TorService и подключается к управляющему сокету. Блокирующий вызов. */
    fun start(torrc: String) {
        TorService.getTorrc(context).writeText(torrc, Charsets.UTF_8)
        val filter = IntentFilter().apply {
            addAction(TorService.ACTION_STATUS)
            addAction(TorService.ACTION_ERROR)
        }
        ContextCompat.registerReceiver(context, statusReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        receiverRegistered = true

        bound = context.bindService(
            Intent(context, TorService::class.java),
            serviceConnection,
            Context.BIND_AUTO_CREATE
        )
        if (!bound) throw IOException("Не удалось запустить службу Tor")
        if (!serviceBound.await(30, TimeUnit.SECONDS)) throw IOException("Служба Tor не ответила")

        // TorService сам аутентифицируется на ControlSocket и читает порты; ждём окончания его инициализации.
        val deadline = SystemClock.elapsedRealtime() + 90_000
        var conn: TorControlConnection? = null
        while (conn == null) {
            if (stopping) throw IOException("Запуск отменён")
            val service = torService ?: throw IOException("Служба Tor отключилась при запуске")
            val candidate = service.torControlConnection
            if (candidate != null && service.socksPort != -1) {
                conn = candidate
            } else {
                if (SystemClock.elapsedRealtime() > deadline) {
                    throw IOException("Управляющий порт Tor не открылся за 90 секунд")
                }
                Thread.sleep(100)
            }
        }
        connection = conn
        conn.addRawEventListener(rawListener)
        conn.setEvents(listOf("CIRC", "STATUS_CLIENT", "NOTICE", "WARN", "ERR", "BW"))

        socksPort = parsePort(conn.getInfo("net/listeners/socks"))
        dnsPort = parsePort(conn.getInfo("net/listeners/dns"))
        if (socksPort <= 0) throw IOException("Tor не открыл SocksPort")
        if (dnsPort <= 0) throw IOException("Tor не открыл DNSPort")
        log(LogLine.Level.INFO, "Tor ${TorService.VERSION_NAME}: SOCKS 127.0.0.1:$socksPort, DNS 127.0.0.1:$dnsPort")

        val phase = conn.getInfo("status/bootstrap-phase") ?: ""
        parseBootstrap(phase)?.let { (p, s) -> listener.onBootstrap(p, s) }
    }

    fun stop() {
        stopping = true
        connection?.let { c -> runCatching { c.removeRawEventListener(rawListener) } }
        connection = null
        if (bound) {
            runCatching { context.unbindService(serviceConnection) }
            bound = false
            torOff.await(8, TimeUnit.SECONDS)
        }
        if (receiverRegistered) {
            runCatching { context.unregisterReceiver(statusReceiver) }
            receiverRegistered = false
        }
        events.shutdownNow()
    }

    private fun conn(): TorControlConnection =
        connection ?: throw IOException("Нет соединения с управляющим портом Tor")

    fun newIdentity() {
        conn().signal("NEWNYM")
        log(LogLine.Level.INFO, "Отправлен SIGNAL NEWNYM")
    }

    /** Закрывает все рабочие цепочки, чтобы новые потоки пошли по новым узлам. */
    fun closeCircuits(): Int {
        val c = conn()
        var closed = 0
        for (line in (c.getInfo("circuit-status") ?: "").lines()) {
            val parts = line.trim().split(' ')
            if (parts.size < 2 || parts[1] != "BUILT") continue
            val purpose = parts.firstOrNull { it.startsWith("PURPOSE=") }?.substringAfter('=') ?: "GENERAL"
            if (purpose != "GENERAL" && !purpose.startsWith("CONFLUX")) continue
            runCatching { c.closeCircuit(parts[0], false) }.onSuccess { closed++ }
        }
        return closed
    }

    fun setNetworkEnabled(enabled: Boolean) {
        conn().setConf("DisableNetwork", if (enabled) "0" else "1")
        syncPorts()
    }

    /**
     * Tor может переоткрыть SOCKS/DNS-листенеры после SETCONF/RESETCONF. Перечитываем фактические
     * порты, чтобы TCP-стек, DNS и служебные запросы не стучались на закрытый порт.
     */
    private fun syncPorts() {
        val c = connection ?: return
        val socks = parsePort(runCatching { c.getInfo("net/listeners/socks") }.getOrNull())
        val dns = parsePort(runCatching { c.getInfo("net/listeners/dns") }.getOrNull())
        if (socks <= 0 || dns <= 0) return
        if (socks == socksPort && dns == dnsPort) return
        socksPort = socks
        dnsPort = dns
        log(LogLine.Level.WARN, "Tor переоткрыл порты: SOCKS 127.0.0.1:$socks, DNS 127.0.0.1:$dns")
        listener.onPortsChanged(socks, dns)
    }

    fun isCircuitEstablished(): Boolean =
        runCatching { conn().getInfo("status/circuit-established")?.trim() == "1" }.getOrDefault(false)

    /** Применяет мосты без перезапуска Tor. [plugins] — транспорт → локальный порт. */
    fun applyBridges(lines: List<String>, plugins: Map<String, Int>) {
        val c = conn()
        if (lines.isEmpty()) {
            c.setConf("UseBridges", "0")
            c.resetConf(listOf("Bridge", "ClientTransportPlugin"))
            syncPorts()
            return
        }
        val conf = ArrayList<String>()
        conf.add("UseBridges 1")
        plugins.forEach { (transport, port) ->
            conf.add("ClientTransportPlugin $transport socks5 127.0.0.1:$port")
        }
        lines.forEach { conf.add("Bridge $it") }
        c.setConf(conf)
        syncPorts()
    }

    fun setExitNodes(fingerprints: List<String>) {
        val c = conn()
        if (fingerprints.isEmpty()) {
            c.resetConf(listOf("ExitNodes", "StrictNodes"))
        } else {
            c.setConf(listOf("ExitNodes " + fingerprints.joinToString(",") { "\$$it" }, "StrictNodes 1"))
        }
        syncPorts()
    }

    fun getInfo(key: String): String? = runCatching { conn().getInfo(key) }.getOrNull()

    /** Цепочка, по которой сейчас идёт больше всего потоков (или самая свежая собранная). */
    fun currentCircuit(): List<CircuitHop> {
        val c = conn()
        val circuits = (c.getInfo("circuit-status") ?: "").lines().mapNotNull { line ->
            val parts = line.trim().split(' ')
            if (parts.size < 3 || parts[1] != "BUILT" || !parts[2].startsWith("$")) return@mapNotNull null
            val purpose = parts.firstOrNull { it.startsWith("PURPOSE=") }?.substringAfter('=') ?: "GENERAL"
            if (purpose != "GENERAL" && !purpose.startsWith("CONFLUX")) return@mapNotNull null
            val hops = parts[2].split(',').mapNotNull { token ->
                val fp = token.removePrefix("$").take(40)
                if (fp.length != 40) return@mapNotNull null
                val nick = when {
                    '~' in token -> token.substringAfter('~')
                    '=' in token -> token.substringAfter('=')
                    else -> ""
                }
                CircuitHop(fp, nick)
            }
            if (hops.size < 3) null else parts[0] to hops
        }
        if (circuits.isEmpty()) return emptyList()
        val usage = HashMap<String, Int>()
        (c.getInfo("stream-status") ?: "").lines().forEach { line ->
            val parts = line.trim().split(' ')
            if (parts.size >= 3) usage[parts[2]] = (usage[parts[2]] ?: 0) + 1
        }
        val best = circuits.maxWith(
            compareBy<Pair<String, List<CircuitHop>>> { usage[it.first] ?: 0 }
                .thenBy { it.first.toLongOrNull() ?: 0L }
        )
        return best.second
    }

    /** Адрес реле из консенсуса: (IP, ORPort) или null (например, для моста). */
    fun relayAddress(fingerprint: String): Pair<String, Int>? {
        val ns = runCatching { conn().getInfo("ns/id/$fingerprint") }.getOrNull() ?: return null
        val r = ns.lines().firstOrNull { it.startsWith("r ") } ?: return null
        val parts = r.split(' ')
        if (parts.size < 8) return null
        val port = parts[7].toIntOrNull() ?: return null
        return parts[6] to port
    }

    private fun handleEvent(keyword: String, data: String) {
        when (keyword) {
            "STATUS_CLIENT" -> {
                val action = data.split(' ').getOrNull(1) ?: return
                when (action) {
                    "BOOTSTRAP" -> parseBootstrap(data)?.let { (p, s) -> listener.onBootstrap(p, s) }
                    "CIRCUIT_ESTABLISHED" -> listener.onCircuitEstablished(true)
                    "CIRCUIT_NOT_ESTABLISHED" -> {
                        log(LogLine.Level.WARN, "Цепочка не установлена: $data")
                        listener.onCircuitEstablished(false)
                    }
                    else -> if (data.startsWith("WARN") || data.startsWith("ERR")) {
                        log(LogLine.Level.WARN, data)
                    }
                }
            }
            "BW" -> {
                val parts = data.trim().split(' ')
                val read = parts.getOrNull(0)?.toLongOrNull() ?: return
                val written = parts.getOrNull(1)?.toLongOrNull() ?: return
                listener.onBandwidth(read, written)
            }
            "CIRC" -> listener.onCircuitChanged()
            "NOTICE" -> log(LogLine.Level.INFO, data)
            "WARN" -> log(LogLine.Level.WARN, data)
            "ERR" -> log(LogLine.Level.ERROR, data)
        }
    }

    companion object {
        /** Свободный TCP-порт на 127.0.0.1 для фиксированного SocksPort. */
        fun freeTcpPort(): Int =
            ServerSocket(0, 1, InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1))).use { it.localPort }

        /** Свободный UDP-порт на 127.0.0.1 для фиксированного DNSPort. */
        fun freeUdpPort(): Int =
            DatagramSocket(0, InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1))).use { it.localPort }

        fun parsePort(value: String?): Int {
            val first = value?.trim()?.split(' ')?.firstOrNull()?.trim('"') ?: return -1
            return first.substringAfterLast(':').toIntOrNull() ?: -1
        }

        private val progressRe = Regex("PROGRESS=(\\d+)")
        private val summaryRe = Regex("SUMMARY=\"([^\"]*)\"")

        fun parseBootstrap(data: String): Pair<Int, String>? {
            val p = progressRe.find(data)?.groupValues?.get(1)?.toIntOrNull() ?: return null
            val s = summaryRe.find(data)?.groupValues?.get(1) ?: ""
            return p to s
        }
    }
}
