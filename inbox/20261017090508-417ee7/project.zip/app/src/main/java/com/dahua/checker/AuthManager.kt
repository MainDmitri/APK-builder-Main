package com.dahua.checker

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

data class UserInfo(
    val nickname: String,
    val code: String,
    val activatedAt: Long
)

object AuthManager {

    // ═══════════════════════════════════════════════════════
    // ВСТАВЬ СЮДА URL СВОЕГО Google Apps Script
    // ═══════════════════════════════════════════════════════
    private const val API_URL = "YOUR_SCRIPT_URL_HERE"
    // ═══════════════════════════════════════════════════════

    private const val ADMIN_KEY = "MainC4yt552_admin_api_key"

    private const val PREFS_NAME = "ms_auth_x7k"
    private const val KEY_ACTIVATED = "ax_st"
    private const val KEY_NICKNAME = "ax_nk"

    private val adminPasswordHash: String by lazy {
        sha256hex("MainC4yt552" + "slt_x9k")
    }

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    // ─── Локальное состояние ───

    fun isActivated(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_ACTIVATED, false)
    }

    fun getActiveNickname(context: Context): String {
        return getPrefs(context).getString(KEY_NICKNAME, "") ?: ""
    }

    private fun saveActivation(context: Context, nickname: String) {
        getPrefs(context).edit()
            .putBoolean(KEY_ACTIVATED, true)
            .putString(KEY_NICKNAME, nickname)
            .apply()
    }

    fun deactivate(context: Context) {
        getPrefs(context).edit()
            .remove(KEY_ACTIVATED)
            .remove(KEY_NICKNAME)
            .apply()
    }

    fun verifyAdminPassword(password: String): Boolean {
        return sha256hex(password + "slt_x9k") == adminPasswordHash
    }

    // ─── Серверные операции ───

    suspend fun activate(context: Context, nickname: String, code: String): Result<Boolean> {
        return withContext(Dispatchers.IO) {
            try {
                val json = JSONObject().apply {
                    put("action", "validate")
                    put("nickname", nickname.trim())
                    put("code", code.trim().uppercase())
                }
                val response = httpPost(json)
                val success = response.optBoolean("success", false)
                if (success) {
                    saveActivation(context, nickname.trim())
                }
                Result.success(success)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun generateCode(nickname: String): Result<String> {
        return withContext(Dispatchers.IO) {
            try {
                val json = JSONObject().apply {
                    put("action", "generate")
                    put("nickname", nickname.trim())
                    put("adminKey", ADMIN_KEY)
                }
                val response = httpPost(json)
                if (response.optBoolean("success", false)) {
                    Result.success(response.getString("code"))
                } else {
                    Result.failure(Exception(response.optString("error", "Ошибка генерации")))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun getUsers(): Result<List<UserInfo>> {
        return withContext(Dispatchers.IO) {
            try {
                val json = JSONObject().apply {
                    put("action", "list")
                    put("adminKey", ADMIN_KEY)
                }
                val response = httpPost(json)
                if (response.optBoolean("success", false)) {
                    val arr = response.getJSONArray("users")
                    val list = mutableListOf<UserInfo>()
                    for (i in 0 until arr.length()) {
                        val u = arr.getJSONObject(i)
                        list.add(UserInfo(
                            nickname = u.getString("nickname"),
                            code = u.getString("code"),
                            activatedAt = u.optLong("createdAt", 0L)
                        ))
                    }
                    Result.success(list)
                } else {
                    Result.failure(Exception(response.optString("error", "Ошибка")))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun deleteUser(nickname: String): Result<Boolean> {
        return withContext(Dispatchers.IO) {
            try {
                val json = JSONObject().apply {
                    put("action", "delete")
                    put("nickname", nickname.trim())
                    put("adminKey", ADMIN_KEY)
                }
                val response = httpPost(json)
                Result.success(response.optBoolean("success", false))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    // ─── HTTP ───

    private fun httpPost(json: JSONObject): JSONObject {
        var currentUrl = API_URL
        var redirects = 0
        while (redirects < 5) {
            val url = URL(currentUrl)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.doOutput = true
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.instanceFollowRedirects = false

            val writer = OutputStreamWriter(conn.outputStream, Charsets.UTF_8)
            writer.write(json.toString())
            writer.flush()
            writer.close()

            val code = conn.responseCode

            if (code == 302 || code == 301 || code == 307) {
                val location = conn.getHeaderField("Location")
                conn.disconnect()
                if (location != null) {
                    currentUrl = location
                    redirects++
                    continue
                }
            }

            val body = if (code in 200..299) {
                conn.inputStream.bufferedReader().readText()
            } else {
                conn.errorStream?.bufferedReader()?.readText()
                    ?: "{\"success\":false,\"error\":\"HTTP $code\"}"
            }
            conn.disconnect()
            return JSONObject(body)
        }
        return JSONObject("{\"success\":false,\"error\":\"Too many redirects\"}")
    }

    private fun sha256hex(text: String): String {
        return MessageDigest.getInstance("SHA-256")
            .digest(text.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }
}
