// Строительство фигурами в одиночной игре (по образцу аддона Effortless Building v5.0 — ExterLeo, порт мода Requioss).
// Режимы: в воздухе, линия, диагональ, стена, диагональная стена, пол, наклонный пол, куб, круг, цилиндр, сфера,
// полукруг/арка/купол, конус, копирование. Модификаторы: отражение, массив, радиальное отражение. Отмена и повтор.
// Ставить: нажатие «использовать» задаёт начало, следующее — конец (у объёмных фигур второе нажатие задаёт основание,
// третье — высоту). Ломать фигурой — так же, кнопкой «ломать». Другая кнопка отменяет начатую фигуру.
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  const MODES = [
    { id: 'off', name: 'Выключено', steps: 0 },
    { id: 'air', name: 'В воздухе', steps: 1 },
    { id: 'line', name: 'Линия', steps: 2 },
    { id: 'dline', name: 'Диагональ', steps: 2 },
    { id: 'wall', name: 'Стена', steps: 2, opts: ['fill2'] },
    { id: 'dwall', name: 'Диаг. стена', steps: 3, opts: ['fill2'] },
    { id: 'floor', name: 'Пол', steps: 2, opts: ['fill2'] },
    { id: 'slope', name: 'Наклонный пол', steps: 3, opts: ['fill2'] },
    { id: 'cube', name: 'Куб', steps: 3, opts: ['fill3'] },
    { id: 'box', name: 'Коробка', steps: 3, opts: ['box'] },
    { id: 'pyramid', name: 'Пирамида', steps: 2, opts: ['fill2'] },
    { id: 'stairs', name: 'Ступени', steps: 2, opts: ['stairs'] },
    { id: 'circle', name: 'Круг', steps: 2, opts: ['fill2', 'shape'] },
    { id: 'cylinder', name: 'Цилиндр', steps: 3, opts: ['fill2', 'shape'] },
    { id: 'sphere', name: 'Сфера', steps: 2, opts: ['fill2'] },
    { id: 'semi', name: 'Полукруг', steps: 2, opts: ['orient', 'fill2'] },
    { id: 'cone', name: 'Конус', steps: 3, opts: ['fill2'] },
    { id: 'copy', name: 'Копировать', steps: 2 }
  ];
  const OPTS = {
    fill2: { key: 'fill', label: 'Заполнение', values: [['filled', 'сплошное'], ['hollow', 'полое']] },
    fill3: { key: 'fill', label: 'Заполнение', values: [['filled', 'сплошное'], ['hollow', 'полое'], ['skeleton', 'каркас']] },
    shape: { key: 'shape', label: 'Форма', values: [['even', 'ровная'], ['uneven', 'овальная']] },
    orient: { key: 'orient', label: 'Вид', values: [['horizontal', 'полукруг'], ['arch', 'арка'], ['dome', 'купол']] },
    box: { key: 'box', label: 'Вид', values: [['open', 'без крыши'], ['closed', 'с крышей'], ['walls', 'только стены']] },
    stairs: { key: 'stairs', label: 'Ступени', values: [['thin', 'тонкие'], ['solid', 'сплошные']] }
  };
  const SUBST = [['off', 'не заменять'], ['similar', 'похожими'], ['any', 'любыми']];
  const BY_ID = {};
  for (const m of MODES) BY_ID[m.id] = m;

  const NO_SHAPE = new Set([26, 64, 71, 193, 194, 195, 196, 197]);
  const STAIRS = new Set([53, 67, 108, 109, 114, 128, 134, 135, 136, 156, 163, 164, 180, 203]);
  const HISTORY = 50;
  const OPS_PER_FRAME = 3000;
  const FACE_DIR = [[0, -1, 0], [0, 1, 0], [0, 0, -1], [0, 0, 1], [-1, 0, 0], [1, 0, 0]];

  function defaults() {
    return {
      mode: 'off', opts: {}, replace: false, max: 10000, netRate: 8, subst: 'similar', printRange: 0, schemSubst: false,
      mirror: { on: false, x: true, y: false, z: false, cx: 0, cy: 64, cz: 0, half: false },
      array: { on: false, ox: 1, oy: 0, oz: 0, count: 3 },
      radial: { on: false, cx: 0, cz: 0, slices: 4, alt: false }
    };
  }

  function normalize(s) {
    const d = defaults();
    if (!s || typeof s !== 'object') return d;
    const out = Object.assign(d, s);
    out.mirror = Object.assign(defaults().mirror, s.mirror || {});
    out.array = Object.assign(defaults().array, s.array || {});
    out.radial = Object.assign(defaults().radial, s.radial || {});
    out.opts = Object.assign({}, s.opts || {});
    if (!BY_ID[out.mode]) out.mode = 'off';
    return out;
  }

  // ---------- Геометрия ----------
  function range(a, b) {
    const out = [];
    const s = a <= b ? 1 : -1;
    for (let v = a; s > 0 ? v <= b : v >= b; v += s) out.push(v);
    return out;
  }

  class PosList {
    constructor(cap) { this.cap = cap; this.list = []; this.seen = new Set(); this.full = false; }
    add(x, y, z, d) {
      if (this.full) return;
      const k = x + ',' + y + ',' + z;
      if (this.seen.has(k)) return;
      this.seen.add(k);
      this.list.push({ x, y, z, d });
      if (this.list.length >= this.cap) this.full = true;
    }
  }

  // Оставляет блоки, у которых есть пустой сосед по заданным осям (полые фигуры)
  function hollow(list, axes) {
    const set = new Set(list.map((p) => p.x + ',' + p.y + ',' + p.z));
    const dirs = [];
    if (axes.indexOf('x') >= 0) dirs.push([1, 0, 0], [-1, 0, 0]);
    if (axes.indexOf('y') >= 0) dirs.push([0, 1, 0], [0, -1, 0]);
    if (axes.indexOf('z') >= 0) dirs.push([0, 0, 1], [0, 0, -1]);
    return list.filter((p) => dirs.some((d) => !set.has((p.x + d[0]) + ',' + (p.y + d[1]) + ',' + (p.z + d[2]))));
  }

  function axesOf(list) {
    if (!list.length) return [];
    let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity, z0 = Infinity, z1 = -Infinity;
    for (const p of list) {
      if (p.x < x0) x0 = p.x; if (p.x > x1) x1 = p.x;
      if (p.y < y0) y0 = p.y; if (p.y > y1) y1 = p.y;
      if (p.z < z0) z0 = p.z; if (p.z > z1) z1 = p.z;
    }
    const a = [];
    if (x1 > x0) a.push('x');
    if (y1 > y0) a.push('y');
    if (z1 > z0) a.push('z');
    return a;
  }

  function lineBetween(out, a, b) {
    const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
    const n = Math.max(Math.abs(dx), Math.abs(dy), Math.abs(dz));
    if (n === 0) { out.add(a.x, a.y, a.z); return; }
    for (let i = 0; i <= n && !out.full; i++) {
      const t = i / n;
      out.add(Math.round(a.x + dx * t), Math.round(a.y + dy * t), Math.round(a.z + dz * t));
    }
  }

  function axisLine(out, a, t) {
    const ax = Math.abs(t.x - a.x), ay = Math.abs(t.y - a.y), az = Math.abs(t.z - a.z);
    if (ax >= ay && ax >= az) for (const x of range(a.x, t.x)) out.add(x, a.y, a.z);
    else if (ay >= az) for (const y of range(a.y, t.y)) out.add(a.x, y, a.z);
    else for (const z of range(a.z, t.z)) out.add(a.x, a.y, z);
  }

  function box(out, a, b, fill) {
    const x0 = Math.min(a.x, b.x), x1 = Math.max(a.x, b.x);
    const y0 = Math.min(a.y, b.y), y1 = Math.max(a.y, b.y);
    const z0 = Math.min(a.z, b.z), z1 = Math.max(a.z, b.z);
    for (let x = x0; x <= x1; x++) {
      for (let y = y0; y <= y1; y++) {
        for (let z = z0; z <= z1; z++) {
          const ex = x === x0 || x === x1, ey = y === y0 || y === y1, ez = z === z0 || z === z1;
          if (fill === 'hollow' && !(ex || ey || ez)) continue;
          if (fill === 'skeleton' && (ex + ey + ez) < 2) continue;
          out.add(x, y, z);
          if (out.full) return;
        }
      }
    }
  }

  // Коробка: пол и стены (по желанию и крыша); «только стены» — без пола и крыши
  function boxShape(out, a, b, kind) {
    const x0 = Math.min(a.x, b.x), x1 = Math.max(a.x, b.x);
    const y0 = Math.min(a.y, b.y), y1 = Math.max(a.y, b.y);
    const z0 = Math.min(a.z, b.z), z1 = Math.max(a.z, b.z);
    for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) {
      const side = x === x0 || x === x1 || z === z0 || z === z1;
      const floor = y === y0 && kind !== 'walls';
      const roof = y === y1 && kind === 'closed';
      if (!side && !floor && !roof) continue;
      out.add(x, y, z);
      if (out.full) return;
    }
  }

  // Пирамида: квадратные слои, каждый следующий на 1 блок уже с каждой стороны
  function pyramid(out, a, t, hollowOn) {
    let x0 = Math.min(a.x, t.x), x1 = Math.max(a.x, t.x), z0 = Math.min(a.z, t.z), z1 = Math.max(a.z, t.z);
    for (let y = a.y; x0 <= x1 && z0 <= z1 && y <= 255 && !out.full; y++, x0++, x1--, z0++, z1--) {
      const top = x0 + 1 > x1 - 1 || z0 + 1 > z1 - 1;
      for (let x = x0; x <= x1; x++) for (let z = z0; z <= z1; z++) {
        if (hollowOn && !top && y !== a.y && x !== x0 && x !== x1 && z !== z0 && z !== z1) continue;
        out.add(x, y, z);
      }
    }
  }

  // Ступени: по главной горизонтальной оси, каждая ступень на блок выше (или ниже); «сплошные» — с заполнением снизу
  function stairsShape(out, a, t, solid) {
    const dx = t.x - a.x, dz = t.z - a.z, alongX = Math.abs(dx) >= Math.abs(dz);
    const n = Math.abs(alongX ? dx : dz), sg = (alongX ? dx : dz) < 0 ? -1 : 1;
    // Конец ниже начала — ступени вниз, иначе вверх; каждая ступень на блок
    const up = t.y < a.y ? -1 : 1;
    const base = up > 0 ? a.y : a.y - n;
    for (let i = 0; i <= n && !out.full; i++) {
      const x = alongX ? a.x + i * sg : a.x, z = alongX ? a.z : a.z + i * sg, y = a.y + i * up;
      if (y < 0 || y > 255) break;
      out.add(x, y, z);
      if (solid) for (let yy = Math.max(0, base); yy < y; yy++) out.add(x, yy, z);
    }
  }

  function rect(out, a, t, hollowOn) {
    for (const x of range(a.x, t.x)) {
      for (const z of range(a.z, t.z)) {
        if (hollowOn && x !== a.x && x !== t.x && z !== a.z && z !== t.z) continue;
        out.add(x, a.y, z);
        if (out.full) return;
      }
    }
  }

  function wall(out, a, t, hollowOn) {
    const alongX = Math.abs(t.x - a.x) >= Math.abs(t.z - a.z);
    const end = alongX ? t.x : t.z;
    const start = alongX ? a.x : a.z;
    for (const h of range(start, end)) {
      for (const y of range(a.y, t.y)) {
        if (hollowOn && h !== start && h !== end && y !== a.y && y !== t.y) continue;
        if (alongX) out.add(h, y, a.z); else out.add(a.x, y, h);
        if (out.full) return;
      }
    }
  }

  function diagWall(out, a, s, topY, hollowOn) {
    const base = new PosList(100000);
    lineBetween(base, { x: a.x, y: 0, z: a.z }, { x: s.x, y: 0, z: s.z });
    const ys = range(a.y, topY);
    const n = base.list.length;
    base.list.forEach((p, i) => {
      for (const y of ys) {
        if (hollowOn && i !== 0 && i !== n - 1 && y !== a.y && y !== topY) continue;
        out.add(p.x, y, p.z);
      }
    });
  }

  // Наклонный пол: прямоугольник a..s, высота растёт от a.y до topY в сторону взгляда
  function slope(out, a, s, topY, yaw, hollowOn) {
    const x0 = Math.min(a.x, s.x), x1 = Math.max(a.x, s.x), z0 = Math.min(a.z, s.z), z1 = Math.max(a.z, s.z);
    const lx = (x1 - x0) || 1, lz = (z1 - z0) || 1;
    const dir = yawDir4(yaw);
    for (let x = x0; x <= x1; x++) {
      for (let z = z0; z <= z1; z++) {
        if (hollowOn && x !== x0 && x !== x1 && z !== z0 && z !== z1) continue;
        let t;
        if (dir === 'south') t = (z - z0) / lz;
        else if (dir === 'north') t = (z1 - z) / lz;
        else if (dir === 'west') t = (x1 - x) / lx;
        else t = (x - x0) / lx;
        out.add(x, Math.round(a.y + (topY - a.y) * t), z);
        if (out.full) return;
      }
    }
  }

  function disk(out, cx, cy, cz, rx, rz, keep) {
    const ex = rx + 0.5, ez = rz + 0.5;
    const ix = Math.ceil(rx), iz = Math.ceil(rz);
    for (let dx = -ix; dx <= ix; dx++) {
      for (let dz = -iz; dz <= iz; dz++) {
        if ((dx * dx) / (ex * ex) + (dz * dz) / (ez * ez) > 1) continue;
        if (keep && !keep(dx, dz)) continue;
        out.add(cx + dx, cy, cz + dz);
        if (out.full) return;
      }
    }
  }

  function radii(a, t, shape) {
    const dx = t.x - a.x, dz = t.z - a.z;
    if (shape === 'uneven') return [Math.abs(dx), Math.abs(dz)];
    const r = Math.sqrt(dx * dx + dz * dz);
    return [r, r];
  }

  function sphere(out, a, r, dome) {
    const e = r + 0.5, i = Math.ceil(r);
    for (let dx = -i; dx <= i; dx++) {
      for (let dy = dome ? 0 : -i; dy <= i; dy++) {
        for (let dz = -i; dz <= i; dz++) {
          if (dx * dx + dy * dy + dz * dz > e * e) continue;
          out.add(a.x + dx, a.y + dy, a.z + dz);
          if (out.full) return;
        }
      }
    }
  }

  function yawDir4(yaw) {
    const n = ((yaw % 360) + 360) % 360;
    if (n < 45 || n >= 315) return 'south';
    if (n < 135) return 'west';
    if (n < 225) return 'north';
    return 'east';
  }
  const facingNS = (yaw) => { const d = yawDir4(yaw); return d === 'south' || d === 'north'; };

  function cone(out, a, s, topY, hollowOn) {
    const r = Math.sqrt((s.x - a.x) ** 2 + (s.z - a.z) ** 2);
    const h = topY - a.y, n = Math.abs(h), sg = h < 0 ? -1 : 1;
    for (let k = 0; k <= n && !out.full; k++) {
      const rk = n === 0 ? r : r * (1 - k / (n + 1));
      const layer = new PosList(1000000);
      disk(layer, a.x, a.y + k * sg, a.z, rk, rk);
      const list = hollowOn && k > 0 ? hollow(layer.list, ['x', 'z']) : layer.list;
      for (const p of list) out.add(p.x, p.y, p.z);
    }
  }

  // ---------- Луч взгляда ----------
  function rayPlane(head, dir, axis, value) {
    const i = axis === 'x' ? 0 : axis === 'y' ? 1 : 2;
    if (Math.abs(dir[i]) < 1e-4) return null;
    let t = (value - head[i]) / dir[i];
    if (t <= 0) return null;
    t = Math.min(t, 64);
    return [head[0] + dir[0] * t, head[1] + dir[1] * t, head[2] + dir[2] * t];
  }
  const flo = (p) => p && { x: Math.floor(p[0]), y: Math.floor(p[1]), z: Math.floor(p[2]) };

  // ---------- Замена блоков ----------
  // Похожие блоки: если нужного нет, ставим из той же группы (доски любого дерева, любой камень, любая шерсть...)
  const GROUPS = [
    [5], [17, 162], [1, 4, 48, 98, 24, 179, 45, 112, 155, 201, 168, 121, 206, 87, 215], [35], [159, 172], [20, 95, 102, 160],
    [236], [2, 3, 60, 110, 243], [44, 158, 182], [53, 67, 108, 109, 114, 128, 134, 135, 136, 156, 163, 164, 180, 203],
    [85, 113], [18, 161], [139], [12], [13], [80, 78], [79, 174], [41, 42, 57, 133, 22, 152, 173], [82, 337]
  ];
  const GROUP_OF = {};
  GROUPS.forEach((g, i) => { for (const id of g) GROUP_OF[id] = i; });
  const UNSTABLE = new Set([12, 13, 46, 237, 252]);
  const TILE = new Set([23, 25, 26, 54, 58, 61, 62, 116, 117, 118, 125, 130, 138, 145, 146, 154, 205, 218]);
  const isStairs = (id) => STAIRS.has(id);

  // Подходит ли блок для «строить из того, что есть»: обычный полный блок без интерфейса и без падения
  function plainBlock(id) {
    const b = MC.Blocks.list[id];
    return !!b && id > 0 && id < 256 && b.shape === 'cube' && b.solid && !b.liquid && !TILE.has(id) && !UNSTABLE.has(id) && !NO_SHAPE.has(id);
  }

  // Данные замены: ориентация ступеней и брёвен сохраняется, вид берётся у найденного блока
  function substData(nid, ndata, sid, sdata) {
    if (isStairs(nid) && isStairs(sid)) return ndata;
    if ((nid === 17 || nid === 162) && (sid === 17 || sid === 162)) return (sdata & 3) | (ndata & 12);
    if ((nid === 44 || nid === 158 || nid === 182) && (sid === 44 || sid === 158 || sid === 182)) return (sdata & 7) | (ndata & 8);
    return sdata;
  }

  // ---------- Модуль ----------
  class Building {
    constructor(game) {
      this.game = game;
      this.cfg = normalize(game.app.settings.eb);
      this.pending = null;
      this.target = null;
      this.preview = null;
      this.queue = [];
      // На сервере блоки ставятся настоящими пакетами по одному, только в радиусе досягаемости
      this.net = [];
      this.netKeys = new Map();
      this.netLast = 0;
      this.netBudget = 0;
      this.netInfo = '';
      this.undoStack = [];
      this.redoStack = [];
      this.clip = null;
      this.clipRot = 0;
      this.version = 0;
      this.prevAttack = false;
      this.hint = '';
    }

    get mode() { return BY_ID[this.cfg.mode]; }
    active() { return this.cfg.mode !== 'off'; }
    opt(key, def) { const o = this.cfg.opts[this.cfg.mode]; return (o && o[key]) || def; }

    save() {
      this.game.app.settings.eb = this.cfg;
      MC.Storage.saveSettings(this.game.app.settings);
    }

    setMode(id) {
      this.cfg.mode = id;
      this.cancel();
      this.save();
    }

    cycleOpt(optName) {
      const o = OPTS[optName];
      const m = this.cfg.mode;
      this.cfg.opts[m] = this.cfg.opts[m] || {};
      const cur = this.cfg.opts[m][o.key] || o.values[0][0];
      const i = o.values.findIndex((v) => v[0] === cur);
      this.cfg.opts[m][o.key] = o.values[(i + 1) % o.values.length][0];
      this.save();
      this.version++;
    }

    optLabel(optName) {
      const o = OPTS[optName];
      const cur = this.opt(o.key, o.values[0][0]);
      const v = o.values.find((x) => x[0] === cur) || o.values[0];
      return o.label + ': ' + v[1];
    }

    cancel() {
      this.pending = null;
      this.preview = null;
      this.target = null;
      this.version++;
    }

    survival() { return this.game.gamemode === 0; }

    // Запас блоков в инвентаре: «id:data» → количество (в одиночной — инвентарь выживания, на сервере — инвентарь от сервера)
    stock() {
      const g = this.game, m = new Map();
      const slots = g.mode === 'sp' ? g.sinv.slots : g.inv || [];
      for (const it of slots) {
        if (!it || !it.id) continue;
        const k = it.id >= 256 ? it.id + ':' + it.data : itemOf(it.id, it.data).id + ':' + itemOf(it.id, it.data).data;
        m.set(k, (m.get(k) || 0) + (it.count || 1));
      }
      return m;
    }

    // Чем заменить недостающий блок: сначала тот же блок другого вида, потом похожий, в режиме «любыми» — самый многочисленный обычный блок
    findSubstitute(nid, ndata, stock) {
      const mode = this.cfg.subst || 'off';
      if (mode === 'off') return null;
      const gi = GROUP_OF[nid];
      let best = null, bestScore = -1;
      for (const [k, n] of stock) {
        if (n <= 0) continue;
        const [id, data] = k.split(':').map(Number);
        let score = -1;
        if (id === nid) score = 3000000 + n;
        else if (gi !== undefined && GROUP_OF[id] === gi) score = 2000000 + n;
        else if (mode === 'any' && !isStairs(nid) && plainBlock(id)) score = 1000000 + n;
        else if (mode === 'any' && isStairs(nid) && plainBlock(id)) score = 500000 + n;
        if (score > bestScore) { bestScore = score; best = { id, data, key: k }; }
      }
      if (!best) return null;
      return { id: best.id, data: substData(nid, ndata, best.id, best.data), key: best.key };
    }

    substLabel() { const v = SUBST.find((x) => x[0] === (this.cfg.subst || 'off')) || SUBST[0]; return 'Нет нужных блоков: ' + v[1]; }
    cycleSubst() { const i = SUBST.findIndex((x) => x[0] === (this.cfg.subst || 'off')); this.cfg.subst = SUBST[(i + 1) % SUBST.length][0]; this.changed(); }
    maxBlocks() { return Math.max(1, Math.min(50000, this.cfg.max | 0)); }

    head() {
      const p = this.game.player;
      return [p.x, p.eyeY, p.z];
    }

    placePos(hit) {
      if (MC.Blocks.list[hit.id].replaceable) return { x: hit.x, y: hit.y, z: hit.z };
      const d = FACE_DIR[hit.face];
      return { x: hit.x + d[0], y: hit.y + d[1], z: hit.z + d[2] };
    }

    // Блок перед игроком на расстоянии досягаемости (режим «в воздухе»)
    airPos() {
      const h = this.head(), d = this.game.player.lookDir();
      const dist = this.game.gamemode === 1 ? 4.5 : 3.5;
      return flo([h[0] + d[0] * dist, h[1] + d[1] * dist, h[2] + d[2] * dist]);
    }

    buildable(item) {
      if (!item || !item.id || item.id >= 256 || NO_SHAPE.has(item.id)) return false;
      const b = MC.Blocks.list[item.id];
      return !!b && b.shape !== 'none' && !b.liquid;
    }

    // ---------- Цель по взгляду ----------
    floorTarget(a) {
      return flo(rayPlane(this.head(), this.game.player.lookDir(), 'y', a.y + 0.5));
    }

    wallTarget(a) {
      const yaw = this.game.player.yaw;
      return flo(facingNS(yaw) ? rayPlane(this.head(), this.game.player.lookDir(), 'z', a.z + 0.5) : rayPlane(this.head(), this.game.player.lookDir(), 'x', a.x + 0.5));
    }

    // Линия: из трёх плоскостей через начало берём ту, где точка на оси ближе всего к лучу взгляда
    lineTarget(a) {
      const h = this.head(), d = this.game.player.lookDir();
      let best = null, bestD = Infinity;
      for (const axis of ['x', 'y', 'z']) {
        const p = rayPlane(h, d, axis, (axis === 'x' ? a.x : axis === 'y' ? a.y : a.z) + 0.5);
        if (!p) continue;
        const q = flo(p);
        const ax = Math.abs(q.x - a.x), ay = Math.abs(q.y - a.y), az = Math.abs(q.z - a.z);
        const c = ax >= ay && ax >= az ? { x: q.x, y: a.y, z: a.z } : ay >= az ? { x: a.x, y: q.y, z: a.z } : { x: a.x, y: a.y, z: q.z };
        const v = [c.x + 0.5 - h[0], c.y + 0.5 - h[1], c.z + 0.5 - h[2]];
        const t = v[0] * d[0] + v[1] * d[1] + v[2] * d[2];
        if (t <= 0) continue;
        const dist = Math.hypot(v[0] - d[0] * t, v[1] - d[1] * t, v[2] - d[2] * t);
        if (dist < bestD) { bestD = dist; best = c; }
      }
      return best;
    }

    // Высота: ближайшая к лучу взгляда точка вертикальной линии над основанием
    heightTarget(s) {
      const h = this.head(), d = this.game.player.lookDir();
      const w = [s.x + 0.5 - h[0], s.y + 0.5 - h[1], s.z + 0.5 - h[2]];
      const b = d[1];
      const den = 1 - b * b;
      if (den < 1e-4) return null;
      const e = d[0] * w[0] + d[1] * w[1] + d[2] * w[2];
      const sParam = (b * e - w[1]) / den;
      const y = Math.round(s.y + Math.max(-64, Math.min(64, sParam)));
      return { x: s.x, y: Math.max(0, Math.min(255, y)), z: s.z };
    }

    freeTarget(a, hit) {
      if (hit) return this.pending.action === 'break' ? { x: hit.x, y: hit.y, z: hit.z } : this.placePos(hit);
      const h = this.head(), d = this.game.player.lookDir();
      const dist = Math.min(64, Math.hypot(a.x + 0.5 - h[0], a.y + 0.5 - h[1], a.z + 0.5 - h[2]));
      return flo([h[0] + d[0] * dist, h[1] + d[1] * dist, h[2] + d[2] * dist]);
    }

    // Взгляд не пересекает плоскость фигуры (например, в небо): точка на луче на расстоянии до начала,
    // прижатая к плоскости режима
    fallbackTarget() {
      const pd = this.pending, a = pd.anchor;
      const h = this.head(), d = this.game.player.lookDir();
      const dist = Math.max(2, Math.min(64, Math.hypot(a.x + 0.5 - h[0], a.y + 0.5 - h[1], a.z + 0.5 - h[2])));
      const q = flo([h[0] + d[0] * dist, h[1] + d[1] * dist, h[2] + d[2] * dist]);
      if (pd.second) return { x: pd.second.x, y: Math.max(0, Math.min(255, q.y)), z: pd.second.z };
      const m = this.cfg.mode;
      if (m === 'wall' || m === 'sphere' || (m === 'semi' && this.opt('orient', 'horizontal') !== 'horizontal')) {
        if (facingNS(this.game.player.yaw)) q.z = a.z; else q.x = a.x;
        return q;
      }
      if (m === 'line' || m === 'dline' || m === 'copy' || m === 'stairs') return q;
      q.y = a.y;
      return q;
    }

    computeTarget(hit) {
      const pd = this.pending;
      const a = pd.anchor, m = this.cfg.mode;
      if (pd.second) return this.heightTarget(pd.second);
      switch (m) {
        case 'line': return this.lineTarget(a);
        case 'dline': case 'stairs': return this.freeTarget(a, hit);
        case 'wall': case 'sphere': return this.wallTarget(a);
        case 'semi': return this.opt('orient', 'horizontal') === 'horizontal' ? this.floorTarget(a) : this.wallTarget(a);
        case 'copy': return hit ? { x: hit.x, y: hit.y, z: hit.z } : this.freeTarget(a, null);
        default: return this.floorTarget(a);
      }
    }

    // ---------- Фигура ----------
    shape(a, t, s) {
      const out = new PosList(this.maxBlocks());
      const m = this.cfg.mode, yaw = this.game.player.yaw;
      const fill = this.opt('fill', 'filled'), hol = fill === 'hollow';
      switch (m) {
        case 'air': out.add(a.x, a.y, a.z); break;
        case 'line': axisLine(out, a, t); break;
        case 'dline': lineBetween(out, a, t); break;
        case 'wall': wall(out, a, t, hol); break;
        case 'floor': rect(out, a, { x: t.x, y: a.y, z: t.z }, hol); break;
        case 'dwall': if (s) diagWall(out, a, s, t.y, hol); else lineBetween(out, a, { x: t.x, y: a.y, z: t.z }); break;
        case 'slope': if (s) slope(out, a, s, t.y, yaw, hol); else rect(out, a, { x: t.x, y: a.y, z: t.z }, false); break;
        case 'cube': if (s) box(out, a, { x: s.x, y: t.y, z: s.z }, fill); else rect(out, a, { x: t.x, y: a.y, z: t.z }, false); break;
        case 'box': if (s) boxShape(out, a, { x: s.x, y: t.y, z: s.z }, this.opt('box', 'open')); else rect(out, a, { x: t.x, y: a.y, z: t.z }, true); break;
        case 'pyramid': pyramid(out, a, t, hol); break;
        case 'stairs': stairsShape(out, a, t, this.opt('stairs', 'thin') === 'solid'); break;
        case 'circle': {
          const [rx, rz] = radii(a, t, this.opt('shape', 'even'));
          if (hol) { const l = new PosList(this.maxBlocks()); disk(l, a.x, a.y, a.z, rx, rz); for (const p of hollow(l.list, ['x', 'z'])) out.add(p.x, p.y, p.z); } else disk(out, a.x, a.y, a.z, rx, rz);
          break;
        }
        case 'cylinder': {
          const [rx, rz] = radii(a, s || t, this.opt('shape', 'even'));
          const l = new PosList(this.maxBlocks());
          disk(l, a.x, 0, a.z, rx, rz);
          const ring = s && hol ? hollow(l.list, ['x', 'z']) : l.list;
          for (const y of range(a.y, s ? t.y : a.y)) for (const p of ring) out.add(p.x, y, p.z);
          break;
        }
        case 'sphere': {
          const r = Math.sqrt((t.x - a.x) ** 2 + (t.y - a.y) ** 2 + (t.z - a.z) ** 2);
          if (hol) { const l = new PosList(1000000); sphere(l, a, r, false); for (const p of hollow(l.list, ['x', 'y', 'z'])) out.add(p.x, p.y, p.z); } else sphere(out, a, r, false);
          break;
        }
        case 'semi': this.semi(out, a, t, yaw, hol); break;
        case 'cone': if (s) cone(out, a, s, t.y, hol); else disk(out, a.x, a.y, a.z, ...radii(a, t, 'even')); break;
        case 'copy': box(out, a, t, 'filled'); break;
      }
      return out.list;
    }

    semi(out, a, t, yaw, hol) {
      const orient = this.opt('orient', 'horizontal');
      const dx = t.x - a.x, dy = t.y - a.y, dz = t.z - a.z;
      const l = new PosList(1000000);
      if (orient === 'horizontal') {
        const r = Math.sqrt(dx * dx + dz * dz);
        const f = { south: [0, 1], north: [0, -1], west: [-1, 0], east: [1, 0] }[yawDir4(yaw)];
        disk(l, a.x, a.y, a.z, r, r, (ox, oz) => ox * f[0] + oz * f[1] >= 0);
      } else if (orient === 'arch') {
        const ns = facingNS(yaw);
        const r = Math.max(Math.abs(ns ? dx : dz), Math.abs(dy));
        const e = r + 0.5, i = Math.ceil(r);
        for (let h = -i; h <= i; h++) for (let v = 0; v <= i; v++) if (h * h + v * v <= e * e) { if (ns) l.add(a.x + h, a.y + v, a.z); else l.add(a.x, a.y + v, a.z + h); }
      } else {
        sphere(l, a, Math.sqrt(dx * dx + dy * dy + dz * dz), true);
      }
      const list = hol ? hollow(l.list, orient === 'dome' ? ['x', 'y', 'z'] : axesOf(l.list)) : l.list;
      for (const p of list) out.add(p.x, p.y, p.z);
    }

    // Отражение, массив и радиальное отражение (как в Effortless Building: массив → отражение → радиальное)
    modify(list, id) {
      const c = this.cfg;
      const cap = this.maxBlocks();
      let cur = list;
      if (c.array.on && c.array.count > 0) {
        const out = new PosList(cap);
        for (const p of cur) out.add(p.x, p.y, p.z, p.d);
        for (let k = 1; k <= c.array.count && !out.full; k++) for (const p of cur) out.add(p.x + c.array.ox * k, p.y + c.array.oy * k, p.z + c.array.oz * k, p.d);
        cur = out.list;
      }
      if (c.mirror.on) {
        const m = c.mirror, off = m.half ? 1 : 0;
        for (const axis of ['x', 'y', 'z']) {
          if (!m[axis]) continue;
          const out = new PosList(cap);
          const center = axis === 'x' ? m.cx : axis === 'y' ? m.cy : m.cz;
          for (const p of cur) {
            out.add(p.x, p.y, p.z, p.d);
            const q = { x: p.x, y: p.y, z: p.z };
            q[axis] = 2 * center + off - p[axis];
            out.add(q.x, q.y, q.z, flipData(id, p.d, axis));
          }
          cur = out.list;
        }
      }
      if (c.radial.on && c.radial.slices > 1) {
        const r = c.radial, out = new PosList(cap);
        for (const p of cur) {
          const dx = p.x - r.cx, dz = p.z - r.cz;
          for (let k = 0; k < r.slices; k++) {
            const ang = k * Math.PI * 2 / r.slices, cs = Math.cos(ang), sn = Math.sin(ang);
            const mx = r.alt && k % 2 === 1 ? -dx : dx;
            const rx = r.cx + Math.round(mx * cs - dz * sn), rz = r.cz + Math.round(mx * sn + dz * cs);
            out.add(rx, p.y, rz, p.d);
          }
        }
        cur = out.list;
      }
      return cur;
    }

    // ---------- Кадр ----------
    update(hit) {
      const g = this.game;
      // Очередь установки: большие фигуры ставятся частями, чтобы игра не замирала
      if (this.queue.length) this.runQueue();
      if (this.net.length) this.runNet(); else this.netInfo = '';
      // Кнопки отмены и повтора на экране видны, пока включён режим строительства
      if (this.bodyEb !== this.active()) { this.bodyEb = this.active(); document.body.classList.toggle('eb', this.bodyEb); }
      if (!this.active()) { this.setHint(''); return; }
      if (this.cfg.mode === 'copy' && this.clip && !this.pending) {
        const at = hit ? this.placePos(hit) : null;
        const key = at ? at.x + ',' + at.y + ',' + at.z + ':' + this.clipRot + ':' + this.version : '';
        if (key !== this.previewKey) {
          this.previewKey = key;
          this.preview = at ? { list: this.pasteList(at), kind: 'place', v: ++this.pv } : null;
        }
        this.setHint('Копирование: нажмите «использовать», чтобы вставить (' + this.clip.blocks.length + ' бл.)');
        return;
      }
      if (this.cfg.mode === 'air' && !hit && this.buildable(g.heldItem())) {
        const p = this.airPos();
        const key = 'air:' + p.x + ',' + p.y + ',' + p.z + ':' + this.version;
        if (key !== this.previewKey) { this.previewKey = key; this.preview = { list: this.modify([p], g.heldItem().id), kind: 'place', v: ++this.pv }; }
        this.setHint('В воздухе: нажмите «использовать», чтобы поставить блок перед собой');
        return;
      }
      if (!this.pending) {
        // Прицел в воздухе: показываем блок, с которого начнётся фигура при нажатии
        if (!hit && this.cfg.mode !== 'copy' && this.buildable(g.heldItem())) {
          const p = this.airPos();
          const key = 'start:' + p.x + ',' + p.y + ',' + p.z + ':' + this.version;
          if (key !== this.previewKey) { this.previewKey = key; this.preview = { list: [p], kind: 'place', v: ++this.pv }; }
          this.setHint(this.mode.name + ': прицел в воздухе — нажмите «использовать», фигура начнётся с подсвеченного блока');
          return;
        }
        if (this.preview) { this.preview = null; this.previewKey = ''; }
        this.setHint(this.mode.name + (this.cfg.mode === 'copy' ? ': выделите область — нажмите на два угла' : ': нажмите «использовать» или «ломать», чтобы начать'));
        return;
      }
      const t = this.computeTarget(hit) || this.fallbackTarget() || this.target || this.pending.anchor;
      this.target = t;
      const pd = this.pending;
      const key = [t.x, t.y, t.z, pd.second ? pd.second.x + '/' + pd.second.y + '/' + pd.second.z : '-', Math.round(g.player.yaw / 45), this.version].join(',');
      if (key !== this.previewKey) {
        this.previewKey = key;
        let list = this.shape(pd.anchor, t, pd.second);
        if (pd.action === 'place') list = this.modify(list.map((p) => ({ x: p.x, y: p.y, z: p.z, d: pd.data })), pd.item.id);
        else if (this.cfg.mode !== 'copy') list = this.modify(list, 0);
        this.preview = { list, kind: pd.action, v: ++this.pv };
      }
      const steps = this.mode.steps;
      const n = this.preview.list.length;
      const word = pd.action === 'break' ? 'сломать' : this.cfg.mode === 'copy' ? 'копировать' : 'поставить';
      const btn = pd.action === 'break' ? '«ломать»' : '«использовать»';
      const stage = steps === 3 && !pd.second ? 'основание; нажмите ' + btn + ', затем выберите высоту' : 'нажмите ' + btn + ', чтобы ' + word;
      this.setHint(this.mode.name + ': ' + n + ' бл. — ' + stage + (n >= this.maxBlocks() ? ' (предел)' : ''));
    }

    setHint(text) { this.hint = this.netInfo ? text + (text ? ' · ' : '') + this.netInfo : text; }

    // «Использовать». true — нажатие обработано строительством
    onUse(hit) {
      const g = this.game;
      if (!this.active() || !g.canEdit()) return false;
      const held = g.heldItem();
      const m = this.cfg.mode;
      if (m === 'copy') return this.copyUse(hit);
      if (this.pending && this.pending.action === 'break') { this.cancel(); g.ui.setPopup('Фигура отменена'); return true; }
      if (!this.buildable(held)) { if (this.pending) this.cancel(); return false; }
      if (hit && !g.player.sneaking && !this.pending && INTERACTIVE_HIT(hit.id)) return false;
      const item = { id: held.id, data: held.data };
      if (m === 'air') {
        const at = hit ? this.placePos(hit) : this.airPos();
        const data = hit ? g.placeData(item.id, item.data, hit, hit.face) : item.data;
        this.commitPlace(this.modify([{ x: at.x, y: at.y, z: at.z, d: data }], item.id), item);
        return true;
      }
      if (!this.pending) {
        // Начало фигуры можно поставить и в воздухе — перед собой на расстоянии досягаемости
        const a = hit ? this.placePos(hit) : this.airPos();
        if (a.y < 0 || a.y > 255) return true;
        this.pending = { action: 'place', anchor: a, second: null, item, data: hit ? g.placeData(item.id, item.data, hit, hit.face) : item.data };
        this.target = a;
        this.previewKey = '';
        return true;
      }
      if (this.pending.item.id !== item.id || this.pending.item.data !== item.data) {
        this.pending.item = item;
        this.pending.data = item.data;
      }
      this.step();
      return true;
    }

    // «Ломать» (первое нажатие). true — обработано
    onAttack(hit) {
      const g = this.game;
      if (!this.active() || !g.canEdit()) return false;
      const m = this.cfg.mode;
      if (m === 'air') return false;
      if (m === 'copy') { if (this.pending || this.clip) { this.cancel(); this.clip = null; g.ui.setPopup('Буфер копирования очищен'); return true; } return false; }
      if (this.pending && this.pending.action === 'place') { this.cancel(); g.ui.setPopup('Фигура отменена'); return true; }
      if (!this.pending) {
        if (!hit) return false;
        // В выживании на сервере каждый блок ломается вручную: сервер проверяет время разрушения
        if (g.mode === 'mp' && g.gamemode !== 1) return false;
        this.pending = { action: 'break', anchor: { x: hit.x, y: hit.y, z: hit.z }, second: null };
        this.target = this.pending.anchor;
        this.previewKey = '';
        return true;
      }
      this.step();
      return true;
    }

    step() {
      const pd = this.pending;
      if (this.mode.steps === 3 && !pd.second) {
        pd.second = this.target || pd.anchor;
        this.previewKey = '';
        return;
      }
      const list = this.preview ? this.preview.list : [];
      this.cancel();
      if (pd.action === 'place') this.commitPlace(list, pd.item);
      else this.commitBreak(list);
    }

    // ---------- Изменение мира ----------
    canPlaceAt(x, y, z, id) {
      const g = this.game, w = g.world;
      if (y < 0 || y > 255 || !w.getChunk(x >> 4, z >> 4)) return false;
      const cur = w.getId(x, y, z);
      const cb = MC.Blocks.list[cur];
      if (!cb.replaceable) {
        if (g.mode === 'mp') return false;
        if (!this.cfg.replace || cur === 7 || cb.hardness < 0 || cur === id) return false;
      }
      const b = MC.Blocks.list[id];
      if (b.solid) {
        const bb = g.player.aabb(g.player.x, g.player.y, g.player.z);
        if (bb[3] > x && bb[0] < x + 1 && bb[4] > y && bb[1] < y + 1 && bb[5] > z && bb[2] < z + 1) return false;
      }
      return true;
    }

    commitPlace(list, item) {
      const g = this.game, w = g.world;
      const ops = [];
      for (const p of list) {
        if (!this.canPlaceAt(p.x, p.y, p.z, item.id)) continue;
        ops.push({ x: p.x, y: p.y, z: p.z, oid: w.getId(p.x, p.y, p.z), odata: w.getData(p.x, p.y, p.z), nid: item.id, ndata: p.d === undefined ? item.data : p.d });
      }
      this.applyNew(ops, 'Поставлено');
    }

    commitBreak(list) {
      const g = this.game, w = g.world;
      const ops = [];
      for (const p of list) {
        if (p.y < 0 || p.y > 255 || !w.getChunk(p.x >> 4, p.z >> 4)) continue;
        const id = w.getId(p.x, p.y, p.z);
        if (!id || MC.Blocks.list[id].hardness < 0 || MC.Blocks.list[id].liquid) continue;
        ops.push({ x: p.x, y: p.y, z: p.z, oid: id, odata: w.getData(p.x, p.y, p.z), nid: 0, ndata: 0 });
      }
      this.applyNew(ops, 'Сломано');
    }

    // Проверка скриптами и расход предметов в выживании, затем запись в историю и очередь
    applyNew(ops, word) {
      const g = this.game;
      if (g.scripts) ops = ops.filter((o) => (o.nid ? g.scripts.emit('blockPlace', { x: o.x, y: o.y, z: o.z, id: o.nid, data: o.ndata }) : g.scripts.emit('blockBreak', { x: o.x, y: o.y, z: o.z, id: o.oid, data: o.odata })) !== false);
      if (g.mode === 'mp') {
        if (g.gamemode !== 1) ops = ops.filter((o) => o.nid);
        if (!ops.length) { g.ui.setPopup('Здесь нечего ставить или ломать'); return; }
        const n = this.netEnqueue(ops);
        this.undoStack.push(ops);
        if (this.undoStack.length > HISTORY) this.undoStack.shift();
        this.redoStack = [];
        g.ui.setPopup(word + ' в очередь: ' + n + ' бл. — ставятся на сервере в радиусе досягаемости');
        return;
      }
      let short = 0;
      if (this.survival()) {
        const res = this.payFor(ops, true);
        ops = res.ops;
        short = res.short;
      }
      if (!ops.length) { g.ui.setPopup(short ? '§cНе хватает блоков в инвентаре' : 'Здесь нечего ставить или ломать'); return; }
      this.queue.push(...ops.map((o) => ({ op: o, dir: 1 })));
      this.undoStack.push(ops);
      if (this.undoStack.length > HISTORY) this.undoStack.shift();
      this.redoStack = [];
      const o = ops[0];
      if (o.nid) MC.Sound.block(o.nid, 'place', o.x + 0.5, o.y + 0.5, o.z + 0.5);
      else MC.Sound.block(o.oid, 'break', o.x + 0.5, o.y + 0.5, o.z + 0.5);
      g.player.swingTime = 1;
      g.ui.setPopup(word + ': ' + ops.length + ' бл.' + (this.lastSubs ? ' §e(заменено: ' + this.lastSubs + ')' : '') + (short ? ' §cНе хватило блоков: ' + short : ''));
    }

    // Выживание: для каждой операции (из состояния «было» в «стало») нужен блок «стало» из инвентаря,
    // а убранный блок возвращается (при ломании — как обычный дроп с учётом инструмента)
    payFor(ops, fresh) {
      const g = this.game, inv = g.sinv;
      const out = [];
      let short = 0, subs = 0;
      const stock = this.stock();
      for (const o of ops) {
        if (!o.nid) { out.push(o); continue; }
        const pi = placeItem(o.nid, o.ndata);
        if (!pi) { short++; continue; }
        if (pi.part) { out.push(o); continue; }
        let k = pi.id + ':' + pi.data, n = pi.count;
        if (!(stock.get(k) >= n)) {
          // Нужного блока нет: строим из того, что есть (если включено; схемы ставят только точные блоки)
          const sub = o.exact ? null : this.findSubstitute(o.nid, o.ndata, stock);
          if (!sub) { short++; continue; }
          o.nid = sub.id; o.ndata = sub.data;
          k = sub.key; n = 1;
          subs++;
          if (this.onSubst) this.onSubst(o);
        }
        stock.set(k, stock.get(k) - n);
        o.pay = { k, n };
        out.push(o);
      }
      this.lastSubs = subs;
      for (const o of out) {
        if (o.pay) { const [iid, idata] = o.pay.k.split(':').map(Number); inv.remove(iid, idata, o.pay.n); delete o.pay; }
        if (o.oid && !MC.Blocks.list[o.oid].liquid) {
          const drops = fresh ? MC.Survival.blockDrops(o.oid, o.odata, g.heldItem().id) : [Object.assign(itemOf(o.oid, o.odata), { count: 1 })];
          for (const it of drops) this.give(it, o);
        }
      }
      if (fresh && out.some((o) => !o.nid)) g.wearTool(Math.min(out.filter((o) => !o.nid).length, 1000));
      return { ops: out, short };
    }

    give(it, at) {
      const g = this.game;
      const left = g.sinv.add({ id: it.id, data: it.data, count: it.count || 1 });
      if (left > 0) g.ents.spawnItem({ id: it.id, data: it.data, count: left }, at.x + 0.5, at.y + 0.5, at.z + 0.5);
    }

    runQueue() {
      const w = this.game.world;
      const n = Math.min(OPS_PER_FRAME, this.queue.length);
      for (let i = 0; i < n; i++) {
        const { op, dir } = this.queue.shift();
        const id = dir > 0 ? op.nid : op.oid, data = dir > 0 ? op.ndata : op.odata;
        w.setBlock(op.x, op.y, op.z, id, data);
      }
    }

    // ---------- Сервер ----------
    netEnqueue(ops) {
      let n = 0;
      if (!this.net.length) { this.netSel = this.game.selected; this.netEquip = ''; }
      for (const o of ops) {
        const k = o.x + ',' + o.y + ',' + o.z;
        if (this.netKeys.has(k)) continue;
        const e = { op: o, k, t: 0, tries: 0, ok: false };
        this.netKeys.set(k, e);
        this.net.push(e);
        n++;
      }
      // Снизу вверх: у каждого блока появляется опора из уже поставленных
      this.net.sort((a, b) => a.op.y - b.op.y || a.op.nid - b.op.nid);
      return n;
    }

    netDrop(i) {
      this.netKeys.delete(this.net[i].k);
      this.net.splice(i, 1);
    }

    // Ответ сервера UpdateBlock: подтверждение установки или разрушения
    netConfirm(x, y, z, id) {
      const e = this.netKeys.get(x + ',' + y + ',' + z);
      if (!e || !e.t) return;
      const o = e.op;
      e.ok = o.nid ? id === o.nid : id === 0;
      if (o.nid && id && !e.ok) {
        // Половина двойной плиты — это продолжение, не ошибка; остальное — сервер поставил другой блок
        const pi = placeItem(o.nid, o.ndata);
        if (!(pi && pi.double && id === pi.id) && !(pi && pi.part) && !MC.Blocks.list[id].replaceable) e.wrong = id;
      }
    }

    clearNet() {
      this.net = [];
      this.netKeys.clear();
      this.netInfo = '';
    }

    // Соседний твёрдый блок, по грани которого кликаем (MCPE ставит блок только к существующему)
    support(o) {
      const w = this.game.world;
      for (let f = 0; f < 6; f++) {
        const d = FACE_DIR[f];
        const x = o.x + d[0], y = o.y + d[1], z = o.z + d[2];
        if (y < 0 || y > 255) continue;
        const id = w.getId(x, y, z), b = MC.Blocks.list[id];
        if (!id || !b || b.replaceable || b.liquid || INTERACTIVE_HIT(id)) continue;
        // Опора, которую сервер ещё не подтвердил, для него пока воздух: ставить на неё рано
        const pend = this.netKeys.get(x + ',' + y + ',' + z);
        if (pend && pend.op.nid && !pend.ok) continue;
        return { x, y, z, id, face: f ^ 1 };
      }
      return null;
    }

    // Ячейка панели с нужным блоком; в творческом блок кладётся в выбранную ячейку
    netSlot(it) {
      const g = this.game;
      const bl = it.id < 256 ? MC.Blocks.list[it.id] : null, v = it.id >= 256 || (!!bl && bl.variants > 1);
      for (let i = 0; i < 9; i++) {
        const h = g.hotbarItem(i);
        if (h && h.id === it.id && (!v || h.data === it.data)) return i;
      }
      // На сервере панель — ссылки на ячейки инвентаря: связываем выбранную ячейку панели с ячейкой, где лежит блок
      if (g.mode === 'mp') {
        for (let s = 0; s < g.inv.length; s++) {
          const h = g.inv[s];
          if (!h || h.id !== it.id || (v && h.data !== it.data)) continue;
          g.hotbarMap[g.selected] = s;
          return g.selected;
        }
      }
      if (g.gamemode === 1) {
        const c = g.creativeItems && g.creativeItems.find((x) => x.id === it.id && (x.data === it.data || x.data < 0));
        if (c || !g.creativeItems) { g.setCreativeSlot({ id: it.id, data: it.data, count: 64, nbt: c && c.nbt }); return g.selected; }
      }
      return -1;
    }

    runNet() {
      const g = this.game, p = g.player, w = g.world, now = performance.now();
      const dt = this.netLast ? Math.min(0.25, (now - this.netLast) / 1000) : 0;
      this.netLast = now;
      const rate = Math.max(2, Math.min(20, this.cfg.netRate | 0 || 8));
      this.netBudget = Math.min(2, this.netBudget + dt * rate);
      if (g.dead || !g.canEdit()) { this.netInfo = 'Сервер: очередь ждёт (' + this.net.length + ' бл.)'; return; }
      const reach = reachOf(g);
      const ex = p.x, ey = p.eyeY, ez = p.z;
      let far = 0, nosup = 0, missing = null, wait = 0, behind = 0, stock = null;
      // Сервер принимает установку только перед игроком (полуплоскость по направлению взгляда, как проверяет Nukkit)
      const yr = p.yaw * Math.PI / 180, lx = -Math.sin(yr), lz = Math.cos(yr);
      for (let i = this.net.length - 1; i >= 0; i--) {
        const e = this.net[i], o = e.op;
        if (!w.getChunk(o.x >> 4, o.z >> 4)) { far++; continue; }
        if (e.wrong) {
          // Сервер поставил не тот блок (в руке на сервере оказался другой предмет)
          if (g.gamemode === 1 && e.tries < 4) {
            g.client.sendAction(MC.PLAYER_ACTION.START_BREAK, o.x, o.y, o.z, 1);
            g.client.sendRemoveBlock(o.x, o.y, o.z);
            w.setBlock(o.x, o.y, o.z, 0, 0);
            this.netEquip = '';
            e.wrong = 0;
            e.t = now;
            e.ok = false;
            continue;
          }
          this.netWrong = (this.netWrong || 0) + 1;
          this.netDrop(i);
          continue;
        }
        if (e.t && !e.ok && now - e.t < 1500) { wait++; continue; }
        if (e.ok) { this.netDrop(i); continue; }
        let cur = w.getId(o.x, o.y, o.z);
        const pi = o.nid ? placeItem(o.nid, o.ndata) : null;
        if (o.nid && !pi) { this.netCannot = (this.netCannot || 0) + 1; this.netDrop(i); continue; }
        // Верхняя половина двери или изголовье кровати встаёт вместе с первой половиной
        if (pi && pi.part) {
          if (cur === o.nid || now - (e.born || (e.born = now)) > 8000) this.netDrop(i); else wait++;
          continue;
        }
        const half = pi && pi.double && cur === pi.id;
        if (e.t) {
          // Сервер не подтвердил: убираем показанный заранее блок и пробуем ещё раз
          if (cur === o.nid) { w.setBlock(o.x, o.y, o.z, o.oid, o.odata); cur = o.oid; }
        } else if (o.nid ? cur === o.nid : cur === 0) { this.netDrop(i); continue; }
        if (e.tries >= 5 || (o.nid && !half && !MC.Blocks.list[cur].replaceable)) { this.netDrop(i); continue; }
        const d2 = (o.x + 0.5 - ex) ** 2 + (o.y + 0.5 - ey) ** 2 + (o.z + 0.5 - ez) ** 2;
        if (d2 > reach * reach) { far++; continue; }
        if (lx * (o.x + 0.5 - ex) + lz * (o.z + 0.5 - ez) < -0.4) { behind++; continue; }
        if (this.netBudget < 1) continue;
        if (o.nid) {
          // Двойная плита: вторая плита ставится нажатием на уже стоящую
          const s = half ? { x: o.x, y: o.y, z: o.z, id: cur, face: w.getData(o.x, o.y, o.z) & 8 ? 0 : 1 } : this.support(o);
          if (!s) { nosup++; continue; }
          const bb = p.aabb(p.x, p.y, p.z);
          if (MC.Blocks.list[o.nid].solid && bb[3] > o.x && bb[0] < o.x + 1 && bb[4] > o.y && bb[1] < o.y + 1 && bb[5] > o.z && bb[2] < o.z + 1) continue;
          let it = { id: pi.id, data: pi.data };
          let slot = this.netSlot(it);
          if (slot < 0 && g.gamemode !== 1 && !o.exact) {
            // Нужного блока нет в инвентаре сервера: берём похожий или любой (по настройке)
            const sub = this.findSubstitute(o.nid, o.ndata, stock || (stock = this.stock()));
            if (sub) {
              o.nid = sub.id; o.ndata = sub.data;
              const sp = placeItem(o.nid, o.ndata);
              it = { id: sp.id, data: sp.data };
              slot = this.netSlot(it);
              if (slot >= 0) { stock.set(sub.key, stock.get(sub.key) - 1); if (this.onSubst) this.onSubst(o); }
            }
          }
          if (slot < 0) { missing = missing || MC.Items.itemName(it.id, it.data); continue; }
          if (slot !== g.selected) g.selectHotbar(slot);
          // Сервер должен знать, что в руке именно этот блок (иначе отклонит установку)
          const hk = g.selected + ':' + g.hotbarMap[g.selected] + ':' + it.id + ':' + it.data;
          if (hk !== this.netEquip) {
            this.netEquip = hk;
            const hs = g.hotbarMap[g.selected];
            g.client.sendEquipment(g.heldItem(), hs >= 0 ? hs + 9 : 255, g.selected);
          }
          const fd = FACE_DIR[s.face];
          g.client.sendUseItem(s.x, s.y, s.z, s.face, 0.5 + fd[0] * 0.5, 0.5 + fd[1] * 0.5, 0.5 + fd[2] * 0.5, ex, ey, ez, g.selected, g.heldItem(), s.id);
          // Показываем сразу; если сервер откажет, он вернёт прежний блок пакетом UpdateBlock
          if (!half || pi.count === 2) w.setBlock(o.x, o.y, o.z, o.nid, o.ndata);
          MC.Sound.block(o.nid, 'place', o.x + 0.5, o.y + 0.5, o.z + 0.5);
        } else {
          g.client.sendAction(MC.PLAYER_ACTION.START_BREAK, o.x, o.y, o.z, 1);
          g.client.sendRemoveBlock(o.x, o.y, o.z);
          w.setBlock(o.x, o.y, o.z, 0, 0);
        }
        g.client.sendSwing();
        p.swingTime = 1;
        e.t = now;
        e.tries++;
        this.netBudget -= 1;
      }
      if (!this.net.length) {
        if (this.netSel !== undefined && this.netSel !== g.selected) g.selectHotbar(this.netSel);
        if (this.netWrong || this.netCannot) {
          g.ui.setPopup('§eГотово, но: ' + [this.netWrong ? 'сервер поставил не тот блок — ' + this.netWrong : '', this.netCannot ? 'нельзя поставить предметом (вода, огонь и т. п.) — ' + this.netCannot : ''].filter(Boolean).join('; '));
          this.netWrong = 0;
          this.netCannot = 0;
        }
        this.netInfo = '';
        return;
      }
      const left = this.net.length - wait;
      this.netInfo = left <= 0 ? 'Сервер: проверка ' + wait + ' бл.' : 'Сервер: осталось ' + left + ' бл.' +
        (this.netCannot ? ' — нельзя поставить предметом: ' + this.netCannot : '') +
        (missing ? ' — §cнет в инвентаре: ' + missing : behind ? ' — повернитесь к постройке (' + behind + ' за спиной)' : far ? ' — подойдите ближе (' + far + ' далеко)' : nosup ? ' — нет опоры у ' + nosup : '');
    }

    undo() { this.history(this.undoStack, this.redoStack, -1, 'Отменено'); }
    redo() { this.history(this.redoStack, this.undoStack, 1, 'Повторено'); }

    history(from, to, dir, word) {
      const g = this.game;
      if (g.mode === 'mp' && g.gamemode !== 1) { g.ui.setPopup('На сервере отмена работает только в творческом режиме'); return; }
      const ops = from.pop();
      if (!ops) { g.ui.setPopup(dir < 0 ? 'Нечего отменять' : 'Нечего повторять'); return; }
      // В обратную сторону операция меняет «стало» на «было»
      let list = ops.map((o) => (dir < 0 ? { x: o.x, y: o.y, z: o.z, oid: o.nid, odata: o.ndata, nid: o.oid, ndata: o.odata, src: o } : Object.assign({ src: o }, o)));
      const w = g.world;
      list = list.filter((o) => w.getChunk(o.x >> 4, o.z >> 4) && w.getId(o.x, o.y, o.z) === o.oid);
      let short = 0;
      if (g.mode === 'sp' && this.survival()) { const r = this.payFor(list, false); list = r.ops; short = r.short; }
      if (!list.length) { g.ui.setPopup(short ? '§cНе хватает блоков в инвентаре' : 'Блоки уже изменены'); return; }
      if (g.mode === 'mp') {
        this.netEnqueue(list);
        to.push(list.map((o) => o.src));
        g.ui.setPopup(word + ': ' + list.length + ' бл. (в очереди сервера)');
        MC.Sound.click();
        return;
      }
      this.queue.push(...list.map((o) => ({ op: o, dir: 1 })));
      to.push(list.map((o) => o.src));
      g.ui.setPopup(word + ': ' + list.length + ' бл.' + (short ? ' §cНе хватило блоков: ' + short : ''));
      MC.Sound.click();
    }

    // ---------- Копирование ----------
    copyUse(hit) {
      const g = this.game;
      if (this.clip) {
        if (!hit) return true;
        const at = this.placePos(hit);
        const list = this.pasteList(at);
        const groups = new Map();
        for (const p of list) {
          const k = p.id + ':' + p.d;
          if (!groups.has(k)) groups.set(k, []);
          groups.get(k).push(p);
        }
        const w = g.world, ops = [];
        for (const p of list) {
          if (!this.canPlaceAt(p.x, p.y, p.z, p.id)) continue;
          ops.push({ x: p.x, y: p.y, z: p.z, oid: w.getId(p.x, p.y, p.z), odata: w.getData(p.x, p.y, p.z), nid: p.id, ndata: p.d });
        }
        this.applyNew(ops, 'Вставлено');
        return true;
      }
      if (!hit) return true;
      if (!this.pending) {
        this.pending = { action: 'copy', anchor: { x: hit.x, y: hit.y, z: hit.z }, second: null };
        this.target = this.pending.anchor;
        this.previewKey = '';
        return true;
      }
      const a = this.pending.anchor, b = { x: hit.x, y: hit.y, z: hit.z };
      this.cancel();
      const w = g.world, blocks = [];
      const x0 = Math.min(a.x, b.x), y0 = Math.min(a.y, b.y), z0 = Math.min(a.z, b.z);
      const x1 = Math.max(a.x, b.x), y1 = Math.max(a.y, b.y), z1 = Math.max(a.z, b.z);
      if ((x1 - x0 + 1) * (y1 - y0 + 1) * (z1 - z0 + 1) > this.maxBlocks() * 4) { g.ui.setPopup('§cСлишком большая область'); return true; }
      for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) {
        const id = w.getId(x, y, z);
        if (!id || NO_SHAPE.has(id) || MC.Blocks.list[id].hardness < 0 && id !== 7) continue;
        if (id === 7 && this.survival()) continue;
        blocks.push({ x: x - x0, y: y - y0, z: z - z0, id, d: w.getData(x, y, z) });
        if (blocks.length >= this.maxBlocks()) break;
      }
      if (!blocks.length) { g.ui.setPopup('В области нет блоков'); return true; }
      this.clip = { blocks, sx: x1 - x0 + 1, sz: z1 - z0 + 1 };
      this.clipRot = 0;
      this.version++;
      g.ui.setPopup('Скопировано: ' + blocks.length + ' бл. Нажмите «использовать», чтобы вставить');
      MC.Sound.click();
      return true;
    }

    rotateClip() { this.clipRot = (this.clipRot + 1) & 3; this.version++; }

    // Блоки буфера в мире: угол области — в точке вставки, поворот по часовой стрелке на 90° × clipRot
    pasteList(at) {
      const c = this.clip, out = [];
      for (const b of c.blocks) {
        let x = b.x, z = b.z, d = b.d;
        for (let r = 0; r < this.clipRot; r++) { const nx = -z, nz = x; x = nx; z = nz; d = rotateData(b.id, d); }
        out.push({ x: at.x + x, y: at.y + b.y, z: at.z + z, id: b.id, d });
      }
      return out;
    }

    // Центр отражения и радиального отражения — блок под игроком
    centerHere(which) {
      const p = this.game.player;
      const x = Math.floor(p.x), y = Math.floor(p.y), z = Math.floor(p.z);
      if (which === 'mirror') { this.cfg.mirror.cx = x; this.cfg.mirror.cy = y; this.cfg.mirror.cz = z; }
      else { this.cfg.radial.cx = x; this.cfg.radial.cz = z; }
      this.save();
      this.version++;
      return x + ' ' + y + ' ' + z;
    }

    changed() { this.save(); this.version++; }
  }

  function INTERACTIVE_HIT(id) {
    return [54, 58, 61, 62, 64, 71, 96, 107, 183, 184, 185, 186, 187, 193, 194, 195, 196, 197, 26, 69, 77, 143, 93, 94].indexOf(id) >= 0;
  }

  // Чем ставится блок: у дверей, кроватей, табличек, редстоуна, семян и т. п. предмет другой.
  // null — предметом не ставится (вода, огонь, портал); part — вторая половина двери или кровати, встаёт сама
  const PLACE_ITEM = {
    64: [324, 0], 71: [330, 0], 193: [427, 0], 194: [428, 0], 195: [429, 0], 196: [430, 0], 197: [431, 0], 26: [355, 0],
    63: [323, 0], 68: [323, 0], 55: [331, 0], 59: [295, 0], 141: [391, 0], 142: [392, 0], 207: [458, 0], 104: [361, 0], 105: [362, 0],
    115: [372, 0], 83: [338, 0], 92: [354, 0], 118: [380, 0], 117: [379, 0], 140: [390, 0], 132: [287, 0], 127: [351, 3],
    62: [61, 0], 124: [123, 0], 93: [356, 0], 94: [356, 0], 149: [404, 0], 150: [404, 0], 75: [76, 0], 74: [73, 0], 178: [151, 0],
    8: null, 9: null, 10: null, 11: null, 51: null, 90: null, 119: null, 120: null, 34: null, 36: null, 95: null, 166: null
  };
  // Двойные плиты ставятся двумя одинарными
  const DOUBLE_SLAB = { 43: 44, 157: 158, 181: 182 };
  function placeItem(id, data) {
    if ((DOOR.has(id) || id === 26 || id === 175) && data & 8) return { part: true };
    if (DOUBLE_SLAB[id]) { const sid = DOUBLE_SLAB[id], b = MC.Blocks.list[sid], v = b && b.variants > 1 ? b.variants : 1; return { id: sid, data: v > 1 ? (data & 7) % v : 0, count: 2, double: true }; }
    if (id in PLACE_ITEM) { const m = PLACE_ITEM[id]; return m ? { id: m[0], data: m[1], count: 1 } : null; }
    const it = itemOf(id, data);
    return { id: it.id, data: it.data, count: 1 };
  }

  // Предмет для блока (ориентация не входит в данные предмета)
  // Вид лежит в младших битах данных; старшие — поворот, верх/низ, возраст (у кварца-колонны вид один на все оси)
  function itemOf(id, data) {
    const b = MC.Blocks.list[id];
    const v = b && b.variants > 1 ? b.variants : 1;
    if (id === 155) return { id, data: Math.min(data & 15, 2) };
    return { id, data: v > 8 ? data % v : v > 1 ? (data & 7) % v : 0 };
  }

  // ---------- Поворот и отражение данных блоков (ориентация в MCPE 1.1) ----------
  // Семейства: стороны 2..5 (сев., юг, зап., вост.), факелы 1..5, «+1» (0 юг, 1 зап., 2 сев., 3 вост.), двери, лоза, брёвна
  const FACE4 = new Set([54, 61, 62, 65, 68, 130, 146, 23, 125, 154, 29, 33, 34, 77, 143]);
  const TORCH = new Set([50, 75, 76]);
  const PLUS1 = new Set([26, 86, 91, 93, 94, 149, 150, 107, 183, 184, 185, 186, 187, 120, 145]);
  const DOOR = new Set([64, 71, 193, 194, 195, 196, 197]);
  const TRAP = new Set([96, 167]);
  const LOGS = new Set([17, 162, 170, 155, 201]);
  const CW4 = { 2: 5, 5: 3, 3: 4, 4: 2 };
  const CWT = { 1: 3, 3: 2, 2: 4, 4: 1 };

  // Поворот на 90° по часовой стрелке (вид сверху): восток → юг → запад → север
  function rotateData(id, d) {
    if (d === undefined) return d;
    if (STAIRS.has(id) || TRAP.has(id)) return [2, 3, 1, 0][d & 3] | (d & ~3);
    if (FACE4.has(id)) { const f = d & 7; return CW4[f] !== undefined ? CW4[f] | (d & 8) : d; }
    if (TORCH.has(id)) return CWT[d & 7] !== undefined ? CWT[d & 7] | (d & 8) : d;
    if (PLUS1.has(id)) return ((d + 1) & 3) | (d & ~3);
    if (DOOR.has(id)) return d & 8 ? d : ((d + 1) & 3) | (d & 4);
    if (id === 106) return ((d << 1) | (d >> 3)) & 15;
    if (LOGS.has(id)) {
      if (id === 155 || id === 201) { const t = d & 15; return id === 155 ? (t === 3 ? 4 : t === 4 ? 3 : t) : d; }
      const ax = d & 12;
      return (d & 3) | (ax === 4 ? 8 : ax === 8 ? 4 : ax);
    }
    return d;
  }

  // Отражение по оси (зеркало): меняются местами противоположные стороны
  function flipData(id, d, axis) {
    if (d === undefined) return d;
    if (STAIRS.has(id) || TRAP.has(id)) {
      const dir = d & 3, up = d & 4;
      if (axis === 'x' && dir < 2) return (dir ^ 1) | (d & ~3);
      if (axis === 'z' && dir >= 2) return (dir ^ 1) | (d & ~3);
      if (axis === 'y' && STAIRS.has(id)) return dir | (up ^ 4);
      return d;
    }
    if (axis === 'y') return d;
    if (FACE4.has(id)) { const f = d & 7; const m = axis === 'x' ? { 4: 5, 5: 4 } : { 2: 3, 3: 2 }; return m[f] !== undefined ? m[f] | (d & 8) : d; }
    if (TORCH.has(id)) { const m = axis === 'x' ? { 1: 2, 2: 1 } : { 3: 4, 4: 3 }; return m[d & 7] !== undefined ? m[d & 7] | (d & 8) : d; }
    if (PLUS1.has(id)) { const f = d & 3; const m = axis === 'x' ? { 1: 3, 3: 1 } : { 0: 2, 2: 0 }; return m[f] !== undefined ? m[f] | (d & ~3) : d; }
    if (DOOR.has(id)) { if (d & 8) return d; const f = d & 3; const m = axis === 'x' ? { 0: 2, 2: 0 } : { 1: 3, 3: 1 }; return m[f] !== undefined ? m[f] | (d & 4) : d; }
    if (id === 106) { return axis === 'x' ? (d & 5) | ((d & 2) << 2) | ((d & 8) >> 2) : (d & 10) | ((d & 1) << 2) | ((d & 4) >> 2); }
    return d;
  }

  // Досягаемость для установки блоков (от глаз до центра блока, как проверяет сервер)
  function reachOf(g) { return g.gamemode === 1 ? 5.5 : 4.5; }

  // Ориентация в данных блока (без открытости, питания и т. п.); -1 — у блока нет ориентации
  const SLAB = new Set([44, 158, 182]);
  function orientOf(id, d) {
    if (STAIRS.has(id)) return d & 7;
    if (TRAP.has(id)) return d & 11;
    if (FACE4.has(id) || TORCH.has(id)) return d & 7;
    if (PLUS1.has(id)) return d & 3;
    if (DOOR.has(id)) return d & 8 ? -1 : d & 3;
    if (LOGS.has(id)) return id === 155 || id === 201 ? d : d & 12;
    if (SLAB.has(id)) return d & 8;
    return -1;
  }

  MC.Building = Building;
  MC.Building.orientOf = orientOf;
  MC.Building.reachOf = reachOf;
  MC.Building.placeItem = placeItem;
  MC.Building.itemOf = itemOf;
  MC.Building.DOUBLE_SLAB = DOUBLE_SLAB;
  MC.Building.rotateData = rotateData;
  MC.Building.flipData = flipData;
  MC.Building.MODES = MODES;
  MC.Building.OPTS = OPTS;
})();
