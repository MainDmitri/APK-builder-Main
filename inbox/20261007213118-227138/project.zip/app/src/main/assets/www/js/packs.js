// Текстур-паки .mcpack (zip с manifest.json и папкой textures), как в Minecraft Bedrock.
// Паки хранятся в IndexedDB, при запуске их текстуры накладываются на встроенные атласы.
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});
  const A = window.MC_ASSETS;
  const TILE = 16;

  const GRASS = [0x79, 0xc0, 0x5a], FOLIAGE = [0x59, 0xae, 0x30], BIRCH = [0x80, 0xa7, 0x55], SPRUCE = [0x61, 0x99, 0x61], WATER = [0x44, 0x7a, 0xf5];
  const ENTITY_TEX = {
    chicken: 'chicken', cow: 'cow/cow', mooshroom: 'cow/mooshroom', pig: 'pig/pig', sheep: 'sheep/sheep', wolf: 'wolf/wolf', villager: 'villager/villager',
    squid: 'squid', rabbit: 'rabbit/brown', bat: 'bat', iron_golem: 'iron_golem', snow_golem: 'snow_golem', ocelot: 'cat/ocelot', polarbear: 'polarbear',
    zombie: 'zombie/zombie', creeper: 'creeper/creeper', skeleton: 'skeleton/skeleton', spider: 'spider/spider', cave_spider: 'spider/cave_spider',
    pigzombie: 'pig/pigzombie', slime: 'slime/slime', enderman: 'enderman/enderman', silverfish: 'silverfish', ghast: 'ghast/ghast', magmacube: 'slime/magmacube',
    blaze: 'blaze', zombie_villager: 'zombie_villager/zombie_villager', witch: 'witch', stray: 'skeleton/stray', husk: 'zombie/husk',
    wither_skeleton: 'skeleton/wither_skeleton', guardian: 'guardian', vindicator: 'vindicator', evoker: 'illager/evoker', vex: 'vex/vex'
  };

  function blockTint(name) {
    if (name === 'grass_side') return [GRASS, 'mask'];
    if (name === 'grass_top' || name === 'tallgrass' || name === 'fern' || name.startsWith('double_plant_grass') || name.startsWith('double_plant_fern') || name === 'reeds') return [GRASS, 'all'];
    if (name === 'leaves_birch') return [BIRCH, 'all'];
    if (name === 'leaves_spruce') return [SPRUCE, 'all'];
    if (/^leaves_(oak|jungle|acacia|big_oak)$/.test(name) || name === 'vine' || name === 'waterlily') return [FOLIAGE, 'all'];
    if (name === 'water_still' || name === 'water_flow') return [WATER, 'all'];
    return null;
  }

  // ---------- ZIP: центральный каталог + deflate через DecompressionStream ----------
  function parseZip(buf) {
    const dv = new DataView(buf);
    const u8 = new Uint8Array(buf);
    let eocd = -1;
    for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 70000); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('Это не zip-архив (.mcpack)');
    const count = dv.getUint16(eocd + 10, true);
    let off = dv.getUint32(eocd + 16, true);
    const entries = new Map();
    const dec = new TextDecoder();
    for (let i = 0; i < count; i++) {
      if (dv.getUint32(off, true) !== 0x02014b50) break;
      const method = dv.getUint16(off + 10, true);
      const csize = dv.getUint32(off + 20, true);
      const usize = dv.getUint32(off + 24, true);
      const nlen = dv.getUint16(off + 28, true), elen = dv.getUint16(off + 30, true), clen = dv.getUint16(off + 32, true);
      const local = dv.getUint32(off + 42, true);
      const name = dec.decode(u8.subarray(off + 46, off + 46 + nlen)).replace(/\\/g, '/');
      if (!name.endsWith('/')) entries.set(name, { method, csize, usize, local });
      off += 46 + nlen + elen + clen;
    }
    return {
      names: [...entries.keys()],
      async read(name) {
        const e = entries.get(name);
        if (!e) return null;
        const nlen = dv.getUint16(e.local + 26, true), elen = dv.getUint16(e.local + 28, true);
        const start = e.local + 30 + nlen + elen;
        const data = u8.subarray(start, start + e.csize);
        if (e.method === 0) return data.slice();
        if (e.method !== 8) throw new Error('Неподдерживаемое сжатие в архиве: ' + e.method);
        if (typeof DecompressionStream === 'undefined') throw new Error('Браузер не поддерживает распаковку zip (нужен Chrome/WebView 103+)');
        const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
        return new Uint8Array(await new Response(stream).arrayBuffer());
      }
    };
  }

  // ---------- Декодирование картинок: PNG через браузер, TGA вручную ----------
  function decodeTga(bytes) {
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const idLen = bytes[0], type = bytes[2], w = dv.getUint16(12, true), h = dv.getUint16(14, true), bpp = bytes[16], desc = bytes[17];
    if ((type !== 2 && type !== 10) || (bpp !== 24 && bpp !== 32)) throw new Error('TGA: поддерживаются только truecolor 24/32 бит');
    const out = new Uint8ClampedArray(w * h * 4);
    const bytesPerPixel = bpp / 4;
    let p = 18 + idLen;
    const topDown = (desc & 0x20) !== 0;
    let i = 0;
    const put = (idx) => {
      const px = idx % w, py = Math.floor(idx / w);
      const y = topDown ? py : h - 1 - py;
      const o = (y * w + px) * 4;
      out[o] = bytes[p + 2]; out[o + 1] = bytes[p + 1]; out[o + 2] = bytes[p]; out[o + 3] = bpp === 32 ? bytes[p + 3] : 255;
    };
    if (type === 2) {
      for (; i < w * h; i++) { put(i); p += bytesPerPixel; }
    } else {
      while (i < w * h) {
        const head = bytes[p++];
        const n = (head & 0x7f) + 1;
        if (head & 0x80) {
          for (let k = 0; k < n && i < w * h; k++, i++) put(i);
          p += bytesPerPixel;
        } else {
          for (let k = 0; k < n && i < w * h; k++, i++) { put(i); p += bytesPerPixel; }
        }
      }
    }
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    c.getContext('2d').putImageData(new ImageData(out, w, h), 0, 0);
    return c;
  }

  function decodePng(bytes) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(new Blob([bytes], { type: 'image/png' }));
      const im = new Image();
      im.onload = () => { URL.revokeObjectURL(url); resolve(im); };
      im.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Не удалось прочитать PNG')); };
      im.src = url;
    });
  }

  async function decodeImage(name, bytes) {
    return name.endsWith('.tga') ? decodeTga(bytes) : decodePng(bytes);
  }

  function loadImg(src) {
    return new Promise((res, rej) => {
      const im = new Image();
      im.onload = () => res(im);
      im.onerror = () => rej(new Error('Не удалось загрузить встроенную текстуру'));
      im.src = src;
    });
  }

  function canvasOf(img) {
    const c = document.createElement('canvas');
    c.width = img.width;
    c.height = img.height;
    const g = c.getContext('2d', { willReadFrequently: true });
    g.drawImage(img, 0, 0);
    return c;
  }

  // Первый кадр 16x16 (анимации лежат вертикальной полосой), с окраской травы и листвы как во встроенном атласе
  function drawTile(ctx, img, ax, ay, tintName) {
    const frame = Math.min(img.width, img.height);
    ctx.clearRect(ax, ay, TILE, TILE);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, 0, 0, frame, frame, ax, ay, TILE, TILE);
    const t = tintName ? blockTint(tintName) : null;
    if (!t) return;
    const id = ctx.getImageData(ax, ay, TILE, TILE);
    const d = id.data;
    for (let i = 0; i < d.length; i += 4) {
      if (t[1] === 'mask') {
        if (d[i + 3] > 0) for (let k = 0; k < 3; k++) d[i + k] = Math.round(d[i + k] * t[0][k] / 255);
        d[i + 3] = 255;
      } else {
        for (let k = 0; k < 3; k++) d[i + k] = Math.round(d[i + k] * t[0][k] / 255);
      }
    }
    ctx.putImageData(id, ax, ay);
  }

  // ---------- Хранилище ----------
  const Store = () => MC.Storage.Packs;

  async function list() { return Store().list(); }

  async function addFile(file) {
    const buf = await file.arrayBuffer();
    const zip = parseZip(buf);
    const manifestName = zip.names.filter((n) => n.endsWith('manifest.json')).sort((a, b) => a.length - b.length)[0];
    let name = file.name.replace(/\.(mcpack|zip)$/i, ''), description = '', uuid = null, version = '';
    if (manifestName) {
      try {
        const m = JSON.parse(new TextDecoder().decode(await zip.read(manifestName)));
        const h = m.header || {};
        name = h.name || name;
        description = h.description || '';
        uuid = h.uuid || null;
        version = Array.isArray(h.version) ? h.version.join('.') : '';
      } catch (e) {
        console.warn('manifest.json не прочитан', e);
      }
    }
    const textures = zip.names.filter((n) => n.includes('textures/') && /\.(png|tga)$/i.test(n)).length;
    const shaders = zip.names.filter((n) => MC.PackShaders.isShaderFile(n)).length;
    if (!textures && !shaders) throw new Error('В архиве нет ни папки textures (PNG/TGA), ни шейдеров (materials, shaders/glsl)');
    // Коды цвета § в названии (и испорченные байты вместо §) не показываем
    const clean = (s) => String(s).replace(/(?:§|\uFFFD)./g, '').trim();
    name = clean(name) || file.name;
    description = clean(description);
    const existing = await Store().list();
    const order = existing.length ? Math.max(...existing.map((p) => p.order || 0)) + 1 : 0;
    const rec = { id: uuid || MC.Storage.uuidv4(), name, description, version, size: file.size, textures, shaders, enabled: true, order, blob: new Blob([buf]) };
    await Store().put(rec);
    return rec;
  }

  async function remove(id) { await Store().remove(id); }

  async function update(rec) { await Store().put(rec); }

  // Отпечаток набора включённых паков: по нему кэшируется результат наложения
  function fingerprint(packs) { return packs.filter((p) => p.enabled).sort((a, b) => a.order - b.order).map((p) => p.id + ':' + p.size).join('|'); }

  // ---------- Наложение на встроенные ресурсы (до инициализации рендера) ----------
  async function apply() {
    let packs;
    try { packs = await Store().list(); } catch (e) { console.warn('Паки недоступны', e); return false; }
    const fp = fingerprint(packs);
    if (!fp) return false;
    let cached = null;
    try { cached = await MC.Storage.kv.get('packs-cache'); } catch (e) { cached = null; }
    if (cached && cached.fp === fp) {
      Object.assign(A, cached.assets);
      return true;
    }
    const assets = await build(packs.filter((p) => p.enabled).sort((a, b) => a.order - b.order));
    Object.assign(A, assets);
    try { await MC.Storage.kv.put('packs-cache', { fp, assets }); } catch (e) { console.warn('Кэш паков не сохранён', e); }
    return true;
  }

  async function build(packs) {
    const blockImg = await loadImg(A.blockAtlas), itemImg = await loadImg(A.itemAtlas);
    const blocks = canvasOf(blockImg), items = canvasOf(itemImg);
    const bctx = blocks.getContext('2d'), ictx = items.getContext('2d');
    const out = {};
    const entity = {};
    const gui = Object.assign({}, A.gui);
    const sky = Object.assign({}, A.sky);
    let destroy = null, steve = null, packShaders = null;
    for (const p of packs) {
      let zip;
      try { zip = parseZip(await p.blob.arrayBuffer()); } catch (e) { console.warn('Пак пропущен', p.name, e); continue; }
      const byPath = new Map();
      for (const n of zip.names) {
        const i = n.indexOf('textures/');
        if (i < 0) continue;
        const rel = n.slice(i + 9).toLowerCase();
        const key = rel.replace(/\.(png|tga)$/i, '');
        // TGA предпочтительнее PNG (как в игре: содержит альфа-канал)
        if (!byPath.has(key) || n.toLowerCase().endsWith('.tga')) byPath.set(key, n);
      }
      const get = async (key) => {
        const n = byPath.get(key);
        if (!n) return null;
        try { return await decodeImage(n.toLowerCase(), await zip.read(n)); } catch (e) { console.warn('Текстура пропущена', n, e.message); return null; }
      };
      for (const [name, idx] of Object.entries(A.blockTiles)) {
        const img = await get('blocks/' + name);
        if (img) drawTile(bctx, img, (idx % A.blockGrid) * TILE, Math.floor(idx / A.blockGrid) * TILE, name);
      }
      for (const [name, idx] of Object.entries(A.itemTiles)) {
        const img = await get('items/' + name);
        if (img) drawTile(ictx, img, (idx % A.itemGrid) * TILE, Math.floor(idx / A.itemGrid) * TILE, null);
      }
      for (const [name, file] of Object.entries(ENTITY_TEX)) {
        const img = await get('entity/' + file);
        if (img) entity[name] = { uri: canvasOf(img).toDataURL(), w: img.width, h: img.height };
      }
      for (const [key, file] of [['gui', 'gui/gui'], ['icons', 'gui/icons'], ['title', 'gui/title'], ['background', 'gui/background']]) {
        const img = await get(file);
        if (img) gui[key] = canvasOf(img).toDataURL();
      }
      for (const [key, file] of [['sun', 'environment/sun'], ['moon', 'environment/moon_phases'], ['clouds', 'environment/clouds']]) {
        const img = await get(file);
        if (img) sky[key] = canvasOf(img).toDataURL();
      }
      const stages = [];
      for (let i = 0; i < 10; i++) stages.push(await get('environment/destroy_stage_' + i));
      if (stages.some(Boolean)) {
        if (!destroy) destroy = canvasOf(await loadImg(A.destroyStages));
        const dctx = destroy.getContext('2d');
        stages.forEach((img, i) => { if (img) drawTile(dctx, img, i * TILE, 0, null); });
      }
      // Шейдеры: берутся из последнего (верхнего по порядку) пака, где они есть
      const shaderNames = zip.names.filter((n) => MC.PackShaders.isShaderFile(n));
      if (shaderNames.length) {
        const files = {};
        for (const n of shaderNames) {
          const rel = MC.PackShaders.relPath(n);
          if (rel) files[rel] = new TextDecoder().decode(await zip.read(n));
        }
        packShaders = { name: p.name, files };
      }
      const steveImg = await get('entity/steve');
      if (steveImg && steveImg.width === 64 && (steveImg.height === 32 || steveImg.height === 64)) steve = steveImg;
    }
    out.blockAtlas = blocks.toDataURL();
    out.itemAtlas = items.toDataURL();
    out.entityTextures = Object.assign({}, A.entityTextures, entity);
    out.gui = gui;
    out.sky = sky;
    if (destroy) out.destroyStages = destroy.toDataURL();
    out.packShaders = packShaders;
    if (steve) {
      const c = canvasOf(steve);
      const d = c.getContext('2d').getImageData(0, 0, 64, steve.height).data;
      out.steveSkin = MC.Skin.toBase64(new Uint8Array(d.buffer));
      out.steveSkinHeight = steve.height;
    }
    return out;
  }

  MC.Packs = { list, addFile, remove, update, apply, parseZip };
})();
