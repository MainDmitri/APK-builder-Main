// Шейдеры из ресурс-паков MCPE 1.x (materials/*.material + shaders/glsl): пак компилируется
// в WebGL, а данные нашего мира подаются в атрибуты и юниформы, которые ждут шейдеры MCPE.
// Используются материалы terrain_alpha_fog (непрозрачные блоки), terrain_blend_fog (вода, лёд)
// и skyplane (небо). Существа, рука и интерфейс рисуются встроенными шейдерами игры.
(function () {
  'use strict';
  const MC = (window.MC = window.MC || {});

  // ---------- Заголовки движка MCPE, которых нет в паке ----------
  const VERSION_COMMON = '#define _centroid\n#define POS4 highp vec4\n#define POS3 highp vec3\n#define MAT4 highp mat4\n';
  const FRAG_PRECISION = '#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n';
  const BUILTIN = {
    'vertexVersionCentroid.h': VERSION_COMMON,
    'vertexVersionCentroidUV.h': VERSION_COMMON,
    'vertexVersionSimple.h': VERSION_COMMON,
    'fragmentVersionCentroid.h': FRAG_PRECISION + VERSION_COMMON,
    'fragmentVersionCentroidUV.h': FRAG_PRECISION + VERSION_COMMON,
    'fragmentVersionSimple.h': FRAG_PRECISION + VERSION_COMMON,
    'uniformMacro.h': '#ifndef _UNIFORM_MACRO_H\n#define _UNIFORM_MACRO_H\n#define UNIFORM uniform\n#define BEGIN_UNIFORM_BLOCK(name)\n#define END_UNIFORM_BLOCK\n#endif\n',
    'uniformPerFrameConstants.h': '#ifndef _UNIFORM_PER_FRAME_CONSTANTS_H\n#define _UNIFORM_PER_FRAME_CONSTANTS_H\n' +
      'uniform vec3 VIEW_POS;\nuniform highp float TIME;\nuniform vec4 FOG_COLOR;\nuniform vec2 FOG_CONTROL;\nuniform float RENDER_DISTANCE;\nuniform float FAR_CHUNKS_DISTANCE;\n#endif\n',
    'uniformWorldConstants.h': '#ifndef _UNIFORM_WORLD_CONSTANTS_H\n#define _UNIFORM_WORLD_CONSTANTS_H\n' +
      'uniform MAT4 WORLDVIEWPROJ;\nuniform MAT4 WORLD;\nuniform MAT4 WORLDVIEW;\nuniform MAT4 PROJ;\n#endif\n',
    'uniformShaderConstants.h': '#ifndef _UNIFORM_SHADER_CONSTANTS_H\n#define _UNIFORM_SHADER_CONSTANTS_H\n' +
      'uniform vec4 CURRENT_COLOR;\nuniform vec4 DARKEN;\nuniform vec3 TEXTURE_DIMENSIONS;\nuniform float HUD_OPACITY;\nuniform MAT4 UV_TRANSFORM;\n#endif\n',
    'uniformRenderChunkConstants.h': '#ifndef _UNIFORM_RENDER_CHUNK_CONSTANTS_H\n#define _UNIFORM_RENDER_CHUNK_CONSTANTS_H\nuniform POS4 CHUNK_ORIGIN_AND_SCALE;\n#endif\n',
    'uniformEntityConstants.h': '#ifndef _UNIFORM_ENTITY_CONSTANTS_H\n#define _UNIFORM_ENTITY_CONSTANTS_H\n' +
      'uniform vec4 OVERLAY_COLOR;\nuniform vec4 TILE_LIGHT_COLOR;\nuniform vec4 CHANGE_COLOR;\nuniform vec4 GLINT_COLOR;\nuniform vec4 UV_ANIM;\nuniform vec2 UV_OFFSET;\nuniform vec2 UV_ROTATION;\nuniform vec2 GLINT_UV_SCALE;\n#endif\n',
    'uniformEffectsConstants.h': '#ifndef _UNIFORM_EFFECTS_CONSTANTS_H\n#define _UNIFORM_EFFECTS_CONSTANTS_H\nuniform vec2 EFFECT_UV_OFFSET;\n#endif\n',
    'uniformWeatherConstants.h': '#ifndef _UNIFORM_WEATHER_CONSTANTS_H\n#define _UNIFORM_WEATHER_CONSTANTS_H\n' +
      'uniform vec4 POSITION_OFFSET;\nuniform vec4 VELOCITY;\nuniform vec4 ALPHA;\nuniform vec4 VIEW_POSITION;\nuniform vec4 SIZE_SCALE;\nuniform vec4 FORWARD;\nuniform vec4 UV_INFO;\nuniform vec4 PARTICLE_BOX;\n#endif\n'
  };

  // ---------- Материалы ----------
  // .material — JSON с комментариями // и /* */ и иногда с лишними запятыми
  function parseLooseJson(text) {
    let out = '', i = 0, inStr = false;
    while (i < text.length) {
      const c = text[i];
      if (inStr) {
        out += c;
        if (c === '\\') { out += text[i + 1] || ''; i += 2; continue; }
        if (c === '"') inStr = false;
        i++;
        continue;
      }
      if (c === '"') { inStr = true; out += c; i++; continue; }
      if (c === '/' && text[i + 1] === '/') { while (i < text.length && text[i] !== '\n') i++; continue; }
      if (c === '/' && text[i + 1] === '*') { const e = text.indexOf('*/', i + 2); i = e < 0 ? text.length : e + 2; continue; }
      out += c;
      i++;
    }
    return JSON.parse(out.replace(/,(\s*[}\]])/g, '$1'));
  }

  function loadMaterials(files) {
    const raw = new Map();
    for (const [path, text] of Object.entries(files)) {
      if (!/^materials\/[^/]+\.material$/i.test(path)) continue;
      let obj;
      try { obj = parseLooseJson(text); } catch (e) { console.warn('Материал не прочитан', path, e.message); continue; }
      for (const [key, def] of Object.entries(obj)) {
        if (!def || typeof def !== 'object') continue;
        const [name, parent] = key.split(':');
        raw.set(name.trim(), { def, parent: parent ? parent.trim() : null });
      }
    }
    const cache = new Map();
    const resolve = (name, depth) => {
      if (cache.has(name)) return cache.get(name);
      const r = raw.get(name);
      if (!r || depth > 16) return null;
      const base = r.parent ? resolve(r.parent, depth + 1) || {} : {};
      const m = Object.assign({}, base, r.def);
      m.defines = [...(base.defines || []), ...(r.def.defines || [])];
      cache.set(name, m);
      return m;
    };
    return (name) => resolve(name, 0);
  }

  // ---------- Исходники шейдеров ----------
  function findFile(files, path) {
    const p = path.replace(/^\/+/, '');
    const base = p.split('/').pop();
    const candidates = [p, p.replace(/^shaders\//, 'shaders/glsl/'), 'shaders/glsl/' + base];
    for (const c of candidates) if (Object.prototype.hasOwnProperty.call(files, c)) return files[c];
    return null;
  }

  function expandIncludes(files, src, seen, depth) {
    if (depth > 12) throw new Error('Слишком глубокие #include');
    return src.replace(/^[ \t]*#include\s+"([^"]+)"[^\n]*$/gm, (m, inc) => {
      const base = inc.split('/').pop();
      const key = inc;
      if (seen.has(key)) return '';
      seen.add(key);
      const text = findFile(files, inc);
      if (text !== null) return expandIncludes(files, text, seen, depth + 1);
      if (BUILTIN[base] !== undefined) return BUILTIN[base];
      throw new Error('Нет файла ' + inc);
    });
  }

  const ATTRS = ['POSITION', 'COLOR', 'TEXCOORD_0', 'TEXCOORD_1'];

  // Атрибуты пака превращаются в обычные глобальные переменные, их заполняет наша main()
  function prepareVertex(src) {
    const has = {};
    src = src.replace(/^[ \t]*attribute\s+((?:(?:highp|mediump|lowp)\s+)?\w+)\s+(\w+)\s*;/gm, (m, type, name) => {
      if (!ATTRS.includes(name)) return m;
      has[name] = true;
      return type + ' ' + name + ';';
    });
    if (!/\bvoid\s+main\s*\(\s*(void)?\s*\)/.test(src)) throw new Error('В вершинном шейдере нет main()');
    src = src.replace(/\bvoid\s+main\s*\(\s*(void)?\s*\)/, 'void pack_main()');
    return { src, has };
  }

  // Эффекты, привязанные к раскладке атласа MCPE 1.2 (номер плитки 32x32), на нашем атласе попадали бы
  // не в те блоки, поэтому отключаются; качание растений и волны воды делает наша main()
  function neutralizeAtlas(src) {
    return src.replace(/floor\s*\(\s*vec2\s*\(\s*(TEXCOORD_0|uv0)\.x\s*\*\s*[\d.]+\s*,\s*\1\.y\s*\*\s*[\d.]+\s*\)\s*\)/g, 'vec2(-100.0)');
  }

  function stripVersion(src) { return src.replace(/^[ \t]*#version[^\n]*$/gm, ''); }

  function build(files, materialName, extraDefines, wrapper) {
    const mat = loadMaterials(files)(materialName);
    if (!mat) throw new Error('В паке нет материала ' + materialName);
    if (!mat.vertexShader || !mat.fragmentShader) throw new Error('У материала ' + materialName + ' нет шейдеров');
    const vsText = findFile(files, mat.vertexShader), fsText = findFile(files, mat.fragmentShader);
    if (vsText === null) throw new Error('Нет файла ' + mat.vertexShader);
    if (fsText === null) throw new Error('Нет файла ' + mat.fragmentShader);
    const defines = [...new Set([...(mat.defines || []), ...extraDefines])].map((d) => '#define ' + d + '\n').join('');
    const vsBody = expandIncludes(files, stripVersion(vsText), new Set(), 0);
    const fsBody = expandIncludes(files, stripVersion(fsText), new Set(), 0);
    const pv = prepareVertex(neutralizeAtlas(vsBody));
    const vs = defines + pv.src + '\n' + wrapper(pv.has);
    const fs = defines + neutralizeAtlas(fsBody);
    return { vs, fs, material: materialName };
  }

  // main() для блоков: декодирует наш a_light в данные вершины MCPE
  const TERRAIN_MAIN = (has) => `
attribute vec3 a_pos;
attribute vec2 a_uv;
attribute float a_light;
void main() {
  float sk = step(63.5, a_light);
  float al = a_light - 64.0 * sk;
  float bl = floor(al / 8.0 + 0.001);
  float rest = al - bl * 8.0;
  float flag = floor(rest / 2.0);
  float lum = rest - flag * 2.0;
  vec3 p = a_pos;
  vec3 w = p + CHUNK_ORIGIN_AND_SCALE.xyz + VIEW_POS;
  if (flag > 0.5 && flag < 1.5) {
    p.x += sin(TIME * 1.4 + w.x * 0.9 + w.z * 0.7 + w.y * 0.4) * 0.035;
    p.z += cos(TIME * 1.1 + w.z * 0.8 + w.x * 0.5) * 0.035;
  } else if (flag > 1.5 && flag < 2.5) {
    p.y += (sin(TIME * 1.8 + w.x * 1.3 + w.z * 0.9) * 0.5 + sin(TIME * 2.6 + w.z * 1.7) * 0.5) * 0.05 - 0.03;
  }
  float ao = clamp(sk > 0.5 ? lum : lum / 0.62, 0.0, 1.0);
  ${has.POSITION ? 'POSITION = vec4(p, 1.0);' : ''}
  ${has.TEXCOORD_0 ? 'TEXCOORD_0 = a_uv;' : ''}
  ${has.TEXCOORD_1 ? 'TEXCOORD_1 = vec2((bl + 0.5) / 16.0, sk > 0.5 ? 0.96875 : 0.65);' : ''}
  ${has.COLOR ? 'COLOR = flag > 1.5 ? vec4(vec3(0.25, 0.42, 0.95) * ao, 1.0) : vec4(vec3(ao), ao);' : ''}
  pack_main();
}`;

  const SKY_MAIN = (has) => `
attribute vec3 a_pos;
void main() {
  ${has.POSITION ? 'POSITION = vec4(a_pos, 1.0);' : ''}
  ${has.COLOR ? 'COLOR = vec4(1.0);' : ''}
  ${has.TEXCOORD_0 ? 'TEXCOORD_0 = a_pos.xz * 0.5 + 0.5;' : ''}
  ${has.TEXCOORD_1 ? 'TEXCOORD_1 = vec2(0.0, 1.0);' : ''}
  pack_main();
}`;

  function compileShader(gl, type, src) {
    const s = gl.createShader(type);
    gl.shaderSource(s, src);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
      const log = gl.getShaderInfoLog(s) || 'неизвестная ошибка';
      gl.deleteShader(s);
      throw new Error((type === gl.VERTEX_SHADER ? 'вершинный' : 'фрагментный') + ' шейдер: ' + log.trim().split('\n').slice(0, 3).join(' | '));
    }
    return s;
  }

  const UNIFORMS = ['WORLDVIEWPROJ', 'WORLD', 'WORLDVIEW', 'PROJ', 'VIEW_POS', 'TIME', 'FOG_COLOR', 'FOG_CONTROL', 'RENDER_DISTANCE', 'FAR_CHUNKS_DISTANCE',
    'CHUNK_ORIGIN_AND_SCALE', 'CURRENT_COLOR', 'DARKEN', 'TEXTURE_DIMENSIONS', 'HUD_OPACITY', 'UV_TRANSFORM', 'TEXTURE_0', 'TEXTURE_1', 'TEXTURE_2',
    'TILE_LIGHT_COLOR', 'OVERLAY_COLOR'];

  function link(gl, p) {
    const prog = gl.createProgram();
    gl.attachShader(prog, compileShader(gl, gl.VERTEX_SHADER, p.vs));
    gl.attachShader(prog, compileShader(gl, gl.FRAGMENT_SHADER, p.fs));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error('сборка программы ' + p.material + ': ' + (gl.getProgramInfoLog(prog) || '').trim());
    const u = {};
    for (const n of UNIFORMS) { const l = gl.getUniformLocation(prog, n); if (l) u[n] = l; }
    return {
      prog, u, material: p.material,
      a: { pos: gl.getAttribLocation(prog, 'a_pos'), uv: gl.getAttribLocation(prog, 'a_uv'), light: gl.getAttribLocation(prog, 'a_light') }
    };
  }

  // Компилирует шейдеры пака; бросает ошибку с понятным текстом, если пак не подходит
  function compile(gl, pack) {
    const files = pack.files;
    const solid = link(gl, build(files, 'terrain_alpha_fog', ['ALPHA_TEST', 'FOG'], TERRAIN_MAIN));
    let trans;
    try { trans = link(gl, build(files, 'terrain_blend_fog', ['BLEND', 'FOG'], TERRAIN_MAIN)); } catch (e) { console.warn('terrain_blend_fog пака', e.message); trans = null; }
    let sky = null;
    try { sky = link(gl, build(files, 'skyplane', [], SKY_MAIN)); } catch (e) { console.warn('skyplane пака', e.message); }
    return { name: pack.name, solid, trans, sky };
  }

  // Файлы шейдеров из zip пака: материалы и всё в shaders/ (пути от корня пака)
  function isShaderFile(n) { return /(^|\/)materials\/[^/]+\.material$/i.test(n) || /(^|\/)shaders\/.+\.(vertex|fragment|h|glsl|vsh|fsh|cspev|cspef|[a-z]+v|[a-z]+f)$/i.test(n); }

  function relPath(n) {
    const m = n.match(/(?:^|\/)((?:materials|shaders)\/.+)$/i);
    return m ? m[1] : null;
  }

  MC.PackShaders = { compile, isShaderFile, relPath, parseLooseJson };
})();
