package com.dmitry.dpibypass

import android.content.Context

const val DEFAULT_DOH_URL = "https://1.1.1.1/dns-query"
const val DEFAULT_SOCKS_PORT = 1080
const val DEFAULT_HTTP_PORT = 8080

/** Параметры фрагментации первого пакета (TLS ClientHello / HTTP-запроса). */
data class FragSettings(
    val fragSize: Int,
    val fragCount: Int,
    val delayMs: Int,
    val splitSni: Boolean,
    val tlsRecordSplit: Boolean,
    val splitHttpHost: Boolean = true
) {
    fun normalized(): FragSettings = copy(
        fragSize = fragSize.coerceIn(1, 64),
        fragCount = fragCount.coerceIn(0, 32),
        delayMs = delayMs.coerceIn(0, 500)
    )
}

enum class Preset(val id: String, val title: String, val description: String) {
    SOFT(
        "soft", "Мягкий",
        "1 байт отдельным пакетом + разрез внутри SNI. Максимальная совместимость."
    ),
    STANDARD(
        "standard", "Стандарт",
        "Разделение TLS-записи по SNI + 1 байт отдельно + разрез SNI, задержка 5 мс."
    ),
    AGGRESSIVE(
        "aggressive", "Агрессивный",
        "Разделение TLS-записи, 8 пакетов по 1 байту, разрез SNI, задержка 20 мс."
    ),
    CUSTOM("custom", "Свой", "Параметры задаются вручную ниже.");

    companion object {
        fun fromId(id: String?): Preset = entries.firstOrNull { it.id == id } ?: STANDARD
    }
}

fun Preset.fragSettings(custom: FragSettings): FragSettings = when (this) {
    Preset.SOFT -> FragSettings(fragSize = 1, fragCount = 1, delayMs = 0, splitSni = true, tlsRecordSplit = false)
    Preset.STANDARD -> FragSettings(fragSize = 1, fragCount = 1, delayMs = 5, splitSni = true, tlsRecordSplit = true)
    Preset.AGGRESSIVE -> FragSettings(fragSize = 1, fragCount = 8, delayMs = 20, splitSni = true, tlsRecordSplit = true)
    Preset.CUSTOM -> custom.normalized()
}

data class ProxyConfig(
    val socksPort: Int = DEFAULT_SOCKS_PORT,
    val httpEnabled: Boolean = true,
    val httpPort: Int = DEFAULT_HTTP_PORT,
    val dohUrl: String = DEFAULT_DOH_URL,
    val preset: Preset = Preset.STANDARD,
    val custom: FragSettings = FragSettings(2, 4, 10, splitSni = true, tlsRecordSplit = true)
) {
    val frag: FragSettings get() = preset.fragSettings(custom)
}

object SettingsStore {
    private const val PREFS = "dpi_bypass_settings"

    fun load(context: Context): ProxyConfig {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val d = ProxyConfig()
        return ProxyConfig(
            socksPort = p.getInt("socks_port", d.socksPort),
            httpEnabled = p.getBoolean("http_enabled", d.httpEnabled),
            httpPort = p.getInt("http_port", d.httpPort),
            dohUrl = p.getString("doh_url", d.dohUrl) ?: d.dohUrl,
            preset = Preset.fromId(p.getString("preset", d.preset.id)),
            custom = FragSettings(
                fragSize = p.getInt("frag_size", d.custom.fragSize),
                fragCount = p.getInt("frag_count", d.custom.fragCount),
                delayMs = p.getInt("delay_ms", d.custom.delayMs),
                splitSni = p.getBoolean("split_sni", d.custom.splitSni),
                tlsRecordSplit = p.getBoolean("tls_record_split", d.custom.tlsRecordSplit)
            ).normalized()
        )
    }

    fun save(context: Context, c: ProxyConfig) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("socks_port", c.socksPort)
            .putBoolean("http_enabled", c.httpEnabled)
            .putInt("http_port", c.httpPort)
            .putString("doh_url", c.dohUrl)
            .putString("preset", c.preset.id)
            .putInt("frag_size", c.custom.fragSize)
            .putInt("frag_count", c.custom.fragCount)
            .putInt("delay_ms", c.custom.delayMs)
            .putBoolean("split_sni", c.custom.splitSni)
            .putBoolean("tls_record_split", c.custom.tlsRecordSplit)
            .apply()
    }
}
