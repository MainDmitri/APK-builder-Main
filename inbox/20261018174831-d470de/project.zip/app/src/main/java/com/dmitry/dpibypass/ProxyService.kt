package com.dmitry.dpibypass

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Foreground-сервис, держащий локальный прокси. */
class ProxyService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Mutex()
    private var engine: ProxyEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopProxy()
            return START_NOT_STICKY
        }
        val config = SettingsStore.load(this)
        // startForeground нужно вызвать сразу, до тяжёлой работы.
        try {
            startInForeground(buildNotification(config))
        } catch (e: Exception) {
            Log.e(TAG, "startForeground не удался", e)
            ProxyState.setError("Не удалось запустить сервис: ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }
        scope.launch {
            lock.withLock {
                engine?.stop()
                engine = null
                val e = ProxyEngine(config)
                try {
                    e.start()
                    engine = e
                    ProxyState.setError(null)
                    ProxyState.setRunning(true)
                } catch (ex: Exception) {
                    Log.e(TAG, "Не удалось запустить прокси", ex)
                    ProxyState.setRunning(false)
                    ProxyState.setError("Не удалось запустить прокси: ${ex.message}")
                    stopForegroundCompat()
                    stopSelf()
                }
            }
        }
        return START_STICKY
    }

    private fun stopProxy() {
        scope.launch {
            lock.withLock {
                engine?.stop()
                engine = null
                ProxyState.setRunning(false)
            }
            stopForegroundCompat()
            stopSelf()
        }
    }

    override fun onDestroy() {
        engine?.stop()
        engine = null
        ProxyState.setRunning(false)
        scope.cancel()
        super.onDestroy()
    }

    private fun startInForeground(notification: Notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun stopForegroundCompat() {
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun buildNotification(config: ProxyConfig): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_LOW
            )
            channel.setShowBadge(false)
            nm.createNotificationChannel(channel)
        }
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ProxyService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = buildString {
            append("SOCKS5 127.0.0.1:").append(config.socksPort)
            if (config.httpEnabled) append(" · HTTP 127.0.0.1:").append(config.httpPort)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openIntent)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .addAction(0, getString(R.string.notif_stop), stopIntent)
            .build()
    }

    companion object {
        private const val TAG = "ProxyService"
        const val ACTION_START = "com.dmitry.dpibypass.START"
        const val ACTION_STOP = "com.dmitry.dpibypass.STOP"
        private const val CHANNEL_ID = "proxy"
        private const val NOTIFICATION_ID = 1080
    }
}
