package com.dmitry.dpibypass

import java.io.OutputStream
import java.util.TreeSet

/**
 * Фрагментация первого пакета соединения в стиле ByeDPI:
 *  - TLS ClientHello режется на несколько TCP-сегментов (первые байты отдельно, разрез внутри SNI);
 *  - опционально ClientHello делится на две TLS-записи (tlsrec) прямо посередине имени хоста,
 *    так что ТСПУ не видит SNI ни в одном отдельном пакете/записи;
 *  - для открытого HTTP запрос режется внутри заголовка Host.
 * Каждая часть пишется отдельным write() на сокет с TCP_NODELAY, между частями — пауза.
 */
object Fragmenter {

    data class Sni(val start: Int, val length: Int)

    fun send(data: ByteArray, out: OutputStream, s: FragSettings) {
        if (data.isEmpty()) return
        var buf = data
        val cuts = TreeSet<Int>()

        if (isTlsHandshake(data)) {
            var sni = findSni(data)
            if (s.tlsRecordSplit) {
                val recordEnd = 5 + recordLength(data)
                val splitAt = if (sni != null && sni.length > 0) sni.start + sni.length / 2
                else minOf(5 + 1, recordEnd - 1)
                if (recordEnd <= data.size && splitAt > 5 && splitAt < recordEnd) {
                    buf = splitTlsRecord(data, splitAt, recordEnd)
                    if (sni != null) {
                        // После вставки второго заголовка (5 байт) позиции после splitAt сдвигаются.
                        val newStart = if (sni.start >= splitAt) sni.start + 5 else sni.start
                        sni = Sni(newStart, sni.length + if (sni.start < splitAt && splitAt < sni.start + sni.length) 5 else 0)
                    }
                    // Разрежем и TCP-поток по границе записей.
                    cuts += splitAt
                }
            }
            addFirstFragments(cuts, s, buf.size)
            if (s.splitSni && sni != null && sni.length > 0) {
                cuts += sni.start + 1
                cuts += sni.start + sni.length / 2
            }
        } else if (s.splitHttpHost && looksLikeHttp(data)) {
            addFirstFragments(cuts, s, buf.size)
            val host = findHttpHost(data)
            if (host != null) {
                cuts += host.start - 4
                cuts += host.start + 1
                cuts += host.start + host.length / 2
            }
        } else {
            out.write(data)
            out.flush()
            return
        }

        var prev = 0
        for (cut in cuts) {
            if (cut <= prev || cut >= buf.size) continue
            out.write(buf, prev, cut - prev)
            out.flush()
            if (s.delayMs > 0) sleep(s.delayMs.toLong())
            prev = cut
        }
        if (prev < buf.size) {
            out.write(buf, prev, buf.size - prev)
            out.flush()
        }
    }

    private fun addFirstFragments(cuts: TreeSet<Int>, s: FragSettings, size: Int) {
        var pos = 0
        repeat(s.fragCount) {
            pos += s.fragSize
            if (pos < size) cuts += pos
        }
    }

    private fun sleep(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    fun isTlsHandshake(d: ByteArray): Boolean =
        d.size >= 6 && d[0].toInt() == 0x16 && d[1].toInt() == 0x03 && d[5].toInt() == 0x01

    fun recordLength(d: ByteArray): Int = ((d[3].toInt() and 0xFF) shl 8) or (d[4].toInt() and 0xFF)

    private fun u8(d: ByteArray, i: Int): Int = d[i].toInt() and 0xFF
    private fun u16(d: ByteArray, i: Int): Int = (u8(d, i) shl 8) or u8(d, i + 1)

    /** Возвращает позицию и длину имени хоста в SNI (абсолютное смещение в буфере) или null. */
    fun findSni(d: ByteArray): Sni? {
        try {
            if (!isTlsHandshake(d)) return null
            val end = minOf(d.size, 5 + recordLength(d))
            var p = 5 + 4          // заголовок записи + тип и длина handshake
            p += 2 + 32            // версия + random
            if (p >= end) return null
            p += 1 + u8(d, p)      // session id
            if (p + 2 > end) return null
            p += 2 + u16(d, p)     // cipher suites
            if (p >= end) return null
            p += 1 + u8(d, p)      // compression methods
            if (p + 2 > end) return null
            val extEnd = minOf(end, p + 2 + u16(d, p))
            p += 2
            while (p + 4 <= extEnd) {
                val type = u16(d, p)
                val len = u16(d, p + 2)
                val body = p + 4
                if (type == 0x0000) {
                    // server_name_list: len(2), name_type(1), name_len(2), name
                    if (body + 5 > extEnd) return null
                    val nameLen = u16(d, body + 3)
                    val nameStart = body + 5
                    if (nameStart + nameLen > extEnd) return null
                    return Sni(nameStart, nameLen)
                }
                p = body + len
            }
        } catch (e: IndexOutOfBoundsException) {
            return null
        }
        return null
    }

    /** Делит первую TLS-запись на две в точке splitAt (абсолютное смещение). */
    private fun splitTlsRecord(d: ByteArray, splitAt: Int, recordEnd: Int): ByteArray {
        val len1 = splitAt - 5
        val len2 = recordEnd - splitAt
        val out = ByteArray(d.size + 5)
        // первая запись
        out[0] = d[0]; out[1] = d[1]; out[2] = d[2]
        out[3] = (len1 shr 8).toByte(); out[4] = len1.toByte()
        System.arraycopy(d, 5, out, 5, len1)
        // вторая запись
        var o = 5 + len1
        out[o] = d[0]; out[o + 1] = d[1]; out[o + 2] = d[2]
        out[o + 3] = (len2 shr 8).toByte(); out[o + 4] = len2.toByte()
        o += 5
        System.arraycopy(d, splitAt, out, o, d.size - splitAt)
        return out
    }

    private val HTTP_METHODS = listOf("GET ", "POST ", "HEAD ", "PUT ", "DELETE ", "OPTIONS ", "PATCH ")

    fun looksLikeHttp(d: ByteArray): Boolean {
        val head = String(d, 0, minOf(d.size, 8), Charsets.ISO_8859_1)
        return HTTP_METHODS.any { head.startsWith(it) }
    }

    /** Позиция значения заголовка Host. */
    fun findHttpHost(d: ByteArray): Sni? {
        val text = String(d, 0, minOf(d.size, 8192), Charsets.ISO_8859_1)
        val idx = Regex("\r\nhost:[ \t]*", RegexOption.IGNORE_CASE).find(text) ?: return null
        val start = idx.range.last + 1
        val end = text.indexOf("\r\n", start).let { if (it < 0) text.length else it }
        if (end <= start) return null
        return Sni(start, end - start)
    }
}
