package com.dmitry.dpibypass

import android.util.Log
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.Proxy
import java.net.URL
import java.net.URLEncoder
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap

/**
 * Резолвер DNS-over-HTTPS (JSON API, application/dns-json).
 * Поддерживает Cloudflare (/dns-query) и Google (/resolve).
 */
class DohResolver(primaryUrl: String) {

    private data class Entry(val addresses: List<InetAddress>, val expiresAt: Long)

    private val urls: List<String> = (listOf(primaryUrl.trim()) + FALLBACK_URLS)
        .filter { it.startsWith("https://") }
        .distinct()

    private val cache = ConcurrentHashMap<String, Entry>()

    @Throws(UnknownHostException::class)
    fun resolve(hostname: String): List<InetAddress> {
        val host = hostname.trim().trimEnd('.').lowercase()
        if (host.isEmpty()) throw UnknownHostException("Пустое имя хоста")
        if (host == "localhost") return listOf(InetAddress.getByName("127.0.0.1"))

        val now = System.currentTimeMillis()
        cache[host]?.let { entry ->
            if (entry.expiresAt > now) return entry.addresses
            cache.remove(host)
        }

        for (url in urls) {
            try {
                var answer = query(url, host, TYPE_A)
                if (answer.status == 3) throw UnknownHostException("NXDOMAIN: $host")
                if (answer.addresses.isEmpty()) answer = query(url, host, TYPE_AAAA)
                if (answer.addresses.isNotEmpty()) {
                    val ttl = answer.ttl.coerceIn(MIN_TTL_SEC, MAX_TTL_SEC)
                    cache[host] = Entry(answer.addresses, System.currentTimeMillis() + ttl * 1000L)
                    if (cache.size > MAX_CACHE) cache.clear()
                    return answer.addresses
                }
                // Ответ пустой — спросим следующий сервер.
            } catch (e: UnknownHostException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "DoH $url не ответил для $host: ${e.message}")
            }
        }

        // Последний шанс — системный DNS (может быть подменён провайдером).
        Log.w(TAG, "DoH недоступен, системный DNS для $host")
        return InetAddress.getAllByName(host).toList()
    }

    private data class Answer(val status: Int, val addresses: List<InetAddress>, val ttl: Int)

    private fun query(base: String, host: String, type: Int): Answer {
        val sep = if (base.contains('?')) "&" else "?"
        val url = URL("$base${sep}name=${URLEncoder.encode(host, "UTF-8")}&type=$type")
        // NO_PROXY: не допускаем петли, если системный прокси указывает на нас самих.
        val conn = url.openConnection(Proxy.NO_PROXY) as HttpURLConnection
        try {
            conn.connectTimeout = TIMEOUT_MS
            conn.readTimeout = TIMEOUT_MS
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("Accept", "application/dns-json")
            val code = conn.responseCode
            if (code != 200) throw java.io.IOException("HTTP $code")
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val json = JSONObject(body)
            val status = json.optInt("Status", 0)
            val list = mutableListOf<InetAddress>()
            var minTtl = Int.MAX_VALUE
            val arr = json.optJSONArray("Answer")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val rec = arr.optJSONObject(i) ?: continue
                    if (rec.optInt("type") != type) continue
                    val data = rec.optString("data").trim()
                    if (!looksLikeIp(data)) continue
                    try {
                        list += InetAddress.getByName(data)
                        minTtl = minOf(minTtl, rec.optInt("TTL", MIN_TTL_SEC))
                    } catch (ignored: Exception) {
                    }
                }
            }
            return Answer(status, list, if (minTtl == Int.MAX_VALUE) MIN_TTL_SEC else minTtl)
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        private const val TAG = "DohResolver"
        private const val TYPE_A = 1
        private const val TYPE_AAAA = 28
        private const val TIMEOUT_MS = 5000
        private const val MIN_TTL_SEC = 30
        private const val MAX_TTL_SEC = 300
        private const val MAX_CACHE = 2000

        val FALLBACK_URLS = listOf(
            "https://1.1.1.1/dns-query",
            "https://8.8.8.8/resolve",
            "https://dns.google/resolve"
        )

        private val IPV4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")
        private val IPV6 = Regex("^[0-9a-fA-F:.]+$")

        fun looksLikeIp(s: String): Boolean =
            IPV4.matches(s) || (s.contains(':') && IPV6.matches(s))
    }
}
