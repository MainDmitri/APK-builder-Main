package com.dahua.checker

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class UserInfo(
    val nickname: String,
    val code: String,
    val activatedAt: Long,
    val deviceId: String = ""
)

object AuthManager {

    // ─── Telegram Serverless Bot endpoints ───
    // После деплоя бота вставь свой URL (формат: https://<bot_username>.t.me/api/)
    private const val TGCLOUD_BASE = "https://YOUR_BOT.t.me/api"

    private const val SECRET_KEY = "MainDmitri_secret_2024_xK9m"

    private const val PREFS_NAME = "ms_auth_x7k"
    private const val KEY_ACTIVATED = "ax_st"
    private const val KEY_NICKNAME = "ax_nk"
    private const val KEY_DEVICE_ID = "ax_did"
    private const val KEY_USERS = "ax_users"

    private val adminPasswordHash: String by lazy {
        sha256hex("MainC4yt552" + "slt_x9k")
    }

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun getDeviceId(context: Context): String {
        return Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            ?: "unknown"
    }

    // ─── Локальное состояние ───

    fun isActivated(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_ACTIVATED, false)
    }

    fun getActiveNickname(context: Context): String {
        return getPrefs(context).getString(KEY_NICKNAME, "") ?: ""
    }

    private fun saveActivation(context: Context, nickname: String, deviceId: String) {
        getPrefs(context).edit()
            .putBoolean(KEY_ACTIVATED, true)
            .putString(KEY_NICKNAME, nickname)
            .putString(KEY_DEVICE_ID, deviceId)
            .apply()
    }

    fun deactivate(context: Context) {
        getPrefs(context).edit()
            .remove(KEY_ACTIVATED)
            .remove(KEY_NICKNAME)
            .remove(KEY_DEVICE_ID)
            .apply()
    }

    fun verifyAdminPassword(password: String): Boolean {
        return sha256hex(password + "slt_x9k") == adminPasswordHash
    }

    // ─── Генерация кода по никнейму (HMAC-SHA256) ───

    private fun generateCodeForNickname(nickname: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(SECRET_KEY.toByteArray(), "HmacSHA256"))
        val hash = mac.doFinal(nickname.trim().lowercase().toByteArray())

        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val sb = StringBuilder()
        for (i in 0 until 12) {
            if (i > 0 && i % 4 == 0) sb.append('-')
            val idx = (hash[i].toInt() and 0xFF) % chars.length
            sb.append(chars[idx])
        }
        return sb.toString()
    }

    // ─── Активация: локальная проверка кода + серверная привязка deviceId ───
    // Result.success(true)  — активировано
    // Result.success(false) — неверный код
    // Result.failure(...)   — код занят другим устройством / ошибка

    fun activate(context: Context, nickname: String, code: String): Result<Boolean> {
        return try {
            val trimmedNick = nickname.trim()
            val expected = generateCodeForNickname(trimmedNick)
            val inputClean = code.trim().uppercase().replace("-", "").replace(" ", "")
            val expectedClean = expected.replace("-", "")

            if (inputClean != expectedClean) {
                return Result.success(false)
            }

            val deviceId = getDeviceId(context)

            // Проверяем через Telegram Serverless бота
            val checkResult = checkDeviceLock(trimmedNick, deviceId, inputClean)

            when (checkResult) {
                "ok" -> {
                    saveActivation(context, trimmedNick, deviceId)
                    // Уведомляем тебя что кто-то активировался
                    notifyActivation(trimmedNick, deviceId)
                    Result.success(true)
                }
                "blocked" -> {
                    Result.failure(Exception("Этот код уже используется на другом устройстве"))
                }
                "offline" -> {
                    // Нет интернета — активируем локально
                    saveActivation(context, trimmedNick, deviceId)
                    Result.success(true)
                }
                else -> {
                    Result.failure(Exception("Ошибка сервера: $checkResult"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─── POST /api/check → { result: "ok" | "blocked" } ───

    private fun checkDeviceLock(nickname: String, deviceId: String, codeClean: String): String {
        return try {
            val url = URL("$TGCLOUD_BASE/check")
            val body = JSONObject().apply {
                put("nickname", nickname)
                put("deviceId", deviceId)
                put("code", codeClean)
            }.toString()

            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray()) }

            val response = conn.inputStream.bufferedReader().readText()
            val json = JSONObject(response)
            json.optString("result", "error")
        } catch (e: java.net.UnknownHostException) {
            "offline"
        } catch (e: java.net.SocketTimeoutException) {
            "offline"
        } catch (e: Exception) {
            "offline"
        }
    }

    // ─── POST /api/notify — уведомление тебе в Telegram ───

    private fun notifyActivation(nickname: String, deviceId: String) {
        try {
            val url = URL("$TGCLOUD_BASE/notify")
            val body = JSONObject().apply {
                put("nickname", nickname)
                put("deviceId", deviceId)
            }.toString()

            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray()) }
            conn.inputStream.close()
        } catch (_: Exception) {
            // Не критично
        }
    }

    // ─── Админ: генерация кода для пользователя ───

    fun generateCode(context: Context, nickname: String): Result<String> {
        return try {
            val trimmed = nickname.trim()
            if (trimmed.isEmpty()) return Result.failure(Exception("Пустой никнейм"))

            val code = generateCodeForNickname(trimmed)
            val users = loadUsers(context).toMutableList()
            val existing = users.indexOfFirst { it.nickname.lowercase() == trimmed.lowercase() }
            if (existing >= 0) return Result.success(users[existing].code)

            users.add(UserInfo(trimmed, code, System.currentTimeMillis()))
            saveUsers(context, users)
            Result.success(code)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getUsers(context: Context): Result<List<UserInfo>> {
        return try {
            Result.success(loadUsers(context))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun deleteUser(context: Context, nickname: String): Result<Boolean> {
        return try {
            val users = loadUsers(context).toMutableList()
            val removed = users.removeAll { it.nickname.lowercase() == nickname.trim().lowercase() }
            if (removed) saveUsers(context, users)
            Result.success(removed)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun loadUsers(context: Context): List<UserInfo> {
        val json = getPrefs(context).getString(KEY_USERS, "[]") ?: "[]"
        val arr = org.json.JSONArray(json)
        val list = mutableListOf<UserInfo>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(UserInfo(
                nickname = obj.getString("nickname"),
                code = obj.getString("code"),
                activatedAt = obj.optLong("createdAt", 0L),
                deviceId = obj.optString("deviceId", "")
            ))
        }
        return list
    }

    private fun saveUsers(context: Context, users: List<UserInfo>) {
        val arr = org.json.JSONArray()
        for (u in users) {
            val obj = JSONObject()
            obj.put("nickname", u.nickname)
            obj.put("code", u.code)
            obj.put("createdAt", u.activatedAt)
            obj.put("deviceId", u.deviceId)
            arr.put(obj)
        }
        getPrefs(context).edit().putString(KEY_USERS, arr.toString()).apply()
    }

    private fun sha256hex(text: String): String {
        return MessageDigest.getInstance("SHA-256")
            .digest(text.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }
}
