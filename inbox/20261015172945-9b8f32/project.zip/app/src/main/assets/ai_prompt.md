Напиши Telegram-бота для платформы Telegram Serverless (tgcloud, https://core.telegram.org/bots/serverless). Дай каждый файл целиком, без сокращений и заглушек, и перед каждым файлом укажи его путь внутри папки tgcloud/ (например, handlers/message.js).

Структура проекта (папка tgcloud/):
- handlers/<тип_апдейта>.js — обработчик апдейта. Имя файла = тип апдейта Bot API: message, edited_message, callback_query, inline_query, chosen_inline_result, pre_checkout_query, shipping_query, my_chat_member, chat_member, chat_join_request, poll, poll_answer, message_reaction, channel_post, business_message и т.д. Подпапок в handlers/ нет.
- lib/… .js — общий код (можно с подпапками), импортируется из обработчиков.
- endpoints/<имя>.js — только если нужен Mini App: функция, которую он вызывает как POST /api/<имя>.
- schema.js — только если нужна база данных: таблицы как именованные экспорты table(...) из 'sdk/db'.

Правила платформы:
1. Код работает в облаке Telegram в изолированном V8, это не Node.js. Нет npm-пакетов, require, fs, process, __dirname, .env. Токен бота не нужен и не должен быть в коде.
2. Только обычный JavaScript (ES-модули, ES2022), не TypeScript: без типов, interface, enum, type.
3. Импорт: SDK по имени — import { api, fetch, InputFile, BotApiError, EndpointError, db } from 'sdk'; import { table, integer, text, eq, sql } from 'sdk/db'. Свои модули — относительным путём С РАСШИРЕНИЕМ .js: import { mainMenu } from '../lib/keyboard.js'. Никаких telegraf, grammy, node-telegram-bot-api, axios, node-fetch.
4. Обработчик — это export default: export default async function (payload, ctx) { … }. payload — содержимое апдейта (для handlers/message — объект Message, для handlers/callback_query — CallbackQuery), полный Update — ctx.update. Эндпоинт — export default async function (input, ctx), проверенные данные Mini App — ctx.initData (ctx.initData.user — пользователь); отказ — throw new EndpointError('текст').
5. Нет polling, bot.launch(), main(), setWebhook. Платформа сама вызывает обработчик на каждый апдейт и сама настраивает вебхук по списку handlers/.
6. Bot API: const result = await api.<метод>({ параметры в snake_case }), например api.sendMessage({ chat_id, text, reply_markup }). Возвращается сразу result. При ошибке бросается BotApiError с полями .code, .description, .parameters.
7. Команды разбирай вручную из message.text, например /^\/start(@\w+)?(\s|$)/ (в группах команда бывает вида /start@имя_бота).
8. Не храни состояние в переменных модуля между апдейтами: каждый вызов может идти в новом экземпляре. Для данных — база: таблицы в schema.js, запросы через db из 'sdk' (всегда await; внешних ключей нет). Деплой не меняет базу — после изменения schema.js нужна миграция (npx tgcloud migrate).
9. HTTP-запросы наружу — только fetch из 'sdk': const res = await fetch(url, { method, headers, body }); res.ok, await res.json().
10. Логи — console.log / console.warn / console.error.
11. Оплата Telegram Stars: api.sendInvoice с currency: 'XTR', provider_token: '', prices: [{ label, amount }]; обязательно handlers/pre_checkout_query.js с await api.answerPreCheckoutQuery({ pre_checkout_query_id: query.id, ok: true }); успешная оплата приходит в handlers/message.js как message.successful_payment.
12. Кнопки callback: handlers/callback_query.js и обязательно await api.answerCallbackQuery({ callback_query_id: query.id }).
13. Все вызовы асинхронные — всегда await.

Пример handlers/message.js:
import { api } from 'sdk';

export default async function (message, ctx) {
  if (typeof message.text !== 'string') return;
  if (/^\/start(@\w+)?(\s|$)/.test(message.text)) {
    await api.sendMessage({ chat_id: message.chat.id, text: 'Привет!' });
  }
}

Задача бота:
