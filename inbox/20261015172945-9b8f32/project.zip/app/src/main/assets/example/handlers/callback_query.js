// handlers/callback_query — нажатия на inline-кнопки.
import { api } from 'sdk';

export default async function (query, ctx) {
  let answer = 'Неизвестная кнопка';
  if (query.data === 'hello') answer = `Привет, ${query.from.first_name}!`;
  if (query.data === 'time') answer = 'Сейчас ' + new Date().toISOString().slice(11, 19) + ' UTC';

  await api.answerCallbackQuery({ callback_query_id: query.id });
  if (query.message) {
    await api.sendMessage({ chat_id: query.message.chat.id, text: answer });
  }
}
