// handlers/message — вызывается на каждое новое сообщение боту.
import { api } from 'sdk';
import { mainMenu } from '../lib/keyboard.js';

export default async function (message, ctx) {
  const text = message.text;
  if (typeof text !== 'string') return;

  if (/^\/start(@\w+)?(\s|$)/.test(text)) {
    await api.sendMessage({
      chat_id: message.chat.id,
      text: `Привет, ${message.from?.first_name ?? 'друг'}! Выберите действие:`,
      reply_markup: mainMenu(),
    });
    return;
  }

  await api.sendMessage({
    chat_id: message.chat.id,
    text: `Вы написали: ${text}`,
    reply_parameters: { message_id: message.message_id },
  });
}
