package com.maindmitri.botpanel

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Ошибка API управления tgcloud со всеми полями ответа сервера. */
class TgCloudException(
    message: String,
    val type: String? = null,
    val code: String? = null,
    val parameters: JSONObject? = null,
    val status: Int? = null,
) : Exception(message) {
    val isRevisionMismatch: Boolean
        get() = type == "REVISION_MISMATCH" || status == 409 || parameters?.opt("current_revision") is Number

    /** Полное описание: текст, тип, код, HTTP-статус, все параметры и лог сервера. */
    fun details(): String = buildString {
        append(message)
        val meta = listOfNotNull(
            type?.let { "тип: $it" },
            code?.let { "код: $it" },
            status?.let { "HTTP $it" },
        )
        if (meta.isNotEmpty()) append("\n").append(meta.joinToString("  "))
        val p = parameters ?: return@buildString
        for (key in p.keys()) {
            if (key == "log") continue
            append("\n").append(key).append(": ").append(TgCloudApi.pretty(p.opt(key)))
        }
        val log = TgCloudApi.formatLogs(p.optJSONArray("log"))
        if (log.isNotEmpty()) {
            append("\n\nЛог сервера:\n").append(log.joinToString("\n"))
        }
    }
}

data class CloudState(val revision: Long?, val modules: Map<String, String>)

data class WebhookInfo(
    val url: String,
    val allowedUpdates: List<String>,
    val pendingUpdates: Int,
    val lastErrorDate: Long?,
    val lastError: String?,
    val expectedUrl: String?,
    val expectedUpdates: List<String>,
    val inSync: Boolean,
)

data class DeployResult(val revision: Long?, val modules: List<String>, val dbChanges: JSONArray?)

data class RunResult(val logs: List<String>, val result: String, val timeMs: Long?, val failed: Boolean, val value: Any? = null)

/** Куда пишется полный журнал запросов и ответов. */
fun interface ApiLog {
    fun write(title: String, body: String)
}

/** Клиент API управления tgcloud — те же запросы, что делает `npx tgcloud` (@tgcloud/cli). */
class TgCloudApi(private val token: String, private val log: ApiLog) {
    private val appId: String = token.substringBefore(':')

    private suspend fun request(method: String, path: String, body: JSONObject? = null): Any? =
        withContext(Dispatchers.IO) {
            val url = "$BASE_URL/$appId/manage$path"
            log.write(
                "→ $method $path",
                "URL: $url\nAuthorization: Bearer $appId:***" +
                    (if (body != null) "\nТело запроса:\n" + forLog(body) else ""),
            )
            val started = System.currentTimeMillis()
            val conn = URL(url).openConnection() as HttpURLConnection
            try {
                conn.requestMethod = method
                conn.connectTimeout = 15_000
                conn.readTimeout = 90_000
                conn.setRequestProperty("Authorization", "Bearer $token")
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("Accept", "application/json")
                if (body != null) {
                    conn.doOutput = true
                    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                }
                val status = conn.responseCode
                val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                val ms = System.currentTimeMillis() - started
                val json = try {
                    JSONObject(text)
                } catch (e: Exception) {
                    log.write("← HTTP $status $method $path ($ms мс)", "Ответ не JSON:\n" + text.ifEmpty { "(пусто)" })
                    throw TgCloudException(
                        "Сервер вернул не JSON (HTTP $status): " + text.take(500).ifEmpty { "пустой ответ" },
                        status = status,
                    )
                }
                log.write("← HTTP $status $method $path ($ms мс)", forLog(json))
                if (!json.optBoolean("ok", false)) {
                    val description = json.optString("description")
                        .ifEmpty { json.optString("error") }
                        .ifEmpty { "Ошибка сервера (HTTP $status)" }
                    val message = if (status == 401 || status == 403) {
                        "Токен отклонён: $description. Возьмите новый: BotFather → бот → Serverless → CLI Access."
                    } else description
                    throw TgCloudException(
                        message,
                        type = json.optString("error_type").ifEmpty { null },
                        code = json.opt("error_code")?.takeIf { it != JSONObject.NULL }?.toString(),
                        parameters = json.optJSONObject("parameters"),
                        status = status,
                    )
                }
                json.opt("result")
            } catch (e: IOException) {
                val msg = "Нет связи с $BASE_URL: ${e.message ?: e.javaClass.simpleName}"
                log.write("✗ $method $path", msg)
                throw TgCloudException(msg)
            } finally {
                conn.disconnect()
            }
        }

    suspend fun getState(): CloudState {
        val r = request("GET", "/get") as? JSONObject ?: JSONObject()
        val modules = linkedMapOf<String, String>()
        r.optJSONObject("canonical_modules")?.let { m ->
            for (key in m.keys()) modules[key] = m.optString(key)
        }
        return CloudState(optLong(r, "revision"), modules)
    }

    /**
     * Деплой (POST /deploy), как `tgcloud push`: `manifest` — полный список модулей
     * (чего в нём нет, сервер удалит), `changed` — исходники изменённых модулей.
     */
    suspend fun deploy(manifest: List<String>, changed: Map<String, String>, expectedRevision: Long?): DeployResult {
        val sources = JSONObject()
        for ((name, code) in changed) sources.put(name, code)
        val body = JSONObject()
            .put("manifest", JSONArray(manifest))
            .put("changed_sources", sources)
        if (expectedRevision != null) body.put("expected_revision", expectedRevision)
        val r = request("POST", "/deploy", body) as? JSONObject ?: JSONObject()
        val deployed = r.optJSONObject("canonical_modules")?.keys()?.asSequence()?.toList() ?: manifest
        return DeployResult(optLong(r, "revision"), deployed.sorted(), r.optJSONArray("db_changes"))
    }

    suspend fun getWebhook(): WebhookInfo = parseWebhook(request("GET", "/webhook") as? JSONObject ?: JSONObject())

    suspend fun syncWebhook(dropPending: Boolean): WebhookInfo {
        val body = JSONObject()
        if (dropPending) body.put("drop_pending_updates", true)
        return parseWebhook(request("POST", "/webhook/sync", body) as? JSONObject ?: JSONObject())
    }

    /** Выполняет модуль в облаке без деплоя (как `tgcloud run`); `sources` — все модули проекта. */
    suspend fun run(module: String, sources: Map<String, String>, args: JSONObject, ctx: JSONObject): RunResult {
        val src = JSONObject()
        for ((name, code) in sources) src.put(name, code)
        val body = JSONObject()
            .put("module", module)
            .put("sources", src)
            .put("args", args)
            .put("ctx", ctx)
        return try {
            val r = request("POST", "/run", body) as? JSONObject ?: JSONObject()
            val value = r.opt("result")
            val failed = value is JSONObject && value.has("__error")
            RunResult(formatLogs(r.optJSONArray("log")), formatValue(value), timeMs(r), failed, value)
        } catch (e: TgCloudException) {
            val p = e.parameters ?: throw e
            RunResult(formatLogs(p.optJSONArray("log")), "Ошибка: " + e.details(), timeMs(p), true)
        }
    }

    private fun timeMs(o: JSONObject): Long? =
        if (o.has("time") && !o.isNull("time")) Math.round(o.optDouble("time") * 1000) else null

    private fun parseWebhook(r: JSONObject): WebhookInfo {
        val expected = r.optJSONObject("expected")
        return WebhookInfo(
            url = r.optString("url"),
            allowedUpdates = strings(r.optJSONArray("allowed_updates")),
            pendingUpdates = r.optInt("pending_update_count", 0),
            lastErrorDate = optLong(r, "last_error_date"),
            lastError = r.optString("last_error_message").ifEmpty { null },
            expectedUrl = expected?.optString("url")?.ifEmpty { null },
            expectedUpdates = strings(expected?.optJSONArray("allowed_updates")),
            inSync = r.optBoolean("in_sync", false),
        )
    }

    companion object {
        const val BASE_URL = "https://cloud.telegram.org"

        private val CODE_MAPS = setOf("canonical_modules", "changed_sources", "sources")

        private fun optLong(o: JSONObject, key: String): Long? =
            if (o.has(key) && !o.isNull(key)) o.optLong(key) else null

        private fun strings(a: JSONArray?): List<String> =
            if (a == null) emptyList() else (0 until a.length()).map { a.optString(it) }

        /** JSON для журнала: всё полностью, кроме исходников модулей — вместо них размер. */
        fun forLog(json: JSONObject): String = (summarize(json) as JSONObject).toString(2)

        private fun summarize(v: Any?): Any? = when (v) {
            is JSONObject -> {
                val out = JSONObject()
                for (key in v.keys()) {
                    val child = v.opt(key)
                    if (key in CODE_MAPS && child is JSONObject) {
                        val sizes = JSONObject()
                        for (m in child.keys()) sizes.put(m, "<код, ${child.optString(m).length} симв.>")
                        out.put(key, sizes)
                    } else {
                        out.put(key, summarize(child))
                    }
                }
                out
            }
            is JSONArray -> JSONArray().also { a -> for (i in 0 until v.length()) a.put(summarize(v.opt(i))) }
            else -> v
        }

        fun pretty(v: Any?): String = when (v) {
            null, JSONObject.NULL -> "null"
            is JSONObject -> v.toString(2)
            is JSONArray -> v.toString(2)
            else -> v.toString()
        }

        /** Полный лог выполнения: тип, время от начала, сообщение, место в коде и прочие поля. */
        fun formatLogs(logs: JSONArray?): List<String> {
            if (logs == null) return emptyList()
            val out = mutableListOf<String>()
            for (i in 0 until logs.length()) {
                val e = logs.optJSONObject(i)
                if (e == null) {
                    out.add(pretty(logs.opt(i)))
                    continue
                }
                val type = when (e.optString("_")) {
                    "log" -> "LOG"
                    "dbg" -> "DBG"
                    "inf" -> "INF"
                    "wrn" -> "WRN"
                    "err" -> "ERR"
                    else -> e.optString("_").uppercase().ifEmpty { "LOG" }
                }
                val t = if (e.has("t")) "+" + Math.round(e.optDouble("t") * 1000) + "мс " else ""
                val msg = if (e.has("M")) e.optString("M") + " …[обрезано сервером]" else e.optString("m")
                val origin = when (val o = e.opt("o")) {
                    is String -> o
                    is JSONObject -> listOfNotNull(o.opt("m") ?: o.opt("module"), o.opt("l") ?: o.opt("line"))
                        .joinToString(":")
                    else -> ""
                }
                val line = StringBuilder("$type $t$msg")
                if (origin.isNotEmpty()) line.append("  [").append(origin).append("]")
                for (key in e.keys()) {
                    if (key in setOf("_", "t", "m", "M", "o")) continue
                    line.append("\n    ").append(key).append(": ").append(pretty(e.opt(key)))
                }
                out.add(line.toString())
            }
            return out
        }

        fun formatValue(v: Any?): String = when {
            v == null || v == JSONObject.NULL -> "undefined"
            v is JSONObject && v.has("__error") -> "Ошибка: " + v.optString("message") +
                (v.optString("stack").ifEmpty { null }?.let { "\n$it" } ?: "") +
                (v.keys().asSequence().filter { it !in setOf("__error", "message", "stack") }
                    .joinToString("") { "\n$it: " + pretty(v.opt(it)) })
            else -> pretty(v)
        }
    }
}
