package com.maindmitri.botpanel

import android.content.Context
import java.io.File

/**
 * Настройки — в SharedPreferences, модули проекта — файлами во внутренней памяти
 * (files/tgcloud/handlers/message.js и т.д., как папка tgcloud/ у CLI).
 */
class Storage(private val context: Context) {
    private val prefs = context.getSharedPreferences("bot_panel", Context.MODE_PRIVATE)
    private val root = File(context.filesDir, "tgcloud")
    private val legacyBotFile = File(context.filesDir, "bot.js")

    var token: String
        get() = prefs.getString(KEY_TOKEN, "") ?: ""
        set(value) = prefs.edit().putString(KEY_TOKEN, value).apply()

    var testUserId: String
        get() = prefs.getString(KEY_TEST_USER, "") ?: ""
        set(value) = prefs.edit().putString(KEY_TEST_USER, value).apply()

    var testText: String
        get() = prefs.getString(KEY_TEST_TEXT, "/start") ?: "/start"
        set(value) = prefs.edit().putString(KEY_TEST_TEXT, value).apply()

    var runModule: String
        get() = prefs.getString(KEY_RUN_MODULE, "handlers/message") ?: "handlers/message"
        set(value) = prefs.edit().putString(KEY_RUN_MODULE, value).apply()

    var runArgs: String
        get() = prefs.getString(KEY_RUN_ARGS, "") ?: ""
        set(value) = prefs.edit().putString(KEY_RUN_ARGS, value).apply()

    var runCtx: String
        get() = prefs.getString(KEY_RUN_CTX, "{}") ?: "{}"
        set(value) = prefs.edit().putString(KEY_RUN_CTX, value).apply()

    /** Все модули проекта. Старый bot.js (однофайловый режим) один раз раскладывается в модули. */
    fun loadModules(): Map<String, String> {
        val modules = sortedMapOf<String, String>()
        if (root.isDirectory) {
            root.walkTopDown().filter { it.isFile && it.name.endsWith(".js") }.forEach { f ->
                val name = f.relativeTo(root).invariantSeparatorsPath.removeSuffix(".js")
                if (Project.checkName(name) == null) modules[name] = f.readText()
            }
        }
        if (modules.isEmpty() && legacyBotFile.exists()) {
            val legacy = legacyBotFile.readText()
            SingleFile.split(legacy)?.forEach { (name, code) ->
                saveModule(name, code)
                modules[name] = code
            }
            legacyBotFile.delete()
        }
        return modules
    }

    fun saveModule(name: String, code: String) {
        require(Project.checkName(name) == null) { "Недопустимое имя модуля: $name" }
        val f = File(root, "$name.js")
        f.parentFile?.mkdirs()
        f.writeText(code)
    }

    fun deleteModule(name: String) {
        require(Project.checkName(name) == null) { "Недопустимое имя модуля: $name" }
        var f: File? = File(root, "$name.js")
        f?.delete()
        // Убираем опустевшие папки до корня проекта.
        f = f?.parentFile
        while (f != null && f != root && f.isDirectory && f.list().isNullOrEmpty()) {
            f.delete()
            f = f.parentFile
        }
    }

    fun replaceAll(modules: Map<String, String>) {
        root.deleteRecursively()
        modules.forEach { (name, code) -> saveModule(name, code) }
    }

    fun asset(name: String): String = context.assets.open(name).bufferedReader(Charsets.UTF_8).use { it.readText() }

    private companion object {
        const val KEY_TOKEN = "cli_token"
        const val KEY_TEST_USER = "test_user_id"
        const val KEY_TEST_TEXT = "test_text"
        const val KEY_RUN_MODULE = "run_module"
        const val KEY_RUN_ARGS = "run_args"
        const val KEY_RUN_CTX = "run_ctx"
    }
}

private val TOKEN_FORMAT = Regex("^app\\d+:\\S+$")

fun validateToken(token: String): String? =
    if (TOKEN_FORMAT.matches(token.trim())) null
    else "Укажите CLI-токен вида app<id>:<secret> (BotFather → бот → Serverless → CLI Access → Access token)"
