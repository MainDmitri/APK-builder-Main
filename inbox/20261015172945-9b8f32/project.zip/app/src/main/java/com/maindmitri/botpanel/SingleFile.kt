package com.maindmitri.botpanel

/**
 * Старый однофайловый формат Bot Panel: один bot.js, где обработчики — именованные экспорты
 * (`export async function message(msg, ctx)`). Раскладывается в модули handlers/<тип>:
 * каждый получает весь код файла без слов export и строку `export default <тип>;`.
 */
object SingleFile {
    private val EXPORT_FUNCTION = Regex("""(?m)^\s*export\s+(?:async\s+)?function\s*\*?\s*([A-Za-z_$][\w$]*)""")
    private val EXPORT_VARIABLE = Regex("""(?m)^\s*export\s+(?:const|let|var)\s+([A-Za-z_$][\w$]*)""")
    private val EXPORT_LIST = Regex("""(?m)^\s*export\s*\{([^}]*)\}\s*;?""")
    private val EXPORT_DEFAULT = Regex("""\bexport\s+default\b""")
    private val EXPORT_PREFIX = Regex("""(?m)^(\s*)export\s+(?=(?:async\s+)?function\b|(?:const|let|var)\b)""")
    private val IDENTIFIER = Regex("""^[A-Za-z_$][\w$]*$""")

    /** Модули handlers/<тип>, если файл в однофайловом формате; иначе null. */
    fun split(source: String): Map<String, String>? {
        val code = Project.blank(source).text
        if (EXPORT_DEFAULT.containsMatchIn(code)) return null
        val names = LinkedHashSet<String>()
        EXPORT_FUNCTION.findAll(code).forEach { names.add(it.groupValues[1]) }
        EXPORT_VARIABLE.findAll(code).forEach { names.add(it.groupValues[1]) }
        EXPORT_LIST.findAll(code).forEach { m -> aliases(m.groupValues[1]).forEach { names.add(it.first) } }
        val handlers = names.filter { it in Project.UPDATE_TYPES }
        if (handlers.isEmpty()) return null
        val base = toLocalScope(source)
        return handlers.associate { h ->
            "handlers/$h" to "// Сгенерировано Bot Panel из однофайлового bot.js\n$base\nexport default $h;\n"
        }
    }

    /** Разбирает содержимое `export { ... }` в пары (экспортируемое имя, локальное имя). */
    private fun aliases(body: String): List<Pair<String, String>> =
        body.split(',').map { it.trim() }.filter { it.isNotEmpty() }.mapNotNull { part ->
            val seg = part.split(Regex("\\s+as\\s+"))
            val local = seg.first().trim()
            val exported = seg.last().trim()
            if (IDENTIFIER.matches(local) && IDENTIFIER.matches(exported)) exported to local else null
        }

    /** Убирает `export` у объявлений и строки `export { ... }`, добавляя мостики для псевдонимов. */
    private fun toLocalScope(source: String): String {
        val bridges = StringBuilder()
        val withoutLists = EXPORT_LIST.replace(source) { m ->
            for ((exported, local) in aliases(m.groupValues[1])) {
                if (exported != local) bridges.append("const ").append(exported).append(" = ").append(local).append(";\n")
            }
            ""
        }
        val stripped = EXPORT_PREFIX.replace(withoutLists) { it.groupValues[1] }
        return stripped.trimEnd() + "\n" + bridges
    }
}
