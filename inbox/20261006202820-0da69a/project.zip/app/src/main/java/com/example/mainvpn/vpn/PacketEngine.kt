package com.example.mainvpn.vpn

import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.InetAddress
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/** Потокобезопасная запись IP-пакетов в TUN. */
class TunWriter(private val out: FileOutputStream) {
    @Volatile var closed = false

    fun write(packet: ByteArray) {
        if (closed) return
        synchronized(this) {
            try {
                out.write(packet)
            } catch (e: IOException) {
                // Интерфейс закрыт при остановке туннеля — пакет просто не доставляется.
            }
        }
    }
}

/**
 * Читает пакеты из TUN и раздаёт их TCP-стеку и обработчику UDP.
 * «Заморозка» останавливает чтение интерфейса: пакеты приложений никуда не уходят
 * (используется при загрузке Tor, смене сети, разрыве цепочки и аварийной блокировке).
 */
class PacketEngine(
    private val pfd: ParcelFileDescriptor,
    socksPort: () -> Int,
    dnsPort: () -> Int,
    dnsProtection: () -> Boolean,
    systemDns: () -> List<InetAddress>,
    private val onFatal: (String) -> Unit
) {
    companion object {
        const val MTU = 1500
        const val ADDRESS_V4 = "172.19.0.1"
        const val ADDRESS_V6 = "fd66:6d61:696e::1"
        const val DNS_V4 = "172.19.0.53"
        val VIRTUAL_DNS: ByteArray = byteArrayOf(172.toByte(), 19, 0, 53)
    }

    private val input = FileInputStream(pfd.fileDescriptor)
    private val writer = TunWriter(FileOutputStream(pfd.fileDescriptor))
    val counters = TrafficCounters()
    private val tcp = TcpStack(writer, socksPort) { dst, _ -> dst.contentEquals(VIRTUAL_DNS) }
    private val udp = UdpHandler(writer, dnsPort, dnsProtection, systemDns, counters)

    private val freezeLock = ReentrantLock()
    private val unfrozen = freezeLock.newCondition()
    @Volatile private var frozen = true
    @Volatile private var running = false
    private var thread: Thread? = null

    val isFrozen: Boolean get() = frozen
    val tcpSessions: Int get() = tcp.sessionCount

    fun start() {
        running = true
        thread = Thread({ readLoop() }, "tun-reader").apply {
            isDaemon = true
            start()
        }
    }

    fun setFrozen(value: Boolean) {
        freezeLock.withLock {
            frozen = value
            if (!value) unfrozen.signalAll()
        }
    }

    private fun readLoop() {
        val buf = ByteArray(32767)
        while (running) {
            freezeLock.withLock {
                while (running && frozen) unfrozen.await(1, TimeUnit.SECONDS)
            }
            if (!running) break
            val n = try {
                input.read(buf)
            } catch (e: IOException) {
                if (running) onFatal("Ошибка чтения TUN: ${e.message}")
                break
            }
            if (n < 0) {
                if (running) onFatal("Интерфейс TUN закрыт системой")
                break
            }
            if (n == 0) continue
            val p = IpPacket.parse(buf, n) ?: continue
            when (p.protocol) {
                IpPacket.PROTO_TCP -> tcp.handle(p, buf)
                IpPacket.PROTO_UDP -> udp.handle(p, buf)
            }
        }
    }

    fun stop() {
        running = false
        setFrozen(false)
        tcp.shutdown()
        udp.shutdown()
        writer.closed = true
        runCatching { pfd.close() }
        thread?.interrupt()
    }
}
