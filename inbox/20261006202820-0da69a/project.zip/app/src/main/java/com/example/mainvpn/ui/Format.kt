package com.example.mainvpn.ui

import androidx.compose.ui.graphics.Color
import com.example.mainvpn.core.ConnState
import com.example.mainvpn.ui.theme.StatusConnected
import com.example.mainvpn.ui.theme.StatusConnecting
import com.example.mainvpn.ui.theme.StatusError
import com.example.mainvpn.ui.theme.StatusOff
import java.util.Locale

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes Б"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format(Locale.US, "%.1f КБ", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format(Locale.US, "%.1f МБ", mb)
    return String.format(Locale.US, "%.2f ГБ", mb / 1024.0)
}

fun formatRate(bytesPerSecond: Long): String = formatBytes(bytesPerSecond) + "/с"

fun stateColor(state: ConnState): Color = when (state) {
    ConnState.OFF -> StatusOff
    ConnState.CONNECTING, ConnState.UPDATING -> StatusConnecting
    ConnState.CONNECTED -> StatusConnected
    ConnState.ERROR -> StatusError
}

fun stateTitle(state: ConnState): String = when (state) {
    ConnState.OFF -> "Отключено"
    ConnState.CONNECTING -> "Подключение…"
    ConnState.CONNECTED -> "Защищено"
    ConnState.UPDATING -> "Обновление цепочки…"
    ConnState.ERROR -> "Ошибка"
}

fun formatFingerprint(fp: String): String = fp.chunked(4).joinToString(" ")
