package com.example.mainvpn.core

import android.content.Context
import java.io.File
import java.io.FileOutputStream

/**
 * Общий журнал событий. Пишут оба процесса (UI и :vpn) в режиме дозаписи,
 * поэтому файл открывается заново на каждую запись.
 */
object LogFile {

    private const val MAX_BYTES = 1_000_000L
    private const val MAX_LINES_READ = 5000

    private fun dir(context: Context): File = File(context.filesDir, "logs").apply { mkdirs() }

    private fun current(context: Context): File = File(dir(context), "mainvpn.log")

    private fun previous(context: Context): File = File(dir(context), "mainvpn.old.log")

    @Synchronized
    fun append(context: Context, lines: List<LogLine>) {
        if (lines.isEmpty()) return
        val file = current(context)
        if (file.length() > MAX_BYTES) {
            val old = previous(context)
            old.delete()
            file.renameTo(old)
        }
        FileOutputStream(file, true).bufferedWriter(Charsets.UTF_8).use { writer ->
            for (line in lines) {
                writer.write(line.encode())
                writer.write("\n")
            }
        }
    }

    fun readAll(context: Context): List<LogLine> {
        val result = ArrayList<LogLine>()
        for (file in listOf(previous(context), current(context))) {
            if (!file.exists()) continue
            file.bufferedReader(Charsets.UTF_8).useLines { seq ->
                seq.forEach { raw -> LogLine.decode(raw)?.let { result.add(it) } }
            }
        }
        return if (result.size > MAX_LINES_READ) result.takeLast(MAX_LINES_READ) else result
    }

    @Synchronized
    fun clear(context: Context) {
        previous(context).delete()
        current(context).delete()
    }
}
