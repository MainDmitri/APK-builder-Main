package com.example.mainvpn.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mainvpn.core.ConnState
import com.example.mainvpn.core.Countries
import com.example.mainvpn.core.HopRole
import com.example.mainvpn.core.RelayInfo
import com.example.mainvpn.core.VpnStatus
import com.example.mainvpn.data.AppSettings
import com.example.mainvpn.ui.theme.StatusConnected
import com.example.mainvpn.ui.theme.StatusOff

@Composable
fun CircuitScreen(
    status: VpnStatus,
    settings: AppSettings,
    countries: CountryListState,
    onLoadCountries: (Boolean) -> Unit,
    onSelectCountry: (String) -> Unit,
    onRebuild: () -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(status.state) {
        if (status.state == ConnState.CONNECTED) onLoadCountries(false)
    }
    var selected by remember { mutableIntStateOf(2) }
    var showCountries by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        if (status.circuit.size < 3) {
            Card(Modifier.fillMaxWidth()) {
                Text(
                    text = if (status.state == ConnState.CONNECTED) "Чтение текущей цепочки из Tor…"
                    else "Цепочка появится после подключения к Tor",
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            Text("Нажмите на узел, чтобы увидеть подробности", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            CircuitGraph(
                hops = status.circuit,
                selected = selected,
                active = status.state == ConnState.CONNECTED,
                onSelect = { selected = it }
            )
            Spacer(Modifier.height(12.dp))
            NodeDetails(status.circuit[selected.coerceIn(0, status.circuit.lastIndex)])
        }

        Spacer(Modifier.height(16.dp))
        Text("Страна выходного узла", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        OutlinedCard(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showCountries = true }
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (settings.exitCountry.isEmpty()) "🎲  Автоматически / Случайно"
                    else "${Countries.flag(settings.exitCountry)}  ${Countries.name(settings.exitCountry)}",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f)
                )
                Text("Изменить", color = MaterialTheme.colorScheme.primary)
            }
        }
        Text(
            text = "Выбор записывает в конфигурацию Tor ExitNodes (выходные узлы страны) и StrictNodes 1, затем перестраивает цепочку.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 6.dp)
        )

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = onRebuild,
            enabled = status.state == ConnState.CONNECTED,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Filled.Refresh, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Перестроить цепочку")
        }
    }

    if (showCountries) {
        CountryDialog(
            current = settings.exitCountry,
            countries = countries,
            connected = status.state == ConnState.CONNECTED,
            onReload = { onLoadCountries(true) },
            onSelect = {
                showCountries = false
                onSelectCountry(it)
            },
            onDismiss = { showCountries = false }
        )
    }
}

@OptIn(ExperimentalTextApi::class)
@Composable
private fun CircuitGraph(hops: List<RelayInfo>, selected: Int, active: Boolean, onSelect: (Int) -> Unit) {
    val measurer = rememberTextMeasurer()
    val transition = rememberInfiniteTransition(label = "flow")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 40f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val surface = MaterialTheme.colorScheme.surface
    val linkColor = if (active) StatusConnected else StatusOff
    val labels = listOf("Вы") + hops.map {
        when (it.role) {
            HopRole.GUARD -> if (it.isBridge) "Мост" else "Вход"
            HopRole.MIDDLE -> "Реле"
            HopRole.EXIT -> "Выход"
        }
    } + listOf("Сеть")
    val flags = listOf("📱") + hops.map { if (it.countryCode.isNotEmpty()) Countries.flag(it.countryCode) else "🌐" } + listOf("🌍")

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .pointerInput(hops) {
                detectTapGestures { tap ->
                    val step = size.width / 5f
                    val index = (tap.x / step).toInt() - 1
                    if (index in hops.indices) onSelect(index)
                }
            }
    ) {
        val step = size.width / 5f
        val cy = size.height * 0.42f
        val nodeRadius = minOf(step * 0.32f, 26.dp.toPx())
        val centers = (0 until 5).map { Offset(step * it + step / 2f, cy) }

        for (i in 0 until 4) {
            drawLine(
                color = linkColor,
                start = centers[i],
                end = centers[i + 1],
                strokeWidth = 3.dp.toPx(),
                pathEffect = if (active) PathEffect.dashPathEffect(floatArrayOf(14f, 10f), -phase) else null
            )
        }
        centers.forEachIndexed { i, c ->
            val isHop = i in 1..hops.size
            val isSelected = isHop && i - 1 == selected
            drawCircle(surface, nodeRadius, c)
            drawCircle(
                color = if (isHop) primary else onSurface.copy(alpha = 0.5f),
                radius = nodeRadius,
                center = c,
                style = Stroke(width = if (isSelected) 5.dp.toPx() else 2.dp.toPx())
            )
            val flagLayout = measurer.measure(flags[i], TextStyle(fontSize = 18.sp))
            drawText(
                flagLayout,
                topLeft = Offset(c.x - flagLayout.size.width / 2f, c.y - flagLayout.size.height / 2f)
            )
            val labelLayout = measurer.measure(
                labels[i],
                TextStyle(
                    fontSize = 12.sp,
                    color = if (isSelected) primary else onSurface,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            )
            drawText(
                labelLayout,
                topLeft = Offset(c.x - labelLayout.size.width / 2f, c.y + nodeRadius + 6.dp.toPx())
            )
        }
    }
}

@Composable
private fun NodeDetails(hop: RelayInfo) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(
                text = when (hop.role) {
                    HopRole.GUARD -> if (hop.isBridge) "Входной узел (мост)" else "Входной узел (Guard)"
                    HopRole.MIDDLE -> "Промежуточное реле (Middle)"
                    HopRole.EXIT -> "Выходной узел (Exit)"
                },
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(8.dp))
            InfoRow("Имя", hop.nickname.ifEmpty { "—" })
            InfoRow("IP-адрес", if (hop.ip.isNotEmpty()) "${hop.ip}:${hop.orPort}" else "—")
            InfoRow(
                "Геолокация",
                if (hop.countryCode.isNotEmpty()) "${Countries.flag(hop.countryCode)} ${Countries.name(hop.countryCode)}"
                else if (hop.isBridge) "не публикуется для мостов" else "—"
            )
            InfoRow(
                "Задержка",
                when (hop.role) {
                    HopRole.GUARD -> if (hop.latencyMs >= 0) "${hop.latencyMs} мс (TCP до узла)" else "не измерена"
                    HopRole.MIDDLE -> "не измеряется"
                    HopRole.EXIT -> if (hop.latencyMs >= 0) "${hop.latencyMs} мс (вся цепочка)" else "—"
                }
            )
            if (hop.role == HopRole.MIDDLE) {
                Text(
                    "Прямой пинг промежуточного узла раскрыл бы вашу цепочку провайдеру, поэтому он не выполняется.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Spacer(Modifier.height(6.dp))
            HorizontalDivider()
            Spacer(Modifier.height(6.dp))
            Text("Отпечаток", style = MaterialTheme.typography.labelMedium)
            Text(formatFingerprint(hop.fingerprint), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun CountryDialog(
    current: String,
    countries: CountryListState,
    connected: Boolean,
    onReload: () -> Unit,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val codes: List<String> = if (countries.counts.isNotEmpty()) {
        countries.counts.entries.sortedByDescending { it.value }.map { it.key }
    } else {
        Countries.common
    }
    val filtered = codes.filter {
        query.isBlank() || Countries.name(it).contains(query, ignoreCase = true) || it.contains(query, ignoreCase = true)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Страна выхода") },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    placeholder = { Text("Поиск страны") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = when {
                        countries.loading -> "Загрузка списка выходных узлов из Onionoo…"
                        countries.error.isNotEmpty() -> "Ошибка загрузки: ${countries.error}"
                        countries.counts.isNotEmpty() -> "Страны с работающими выходными узлами: ${countries.counts.size}"
                        connected -> "Список ещё не загружен"
                        else -> "Подключитесь, чтобы загрузить актуальный список"
                    },
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(6.dp))
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    item {
                        CountryRow("🎲", "Автоматически / Случайно", "", current.isEmpty()) { onSelect("") }
                    }
                    items(filtered, key = { it }) { code ->
                        val count = countries.counts[code]
                        CountryRow(
                            flag = Countries.flag(code),
                            name = Countries.name(code),
                            extra = if (count != null) "$count узл." else "",
                            selected = code == current
                        ) { onSelect(code) }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Закрыть") }
        },
        dismissButton = {
            if (connected) TextButton(onClick = onReload) { Text("Обновить список") }
        }
    )
}

@Composable
private fun CountryRow(flag: String, name: String, extra: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(flag, modifier = Modifier.width(32.dp))
        Text(name, modifier = Modifier.weight(1f))
        if (extra.isNotEmpty()) {
            Text(extra, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(end = 8.dp))
        }
        if (selected) Icon(Icons.Filled.Check, contentDescription = "Выбрано", tint = MaterialTheme.colorScheme.primary)
    }
}
