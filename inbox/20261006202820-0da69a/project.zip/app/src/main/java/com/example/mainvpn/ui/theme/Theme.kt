package com.example.mainvpn.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Primary = Color(0xFF1565C0)
val StatusConnected = Color(0xFF2E7D32)
val StatusConnecting = Color(0xFFF9A825)
val StatusError = Color(0xFFC62828)
val StatusOff = Color(0xFF9E9E9E)

private val LightColors = lightColorScheme(
    primary = Primary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD3E3FD),
    onPrimaryContainer = Color(0xFF001C3B),
    secondary = Color(0xFF455A64),
    error = StatusError
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9CC2FF),
    onPrimary = Color(0xFF003063),
    primaryContainer = Primary,
    onPrimaryContainer = Color.White,
    secondary = Color(0xFFB0BEC5),
    error = Color(0xFFFF8A80)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}
