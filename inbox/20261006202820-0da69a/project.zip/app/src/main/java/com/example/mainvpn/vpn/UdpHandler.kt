package com.example.mainvpn.vpn

import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

class TrafficCounters {
    val udpBlocked = AtomicLong()
    val dnsViaTor = AtomicLong()
    val dnsDirect = AtomicLong()
}

/**
 * UDP из туннеля. Tor передаёт только TCP, поэтому:
 * • DNS (порт 53) перехватывается: при защите от утечек — в DNSPort Tor, иначе — напрямую на DNS провайдера;
 * • весь остальной UDP (QUIC, STUN/WebRTC и т. п.) отбрасывается, чтобы он не шёл мимо Tor.
 */
class UdpHandler(
    private val tun: TunWriter,
    private val dnsPort: () -> Int,
    private val dnsProtection: () -> Boolean,
    private val systemDns: () -> List<InetAddress>,
    private val counters: TrafficCounters
) {
    private val loopback: InetAddress = InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1))

    private val pool = ThreadPoolExecutor(
        2, 32, 30, TimeUnit.SECONDS, LinkedBlockingQueue(512),
        { r -> Thread(null, r, "dns", 128 * 1024).apply { isDaemon = true } },
        ThreadPoolExecutor.DiscardPolicy()
    )

    fun handle(p: IpPacket.Parsed, buf: ByteArray) {
        val off = p.payloadOffset
        if (p.payloadEnd - off < 8) return
        val srcPort = IpPacket.u16(buf, off)
        val dstPort = IpPacket.u16(buf, off + 2)
        val udpLen = IpPacket.u16(buf, off + 4)
        val payloadStart = off + 8
        val payloadLen = minOf(udpLen - 8, p.payloadEnd - payloadStart)
        if (payloadLen <= 0) return
        if (dstPort != 53) {
            counters.udpBlocked.incrementAndGet()
            return
        }
        val query = buf.copyOfRange(payloadStart, payloadStart + payloadLen)
        pool.execute { resolve(p.src, srcPort, p.dst, query) }
    }

    private fun resolve(client: ByteArray, clientPort: Int, server: ByteArray, query: ByteArray) {
        val target = if (dnsProtection()) {
            val port = dnsPort()
            if (port <= 0) return
            counters.dnsViaTor.incrementAndGet()
            InetSocketAddress(loopback, port)
        } else {
            val address = if (server.contentEquals(PacketEngine.VIRTUAL_DNS)) {
                systemDns().firstOrNull() ?: return
            } else {
                InetAddress.getByAddress(server)
            }
            counters.dnsDirect.incrementAndGet()
            InetSocketAddress(address, 53)
        }
        try {
            DatagramSocket().use { socket ->
                socket.soTimeout = 10_000
                socket.send(DatagramPacket(query, query.size, target))
                val resp = ByteArray(4096)
                val packet = DatagramPacket(resp, resp.size)
                socket.receive(packet)
                tun.write(IpPacket.buildUdp(server, client, 53, clientPort, resp, 0, packet.length))
            }
        } catch (e: IOException) {
            // Нет ответа резолвера — приложение повторит запрос само.
        }
    }

    fun shutdown() {
        pool.shutdownNow()
    }
}
