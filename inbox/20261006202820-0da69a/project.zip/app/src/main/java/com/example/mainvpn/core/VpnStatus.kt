package com.example.mainvpn.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class ConnState { OFF, CONNECTING, CONNECTED, UPDATING, ERROR }

enum class HopRole { GUARD, MIDDLE, EXIT }

data class RelayInfo(
    val role: HopRole,
    val fingerprint: String,
    val nickname: String,
    val ip: String,
    val orPort: Int,
    val countryCode: String,
    val isBridge: Boolean,
    val latencyMs: Long
) {
    fun toJson(): JSONObject = JSONObject()
        .put("role", role.name)
        .put("fp", fingerprint)
        .put("nick", nickname)
        .put("ip", ip)
        .put("port", orPort)
        .put("cc", countryCode)
        .put("bridge", isBridge)
        .put("lat", latencyMs)

    companion object {
        fun fromJson(o: JSONObject) = RelayInfo(
            role = HopRole.entries.firstOrNull { it.name == o.optString("role") } ?: HopRole.MIDDLE,
            fingerprint = o.optString("fp"),
            nickname = o.optString("nick"),
            ip = o.optString("ip"),
            orPort = o.optInt("port"),
            countryCode = o.optString("cc"),
            isBridge = o.optBoolean("bridge"),
            latencyMs = o.optLong("lat", -1L)
        )
    }
}

data class VpnStatus(
    val running: Boolean = false,
    val state: ConnState = ConnState.OFF,
    val bootstrap: Int = 0,
    val bootstrapSummary: String = "",
    val message: String = "",
    val exitIp: String = "",
    val exitCountry: String = "",
    val isTor: Boolean = false,
    val pingMs: Long = -1L,
    val rxRate: Long = 0L,
    val txRate: Long = 0L,
    val rxTotal: Long = 0L,
    val txTotal: Long = 0L,
    val circuit: List<RelayInfo> = emptyList(),
    val socksPort: Int = -1,
    val dnsPort: Int = -1,
    val suggestSnowflake: Boolean = false,
    val networkFrozen: Boolean = false,
    val reconnectInSec: Int = 0,
    val bridgeMode: String = "",
    val exitCountrySetting: String = "",
    val lockdownEnabled: Boolean = false,
    val alwaysOn: Boolean = false,
    val tcpSessions: Int = 0,
    val udpBlocked: Long = 0L,
    val dnsViaTor: Long = 0L,
    val dnsDirect: Long = 0L,
    val updatedAt: Long = 0L
) {
    fun toJson(): JSONObject {
        val hops = JSONArray()
        circuit.forEach { hops.put(it.toJson()) }
        return JSONObject()
            .put("running", running)
            .put("state", state.name)
            .put("bootstrap", bootstrap)
            .put("bootstrapSummary", bootstrapSummary)
            .put("message", message)
            .put("exitIp", exitIp)
            .put("exitCountry", exitCountry)
            .put("isTor", isTor)
            .put("pingMs", pingMs)
            .put("rxRate", rxRate)
            .put("txRate", txRate)
            .put("rxTotal", rxTotal)
            .put("txTotal", txTotal)
            .put("circuit", hops)
            .put("socksPort", socksPort)
            .put("dnsPort", dnsPort)
            .put("suggestSnowflake", suggestSnowflake)
            .put("networkFrozen", networkFrozen)
            .put("reconnectInSec", reconnectInSec)
            .put("bridgeMode", bridgeMode)
            .put("exitCountrySetting", exitCountrySetting)
            .put("lockdownEnabled", lockdownEnabled)
            .put("alwaysOn", alwaysOn)
            .put("tcpSessions", tcpSessions)
            .put("udpBlocked", udpBlocked)
            .put("dnsViaTor", dnsViaTor)
            .put("dnsDirect", dnsDirect)
            .put("updatedAt", updatedAt)
    }

    companion object {
        fun fromJson(o: JSONObject): VpnStatus {
            val hops = ArrayList<RelayInfo>()
            val arr = o.optJSONArray("circuit")
            if (arr != null) {
                for (i in 0 until arr.length()) hops.add(RelayInfo.fromJson(arr.getJSONObject(i)))
            }
            return VpnStatus(
                running = o.optBoolean("running"),
                state = ConnState.entries.firstOrNull { it.name == o.optString("state") }
                    ?: ConnState.OFF,
                bootstrap = o.optInt("bootstrap"),
                bootstrapSummary = o.optString("bootstrapSummary"),
                message = o.optString("message"),
                exitIp = o.optString("exitIp"),
                exitCountry = o.optString("exitCountry"),
                isTor = o.optBoolean("isTor"),
                pingMs = o.optLong("pingMs", -1L),
                rxRate = o.optLong("rxRate"),
                txRate = o.optLong("txRate"),
                rxTotal = o.optLong("rxTotal"),
                txTotal = o.optLong("txTotal"),
                circuit = hops,
                socksPort = o.optInt("socksPort", -1),
                dnsPort = o.optInt("dnsPort", -1),
                suggestSnowflake = o.optBoolean("suggestSnowflake"),
                networkFrozen = o.optBoolean("networkFrozen"),
                reconnectInSec = o.optInt("reconnectInSec"),
                bridgeMode = o.optString("bridgeMode"),
                exitCountrySetting = o.optString("exitCountrySetting"),
                lockdownEnabled = o.optBoolean("lockdownEnabled"),
                alwaysOn = o.optBoolean("alwaysOn"),
                tcpSessions = o.optInt("tcpSessions"),
                udpBlocked = o.optLong("udpBlocked"),
                dnsViaTor = o.optLong("dnsViaTor"),
                dnsDirect = o.optLong("dnsDirect"),
                updatedAt = o.optLong("updatedAt")
            )
        }

        private fun file(context: Context) = File(context.filesDir, "vpn_state.json")

        /** Атомарная запись последнего состояния службы (читается процессом UI при старте). */
        fun save(context: Context, status: VpnStatus) {
            val target = file(context)
            val tmp = File(context.filesDir, "vpn_state.json.tmp")
            tmp.writeText(status.toJson().toString(), Charsets.UTF_8)
            if (!tmp.renameTo(target)) {
                target.writeText(status.toJson().toString(), Charsets.UTF_8)
                tmp.delete()
            }
        }

        fun load(context: Context): VpnStatus? {
            val f = file(context)
            if (!f.exists()) return null
            return runCatching { fromJson(JSONObject(f.readText(Charsets.UTF_8))) }.getOrNull()
        }
    }
}
