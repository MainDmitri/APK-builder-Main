package com.example.mainvpn.core

import java.util.Locale

object Countries {

    private val russian: Locale = Locale.forLanguageTag("ru")

    /** Страны, в которых традиционно больше всего выходных узлов Tor (используется, пока не загружен список из Onionoo). */
    val common = listOf(
        "de", "nl", "us", "fr", "se", "ch", "fi", "gb", "ca", "at",
        "ro", "pl", "no", "lu", "is", "cz", "es", "it", "dk", "bg",
        "md", "jp", "sg", "au"
    )

    fun flag(code: String): String {
        if (code.length != 2) return "🏳"
        val upper = code.uppercase(Locale.ROOT)
        if (!upper.all { it in 'A'..'Z' }) return "🏳"
        val first = Character.toChars(0x1F1E6 + (upper[0] - 'A'))
        val second = Character.toChars(0x1F1E6 + (upper[1] - 'A'))
        return String(first) + String(second)
    }

    fun name(code: String): String {
        if (code.length != 2) return "Неизвестно"
        val upper = code.uppercase(Locale.ROOT)
        val display = runCatching {
            Locale.Builder().setRegion(upper).build().getDisplayCountry(russian)
        }.getOrDefault("")
        return display.ifBlank { upper }
    }
}
