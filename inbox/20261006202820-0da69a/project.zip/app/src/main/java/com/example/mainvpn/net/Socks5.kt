package com.example.mainvpn.net

import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/** Минимальный клиент SOCKS5 (RFC 1928) для SocksPort Tor на 127.0.0.1. */
object Socks5 {

    class SocksException(val code: Int) : IOException(describe(code))

    private val LOOPBACK: InetAddress = InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1))

    fun describe(code: Int): String = when (code) {
        1 -> "SOCKS: общая ошибка"
        2 -> "SOCKS: соединение запрещено правилами Tor"
        3 -> "SOCKS: сеть недоступна"
        4 -> "SOCKS: узел недоступен"
        5 -> "SOCKS: в соединении отказано"
        6 -> "SOCKS: истёк TTL"
        7 -> "SOCKS: команда не поддерживается"
        8 -> "SOCKS: тип адреса не поддерживается"
        else -> "SOCKS: код ошибки $code"
    }

    /**
     * Открывает соединение через Tor. Нужно передать либо [host] (имя резолвится на выходном узле),
     * либо [address] (4 или 16 байт).
     */
    fun connect(
        proxyPort: Int,
        host: String?,
        address: ByteArray?,
        port: Int,
        timeoutMs: Int
    ): Socket {
        if (proxyPort <= 0) throw IOException("SocksPort Tor ещё не открыт")
        val socket = Socket()
        try {
            socket.tcpNoDelay = true
            socket.connect(InetSocketAddress(LOOPBACK, proxyPort), 5000)
            socket.soTimeout = timeoutMs
            val out = socket.getOutputStream()
            val input = DataInputStream(socket.getInputStream())

            out.write(byteArrayOf(5, 1, 0))
            out.flush()
            val greeting = ByteArray(2)
            input.readFully(greeting)
            if (greeting[0].toInt() != 5 || greeting[1].toInt() != 0) {
                throw IOException("SOCKS: прокси не принял метод без аутентификации")
            }

            val req = ByteArrayOutputStream()
            req.write(5)
            req.write(1)
            req.write(0)
            when {
                host != null -> {
                    val hb = host.toByteArray(Charsets.US_ASCII)
                    if (hb.size > 255) throw IOException("Слишком длинное имя узла")
                    req.write(3)
                    req.write(hb.size)
                    req.write(hb)
                }
                address != null && address.size == 4 -> {
                    req.write(1)
                    req.write(address)
                }
                address != null && address.size == 16 -> {
                    req.write(4)
                    req.write(address)
                }
                else -> throw IOException("Не указан адрес назначения")
            }
            req.write((port ushr 8) and 0xFF)
            req.write(port and 0xFF)
            out.write(req.toByteArray())
            out.flush()

            val head = ByteArray(4)
            input.readFully(head)
            if (head[0].toInt() != 5) throw IOException("SOCKS: неверная версия ответа")
            val rep = head[1].toInt() and 0xFF
            if (rep != 0) throw SocksException(rep)
            val skip = when (head[3].toInt() and 0xFF) {
                1 -> 4 + 2
                4 -> 16 + 2
                3 -> input.readUnsignedByte() + 2
                else -> throw IOException("SOCKS: неизвестный тип адреса в ответе")
            }
            val tail = ByteArray(skip)
            input.readFully(tail)
            socket.soTimeout = 0
            return socket
        } catch (e: IOException) {
            runCatching { socket.close() }
            throw e
        }
    }
}
