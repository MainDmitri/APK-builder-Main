package com.example.mainvpn.core

data class LogLine(val time: Long, val level: Level, val message: String) {

    enum class Level { INFO, WARN, ERROR }

    fun encode(): String =
        "$time|${level.name}|${message.replace('\n', ' ').replace('\r', ' ')}"

    companion object {
        fun decode(raw: String): LogLine? {
            val first = raw.indexOf('|')
            if (first <= 0) return null
            val second = raw.indexOf('|', first + 1)
            if (second < 0) return null
            val time = raw.substring(0, first).toLongOrNull() ?: return null
            val level = Level.entries.firstOrNull { it.name == raw.substring(first + 1, second) }
                ?: return null
            return LogLine(time, level, raw.substring(second + 1))
        }
    }
}
