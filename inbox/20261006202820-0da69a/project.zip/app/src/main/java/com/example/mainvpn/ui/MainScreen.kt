package com.example.mainvpn.ui

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

private data class Tab(val title: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("MAIN VPN", "Главная", Icons.Filled.Home),
    Tab("Цепочка узлов", "Цепочка", Icons.Filled.LocationOn),
    Tab("Безопасность", "Настройки", Icons.Filled.Settings),
    Tab("Диагностика и журнал", "Журнал", Icons.AutoMirrored.Filled.List)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(currentTab: Int, onTabChange: (Int) -> Unit, vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val status by vm.status.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var notificationsAsked by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.messages.collect { snackbar.showSnackbar(it) }
    }

    val vpnConsent = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            vm.connect()
        } else {
            vm.message("Без разрешения на создание VPN туннель не запустится")
        }
    }

    val requestVpnAndConnect = {
        val intent = VpnService.prepare(context)
        if (intent != null) vpnConsent.launch(intent) else vm.connect()
    }

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) vm.message("Уведомления запрещены: статус VPN не будет виден в шторке")
        requestVpnAndConnect()
    }

    val onPower: () -> Unit = {
        if (status.running) {
            vm.disconnect()
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !notificationsAsked &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationsAsked = true
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            requestVpnAndConnect()
        }
    }

    if (status.running && status.suggestSnowflake) {
        AlertDialog(
            onDismissRequest = { vm.dismissSnowflake() },
            title = { Text("Похоже, Tor блокируется") },
            text = {
                Text(
                    "Загрузка застряла ниже 15% дольше 15 секунд: входные узлы Tor, вероятно, блокирует провайдер. " +
                        "Включить мост Snowflake? Он маскирует трафик под WebRTC-видеозвонок и обходит DPI."
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.acceptSnowflake() }) { Text("Включить Snowflake") }
            },
            dismissButton = {
                TextButton(onClick = { vm.dismissSnowflake() }) { Text("Не сейчас") }
            }
        )
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text(tabs[currentTab].title) }) },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = currentTab == index,
                        onClick = { onTabChange(index) },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { innerPadding ->
        val modifier = Modifier.padding(innerPadding)
        when (currentTab) {
            0 -> DashboardScreen(
                status = status,
                settings = settings,
                onPower = onPower,
                onNewIdentity = vm::newIdentity,
                modifier = modifier
            )
            1 -> {
                val countries by vm.countries.collectAsStateWithLifecycle()
                CircuitScreen(
                    status = status,
                    settings = settings,
                    countries = countries,
                    onLoadCountries = { vm.loadExitCountries(it) },
                    onSelectCountry = vm::setExitCountry,
                    onRebuild = vm::rebuildCircuit,
                    modifier = modifier
                )
            }
            2 -> SettingsScreen(vm = vm, status = status, settings = settings, modifier = modifier)
            else -> DiagnosticsScreen(vm = vm, status = status, modifier = modifier)
        }
    }
}
