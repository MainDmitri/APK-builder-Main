package com.example.mainvpn.vpn

import android.os.SystemClock
import com.example.mainvpn.net.Socks5
import java.io.IOException
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlin.random.Random

/**
 * Одно TCP-соединение приложения, терминируемое в пользовательском пространстве:
 * со стороны TUN — собственная реализация TCP (рукопожатие, подтверждения, окно, повторы),
 * со стороны сети — поток через SOCKS5 Tor.
 */
class TcpSession(
    private val stack: TcpStack,
    val key: String,
    private val clientIp: ByteArray,
    private val clientPort: Int,
    private val serverIp: ByteArray,
    private val serverPort: Int
) {
    private enum class State { CONNECTING, SYN_RECEIVED, ESTABLISHED, CLOSED }

    private val lock = ReentrantLock()
    private val canSend = lock.newCondition()

    @Volatile private var state = State.CONNECTING
    private val iss: Int = Random.nextInt()
    private var sndUna = iss
    private var sndNxt = iss
    private var rcvNxt = 0
    private var clientWindow = 0
    private var mss = 536
    private val unacked = ByteBuffer()
    private var finSent = false
    private var finSeq = 0
    private var finAcked = false
    private var clientFin = false
    private var socket: Socket? = null
    private val upstream = LinkedBlockingQueue<ByteArray>()
    private val queued = AtomicInteger(0)
    private var lastAdvertised = MAX_QUEUE
    private var rtoMs = INITIAL_RTO
    private var retransmits = 0
    private var timerStart = 0L
    private val createdAt = SystemClock.elapsedRealtime()

    fun onSyn(seq: Int, window: Int, clientMss: Int) {
        lock.withLock {
            rcvNxt = seq + 1
            clientWindow = window
            mss = clientMss
        }
        stack.connectExecutor.execute {
            val s = try {
                Socks5.connect(stack.socksPort(), null, serverIp, serverPort, CONNECT_TIMEOUT_MS)
            } catch (e: IOException) {
                lock.withLock {
                    if (state != State.CLOSED) {
                        sendRstAck()
                        closeLocked()
                    }
                }
                return@execute
            }
            lock.withLock {
                if (state == State.CLOSED) {
                    runCatching { s.close() }
                    return@execute
                }
                socket = s
                state = State.SYN_RECEIVED
                sendSynAck()
                sndNxt = iss + 1
                timerStart = SystemClock.elapsedRealtime()
            }
        }
    }

    fun onSegment(seq: Int, ack: Int, flags: Int, window: Int, buf: ByteArray, off: Int, len: Int) {
        lock.withLock {
            if (state == State.CLOSED) return
            if (flags and IpPacket.RST != 0) {
                closeLocked()
                return
            }
            if (flags and IpPacket.SYN != 0) {
                if (state == State.SYN_RECEIVED) sendSynAck()
                return
            }
            if (flags and IpPacket.ACK == 0 || state == State.CONNECTING) return

            if (state == State.SYN_RECEIVED) {
                if (ack != iss + 1) return
                state = State.ESTABLISHED
                sndUna = ack
                clientWindow = window
                retransmits = 0
                rtoMs = INITIAL_RTO
                startPumps()
            } else {
                processAck(ack, window)
            }
            if (len > 0) processData(seq, buf, off, len)
            if (flags and IpPacket.FIN != 0) processFin(seq + len)
            if (clientFin && finSent && finAcked) closeLocked()
        }
    }

    /** Вызывается таймером стека: повторная передача и тайм-ауты. true — сессию можно удалить. */
    fun tick(now: Long): Boolean {
        lock.withLock {
            when (state) {
                State.CLOSED -> return true
                State.CONNECTING -> if (now - createdAt > CONNECT_TIMEOUT_MS + 15_000) {
                    sendRstAck()
                    closeLocked()
                }
                State.SYN_RECEIVED -> if (now - timerStart > rtoMs) {
                    if (++retransmits > 6) {
                        closeLocked()
                    } else {
                        sendSynAck()
                        timerStart = now
                        rtoMs = (rtoMs * 2).coerceAtMost(MAX_RTO)
                    }
                }
                State.ESTABLISHED -> if (sndNxt != sndUna && now - timerStart > rtoMs) {
                    if (++retransmits > 10) {
                        sendRstAck()
                        closeLocked()
                    } else {
                        retransmitLocked()
                        timerStart = now
                        rtoMs = (rtoMs * 2).coerceAtMost(MAX_RTO)
                    }
                }
            }
            return state == State.CLOSED
        }
    }

    fun abort() {
        lock.withLock {
            if (state != State.CLOSED) {
                if (state != State.CONNECTING) sendRstAck()
                closeLocked()
            }
        }
    }

    private fun processAck(ack: Int, window: Int) {
        val acked = ack - sndUna
        val inflight = sndNxt - sndUna
        if (acked in 1..inflight) {
            var dataAcked = acked
            if (finSent && ack == finSeq + 1) {
                finAcked = true
                dataAcked -= 1
            }
            unacked.drop(dataAcked.coerceAtMost(unacked.size))
            sndUna = ack
            retransmits = 0
            rtoMs = INITIAL_RTO
            timerStart = SystemClock.elapsedRealtime()
        }
        clientWindow = window
        canSend.signalAll()
    }

    private fun processData(seq: Int, buf: ByteArray, off: Int, len: Int) {
        if (seq == rcvNxt && !clientFin && queued.get() + len <= MAX_QUEUE) {
            upstream.offer(buf.copyOfRange(off, off + len))
            queued.addAndGet(len)
            rcvNxt += len
        }
        sendAck()
    }

    private fun processFin(clientFinSeq: Int) {
        if (!clientFin && clientFinSeq == rcvNxt) {
            clientFin = true
            rcvNxt += 1
            upstream.offer(EOF)
        }
        sendAck()
    }

    private fun startPumps() {
        stack.startThread("tcp-up-$clientPort") { writerLoop() }
        stack.startThread("tcp-down-$clientPort") { readerLoop() }
    }

    /** Данные от приложения → Tor. */
    private fun writerLoop() {
        val s = socket ?: return
        try {
            val out = s.getOutputStream()
            while (true) {
                val chunk = upstream.take()
                if (chunk === EOF) {
                    if (state != State.CLOSED) s.shutdownOutput()
                    return
                }
                out.write(chunk)
                queued.addAndGet(-chunk.size)
                lock.withLock {
                    if (state == State.ESTABLISHED && lastAdvertised < 4 * mss) sendAck()
                }
            }
        } catch (e: IOException) {
            failFromPump()
        } catch (e: InterruptedException) {
            failFromPump()
        }
    }

    /** Данные из Tor → приложению, с учётом окна получателя. */
    private fun readerLoop() {
        val s = socket ?: return
        val buf = ByteArray(32 * 1024)
        try {
            val input = s.getInputStream()
            while (true) {
                var room = 0
                lock.withLock {
                    while (state == State.ESTABLISHED && !finSent && (sndNxt - sndUna) >= clientWindow) {
                        canSend.await(1, TimeUnit.SECONDS)
                    }
                    if (state != State.ESTABLISHED || finSent) return
                    room = clientWindow - (sndNxt - sndUna)
                }
                val n = input.read(buf, 0, minOf(buf.size, room))
                lock.withLock {
                    if (state != State.ESTABLISHED) return
                    if (n < 0) {
                        sendFin()
                        if (clientFin && finAcked) closeLocked()
                        return
                    }
                    if (n > 0) sendData(buf, n)
                }
            }
        } catch (e: IOException) {
            failFromPump()
        } catch (e: InterruptedException) {
            failFromPump()
        }
    }

    private fun failFromPump() {
        lock.withLock {
            if (state != State.CLOSED) {
                sendRstAck()
                closeLocked()
            }
        }
    }

    private fun sendData(buf: ByteArray, n: Int) {
        if (sndNxt == sndUna) timerStart = SystemClock.elapsedRealtime()
        var pos = 0
        while (pos < n) {
            val len = minOf(mss, n - pos)
            val flags = IpPacket.ACK or (if (pos + len == n) IpPacket.PSH else 0)
            stack.send(
                IpPacket.buildTcp(
                    serverIp, clientIp, serverPort, clientPort,
                    sndNxt, rcvNxt, flags, advertiseWindow(), null, buf, pos, len
                )
            )
            unacked.append(buf, pos, len)
            sndNxt += len
            pos += len
        }
    }

    private fun sendFin() {
        if (finSent) return
        if (sndNxt == sndUna) timerStart = SystemClock.elapsedRealtime()
        finSeq = sndNxt
        stack.send(
            IpPacket.buildTcp(
                serverIp, clientIp, serverPort, clientPort,
                finSeq, rcvNxt, IpPacket.FIN or IpPacket.ACK, advertiseWindow(), null, null, 0, 0
            )
        )
        sndNxt += 1
        finSent = true
    }

    private fun retransmitLocked() {
        val dataLen = unacked.size
        val limit = minOf(dataLen, maxOf(clientWindow, mss))
        var sent = 0
        var seq = sndUna
        while (sent < limit) {
            val len = minOf(mss, limit - sent)
            val chunk = unacked.copy(sent, len)
            stack.send(
                IpPacket.buildTcp(
                    serverIp, clientIp, serverPort, clientPort,
                    seq, rcvNxt, IpPacket.ACK or IpPacket.PSH, advertiseWindow(), null, chunk, 0, len
                )
            )
            seq += len
            sent += len
        }
        if (finSent && !finAcked && sent >= dataLen) {
            stack.send(
                IpPacket.buildTcp(
                    serverIp, clientIp, serverPort, clientPort,
                    finSeq, rcvNxt, IpPacket.FIN or IpPacket.ACK, advertiseWindow(), null, null, 0, 0
                )
            )
        }
    }

    private fun advertiseWindow(): Int {
        val w = (MAX_QUEUE - queued.get()).coerceAtLeast(0)
        lastAdvertised = w
        return w
    }

    private fun sendSynAck() {
        val options = byteArrayOf(2, 4, (mss ushr 8).toByte(), mss.toByte())
        stack.send(
            IpPacket.buildTcp(
                serverIp, clientIp, serverPort, clientPort,
                iss, rcvNxt, IpPacket.SYN or IpPacket.ACK, advertiseWindow(), options, null, 0, 0
            )
        )
    }

    private fun sendAck() {
        stack.send(
            IpPacket.buildTcp(
                serverIp, clientIp, serverPort, clientPort,
                sndNxt, rcvNxt, IpPacket.ACK, advertiseWindow(), null, null, 0, 0
            )
        )
    }

    private fun sendRstAck() {
        stack.send(
            IpPacket.buildTcp(
                serverIp, clientIp, serverPort, clientPort,
                sndNxt, rcvNxt, IpPacket.RST or IpPacket.ACK, 0, null, null, 0, 0
            )
        )
    }

    private fun closeLocked() {
        state = State.CLOSED
        socket?.let { runCatching { it.close() } }
        upstream.clear()
        upstream.offer(EOF)
        canSend.signalAll()
        stack.remove(key)
    }

    /** Буфер отправленных, но ещё не подтверждённых байтов. */
    private class ByteBuffer {
        private var data = ByteArray(16 * 1024)
        private var start = 0
        var size = 0
            private set

        fun append(src: ByteArray, off: Int, len: Int) {
            if (start + size + len > data.size) {
                if (size + len <= data.size) {
                    System.arraycopy(data, start, data, 0, size)
                } else {
                    val grown = ByteArray(maxOf(data.size * 2, size + len))
                    System.arraycopy(data, start, grown, 0, size)
                    data = grown
                }
                start = 0
            }
            System.arraycopy(src, off, data, start + size, len)
            size += len
        }

        fun drop(n: Int) {
            start += n
            size -= n
            if (size == 0) start = 0
        }

        fun copy(offset: Int, len: Int): ByteArray = data.copyOfRange(start + offset, start + offset + len)
    }

    companion object {
        const val MAX_QUEUE = 65535
        private const val INITIAL_RTO = 1000L
        private const val MAX_RTO = 16_000L
        private const val CONNECT_TIMEOUT_MS = 60_000
        private val EOF = ByteArray(0)
    }
}
