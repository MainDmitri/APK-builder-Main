package com.example.mainvpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.example.mainvpn.ui.MainScreen
import com.example.mainvpn.ui.theme.AppTheme

class MainActivity : ComponentActivity() {

    private var currentTab by mutableIntStateOf(0)

    private val backToDashboard = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            selectTab(0)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        onBackPressedDispatcher.addCallback(this, backToDashboard)
        selectTab(savedInstanceState?.getInt(KEY_TAB) ?: 0)
        setContent {
            AppTheme {
                MainScreen(currentTab = currentTab, onTabChange = ::selectTab)
            }
        }
    }

    private fun selectTab(tab: Int) {
        currentTab = tab
        backToDashboard.isEnabled = tab != 0
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_TAB, currentTab)
    }

    private companion object {
        const val KEY_TAB = "tab"
    }
}
