package com.example.mainvpn.core

/** Команды и широковещательные сообщения между процессом UI и процессом службы :vpn. */
object Protocol {
    const val ACTION_START = "com.example.mainvpn.action.START"
    const val ACTION_STOP = "com.example.mainvpn.action.STOP"
    const val ACTION_NEW_IDENTITY = "com.example.mainvpn.action.NEW_IDENTITY"
    const val ACTION_REBUILD_CIRCUIT = "com.example.mainvpn.action.REBUILD_CIRCUIT"
    const val ACTION_UPDATE_SETTINGS = "com.example.mainvpn.action.UPDATE_SETTINGS"
    const val ACTION_DISMISS_SNOWFLAKE = "com.example.mainvpn.action.DISMISS_SNOWFLAKE"

    const val BROADCAST_STATE = "com.example.mainvpn.broadcast.STATE"
    const val BROADCAST_LOG = "com.example.mainvpn.broadcast.LOG"

    const val EXTRA_STATE_JSON = "state_json"
    const val EXTRA_LOG_LINES = "log_lines"
    const val EXTRA_SETTINGS_JSON = "settings_json"

    const val VPN_PROCESS_SUFFIX = ":vpn"
}
