package com.example.mainvpn.diag

import android.content.Context
import android.net.ConnectivityManager
import com.example.mainvpn.core.VpnStatus
import com.example.mainvpn.data.AppSettings
import com.example.mainvpn.net.DnsMessage
import com.example.mainvpn.net.TorHttp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.URI
import kotlin.random.Random

enum class TestVerdict { PASS, WARN, FAIL }

data class TestResult(
    val title: String,
    val verdict: TestVerdict,
    val summary: String,
    val details: List<String>
)

/** Реальные проверки безопасности соединения: Tor, утечки DNS, WebRTC/STUN. */
object SecurityTests {

    private const val TOR_CHECK_URL = "https://check.torproject.org/api/ip"
    private const val BASH_WS = "bash.ws"
    private const val STUN_HOST = "stun.l.google.com"
    private const val STUN_PORT = 19302

    suspend fun runAll(context: Context, status: VpnStatus, settings: AppSettings): List<TestResult> =
        coroutineScope {
            listOf(
                async(Dispatchers.IO) { torCheck(status) },
                async(Dispatchers.IO) { dnsLeak(context, status, settings) },
                async(Dispatchers.IO) { webRtc(status) }
            ).awaitAll()
        }

    private fun torCheck(status: VpnStatus): TestResult {
        val title = "Соединение через Tor"
        return try {
            val resp = TorHttp.get(status.socksPort, TOR_CHECK_URL)
            if (resp.code != 200) throw IOException("HTTP ${resp.code}")
            val json = JSONObject(resp.text())
            val ip = json.optString("IP")
            if (json.optBoolean("IsTor")) {
                TestResult(title, TestVerdict.PASS, "check.torproject.org подтверждает выход через Tor", listOf("Выходной IP: $ip"))
            } else {
                TestResult(title, TestVerdict.FAIL, "Запрос пришёл не с выходного узла Tor", listOf("IP: $ip"))
            }
        } catch (e: Exception) {
            TestResult(title, TestVerdict.FAIL, "Проверка не выполнена: ${e.message}", emptyList())
        }
    }

    /**
     * Тест bash.ws: уникальные имена резолвятся тем же путём, что DNS-запросы приложений в туннеле
     * (DNSPort Tor при включённой защите, иначе DNS провайдера). Затем bash.ws сообщает, какие
     * резолверы к нему обратились, и сравнивает их с вашим реальным IP.
     */
    private suspend fun dnsLeak(context: Context, status: VpnStatus, settings: AppSettings): TestResult {
        val title = "Утечка DNS"
        val details = ArrayList<String>()
        details.add("DNS-запросов из туннеля через Tor: ${status.dnsViaTor}, напрямую: ${status.dnsDirect}")
        return try {
            val id = TorHttp.get(status.socksPort, "https://$BASH_WS/id").text().trim()
            if (id.isEmpty() || !id.all { it.isLetterOrDigit() }) throw IOException("bash.ws вернул неверный идентификатор")

            val resolver: InetSocketAddress = if (settings.dnsProtection) {
                InetSocketAddress(InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1)), status.dnsPort)
            } else {
                val cm = context.getSystemService(ConnectivityManager::class.java)
                val dns = cm.activeNetwork?.let { cm.getLinkProperties(it)?.dnsServers }?.firstOrNull()
                    ?: throw IOException("не найден DNS-сервер провайдера")
                InetSocketAddress(dns, 53)
            }
            details.add(
                if (settings.dnsProtection) "Путь DNS в туннеле: DNSPort Tor (127.0.0.1:${status.dnsPort})"
                else "Путь DNS в туннеле: напрямую к ${resolver.address.hostAddress} (защита выключена)"
            )

            val answered = coroutineScope {
                (1..10).map { i ->
                    async(Dispatchers.IO) { probe(resolver, "$i.$id.$BASH_WS") }
                }.awaitAll()
            }.count { it }
            details.add("Ответов резолвера на пробные запросы: $answered из 10")

            val json = withContext(Dispatchers.IO) { directGet("https://$BASH_WS/dnsleak/test/$id?json") }
            val arr = JSONArray(json)
            var realAsn = ""
            var realIp = ""
            var conclusion = ""
            val servers = ArrayList<JSONObject>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                when (o.optString("type")) {
                    "ip" -> {
                        realIp = o.optString("ip")
                        realAsn = o.optString("asn")
                    }
                    "dns" -> servers.add(o)
                    "conclusion" -> conclusion = o.optString("ip")
                }
            }
            details.add("Ваш реальный IP (для сравнения): $realIp ${if (realAsn.isNotEmpty()) "[$realAsn]" else ""}")
            servers.forEach { o ->
                details.add("Резолвер: ${o.optString("ip")} ${o.optString("country_name")} ${o.optString("asn")}".trim())
            }
            if (conclusion.isNotEmpty()) details.add("Вывод bash.ws: $conclusion")

            val leaked = realAsn.isNotEmpty() && servers.any { it.optString("asn") == realAsn }
            when {
                leaked -> TestResult(title, TestVerdict.FAIL, "DNS-запросы видит ваш провайдер", details)
                !settings.dnsProtection -> TestResult(title, TestVerdict.WARN, "Защита от утечек DNS выключена в настройках", details)
                servers.isEmpty() -> TestResult(title, TestVerdict.WARN, "Резолверы не зафиксированы, повторите тест", details)
                else -> TestResult(title, TestVerdict.PASS, "DNS-запросы выходят только из сети Tor", details)
            }
        } catch (e: Exception) {
            TestResult(title, TestVerdict.FAIL, "Проверка не выполнена: ${e.message}", details)
        }
    }

    /** true, если резолвер ответил. Сам ответ не важен: bash.ws фиксирует факт запроса к своему серверу. */
    private fun probe(resolver: InetSocketAddress, name: String): Boolean {
        val id = Random.nextInt(0, 0xFFFF)
        val query = DnsMessage.buildQuery(id, name)
        return try {
            DatagramSocket().use { s ->
                s.soTimeout = 8000
                s.send(DatagramPacket(query, query.size, resolver))
                val buf = ByteArray(1500)
                val p = DatagramPacket(buf, buf.size)
                s.receive(p)
                DnsMessage.responseCode(buf, p.length, id) >= 0
            }
        } catch (e: IOException) {
            false
        }
    }

    private fun directGet(url: String): String {
        val conn = URI(url).toURL().openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 15_000
            val code = conn.responseCode
            if (code != 200) throw IOException("bash.ws вернул HTTP $code")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    /**
     * WebRTC раскрывает адреса через ICE-кандидаты: локальные адреса интерфейсов (host) и
     * публичный адрес, полученный по STUN через UDP (srflx). Проверяем оба канала.
     */
    private fun webRtc(status: VpnStatus): TestResult {
        val title = "WebRTC / STUN"
        val details = ArrayList<String>()
        val local = ArrayList<String>()
        runCatching {
            NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
                .filter { it.isUp && !it.isLoopback }
                .forEach { nif ->
                    nif.inetAddresses.toList()
                        .filter { !it.isLoopbackAddress && !it.isLinkLocalAddress }
                        .forEach { local.add("${nif.name}: ${it.hostAddress}") }
                }
        }
        details.add("Локальные адреса (host-кандидаты): " + if (local.isEmpty()) "нет" else local.joinToString("; "))

        val stunIp = runCatching { stunPublicAddress() }
        stunIp.onSuccess { details.add("STUN в обход туннеля видит IP: $it (так выглядела бы утечка)") }
        stunIp.onFailure { details.add("Прямой STUN-запрос не выполнен: ${it.message}") }
        details.add("UDP-пакетов, отброшенных в туннеле (STUN/QUIC и др.): ${status.udpBlocked}")
        details.add("Для проверки конкретного браузера откройте browserleaks.com/webrtc")

        return if (status.running) {
            TestResult(
                title, TestVerdict.PASS,
                "Туннель отбрасывает весь UDP, кроме DNS: STUN-запросы приложений не уходят мимо Tor",
                details
            )
        } else {
            TestResult(title, TestVerdict.FAIL, "Туннель не активен — WebRTC может раскрыть реальный IP", details)
        }
    }

    /** STUN Binding Request (RFC 5389) и разбор XOR-MAPPED-ADDRESS. */
    private fun stunPublicAddress(): String {
        val server = InetAddress.getAllByName(STUN_HOST).firstOrNull { it is Inet4Address }
            ?: throw IOException("не удалось найти адрес STUN-сервера")
        val tid = Random.nextBytes(12)
        val req = ByteArray(20)
        req[0] = 0x00; req[1] = 0x01
        req[2] = 0x00; req[3] = 0x00
        req[4] = 0x21; req[5] = 0x12; req[6] = 0xA4.toByte(); req[7] = 0x42
        System.arraycopy(tid, 0, req, 8, 12)
        DatagramSocket().use { s ->
            s.soTimeout = 5000
            s.send(DatagramPacket(req, req.size, InetSocketAddress(server, STUN_PORT)))
            val buf = ByteArray(1024)
            val p = DatagramPacket(buf, buf.size)
            s.receive(p)
            var pos = 20
            val end = minOf(p.length, 20 + (((buf[2].toInt() and 0xFF) shl 8) or (buf[3].toInt() and 0xFF)))
            while (pos + 4 <= end) {
                val type = ((buf[pos].toInt() and 0xFF) shl 8) or (buf[pos + 1].toInt() and 0xFF)
                val len = ((buf[pos + 2].toInt() and 0xFF) shl 8) or (buf[pos + 3].toInt() and 0xFF)
                val v = pos + 4
                if ((type == 0x0020 || type == 0x0001) && len >= 8 && buf[v + 1].toInt() == 0x01) {
                    val addr = ByteArray(4)
                    for (i in 0 until 4) {
                        addr[i] = if (type == 0x0020) (buf[v + 4 + i].toInt() xor req[4 + i].toInt()).toByte() else buf[v + 4 + i]
                    }
                    return InetAddress.getByAddress(addr).hostAddress ?: "?"
                }
                pos = v + ((len + 3) / 4) * 4
            }
        }
        throw IOException("в ответе STUN нет адреса")
    }
}
