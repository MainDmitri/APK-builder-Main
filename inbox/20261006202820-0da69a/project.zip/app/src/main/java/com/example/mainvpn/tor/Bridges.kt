package com.example.mainvpn.tor

import com.example.mainvpn.data.AppSettings
import com.example.mainvpn.data.BridgeMode
import org.json.JSONObject

/**
 * Мосты Tor. Встроенный список — публичные мосты, которые раздаёт Tor Project
 * (тот же набор, что в Tor Browser и Orbot). Его можно обновить из Moat API.
 */
object Bridges {

    const val MOAT_BUILTIN_URL = "https://bridges.torproject.org/moat/circumvention/builtin"

    const val DEFAULT_BUILTIN_JSON = """{"obfs4":["obfs4 45.145.95.6:27015 C5B7CD6946FF10C5B3E89691A7D3F2C122D2117C cert=TD7PbUO0/0k6xYHMPW3vJxICfkMZNdkRrb63Zhl5j9dW3iRGiCx0A7mPhe5T2EDzQ35+Zw iat-mode=0","obfs4 37.218.245.14:38224 D9A82D2F9C2F65A18407B1D2B764F130847F8B5D cert=bjRaMrr1BRiAW8IE9U5z27fQaYgOhX1UCmOpg2pFpoMvo6ZgQMzLsaTzzQNTlm7hNcb+Sg iat-mode=0","obfs4 146.57.248.225:22 10A6CD36A537FCE513A322361547444B393989F0 cert=K1gDtDAIcUfeLqbstggjIw2rtgIKqdIhUlHp82XRqNSq/mtAjp1BIC9vHKJ2FAEpGssTPw iat-mode=0","obfs4 212.83.43.74:443 39562501228A4D5E27FCA4C0C81A01EE23AE3EE4 cert=PBwr+S8JTVZo6MPdHnkTwXJPILWADLqfMGoVvhZClMq/Urndyd42BwX9YFJHZnBB3H0XCw iat-mode=1","obfs4 212.83.43.95:443 BFE712113A72899AD685764B211FACD30FF52C31 cert=ayq0XzCwhpdysn5o0EyDUbmSOx3X/oTEbzDMvczHOdBJKlvIdHHLJGkZARtT4dcBFArPPg iat-mode=1","obfs4 209.148.46.65:443 74FAD13168806246602538555B5521A0383A1875 cert=ssH+9rP8dG2NLDN2XuFw63hIO/9MNNinLmxQDpVa+7kTOa9/m+tGWT1SmSYpQ9uTBGa6Hw iat-mode=0","obfs4 51.222.13.177:80 5EDAC3B810E12B01F6FD8050D2FD3E277B289A08 cert=2uplIpLQ0q9+0qMFrK5pkaYRDOe460LL9WHBvatgkuRr/SL31wBOEupaMMJ6koRE6Ld0ew iat-mode=0"],"snowflake":["snowflake 192.0.2.3:80 2B280B23E1107BB62ABFC40DDCC8824814F80A72 fingerprint=2B280B23E1107BB62ABFC40DDCC8824814F80A72 url=https://1098762253.rsc.cdn77.org/ fronts=app.datapacket.com,www.datapacket.com ice=stun:stun.epygi.com:3478,stun:stun.uls.co.za:3478,stun:stun.voipgate.com:3478,stun:stun.mixvoip.com:3478,stun:stun.telnyx.com:3478,stun:stun.hot-chilli.net:3478,stun:stun.fitauto.ru:3478,stun:stun.m-online.net:3478 utls-imitate=hellorandomizedalpn","snowflake 192.0.2.4:80 8838024498816A039FCBBAB14E6F40A0843051FA fingerprint=8838024498816A039FCBBAB14E6F40A0843051FA url=https://1098762253.rsc.cdn77.org/ fronts=app.datapacket.com,www.datapacket.com ice=stun:stun.epygi.com:3478,stun:stun.uls.co.za:3478,stun:stun.voipgate.com:3478,stun:stun.mixvoip.com:3478,stun:stun.telnyx.com:3478,stun:stun.hot-chilli.net:3478,stun:stun.fitauto.ru:3478,stun:stun.m-online.net:3478 utls-imitate=hellorandomizedalpn"]}"""

    /** true, если в ответе Moat есть мосты obfs4 и snowflake. */
    fun validateBuiltinJson(json: String): Boolean = runCatching {
        val o = JSONObject(json)
        (o.optJSONArray("obfs4")?.length() ?: 0) > 0 && (o.optJSONArray("snowflake")?.length() ?: 0) > 0
    }.getOrDefault(false)

    fun builtin(json: String, transport: String): List<String> {
        val source = if (validateBuiltinJson(json)) json else DEFAULT_BUILTIN_JSON
        val arr = JSONObject(source).optJSONArray(transport) ?: return emptyList()
        return (0 until arr.length()).map { arr.getString(it).trim() }.filter { it.isNotEmpty() }
    }

    fun parseCustom(text: String): List<String> =
        text.lines()
            .map { it.trim().removePrefix("Bridge ").removePrefix("bridge ").trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }

    fun linesFor(settings: AppSettings): List<String> = when (settings.bridgeMode) {
        BridgeMode.DIRECT -> emptyList()
        BridgeMode.OBFS4 -> builtin(settings.builtinBridgesJson, "obfs4")
        BridgeMode.SNOWFLAKE -> builtin(settings.builtinBridgesJson, "snowflake")
        BridgeMode.CUSTOM -> parseCustom(settings.customBridges)
    }

    /** Имя транспорта или null для обычного моста «IP:порт отпечаток». */
    fun transportOf(line: String): String? {
        val first = line.substringBefore(' ')
        if (first.isEmpty()) return null
        if (first[0].isDigit() || first.startsWith("[")) return null
        return first.lowercase()
    }

    fun args(line: String): Map<String, String> =
        line.split(' ').filter { it.contains('=') }.associate {
            it.substringBefore('=') to it.substringAfter('=')
        }

    /** Адрес моста «хост:порт» (для обычных мостов и obfs4/webtunnel). */
    fun address(line: String): Pair<String, Int>? {
        val tokens = line.split(' ').filter { it.isNotEmpty() }
        val addr = (if (transportOf(line) == null) tokens.getOrNull(0) else tokens.getOrNull(1)) ?: return null
        val host = addr.substringBeforeLast(':').removePrefix("[").removeSuffix("]")
        val port = addr.substringAfterLast(':').toIntOrNull() ?: return null
        return host to port
    }

    fun fingerprint(line: String): String? {
        val tokens = line.split(' ').filter { it.isNotEmpty() }
        val idx = if (transportOf(line) == null) 1 else 2
        val fp = tokens.getOrNull(idx) ?: return null
        return if (fp.length == 40 && fp.all { it.isDigit() || it.uppercaseChar() in 'A'..'F' }) fp.uppercase() else null
    }
}
