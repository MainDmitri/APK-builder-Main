package com.example.mainvpn.data

import android.content.Context
import androidx.core.content.edit
import org.json.JSONArray
import org.json.JSONObject

enum class BridgeMode(val title: String) {
    DIRECT("Прямое подключение"),
    OBFS4("Встроенные мосты obfs4"),
    SNOWFLAKE("Snowflake (обход DPI)"),
    CUSTOM("Свои мосты")
}

data class AppSettings(
    val killSwitch: Boolean = true,
    val dnsProtection: Boolean = true,
    val bridgeMode: BridgeMode = BridgeMode.DIRECT,
    val customBridges: String = "",
    val excludedApps: Set<String> = emptySet(),
    val exitCountry: String = "",
    val builtinBridgesJson: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("killSwitch", killSwitch)
        .put("dnsProtection", dnsProtection)
        .put("bridgeMode", bridgeMode.name)
        .put("customBridges", customBridges)
        .put("excludedApps", JSONArray(excludedApps.toList()))
        .put("exitCountry", exitCountry)
        .put("builtinBridgesJson", builtinBridgesJson)

    companion object {
        fun fromJson(o: JSONObject): AppSettings {
            val apps = HashSet<String>()
            val arr = o.optJSONArray("excludedApps")
            if (arr != null) for (i in 0 until arr.length()) apps.add(arr.getString(i))
            return AppSettings(
                killSwitch = o.optBoolean("killSwitch", true),
                dnsProtection = o.optBoolean("dnsProtection", true),
                bridgeMode = BridgeMode.entries.firstOrNull { it.name == o.optString("bridgeMode") }
                    ?: BridgeMode.DIRECT,
                customBridges = o.optString("customBridges"),
                excludedApps = apps,
                exitCountry = o.optString("exitCountry"),
                builtinBridgesJson = o.optString("builtinBridgesJson")
            )
        }
    }
}

/** Хранение настроек в SharedPreferences("app"). */
object SettingsStore {
    private const val PREFS = "app"
    private const val KEY_KILL_SWITCH = "kill_switch"
    private const val KEY_DNS = "dns_protection"
    private const val KEY_BRIDGE_MODE = "bridge_mode"
    private const val KEY_CUSTOM_BRIDGES = "custom_bridges"
    private const val KEY_EXCLUDED = "excluded_apps"
    private const val KEY_EXIT_COUNTRY = "exit_country"
    private const val KEY_BUILTIN_BRIDGES = "builtin_bridges_json"

    fun load(context: Context): AppSettings {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val excluded = HashSet<String>()
        val raw = p.getString(KEY_EXCLUDED, "[]") ?: "[]"
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) excluded.add(arr.getString(i))
        }
        return AppSettings(
            killSwitch = p.getBoolean(KEY_KILL_SWITCH, true),
            dnsProtection = p.getBoolean(KEY_DNS, true),
            bridgeMode = BridgeMode.entries.firstOrNull { it.name == p.getString(KEY_BRIDGE_MODE, null) }
                ?: BridgeMode.DIRECT,
            customBridges = p.getString(KEY_CUSTOM_BRIDGES, "") ?: "",
            excludedApps = excluded,
            exitCountry = p.getString(KEY_EXIT_COUNTRY, "") ?: "",
            builtinBridgesJson = p.getString(KEY_BUILTIN_BRIDGES, "") ?: ""
        )
    }

    /**
     * commit = true нужен перед стартом службы: она работает в отдельном процессе
     * и читает файл настроек при запуске.
     */
    fun save(context: Context, s: AppSettings, commit: Boolean = false) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit(commit = commit) {
            putBoolean(KEY_KILL_SWITCH, s.killSwitch)
            putBoolean(KEY_DNS, s.dnsProtection)
            putString(KEY_BRIDGE_MODE, s.bridgeMode.name)
            putString(KEY_CUSTOM_BRIDGES, s.customBridges)
            putString(KEY_EXCLUDED, JSONArray(s.excludedApps.toList()).toString())
            putString(KEY_EXIT_COUNTRY, s.exitCountry)
            putString(KEY_BUILTIN_BRIDGES, s.builtinBridgesJson)
        }
    }
}
