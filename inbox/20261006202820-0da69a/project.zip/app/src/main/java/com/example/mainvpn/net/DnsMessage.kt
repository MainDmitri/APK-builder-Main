package com.example.mainvpn.net

import java.io.ByteArrayOutputStream

/** Построение DNS-запросов (RFC 1035) для диагностики утечек. */
object DnsMessage {

    const val TYPE_A = 1

    fun buildQuery(id: Int, name: String, type: Int = TYPE_A): ByteArray {
        val out = ByteArrayOutputStream()
        out.write((id ushr 8) and 0xFF)
        out.write(id and 0xFF)
        out.write(0x01) // RD
        out.write(0x00)
        out.write(0); out.write(1) // QDCOUNT
        out.write(0); out.write(0) // ANCOUNT
        out.write(0); out.write(0) // NSCOUNT
        out.write(0); out.write(0) // ARCOUNT
        for (label in name.trimEnd('.').split('.')) {
            val bytes = label.toByteArray(Charsets.US_ASCII)
            require(bytes.size in 1..63) { "Неверная метка DNS: $label" }
            out.write(bytes.size)
            out.write(bytes)
        }
        out.write(0)
        out.write((type ushr 8) and 0xFF)
        out.write(type and 0xFF)
        out.write(0); out.write(1) // QCLASS IN
        return out.toByteArray()
    }

    /** Код ответа (RCODE) или -1, если пакет не является ответом на запрос с [id]. */
    fun responseCode(packet: ByteArray, length: Int, id: Int): Int {
        if (length < 12) return -1
        val rid = ((packet[0].toInt() and 0xFF) shl 8) or (packet[1].toInt() and 0xFF)
        if (rid != id) return -1
        if ((packet[2].toInt() and 0x80) == 0) return -1
        return packet[3].toInt() and 0x0F
    }
}
