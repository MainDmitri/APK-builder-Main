package com.example.mainvpn.net

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Socket
import java.net.URI
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLPeerUnverifiedException
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * HTTP/1.1-клиент поверх SOCKS5 Tor. Имя узла передаётся в Tor (резолвится на выходном узле),
 * поэтому запросы приложения не утекают в DNS провайдера, даже несмотря на то, что
 * само приложение исключено из VPN (иначе Tor не смог бы выйти в сеть).
 */
object TorHttp {

    class Response(val code: Int, val headers: Map<String, String>, val body: ByteArray) {
        fun text(): String = String(body, Charsets.UTF_8)
    }

    private const val USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0"

    fun get(socksPort: Int, url: String, timeoutMs: Int = 30_000, maxBytes: Int = 4_000_000): Response =
        request(socksPort, "GET", url, null, null, timeoutMs, maxBytes)

    fun post(
        socksPort: Int,
        url: String,
        body: ByteArray,
        contentType: String,
        timeoutMs: Int = 30_000,
        maxBytes: Int = 4_000_000
    ): Response = request(socksPort, "POST", url, body, contentType, timeoutMs, maxBytes)

    /** Время установления TCP-соединения через всю цепочку Tor до [host]:[port], мс. */
    fun measureConnect(socksPort: Int, host: String, port: Int, timeoutMs: Int = 20_000): Long {
        val start = System.nanoTime()
        Socks5.connect(socksPort, host, null, port, timeoutMs).use { }
        return (System.nanoTime() - start) / 1_000_000
    }

    private fun request(
        socksPort: Int,
        method: String,
        url: String,
        body: ByteArray?,
        contentType: String?,
        timeoutMs: Int,
        maxBytes: Int
    ): Response {
        var current = url
        var currentMethod = method
        var currentBody = body
        repeat(5) {
            val resp = once(socksPort, currentMethod, current, currentBody, contentType, timeoutMs, maxBytes)
            if (resp.code in listOf(301, 302, 303, 307, 308)) {
                val location = resp.headers["location"] ?: return resp
                current = URI(current).resolve(location).toString()
                if (resp.code == 303 || ((resp.code == 301 || resp.code == 302) && currentMethod == "POST")) {
                    currentMethod = "GET"
                    currentBody = null
                }
            } else {
                return resp
            }
        }
        throw IOException("Слишком много перенаправлений")
    }

    private fun once(
        socksPort: Int,
        method: String,
        url: String,
        body: ByteArray?,
        contentType: String?,
        timeoutMs: Int,
        maxBytes: Int
    ): Response {
        val uri = URI(url)
        val https = when (uri.scheme?.lowercase()) {
            "https" -> true
            "http" -> false
            else -> throw IOException("Неподдерживаемая схема: ${uri.scheme}")
        }
        val host = uri.host ?: throw IOException("Нет имени узла в адресе $url")
        val port = if (uri.port > 0) uri.port else if (https) 443 else 80
        val path = buildString {
            append(if (uri.rawPath.isNullOrEmpty()) "/" else uri.rawPath)
            if (!uri.rawQuery.isNullOrEmpty()) append('?').append(uri.rawQuery)
        }

        val raw = Socks5.connect(socksPort, host, null, port, timeoutMs)
        val socket: Socket = try {
            if (https) {
                val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
                val ssl = factory.createSocket(raw, host, port, true) as SSLSocket
                ssl.soTimeout = timeoutMs
                ssl.startHandshake()
                if (!HttpsURLConnection.getDefaultHostnameVerifier().verify(host, ssl.session)) {
                    throw SSLPeerUnverifiedException("Сертификат не соответствует узлу $host")
                }
                ssl
            } else {
                raw.soTimeout = timeoutMs
                raw
            }
        } catch (e: IOException) {
            runCatching { raw.close() }
            throw e
        }

        socket.use { s ->
            val out = s.getOutputStream()
            val hostHeader = if ((https && port == 443) || (!https && port == 80)) host else "$host:$port"
            val head = StringBuilder()
                .append(method).append(' ').append(path).append(" HTTP/1.1\r\n")
                .append("Host: ").append(hostHeader).append("\r\n")
                .append("User-Agent: ").append(USER_AGENT).append("\r\n")
                .append("Accept: */*\r\n")
                .append("Accept-Encoding: identity\r\n")
                .append("Connection: close\r\n")
            if (body != null) {
                head.append("Content-Type: ").append(contentType ?: "application/octet-stream").append("\r\n")
                head.append("Content-Length: ").append(body.size).append("\r\n")
            }
            head.append("\r\n")
            out.write(head.toString().toByteArray(Charsets.ISO_8859_1))
            if (body != null) out.write(body)
            out.flush()

            val input = BufferedInputStream(s.getInputStream())
            val statusLine = readLine(input) ?: throw IOException("Пустой ответ сервера")
            val parts = statusLine.split(' ')
            if (parts.size < 2) throw IOException("Неверная строка статуса: $statusLine")
            val code = parts[1].toIntOrNull() ?: throw IOException("Неверный код ответа: $statusLine")
            val headers = HashMap<String, String>()
            while (true) {
                val line = readLine(input) ?: break
                if (line.isEmpty()) break
                val idx = line.indexOf(':')
                if (idx > 0) headers[line.substring(0, idx).trim().lowercase()] = line.substring(idx + 1).trim()
            }
            val sink = ByteArrayOutputStream()
            readBody(input, headers, sink, maxBytes, method == "HEAD" || code == 204 || code == 304)
            return Response(code, headers, sink.toByteArray())
        }
    }

    private fun readBody(
        input: InputStream,
        headers: Map<String, String>,
        sink: OutputStream,
        maxBytes: Int,
        noBody: Boolean
    ) {
        if (noBody) return
        var total = 0L
        val buf = ByteArray(16 * 1024)
        fun write(n: Int) {
            total += n
            if (total > maxBytes) throw IOException("Ответ превышает $maxBytes байт")
            sink.write(buf, 0, n)
        }
        if (headers["transfer-encoding"]?.lowercase()?.contains("chunked") == true) {
            while (true) {
                val sizeLine = readLine(input) ?: throw IOException("Обрыв chunked-ответа")
                val size = sizeLine.substringBefore(';').trim().toIntOrNull(16)
                    ?: throw IOException("Неверный размер блока: $sizeLine")
                if (size == 0) {
                    while (true) {
                        val trailer = readLine(input) ?: break
                        if (trailer.isEmpty()) break
                    }
                    return
                }
                var left = size
                while (left > 0) {
                    val n = input.read(buf, 0, minOf(buf.size, left))
                    if (n < 0) throw IOException("Обрыв chunked-ответа")
                    write(n)
                    left -= n
                }
                readLine(input)
            }
        }
        val length = headers["content-length"]?.toLongOrNull()
        if (length != null) {
            var left = length
            while (left > 0) {
                val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                if (n < 0) throw IOException("Ответ оборван")
                write(n)
                left -= n
            }
            return
        }
        while (true) {
            val n = input.read(buf)
            if (n < 0) return
            write(n)
        }
    }

    private fun readLine(input: InputStream): String? {
        val sb = ByteArrayOutputStream()
        while (true) {
            val b = input.read()
            if (b < 0) return if (sb.size() == 0) null else String(sb.toByteArray(), Charsets.ISO_8859_1)
            if (b == '\n'.code) {
                val bytes = sb.toByteArray()
                val len = if (bytes.isNotEmpty() && bytes.last() == '\r'.code.toByte()) bytes.size - 1 else bytes.size
                return String(bytes, 0, len, Charsets.ISO_8859_1)
            }
            sb.write(b)
            if (sb.size() > 64 * 1024) throw IOException("Слишком длинная строка заголовка")
        }
    }
}
