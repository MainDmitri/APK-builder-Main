package com.example.mainvpn.ui

import android.app.ActivityManager
import android.app.Application
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.mainvpn.core.ConnState
import com.example.mainvpn.core.LogFile
import com.example.mainvpn.core.LogLine
import com.example.mainvpn.core.Protocol
import com.example.mainvpn.core.VpnStatus
import com.example.mainvpn.data.AppSettings
import com.example.mainvpn.data.BridgeMode
import com.example.mainvpn.data.InstalledApp
import com.example.mainvpn.data.InstalledApps
import com.example.mainvpn.data.SettingsStore
import com.example.mainvpn.diag.SecurityTests
import com.example.mainvpn.diag.TestResult
import com.example.mainvpn.diag.TestVerdict
import com.example.mainvpn.net.Onionoo
import com.example.mainvpn.net.TorHttp
import com.example.mainvpn.tor.Bridges
import com.example.mainvpn.vpn.TorVpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DiagnosticsState(
    val running: Boolean = false,
    val results: List<TestResult> = emptyList(),
    val finishedAt: Long = 0L
)

data class CountryListState(
    val loading: Boolean = false,
    val counts: Map<String, Int> = emptyMap(),
    val error: String = ""
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx: Application get() = getApplication()

    private val _settings = MutableStateFlow(SettingsStore.load(app))
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _status = MutableStateFlow(initialStatus(app))
    val status: StateFlow<VpnStatus> = _status.asStateFlow()

    private val _logs = MutableStateFlow<List<LogLine>>(emptyList())
    val logs: StateFlow<List<LogLine>> = _logs.asStateFlow()

    private val _apps = MutableStateFlow<List<InstalledApp>?>(null)
    val apps: StateFlow<List<InstalledApp>?> = _apps.asStateFlow()

    private val _diagnostics = MutableStateFlow(DiagnosticsState())
    val diagnostics: StateFlow<DiagnosticsState> = _diagnostics.asStateFlow()

    private val _countries = MutableStateFlow(CountryListState())
    val countries: StateFlow<CountryListState> = _countries.asStateFlow()

    private val _bridgeRefresh = MutableStateFlow(false)
    val bridgeRefreshRunning: StateFlow<Boolean> = _bridgeRefresh.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Protocol.BROADCAST_STATE -> {
                    val raw = intent.getStringExtra(Protocol.EXTRA_STATE_JSON) ?: return
                    runCatching { VpnStatus.fromJson(JSONObject(raw)) }.onSuccess { _status.value = it }
                }
                Protocol.BROADCAST_LOG -> {
                    val lines = intent.getStringArrayListExtra(Protocol.EXTRA_LOG_LINES) ?: return
                    appendLogs(lines.mapNotNull { LogLine.decode(it) })
                }
            }
        }
    }

    init {
        val filter = IntentFilter().apply {
            addAction(Protocol.BROADCAST_STATE)
            addAction(Protocol.BROADCAST_LOG)
        }
        ContextCompat.registerReceiver(app, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        viewModelScope.launch {
            val stored = withContext(Dispatchers.IO) { LogFile.readAll(ctx) }
            _logs.value = (stored + _logs.value).takeLast(MAX_LOGS)
        }
    }

    override fun onCleared() {
        runCatching { ctx.unregisterReceiver(receiver) }
        super.onCleared()
    }

    private fun appendLogs(lines: List<LogLine>) {
        if (lines.isEmpty()) return
        _logs.value = (_logs.value + lines).takeLast(MAX_LOGS)
    }

    private fun logUi(level: LogLine.Level, message: String) {
        val line = LogLine(System.currentTimeMillis(), level, message)
        appendLogs(listOf(line))
        viewModelScope.launch(Dispatchers.IO) { runCatching { LogFile.append(ctx, listOf(line)) } }
    }

    fun message(text: String) {
        _messages.tryEmit(text)
    }

    // ------------------------------------------------------------ туннель

    fun connect() {
        SettingsStore.save(ctx, _settings.value, commit = true)
        _status.value = VpnStatus(running = true, state = ConnState.CONNECTING, bootstrapSummary = "Запуск службы VPN")
        ContextCompat.startForegroundService(
            ctx, Intent(ctx, TorVpnService::class.java).setAction(Protocol.ACTION_START)
        )
    }

    fun disconnect() {
        sendCommand(Protocol.ACTION_STOP)
    }

    fun newIdentity() {
        if (_status.value.state != ConnState.CONNECTED) {
            message("Новая личность доступна только при активном туннеле")
            return
        }
        sendCommand(Protocol.ACTION_NEW_IDENTITY)
    }

    fun rebuildCircuit() {
        if (_status.value.state != ConnState.CONNECTED) {
            message("Перестроить цепочку можно только при активном туннеле")
            return
        }
        sendCommand(Protocol.ACTION_REBUILD_CIRCUIT)
    }

    private fun sendCommand(action: String, extras: Intent.() -> Unit = {}) {
        if (!_status.value.running) return
        try {
            ctx.startService(Intent(ctx, TorVpnService::class.java).setAction(action).apply(extras))
        } catch (e: IllegalStateException) {
            message("Служба VPN недоступна: ${e.message}")
        }
    }

    // ------------------------------------------------------------ настройки

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val updated = transform(_settings.value)
        if (updated == _settings.value) return
        _settings.value = updated
        SettingsStore.save(ctx, updated)
        sendCommand(Protocol.ACTION_UPDATE_SETTINGS) {
            putExtra(Protocol.EXTRA_SETTINGS_JSON, updated.toJson().toString())
        }
    }

    fun setExitCountry(code: String) = updateSettings { it.copy(exitCountry = code) }

    fun acceptSnowflake() {
        updateSettings { it.copy(bridgeMode = BridgeMode.SNOWFLAKE) }
        logUi(LogLine.Level.INFO, "Пользователь включил мост Snowflake")
    }

    fun dismissSnowflake() {
        sendCommand(Protocol.ACTION_DISMISS_SNOWFLAKE)
    }

    fun toggleExcluded(pkg: String, excluded: Boolean) = updateSettings {
        it.copy(excludedApps = if (excluded) it.excludedApps + pkg else it.excludedApps - pkg)
    }

    fun loadApps() {
        if (_apps.value != null) return
        viewModelScope.launch {
            _apps.value = withContext(Dispatchers.IO) { InstalledApps.load(ctx) }
        }
    }

    /** Обновляет встроенные мосты из Moat API Tor Project (через Tor, если туннель активен). */
    fun refreshBuiltinBridges() {
        if (_bridgeRefresh.value) return
        _bridgeRefresh.value = true
        viewModelScope.launch {
            try {
                val st = _status.value
                val json = withContext(Dispatchers.IO) {
                    if (st.state == ConnState.CONNECTED && st.socksPort > 0) {
                        val r = TorHttp.post(st.socksPort, Bridges.MOAT_BUILTIN_URL, "{}".toByteArray(), "application/vnd.api+json")
                        if (r.code != 200) throw IOException("HTTP ${r.code}")
                        r.text()
                    } else {
                        moatDirect()
                    }
                }
                if (!Bridges.validateBuiltinJson(json)) throw IOException("ответ не содержит мостов obfs4 и snowflake")
                updateSettings { it.copy(builtinBridgesJson = json) }
                logUi(LogLine.Level.INFO, "Встроенные мосты обновлены из Moat API")
                message("Список встроенных мостов обновлён")
            } catch (e: Exception) {
                logUi(LogLine.Level.WARN, "Не удалось обновить мосты: ${e.message}")
                message("Не удалось обновить мосты: ${e.message}")
            } finally {
                _bridgeRefresh.value = false
            }
        }
    }

    private fun moatDirect(): String {
        val conn = URI(Bridges.MOAT_BUILTIN_URL).toURL().openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 20_000
            conn.readTimeout = 20_000
            conn.setRequestProperty("Content-Type", "application/vnd.api+json")
            conn.outputStream.use { it.write("{}".toByteArray()) }
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    // ------------------------------------------------------------ узлы

    fun loadExitCountries(force: Boolean = false) {
        val st = _status.value
        if (st.state != ConnState.CONNECTED || st.socksPort <= 0) return
        if (_countries.value.loading || (!force && _countries.value.counts.isNotEmpty())) return
        _countries.value = _countries.value.copy(loading = true, error = "")
        viewModelScope.launch {
            try {
                val counts = withContext(Dispatchers.IO) { Onionoo.exitCountryCounts(st.socksPort) }
                _countries.value = CountryListState(counts = counts)
            } catch (e: Exception) {
                _countries.value = _countries.value.copy(loading = false, error = e.message ?: "ошибка")
            }
        }
    }

    // ------------------------------------------------------------ диагностика

    fun runSecurityTests() {
        val st = _status.value
        if (st.state != ConnState.CONNECTED || st.socksPort <= 0) {
            message("Подключите VPN, чтобы запустить тестирование")
            return
        }
        if (_diagnostics.value.running) return
        _diagnostics.value = _diagnostics.value.copy(running = true)
        logUi(LogLine.Level.INFO, "Запущено тестирование безопасности")
        viewModelScope.launch {
            val results = SecurityTests.runAll(ctx, st, _settings.value)
            _diagnostics.value = DiagnosticsState(false, results, System.currentTimeMillis())
            results.forEach {
                logUi(
                    when (it.verdict) {
                        TestVerdict.PASS -> LogLine.Level.INFO
                        TestVerdict.WARN -> LogLine.Level.WARN
                        TestVerdict.FAIL -> LogLine.Level.ERROR
                    },
                    "Тест «${it.title}»: ${it.summary}"
                )
            }
        }
    }

    fun formatLogs(lines: List<LogLine>): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        return lines.joinToString("\n") { "${fmt.format(Date(it.time))} [${it.level.name}] ${it.message}" }
    }

    fun copyLogs(lines: List<LogLine>) {
        val cm = ctx.getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("MAIN VPN log", formatLogs(lines)))
        message("Скопировано строк: ${lines.size}")
    }

    fun exportLogs(uri: Uri, lines: List<LogLine>) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(formatLogs(lines).toByteArray()) }
                        ?: throw IOException("не удалось открыть файл")
                }
                message("Журнал сохранён")
            } catch (e: Exception) {
                message("Ошибка сохранения: ${e.message}")
            }
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { LogFile.clear(ctx) }
            _logs.value = emptyList()
        }
    }

    companion object {
        private const val MAX_LOGS = 5000

        private fun initialStatus(context: Context): VpnStatus {
            val saved = VpnStatus.load(context) ?: return VpnStatus()
            val am = context.getSystemService(ActivityManager::class.java)
            val vpnProcess = context.packageName + Protocol.VPN_PROCESS_SUFFIX
            val alive = am.runningAppProcesses?.any { it.processName == vpnProcess } == true
            return if (saved.running && !alive) VpnStatus() else saved
        }
    }
}
