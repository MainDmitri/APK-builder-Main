package com.example.mainvpn.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mainvpn.core.ConnState
import com.example.mainvpn.core.LogLine
import com.example.mainvpn.core.VpnStatus
import com.example.mainvpn.diag.TestResult
import com.example.mainvpn.diag.TestVerdict
import com.example.mainvpn.ui.theme.StatusConnected
import com.example.mainvpn.ui.theme.StatusConnecting
import com.example.mainvpn.ui.theme.StatusError
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DiagnosticsScreen(vm: MainViewModel, status: VpnStatus, modifier: Modifier = Modifier) {
    val diagnostics by vm.diagnostics.collectAsStateWithLifecycle()
    val logs by vm.logs.collectAsStateWithLifecycle()
    var showInfo by rememberSaveable { mutableStateOf(true) }
    var showWarn by rememberSaveable { mutableStateOf(true) }
    var showError by rememberSaveable { mutableStateOf(true) }
    var query by rememberSaveable { mutableStateOf("") }

    val filtered = remember(logs, showInfo, showWarn, showError, query) {
        logs.filter { line ->
            val levelOk = when (line.level) {
                LogLine.Level.INFO -> showInfo
                LogLine.Level.WARN -> showWarn
                LogLine.Level.ERROR -> showError
            }
            levelOk && (query.isBlank() || line.message.contains(query, ignoreCase = true))
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) vm.exportLogs(uri, filtered)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Button(
            onClick = { vm.runSecurityTests() },
            enabled = !diagnostics.running && status.state == ConnState.CONNECTED,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (diagnostics.running) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
            } else {
                Icon(Icons.Filled.Lock, contentDescription = null)
            }
            Spacer(Modifier.width(8.dp))
            Text(if (diagnostics.running) "Идёт тестирование…" else "Тестирование безопасности")
        }
        if (status.state != ConnState.CONNECTED) {
            Text(
                "Тесты доступны при активном туннеле",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        if (diagnostics.finishedAt > 0) {
            Text(
                "Последний запуск: " + SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault()).format(Date(diagnostics.finishedAt)),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        diagnostics.results.forEach { result ->
            Spacer(Modifier.height(8.dp))
            ResultCard(result)
        }

        Spacer(Modifier.height(16.dp))
        Text("Журнал событий", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = showInfo, onClick = { showInfo = !showInfo }, label = { Text("Info") })
            FilterChip(selected = showWarn, onClick = { showWarn = !showWarn }, label = { Text("Warn") })
            FilterChip(selected = showError, onClick = { showError = !showError }, label = { Text("Error") })
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            placeholder = { Text("Поиск по журналу") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.copyLogs(filtered) }, enabled = filtered.isNotEmpty()) { Text("Копировать") }
            IconButton(
                onClick = {
                    val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
                    exportLauncher.launch("mainvpn-log-$stamp.txt")
                },
                enabled = filtered.isNotEmpty()
            ) { Icon(Icons.Filled.Share, contentDescription = "Сохранить в файл") }
            IconButton(onClick = { vm.clearLogs() }, enabled = logs.isNotEmpty()) {
                Icon(Icons.Filled.Delete, contentDescription = "Очистить журнал")
            }
            Spacer(Modifier.weight(1f))
            Text("${filtered.size} / ${logs.size}", style = MaterialTheme.typography.bodySmall)
        }
        Terminal(filtered)
    }
}

@Composable
private fun ResultCard(result: TestResult) {
    val (icon, color) = when (result.verdict) {
        TestVerdict.PASS -> Icons.Filled.Check to StatusConnected
        TestVerdict.WARN -> Icons.Filled.Warning to StatusConnecting
        TestVerdict.FAIL -> Icons.Filled.Close to StatusError
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = color)
                Spacer(Modifier.width(8.dp))
                Text(result.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
            }
            Text(result.summary, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
            result.details.forEach {
                Text("• $it", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
}

@Composable
private fun Terminal(lines: List<LogLine>) {
    val state = rememberLazyListState()
    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) state.scrollToItem(lines.lastIndex)
    }
    val fmt = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(420.dp)
            .background(Color(0xFF101418), RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        if (lines.isEmpty()) {
            Text("Журнал пуст", color = Color(0xFF9E9E9E), style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp))
        }
        LazyColumn(state = state, modifier = Modifier.fillMaxSize()) {
            items(lines) { line ->
                val color = when (line.level) {
                    LogLine.Level.INFO -> Color(0xFFB9F6CA)
                    LogLine.Level.WARN -> Color(0xFFFFE082)
                    LogLine.Level.ERROR -> Color(0xFFFF8A80)
                }
                Text(
                    text = "${fmt.format(Date(line.time))} ${line.level.name.padEnd(5)} ${line.message}",
                    color = color,
                    style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 14.sp)
                )
            }
        }
    }
}
