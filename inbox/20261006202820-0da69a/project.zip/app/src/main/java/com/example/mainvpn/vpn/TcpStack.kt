package com.example.mainvpn.vpn

import android.os.SystemClock
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/** Диспетчер TCP-сессий: каждое соединение приложения превращается в поток SOCKS5 через Tor. */
class TcpStack(
    private val tun: TunWriter,
    val socksPort: () -> Int,
    private val rejectDestination: (ByteArray, Int) -> Boolean
) {
    private val sessions = ConcurrentHashMap<String, TcpSession>()

    val connectExecutor: ExecutorService = Executors.newCachedThreadPool { r ->
        Thread(null, r, "tcp-connect", 128 * 1024).apply { isDaemon = true }
    }

    private val timer: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "tcp-timer").apply { isDaemon = true }
    }

    init {
        timer.scheduleWithFixedDelay({
            val now = SystemClock.elapsedRealtime()
            for (s in sessions.values) {
                if (s.tick(now)) sessions.remove(s.key)
            }
        }, 250, 250, TimeUnit.MILLISECONDS)
    }

    val sessionCount: Int get() = sessions.size

    fun send(packet: ByteArray) = tun.write(packet)

    fun remove(key: String) {
        sessions.remove(key)
    }

    fun startThread(name: String, body: () -> Unit) {
        Thread(null, { body() }, name, 128 * 1024).apply {
            isDaemon = true
            start()
        }
    }

    fun handle(p: IpPacket.Parsed, buf: ByteArray) {
        val off = p.payloadOffset
        if (p.payloadEnd - off < 20) return
        val srcPort = IpPacket.u16(buf, off)
        val dstPort = IpPacket.u16(buf, off + 2)
        val seq = IpPacket.u32(buf, off + 4)
        val ack = IpPacket.u32(buf, off + 8)
        val dataOffset = ((buf[off + 12].toInt() ushr 4) and 0x0F) * 4
        if (dataOffset < 20 || off + dataOffset > p.payloadEnd) return
        val flags = buf[off + 13].toInt() and 0xFF
        val window = IpPacket.u16(buf, off + 14)
        val payloadStart = off + dataOffset
        val payloadLen = p.payloadEnd - payloadStart

        val key = "${IpPacket.addressString(p.src)}|$srcPort|${IpPacket.addressString(p.dst)}|$dstPort"
        val existing = sessions[key]
        if (existing != null) {
            existing.onSegment(seq, ack, flags, window, buf, payloadStart, payloadLen)
            return
        }
        if (flags and IpPacket.RST != 0) return
        val isNewSyn = (flags and IpPacket.SYN) != 0 && (flags and IpPacket.ACK) == 0
        if (!isNewSyn || socksPort() <= 0 || rejectDestination(p.dst, dstPort)) {
            sendReset(p, srcPort, dstPort, seq, ack, flags, payloadLen)
            return
        }
        val maxMss = if (p.version == 4) PacketEngine.MTU - 40 else PacketEngine.MTU - 60
        val mss = (parseMss(buf, off + 20, off + dataOffset) ?: 536).coerceIn(536, maxMss)
        val session = TcpSession(this, key, p.src, srcPort, p.dst, dstPort)
        sessions[key] = session
        session.onSyn(seq, window, mss)
    }

    private fun parseMss(buf: ByteArray, from: Int, to: Int): Int? {
        var i = from
        while (i < to) {
            when (val kind = buf[i].toInt() and 0xFF) {
                0 -> return null
                1 -> i++
                else -> {
                    if (i + 1 >= to) return null
                    val len = buf[i + 1].toInt() and 0xFF
                    if (len < 2 || i + len > to) return null
                    if (kind == 2 && len == 4) return IpPacket.u16(buf, i + 2)
                    i += len
                }
            }
        }
        return null
    }

    private fun sendReset(p: IpPacket.Parsed, srcPort: Int, dstPort: Int, seq: Int, ack: Int, flags: Int, payloadLen: Int) {
        val packet = if (flags and IpPacket.ACK != 0) {
            IpPacket.buildTcp(p.dst, p.src, dstPort, srcPort, ack, 0, IpPacket.RST, 0, null, null, 0, 0)
        } else {
            var consumed = payloadLen
            if (flags and IpPacket.SYN != 0) consumed++
            if (flags and IpPacket.FIN != 0) consumed++
            IpPacket.buildTcp(
                p.dst, p.src, dstPort, srcPort, 0, seq + consumed,
                IpPacket.RST or IpPacket.ACK, 0, null, null, 0, 0
            )
        }
        tun.write(packet)
    }

    fun shutdown() {
        timer.shutdownNow()
        for (s in sessions.values) s.abort()
        sessions.clear()
        connectExecutor.shutdownNow()
    }
}
