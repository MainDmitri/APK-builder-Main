package com.example.mainvpn.tor

import IPtProxy.Controller
import IPtProxy.IPtProxy
import IPtProxy.OnTransportEvents
import android.content.Context
import com.example.mainvpn.core.LogLine
import java.io.File

/**
 * Подключаемые транспорты (obfs4/lyrebird, Snowflake, meek, webtunnel) из библиотеки IPtProxy.
 * Каждый транспорт поднимает локальный SOCKS-порт, который передаётся Tor через ClientTransportPlugin.
 */
class PluggableTransports(
    private val context: Context,
    private val log: (LogLine.Level, String) -> Unit
) {
    private var controller: Controller? = null
    private val running = LinkedHashMap<String, Int>()

    private val supported = setOf(
        IPtProxy.Obfs4, IPtProxy.Obfs3, IPtProxy.ScrambleSuit,
        IPtProxy.MeekLite, IPtProxy.Webtunnel, IPtProxy.Snowflake
    )

    private fun controller(): Controller {
        controller?.let { return it }
        val stateDir = File(context.filesDir, "pt_state").apply { mkdirs() }
        val created = IPtProxy.newController(
            stateDir.absolutePath,
            true,
            false,
            "INFO",
            object : OnTransportEvents {
                override fun connected(transport: String?) {
                    log(LogLine.Level.INFO, "Транспорт $transport: соединение установлено")
                }

                override fun error(transport: String?, error: Exception?) {
                    log(LogLine.Level.WARN, "Транспорт $transport: ${error?.message ?: "ошибка"}")
                }

                override fun stopped(transport: String?, error: Exception?) {
                    log(
                        if (error == null) LogLine.Level.INFO else LogLine.Level.WARN,
                        "Транспорт $transport остановлен${error?.message?.let { ": $it" } ?: ""}"
                    )
                }
            }
        )
        controller = created
        return created
    }

    fun isSupported(transport: String): Boolean = transport in supported

    /**
     * Запускает транспорт (если ещё не запущен) и возвращает его локальный SOCKS-порт.
     * Для Snowflake параметры брокера, фронтинга и STUN берутся из строки моста.
     */
    @Synchronized
    fun start(transport: String, bridgeLine: String?): Int {
        running[transport]?.let { return it }
        val c = controller()
        if (transport == IPtProxy.Snowflake && bridgeLine != null) {
            val a = Bridges.args(bridgeLine)
            a["url"]?.let { c.snowflakeBrokerUrl = it }
            (a["fronts"] ?: a["front"])?.let { c.snowflakeFrontDomains = it }
            a["ice"]?.let { c.snowflakeIceServers = it }
            a["ampcache"]?.let { c.snowflakeAmpCacheUrl = it }
            a["sqsqueue"]?.let { c.snowflakeSqsUrl = it }
            a["sqscreds"]?.let { c.snowflakeSqsCreds = it }
            c.snowflakeMaxPeers = 1L
        }
        c.start(transport, "")
        val port = c.port(transport).toInt()
        if (port <= 0) throw IllegalStateException("Транспорт $transport не открыл локальный порт")
        running[transport] = port
        log(LogLine.Level.INFO, "Транспорт $transport запущен на 127.0.0.1:$port")
        return port
    }

    @Synchronized
    fun stopAll() {
        val c = controller ?: return
        for (t in running.keys) runCatching { c.stop(t) }
        running.clear()
    }
}
