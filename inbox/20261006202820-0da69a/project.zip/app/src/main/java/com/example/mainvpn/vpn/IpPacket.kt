package com.example.mainvpn.vpn

import java.net.InetAddress
import java.util.concurrent.atomic.AtomicInteger

/** Разбор и сборка IPv4/IPv6-пакетов с TCP/UDP для TUN-интерфейса. */
object IpPacket {

    const val PROTO_TCP = 6
    const val PROTO_UDP = 17

    const val FIN = 0x01
    const val SYN = 0x02
    const val RST = 0x04
    const val PSH = 0x08
    const val ACK = 0x10

    class Parsed(
        val version: Int,
        val protocol: Int,
        val src: ByteArray,
        val dst: ByteArray,
        val payloadOffset: Int,
        val payloadEnd: Int
    )

    private val ipId = AtomicInteger(1)

    fun parse(buf: ByteArray, len: Int): Parsed? {
        if (len < 20) return null
        return when ((buf[0].toInt() ushr 4) and 0x0F) {
            4 -> {
                val ihl = (buf[0].toInt() and 0x0F) * 4
                if (ihl < 20 || len < ihl) return null
                val total = u16(buf, 2)
                if (total < ihl || total > len) return null
                val fragment = u16(buf, 6)
                // Фрагменты (MF или смещение) не собираем: TCP с DF и DNS фрагментируются крайне редко.
                if ((fragment and 0x2000) != 0 || (fragment and 0x1FFF) != 0) return null
                Parsed(4, buf[9].toInt() and 0xFF, buf.copyOfRange(12, 16), buf.copyOfRange(16, 20), ihl, total)
            }
            6 -> {
                if (len < 40) return null
                val payloadLen = u16(buf, 4)
                if (40 + payloadLen > len) return null
                Parsed(6, buf[6].toInt() and 0xFF, buf.copyOfRange(8, 24), buf.copyOfRange(24, 40), 40, 40 + payloadLen)
            }
            else -> null
        }
    }

    fun u16(b: ByteArray, off: Int): Int =
        ((b[off].toInt() and 0xFF) shl 8) or (b[off + 1].toInt() and 0xFF)

    fun u32(b: ByteArray, off: Int): Int =
        ((b[off].toInt() and 0xFF) shl 24) or ((b[off + 1].toInt() and 0xFF) shl 16) or
            ((b[off + 2].toInt() and 0xFF) shl 8) or (b[off + 3].toInt() and 0xFF)

    private fun put16(b: ByteArray, off: Int, v: Int) {
        b[off] = (v ushr 8).toByte()
        b[off + 1] = v.toByte()
    }

    private fun put32(b: ByteArray, off: Int, v: Int) {
        b[off] = (v ushr 24).toByte()
        b[off + 1] = (v ushr 16).toByte()
        b[off + 2] = (v ushr 8).toByte()
        b[off + 3] = v.toByte()
    }

    fun addressString(addr: ByteArray): String = InetAddress.getByAddress(addr).hostAddress ?: "?"

    private fun sum(b: ByteArray, off: Int, len: Int, initial: Long): Long {
        var s = initial
        var i = off
        val end = off + len
        while (i + 1 < end) {
            s += u16(b, i).toLong()
            i += 2
        }
        if (i < end) s += ((b[i].toInt() and 0xFF) shl 8).toLong()
        return s
    }

    private fun fold(s0: Long): Int {
        var s = s0
        while (s ushr 16 != 0L) s = (s and 0xFFFF) + (s ushr 16)
        return s.toInt().inv() and 0xFFFF
    }

    private fun writeIpHeader(pkt: ByteArray, src: ByteArray, dst: ByteArray, proto: Int, l4Len: Int) {
        if (src.size == 4) {
            pkt[0] = 0x45
            pkt[1] = 0
            put16(pkt, 2, 20 + l4Len)
            put16(pkt, 4, ipId.getAndIncrement() and 0xFFFF)
            put16(pkt, 6, 0x4000)
            pkt[8] = 64
            pkt[9] = proto.toByte()
            System.arraycopy(src, 0, pkt, 12, 4)
            System.arraycopy(dst, 0, pkt, 16, 4)
            put16(pkt, 10, fold(sum(pkt, 0, 20, 0)))
        } else {
            pkt[0] = 0x60
            put16(pkt, 4, l4Len)
            pkt[6] = proto.toByte()
            pkt[7] = 64
            System.arraycopy(src, 0, pkt, 8, 16)
            System.arraycopy(dst, 0, pkt, 24, 16)
        }
    }

    private fun pseudoSum(src: ByteArray, dst: ByteArray, proto: Int, l4Len: Int): Long {
        var s = sum(src, 0, src.size, 0)
        s = sum(dst, 0, dst.size, s)
        s += proto.toLong()
        s += l4Len.toLong()
        return s
    }

    fun buildTcp(
        src: ByteArray, dst: ByteArray, srcPort: Int, dstPort: Int,
        seq: Int, ack: Int, flags: Int, window: Int,
        options: ByteArray?, payload: ByteArray?, payloadOff: Int, payloadLen: Int
    ): ByteArray {
        val ipLen = if (src.size == 4) 20 else 40
        val optLen = options?.size ?: 0
        val tcpLen = 20 + optLen + payloadLen
        val pkt = ByteArray(ipLen + tcpLen)
        writeIpHeader(pkt, src, dst, PROTO_TCP, tcpLen)
        val t = ipLen
        put16(pkt, t, srcPort)
        put16(pkt, t + 2, dstPort)
        put32(pkt, t + 4, seq)
        put32(pkt, t + 8, ack)
        pkt[t + 12] = (((20 + optLen) / 4) shl 4).toByte()
        pkt[t + 13] = flags.toByte()
        put16(pkt, t + 14, window.coerceIn(0, 0xFFFF))
        if (options != null) System.arraycopy(options, 0, pkt, t + 20, optLen)
        if (payload != null && payloadLen > 0) System.arraycopy(payload, payloadOff, pkt, t + 20 + optLen, payloadLen)
        val cs = fold(sum(pkt, t, tcpLen, pseudoSum(src, dst, PROTO_TCP, tcpLen)))
        put16(pkt, t + 16, cs)
        return pkt
    }

    fun buildUdp(
        src: ByteArray, dst: ByteArray, srcPort: Int, dstPort: Int,
        payload: ByteArray, payloadOff: Int, payloadLen: Int
    ): ByteArray {
        val ipLen = if (src.size == 4) 20 else 40
        val udpLen = 8 + payloadLen
        val pkt = ByteArray(ipLen + udpLen)
        writeIpHeader(pkt, src, dst, PROTO_UDP, udpLen)
        val u = ipLen
        put16(pkt, u, srcPort)
        put16(pkt, u + 2, dstPort)
        put16(pkt, u + 4, udpLen)
        System.arraycopy(payload, payloadOff, pkt, u + 8, payloadLen)
        var cs = fold(sum(pkt, u, udpLen, pseudoSum(src, dst, PROTO_UDP, udpLen)))
        if (cs == 0) cs = 0xFFFF
        put16(pkt, u + 6, cs)
        return pkt
    }
}
