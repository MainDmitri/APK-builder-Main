package com.example.mainvpn.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.mainvpn.core.ConnState
import com.example.mainvpn.core.Countries
import com.example.mainvpn.core.VpnStatus
import com.example.mainvpn.data.AppSettings

@Composable
fun DashboardScreen(
    status: VpnStatus,
    settings: AppSettings,
    onPower: () -> Unit,
    onNewIdentity: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(8.dp))
        PowerButton(state = status.state, onClick = onPower)
        Spacer(Modifier.height(12.dp))
        Text(
            text = stateTitle(status.state),
            style = MaterialTheme.typography.headlineSmall,
            color = stateColor(status.state),
            fontWeight = FontWeight.SemiBold
        )
        if (status.message.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = status.message,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
        }
        if (status.state == ConnState.CONNECTING) {
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { status.bootstrap / 100f },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "Bootstrap ${status.bootstrap}%" +
                    if (status.bootstrapSummary.isNotEmpty()) " — ${status.bootstrapSummary}" else "",
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(20.dp))
        StatusCard(status = status, onNewIdentity = onNewIdentity)
        Spacer(Modifier.height(12.dp))
        ModeCard(status = status, settings = settings)
    }
}

@Composable
private fun PowerButton(state: ConnState, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "power")
    val pulse by transition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulse"
    )
    val color by animateColorAsState(stateColor(state), label = "powerColor")
    val pulsing = state == ConnState.CONNECTING || state == ConnState.UPDATING
    val description = if (state == ConnState.OFF || state == ConnState.ERROR) "Подключить" else "Отключить"

    Box(
        modifier = Modifier
            .size(210.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val radius = size.minDimension / 2f
            when (state) {
                ConnState.CONNECTED -> drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(color.copy(alpha = 0.55f), Color.Transparent),
                        center = center,
                        radius = radius
                    ),
                    radius = radius
                )
                ConnState.CONNECTING, ConnState.UPDATING -> drawCircle(color.copy(alpha = 0.3f * pulse), radius)
                ConnState.ERROR -> drawCircle(color.copy(alpha = 0.2f), radius)
                ConnState.OFF -> Unit
            }
            val ring = radius * 0.74f
            if (state == ConnState.OFF) {
                drawCircle(color, ring, style = Stroke(width = 6.dp.toPx()))
            } else {
                drawCircle(color.copy(alpha = if (pulsing) 0.6f + 0.4f * pulse else 1f), ring)
            }
            val iconColor = if (state == ConnState.OFF) color else Color.White
            val r = ring * 0.42f
            val stroke = 9.dp.toPx()
            drawArc(
                color = iconColor,
                startAngle = -60f,
                sweepAngle = 300f,
                useCenter = false,
                topLeft = Offset(center.x - r, center.y - r),
                size = Size(r * 2, r * 2),
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            drawLine(
                color = iconColor,
                start = Offset(center.x, center.y - r * 1.3f),
                end = Offset(center.x, center.y - r * 0.15f),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
private fun StatusCard(status: VpnStatus, onNewIdentity: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Статус туннеля",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                FilledTonalButton(
                    onClick = onNewIdentity,
                    enabled = status.state == ConnState.CONNECTED
                ) {
                    if (status.state == ConnState.UPDATING) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                    Spacer(Modifier.width(6.dp))
                    Text("Новая личность")
                }
            }
            Spacer(Modifier.height(8.dp))
            HorizontalDivider()
            Spacer(Modifier.height(8.dp))
            val active = status.state == ConnState.CONNECTED || status.state == ConnState.UPDATING
            InfoRow("Выходной IP (Exit Node)", if (active && status.exitIp.isNotEmpty()) status.exitIp else "—")
            InfoRow(
                "Страна выхода",
                if (active && status.exitCountry.isNotEmpty()) {
                    "${Countries.flag(status.exitCountry)} ${Countries.name(status.exitCountry)}"
                } else "—"
            )
            InfoRow("Пинг (через цепочку)", if (active && status.pingMs >= 0) "${status.pingMs} мс" else "—")
            InfoRow("Приём ↓", if (status.running) formatRate(status.rxRate) else "—")
            InfoRow("Передача ↑", if (status.running) formatRate(status.txRate) else "—")
            InfoRow(
                "Всего за сеанс",
                if (status.running) "↓ ${formatBytes(status.rxTotal)}  ↑ ${formatBytes(status.txTotal)}" else "—"
            )
            InfoRow("Проверка Tor", if (active && status.exitIp.isNotEmpty()) (if (status.isTor) "IsTor = true" else "НЕ Tor") else "—")
        }
    }
}

@Composable
private fun ModeCard(status: VpnStatus, settings: AppSettings) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Режим", style = MaterialTheme.typography.titleMedium)
            InfoRow("Подключение", settings.bridgeMode.title)
            InfoRow(
                "Страна выхода",
                if (settings.exitCountry.isEmpty()) "Автоматически" else
                    "${Countries.flag(settings.exitCountry)} ${Countries.name(settings.exitCountry)}"
            )
            InfoRow("Kill Switch", if (settings.killSwitch) "включён" else "выключен")
            InfoRow("Защита DNS", if (settings.dnsProtection) "включена" else "выключена")
            if (status.running) {
                InfoRow("TCP-соединений в туннеле", status.tcpSessions.toString())
                InfoRow("Трафик", if (status.networkFrozen) "заморожен" else "передаётся")
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1f)
        )
    }
}
