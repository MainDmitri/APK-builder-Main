package com.example.mainvpn.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mainvpn.core.VpnStatus
import com.example.mainvpn.data.AppSettings
import com.example.mainvpn.data.BridgeMode
import com.example.mainvpn.tor.Bridges

@Composable
fun SettingsScreen(vm: MainViewModel, status: VpnStatus, settings: AppSettings, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val apps by vm.apps.collectAsStateWithLifecycle()
    val refreshing by vm.bridgeRefreshRunning.collectAsStateWithLifecycle()
    var appQuery by rememberSaveable { mutableStateOf("") }
    var customDraft by rememberSaveable(settings.customBridges) { mutableStateOf(settings.customBridges) }

    LaunchedEffect(Unit) { vm.loadApps() }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    SwitchRow(
                        title = "Аварийная блокировка (Kill Switch)",
                        checked = settings.killSwitch,
                        onChange = { v -> vm.updateSettings { it.copy(killSwitch = v) } }
                    )
                    Text(
                        "Если Tor упадёт или зависнет, VPN-интерфейс останется поднятым, а весь трафик будет " +
                            "заблокирован до вашего отключения. Защиту на случай остановки самого приложения даёт " +
                            "только системный режим «Постоянная VPN» + «Блокировать соединения без VPN».",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Системная блокировка: " + when {
                            !status.running -> "статус виден при подключении"
                            status.lockdownEnabled -> "включена ✅"
                            status.alwaysOn -> "постоянная VPN включена, блокировка без VPN — нет"
                            else -> "выключена"
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )
                    TextButton(onClick = {
                        try {
                            context.startActivity(Intent(Settings.ACTION_VPN_SETTINGS))
                        } catch (e: ActivityNotFoundException) {
                            vm.message("Системные настройки VPN недоступны на этом устройстве")
                        }
                    }) { Text("Открыть системные настройки VPN") }
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    SwitchRow(
                        title = "Защита от утечек DNS",
                        checked = settings.dnsProtection,
                        onChange = { v -> vm.updateSettings { it.copy(dnsProtection = v) } }
                    )
                    Text(
                        "Все DNS-запросы (порт 53) из туннеля перехватываются и отправляются в DNSPort Tor. " +
                            "Если выключить, запросы пойдут напрямую к DNS провайдера.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Обход блокировок (Bridges)", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    BridgeMode.entries.forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .selectable(
                                    selected = settings.bridgeMode == mode,
                                    onClick = { vm.updateSettings { it.copy(bridgeMode = mode) } },
                                    role = Role.RadioButton
                                )
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = settings.bridgeMode == mode, onClick = null)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(mode.title)
                                Text(
                                    text = when (mode) {
                                        BridgeMode.DIRECT -> "Прямое соединение с узлами Tor"
                                        BridgeMode.OBFS4 -> "Обфусцированные мосты, трафик не похож на Tor"
                                        BridgeMode.SNOWFLAKE -> "Через WebRTC-прокси добровольцев, обходит DPI"
                                        BridgeMode.CUSTOM -> "Строки мостов от bridges.torproject.org"
                                    },
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                    if (settings.bridgeMode == BridgeMode.CUSTOM) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = customDraft,
                            onValueChange = { customDraft = it },
                            label = { Text("Строки мостов, по одной на строку") },
                            placeholder = { Text("obfs4 1.2.3.4:443 FINGERPRINT cert=… iat-mode=0") },
                            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            minLines = 4,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            "Получить мосты: https://bridges.torproject.org или Telegram-бот @GetBridgesBot. " +
                                "Поддерживаются obfs4, webtunnel, snowflake, meek_lite и обычные мосты.",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                val count = Bridges.parseCustom(customDraft).size
                                if (count == 0) {
                                    vm.message("Введите хотя бы одну строку моста")
                                } else {
                                    vm.updateSettings { it.copy(customBridges = customDraft.trim()) }
                                    vm.message("Сохранено мостов: $count")
                                }
                            },
                            enabled = customDraft.trim() != settings.customBridges
                        ) { Text("Сохранить мосты") }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { vm.refreshBuiltinBridges() }, enabled = !refreshing) {
                        if (refreshing) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                        Text("Обновить встроенные мосты (Moat)")
                    }
                    Text(
                        if (settings.builtinBridgesJson.isEmpty()) "Используется список, встроенный в приложение"
                        else "Используется список, загруженный из Moat API",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Раздельное туннелирование (Split Tunneling)", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Отмеченные приложения будут ходить в интернет напрямую, мимо Tor (например, банковские " +
                            "клиенты). Изменения применяются при следующем подключении. Исключено: ${settings.excludedApps.size}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = appQuery,
                        onValueChange = { appQuery = it },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        placeholder = { Text("Поиск приложения") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        val list = apps
        if (list == null) {
            item {
                Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        } else {
            val filtered = list.filter {
                appQuery.isBlank() || it.label.contains(appQuery, ignoreCase = true) ||
                    it.packageName.contains(appQuery, ignoreCase = true)
            }
            items(filtered, key = { it.packageName }) { app ->
                val excluded = app.packageName in settings.excludedApps
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.toggleExcluded(app.packageName, !excluded) }
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val icon = app.icon
                    if (icon != null) {
                        Image(bitmap = icon, contentDescription = null, modifier = Modifier.size(36.dp))
                    } else {
                        Spacer(Modifier.size(36.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(app.label, style = MaterialTheme.typography.bodyLarge)
                        Text(app.packageName, style = MaterialTheme.typography.bodySmall)
                    }
                    Checkbox(checked = excluded, onCheckedChange = { vm.toggleExcluded(app.packageName, it) })
                }
            }
        }
    }
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
