package com.example.mainvpn.net

import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder

/** Клиент публичного API Onionoo (сведения о реле Tor). Все запросы идут через Tor. */
object Onionoo {

    private const val BASE = "https://onionoo.torproject.org/details"

    data class Relay(
        val fingerprint: String,
        val nickname: String,
        val country: String,
        val asName: String
    )

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun relays(socksPort: Int, query: String): List<JSONObject> {
        val resp = TorHttp.get(socksPort, "$BASE?$query", timeoutMs = 45_000, maxBytes = 8_000_000)
        if (resp.code != 200) throw IOException("Onionoo вернул HTTP ${resp.code}")
        val arr = JSONObject(resp.text()).optJSONArray("relays") ?: return emptyList()
        return (0 until arr.length()).map { arr.getJSONObject(it) }
    }

    private fun toRelay(o: JSONObject) = Relay(
        fingerprint = o.optString("fingerprint"),
        nickname = o.optString("nickname"),
        country = o.optString("country"),
        asName = o.optString("as_name")
    )

    fun lookup(socksPort: Int, fingerprint: String): Relay? =
        relays(socksPort, "lookup=${enc(fingerprint)}&fields=fingerprint,nickname,country,as_name")
            .firstOrNull()?.let(::toRelay)

    fun searchByIp(socksPort: Int, ip: String): Relay? =
        relays(socksPort, "type=relay&search=${enc(ip)}&fields=fingerprint,nickname,country,as_name")
            .firstOrNull()?.let(::toRelay)

    /** Отпечатки работающих выходных узлов страны [country], самые мощные первыми. */
    fun exitFingerprints(socksPort: Int, country: String, limit: Int = 150): List<String> =
        relays(
            socksPort,
            "type=relay&running=true&flag=Exit&country=${enc(country)}" +
                "&order=-consensus_weight&limit=$limit&fields=fingerprint"
        ).map { it.optString("fingerprint") }.filter { it.length == 40 }

    /** Количество работающих выходных узлов по странам. */
    fun exitCountryCounts(socksPort: Int): Map<String, Int> {
        val counts = HashMap<String, Int>()
        relays(socksPort, "type=relay&running=true&flag=Exit&fields=country").forEach { o ->
            val cc = o.optString("country")
            if (cc.length == 2) counts[cc] = (counts[cc] ?: 0) + 1
        }
        return counts
    }
}
