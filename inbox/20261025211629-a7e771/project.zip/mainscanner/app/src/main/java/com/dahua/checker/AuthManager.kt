package com.dahua.checker

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class UserInfo(
    val nickname: String,
    val code: String,
    val activatedAt: Long
)

object AuthManager {

    // Секретный ключ для генерации кодов (HMAC)
    private const val SECRET_KEY = "MainDmitri_secret_2024_xK9m"

    private const val PREFS_NAME = "ms_auth_x7k"
    private const val KEY_ACTIVATED = "ax_st"
    private const val KEY_NICKNAME = "ax_nk"
    private const val KEY_USERS = "ax_users"

    private val adminPasswordHash: String by lazy {
        sha256hex("MainC4yt552" + "slt_x9k")
    }

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    // ─── Локальное состояние ───

    fun isActivated(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_ACTIVATED, false)
    }

    fun getActiveNickname(context: Context): String {
        return getPrefs(context).getString(KEY_NICKNAME, "") ?: ""
    }

    private fun saveActivation(context: Context, nickname: String) {
        getPrefs(context).edit()
            .putBoolean(KEY_ACTIVATED, true)
            .putString(KEY_NICKNAME, nickname)
            .apply()
    }

    fun deactivate(context: Context) {
        getPrefs(context).edit()
            .remove(KEY_ACTIVATED)
            .remove(KEY_NICKNAME)
            .apply()
    }

    fun verifyAdminPassword(password: String): Boolean {
        return sha256hex(password + "slt_x9k") == adminPasswordHash
    }

    // ─── Генерация кода по никнейму (детерминированная, HMAC-SHA256) ───
    // Формат: XXXX-XXXX-XXXX (12 символов + 2 дефиса = 14)

    private fun generateCodeForNickname(nickname: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(SECRET_KEY.toByteArray(), "HmacSHA256"))
        val hash = mac.doFinal(nickname.trim().lowercase().toByteArray())

        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val sb = StringBuilder()
        for (i in 0 until 12) {
            if (i > 0 && i % 4 == 0) sb.append('-')
            val idx = (hash[i].toInt() and 0xFF) % chars.length
            sb.append(chars[idx])
        }
        return sb.toString()
    }

    // ─── Активация: проверка кода локально ───

    fun activate(context: Context, nickname: String, code: String): Result<Boolean> {
        return try {
            val expected = generateCodeForNickname(nickname.trim())
            // Убираем пробелы и дефисы, сравниваем только буквы/цифры
            val inputClean = code.trim().uppercase().replace("-", "").replace(" ", "")
            val expectedClean = expected.replace("-", "")
            if (inputClean == expectedClean) {
                saveActivation(context, nickname.trim())
                Result.success(true)
            } else {
                Result.success(false)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─── Админ: генерация кода для пользователя ───

    fun generateCode(context: Context, nickname: String): Result<String> {
        return try {
            val trimmed = nickname.trim()
            if (trimmed.isEmpty()) {
                return Result.failure(Exception("Пустой никнейм"))
            }
            val code = generateCodeForNickname(trimmed)

            // Сохраняем в список выданных кодов
            val users = loadUsers(context).toMutableList()
            val existing = users.indexOfFirst { it.nickname.lowercase() == trimmed.lowercase() }
            if (existing >= 0) {
                return Result.success(users[existing].code)
            }
            users.add(UserInfo(trimmed, code, System.currentTimeMillis()))
            saveUsers(context, users)

            Result.success(code)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─── Админ: список пользователей ───

    fun getUsers(context: Context): Result<List<UserInfo>> {
        return try {
            Result.success(loadUsers(context))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─── Админ: удаление пользователя ───

    fun deleteUser(context: Context, nickname: String): Result<Boolean> {
        return try {
            val users = loadUsers(context).toMutableList()
            val removed = users.removeAll { it.nickname.lowercase() == nickname.trim().lowercase() }
            if (removed) {
                saveUsers(context, users)
            }
            Result.success(removed)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─── Хранение списка пользователей в SharedPreferences (JSON) ───

    private fun loadUsers(context: Context): List<UserInfo> {
        val json = getPrefs(context).getString(KEY_USERS, "[]") ?: "[]"
        val arr = JSONArray(json)
        val list = mutableListOf<UserInfo>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                UserInfo(
                    nickname = obj.getString("nickname"),
                    code = obj.getString("code"),
                    activatedAt = obj.optLong("createdAt", 0L)
                )
            )
        }
        return list
    }

    private fun saveUsers(context: Context, users: List<UserInfo>) {
        val arr = JSONArray()
        for (u in users) {
            val obj = JSONObject()
            obj.put("nickname", u.nickname)
            obj.put("code", u.code)
            obj.put("createdAt", u.activatedAt)
            arr.put(obj)
        }
        getPrefs(context).edit()
            .putString(KEY_USERS, arr.toString())
            .apply()
    }

    private fun sha256hex(text: String): String {
        return MessageDigest.getInstance("SHA-256")
            .digest(text.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }
}
