import { useState } from 'react';

export default function SnapshotsTab({ snapshots }) {
  const [viewUrl, setViewUrl] = useState(null);
  const entries = Object.entries(snapshots);
  return (
    <div className="tab-content">
      <div className="snap-grid">
        {entries.map(([name, url]) => (
          <div key={name} className="snap-thumb" onClick={() => setViewUrl(url)}>
            <img src={url} alt={name} loading="lazy" />
            <span className="snap-name">{name}</span>
          </div>
        ))}
      </div>
      {entries.length === 0 && <div className="empty">No snapshots found in archive</div>}
      {viewUrl && (
        <div className="overlay" onClick={() => setViewUrl(null)}>
          <img src={viewUrl} alt="full" />
        </div>
      )}
    </div>
  );
}