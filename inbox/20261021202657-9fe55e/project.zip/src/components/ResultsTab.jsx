import { useState, useMemo } from 'react';
import ResultCard from './ResultCard';

export default function ResultsTab({ results, snapshots }) {
  const [search, setSearch] = useState('');
  const [selectedSnapshot, setSelectedSnapshot] = useState(null);
  const filtered = useMemo(() => {
    if (!search.trim()) return results;
    const q = search.toLowerCase();
    return results.filter(r =>
      r.ip.includes(q) || r.device.toLowerCase().includes(q) ||
      r.user.toLowerCase().includes(q) || r.vuln.toLowerCase().includes(q)
    );
  }, [results, search]);
  const getSnapshot = (row) => {
    const candidates = [
      `${row.ip}_${row.port}.jpg`, `${row.ip}_${row.port}.png`,
      `${row.ip}.jpg`, `${row.ip}.png`,
      `${row.ip.replace(/\./g, '_')}_${row.port}.jpg`,
      `${row.ip.replace(/\./g, '_')}.jpg`
    ];
    for (const c of candidates) {
      if (snapshots[c.toLowerCase()]) return snapshots[c.toLowerCase()];
    }
    return null;
  };
  return (
    <div className="tab-content">
      <div className="search-bar">
        <input type="text" placeholder="Search IP, device, creds…" value={search}
          onChange={e => setSearch(e.target.value)} className="search-input" />
        <span className="count">{filtered.length}/{results.length}</span>
      </div>
      <div className="results-list">
        {filtered.map((row, i) => (
          <ResultCard key={`${row.ip}-${row.port}-${i}`} row={row}
            snapshotUrl={getSnapshot(row)}
            onTap={(r) => { const s = getSnapshot(r); if (s) setSelectedSnapshot(s); }} />
        ))}
      </div>
      {filtered.length === 0 && <div className="empty">No matching results</div>}
      {selectedSnapshot && (
        <div className="overlay" onClick={() => setSelectedSnapshot(null)}>
          <img src={selectedSnapshot} alt="full snapshot" />
        </div>
      )}
    </div>
  );
}