import { memo } from 'react';

const ResultCard = memo(function ResultCard({ row, snapshotUrl, onTap }) {
  return (
    <div className="result-card" onClick={() => onTap?.(row)} role="button" tabIndex={0}>
      <div className="card-top">
        <span className="ip-port">{row.ip}:{row.port}</span>
        {row.device && <span className="device-tag">{row.device}</span>}
      </div>
      {(row.user || row.pass) && (
        <div className="creds-row">
          {row.user && <span className="cred user">👤 {row.user}</span>}
          {row.pass && <span className="cred pass">🔑 {row.pass}</span>}
        </div>
      )}
      {row.vuln && <div className="vuln-line">⚠️ {row.vuln}</div>}
      {snapshotUrl && (
        <div className="snapshot-preview">
          <img src={snapshotUrl} alt="snapshot" loading="lazy" />
        </div>
      )}
    </div>
  );
});

export default ResultCard;