export function parseCSV(text) {
  const rows = [];
  let current = '';
  let inQuotes = false;
  let row = [];
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const next = text[i + 1];
    if (inQuotes) {
      if (ch === '"' && next === '"') { current += '"'; i++; }
      else if (ch === '"') { inQuotes = false; }
      else { current += ch; }
    } else {
      if (ch === '"') { inQuotes = true; }
      else if (ch === ',') { row.push(current.trim()); current = ''; }
      else if (ch === '\n' || (ch === '\r' && next === '\n')) {
        row.push(current.trim()); current = '';
        if (row.some(c => c !== '')) rows.push(row);
        row = [];
        if (ch === '\r') i++;
      } else { current += ch; }
    }
  }
  if (current !== '' || row.length > 0) {
    row.push(current.trim());
    if (row.some(c => c !== '')) rows.push(row);
  }
  return rows;
}

export function parseIngramResults(text) {
  const rows = parseCSV(text);
  if (rows.length === 0) return [];
  const first = rows[0];
  const hasHeader = first[0]?.toLowerCase() === 'ip' || first[0]?.toLowerCase() === 'host';
  const dataRows = hasHeader ? rows.slice(1) : rows;
  return dataRows.map(parts => ({
    ip: parts[0] || '', port: parts[1] || '', device: parts[2] || '',
    user: parts[3] || '', pass: parts[4] || '', vuln: parts.slice(5).join(', ').trim()
  })).filter(r => r.ip);
}