import JSZip from 'jszip';
import { parseIngramResults } from './csvParser';

export async function loadIngramZip(file) {
  const zip = await JSZip.loadAsync(file);
  const entries = Object.keys(zip.files);
  const csvPath = entries.find(p => /results\.csv$/i.test(p));
  if (!csvPath) throw new Error('results.csv not found in archive');
  const csvText = await zip.files[csvPath].async('string');
  const results = parseIngramResults(csvText);
  const snapshotEntries = entries.filter(p =>
    /snapshots?\//i.test(p) && /\.(jpg|jpeg|png|gif|webp)$/i.test(p)
  );
  const snapshots = {};
  for (const path of snapshotEntries) {
    try {
      const blob = await zip.files[path].async('blob');
      const url = URL.createObjectURL(blob);
      const name = path.split('/').pop();
      snapshots[name.toLowerCase()] = url;
    } catch (_) {}
  }
  const flatImages = entries.filter(p =>
    !p.includes('/') && /\.(jpg|jpeg|png|gif|webp)$/i.test(p)
  );
  for (const path of flatImages) {
    try {
      const blob = await zip.files[path].async('blob');
      snapshots[path.toLowerCase()] = URL.createObjectURL(blob);
    } catch (_) {}
  }
  return { results, snapshots, fileName: file.name };
}