import { useState, useRef, useCallback } from 'react';
import { loadIngramZip } from './utils/zipLoader';
import ResultsTab from './components/ResultsTab';
import SnapshotsTab from './components/SnapshotsTab';

function App() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('results');
  const fileRef = useRef(null);
  const handleFile = useCallback(async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true); setError(''); setData(null);
    try {
      const result = await loadIngramZip(file);
      setData(result);
      navigator.vibrate?.(30);
    } catch (err) {
      setError(err.message || 'Failed to load archive');
      navigator.vibrate?.([50, 30, 50]);
    } finally { setLoading(false); e.target.value = ''; }
  }, []);
  return (
    <div className="app-shell">
      <div className="safe-top" />
      <header className="app-header">
        <h1>Ingram Viewer</h1>
        {!data && <p className="subtitle">Load your scan results</p>}
      </header>
      {!data && !loading && (
        <div className="upload-zone">
          <input ref={fileRef} type="file" accept=".zip" onChange={handleFile} hidden />
          <button onClick={() => fileRef.current?.click()} className="btn-upload">📦 Load Ingram ZIP</button>
          <p className="upload-hint">ZIP should contain <code>results.csv</code> and optional <code>snapshots/</code> folder</p>
        </div>
      )}
      {loading && <div className="loading-state"><div className="spinner" /><p>Parsing archive…</p></div>}
      {error && (
        <div className="error-box">
          <span>{error}</span>
          <button onClick={() => setError('')} className="btn-dismiss">✕</button>
        </div>
      )}
      {data && (
        <>
          <nav className="tab-bar">
            <button className={`tab ${activeTab === 'results' ? 'active' : ''}`}
              onClick={() => setActiveTab('results')}>Results ({data.results.length})</button>
            <button className={`tab ${activeTab === 'snapshots' ? 'active' : ''}`}
              onClick={() => setActiveTab('snapshots')}>Snapshots ({Object.keys(data.snapshots).length})</button>
            <button className="tab-reload" onClick={() => { setData(null); setError(''); }}>↻</button>
          </nav>
          {activeTab === 'results' && <ResultsTab results={data.results} snapshots={data.snapshots} />}
          {activeTab === 'snapshots' && <SnapshotsTab snapshots={data.snapshots} />}
        </>
      )}
      <div className="safe-bottom" />
    </div>
  );
}

export default App;